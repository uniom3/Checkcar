create view VT_XMLDISPONIVELFATURAMENTO as
select xml.iddepositante, ed.cgc cnpjdepositante,
       ed.inscrestadual iedepositante, ed.razaosocial depositante,
       xml.chaveacesso chaveacessonfe, xml.id h$id,
       xml.idarmazem h$idarmazem, xml.rowid h$tableid
  from xmlfaturamento xml, entidade ed, depositante d
 where ed.identidade = xml.iddepositante
   and d.identidade = xml.iddepositante
   and d.impxmlapenasfaturamento = 1
   and xml.idprenf is null
/

