create view V_ENDERECO as
select ent.codigointerno, decode(ent.pessoa, 'J', ent.cgc, ent.cic) idpessoa,
       e.identidade, e.idendereco, e.tipoendereco, e.cep,
       t.completo tipologr, e.logradouro, e.idbairro, e.idcidade, e.numero,
       e.impressao, e.cobranca, e.correspondencia, e.entrega, e.complemento,
       e.atz, b.descr bairro, t.completo tipo_endereco, c.descr cidade,
       c.estadocidade uf,
       ep.endereco endereco,
       e.descr descricaoendereco, c.codigocidade codexterno,
       p.pais, c.codmunicipio,
       ep.complendereco complendereco, e.codendereco
  from entidade ent, enderecopadrao ep, endereco e, tipoendereco t, bairro b, cidade c, pais p
 where ep.identidade = ent.identidade
   and e.idendereco = ep.idendereco
   and e.identidade = ent.identidade
   and t.idtipoendereco(+) = e.tipoendereco
   and b.idcidade(+) = e.idcidade
   and b.idbairro(+) = e.idbairro
   and c.idcidade(+) = e.idcidade
   and p.idpais(+) = c.pais
/

