create package PK_TROCALOTESEP is

  procedure trocarQtdeAtendidaNF
  (
    p_idnotafiscal in number,
    p_idproduto    in number,
    p_qtdeunit     in number
  );

  function trocarLoteIndustriaSep
  (
    p_idTroca         in number,
    p_idRegiaoDestino in number,
    p_bufferDestino   in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_tarefa          in varchar2 := null
  ) return number;

  function buscarLoteIndustriaParaTroca
  (
    p_idOnda          in number,
    p_idNotaFiscal    in number,
    p_idProduto       in number,
    p_idDepositante   in number,
    p_idArmazem       in number,
    p_idLocalOrigem   in number,
    p_loteIndustria   in varchar2,
    p_barraSeparacao  in varchar2,
    p_qtdeTroca       in number,
    p_idRegiaoDestino in number,
    p_bufferDestino   in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_tarefa          in varchar2 := null,
    p_origemPacking   in number := 0
  ) return number;

end;
/

