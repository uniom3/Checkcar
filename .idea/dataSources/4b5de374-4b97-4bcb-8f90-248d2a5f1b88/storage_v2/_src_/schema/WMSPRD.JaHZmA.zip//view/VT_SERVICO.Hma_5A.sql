create view VT_SERVICO as
select l.idarmazem h$idarmazem, l.idlocal, l.idlocalformatado f$idlocal,
       l.ordem h$ordem, decode(l.ativo, 'S', 1, 0) ativo, s.descr setor,
       l.idsetor, l.tipo, r.descr regiao, 'SERVIÇO' tipolocal, l.id h$id
  from local l, setor s, regiaoarmazenagem r
 where s.idsetor(+) = l.idsetor
   and r.idregiao(+) = l.idregiao
   and l.tipo in (9)
/

