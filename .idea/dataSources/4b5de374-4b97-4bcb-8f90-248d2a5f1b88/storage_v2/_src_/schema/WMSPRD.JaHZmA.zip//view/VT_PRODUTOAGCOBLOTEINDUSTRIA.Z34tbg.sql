create view VT_PRODUTOAGCOBLOTEINDUSTRIA as
select c.loteindustria, c.idlotenf, c.codproduto, c.descricao produto,
       sum(round(c.qtdeacobrir, 6)) qtdeacobrir, c.vlrunit valorunitario,
       c.embalagem, c.fatorconversao, sum(c.qtdeacobrirunid) qtdeacobrirunid,
       c.numnf notafiscal, c.serie, c.dataemissao dtemissao,
       c.cnpjdepositante, c.depositante, c.emitente, c.destinatario,
       c.emitentefantasia fantasiaemitente, c.idproduto, c.iddepositante,
       c.idnotafiscal, c.idarmazem h$idarmazem
  from v_cobertura_notafiscal c
 group by c.loteindustria, c.idlotenf, c.codproduto, c.descricao, c.vlrunit,
          c.embalagem, c.fatorconversao, c.numnf, c.serie, c.dataemissao,
          c.cnpjdepositante, c.depositante, c.emitente, c.destinatario,
          c.emitentefantasia, c.idproduto, c.iddepositante, c.idnotafiscal,
          c.idarmazem
/

