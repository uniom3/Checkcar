create view VT_PRODUTOKIT as
select p.codigointerno, p.descr, e.barra, e.fatorconversao, p.idproduto
  from produto p, embalagem e
 where e.ativo = 'S'
   and e.idproduto = p.idproduto
   and p.multiendereco = 'N'
   and p.ativo = 'S'
   and not exists (select 1
          from produtodepositante
         where idproduto = p.idproduto
           and itemrastreado = 'S')
/

