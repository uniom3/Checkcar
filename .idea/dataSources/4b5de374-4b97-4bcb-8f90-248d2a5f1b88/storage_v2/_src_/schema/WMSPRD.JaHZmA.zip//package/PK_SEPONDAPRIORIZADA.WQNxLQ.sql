create package pk_sepOndaPriorizada is

  procedure removerPriorizacao
  (
    p_idArmazem         number,
    p_idUsuarioCadastro number,
    p_idUsuario         number := null,
    p_log               number := 1
  );

  procedure adicionarPriorizacao
  (
    p_idArmazem         number,
    p_idUsuarioCadastro number,
    p_tipoPriorizacao   number,
    p_packing           number,
    p_packingCheckout   number,
    p_colmeia           number
  );

  function getTextoPrioridade
  (
    p_idUsuario  number,
    p_tipo       number,
    p_prioridade number
  ) return varchar2;

end pk_sepOndaPriorizada;
/

