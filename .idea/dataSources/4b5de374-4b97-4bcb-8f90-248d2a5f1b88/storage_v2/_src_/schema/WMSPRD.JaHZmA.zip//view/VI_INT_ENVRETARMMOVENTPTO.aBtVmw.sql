create view VI_INT_ENVRETARMMOVENTPTO as
select agrupador id, idprenf, serie, numero,
       to_char(dataemissao, 'DDMMYY') dataemissao, cfop,
       trim(to_char(nvl(valortotal, 0), '9999999990.0000')) valortotal,
       trim(to_char(nvl(valoricms, 0), '9999999990.0000')) valoricms,
       trim(to_char(nvl(totalnota, 0), '9999999990.0000')) totalnota,
       recebedorcnpj, situacaonf, clfiscal, formulario,
       to_char(datadigitacao, 'DDMMYY') datadigitacao, chavenfe,
       fornecedor_razaosocial, fornecedor_endereco, fornecedor_complemento,
       fornecedor_bairro, fornecedor_cep, fornecedor_tipo,
       fornecedor_cnpjcpf, fornecedor_nomereduzido, fornecedor_estado,
       fornecedor_codmun, fornecedor_ddd, fornecedor_tel, fornecedor_ie,
       trim(to_char(nvl(baseicms, 0), '9999999990.0000')) baseicms,
       trim(to_char(nvl(isentasicms, 0), '9999999990.0000')) isentasicms,
       trim(to_char(nvl(outrasicms, 0), '9999999990.0000')) outrasicms,
       trim(to_char(nvl(baseicmssubstituido, 0), '9999999990.0000')) baseicmssubstituido,
       trim(to_char(nvl(icmssubstituido, 0), '9999999990.0000')) icmssubstituido,
       trim(to_char(nvl(pis, 0), '9999999990.0000')) pis,
       trim(to_char(nvl(cofins, 0), '9999999990.0000')) cofins
  from int_envio_zz_nfentrada
/

