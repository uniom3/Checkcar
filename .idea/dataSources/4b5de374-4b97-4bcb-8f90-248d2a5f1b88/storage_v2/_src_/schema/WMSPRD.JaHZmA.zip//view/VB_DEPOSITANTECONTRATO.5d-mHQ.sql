create view VB_DEPOSITANTECONTRATO as
select rownum h$tableid, h$idcontrato, iddepositante, codigointerno,
       depositante, cgc
  from (select c.id h$idcontrato, c.identidadepagadora iddepositante,
                e.codigointerno, e.razaosocial depositante, e.cgc
           from contrato c, entidade e
          where e.identidade = c.identidadepagadora
         union
         select c.id, cd.iddepositante iddepositante,
                e.codigointerno, e.razaosocial depositante, e.cgc
           from contratodepositante cd, contrato c, entidade e
          where c.id = cd.idcontrato
            and c.identidadepagadora <> cd.iddepositante
            and e.identidade = cd.iddepositante)
/

