create PACKAGE BODY PK_RECEBIMENTO_BACKLIST IS

  procedure controlaStatusBackList
  (
    p_idnotafiscal in number,
    p_novoStatus   in number
  ) is
    v_backlistvalidado number;
    v_novoStatusUp     number;
  
  begin
    select backlistvalidado
      into v_backlistvalidado
      from notafiscal
     where idnotafiscal = p_idnotafiscal;
  
    if (v_backlistvalidado = p_novoStatus) then
      return;
    end if;
  
    v_novoStatusUp := p_novoStatus;
    if (v_backlistvalidado = BACKLIST_VALIDADO and
       p_novoStatus = BACKLIST_NAO_VALIDADO) then
      v_novoStatusUp := BACKLIST_INVALIDO;
    end if;
  
    update notafiscal
       set backlistvalidado = v_novoStatusUp
     where idnotafiscal = p_idnotafiscal;
  end controlaStatusBackList;

  function manterBackList
  (
    p_idBacklist          in number,
    p_idNfDet             in number,
    p_idusuario           in number,
    p_loteindustria       in varchar,
    p_qtde                in number,
    p_idusuarioSupervisor in number,
    p_idmotivo            in number,
    p_operacao            in number := 0,
    p_dtfabricacao        in date,
    p_vencimento          in date,
    p_atualizar           in number := 0,
    p_correcaoBacklistOr  in number := 0
    
  ) return number is
  
    CONCLUIDO_SUCESSO   constant number := 0;
    SOLICITA_SUPERVISOR constant number := 1;
  
    OPERACAO_ADD_EDIT constant number := 0;
    OPERACAO_DELETE   constant number := 1;
  
    C_NAO constant number := 0;
    C_SIM constant number := 1;
  
    C_ATUALIZARQTDE constant number := 1;
  
    v_depositante                  entidade.razaosocial%type;
    v_backlist                     backlist%rowtype;
    v_idNotaFiscal                 number;
    V_backlistvalidado             number;
    v_tipoBacklist                 number;
    v_coletadtavenclote            number;
    v_depFracionaLote              number;
    v_idlotenf                     number;
    v_idDepositante                number;
    v_bloqltindustriavencdiferente number;
  
    v_idProduto     number;
    v_medicamento   number;
    v_prazoValidade number;
  
    v_msg t_message;
  
    function isBackListORCorrecao(p_idNfDet in number) return boolean is
      v_controle number := 0;
    begin
      select count(1)
        into v_controle
        from notafiscal nf, nfdet nd, lotenf ln
       where nf.idnotafiscal = nd.nf
         and nf.idlotenf = ln.idlotenf
         and nd.idnfdet = p_idNfDet
         and ln.emcorrecaobacklist = C_SIM;
    
      return(v_controle > 0);
    
    end;
  
    procedure validarStatusRecebimento is
    begin
      for c_result in (select h$status
                         from vt_backlistproduto v, nfdet nd, notafiscal nf,
                              produtodepositante pd
                        where nd.idnfdet = p_idNfDet
                          and nf.idnotafiscal = nd.nf
                          and pd.identidade = nf.iddepositante
                          and pd.idproduto = nd.idproduto
                          and v.idnfdet = p_idNfDet
                          and decode(pd.coletaloteindust, 'S',
                                     v.loteindustria, 1) =
                              decode(pd.coletaloteindust, 'S',
                                     trim(p_loteindustria), 1)
                          and decode(pd.coletadtavenclote, 1, v.vencimento, 3,
                                     v.vencimento, 1) =
                              decode(pd.coletadtavenclote, 1,
                                     to_char(p_vencimento, 'dd/mm/yyyy'), 3,
                                     to_char(p_vencimento, 'dd/mm/yyyy'), 1)
                          and decode(pd.coletadtavenclote, 2, v.dtfabricacao,
                                     3, v.dtfabricacao, 1) =
                              decode(pd.coletadtavenclote, 2,
                                     to_char(p_dtfabricacao, 'dd/mm/yyyy'), 3,
                                     to_char(p_dtfabricacao, 'dd/mm/yyyy'), 1))
      loop
        if (c_result.h$status not in (0, 3))
           and (not isBackListORCorrecao(p_idNfDet)) then
          v_msg := t_message('Não é possível cadastrar um backlist com Status do Recebimento diferente de Inexistente ou Pendente');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    end validarStatusRecebimento;
  
    procedure validarQtdInformada is
      C_UTZ_BACKLIST_VOLUME constant number := 1;
      C_UTZ_BACKLIST_QTD    constant number := 2;
      C_UTZ_BACKLIST_QTDVOL constant number := 3;
    begin
      if (p_operacao = OPERACAO_DELETE) then
        return;
      end if;
    
      case
        when v_tipoBacklist = C_UTZ_BACKLIST_VOLUME then
          if (p_qtde is not null) then
            v_msg := t_message('O Depositante {0} utiliza por volume, onde não é permitido informar quantidade.');
            v_msg.addParam(v_depositante);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        when v_tipoBacklist = C_UTZ_BACKLIST_QTD then
          if (p_qtde is null) then
            v_msg := t_message('O Depositante {0} utiliza por quantidade, onde é obrigatório informar quantidade.');
            v_msg.addParam(v_depositante);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        when v_tipoBacklist = C_UTZ_BACKLIST_QTDVOL then
          if (p_qtde is null) then
            v_msg := t_message('O Depositante {0} utiliza por volume e quantidade, onde é obrigatório informar quantidade.');
            v_msg.addParam(v_depositante);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          v_msg := t_message('O Depositante {0} não utiliza backlist no recebimento.');
          v_msg.addParam(v_depositante);
          raise_application_error(-20000, v_msg.formatMessage);
      end case;
    end validarQtdInformada;
  
    procedure gerarLogAlteracaoBackList is
      v_motivo motivo.descr%type;
    begin
      if (p_qtde < 0 and p_operacao = 0) then
        v_msg := t_message('A quantidade tem que ser maior que zero!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_idmotivo = 0) then
        return;
      end if;
    
      select descr
        into v_motivo
        from motivo
       where idmotivo = p_idmotivo;
    
      pk_utilities.GeraLog(p_idusuarioSupervisor,
                           'BACKLIST MODIFICADO ESTADO DE VALIDO PARA NAO VALIDO POR ALTERACAO DE DADOS, LIBERADO POR SUPERVISOR:' ||
                            p_idusuarioSupervisor || ', MOTIVO: ' ||
                            v_motivo, p_idBacklist, 'BK');
    end gerarLogAlteracaoBackList;
  
    procedure executarDelete is
    
      procedure deletarBackList is
      begin
        delete from backlist
         where id = p_idBacklist;
      
        pk_utilities.GeraLog(v_backlist.idusuario, 'BACKLIST EXCLUIDO',
                             p_idBacklist, 'BK');
      end deletarBackList;
    
      procedure abaterQtdeBackList is
        v_saldo number;
      
        function validaQtdeBackListQtdeEstorno return boolean is
          v_qtdebacklist number;
        begin
          select sum(b.qtde)
            into v_qtdebacklist
            from backlist b
           where b.idnfdet = p_idnfdet
             and b.loteindustria = trim(p_loteindustria);
        
          return v_qtdebacklist + p_qtde >= 0;
        end validaQtdeBackListQtdeEstorno;
      
      begin
        if (not validaQtdeBackListQtdeEstorno) then
          v_msg := t_message('Quantidade de estorno superior a quantidade do BackList.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (p_qtde = 0) then
          v_msg := t_message('Quantidade de estorno não pode ser 0.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        v_saldo := p_qtde;
        for c_bl in (select b.id, b.qtde
                       from backlist b
                      where b.idnfdet = p_idNfDet
                        and b.loteindustria = trim(p_loteindustria)
                      order by b.qtde desc)
        loop
          v_saldo := c_bl.qtde + v_saldo;
        
          if (v_saldo <= 0) then
            delete from backList
             where id = c_bl.id;
          end if;
        
          if (v_saldo > 0) then
            update backlist b
               set b.qtde = v_saldo
             where id = c_bl.id;
          end if;
        
          if (v_saldo >= 0) then
            return;
          end if;
        
        end loop;
      
      end abaterQtdeBackList;
    
    begin
      if (p_operacao <> OPERACAO_DELETE) then
        return;
      end if;
    
      if p_qtde is null then
        deletarBackList;
      else
        abaterQtdeBackList;
      end if;
    
    end executarDelete;
  
    procedure executarInsert is
      v_log varchar2(50);
    begin
      if (p_operacao <> OPERACAO_ADD_EDIT) then
        return;
      end if;
    
      if (v_coletadtavenclote = C_NAO_COLETA_DATAS) then
        v_backlist.dtfabricacao := null;
        v_backlist.vencimento   := null;
      end if;
    
      if (p_idBacklist is not null and p_idBacklist <> 0) then
        v_log := 'ALTERADO';
      
        update backlist
           set idusuario     = v_backlist.idusuario,
               loteindustria = v_backlist.loteindustria,
               qtde          = decode(p_atualizar, C_ATUALIZARQTDE,
                                      nvl(qtde, 0) + v_backlist.qtde,
                                      v_backlist.qtde),
               dtfabricacao  = v_backlist.dtfabricacao,
               vencimento    = v_backlist.vencimento
         where id = p_idBacklist;
      else
        v_log := 'CADASTRADO';
      
        insert into backlist
          (id, idnfdet, idusuario, loteindustria, qtde, dtfabricacao,
           vencimento)
        values
          (seq_backlist.nextval, v_backlist.idnfdet, v_backlist.idusuario,
           v_backlist.loteindustria, v_backlist.qtde,
           v_backlist.dtfabricacao, v_backlist.vencimento);
      end if;
    
      pk_utilities.GeraLog(v_backlist.idusuario,
                           'BACKLIST ' || v_log || '. LOT.IND:' ||
                            v_backlist.loteindustria || ' QTDE: ' ||
                            v_backlist.qtde || ' DT FABRICAÇÃO: ' ||
                            v_backlist.dtfabricacao || ' DT VENCIMENTO: ' ||
                            v_backlist.vencimento, p_idBacklist, 'BK');
    
    end executarInsert;
  
    procedure validarLoteIndDuplicadoProd(p_idNotaFiscal in number) is
      v_qtde number;
    begin
      select count(1)
        into v_qtde
        from backlist b, nfdet nfd, notafiscal nf
       where b.loteindustria = trim(p_loteindustria)
         and nfd.idnfdet = b.idnfdet
         and nfd.idnfdet <> p_idNfDet
         and nf.idnotafiscal = nfd.nf
         and nf.idnotafiscal = p_idNotaFiscal;
    
      if (v_qtde > 0) then
        v_msg := t_message('O Lote Indústria [ {0} ] já está cadastrado para outro produto da Nota Fiscal [ idNotaFiscal: {1} ].' ||
                           chr(13) || 'Operação não permitida.');
        v_msg.addParam(trim(p_loteindustria));
        v_msg.addParam(p_idNotaFiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_qtde
        from backlist b, nfdet nfd
       where b.id <> nvl(p_idBacklist, 0)
         and nfd.idnfdet = b.idnfdet
         and b.loteindustria = trim(p_loteindustria)
         and nfd.idnfdet = p_idNfDet;
    
      if (v_qtde > 0) then
        v_msg := t_message('O Lote Indústria [ {0} ] já está cadastrado para o produto da Nota Fiscal [ idNotaFiscal: {1} ].' ||
                           chr(13) || 'Operação não permitida.');
        v_msg.addParam(trim(p_loteindustria));
        v_msg.addParam(p_idNotaFiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarLoteIndDuplicadoProd;
  
    procedure validarLoteIndustriaVencDif is
      v_existeLotes number;
      v_vencimentos varchar2(1000);
      v_idnfs       varchar2(1000);
      v_idnfdets    varchar2(1000);
    begin
      -- Validando a existência de outros Backlist's com mesmo lote indústria do mesmo produto e depositante mas com vencimento diferente
      -- incluindo na validação as notas que não estejam canceladas e OR's que tenham lotes gerados e ainda não processados (neste caso irá validar os lotes gerados)
      -- Quando o produto/depositante estiver configurado para validar apenas mês e ano do vencimento irá considerar o último dia do mês para validação
      select count(*),
             stragg(decode(b.vencimento, null, 'SEM VENCIMENTO',
                            to_char(b.vencimento, 'dd/mm/rrrr'))),
             stragg(b.nf), stragg(b.idnfdet)
        into v_existeLotes, v_vencimentos, v_idnfs, v_idnfdets
        from (select distinct b.vencimento, nd.nf, nd.idnfdet
                 from backlist b, nfdet nd, notafiscal nf,
                      produtodepositante pd
                where b.id <> nvl(p_idBacklist, -1)
                  and b.loteindustria = v_backlist.loteindustria
                  and decode(pd.validarmesano, 0,
                             nvl(b.vencimento,
                                  to_date('01/01/1900', 'dd/mm/rrrr')),
                             last_day(nvl(b.vencimento,
                                           to_date('01/01/1900', 'dd/mm/rrrr')))) <>
                      decode(pd.validarmesano, 0,
                             nvl(v_backlist.vencimento,
                                  to_date('01/01/1900', 'dd/mm/rrrr')),
                             last_day(nvl(v_backlist.vencimento,
                                           to_date('01/01/1900', 'dd/mm/rrrr'))))
                  and nd.idnfdet = b.idnfdet
                  and nd.idproduto = v_idProduto
                  and nf.idnotafiscal = nd.nf
                  and nf.iddepositante = v_idDepositante
                  and nf.statusnf <> 'X'
                  and pd.identidade = nf.iddepositante
                  and pd.idproduto = nd.idproduto
                  and not exists (select 1
                         from lotenf lnf
                        where lnf.idlotenf = nf.idlotenf
                          and lnf.cadloteaut = 'S')) b;
    
      if (v_existeLotes > 0) then
        v_msg := t_message('O Lote Indústria [ {0} ] já está cadastrado em backlist com o vencimento [ {1} ] ' ||
                           ' NotaFiscal id(s) [ {2} ], NfDet id(s) [ {3} ]. ' ||
                           chr(13) || 'Operação não permitida.');
        v_msg.addParam(v_backlist.loteindustria);
        v_msg.addParam(v_vencimentos);
        v_msg.addParam(v_idnfs);
        v_msg.addParam(v_idnfdets);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Validando a existência de lotes com mesmo lote indústria do mesmo produto e depositante mas com vencimento diferente
      -- Quando o produto/depositante está configurado para validar apenas mês e ano o lote já deve estar com o último dia do mês
      -- portanto, se estiver configurado, somente a data do backlist será considerada como o último dia do mês
      select count(*),
             stragg(decode(l.dtvenc, null, 'SEM VENCIMENTO',
                            to_char(l.dtvenc, 'dd/mm/rrrr')))
        into v_existeLotes, v_vencimentos
        from (select distinct l.dtvenc
                 from lote l, produtodepositante pd
                where l.descr = v_backlist.loteindustria
                  and l.idproduto = v_idProduto
                  and l.iddepositante = v_idDepositante
                  and pd.identidade = l.iddepositante
                  and pd.idproduto = l.idproduto
                  and nvl(l.dtvenc, to_date('01/01/1900', 'dd/mm/rrrr')) <>
                      decode(pd.validarmesano, 0,
                             nvl(v_backlist.vencimento,
                                  to_date('01/01/1900', 'dd/mm/rrrr')),
                             last_day(nvl(v_backlist.vencimento,
                                           to_date('01/01/1900', 'dd/mm/rrrr'))))) l;
    
      if (v_existeLotes > 0) then
        v_msg := t_message('O Lote Indústria [ {0} ] já está cadastrado em lotes com o vencimento [ {1} ].' ||
                           chr(13) || 'Operação não permitida.');
        v_msg.addParam(v_backlist.loteindustria);
        v_msg.addParam(v_vencimentos);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarLoteIndustriaVencDif;
  
  begin
    -- validarNotaEstaVinculadoOR
    begin
      select n.idnotafiscal, n.backlistvalidado, nvl(d.utzbacklist, 0),
             e.razaosocial, d.fracionarlote, nvl(n.idlotenf, 0),
             d.identidade, d.bloqltindustriavencdiferente
        into v_idNotaFiscal, v_backlistvalidado, v_tipoBacklist,
             v_depositante, v_depFracionaLote, v_idlotenf, v_idDepositante,
             v_bloqltindustriavencdiferente
        from notafiscal n, nfdet nd, entidade e, depositante d
       where nd.nf = n.idnotafiscal
         and nd.idnfdet = p_idnfdet
         and ((n.idlotenf is null) or
             (n.idlotenf is not null and
             (exists
              (select 1
                   from lotenf ln
                  where ln.idlotenf = n.idlotenf
                    and p_correcaoBacklistOr = 1
                    and ln.emcorrecaobacklist = c_sim) or
              nvl(n.idlotenf, 0) = retonarConferenciaAlocada(n.idlotenf))))
            
         and e.identidade = n.iddepositante
         and d.identidade = e.identidade;
    exception
      when no_data_found then
      
        v_msg := t_message('A Notafiscal deste backlist ja está vinculada a uma O.R. Para alterar o backlist desvincule o Notafiscal da O.R.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    validarStatusRecebimento;
  
    if (v_backlistvalidado = BACKLIST_VALIDADO and
       p_idusuarioSupervisor = 0) then
      return SOLICITA_SUPERVISOR;
    end if;
  
    if (v_depFracionaLote = C_NAO) then
      validarLoteIndDuplicadoProd(v_idNotaFiscal);
    end if;
  
    validarQtdInformada;
  
    gerarLogAlteracaoBackList();
  
    if (retonarConferenciaAlocada(v_idlotenf) = 0) then
      controlaStatusBackList(v_idNotaFiscal, BACKLIST_INVALIDO);
    end if;
  
    select pd.coletadtavenclote, nd.idproduto, p.prazovalidade
      into v_coletadtavenclote, v_idProduto, v_prazoValidade
      from notafiscal nf, produtodepositante pd, nfdet nd, produto p
     where nf.idnotafiscal = v_idNotaFiscal
       and pd.identidade = nf.iddepositante
       and nd.nf = nf.idnotafiscal
       and pd.idproduto = nd.idproduto
       and p.idproduto = nd.idproduto
       and nd.idnfdet = p_idnfdet;
  
    v_backlist.idnfdet       := p_idNfDet;
    v_backlist.idusuario     := p_idusuario;
    v_backlist.loteindustria := trim(p_loteindustria);
    v_backlist.qtde          := p_qtde;
    v_backlist.dtfabricacao  := p_dtfabricacao;
    v_backlist.vencimento    := p_vencimento;
  
    select count(1)
      into v_medicamento
      from dual
     where exists (select 1
              from produto p, tipoproduto tp
             where 1 = 1
               and p.idtipo = tp.idtipo
               and p.idproduto = v_idProduto
               and nvl(tp.medicamento, 0) = 1);
  
    if (v_medicamento > 0 and p_operacao = OPERACAO_ADD_EDIT) then
    
      if v_backlist.vencimento is null
         and v_backlist.dtfabricacao is not null then
        v_backlist.vencimento := add_months(v_backlist.dtfabricacao,
                                            v_prazovalidade);
      elsif v_backlist.dtfabricacao is null
            and v_backlist.vencimento is not null then
        v_backlist.dtfabricacao := add_months(v_backlist.vencimento,
                                              -v_prazovalidade);
      end if;
    
      if (v_backlist.dtfabricacao is null) then
        v_msg := t_message('Produto é medicamento e data de fabricação não informada.' ||
                           chr(13) || 'Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_backlist.vencimento is null) then
        v_msg := t_message('Produto é medicamento e data de vencimento não informada.' ||
                           chr(13) || 'Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    else
      if (p_operacao <> OPERACAO_DELETE) then
        if (v_coletadtavenclote in
           (C_COLETA_FABRICACAO, C_COLETA_VENC_FABR) and
           v_backlist.dtfabricacao is null) then
          v_msg := t_message('Produto coleta data de fabricação e a data não foi informada.' ||
                             chr(13) || 'Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (v_coletadtavenclote in
           (C_COLETA_VENCIMENTO, C_COLETA_VENC_FABR) and
           v_backlist.vencimento is null) then
          v_msg := t_message('Produto coleta data de vencimento e a data não foi informada.' ||
                             chr(13) || 'Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (v_coletadtavenclote = C_COLETA_FABRICACAO) then
          v_backlist.vencimento := add_months(v_backlist.dtfabricacao,
                                              v_prazovalidade);
        end if;
      
        if (v_coletadtavenclote = C_COLETA_VENCIMENTO) then
          v_backlist.dtfabricacao := add_months(v_backlist.vencimento,
                                                -v_prazovalidade);
        end if;
      end if;
    end if;
  
    if (v_bloqltindustriavencdiferente = C_SIM) then
      validarLoteIndustriaVencDif;
    end if;
  
    executarDelete;
    executarInsert;
  
    return CONCLUIDO_SUCESSO;
  end;

  function deleteBackList
  (
    p_idBacklist          in number,
    p_idNfDet             in number,
    p_idusuarioSupervisor in number,
    p_idmotivo            in number,
    p_idUsuario           in number
    
  ) return number is
  begin
    return manterBackList(p_idBacklist, p_idNfDet, p_idUsuario, null, null,
                          p_idusuarioSupervisor, p_idmotivo, 1, null, null);
  end;

  procedure validarBacklist(p_idNotaFiscal in number) is
  
    TIPO_SUCESSO constant number := 0;
    TIPO_ERRO    constant number := 1;
  
    TIPO_BACKLIST_NAO      constant number := 0;
    TIPO_BACKLIST_VOLUME   constant number := 1;
    TIPO_BACKLIST_QTDE     constant number := 2;
    TIPO_BACKLIST_VOL_QTDE constant number := 3;
  
    v_tipoBacklist       number;
    v_idDepositante      number;
    v_resultadoValidacao number;
    v_qtdeItemValidar    number;
  
    v_msg      t_message;
    v_msgDescr t_message;
  
    function getQtdeItemValidar return number is
      v_qtd number := 0;
    begin
    
      select count(*)
        into v_qtd
        from notafiscal nf, nfdet nd, produtodepositante pd
       where nf.idnotafiscal = nd.nf
         and nd.idproduto = pd.idproduto
         and nf.iddepositante = pd.identidade
         and pd.coletaloteindust = 'S'
         and pd.naocriticabacklist = 0
         and nf.idnotafiscal = p_idNotaFiscal;
    
      return v_qtd;
    end getQtdeItemValidar;
  
    procedure addResumo
    (
      p_grupo     in varchar2,
      p_descricao in varchar2,
      p_tipo      in number
    ) is
    begin
      insert into gtt_resumoexecucao
        (idresumoexecucao, grupo, descricao, tipo)
      values
        (seq_gtt_resumoexecucao.nextval, p_grupo, p_descricao, p_tipo);
    end addResumo;
  
    procedure updateNotaFiscal(p_status in number) is
    begin
      update notafiscal
         set backlistvalidado = p_status
       where idnotafiscal = p_idNotaFiscal;
    end;
  
    procedure validarBacklistCadastrado is
      v_qtdeBacklist       number;
      v_qtdeRemoveBacklist number;
    begin
      select count(1)
        into v_qtdeBacklist
        from notafiscal nf, nfdet nfd, backlist b
       where nf.idnotafiscal = nfd.nf
         and nfd.idnfdet = b.idnfdet
         and nf.idnotafiscal = p_idNotaFiscal;
    
      if v_qtdeBacklist = 0 then
        v_msg := t_message('A Nota Fiscal id: {0} não possui Backlist cadastrado. Favor verifique.');
        v_msg.addParam(p_idNotaFiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    end validarBacklistCadastrado;
  
    procedure validarPorVolume(p_tipoBacklist in number) is
      v_qtdeVolumesNf number;
      v_qtdeBacklist  number;
    begin
      if p_tipoBacklist not in
         (TIPO_BACKLIST_VOLUME, TIPO_BACKLIST_VOL_QTDE) then
        return;
      end if;
    
      select nf.QUANTIDADE
        into v_qtdeVolumesNf
        from notafiscal nf
       where idnotafiscal = p_idNotaFiscal;
    
      if (v_qtdeVolumesNf is null or v_qtdeVolumesNf = 0) then
        v_msg      := t_message('Cadastro da NotaFiscal');
        v_msgDescr := t_message('Não foi possivel validar o backlist, pois o depositante esta configurado para utilizar validacao por volume e a quantidade de volumes nao foi informada na notafiscal.');
        addResumo(v_msg.formatMessage, v_msgDescr.formatMessage, TIPO_ERRO);
        return;
      end if;
    
      select count(1)
        into v_qtdeBacklist
        from notafiscal nf, nfdet nfd, backlist b, produtodepositante pd
       where nf.idnotafiscal = nfd.nf
         and nfd.idnfdet = b.idnfdet
         and nf.idnotafiscal = p_idNotaFiscal
         and nf.iddepositante = pd.identidade
         and nfd.idproduto = pd.idproduto
         and pd.naocriticabacklist = 0;
    
      if v_qtdeVolumesNf <> v_qtdeBacklist then
        v_msg      := t_message('Backlist invalido');
        v_msgDescr := t_message('Backlist de volume invalido, quantidade de volumes em nota: ' ||
                                '{0}, quantidade no backlist: {1}');
        v_msgDescr.addParam(v_qtdeVolumesNf);
        v_msgDescr.addParam(v_qtdeBacklist);
        addResumo(v_msg.formatMessage, v_msgDescr.formatMessage, TIPO_ERRO);
        return;
      end if;
    end validarPorVolume;
  
    procedure validarPorQuantidade(p_tipoBacklist in number) is
      v_qtdetotalbacklist number;
    begin
      if p_tipoBacklist not in (TIPO_BACKLIST_QTDE, TIPO_BACKLIST_VOL_QTDE) then
        return;
      end if;
    
      for c_nfdet in (select nfd.idnfdet, nfd.qtde, p.descr produto
                        from nfdet nfd, produto p, produtodepositante pd
                       where nfd.nf = p_idNotaFiscal
                         and p.idproduto = nfd.idproduto
                         and pd.idproduto = p.idproduto
                         and pd.identidade = v_idDepositante
                         and pd.coletaloteindust = 'S'
                         and pd.naocriticabacklist = 0)
      loop
      
        select nvl(sum(qtde), 0)
          into v_qtdetotalbacklist
          from backlist
         where idnfdet = c_nfdet.idnfdet;
      
        if c_nfdet.qtde <> v_qtdetotalbacklist then
          v_msg      := t_message('Backlist invalido');
          v_msgDescr := t_message('Backlist de quantidade invalido, item notafiscal id: ' ||
                                  '{0}, invalido produto, ' ||
                                  '{1}, quantidade notafiscal: ' ||
                                  '{2}, quantidade backlist: {3}');
          v_msgDescr.addParam(c_nfdet.idnfdet);
          v_msgDescr.addParam(c_nfdet.produto);
          v_msgDescr.addParam(c_nfdet.qtde);
          v_msgDescr.addParam(v_qtdetotalbacklist);
          addResumo(v_msg.formatMessage, v_msgDescr.formatMessage,
                    TIPO_ERRO);
        end if;
      end loop;
    end validarPorQuantidade;
  
    procedure atualizaNotaFiscal(p_validado in boolean) is
      v_statusValidado number;
    begin
      if p_validado then
        v_statusValidado := BACKLIST_VALIDADO;
        v_msg            := t_message('Validação da Backlist');
        v_msgDescr       := t_message('Backlist da Nota Fiscal id: {0}' ||
                                      ' foi validado.');
        v_msgDescr.addParam(p_idNotaFiscal);
        addResumo(v_msg.formatMessage, v_msgDescr.formatMessage,
                  TIPO_SUCESSO);
      else
        v_statusValidado := BACKLIST_INVALIDO;
        v_msg            := t_message('Validação da Backlist');
        v_msgDescr       := t_message('Backlist da Nota Fiscal id: {0}' ||
                                      ' não foi validado. Verifique as quantidades definidas em Nota e confronte-as com o Backlist.');
        v_msgDescr.addParam(p_idNotaFiscal);
        addResumo(v_msg.formatMessage, v_msgDescr.formatMessage, TIPO_ERRO);
      end if;
    
      updateNotaFiscal(v_statusValidado);
    
    end atualizaNotaFiscal;
  
    procedure validarTipoQtdBackList is
      C_UTZ_BACKLIST_VOLUME constant number := 1;
      C_UTZ_BACKLIST_QTD    constant number := 2;
      C_UTZ_BACKLIST_QTDVOL constant number := 3;
    
      v_tipoBackList    number;
      v_qtdItemInvalido number;
    begin
      select nvl(d.utzbacklist, 0)
        into v_tipoBackList
        from notafiscal nf, depositante d
       where nf.idnotafiscal = p_idNotafiscal
         and d.identidade = nf.iddepositante;
    
      if (v_tipoBacklist in (C_UTZ_BACKLIST_QTD, C_UTZ_BACKLIST_QTDVOL)) then
        select count(1)
          into v_qtdItemInvalido
          from backlist bk, nfdet nd, notafiscal nf, produtodepositante pd
         where nd.nf = p_idNotafiscal
           and bk.idnfdet = nd.idnfdet
           and nd.nf = nf.idnotafiscal
           and nf.iddepositante = pd.identidade
           and nd.idproduto = pd.idproduto
           and pd.naocriticabacklist = 0
           and (bk.qtde is null or bk.qtde = 0);
      
        if (v_qtdItemInvalido > 0) then
          v_msg := t_message('O Backlist da Nota Fiscal ID: {0} possui itens cadastrados sem informar quantidade e a configuração do tipo de backlist utilizado pelo depositante da nota exige que seja informada a quantidade.');
          v_msg.addParam(p_idNotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
        return;
      end if;
    
      if (v_tipoBacklist = C_UTZ_BACKLIST_VOLUME) then
        select count(1)
          into v_qtdItemInvalido
          from backlist bk, nfdet nd, notafiscal nf, produtodepositante pd
         where nd.nf = p_idNotafiscal
           and bk.idnfdet = nd.idnfdet
           and nd.nf = nf.idnotafiscal
           and nf.iddepositante = pd.identidade
           and nd.idproduto = pd.idproduto
           and pd.naocriticabacklist = 0
           and nvl(bk.qtde, 0) > 0;
      
        if (v_qtdItemInvalido > 0) then
          v_msg := t_message('O Backlist da Nota Fiscal ID: {0} possui itens cadastrados onde foi informada quantidade e a configuração do tipo de backlist utilizado pelo depositante da nota prevê que não seja informada a quantidade.');
          v_msg.addParam(p_idNotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
        return;
      end if;
    end validarTipoQtdBackList;
  
    procedure validarDtVencFabr is
      v_vencimentovazio number;
      v_fabricacaovazia number;
    begin
      for c_coletaVencLote in (select pd.coletadtavenclote, nd.idproduto
                                 from notafiscal nf, produtodepositante pd,
                                      nfdet nd
                                where nf.idnotafiscal = p_idNotaFiscal
                                  and pd.identidade = nf.iddepositante
                                  and nd.nf = nf.idnotafiscal
                                  and pd.idproduto = nd.idproduto
                                  and pd.naocriticabacklist = 0)
      loop
        if c_coletaVencLote.Coletadtavenclote <> C_NAO_COLETA_DATAS then
          select sum(decode(b.vencimento, null, 1, 0)) vencimentovazio,
                 sum(decode(b.dtfabricacao, null, 1, 0)) fabricacaovazia
            into v_vencimentovazio, v_fabricacaovazia
            from notafiscal nf, nfdet nd, backlist b
           where nf.idnotafiscal = p_idNotaFiscal
             and nd.nf = nf.idnotafiscal
             and nd.idproduto = c_coletaVencLote.Idproduto
             and b.idnfdet = nd.idnfdet;
        
          if c_coletaVencLote.Coletadtavenclote = C_COLETA_VENCIMENTO
             and v_vencimentovazio > 0 then
            v_msg := t_message('O Backlist da Nota Fiscal ID: {0} possui itens cadastrados sem informar a data de vencimento e a configuração da relação produto/depositante utilizado exige que seja preenchida essa informação. IDPRODUTO: {1}');
            v_msg.addParam(p_idNotafiscal);
            v_msg.addParam(c_coletaVencLote.Idproduto);
            raise_application_error(-20000, v_msg.formatMessage);
          
          end if;
        
          if c_coletaVencLote.Coletadtavenclote = C_COLETA_FABRICACAO
             and v_fabricacaovazia > 0 then
            v_msg := t_message('O Backlist da Nota Fiscal ID: {0} possui itens cadastrados sem informar a data de fabricação e a configuração da relação produto/depositante utilizado exige que seja preenchida essa informação. IDPRODUTO: {1}');
            v_msg.addParam(p_idNotafiscal);
            v_msg.addParam(c_coletaVencLote.Idproduto);
            raise_application_error(-20000, v_msg.formatMessage);
          
          end if;
        
          if c_coletaVencLote.Coletadtavenclote = C_COLETA_VENC_FABR
             and (v_vencimentovazio > 0 or v_fabricacaovazia > 0) then
            v_msg := t_message('O Backlist da Nota Fiscal ID: {0} possui itens cadastrados sem informar a data de fabricação e/ou data de vencimento e a configuração da relação produto/depositante utilizado exige que seja preenchida as duas informações. IDPRODUTO: {1}');
            v_msg.addParam(p_idNotafiscal);
            v_msg.addParam(c_coletaVencLote.Idproduto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end loop;
    end validarDtVencFabr;
  begin
  
    /*retorno da nota quantos itens devem ser criticados*/
    v_qtdeItemValidar := getQtdeItemValidar();
    v_resultadoValidacao := 0;
  
    if (v_qtdeItemValidar > 0) then
    
      validarBacklistCadastrado;
      validarTipoQtdBackList;
      validarDtVencFabr;
    
      select d.utzbacklist, d.identidade
        into v_tipoBacklist, v_idDepositante
        from notafiscal n, depositante d
       where n.iddepositante = d.identidade
         and n.idnotafiscal = p_idNotaFiscal;
    
      if v_tipoBacklist = TIPO_BACKLIST_NAO then
        v_msg := t_message('O Depositante id: {0} não está configurado para utilizar Backlist. Favor verifique.');
        v_msg.addParam(v_idDepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      validarPorVolume(v_tipoBacklist);
      validarPorQuantidade(v_tipoBacklist);
    
    end if;
  
    select count(1)
      into v_resultadoValidacao
      from gtt_resumoexecucao;
  
    atualizaNotaFiscal(v_resultadoValidacao = 0);
  end;

  function getBarraProdutoLtIndustria
  (
    p_idLoteNf      in number,
    p_loteindustria in varchar2,
    p_idDepositante in number,
    p_barra         in varchar2 default null
  ) return varchar2 is
    v_barraProdutoNF nfdet.barra%type;
    v_qtde           nfdet.qtde%type;
  begin
    begin
      delete from gtt_selecao;
    
      if p_barra is not null then
        begin
          select e.barra, bk.qtde * e2.fatorconversao
            into v_barraProdutoNF, v_qtde
            from notafiscal nf, nfdet n, backlist bk, embalagem e,
                 embalagem e2
           where nf.idlotenf = p_idLoteNf
             and nf.iddepositante = p_idDepositante
             and n.nf = nf.idnotafiscal
             and n.idnfdet = bk.idnfdet
             and n.idproduto = e.idproduto
             and e.fatorconversao = 1
             and e.ativo = 'S'
             and bk.loteindustria = trim(p_loteindustria)
             and e2.idproduto = n.idproduto
             and e2.barra = p_barra
             and e2.ativo = 'S';
        exception
          when too_many_rows then
            select e.barra, bk.qtde * e.fatorconversao
              into v_barraProdutoNF, v_qtde
              from notafiscal nf, nfdet n, backlist bk, embalagem e
             where nf.idlotenf = p_idLoteNf
               and nf.iddepositante = p_idDepositante
               and n.nf = nf.idnotafiscal
               and n.idnfdet = bk.idnfdet
               and n.idproduto = e.idproduto
               and e.barra = p_barra
               and e.ativo = 'S'
               and bk.loteindustria = trim(p_loteindustria);
        end;
      else
        select e.barra, bk.qtde * e2.fatorconversao
          into v_barraProdutoNF, v_qtde
          from notafiscal nf, nfdet n, backlist bk, embalagem e,
               embalagem e2
         where nf.idlotenf = p_idLoteNf
           and nf.iddepositante = p_idDepositante
           and n.nf = nf.idnotafiscal
           and n.idnfdet = bk.idnfdet
           and n.idproduto = e.idproduto
           and e.fatorconversao = 1
           and e.ativo = 'S'
           and bk.loteindustria = trim(p_loteindustria)
           and e2.barra = n.barra
           and e2.idproduto = n.idproduto
           and e2.ativo = 'S';
      end if;
    
      insert into gtt_selecao
      values
        (v_qtde);
    
      return v_barraProdutoNF;
    exception
      when no_data_found then
        return null;
      when too_many_rows then
        begin
          delete from gtt_selecao;
        
          select distinct e.barra
            into v_barraProdutoNF
            from notafiscal nf, nfdet n, backlist bk, embalagem e
           where nf.idlotenf = p_idLoteNf
             and nf.iddepositante = p_idDepositante
             and n.nf = nf.idnotafiscal
             and n.idnfdet = bk.idnfdet
             and n.idproduto = e.idproduto
             and e.fatorconversao = 1
             and e.ativo = 'S'
             and bk.loteindustria = trim(p_loteindustria);
        
          return v_barraProdutoNF;
        exception
          when no_data_found then
            return null;
          when too_many_rows then
            return null;
        end;
    end;
  
  end getBarraProdutoLtIndustria;

  function getDataLoteIndustria
  (
    p_idLoteNf      in number,
    p_loteindustria in varchar2,
    p_idDepositante in number,
    p_tipoData      in number
  ) return date is
    v_dataLote date;
  begin
  
    v_dataLote := null;
  
    begin
      select decode(p_tipoData, 0, bk.dtfabricacao, bk.vencimento) databacklist
        into v_dataLote
        from notafiscal nf, nfdet n, backlist bk
       where nf.idlotenf = p_idLoteNf
         and nf.iddepositante = p_idDepositante
         and n.nf = nf.idnotafiscal
         and n.idnfdet = bk.idnfdet
         and bk.loteindustria = trim(p_loteindustria);
    
      return v_dataLote;
    exception
      when others then
      
        begin
          select distinct decode(p_tipoData, 0, bk.dtfabricacao,
                                  bk.vencimento) databacklist
            into v_dataLote
            from notafiscal nf, nfdet n, backlist bk
           where nf.idlotenf = p_idLoteNf
             and nf.iddepositante = p_idDepositante
             and n.nf = nf.idnotafiscal
             and n.idnfdet = bk.idnfdet
             and bk.loteindustria = trim(p_loteindustria);
        
          return v_dataLote;
        
        exception
          when others then
            return null;
        end;
      
        return v_dataLote;
    end;
  end;

  procedure validarBackListPrenf(p_idprenf in number) is
    v_idNotaFiscal number;
    v_backvalidado number;
    v_tipo         char(1);
    v_qtde         number;
  
    C_BACKLISTVALIDADO constant number := 2;
    C_TIPONOTAENTRADA  constant char(1) := 'E';
  
    v_msg t_message;
  
  begin
    select nf.idnotafiscal, nf.tipo
      into v_idNotaFiscal, v_tipo
      from notafiscal nf
     where nf.idprenf = p_idprenf;
  
    select count(1)
      into v_qtde
      from nfdetrastro nfd
     where nfd.idprenf = p_idprenf;
  
    if (v_qtde > 0 and v_tipo = C_TIPONOTAENTRADA) then
      validarBacklist(v_idNotaFiscal);
    
      select nf.backlistvalidado
        into v_backvalidado
        from notafiscal nf
       where nf.idnotafiscal = v_idNotaFiscal;
    
      if (v_backvalidado <> C_BACKLISTVALIDADO) then
        v_msg := t_message('Inconsistências encontradas na TAG MED. Verifique o cadastro de BackList');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end if;
  
  end;

  procedure cadastrarAutomaticoBacklist
  (
    r_int          in int_backlist%rowtype,
    p_idusuario    in number,
    p_validar      in varchar2 default 'S',
    p_idnfdet      in number,
    p_idNotaFiscal in number,
    p_qtde         in number default 0
    
  ) is
  
    BACKLIST_VALIDADO constant number := 1;
  
    v_msgErro            varchar2(1000);
    v_idBacklist         number;
    v_resultado          number;
    v_resultadoValidacao number;
    V_idlogintegracao    number;
    v_qtde               number;
    v_msgerrovalidacao   varchar2(4000);
    v_msg                t_message;
    v_erro               varchar2(4000);
  
  begin
    begin
      if p_qtde = 0 then
        v_qtde := r_int.qtde;
      else
        v_qtde := p_qtde;
      end if;
    
      begin
        select b.id
          into v_idBacklist
          from backlist b
         where b.idnfdet = p_idnfdet
           and b.loteindustria = r_int.backlist_lote
           and b.dtfabricacao = r_int.data_fabricacao
           and b.vencimento = r_int.data_vencimento;
      exception
        when no_data_found then
          v_idBacklist := null;
      end;
    
      v_resultado := manterBackList(v_idBacklist, p_idnfdet, p_idusuario,
                                    r_int.backlist_lote, v_qtde, 0, 0, 0,
                                    r_int.data_fabricacao,
                                    r_int.data_vencimento, 1);
    
      if v_resultado = BACKLIST_VALIDADO then
        v_msg := t_message('O BACKLIST DA NOTA FISCAL NÚMERO: {0} SÉRIE: {1} JÁ FOI VALIDADO.');
        v_msg.addParam(r_int.notafiscal);
        v_msg.addParam(r_int.serie);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if p_validar = 'S' then
        pk_recebimento_backlist.validarBacklist(p_idNotaFiscal);
      end if;
    
      select count(1)
        into v_resultadoValidacao
        from gtt_resumoexecucao
       where tipo = 1;
    
      if (v_resultadoValidacao = 0) then
        -- Quando o backlist da nota fiscal é validado na integração do último backlist enviado,
        -- deve-se apagar os logs de integração de erro de validação de backlist dos backlists anteriores,
        -- para não causar confusão na visualização dos logs para backlist que foram validados com sucesso     
        delete from logintegracao l
         where l.numnf = r_int.notafiscal
           and l.extencaoarq = 'BKL'
           and l.tipo = 'E';
      
        v_idlogintegracao := pk_utilities.GerarLogIntegracao(null, null,
                                                             null, 'S',
                                                             p_idusuario,
                                                             'O BACKLIST DA NOTA FISCAL NÚMERO: ' ||
                                                              r_int.notafiscal ||
                                                              ' SÉRIE: ' ||
                                                              r_int.serie ||
                                                              ' VALIDADO COM SUCESSO.',
                                                             'BKL', null,
                                                             r_int.notafiscal,
                                                             r_int.notafiscal,
                                                             r_int.codproduto,
                                                             null,
                                                             r_int.agrupador);
      elsif (v_resultadoValidacao > 0) then
        select stragg(t.description)
          into v_msgerrovalidacao
          from (select distinct g.grupo || ' - ' || g.descricao description
                   from gtt_resumoexecucao g
                  where g.tipo = 1) t;
      
        v_idlogintegracao := pk_utilities.GerarLogIntegracao(null, null,
                                                             null, 'E',
                                                             p_idusuario,
                                                             v_msgerrovalidacao,
                                                             'BKL', null,
                                                             r_int.notafiscal,
                                                             r_int.notafiscal,
                                                             r_int.codproduto,
                                                             null,
                                                             r_int.agrupador);
      end if;
    exception
      when others then
        v_msgErro := SQLERRM;
      
        for rec in (select g.descricao
                      from gtt_resumoexecucao g
                     where g.tipo = 1)
        loop
          if (v_erro is null) then
            v_erro := rec.descricao;
          else
            if (length(v_erro || ',' || rec.descricao) > 3998) then
              v_erro := v_erro || substr(',' || rec.descricao, 0,
                                         3998 - length(v_erro));
            else
              v_erro := v_erro || ',' || rec.descricao;
            end if;
          end if;
        end loop;
      
        v_msg := t_message(v_erro);
      
        if (v_msg is null) then
          raise_application_error(-20000, v_msgErro);
        end if;
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
  end;

  function retonarConferenciaAlocada(p_idlotenf in number) return number is
    v_retorno number := 0;
  begin
    begin
      select l.idlotenf
        into v_retorno
        from lotenf l, tiporecebimento tr
       where l.idtiporecebimento = tr.idtiporecebimento
         and l.idlotenf = nvl(p_idlotenf, 0)
         and tr.conferenciaalocada = 1;
    exception
      when no_data_found then
        v_retorno := 0;
    end;
    return v_retorno;
  end retonarConferenciaAlocada;

  procedure removerAutomaticoBacklist
  (
    r_int       in int_backlist%rowtype,
    p_idusuario in number,
    p_idnfdet   in number
  ) is
    v_resultado       number;
    v_idlogintegracao number;
  
  begin
  
    v_resultado := manterBackList(null, p_idnfdet, p_idusuario,
                                  r_int.backlist_lote, r_int.qtde, -1, 0, 1,
                                  null, null);
  
    if (v_resultado = 0) then
      V_idlogintegracao := pk_utilities.GerarLogIntegracao(null, null, null,
                                                           'S', p_idusuario,
                                                           'O BACKLIST DA NOTA FISCAL NÚMERO: ' ||
                                                            r_int.notafiscal ||
                                                            ' SÉRIE: ' ||
                                                            r_int.serie ||
                                                            ' MODIFICADA COM SUCESSO.',
                                                           'BKL', null,
                                                           r_int.notafiscal,
                                                           r_int.notafiscal,
                                                           r_int.codproduto,
                                                           null,
                                                           r_int.agrupador);
    end if;
  
  end removerAutomaticoBacklist;

  procedure validarBacklistAgrupador(p_agrupador in number) is
  begin
    -- Encontrando a Nota Fiscal de Entrada do BackList
    for c_nota in (select distinct nf.idnotafiscal
                     from notafiscal nf, entidade rem, entidade dep,
                          depositante d, lotenf l, int_backlist b
                    where 1 = 1
                      and d.utzbacklist in (1, 2, 3)
                      and rem.identidade(+) = nf.remetente
                      and trim(decode(rem.pessoa, 'J', rem.cgc, rem.cic)) =
                          trim(b.cnpj_emitente)
                      and trim(rem.inscrestadual) =
                          trim(b.inscrestadual_emitente)
                      and dep.identidade(+) = nf.iddepositante
                      and trim(decode(dep.pessoa, 'J', dep.cgc, dep.cic)) =
                          trim(b.cnpj_depositante)
                      and nf.iddepositante = d.identidade
                      and nf.tipo = 'E'
                      and nf.movestoque = 'S'
                      and not exists
                    (select nfr.idnfremessa
                             from nfremarmazenagem nfr
                            where nfr.idnfremessa = nf.idnotafiscal)
                      and nf.codigointerno = b.notafiscal
                      and trim(nf.sequencia) = trim(b.serie)
                      and l.idlotenf(+) = nf.idlotenf
                      and b.agrupador = p_agrupador)
    loop
      validarBacklist(c_nota.idnotafiscal);
    end loop;
  
  end validarBacklistAgrupador;

  procedure ajsuteBackupBacklist
  (
    p_idNotafiscal number,
    p_tipo         number
  ) is
    v_tipoBacklist number := 0;
  begin
    begin
      select nvl(d.utzbacklist, 0)
        into v_tipoBacklist
        from notafiscal n, depositante d
       where n.iddepositante = d.identidade
         and n.idnotafiscal = p_idNotafiscal;
    exception
      when no_data_found then
        v_tipoBacklist := 0;
    end;
  
    if v_tipoBacklist <> 0 then
      -- 0 é para insert e 1 é para delete
      if (p_tipo = 0) then
        insert into backlist_backup
          (id, idnfdet, idusuario, loteindustria, qtde, dtfabricacao,
           vencimento)
          (select bl.id, bl.idnfdet, bl.idusuario, bl.loteindustria, bl.qtde,
                  bl.dtfabricacao, bl.vencimento
             from backlist bl, nfdet nd
            where nd.nf = p_idNotafiscal
              and bl.idnfdet = nd.idnfdet);
      else
        delete from backlist_backup bl
         where bl.idnfdet in (select nd.idnfdet
                                from nfdet nd
                               where nd.nf = p_idNotafiscal);
      end if;
    end if;
  
  end;
  procedure restaurarBackup
  (
    p_idLoteNf     in number,
    p_idnotaFiscal in number default null
  ) is
  
    v_qtd number := 0;
  begin
    delete from backlist a
     where not exists (select 1
              from backlist_backup b
             where b.id = a.id)
       and exists
     (select 1
              from notafiscal nf, nfdet nd
             where nf.idnotafiscal = nd.nf
               and nvl(nf.idlotenf, 0) = p_idLoteNf
               and nf.idnotafiscal = nvl(p_idNotafiscal, nf.idnotafiscal)
               and nd.idnfdet = a.idnfdet);
  
    merge into backlist a
    using (select b.id, b.idnfdet, b.idusuario, b.loteindustria, b.qtde,
                  b.dtfabricacao, b.vencimento
             from backlist_backup b
            where exists (select *
                     from notafiscal nf, nfdet nd
                    where nf.idnotafiscal = nd.nf
                      and nd.idnfdet = b.idnfdet
                      and nf.idlotenf = p_idLoteNf
                      and nf.idnotafiscal =
                          nvl(p_idnotaFiscal, nf.idnotafiscal))) s
    on (s.id = a.id)
    when matched then
      update
         set a.qtde          = s.qtde,
             a.loteindustria = s.loteindustria,
             a.dtfabricacao  = s.dtfabricacao,
             a.vencimento    = s.vencimento;
  
  end restaurarBackup;

  procedure setStatusCorrecaoBackList
  (
    p_idLoteNf in number,
    p_status   in number
  ) is
  
  begin
  
    update lotenf l
       set l.emcorrecaobacklist = p_status
     where l.idlotenf = p_idLoteNf;
  
  end setStatusCorrecaoBackList;

  function getResumoValidacaoBackListOR(p_idLotenf in number) return number is
  
    DIF_NEG           constant number := 0;
    DIF_INEXISTENTE   constant number := 1;
    DIF_POS_SEM_SALDO constant number := 2;
    DIF_POS_COM_SALDO constant number := 3;
  
    v_resultado number := DIF_INEXISTENTE;
  
  begin
  
    select count(*)
      into v_resultado
      from vt_backlistor v
     where v.h$idlotenf = p_idLotenf
       and v.diferenca < 0;
  
    if (v_resultado > 0) then
      v_resultado := DIF_NEG;
    else
      v_resultado := DIF_INEXISTENTE;
    
      for crs_saldo in (select v.idproduto
                          from vt_backlistor v
                         where v.h$idlotenf = p_idLotenf
                           and v.diferenca > 0)
      loop
        v_resultado := DIF_POS_SEM_SALDO;
        for crs_saldoNF in (select nf.idnotafiscal, nd.idnfdet, nd.idproduto,
                                   nd.qtdeatendida * e.fatorconversao qtd
                              from notafiscal nf, nfdet nd, embalagem e
                             where nf.idnotafiscal = nd.nf
                               and nf.idlotenf = p_idloteNF
                               and nd.idproduto = crs_saldo.idproduto
                               and nd.idproduto = e.idproduto
                               and nd.barra = e.barra
                               and (nd.qtdeatendida * e.fatorconversao) >
                                   (select sum(b.qtde * e.fatorconversao)
                                      from backlist b
                                     where b.idnfdet = nd.idnfdet)
                               and exists
                             (select 1
                                      from vt_backlistor v
                                     where v.h$idlotenf = nf.idlotenf
                                       and v.idproduto = nd.idproduto
                                       and v.diferenca > 0))
        loop
          v_resultado := DIF_POS_COM_SALDO;
          exit;
        end loop;
        if (v_resultado = DIF_POS_COM_SALDO) then
          exit;
        end if;
      end loop;
    end if;
  
    return v_resultado;
  end getResumoValidacaoBackListOR;

END PK_RECEBIMENTO_BACKLIST;
/

