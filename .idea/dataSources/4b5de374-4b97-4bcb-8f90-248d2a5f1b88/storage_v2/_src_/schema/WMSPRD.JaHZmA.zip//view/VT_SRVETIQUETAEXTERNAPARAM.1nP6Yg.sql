create view VT_SRVETIQUETAEXTERNAPARAM as
select sp.id, s.descr servicoetiquetaexterna, sp.parametro, sp.valor,
       sp.idsrvetiquetaexterna h$idsrvetiquetaexterna
  from srvetiquetaexternaparam sp, servicoetiquetaexterna s
 where s.id = sp.idsrvetiquetaexterna
   and upper(sp.parametro) <> upper('printerResolution')
/

