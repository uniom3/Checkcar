create view VT_ITENSORDEMTRANSFERENCIA as
select ot.numeroordemtransferencia numordemtransf,
       oi.idordemtransferenciaitem, oi.itemlocation, p.codigointerno,
       p.descr produto, tp.descr tipo, stp.descr subtipo,
       fam.razaosocial familia, oi.qtdeinformada, oi.qtderecebida,
       oi.idproduto, ot.idordemtransferencia h$idordemtransferencia
  from ordemtransferencia ot, ordemtransferenciaitem oi, produto p,
       tipoproduto tp, subtipoproduto stp, entidade fam
 where oi.idordemtransferencia = ot.idordemtransferencia
   and p.idproduto = oi.idproduto
   and tp.idtipo = p.idtipo
   and stp.idsubtipo = p.idsubtipo
   and fam.identidade = p.idfamilia
/

