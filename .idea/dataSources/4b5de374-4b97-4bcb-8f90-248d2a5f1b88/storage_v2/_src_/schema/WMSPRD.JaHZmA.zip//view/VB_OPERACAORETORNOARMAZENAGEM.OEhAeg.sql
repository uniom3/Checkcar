create view VB_OPERACAORETORNOARMAZENAGEM as
select o.idcfop cfop, o.descr operacao, o.idoperacao, o.tipo h$tipooperacao,
       o.modelodocfiscal h$modelodocfiscal, o.tipooper h$tipooper
  from operacao o
 where o.tipooper = 'TA'
/

