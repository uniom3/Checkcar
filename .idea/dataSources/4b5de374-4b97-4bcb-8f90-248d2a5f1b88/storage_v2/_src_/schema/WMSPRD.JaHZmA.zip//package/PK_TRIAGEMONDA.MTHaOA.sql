create package pk_triagemonda is
  C_LIDO     constant number := 1;
  C_NAO_LIDO constant number := 0;

  procedure marcarNotaComoLida
  (
    p_idNotaFiscal number,
    p_idOnda       number
  );

  procedure marcarOndaComoLida(p_idOnda number);
end pk_triagemonda;
/

