create view V_SALDOESTOQUECOBERTURA as
select lt.idarmazem, lt.iddepositante, lt.idproduto,
       sum(cob.qtdecoberto - nvl(ret.qtderetorno, 0)) estoque,
       sum((cob.valorcob / cob.qtdecoberto) *
            (cob.qtdecoberto - nvl(ret.qtderetorno, 0))) valor
  from (select cl.idlote, sum(cl.qtdecoberto) qtdecoberto,
                sum(cl.qtdecoberto * (nd.precounitliquido / e.fatorconversao)) valorcob
           from coberturalote cl, nfdet nd, embalagem e
          where nd.idnfdet = cl.idnfdet
            and e.idproduto = nd.idproduto
            and e.barra = nd.barra
          group by cl.idlote) cob,
       (select cf.idlote, sum(cf.qtde) qtderetorno
           from coberturanotafiscal cf, notafiscal nf
          where nf.idnotafiscal = cf.idnotafiscalretorno
            and nf.statusnf = 'P'
          group by cf.idlote) ret, lote lt
 where ret.idlote(+) = cob.idlote
   and lt.idlote = cob.idlote
 group by lt.idarmazem, lt.iddepositante, lt.idproduto
having sum(cob.qtdecoberto - nvl(ret.qtderetorno, 0)) > 0
/

