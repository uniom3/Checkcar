create view VI_INT_ENVIO_AM_OCR as
select agrupador id, vendorpartytype, vendorpartyid, warehouselocationid,
       purchaseordernumber, vendorordernumber, cancelrequesttype,
       responsecondition, resultcode
  from int_envio_am_ocr
/

