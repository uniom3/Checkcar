create view VT_CONTROLEAVARIADET as
select decode(c.idlote, null, 0, 1) marcado, e.idlote, e.loteindustria,
       e.estoquedisponivel, nvl(c.qtde, 0) qtdeavaria,
       p.codigointerno codproduto, p.descr produto,
       d.razaosocial depositante, e.dtvencimento, e.idproduto,
       e.iddepositante, e.idcontroleavaria h$idcontroleavaria,
       dp.fracionarlote h$fracionarlote
  from (select ca.idcontroleavaria, ll.idlote, l.descr loteindustria,
                round(ll.estoque + ll.adicionar - ll.pendencia, 6) estoquedisponivel,
                l.dtvenc dtvencimento, l.idproduto, l.iddepositante
           from controleavaria ca, lotelocal ll, local lc, lote l, setor s
          where ll.idarmazem = ca.idarmazemorigem
            and ll.idlocal = ca.idlocalorigem
            and ((ll.estoque - ll.pendencia > 0) or exists
                 (select 1
                    from controleavariadet
                   where idcontroleavaria = ca.idcontroleavaria
                     and idlote = ll.idlote))
            and lc.idarmazem = ll.idarmazem
            and lc.idlocal = ll.idlocal
            and nvl(lc.ativo, 'N') = 'S'
            and l.idlote = ll.idlote
            and l.tipolote = 'L'
            and l.estado = 'N'
            and l.idlotemont is null
            and s.idsetor = lc.idsetor) e, produto p, entidade d,
       controleavariadet c, depositante dp
 where p.idproduto(+) = e.idproduto
   and d.identidade(+) = e.iddepositante
   and c.idcontroleavaria(+) = e.idcontroleavaria
   and c.idlote(+) = e.idlote
   and d.identidade = dp.identidade
   and not exists
 (select 1
          from conferenciaentradadet ced, checklistmaterialvalor cmv
         where ced.idlote = e.idlote
           and cmv.idlotenf = ced.idlotenf
           and cmv.idconferenciaentrada = ced.idconferenciaentrada
           and cmv.idcontagem = ced.idcontagem)
   and not exists
 (select 1
          from ordemservico os, origemlote los, notafiscal nf
         where os.idlotenf = nf.idlotenf
           and os.tiposervico in ('E', 'I', 'J')
           and los.idlote = e.idlote
           and nf.idnotafiscal = los.idnotafiscal)
   and not exists
 (select 1
          from ordemservico os, origemlote los, notafiscal nf
         where os.idlotenf = nf.idlotenf
           and os.tiposervico in ('E', 'I', 'J')
           and los.idlote = pk_lote.getIdLoteAnterior(e.idlote)
           and nf.idnotafiscal = los.idnotafiscal)
/

