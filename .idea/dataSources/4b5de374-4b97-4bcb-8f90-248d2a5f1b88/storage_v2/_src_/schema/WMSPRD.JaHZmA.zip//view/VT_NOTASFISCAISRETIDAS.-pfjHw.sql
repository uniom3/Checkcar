create view VT_NOTASFISCAISRETIDAS as
select e.razaosocial depositante, nf.numpedidofornecedor numeroPedido,
       nf.codigointerno numeroNf,
       decode(op.tipoOper, 'RA', 'Remessa Armazenagem', 'RS',
               'Remessa Simbólica para Armazenagem', 'TA',
               'Retorno de Armazenagem', 'TS',
               'Retorno Simbólico de Armazenagem', 'TG',
               'Retorno Armazenagem GMB', 'G',
               'Guia Movimentação Bancária (GMB)', 'RD', 'Retorno Devolução',
               'Outros') tipoOper, nf.impresso faturado, nf.impresso,
       emit.razaosocial emitente, dest.razaosocial destinatario,
       nfr.idromaneio ondaSeparacao, nf.chaveacessonfe, nf.dataemissao,
       decode(nf.statusnf, 'P', 'PROCESSADA', 'X', 'CANCELADA', 'C',
               'EM CARGA/OR', 'N',
               decode(nf.digitada, 'S', 'DIGITADA', 'IMPORTADA'), 'IMPORTADA') statusNf,
       decode(nf.statusretencao, 0, 'SEM RETENÇÃO', 1, 'RETIDA', 'LIBERADA') statusRetencao,
       mv.descr motivo, nf.datahoraretencao,
       userRet.nomeusuario usuarioRetencao, nf.Datahoralibretencao,
       userLibRet.nomeUsuario usuarioLibRet, nf.idnotafiscal, nf.idarmazem h$idarmazem,
       nf.rowid h$tableid, nf.statusretencao h$statusRetencao,
       nf.idnotafiscal h$idnotafiscal, nf.statusnf h$statusnf
  from notafiscal nf, depositante d, entidade e, entidade emit,
       entidade dest, nfromaneio nfr, motivo mv, usuario userRet,
       usuario userLibRet, operacao op
 where d.utilizaretencaoexpedicao = 1
   and nf.tipo = 'S'
   and nf.statusnf <> 'X'
   and not exists
 (select 1
          from notafiscal nf1
         where nf1.idnotafiscal = nf.idnotafiscal
           and (nf1.sequencia like 'AJUSTE%' or nf1.sequencia like 'AVARIA%' or
               nf1.sequencia like 'INVENTARIO%' or
               nf1.sequencia like 'RET%' or nf1.sequencia like 'PRODREC%' or
               nf1.sequencia like 'AGCOB%'))
   and op.idoperacao = nf.idoperacao
   and d.identidade = nf.iddepositante
   and e.identidade = d.identidade
   and e.identidade = nf.iddepositante
   and emit.identidade = nf.remetente
   and dest.identidade = nf.destinatario
   and nfr.idnotafiscal(+) = nf.idnotafiscal
   and mv.idmotivo(+) = nf.idmotivoretencao
   and userRet.Idusuario(+) = nf.idusuarioretencao
   and userLibRet.Idusuario(+) = nf.idusuarioliberacaoretencao
/

