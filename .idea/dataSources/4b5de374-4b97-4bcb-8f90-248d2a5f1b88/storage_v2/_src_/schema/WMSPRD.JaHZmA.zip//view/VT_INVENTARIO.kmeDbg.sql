create view VT_INVENTARIO as
select i.idinventario,
       (select decode(qtdDep, 1,
                        (select e.razaosocial
                            from entidade e, depositanteinventario dii
                           where e.identidade = dii.identidade
                             and dii.idinventario = k.idinventario
                             and rownum = 1), '[' || qtdDep || '] DEPOSITANTES')
           from (select di.idinventario, count(id) qtdDep
                    from depositanteinventario di
                   group by di.idinventario) k
          where k.idinventario = i.idinventario) depositante, i.descricao,
       decode(i.situacao, 'C', 'AGUARDANDO LIBERAÇÃO', 'B',
               'BLOQUEADO PARA CONTAGENS', 'L', 'LIBERADO PARA CONTAGENS', 'F',
               'FINALIZADO', 'X', 'CANCELADO') situacao,
       decode(i.tipoinventario, 'G', 'GERAL', 'C', 'ROTATIVO') tipo,
       decode(i.contageminventario, 0, 'PICKING E PULMÃO', 1, 'PICKING', 2,
               'PULMÃO') tipocontagem,
       decode(i.padraoidentificacao, 0, 'LOTE', 1, 'EMBALAGEM', 2,
               'INFORMAÇÃO ESPECÍFICA') identificarprodutopor,
       i.conferirestado, i.conferirdatavencimento, i.conferirdatafabricacao,
       i.conferirloteindustria, i.conferenciaporproduto, i.atualizadadoslote,
       i.atualizapickinginv, i.solicitaqtdecaixa,
       i.ignorarcontagemautomaticamento, i.permitircontduplicadadoprod,
       i.permitircontagemdupporendereco, i.agruparcontagemdoproduto,
       i.qtdejuntocombarra, i.datahora dtcadastro,
       u.nomeusuario usuariocadastro, i.dataliberacao dtliberacao,
       ul.nomeusuario usuarioliberacao, i.databloqueio dtbloqueio,
       ub.nomeusuario usuariobloqueio, i.datafinalizacao dtfinalizacao,
       uf.nomeusuario usuariofinalizacao, i.contacontabil,
       i.inventarioterceirizado, i.empresarespinventario,
       i.tipoinventario h$tipo, i.contageminventario h$tipocontagem,
       i.padraoidentificacao h$identificarproduto, i.situacao h$situacao,
       i.idarmazem h$idarmazem, i.retorno h$retorno,
       (select count(1)
           from depositanteinventario di
          where di.idinventario = i.idinventario) H$DEPVINCULADO,
       (case
          when i.inventarioterceirizado = 0 then
           0
          else
           (select di.identidade
              from depositanteinventario di
             where di.idinventario = i.idinventario
               and rownum = 1)
        end) iddepositante,
       (select count(1)
           from invdet inv
          where inv.idinventario = i.idinventario
            and inv.contagemautomatica = 'S') h$contagemAutomatica
  from inventario i, usuario u, usuario ul, usuario ub, usuario uf
 where u.idusuario = i.idusuario
   and ul.idusuario(+) = i.idusuarioliberacao
   and ub.idusuario(+) = i.idusuariobloqueio
   and uf.idusuario(+) = i.idusuariofinalizacao
 order by i.idinventario desc
/

