create view VT_RELATORIOKARDEXPRODUTO as
select e.identidade, e.razaosocial, e.cgc, e.cic, p.idproduto, p.descr,
       p.codigointerno
  from depositante d, entidade e, produto p, produtodepositante pd
 where pd.identidade = d.identidade
   and pd.idproduto = p.idproduto
   and e.identidade = d.identidade
   and exists
 (select 1
          from kardexdet kd
         where kd.iddepositante = d.identidade
           and kd.idproduto = p.idproduto
           and kd.operacao in ('ORDEM RECEBIMENTO', 'ROMANEIO/ONDA'))
 order by e.razaosocial, p.descr
/

