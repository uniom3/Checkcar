create view VT_PRODUTOSEMPICKING as
select p.idproduto, p.codigointerno codproduto, p.descr produto,
       e.razaosocial depositante, f.razaosocial familia
  from produtodepositante pd, produto p, entidade e, entidade f,
       depositante d
 where (pd.idproduto, pd.identidade) not in
       (select pl.idproduto, pl.identidade
          from produtolocal pl
         where pl.idproduto = pd.idproduto
           and pl.identidade = pd.identidade)
   and e.identidade = pd.identidade
   and p.idproduto = pd.idproduto
   and p.ativo = 'S'
   and f.identidade(+) = p.idfamilia
   and d.identidade = pd.identidade
   and d.usapicking = 'S'
/

