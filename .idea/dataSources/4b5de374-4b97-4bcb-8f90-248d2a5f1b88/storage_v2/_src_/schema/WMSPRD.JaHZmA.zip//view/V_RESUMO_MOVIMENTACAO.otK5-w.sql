create view V_RESUMO_MOVIMENTACAO as
select ent.tipomov, ent.id,
       pk_recebimento.Ret_NF_OR(ent.id, ent.idproduto) numnf,
       d.razaosocial depositante, ent.datamov, ent.mesmov, ent.mes,
       ent.classificacao, p.codigointerno codprod, p.descr produto,
       ent.totalprod, ent.totalpeso, ent.totalvolume, ent.totalnf,
       ent.idproduto, ent.identidade, 'E' tipo, null remetente, null destinatario
  from v_detalhe_entrada ent, entidade d, produto p
 where d.identidade = ent.identidade
   and p.idproduto = ent.idproduto
union
select sai.tipomov, sai.id, to_char(sai.numnf) numnf,
       d.razaosocial depositante, sai.datamov, sai.mesmov, sai.mes,
       sai.classificacao, p.codigointerno codprod, p.descr produto,
       sai.totalprod, sai.totalpeso, sai.totalvolume, sai.totalnf,
       sai.idproduto, sai.identidade, 'S' tipo, sai.remetente, sai.destinatario
  from v_detalhe_saida sai, entidade d, produto p
 where d.identidade = sai.identidade
   and p.idproduto = sai.idproduto
union
select aj.tipomov, aj.id, aj.numnf, d.razaosocial depositante, aj.datamov,
       aj.mesmov, aj.mes, aj.classificacao, p.codigointerno codprod,
       p.descr produto, aj.totalprod, aj.totalpeso, aj.totalvolume,
       aj.totalnf, aj.idproduto, aj.identidade, aj.tipo, aj.remetente, aj.destinatario
  from v_detalhe_ajuste aj, entidade d, produto p
 where d.identidade = aj.identidade
   and p.idproduto = aj.idproduto
/

