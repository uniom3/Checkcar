create view VT_DESESTOJAMENTO as
select os.rowid h$tableid, os.idordemservico, os.datacadastro dtcadastro,
       e.razaosocial depositante,
       decode(os.situacao, 'A', 'Aguardando', 'P', 'Processada', 'X',
               'Cancelada') situacao, os.tiposervico, os.idlotenf,
       rp.codigointerno onda, os.dataprocessamento dtprocessamento,
       os.datacancelamento, u.nomeusuario usuariocancelamento,
       os.identidade iddepositante, os.idromaneio h$idromaneio,
       os.situacao h$situacao, os.tiposervico h$tiposervico,
       os.idarmazem h$idarmazem,
       decode(count(cml.idlote), 0, 0, 1) h$lotevinculado,
       d.permitiralterarqtdeseparacao H$PERMITIRALTERARQTDESEPARACAO
  from ordemservico os, entidade e, romaneiopai rp,
       classificacaomisturalote cml, depositante d, usuario u
 where e.identidade = os.identidade
   and rp.idromaneio(+) = os.idromaneio
   and os.tiposervico = 'J'
   and cml.idordemservico(+) = os.idordemservico
   and d.identidade = e.identidade
   and u.idusuario(+) = os.idusuariocancel
 group by os.rowid, os.idordemservico, os.datacadastro, e.razaosocial,
          os.tiposervico, os.situacao, os.idlotenf, rp.codigointerno,
          os.dataprocessamento, os.identidade, os.idproduto, os.idromaneio,
          os.situacao, os.tiposervico, os.idarmazem,
          d.permitiralterarqtdeseparacao, os.datacancelamento, u.nomeusuario
/

