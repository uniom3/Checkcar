create view VT_GERENCIADORSEPARACAO as
select rp.idromaneio id, rp.codigointerno, rp.tituloromaneio titulo,
       (select count(distinct ra.idregiao)
           from movimentacao m, local l, regiaoarmazenagem ra
          where m.idonda = rp.idromaneio
            and l.id = m.idlocalorigem
            and ra.idregiao = l.idregiao) qtdeMapas,
       (select count(distinct nf.idnotafiscal)
           from movimentacao m, notafiscal nf
          where m.idonda = rp.idromaneio
            and m.status <> 3
            and nf.idnotafiscal = m.idnotafiscal) qtdePedidos,
       (select count(distinct lt.idproduto)
           from movimentacao m, lote lt
          where m.idonda = rp.idromaneio
            and lt.idlote = m.idlote) qtdeProdutos,
       (select (sum(case
                        when m.status in (2) then
                         1
                        else
                         0
                      end) * 100) / decode(sum(case
                                                 when m.status in (0, 1, 2) then
                                                  1
                                                 else
                                                  0
                                               end), 0, 1,
                                           sum(case
                                                  when m.status in (0, 1, 2) then
                                                   1
                                                  else
                                                   0
                                                end))
           from movimentacao m
          where m.idonda = rp.idromaneio) percentual, rp.statusonda status,
       rp.idarmazem h$idarmazem
  from romaneiopai rp
 where rp.statusonda not in (0, 3, 5)
   and rp.tipo = 1
/

