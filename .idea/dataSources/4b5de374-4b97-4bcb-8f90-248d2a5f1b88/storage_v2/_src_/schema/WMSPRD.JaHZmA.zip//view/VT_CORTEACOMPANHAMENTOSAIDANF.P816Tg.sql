create view VT_CORTEACOMPANHAMENTOSAIDANF as
select r.codigointerno onda, r.tituloromaneio tituloondaromaneio,
       stragg(distinct nf.pedido) pedido,
       stragg(distinct nf.notafiscal) notafiscal,
       stragg(distinct nf.serie) serie,
       decode(lo.tipo, 0, 'SEPARAÇÃO', 1, 'SEPARAÇÃO', 2, 'SEPARAÇÃO', 8,
               'PACKING', 'LOCAL NÃO FORNECIDO') tipolocalcorte,
       lo.idlocal idlocalcorte, lo.idlocalformatado f$idlocalcorte,
       lo.ordem h$ordemcorte,
       (decode(f.bufferorigem, 1, 'BUFFER DE ', '') || rao.descr ||
        ' PARA ' || decode(f.bufferdestino, 1, 'BUFFER DE ') || rad.descr) separacao,
       decode(f.identificador, 0, f.idenderecofalta, f.identificador) identificadorseparacao,
       f.codbarratarefa tarefa, p.codigointerno codproduto, p.descr produto,
       f.fatorconversao, f.qtdeseparacao,
       (f.qtdeencontrada * nvl(e.fatorconversao, 1)) qtdeencontrada,
       f.qtdeconfirmada, u.nomeusuario usuariocorte, f.data dtcorte,
       stragg(distinct mn.codbarratarefa) novatarefa,
       stragg(distinct nvl(us.nomeusuario, u.nomeusuario)) usuarioseparacao,
       stragg(distinct los.idlocalformatado) idlocalseparacao, f.status,
       mo.descr motivoocorrencia, ur.nomeusuario usuarioresolucao,
       f.dataresolucao dtresolucao, sum(nf.valor) valoraceito,
       f.id idcortefisico, fn.idajustemovto idajuste,
       stragg(distinct nf.idnotafiscal) idnotafiscal
  from gtt_selecao g, cortefisiconf fn, cortefisico f, romaneiopai r,
       local lo, regiaoarmazenagem rao, regiaoarmazenagem rad, produto p,
       embalagem e, usuario u, usuario ur, resestoquecortefisiconf res,
       v_tarefas_onda m, usuario us, local los, v_tarefas_onda mn,
       ajustemovto aj, motivo mo,
       (select nf.idnotafiscal, nf.numpedidofornecedor pedido,
                nf.codigointerno notafiscal, nf.sequencia serie, nd.idproduto,
                sum(nvl(nd.qtdecorteseparacaoaceita, 0) *
                     nvl(nd.precounitliquido, 0)) valor
           from notafiscal nf, nfdet nd
          where nd.nf = nf.idnotafiscal
          group by nf.idnotafiscal, nf.numpedidofornecedor, nf.codigointerno,
                   nf.sequencia, nd.idproduto) nf
 where fn.idnotafiscal = g.idselecionado
   and fn.qtdeseparacao <> fn.qtdeutilizada
   and f.id = fn.idcortefisico
   and r.idromaneio = f.idonda
   and lo.id = f.idenderecofalta
   and rao.idregiao = f.idregiaoorigem
   and rad.idregiao = f.idregiaodestino
   and p.idproduto = f.idproduto
   and e.idproduto(+) = f.idproduto
   and e.barra(+) = f.barra
   and u.idusuario = f.idusuario
   and ur.idusuario(+) = f.idusuarioresolucao
   and res.idcortefisiconf = fn.id
   and m.id = res.idmovimentacaoafetada
   and us.idusuario(+) = m.idusuario
   and los.id = m.idlocalorigem
   and mn.id(+) = res.idmovimentacaonova
   and nf.idnotafiscal = fn.idnotafiscal
   and nf.idproduto = f.idproduto
   and mo.idmotivo(+) = aj.idmotivo
   and aj.idajustemovto(+) = fn.idajustemovto
 group by r.codigointerno, r.tituloromaneio, lo.idlocal, lo.idlocalformatado,
          lo.ordem,
          decode(lo.tipo, 0, 'SEPARAÇÃO', 1, 'SEPARAÇÃO', 2, 'SEPARAÇÃO', 8,
                  'PACKING', 'LOCAL NÃO FORNECIDO'),
          (decode(f.bufferorigem, 1, 'BUFFER DE ', '') || rao.descr ||
           ' PARA ' || decode(f.bufferdestino, 1, 'BUFFER DE ') ||
           rad.descr), p.idproduto, p.codigointerno, p.descr,
          decode(f.identificador, 0, f.idenderecofalta, f.identificador),
          f.fatorconversao, f.qtdeseparacao,
          (f.qtdeencontrada * nvl(e.fatorconversao, 1)), f.qtdeconfirmada,
          f.id, f.status, f.data, f.codbarratarefa, f.dataresolucao,
          u.nomeusuario, ur.nomeusuario, mo.descr, mo.idmotivo,
          fn.idajustemovto
 order by f.data desc
/

