create view VT_TIPOATIVIDADEGRUPOREGIAO as
select tgr.idregiao, ra.descr regiao, tgr.idtipoatividade h$idtipoatividade, tgr.idgrupo h$idgrupo
  from tipoatividadegruporegiao tgr, regiaoarmazenagem ra
where ra.idregiao = tgr.idregiao
/

