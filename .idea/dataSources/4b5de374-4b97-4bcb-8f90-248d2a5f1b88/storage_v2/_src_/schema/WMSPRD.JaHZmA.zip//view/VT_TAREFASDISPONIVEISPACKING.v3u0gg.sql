create view VT_TAREFASDISPONIVEISPACKING as
select pp.codbarratarefa, pp.idnotafiscal identificador, nf.codigointerno,
       nf.numpedidofornecedor numeroPedido,
       trunc((sum(pp.qtdeseparada) * 100) / sum(pp.qtdetotal)) percentual,
       pp.idenderecopacking h$idpacking, rp.idarmazem h$idArmazem,
       pp.codbarratarefa || pp.idnotafiscal h$tableid
  from v_tarefaprodutoconfpacking pp, romaneiopai rp, notafiscal nf
 where pp.idonda = rp.idromaneio
   and rp.statusonda in (2, 4)
   and pp.qtdeemvolume <> pp.qtdetotal
   and nf.idnotafiscal = pp.idnotafiscal
 group by pp.codbarratarefa, pp.idnotafiscal, nf.codigointerno,
          nf.numpedidofornecedor, pp.idenderecopacking, rp.idarmazem,
          pp.codbarratarefa || pp.idnotafiscal
/

