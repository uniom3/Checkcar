create view VI_INT_ENVIO_EFD_0150_INV as
select distinct '0150' reg, h.idarmazem, h.data dataprocessamento,
                e.codigointerno cod_part, e.razaosocial nome, 01058 cod_pais,
                decode(e.pessoa, 'J',
                        replace(replace(replace(e.cgc, '.', ''), '/', ''), '-',
                                 ''), ' ') cnpj,
                decode(e.pessoa, 'F',
                        replace(replace(replace(e.cic, '.', ''), '/', ''), '-',
                                 ''), ' ') cpf,
                nvl(pk_entidade.retValorSemMascara(e.inscrestadual), ' ') ie,
                ed.codmunicipio cod_mun,
                nvl(e.inscricaosuframa, ' ') suframa,
                nvl(ed.logradouro, ' ') "END", nvl(ed.numero, ' ') num,
                nvl(ed.complendereco, ' ') compl, nvl(ed.bairro, ' ') bairro
  from historicoestoquediario h, lote l, depositante d, entidade e,
       v_endereco ed, regime r
 where h.valor > 0
   and l.idlote = h.idlote
   and d.identidade = l.iddepositante
   and e.identidade = d.identidade
   and ed.identidade(+) = e.identidade
   and ed.idendereco(+) = pk_entidade.f_ret_idendereco(e.identidade)
   and d.idregime = r.idregime
   and r.classificacao = 'A'
/

