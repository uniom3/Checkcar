create view VI_INT_ENVIO_FATUR_SPEC_LOTE as
select codigointerno, sequencia, numpedido, cnpj_depositante, cnpj_emitente,
       idseq, substr(codigoproduto, 1, 20) codigoproduto,
       case
          when length(barra) <= 20 then
           barra
          else
           ''
        end barra, idnfdet, informacaoespecifica, valor, idfaturamentoespec,
       agrupador id, codigoproduto codproduto, barra barraemb
  from int_envio_faturamentoespec_lot
/

