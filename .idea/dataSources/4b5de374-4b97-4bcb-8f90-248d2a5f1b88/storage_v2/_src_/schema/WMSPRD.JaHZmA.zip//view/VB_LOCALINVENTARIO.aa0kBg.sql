create view VB_LOCALINVENTARIO as
select e.idlocal, l.idlocalformatado f$idlocal, l.rua, l.predio, l.andar,
       l.id H$IDENDERECO, e.idinventario h$idinventario
  from escopoinventario e, local l
 where e.idlocal = l.idlocal
   and e.idarmazem = l.idarmazem
/

