create view V_PRODUTIVIDADE_POSICIONAMENTO as
select data, anomes, idusuario, usuario, nomeusuario, atividade, depositante,
       setor, regiao, pk_utilities.retornarTempo(tempogasto) tempogasto,
       qtdeitens, qtdeunidades, round(qtdevolumes, 6) qtdevolumes,
       round(pesokg, 4) pesokg, qtdeatividade
  from (select p.data, p.anomes, p.idusuario, p.usuario, p.nomeusuario,
                p.atividade, p.depositante, p.setor, p.regiao,
                sum(p.tempogasto) tempogasto, sum(p.qtdeitens) qtdeitens,
                sum(p.qtdeunidades) qtdeunidades,
                sum(p.qtdevolumes) qtdevolumes, sum(p.pesokg) pesokg,
                sum(p.qtdeatividade) qtdeatividade
           from (select ol.idlotenf, trunc(m.dataposicionamento) data,
                         to_char(m.dataposicionamento, 'yyyy/mm') anomes,
                         m.idusuario, u.nomeusuario usuario,
                         u.nomeusuariocompleto nomeusuario,
                         'POSICIONAMENTO' atividade,
                         edep.razaosocial depositante, s.descr setor,
                         r.descr regiao, min(m.dataposicionamento) horainicio,
                         max(m.dataposicionamento) horafim,
                         (max(m.dataposicionamento) - min(m.dataposicionamento)) *
                          86400 tempogasto,
                         count(distinct l.idproduto) qtdeitens,
                         sum(l.qtdeentrada * e.fatorconversao) qtdeunidades,
                         sum((l.qtdeentrada * e.fatorconversao) /
                              pk_produto.getFatorEmbCompra(l.idproduto)) qtdevolumes,
                         sum(l.qtdeentrada * e.pesobruto) / 1000 pesokg,
                         count(distinct m.idalocacao) qtdeatividade
                    from orlote ol, mapaalocacao m, usuario u, lote l,
                         embalagem e, local lo, setor s, regiaoarmazenagem r,
                         entidade edep
                   where m.idlote = ol.idlote
                     and m.posicionado = 1
                     and u.idusuario = m.idusuarioposicionamento
                     and l.idlote = m.idlote
                     and e.idproduto = l.idproduto
                     and e.barra = l.barra
                     and lo.idarmazem = m.idarmazem
                     and lo.idlocal = m.idlocal
                     and s.idsetor(+) = lo.idsetor
                     and r.idregiao(+) = lo.idregiao
                     and edep.identidade(+) = l.iddepositante
                   group by ol.idlotenf, trunc(m.dataposicionamento),
                            to_char(m.dataposicionamento, 'yyyy/mm'),
                            m.idusuario, u.nomeusuario, u.nomeusuariocompleto,
                            s.descr, r.descr, edep.razaosocial) p
          group by p.data, p.anomes, p.idusuario, p.usuario, p.nomeusuario,
                   p.atividade, p.setor, p.regiao, p.depositante)
 order by data, nomeusuario
/

