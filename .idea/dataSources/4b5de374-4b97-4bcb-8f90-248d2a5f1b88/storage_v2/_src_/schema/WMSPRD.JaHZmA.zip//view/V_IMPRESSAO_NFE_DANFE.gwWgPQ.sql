create view V_IMPRESSAO_NFE_DANFE as
select (select sign(count(1))
           from nfe n
          where 1 = 1
            and n.idnotafiscal = nf.idnotafiscal
            and n.tipoAcao = 0
            and n.situacao = 3) existe_nfe,
       (select sign(count(1))
           from danfe_notafiscal d
          where d.idnotafiscal = nf.idnotafiscal
            and d.pdf is not null) existe_pdf, nf.idprenf
  from notafiscal nf
/

