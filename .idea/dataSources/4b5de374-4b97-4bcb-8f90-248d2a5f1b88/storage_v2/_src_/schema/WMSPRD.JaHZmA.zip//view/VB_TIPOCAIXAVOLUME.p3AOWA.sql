create view VB_TIPOCAIXAVOLUME as
select t.idtipocaixavolume, descr caixa,
       decode(t.tipo, 0, 'PROPRIA', 1, 'RETORNAVEL', 2, 'PACOTE', 3,
               'REUTILIZAVEL') tipocaixa, t.tipo h$tipo
  from tipocaixavolume t
 where t.disponivel = 1
   and t.ativo = 1
/

