create view VB_SUBFAMILIA as
select idsubfamilia, descr subfamilia
   from subfamilia
/

