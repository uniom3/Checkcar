create view VT_PRODUTOAUDITADOCEGA as
select barra, produto, conferido, H$idauditoriavolume,
       H$confirmaqtdeauditoria, H$quantidadeliberada
  from vt_produtoAuditado
/

