create view VR_CARTACORRECAONFE as
select (select infevento_id from vr_xmlcancelamento v where v.h$idnotafiscal = nf.idnotafiscal) idevento,
       ent.razaosocial razaosocialemitente,
       e.endereco endereco,
       e.bairro || ' - ' || e.cep bairrocep,
       e.cidade || ' - ' || e.uf || ' ' || tel.idtelefone cidadeuftelefone,
       to_char(nfe.datahoratransmissao, 'DD/MM/RRRR HH24:MI:SS') datahoracriacao,
       nfe.protocoloenvio protocolo,
       to_char(nfe.datahorarecebimento, 'DD/MM/RRRR HH24:MI:SS') datahorasefaz,
       nf.codigointerno notafiscal,
       nf.sequencia serie,
       nfe.chaveacesso codbarra,
       nfe.justificativaenvio correcao,
       nfe.id idnfe
  from nfe nfe, notafiscal nf, entidade ent, v_endereco e, telefone tel
  where nf.remetente = ent.identidade
    and nf.idnotafiscal = nfe.idnotafiscal
    and e.identidade(+) = ent.identidade
    and tel.identidade(+) = e.identidade
    and tel.idendereco(+) = e.idendereco
    and nfe.tipoevento = 1
    and nfe.situacao = 3
/

