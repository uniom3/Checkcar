create view VT_VINCTEMORDEMCOMPRANFDET as
select i.qtdeassociada, i.qtdedisponivel, o.codigoordemcompra,
       d.codigointerno coddepositante, d.razaosocial depositante,
       p.codigointerno codproduto, p.descr produto, i.dtestimadarecebimento,
       p.idproduto, o.idordemcompra, o.idarmazem h$idarmazem,
       d.identidade h$iddepositante, i.iditemordemcompra h$iditemordemcompra
  from (select o.idordemcompra, o.iditemordemcompra, o.idarmazem,
                o.iddepositante, o.idproduto, o.dtestimadarecebimento,
                o.qtde - sum(nvl(a.qtde, 0)) qtdedisponivel,
                sum(nvl(a.qtde, 0)) qtdeassociada
           from (select o.idordemcompra, o.idarmazem, o.iddepositante,
                         io.idproduto, io.iditemordemcompra,
                         io.qtdesolicitada qtde,
                         io.qtderecebida qtderecebida,
                         io.dtestimadarecebimento
                    from ordemcompra o, itemordemcompra io
                   where io.idordemcompra = o.idordemcompra) o,
                (select o.idarmazem, o.iddepositante, io.idproduto,
                         io.iditemordemcompra, idet.idnfdet, idet.qtde
                    from ordemcompra o, itemordemcompra io, itemopanfdet idet
                   where io.idordemcompra = o.idordemcompra
                     and idet.iditemordemcompra = io.iditemordemcompra) a
          where a.idarmazem(+) = o.idarmazem
            and a.iddepositante(+) = o.iddepositante
            and a.idproduto(+) = o.idproduto
            and a.iditemordemcompra(+) = o.iditemordemcompra
          group by o.idordemcompra, o.iditemordemcompra, o.idarmazem,
                   o.iddepositante, o.idproduto, o.qtde,
                   o.dtestimadarecebimento) i, ordemcompra o, entidade d,
       produto p
 where o.idordemcompra = i.idordemcompra
   and d.identidade (+) = o.iddepositante
   and p.idproduto = i.idproduto
/

