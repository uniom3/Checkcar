create view VB_OPERACAO as
select o.idcfop cfop, o.descr operacao, o.idoperacao, o.tipo h$tipooperacao,
       o.modelodocfiscal h$modelodocfiscal, o.tipooper h$tipooper
  from operacao o
 where (o.tipooper not in ('TA', 'TG', 'TS', 'RG', 'G') or
       o.tipooper is null)
/

