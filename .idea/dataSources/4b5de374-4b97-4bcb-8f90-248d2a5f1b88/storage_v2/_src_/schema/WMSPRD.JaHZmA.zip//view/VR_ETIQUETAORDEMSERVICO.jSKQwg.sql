create view VR_ETIQUETAORDEMSERVICO as
select por.codproduto codsku, nvl(por.barraunitaria, ' ') barra,
       pk_lote.gerarloteIndPorOS(g.idselecionado) loteindustria,
       (select min(l.dtvenc)
           from lote l, movimentacao m
          where m.idonda = os.idromaneio
            and l.idlote = m.idlote
          group by os.idordemservico) dtvencimento,
       pk_lote.gerarBarra128GS1(os.idarmazem, 1, por.barraunitaria,
                                 pk_lote.gerarloteIndPorOS(g.idselecionado),
                                 (select min(l.dtvenc)
                                     from lote l, movimentacao m
                                    where m.idonda = os.idromaneio
                                      and l.idlote = m.idlote
                                    group by os.idordemservico), 0) barraGS1,
       pk_lote.gerarBarra128GS1(os.idarmazem, 1, por.barraunitaria,
                                 pk_lote.gerarloteIndPorOS(g.idselecionado),
                                 (select min(l.dtvenc)
                                     from lote l, movimentacao m
                                    where m.idonda = os.idromaneio
                                      and l.idlote = m.idlote
                                    group by os.idordemservico), 1) barraGS1Texto,
       os.idordemservico idordemservico
  from gtt_selecao g, ordemservico os, vt_produtoor por
 where 1 = 1
   and g.idselecionado = os.idordemservico
   and os.tiposervico IN ('E', 'I')
   and os.situacao in ('B', 'O', 'P')
   and os.idlotenf = por.idlotenf
/

