create view VR_RELATORIOMAPAALOCACAO as
select m.armazem, m.depositante, m.idlotenf,
       decode(m.classificacao, 'C', 'COMPRA', 'D', 'DEVOLUCAO PARCIAL', 'T',
               'DEVOLUCAO TOTAL', 'R', 'REENTREGA', 'X',
               'CROSSDOCKING COM PICKING DINAMICO', 'A', 'CROSSDOCKING DIRETO',
               'M', 'CROSSDOCKING ALOCACAO MANUAL', 'I', 'OPERACOES INTERNAS',
               'Z', 'CROSS DOCKING ALOCAÇÃO ENDEREÇOS BLOCADOS', 'E',
               'ENCOMENDA') tiporecebimento, m.idlote, m.codproduto,
       m.codreferencia, m.produto, m.qtde, m.descrreduzido embalagem,
       m.idlocalformatado idlocal, m.tipolocal, m.descr descrmapa,
       m.normapalet norma, m.idalocacao, nvl(m.lote, ' ') loteindustria
  from v_mapaalocacao m
/

