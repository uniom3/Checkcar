create view VB_CEST as
select v.id, v.codigo, v.descricao
  from vt_cest v
/

