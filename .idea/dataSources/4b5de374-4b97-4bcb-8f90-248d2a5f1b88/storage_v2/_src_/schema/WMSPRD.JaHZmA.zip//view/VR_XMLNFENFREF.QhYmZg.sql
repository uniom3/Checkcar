create view VR_XMLNFENFREF as
select trim(decode(nfc.tiponf, 'E', nfic.chaveacessonfe, null)) ide_NFref_refNFe,
       decode(nfc.tiponf, 'E', null,
               case
                  when (nvl(nfic.estado_emit, eemit.uf) = 'AC') then
                   12
                  when (nvl(nfic.estado_emit, eemit.uf) = 'AL') then
                   27
                  when (nvl(nfic.estado_emit, eemit.uf) = 'AM') then
                   13
                  when (nvl(nfic.estado_emit, eemit.uf) = 'BA') then
                   29
                  when (nvl(nfic.estado_emit, eemit.uf) = 'CE') then
                   23
                  when (nvl(nfic.estado_emit, eemit.uf) = 'DF') then
                   53
                  when (nvl(nfic.estado_emit, eemit.uf) = 'ES') then
                   32
                  when (nvl(nfic.estado_emit, eemit.uf) = 'GO') then
                   52
                  when (nvl(nfic.estado_emit, eemit.uf) = 'MA') then
                   21
                  when (nvl(nfic.estado_emit, eemit.uf) = 'MG') then
                   31
                  when (nvl(nfic.estado_emit, eemit.uf) = 'MS') then
                   50
                  when (nvl(nfic.estado_emit, eemit.uf) = 'MT') then
                   51
                  when (nvl(nfic.estado_emit, eemit.uf) = 'PA') then
                   15
                  when (nvl(nfic.estado_emit, eemit.uf) = 'PB') then
                   25
                  when (nvl(nfic.estado_emit, eemit.uf) = 'PE') then
                   26
                  when (nvl(nfic.estado_emit, eemit.uf) = 'PI') then
                   22
                  when (nvl(nfic.estado_emit, eemit.uf) = 'PR') then
                   41
                  when (nvl(nfic.estado_emit, eemit.uf) = 'RJ') then
                   33
                  when (nvl(nfic.estado_emit, eemit.uf) = 'RN') then
                   24
                  when (nvl(nfic.estado_emit, eemit.uf) = 'RO') then
                   11
                  when (nvl(nfic.estado_emit, eemit.uf) = 'RR') then
                   14
                  when (nvl(nfic.estado_emit, eemit.uf) = 'RS') then
                   43
                  when (nvl(nfic.estado_emit, eemit.uf) = 'SC') then
                   42
                  when (nvl(nfic.estado_emit, eemit.uf) = 'SE') then
                   28
                  when (nvl(nfic.estado_emit, eemit.uf) = 'SP') then
                   35
                  when (nvl(nfic.estado_emit, eemit.uf) = 'TO') then
                   17
                  else
                   99
                end) ide_NFref_refNF_cUF,
       decode(nfc.tiponf, 'E', null,
               to_char(to_date(nfic.data_emissao, 'dd/mm/yyyy'), 'yymm')) ide_NFref_refNF_AAMM,
       decode(nfc.tiponf, 'E', null,
               replace(replace(replace(nfic.cnpj_emitente, '.', ''), '/', ''),
                        '-', '')) ide_NFref_refNF_CNPJ,
       decode(nfc.tiponf, 'E', null, nvl(nfic.modelodocfiscal, '01')) ide_NFref_refNF_mod,
       decode(nfc.tiponf, 'E', null, nvl(nfic.sequencia, '0')) ide_NFref_refNF_serie,
       decode(nfc.tiponf, 'E', null, to_number(nfic.codigointerno)) ide_NFref_refNF_nNF,
       nf.idprenf h$idprenf
  from notafiscal nf,
       (select distinct idnotafiscalretorno, idnotafiscalcobertura
           from coberturanotafiscal) cf, notafiscal nfc, nfimpressao nfic,
       entidade emit, v_endereco eemit
 where nvl(nf.tiponf, 'N') in ('N', 'E')
   and cf.idnotafiscalretorno = nf.idnotafiscal
   and nfc.idnotafiscal = cf.idnotafiscalcobertura
   and nfic.idprenf = nfc.idprenf
   and emit.identidade = nfc.remetente
   and eemit.identidade(+) = nfc.remetente
/

