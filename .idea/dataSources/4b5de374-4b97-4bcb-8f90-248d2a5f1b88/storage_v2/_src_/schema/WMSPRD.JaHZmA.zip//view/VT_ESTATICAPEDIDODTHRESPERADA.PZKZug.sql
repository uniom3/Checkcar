create view VT_ESTATICAPEDIDODTHRESPERADA as
select trunc(nf.dataesperadaembarque) dataesperadaembarque,
       to_number(to_char(nf.dataesperadaembarque, 'hh24')) horaesperadaembarque,
       count(nf.idnotafiscal) qtde_pedido_nf,
       sum(decode(nf.estoqueverificado, 'N', 1, 0)) -
       sum(decode(nf.statusnf, 'X', 1, 0)) falta_liberar_estoque,
       sum(decode(nf.estoqueverificado, 'S', 1, 0)) - count(rp.idromaneio) estoque_liberado,
       sum(decode(nf.statusnf, 'X', 1, 0)) canceladas,
       sum(case
             when (nf.estoqueverificado <> 'X') then
              0
             when (select count(1)
                     from nfdet
                    where nf = nf.idnotafiscal
                      and qtdeatendida > 0) = 0 then
              1
             else
              0
           end) nao_liberada,
       count(rp.idromaneio) em_onda,
       sum(decode(s.separado, '0', 1, 0)) falta_separar,
       sum(decode(s.separado, '1', 1, 0)) separados,
       sum(decode(s.conferido, '1', 1, 0)) conferidos,
       sum(decode(nfi.statusdoc, '9', 1, 0)) expedidos
  from notafiscal nf,
       nfimpressao nfi,
       nfromaneio nfr,
       romaneiopai rp,
       saidapornf s,
       (select rc.identidade, stragg(r.descr) rota, stragg(r.codigo) codrota
          from rotacliente rc, rotas r
         where r.idrota = rc.idrota
         group by rc.identidade) r
 where r.identidade(+) = nf.ident_entrega
   and rp.idromaneio(+) = nfr.idromaneio
   and nfr.idnotafiscal(+) = nf.idnotafiscal
   and s.idnotafiscal(+) = nf.idnotafiscal
   and nfi.idprenf = nf.idprenf
   and trunc(nf.dataesperadaembarque) >= trunc(sysdate - 10)
   and nvl(nf.sequencia, ' ') not like 'AJUSTE%'
   and nvl(nf.sequencia, ' ') not like 'DEV%'
   and nvl(nf.sequencia, ' ') not like 'AVARIA%'
   and nf.tipo = 'S'
 group by trunc(nf.dataesperadaembarque),
          to_number(to_char(nf.dataesperadaembarque, 'hh24'))
 order by trunc(nf.dataesperadaembarque),
          to_number(to_char(nf.dataesperadaembarque, 'hh24'))
/

