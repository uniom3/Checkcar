create view VT_RELACAOMANIFESTOS as
select c.codigointerno H$tableid, trunc(c.data) data, c.codigointerno carga,
       count(nfnumformulario) qtdepedidos,
       count(distinct mc.codcli) qtdeentregas, sum(mc.valor) valor,
       round(sum(mc.pesob), 2) pesokg, c.idarmazem h$idarmazem
  from manifestocarga mc, carga c
 where c.idcarga = mc.idcarga
 group by c.idarmazem, c.data, c.codigointerno
 order by c.data, c.codigointerno
/

