create view VT_CHECKLISTMATERIAL as
select idchecklistmaterial, questao
from checklistmaterial
/

