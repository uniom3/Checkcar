create view VB_ENTIDADEDEPOSITANTE as
select razaosocial, identidade, fantasia, cgc, cic, inscrestadual, pessoa, codigointerno
  from entidade
 where tipoentidade in (select idtipo
                          from tipo
                         where descr like '%FORNECEDOR%'
                            or descr like '%DEPOSITANTE%'
                            or descr like '%PROPRIETARIO%')
   and identidade not in (select identidade
                            from depositante)
   and iddepositante is null
/

