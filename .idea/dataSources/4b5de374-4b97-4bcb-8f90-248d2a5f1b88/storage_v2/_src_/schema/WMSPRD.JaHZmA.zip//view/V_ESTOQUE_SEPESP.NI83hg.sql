create view V_ESTOQUE_SEPESP as
select ll.idarmazem, l.iddepositante, p.idproduto, e.barra, ll.idlocal,
       ll.idlote, ll.dtalocacao, ll.estoque, nvl(ll.pendencia, 0) pendencia,
       nvl(ll.reservado, 0) reservado, nvl(ll.adicionar, 0) adicionar,
       nvl((nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
            (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)), 0) disp,
       p.codigointerno codprod, pd.codigointerno codProdutoDepositante,
       p.descr produto, e.altura, e.largura, e.comprimento, e.fatorconversao,
       lo.picking, lo.idsetor, lo.ativo localativo, l.estado estadolote,
       e.lastro, e.qtdecamada, l.dtvenc, lo.bloco, lo.rua, lo.predio,
       lo.andar, lo.apartamento, embun.barra barraun,
       nvl(lo.estanteria, 'N') estanteria, a.descr armazem, p.idfamilia,
       p.idsubfamilia, l.liberado loteliberado, l.databloqueio,
       l.motivobloqueio, ub.nomeusuario usuariobloqueio,
       l.descr descricaolote, l.qtdedisponivel qtdecobertalote,
       nvl(lo.modulo, nvl(a.modulopadrao, 2)) modulo, lo.idlocalpai,
       lo.idarmazempai,
       nvl(embun.altura, 0) * nvl(embun.largura, 0) *
        nvl(embun.comprimento, 0) cubagemprod,
       nvl(embun.pesobruto, 0) pesoprod, dep.razaosocial depositante,
       dep.codigointerno coddepositante, s.descr setor,
       decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'T',
               'VENCIDO/TRUNCADO', 'OUTROS') estado,
       embun.fatorconversao fatorconvun, embun.descrreduzido descrreduzidoun,
       l.idlotemont, l.itemadicional, l.idencomenda,
       decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'BANCADA', 6,
               'RUA EXPEDIÇÃO') tipolocal, nvl(s.expedicao, 'N') expedicao,
       l.idprodutoamostra, s.codigointegracao, lo.buffer, lo.tipo,
       lo.idlocalformatado, l.tipolote, l.estado h$estado,
       ll.idendereco h$idendereco, l.dtfabricacao
  from lotelocal ll, local lo, lote l, produto p, embalagem e, armazem a,
       usuario ub, embalagem embun, entidade dep, setor s,
       produtodepositante pd
 where lo.idlocal = ll.idlocal
   and lo.idarmazem = ll.idarmazem
   and l.idlote = ll.idlote
   and p.idproduto = l.idproduto
   and e.barra = l.barra
   and e.idproduto = l.idproduto
   and a.idarmazem = ll.idarmazem
   and nvl(l.tipolote, 'L') = 'L'
   and ub.idusuario(+) = l.idusuariobloqueio
   and embun.idproduto(+) = l.idproduto
   and embun.barra(+) = pk_produto.retornar_codbarra(l.idproduto, 1)
   and dep.identidade = l.iddepositante
   and s.idsetor(+) = lo.idsetor
   and s.expedicao = 'S'
   and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
       (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0
   and pd.identidade = dep.identidade
   and pd.idproduto = p.idproduto
/

