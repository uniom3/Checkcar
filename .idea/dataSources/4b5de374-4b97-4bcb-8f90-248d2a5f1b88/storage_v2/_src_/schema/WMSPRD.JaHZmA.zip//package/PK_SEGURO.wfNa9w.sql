create package PK_SEGURO is

  procedure addContratoSeguro
  (
    p_idSeguro   in number,
    p_idContrato in number
  );

  procedure removeContratoSeguro
  (
    p_idSeguro   in number,
    p_idContrato in number
  );
end PK_SEGURO;
/

