create view VT_USUARIOGRUPO as
select g.idgrupo, g.descr
  from grupo g
/

