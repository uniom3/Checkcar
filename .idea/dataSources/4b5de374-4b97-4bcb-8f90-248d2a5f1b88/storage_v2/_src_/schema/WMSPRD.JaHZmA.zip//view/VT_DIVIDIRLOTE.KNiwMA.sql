create view VT_DIVIDIRLOTE as
select v.h$tableid, v.idlocal, v.idlote, v.dtalocacao, v.estoqueun,
       v.pendenciaun, v.adicionarun, v.disponivelun, v.estoqueembalagem,
       v.pendenciaembalagem, v.adicionarembalagem, v.disponivelembalagem,
       v.dtentrada, v.dtvencimento vencimento, v.codproduto codigointerno,
       v.produto, v.coddepositante coddepositante, v.depositante, v.setor,
       v.fatorconversao fatorlote, v.tipolocal, v.estado, v.loteliberado,
       v.dtbloqueio databloqueio, v.motivobloqueio, v.usuariobloqueio,
       v.loteindustria, v.idlotenf, v.regiao, v.localativo localativo,
       v.barra barra_lote, v.embalagem embalagemlote, v.h$idarmazem,
       v.idproduto h$idproduto
  from vt_estoquelocalporlote v
 where 1 = 1
   and not exists (select 1
          from estoqueinformacaoespecifica e
         where e.idlote = v.idlote)


/

