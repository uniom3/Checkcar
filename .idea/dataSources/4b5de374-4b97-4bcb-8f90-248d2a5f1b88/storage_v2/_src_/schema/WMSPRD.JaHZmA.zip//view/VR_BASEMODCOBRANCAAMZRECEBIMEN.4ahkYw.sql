create view VR_BASEMODCOBRANCAAMZRECEBIMEN as
select 'RECEBIMENTO' operacao, p.idproduto, p.descr,
       round((emb.comprimento / 10), 2) comprimentocm,
       round((emb.largura / 10), 2) larguracm,
       round((emb.altura / 10), 2) alturacm,
       round((emb.largura * emb.altura * emb.comprimento / 1000), 2) volumecm3,
       round((emb.pesobruto / 1000), 2) pesobrutokg,
       round((emb.pesoliquido / 1000), 2) pesoliquidokg, ma.dataalocacao data,
       sum(lt.qtdeentrada) qtde
  from mapaalocacao ma, orlote ol, lotenf lnf, lote lt, produto p,
       embalagem emb
 where ma.status = 'F'
   and ol.idlote = ma.idlote
   and lnf.idlotenf = ol.idlotenf
   and lt.idlote = ol.idlote
   and p.idproduto = lt.idproduto
   and emb.idproduto = p.idproduto
   and emb.barra = lt.barra
 group by 'RECEBIMENTO', p.idproduto, p.descr,
          round((emb.comprimento / 10), 2), round((emb.largura / 10), 2),
          round((emb.altura / 10), 2),
          round((emb.largura * emb.altura * emb.comprimento / 1000), 2),
          round((emb.pesobruto / 1000), 2),
          round((emb.pesoliquido / 1000), 2), ma.dataalocacao
/

