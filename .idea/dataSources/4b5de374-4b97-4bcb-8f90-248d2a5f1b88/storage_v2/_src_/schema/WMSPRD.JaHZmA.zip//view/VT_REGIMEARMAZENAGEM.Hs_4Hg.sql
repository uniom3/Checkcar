create view VT_REGIMEARMAZENAGEM as
select idregime, descr, classificacao, contribuinteicms
  from regime
/

