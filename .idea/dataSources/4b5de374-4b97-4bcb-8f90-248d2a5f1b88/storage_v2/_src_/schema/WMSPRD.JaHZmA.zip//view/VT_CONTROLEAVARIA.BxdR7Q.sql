create view VT_CONTROLEAVARIA as
select c.idcontroleavaria, to_char(c.dataavaria, 'dd/mm/yyyy') dtavaria,
       decode(c.estado, 'D', 'DANIFICADO', 'T', 'VENCIDO/TRUNCADO') estado,
       u.nomeusuario usuarioqueavariou, m.descr motivoavaria,
       c.motivo observacao, c.idlocalorigem localorigem,
       lo.idlocalformatado f$localorigem, c.idlocaldestino localdestino,
       ld.idlocalformatado f$localdestino, r.idremanejamento remanejamento,
       c.dataprocessamento dtprocessamento,
       decode(c.finalizado, 'S', 'FINALIZADO', 'PENDENTE') status,
       c.finalizado h$status, c.estado h$estado,
       c.idarmazemorigem h$idarmazem, m.idmotivo h$idmotivo,
       lo.ordem h$ordemorigem, ld.ordem h$ordemdestino
  from controleavaria c, usuario u, motivo m, remanejamento r, local lo,
       local ld
 where u.idusuario = c.idusuario
   and m.idmotivo(+) = c.idmotivo
   and r.idcontroleavaria(+) = c.idcontroleavaria
   and lo.idlocal = c.idlocalorigem
   and lo.idarmazem = c.idarmazemorigem
   and ld.idlocal = c.idlocaldestino
   and ld.idarmazem = c.idarmazemdestino
/

