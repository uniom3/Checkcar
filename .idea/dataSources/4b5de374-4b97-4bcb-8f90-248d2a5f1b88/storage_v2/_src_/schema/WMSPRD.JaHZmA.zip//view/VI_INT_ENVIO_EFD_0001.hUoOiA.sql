create view VI_INT_ENVIO_EFD_0001 as
select '0001' reg, 0 ind_mov
  from dual
/

