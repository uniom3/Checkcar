create view V_ARMAZEM3D_PRODUTOS as
select lo.idarmazem || nvl(lo.bloco, '01') || lo.idlocal CD_ENDERECO,
       sum(ll.estoque / e.fatorconversao) QT_ESTOQUE,
       sum(ll.pendencia / e.fatorconversao) QT_RESERVA_SAIDA,
       sum(ll.adicionar / e.fatorconversao) QT_TRANSITO_ENTRADA,
       ll.idarmazem ID, lo.idlocalformatado CD_ENDERECO_FORMATADO,
       p.descr DS_PRODUTO, pd.codigointerno CD_PRODUTO, e.barra,
       d.razaosocial depositante
  from lotelocal ll, local lo, lote l, produto p, produtodepositante pd,
       embalagem e, entidade d
 where ll.estoque + ll.adicionar + ll.pendencia > 0
   and lo.id = ll.idendereco
   and l.idlote = ll.idlote
   and l.idarmazem = ll.idarmazem
   and l.tipolote = 'L'
   and p.idproduto = l.idproduto
   and pd.idproduto = l.idproduto
   and pd.identidade = l.iddepositante
   and e.idproduto = l.idproduto
   and e.barra = nvl(pd.embalagemestoque, l.barra)
   and d.identidade = l.iddepositante
 group by lo.idarmazem || nvl(lo.bloco, '01') || lo.idlocal, l.idproduto,
          l.barra, l.iddepositante, ll.idarmazem, lo.idlocalformatado,
          p.descr, pd.codigointerno, e.barra, d.razaosocial
 order by p.descr
/

