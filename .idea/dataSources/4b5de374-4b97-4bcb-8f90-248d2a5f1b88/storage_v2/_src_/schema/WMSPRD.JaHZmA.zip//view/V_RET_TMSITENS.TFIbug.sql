create view V_RET_TMSITENS as
select nd.nf idnotafiscal,
       pr.codigointerno,
       pr.descr nome_descr_prod,
       em.descrreduzido tipoembalagem, nvl(nd.qtdeatendida,0) qtde,
       nd.precounitliquido, nd.precounitliquido*nd.qtdeatendida total_item,
       nd.pesobruto, nd.pesoliquido
  from nfdet nd, produto pr, embalagem em
 where em.idproduto = nd.idproduto
   and em.barra = nd.barra
   and pr.idproduto = nd.idproduto
/

