create view VI_INT_OR_H as
select nroor "OR", ANO, MES, DIA, HORA, CNPJ, CODTRANSP, CLASSIFICACAO,
       PLACA, MOTORISTA, QTDEVOLUME, PESO, TIPORECEBIMENTO, INFOCOMPLEMENTAR,
       ID, '*' F, idreplicacao
  from int_envio_or_h o
/

