create view VT_SETORDEPOSITANTE as
select decode(sd.idsetor, null, 0, 1) marcado,
       s.codigointerno coddepositante, cgc, cic, s.inscrestadual, s.pessoa,
       s.razaosocial, s.fantasia, s.ativo, sd.codintegracao, s.idsetor,
       s.identidade iddepositante,
       s.integrardepositoerpsenior h$integrardepositoerpsenior
  from (select s.idsetor, e.identidade, e.codigointerno, cgc, cic,
                e.inscrestadual, e.pessoa, e.razaosocial, e.fantasia, e.ativo,
                d.integrardepositoerpsenior
           from setor s, depositante d, entidade e
          where e.identidade = d.identidade) s, setordepositante sd
 where sd.iddepositante(+) = s.identidade
   and sd.idsetor(+) = s.idsetor
/

