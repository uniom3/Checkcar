create view VR_LIVROREGISTROSAIDAPORICMS as
select lv.idlivrofiscal, 
initcap(e.razaosocial) firma, e.inscrestadual,
       e.cgc cnpj, lv.numero numerolivro, lv.ultimapagina, lv.dtgeracao,
       lv.datainicio || ' a ' || lv.datatermino periodo, il.aliquotaicms,
       sum(il.basecalculoicms) basecalculoicms, sum(il.impostoicms) impostoicms, il.dtsaida
  from livrofiscal lv, itemlivrofiscalsaida il, entidade e
 where il.idlivrofiscal = lv.idlivrofiscal
   and e.identidade = lv.identidade
   group by lv.idlivrofiscal, e.razaosocial,  e.inscrestadual, lv.numero, lv.ultimapagina, lv.dtgeracao, e.cgc,
       lv.datainicio || ' a ' || lv.datatermino, il.aliquotaicms, il.dtsaida
/

