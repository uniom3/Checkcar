create view VI_INT_ENVRETARMMOVSAIPTO as
select agrupador id, idprenf, destinatariocnpj, serie, numero,
       to_char(dataemissao, 'DDMMYY') dataemissao, cfop,
       trim(to_char(nvl(valmercadorias, 0), '9999999990.0000')) valmercadorias,
       trim(to_char(nvl(valicms, 0), '9999999990.0000')) valicms,
       trim(to_char(nvl(valtotal, 0), '9999999990.0000')) valtotal,
       cnpjemitente, clfiscal, destinatarioie, transpnome, transpuf,
       transpcnpj, transpend, transpcidade, transpie,
       trim(to_char(nvl(nrovolume, 0), '9999990.00')) nrovolume, especie,
       marca, trim(to_char(nvl(pesobruto, 0), '9999999990')) pesobruto,
       trim(to_char(nvl(pesoliquido, 0), '9999999990')) pesoliquido,
       chavenfe,
       replace(replace(observacao, chr(10), ' '), chr(13), ' ') observacao,
       clientepessoa, clientecnpj, clientenome, clientetipo,
       clientenomereduzido, clienteend, clientecomplem, clientebairro,
       clientecep, clienteuf, clientecod_mun, clienteddd, clientetel,
       clienteie, clientesegmento,
       trim(to_char(nvl(baseicms, 0), '9999999990.0000')) baseicms,
       trim(to_char(nvl(isentasicms, 0), '9999999990.0000')) isentasicms,
       trim(to_char(nvl(outrasicms, 0), '9999999990.0000')) outrasicms,
       trim(to_char(nvl(baseicmssubstituido, 0), '9999999990.0000')) baseicmssubstituido,
       trim(to_char(nvl(icmssubstituido, 0), '9999999990.0000')) icmssubstituido,
       trim(to_char(nvl(pis, 0), '9999999990.0000')) pis,
       trim(to_char(nvl(cofins, 0), '9999999990.0000')) cofins
  from int_envio_zz_nfsaida
/

