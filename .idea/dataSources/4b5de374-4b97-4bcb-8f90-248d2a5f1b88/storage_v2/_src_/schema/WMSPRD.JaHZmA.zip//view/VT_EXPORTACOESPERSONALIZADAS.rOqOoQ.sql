create view VT_EXPORTACOESPERSONALIZADAS as
select conf.idconfigexppersonalizada, conf.descricao descrExportacao,
       conf.nomenclatura, conf.extensaoarq,
       decode(conf.tipoformatacaoarquivo, 0, 'Excel (.xlsx)', 1,
               'Separado por Vírgula(' || ',' || ') .csv', 2,
               'Separado por Ponto e Vírgula(' || '' || ') .scsv', 3,
               'Separado por Pipes(' || '|' || ') .psv', 4,
               'Separado por Tabulações (tsv)', 5, 'Acrobat (pdf)', 6,
               'Xml (xml)') tipoformatacaoarquivo, conf.ativo,
       s.nome consultaDinamica,
       case
          when ts.id is not null then
           lpad(ts.horaexecucao, 2, '0') || ':' ||
           lpad(ts.minutoexecucao, 2, '0')
          when tm.id is not null then
           lpad(tm.horaexecucao, 2, '0') || ':' ||
           lpad(tm.minutoexecucao, 2, '0')
          when td.id is not null then
           lpad(td.horaexecucao, 2, '0') || ':' ||
           lpad(td.minutoexecucao, 2, '0')
          else
           null
        end horaminutoexecucao,
       decode(conf.tipoperiodicidade, 0, 'Diário', 1, 'Semanal', 2, 'Mensal',
               3, 'Tempo em Tempo') tipoperiodicidade,
       case
          when ts.id is not null then
           decode(ts.diasemana, 0, 'Domingo', 1, 'Segunda-feira', 2,
                  'Terça-feira', 3, 'Quarta-feira', 4, 'Quinta-feira', 5,
                  'Sexta-feira')
          when tm.id is not null then
           decode(tm.diames, 0, 'Último dia do mês', to_char(tm.diames))
          when tp.id is not null then
           lpad(tp.tempohora, 2, '0') || ':' || lpad(tp.tempominuto, 2, '0')
          else
           null
        end periodicidade, conf.idConsultaDinamica idconsultaDinamica,
       conf.idconfiguracaointegracao
  from configexportacaopersonalizada conf, sql s, Triggerdiaria td,
       triggersemanal ts, triggermensal tm, triggertempoemtempo tp
 where s.id = conf.idconsultaDinamica
   and td.tsunamijob(+) = conf.tsunamijob
   and ts.tsunamijob(+) = conf.tsunamijob
   and tm.tsunamijob(+) = conf.tsunamijob
   and tp.tsunamijob(+) = conf.tsunamijob
/

