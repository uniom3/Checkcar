create view V_ENTRADA_MAIOR_MOV_DET as
select lnf.idtiporecebimento,
       to_char(nf.dataprocessamento, 'mm/yyyy') mesmov,
       sum(nfd.qtde * e.fatorconversao) qtdetotal,
       count(distinct nf.idnotafiscal) totalnf
  from notafiscal nf, lotenf lnf, nfdet nfd, embalagem e
 where nf.tipo = 'E'
   and lnf.idlotenf = nf.idlotenf
   and lnf.status = 'P'
   and nfd.nf = nf.idnotafiscal
   and e.idproduto = nfd.idproduto
   and e.barra = nfd.barra
 group by lnf.idtiporecebimento, to_char(nf.dataprocessamento, 'mm/yyyy')


/

