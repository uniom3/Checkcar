create TYPE BODY T_PRENFDET IS
  MEMBER PROCEDURE INITIALIZE
  (
    P_IDPRENF                  NUMBER,
    P_IDSEQ                    NUMBER,
    P_CODIGOINDUSTRIA          VARCHAR2,
    P_DESCR_PROD               VARCHAR2,
    P_BARRA                    VARCHAR2,
    P_APRESENTACAO             VARCHAR2,
    P_CLASSIFICACAOFISCAL      VARCHAR2,
    P_ST                       CHAR,
    P_QTDE                     NUMBER,
    P_VLRUNITBRUTO             NUMBER,
    P_VLRUNIT                  NUMBER,
    P_VLRTOTAL                 NUMBER,
    P_ALIQICMS                 NUMBER,
    P_ALIQIPI                  NUMBER,
    P_IPI                      NUMBER,
    P_VLRDESC                  NUMBER,
    P_QTDEBONIFIC              NUMBER,
    P_BASEICMS                 NUMBER,
    P_VALORICMS                NUMBER,
    P_BASEICMSSUBST            NUMBER,
    P_ICMSSUBST                NUMBER,
    P_FRETE                    NUMBER,
    P_SEGURO                   NUMBER,
    P_DESPESAACESSORIA         NUMBER,
    P_PIS                      NUMBER,
    P_COFINS                   NUMBER,
    P_PORCDESCONTO             NUMBER,
    P_DESCONTO                 NUMBER,
    P_TOTALLIQUIDO             NUMBER,
    P_DATANOTA                 DATE,
    P_PESOBRUTO                NUMBER,
    P_PESOLIQUIDO              NUMBER,
    P_STATUS                   CHAR,
    P_UNIDADE                  VARCHAR2,
    P_CFOP                     VARCHAR2,
    P_NFNUMFORMULARIO          VARCHAR2,
    P_TIPONF                   VARCHAR2,
    P_DESCRTIPONF              VARCHAR2,
    P_SOMAVALORTIPONF          CHAR,
    P_SERIE                    VARCHAR2,
    P_TIPOMATERIAL             NUMBER,
    P_IDUSUARIO                NUMBER,
    P_ST2                      CHAR,
    P_IDNFDET                  NUMBER,
    P_IDPEDIDOVENDA            NUMBER,
    P_CHAVEIDENTIFICACAOEXT    VARCHAR2,
    P_NCM                      VARCHAR2,
    P_CEST                     VARCHAR2,
    P_EX_TIPI                  VARCHAR2,
    P_GENERO                   NUMBER,
    P_CLASSEIPI                VARCHAR2,
    P_CODSELOIPI               VARCHAR2,
    P_QTDESELOIPI              NUMBER,
    P_CODIGOIPI                VARCHAR2,
    P_CODIGOLISTASERVICO       NUMBER,
    P_CFOPPROD                 NUMBER,
    P_ORIGEMPRODUTO            NUMBER,
    P_MODALIDADEBCICMS         NUMBER,
    P_REDUCAOICMS              NUMBER,
    P_MVAICMSST                NUMBER,
    P_BCICMSST                 NUMBER,
    P_REDUCAOICMSST            NUMBER,
    P_CSTIPI                   VARCHAR2,
    P_BCIPI                    NUMBER,
    P_CSTPIS                   NUMBER,
    P_BCPIS                    NUMBER,
    P_ALIQPIS                  NUMBER,
    P_CSTCOFINS                NUMBER,
    P_BCCOFINS                 NUMBER,
    P_ALIQCOFINS               NUMBER,
    P_VALORBCII                NUMBER,
    P_VALORDESPADUANEIRAS      NUMBER,
    P_VALORII                  NUMBER,
    P_VALORIIOPERFINANCEIRAS   NUMBER,
    P_DIPRODUTO                NUMBER,
    P_MODALIDADEBCICMSST       NUMBER,
    P_ALIQICMSST               NUMBER,
    P_INFADICIONALPROD         VARCHAR2,
    P_ICMSST                   NUMBER,
    P_IDNFDETI                 NUMBER,
    P_DESCRREDUZIDO            CHAR,
    P_NUMEROORDEMCOMPRA        VARCHAR2,
    P_MOVESTOQUE               CHAR,
    P_DTVENCIMENTOLOTE         DATE,
    P_NUMEROORDEMTRANSFERENCIA VARCHAR2,
    P_QTDEATENDIDA             NUMBER,
    P_VALORICMSDESONERADO      NUMBER,
    P_CODIGOPRODANVISA         VARCHAR2,
    P_PRECOMAXIMOCONSUMIDOR    NUMBER,
    P_REMESSA                  VARCHAR2,
    P_NOTAFISCAL               VARCHAR2,
    P_SERIENF                  VARCHAR2,
    P_TIPOPTL                  VARCHAR2,
    P_TIPOCAIXASEP             VARCHAR2,
    P_VOLUMECAIXA              NUMBER,
    P_MENSAGEM_CAIXA           VARCHAR2,
    P_CODSETOR                 VARCHAR2,
    P_MOTIVOISENCAO            VARCHAR2,
    P_BASECALCULORETIDOPORST   NUMBER,
    P_PERCENTUALFCPRETIDOPORST NUMBER,
    P_VALORFCPRETIDOPORST      NUMBER,
    P_OBSITEMSEPARACAO         VARCHAR2,
	P_CODIGOBENEFICIOFISCAL    VARCHAR2,
    P_MOTIVODESONERACAOICMS    NUMBER
  ) IS
  BEGIN
    IDPRENF                  := P_IDPRENF;
    IDSEQ                    := P_IDSEQ;
    CODIGOINDUSTRIA          := P_CODIGOINDUSTRIA;
    DESCR_PROD               := P_DESCR_PROD;
    BARRA                    := P_BARRA;
    APRESENTACAO             := P_APRESENTACAO;
    CLASSIFICACAOFISCAL      := P_CLASSIFICACAOFISCAL;
    ST                       := P_ST;
    QTDE                     := P_QTDE;
    VLRUNITBRUTO             := P_VLRUNITBRUTO;
    VLRUNIT                  := P_VLRUNIT;
    VLRTOTAL                 := P_VLRTOTAL;
    ALIQICMS                 := P_ALIQICMS;
    ALIQIPI                  := P_ALIQIPI;
    IPI                      := P_IPI;
    VLRDESC                  := P_VLRDESC;
    QTDEBONIFIC              := P_QTDEBONIFIC;
    BASEICMS                 := P_BASEICMS;
    VALORICMS                := P_VALORICMS;
    BASEICMSSUBST            := P_BASEICMSSUBST;
    ICMSSUBST                := P_ICMSSUBST;
    FRETE                    := P_FRETE;
    SEGURO                   := P_SEGURO;
    DESPESAACESSORIA         := P_DESPESAACESSORIA;
    PIS                      := P_PIS;
    COFINS                   := P_COFINS;
    PORCDESCONTO             := P_PORCDESCONTO;
    DESCONTO                 := P_DESCONTO;
    TOTALLIQUIDO             := P_TOTALLIQUIDO;
    DATANOTA                 := P_DATANOTA;
    PESOBRUTO                := P_PESOBRUTO;
    PESOLIQUIDO              := P_PESOLIQUIDO;
    STATUS                   := P_STATUS;
    UNIDADE                  := P_UNIDADE;
    CFOP                     := P_CFOP;
    NFNUMFORMULARIO          := P_NFNUMFORMULARIO;
    TIPONF                   := P_TIPONF;
    DESCRTIPONF              := P_DESCRTIPONF;
    SOMAVALORTIPONF          := P_SOMAVALORTIPONF;
    SERIE                    := P_SERIE;
    TIPOMATERIAL             := P_TIPOMATERIAL;
    IDUSUARIO                := P_IDUSUARIO;
    ST2                      := P_ST2;
    IDNFDET                  := P_IDNFDET;
    IDPEDIDOVENDA            := P_IDPEDIDOVENDA;
    CHAVEIDENTIFICACAOEXT    := P_CHAVEIDENTIFICACAOEXT;
    NCM                      := P_NCM;
    CEST                     := P_CEST;
    EX_TIPI                  := P_EX_TIPI;
    GENERO                   := P_GENERO;
    CLASSEIPI                := P_CLASSEIPI;
    CODSELOIPI               := P_CODSELOIPI;
    QTDESELOIPI              := P_QTDESELOIPI;
    CODIGOIPI                := P_CODIGOIPI;
    CODIGOLISTASERVICO       := P_CODIGOLISTASERVICO;
    CFOPPROD                 := P_CFOPPROD;
    ORIGEMPRODUTO            := P_ORIGEMPRODUTO;
    MODALIDADEBCICMS         := P_MODALIDADEBCICMS;
    REDUCAOICMS              := P_REDUCAOICMS;
    MVAICMSST                := P_MVAICMSST;
    BCICMSST                 := P_BCICMSST;
    REDUCAOICMSST            := P_REDUCAOICMSST;
    CSTIPI                   := P_CSTIPI;
    BCIPI                    := P_BCIPI;
    CSTPIS                   := P_CSTPIS;
    BCPIS                    := P_BCPIS;
    ALIQPIS                  := P_ALIQPIS;
    CSTCOFINS                := P_CSTCOFINS;
    BCCOFINS                 := P_BCCOFINS;
    ALIQCOFINS               := P_ALIQCOFINS;
    VALORBCII                := P_VALORBCII;
    VALORDESPADUANEIRAS      := P_VALORDESPADUANEIRAS;
    VALORII                  := P_VALORII;
    VALORIIOPERFINANCEIRAS   := P_VALORIIOPERFINANCEIRAS;
    DIPRODUTO                := P_DIPRODUTO;
    MODALIDADEBCICMSST       := P_MODALIDADEBCICMSST;
    ALIQICMSST               := P_ALIQICMSST;
    INFADICIONALPROD         := P_INFADICIONALPROD;
    ICMSST                   := P_ICMSST;
    IDNFDETI                 := P_IDNFDETI;
    DESCRREDUZIDO            := P_DESCRREDUZIDO;
    NUMEROORDEMCOMPRA        := P_NUMEROORDEMCOMPRA;
    MOVESTOQUE               := P_MOVESTOQUE;
    DTVENCIMENTOLOTE         := P_DTVENCIMENTOLOTE;
    NUMEROORDEMTRANSFERENCIA := P_NUMEROORDEMTRANSFERENCIA;
    QTDEATENDIDA             := P_QTDEATENDIDA;
    VALORICMSDESONERADO      := P_VALORICMSDESONERADO;
    CODIGOPRODANVISA         := P_CODIGOPRODANVISA;
    PRECOMAXIMOCONSUMIDOR    := P_PRECOMAXIMOCONSUMIDOR;
    REMESSA                  := P_REMESSA;
    NOTAFISCAL               := P_NOTAFISCAL;
    SERIENF                  := P_SERIENF;
    TIPOPTL                  := P_TIPOPTL;
    TIPOCAIXASEP             := P_TIPOCAIXASEP;
    VOLUMECAIXA              := P_VOLUMECAIXA;
    MENSAGEM_CAIXA           := P_MENSAGEM_CAIXA;
    CODSETOR                 := P_CODSETOR;
    MOTIVOISENCAO            := P_MOTIVOISENCAO;
    BASECALCULORETIDOPORST   := P_BASECALCULORETIDOPORST;
    PERCENTUALFCPRETIDOPORST := P_PERCENTUALFCPRETIDOPORST;
    VALORFCPRETIDOPORST      := P_VALORFCPRETIDOPORST;
    OBSITEMSEPARACAO         := P_OBSITEMSEPARACAO;
    CODIGOBENEFICIOFISCAL    := P_CODIGOBENEFICIOFISCAL;
    MOTIVODESONERACAOICMS    := P_MOTIVODESONERACAOICMS;
  END;
END;
/

