create package body pk_usuario is
  e_modulonaopermitido exception;

  C_USUARIO_DADOSACEITOS      constant number := 0;
  C_USUARIO_DADOSINCORRETOS   constant number := 1;
  C_USUARIO_USUARIOINATIVO    constant number := 2;
  C_USUARIO_TENTATIVASMAXIMAS constant number := 3;
  C_USUARIO_SENHATEMPORARIA   constant number := 4;
  C_USUARIO_SENHAEXPIRADA     constant number := 5;
  C_USUARIO_MODULONAOPERMIT   constant number := 6;
  C_USUARIO_LOGIN_VIA_AD      constant number := 7;
  C_USUARIO_LOGIN_VIA_PLAT_G7 constant number := 10;

  procedure atribuirPermissao
  (
    p_idinterface in number,
    p_idgrupo     in number
  ) is
  begin
  
    insert into restricaointerface
      (idinterface, idgrupo, consulta, adiciona, atualiza, exclui, geralog,
       botoes)
    values
      (p_idinterface, p_idgrupo, 'S', 'N', 'N', 'N', 'S', 'N');
  exception
    when dup_val_on_index then
      update restricaointerface
         set consulta = 'S'
       where idinterface = p_idinterface
         and idgrupo = p_idgrupo;
  end;

  procedure retirarPermissao
  (
    p_idinterface in number,
    p_idgrupo     in number
  ) is
  begin
    delete from restricaointerface
     where idinterface = p_idinterface
       and idgrupo = p_idgrupo;
  end;

  procedure removerUsuarioDoGrupo
  (
    p_idgrupo   in grupousuario.idgrupo%type,
    p_idusuario in grupousuario.idusuario%type
  ) is
  begin
    delete grupousuario
     where idgrupo = p_idgrupo
       and idusuario = p_idusuario;
  end removerUsuarioDoGrupo;

  procedure inserirUsuarioNoGrupo
  (
    p_idgrupo   in grupousuario.idgrupo%type,
    p_idusuario in grupousuario.idusuario%type
  ) is
  begin
    insert into grupousuario
      (idgrupo, idusuario)
    values
      (p_idgrupo, p_idusuario);
  end inserirUsuarioNoGrupo;

  function getUsuario(p_idusuario in number) return varchar2 is
    v_usuario usuario.nomeusuario%type;
  begin
    select nomeusuario
      into v_usuario
      from usuario
     where idusuario = p_idusuario;
  
    return v_usuario;
  end;

  procedure vincularTipoAtividade
  (
    p_idgrupo         in number,
    p_idtipoatividade in number
  ) is
    v_msg t_message;
  
  begin
  
    insert into tipoatividadegrupo
      (idtipoatividade, idgrupo)
    values
      (p_idtipoatividade, p_idgrupo);
  
  exception
    when others then
      v_msg := t_message('OCORREU UM ERRO AO TENTAR VINCULAR A ATIVIDADE: {0} AO GRUPO: {1}');
      v_msg.addParam(p_idtipoatividade);
      v_msg.addParam(p_idgrupo);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  procedure desvincularTipoAtividade
  (
    p_idgrupo         in number,
    p_idtipoatividade in number
  ) is
    v_msg t_message;
  
  begin
  
    delete from tipoatividadegrupo
     where idtipoatividade = p_idtipoatividade
       and idgrupo = p_idgrupo;
  
  exception
    when others then
      v_msg := t_message('OCORREU UM ERRO AO TENTAR DESVINCULAR A ATIVIDADE: {0} DO GRUPO: {1}');
      v_msg.addParam(p_idtipoatividade);
      v_msg.addParam(p_idgrupo);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  procedure validarAcessoModulo
  (
    p_idUsuario   in number,
    p_nomeUsuario in varchar2,
    p_modulo      in varchar2,
    p_tipoLogin   in number
  ) is
    v_acesso number;
    v_msg    t_message;
  begin
    select count(1)
      into v_acesso
      from restricaointerface ri
     where ri.idgrupo in (select gu.idgrupo
                            from grupousuario gu
                           where gu.idusuario = p_idusuario)
       and exists (select 1
              from interface i
             where i.modulo = p_modulo
               and i.idinterface = ri.idinterface);
  
    if (v_acesso = 0) then
      if (p_tipoLogin not in
         (C_USUARIO_LOGIN_VIA_AD, C_USUARIO_LOGIN_VIA_PLAT_G7)) then
        raise e_modulonaopermitido;
      end if;
    
      v_msg := t_message('O usuário {0} não possui acesso ao módulo ' || case
                           when p_modulo = 'C' then
                            'Coletor de Dados'
                           when p_modulo = 'W' then
                            'WMS Web'
                           when p_modulo = 'A' then
                            'Operação de Depósito'
                           when p_modulo = 'E' then
                            'SiltWMS Enterprise'
                           else
                            'Sistema'
                         end || '.');
      v_msg.addParam(p_nomeUsuario);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarAcessoModulo;

  function doLogin
  (
    p_usuario in varchar2,
    p_senha   in varchar2,
    p_modulo  in varchar2
  ) return number is
    e_usuarioDadoIncorretos   exception;
    e_usuarioInativo          exception;
    e_tentativaMaximaAtingida exception;
    e_senhaTemporaria         exception;
    e_senhaExpirada           exception;
    e_login_via_ad            exception;
    e_login_via_plataforma_g7 exception;
  
    r_user              usuario%rowtype;
    r_configuracaoGeral configuracao%rowtype;
  
    procedure getConfiguracaoGeral is
    begin
      select *
        into r_configuracaoGeral
        from configuracao c
       where c.ativo = 'S'
         and rownum = 1;
    end getConfiguracaoGeral;
  
    procedure getUsuario is
    begin
      select *
        into r_user
        from usuario u
       where u.nomeusuario = upper(p_usuario);
    exception
      when no_data_found then
        raise e_usuarioDadoIncorretos;
    end getUsuario;
  
    procedure validarSenha is
      v_controleAcesso controleacesso%rowtype;
    
      procedure limparTentativasAnteriores is
      begin
      
        v_controleAcesso.qtderrologin := 0;
        --        v_controleAcesso.codigoredefinirsenha := null;
      
        update controleAcesso
           set row = v_controleAcesso
         where idusuario = r_user.idusuario;
      
      end limparTentativasAnteriores;
    
      procedure controlaTentativasAcesso is
      begin
        begin
          select *
            into v_controleAcesso
            from controleacesso
           where idusuario = r_user.idusuario;
        exception
          when no_data_found then
            select seq_controleAcesso.nextval
              into v_controleAcesso.id
              from dual;
          
            v_controleAcesso.idusuario := r_user.idusuario;
          
            insert into controleacesso
            values v_controleAcesso;
        end;
      
        v_controleAcesso.dtUltimaTentativaLogin := sysdate;
      
        if ((r_user.senha <> p_senha) and (r_user.ativo = 'S')) then
        
          if ((r_configuracaoGeral.Qtdetentativaslogin > 0) and
             ((v_controleAcesso.qtderrologin + 1) >=
             r_configuracaoGeral.Qtdetentativaslogin)) then
          
            if (r_user.ativo = 'S') then
              r_user.ativo := 'N';
            
              update usuario
                 set row = r_user
               where idusuario = r_user.idusuario;
            end if;
          
            raise e_tentativaMaximaAtingida;
          end if;
        
          v_controleAcesso.qtderrologin := nvl(v_controleAcesso.qtderrologin,
                                               0) + 1;
        
          update controleAcesso
             set row = v_controleAcesso
           where idusuario = r_user.idusuario;
        
          raise e_usuarioDadoIncorretos;
        end if;
      
        limparTentativasAnteriores();
      end;
    
    begin
      controlaTentativasAcesso();
    
      if ((r_user.ativo = 'N') and (r_user.senha <> p_senha)) then
        raise e_usuarioDadoIncorretos;
      end if;
    
      if (r_user.ativo = 'N') then
        raise e_usuarioInativo;
      end if;
    
      if (r_user.senhatmp = 1) then
        raise e_senhaTemporaria;
      end if;
    
      if (r_user.data_prox_alteracao <= sysdate) then
        raise e_senhaExpirada;
      end if;
    
      limparTentativasAnteriores;
      --atualizarDadosRefLogin;
    end validarSenha;
  
    procedure validarMetodoAutenticacao is
    begin
      if (r_configuracaoGeral.utzservidorldap = 1 and r_user.utzloginad = 1) then
        raise e_login_via_ad;
      end if;
    
      if (r_configuracaoGeral.utzplataformag7 = 1 and r_user.utzloging7 = 1) then
        raise e_login_via_plataforma_g7;
      end if;
    end validarMetodoAutenticacao;
  
  begin
    getConfiguracaoGeral;
    getUsuario;
    validarMetodoAutenticacao;
    validarSenha;
    validarAcessoModulo(r_user.idusuario, r_user.nomeusuario, p_modulo, 0);
  
    return(C_USUARIO_DADOSACEITOS);
  exception
    when e_usuarioDadoIncorretos then
      return(C_USUARIO_DADOSINCORRETOS);
    when e_usuarioInativo then
      return(C_USUARIO_USUARIOINATIVO);
    when e_tentativaMaximaAtingida then
      return(C_USUARIO_TENTATIVASMAXIMAS);
    when e_senhaTemporaria then
      return(C_USUARIO_SENHATEMPORARIA);
    when e_senhaExpirada then
      return(C_USUARIO_SENHAEXPIRADA);
    when e_modulonaopermitido then
      return(C_USUARIO_MODULONAOPERMIT);
    when e_login_via_ad then
      return(C_USUARIO_LOGIN_VIA_AD);
    when e_login_via_plataforma_g7 then
      return(C_USUARIO_LOGIN_VIA_PLAT_G7);
  end doLogin;

  procedure gravarHistAlteracaoSenha
  (
    p_idusuarioalteracao in usuario.idusuario%type,
    p_idusuarioalterado  in usuario.idusuario%type,
    p_novasenha          in usuario.senha%type
  ) is
  begin
    insert into historicosenhausuario
      (id, idusuarioalteracao, idusuarioalterado, senha, data)
    values
      (seq_historicosenhausuario.nextval, p_idusuarioalteracao,
       p_idusuarioalterado, p_novasenha, sysdate);
  end;

  procedure validarRegrasSenha
  (
    p_idusuarioalterado in usuario.idusuario%type,
    p_novaSenhaCript    in usuario.senha%type,
    p_novaSenha         in usuario.senha%type
  ) is
    r_configuracao configuracao%rowtype;
    v_msg          t_message;
  
    procedure getConfiguracao is
    begin
      begin
        select *
          into r_configuracao
          from configuracao c
         where c.ativo = 'S';
      exception
        when no_data_found then
          v_msg := t_message('Configuração Geral não encontrada para validação da senha.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end getConfiguracao;
  
    procedure validarSenhaAlterada is
      v_senhaAtual usuario.senha%type;
    begin
      begin
        select u.senha
          into v_senhaAtual
          from usuario u
         where u.idusuario = p_idusuarioalterado;
      exception
        when no_data_found then
          return;
      end;
      if v_senhaAtual = p_novaSenhaCript then
        v_msg := t_message('A senha atual é igual a nova senha, por favor informe uma nova senha.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarSenhaAlterada;
  
    procedure validarSenhaUtilizada is
      v_qtdeSenhaJaUtilizada number;
      v_qtdeOutraSenha       number;
      v_dtUltimaAlteracao    date;
    begin
    
      select max(hs.data)
        into v_dtUltimaAlteracao
        from historicosenhausuario hs
       where hs.idusuarioalterado = p_idusuarioalterado
         and hs.senha = p_novaSenhaCript;
    
      if v_dtUltimaAlteracao is null then
        return;
      end if;
    
      select count(1)
        into v_qtdeSenhaJaUtilizada
        from historicosenhausuario hs
       where hs.data > v_dtUltimaAlteracao
         and hs.idusuarioalterado = p_idusuarioalterado;
    
      if v_qtdeSenhaJaUtilizada < r_configuracao.qtdesenhasreutilizar then
        v_qtdeOutraSenha := r_configuracao.qtdesenhasreutilizar -
                            v_qtdeSenhaJaUtilizada;
      
        v_msg := t_message('Esta senha só poderá ser reutilizada após definir : {0} senha(s) diferente(s).');
        v_msg.addParam(v_qtdeOutraSenha);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarSenhaUtilizada;
  
    procedure validarSenhaComplexa is
    begin
      if length(p_novaSenha) < r_configuracao.qtdemincaractsenha then
        v_msg := t_message('A nova senha deve possuir no mínimo {0} caracteres.');
        v_msg.addParam(r_configuracao.qtdemincaractsenha);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_configuracao.utilizaletraminuscula = 1 then
        if not pk_utilities.isPossuiCaratereMinusculo(p_novaSenha) then
          v_msg := t_message('A nova senha deve possuir no mínimo um caractere minúsculo.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if r_configuracao.utilizaletramaiuscula = 1 then
        if not pk_utilities.isPossuiCaratereMaiusculo(p_novaSenha) then
          v_msg := t_message('A nova senha deve possuir no mínimo um caractere maiúsculo.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if r_configuracao.utilizanumeros = 1 then
        if not pk_utilities.isPossuiNumero(p_novaSenha) then
          v_msg := t_message('A nova senha deve possuir no mínimo um caractere numérico.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if r_configuracao.utilizacaractespeciais = 1 then
        if not pk_utilities.isPossuiCaratereEspecial(p_novaSenha) then
          v_msg := t_message('A nova senha deve possuir no mínimo um caractere especial.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validarSenhaComplexa;
  begin
    getConfiguracao;
    validarSenhaAlterada;
    validarSenhaUtilizada;
    validarSenhaComplexa;
  end;

  function gerarSenha return varchar2 is
  
    v_senhaGerada usuario.senha%type;
    v_tamanho     number;
  
    v_qtdeMinCaractSenha     number;
    v_utilizaLetraMaiuscula  number;
    v_utilizaLetraMinuscula  number;
    v_utilizaNumeros         number;
    v_utilizaCaractEspeciais number;
  
    function getRandomCaractereEspecial(p_senhaGerada in usuario.senha%type)
      return usuario.senha%type is
      v_posicao number := 0;
    begin
      v_posicao := trim(to_char(dbms_random.value(1, 22), '99'));
      return p_senhaGerada || substr('!@#$%&*()_-+={}[]/\<>?', v_posicao, 1);
    
    end getRandomCaractereEspecial;
  
    function getRandomNumero(p_senhaGerada in usuario.senha%type)
      return usuario.senha%type is
    begin
      return p_senhaGerada || trim(to_char(dbms_random.value(0, 9), '9'));
    end getRandomNumero;
  
    function getRandomLetraMinuscula(p_senhaGerada in usuario.senha%type)
      return usuario.senha%type is
    begin
      return p_senhaGerada || dbms_random.string('L', 1);
    end getRandomLetraMinuscula;
  
    function getRandomLetraMaiuscula(p_senhaGerada in usuario.senha%type)
      return usuario.senha%type is
    begin
      return p_senhaGerada || dbms_random.string('U', 1);
    end getRandomLetraMaiuscula;
  
  begin
    select c.qtdemincaractsenha, c.utilizaletramaiuscula,
           c.utilizaletraminuscula, c.utilizanumeros,
           c.utilizacaractespeciais
      into v_qtdeMinCaractSenha, v_utilizaLetraMaiuscula,
           v_utilizaLetraMinuscula, v_utilizaNumeros,
           v_utilizaCaractEspeciais
      from configuracao c
     where c.ativo = 'S';
  
    v_senhaGerada := '';
    v_tamanho     := 0;
  
    while v_tamanho < v_qtdeMinCaractSenha
    loop
    
      if v_utilizaLetraMaiuscula = 1
         and v_tamanho < v_qtdeMinCaractSenha then
        v_senhaGerada := getRandomLetraMaiuscula(v_senhaGerada);
        v_tamanho     := length(v_senhaGerada);
      end if;
    
      if v_utilizaLetraMinuscula = 1
         and v_tamanho < v_qtdeMinCaractSenha then
        v_senhaGerada := getRandomLetraMinuscula(v_senhaGerada);
        v_tamanho     := length(v_senhaGerada);
      end if;
    
      if v_utilizaNumeros = 1
         and v_tamanho < v_qtdeMinCaractSenha then
        v_senhaGerada := getRandomNumero(v_senhaGerada);
        v_tamanho     := length(v_senhaGerada);
      end if;
    
      if v_utilizaCaractEspeciais = 1
         and v_tamanho < v_qtdeMinCaractSenha then
        v_senhaGerada := getRandomCaractereEspecial(v_senhaGerada);
        v_tamanho     := length(v_senhaGerada);
      end if;
    
      if ((v_utilizaLetraMaiuscula = 0) and (v_utilizaLetraMinuscula = 0) and
         (v_utilizaNumeros = 0) and (v_utilizaCaractEspeciais = 0) and
         (v_tamanho < v_qtdeMinCaractSenha)) then
        v_senhaGerada := getRandomLetraMinuscula(v_senhaGerada);
        v_tamanho     := length(v_senhaGerada);
      end if;
    
    end loop;
    return v_senhaGerada;
  end gerarSenha;

  procedure alterarSenhaCodigo
  (
    p_codigo         in usuario.codigoredefinirsenha%type,
    p_novaSenhaCript in usuario.senha%type,
    p_novaSenha      in usuario.senha%type
  ) is
    v_idusuario number;
    v_msg       t_message;
  
  begin
    begin
      select idusuario
        into v_idusuario
        from usuario u
       where u.codigoredefinirsenha = p_codigo;
    exception
      when no_data_found then
        v_msg := t_message('Codigo redefinicao senha invalido.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    alterarSenha(v_idusuario, p_novaSenhaCript, p_novaSenha);
  end;

  procedure alterarSenha
  (
    p_idusuarioalterado in usuario.idusuario%type,
    p_novaSenhaCript    in usuario.senha%type,
    p_novaSenha         in usuario.senha%type
  ) is
    r_usuario usuario%rowtype;
    v_msg     t_message;
  
  begin
    begin
      select *
        into r_usuario
        from usuario u
       where u.idusuario = p_idusuarioalterado
         for update;
    exception
      when no_data_found then
        v_msg := t_message('Usuário não encontrado.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    validarRegrasSenha(p_idusuarioalterado, p_novaSenhaCript, p_novaSenha);
    gravarHistAlteracaoSenha(p_idusuarioalterado, p_idusuarioalterado,
                             p_novaSenhaCript);
    r_usuario.senha                 := p_novaSenhaCript;
    r_usuario.codigoredefinirsenha  := null;
    r_usuario.utzsenhacasesensitive := 1;
  
    select (sysdate + nvl(c.mudarsenhaemdias, 10))
      into r_usuario.data_prox_alteracao
      from configuracao c
     where c.ativo = 'S';
  
    if (r_usuario.senhatmp = 1) then
      r_usuario.senhatmp := 0;
    end if;
  
    update usuario
       set row = r_usuario
     where idusuario = r_usuario.idusuario;
  
    update controleacesso
       set qtderrologin = 0
     where idusuario = r_usuario.idusuario;
  
  end alterarSenha;

  procedure redefinirSenhaEmail
  (
    p_idusuario         in number,
    p_codigoRecuperacao in varchar2
  ) is
    v_emailaccount  number;
    v_idactionemail number;
    v_mensagem      varchar2(2000);
    r_user          usuario%rowtype;
    C_ENVIAR_EMAIL_RECSENHA constant number := 8;
    C_TIPO_EMAIL_RECSENHA   constant number := 2;
  
  begin
    select cf.idemailaccount
      into v_emailaccount
      from configuracao cf, emailaccount ec
     where cf.ativo = 'S'
       and ec.id = cf.idemailaccount;
  
    select seq_actionemail.nextval
      into v_idactionemail
      from dual;
  
    select u.*
      into r_user
      from usuario u
     where u.idusuario = p_idusuario
       for update;
  
    r_user.codigoredefinirsenha := p_codigoRecuperacao;
  
    v_mensagem := '<h1>Redefinir Senha</h1><br/>';
    v_mensagem := v_mensagem ||
                  '<p>Conforme solicita&ccedil;&atilde;o realizada em ' ||
                  to_char(sysdate, 'dd/mm/rrrr hh24:mi:ss') ||
                  ' segue abaixo o c&oacute;digo para redefinir a senha de acesso de seu usu&aacute;rio ao sistema SiltWMS e seus M&oacute;dulos</p><br/>';
    v_mensagem := v_mensagem || '<p>Usu&aacute;rio: <strong>' ||
                  r_user.nomeusuario || '</strong><br/>';
    v_mensagem := v_mensagem ||
                  'C&oacute;digo de Redefini&ccedil;&atilde;o de Senha: <strong>' ||
                  p_codigoRecuperacao || '</strong><br/>';
    v_mensagem := v_mensagem ||
                  '<p>Aten&ccedil;&atilde;o acesse novamente a op&ccedil;&atilde;o de redefini&ccedil;&atilde;o de senha e informe o seu usu&aacute;rio e o c&oacute;digo acima para definir uma nova senha para seu usu&aacute;rio.</p><br/>';
    v_mensagem := v_mensagem ||
                  '<p>Este procedimento n&atilde;o impede o login com sua senha anterior, caso acesse o sistema ap&oacute;s a solicita&ccedil;&atilde;o de Redefini&ccedil;&atilde;o de Senha o c&oacute;digo gerado ser&aacute; descartado.</p><br/>';
  
    insert into actionemail
      (id, emailaccount, assunto, mensagem, destinatario, status,
       datacriacao, tipo)
    values
      (v_idactionemail, v_emailaccount, 'SYTHEX-WMS Redefinir Senha',
       v_mensagem, r_user.email, 0, sysdate, C_TIPO_EMAIL_RECSENHA);
  
    pk_job.JobCriarTarefa(C_ENVIAR_EMAIL_RECSENHA,
                          'idActionEmail=' || v_idactionemail, p_idusuario,
                          'Envio de Código para redefinição de senha');
    update usuario
       set row = r_user
     where idusuario = r_user.idusuario;
  end redefinirSenhaEmail;

  procedure enviarSenhaTemporariaPorEmail
  (
    p_idUsuario     in number,
    p_idUsuarioDest in number,
    p_senha         in varchar2
  ) is
    r_user usuario%rowtype;
    C_ENVIAR_EMAIL_SENHATEMPORARIA constant number := 9;
    C_TIPO_EMAIL_SENHATEMPORARIA   constant number := 3;
  
    v_msg t_message;
  
    procedure criarJobEnvioEmail
    (
      p_idUsuario in number,
      r_user      in out usuario%rowtype
    ) is
      v_emailaccount  configuracao.idemailaccount%type;
      v_idactionemail actionemail.id%type;
      v_mensagem      actionemail.mensagem%type;
    begin
      begin
        select cf.idemailaccount
          into v_emailaccount
          from configuracao cf, emailaccount ec
         where cf.ativo = 'S'
           and ec.id = cf.idemailaccount;
      exception
        when no_data_found then
          v_msg := t_message('Não há conta para envio de emails configurada no sistema.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      select seq_emailaccount.nextval
        into v_idactionemail
        from dual;
    
      v_mensagem := '<h1>Envio de Senha Tempor&aacute;ria por E-mail</h1><br/>';
      v_mensagem := v_mensagem ||
                    '<p>Conforme solicita&ccedil;&atilde;o realizada em ' ||
                    to_char(sysdate, 'dd/mm/rrrr hh24:mi:ss') ||
                    ' segue abaixo a senha tempor&aacute;ria de acesso de seu usu&aacute;rio ao sistema SiltWMS e seus M&oacute;dulos</p><br/>';
      v_mensagem := v_mensagem || '<p>Usu&aacute;rio: <strong>' ||
                    r_user.nomeusuario || '</strong><br/>';
      v_mensagem := v_mensagem || 'Senha Tempor&aacute;ria: <strong>' ||
                    p_senha || '</strong><br/>';
      v_mensagem := v_mensagem ||
                    '<h3>Lembre-se que obrigat&oacute;riamente sua senha ser&aacute; redefinida ao realizar o login.</h3><br/>';
      insert into actionemail
        (id, emailaccount, assunto, mensagem, destinatario, status,
         datacriacao, tipo)
      values
        (v_idactionemail, v_emailaccount, 'SYTHEX-WMS Senha Temporária',
         v_mensagem, r_user.email, 0, sysdate, C_TIPO_EMAIL_SENHATEMPORARIA);
    
      pk_job.JobCriarTarefa(C_ENVIAR_EMAIL_SENHATEMPORARIA,
                            'idActionEmail=' || v_idactionemail, p_idusuario,
                            'Envio de senha temporária');
    end criarJobEnvioEmail;
  
    procedure carregarEValidarUsuario
    (
      p_idUsuarioDest in number,
      r_user          in out usuario%rowtype
    ) is
    begin
      select u.*
        into r_user
        from usuario u
       where u.idusuario = p_idUsuarioDest
         for update;
    
      if (r_user.senhatmp = 0) then
        v_msg := t_message('O usuário não possui senha temporária, por este motivo não será enviado o e-mail. IDUSUARIO: {0}, NOMEUSUARIO: {1}');
        v_msg.addParam(r_user.idusuario);
        v_msg.addParam(r_user.nomeusuario);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_user.email is null OR length(r_user.email) = 0) then
        v_msg := t_message('O usuário não possui e-mail cadastrado, por este motivo não será enviado o e-mail. IDUSUARIO: {0}, NOMEUSUARIO: {1}');
        v_msg.addParam(r_user.idusuario);
        v_msg.addParam(r_user.nomeusuario);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_user.enviarsenha = 0) then
        v_msg := t_message('O usuário não está marcado para enviar a senha por e-mail, por este motivo não será enviado o e-mail. IDUSUARIO: {0}, NOMEUSUARIO: {1}');
        v_msg.addParam(r_user.idusuario);
        v_msg.addParam(r_user.nomeusuario);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end carregarEValidarUsuario;
  
  begin
    carregarEValidarUsuario(p_idUsuarioDest, r_user);
  
    criarJobEnvioEmail(p_idUsuario, r_user);
  
    r_user.enviarsenha := 0;
  
    update usuario
       set row = r_user
     where idusuario = r_user.idusuario;
  
    pk_utilities.GeraLog(0,
                         'Senha Temporária agendada para envio para o Email : ' ||
                          r_user.email, p_idUsuarioDest, 'EU');
  exception
    when others then
      pk_utilities.GeraLog(0,
                           'Ao Enviar Senha Temporária por Email ocorreu o erro: ' ||
                            Sqlerrm, p_idUsuarioDest, 'EU');
  end enviarSenhaTemporariaPorEmail;

  procedure removerUsuario
  (
    p_idUsuario         in number,
    p_idUsuarioExcluido in number
  ) is
    v_nomeUsuario usuario.nomeusuario%type;
  begin
  
    select u.nomeusuario
      into v_nomeUsuario
      from usuario u
     where u.idusuario = p_idUsuarioExcluido;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'O usuário ID: ' || p_idUsuario ||
                          ' apagou o usuário ID: ' || p_idUsuarioExcluido ||
                          ', Nome: ' || v_nomeUsuario, p_idUsuarioExcluido,
                         'EU');
  
    delete from historicosenhausuario hs
     where hs.idusuarioalterado = p_idUsuarioExcluido;
  
    delete from usuario u
     where u.idusuario = p_idUsuarioExcluido;
  end;

  procedure validarCodBarraCracha
  (
    p_idUsuario      in number,
    p_codBarraCracha in varchar2
  ) is
    v_qtdeUsuario number;
    v_msg         t_message;
  
  begin
    select count(u.idusuario)
      into v_qtdeUsuario
      from usuario u
     where u.codbarra = p_codBarraCracha
       and u.idusuario <> p_idUsuario;
  
    if (v_qtdeUsuario > 0) then
      v_msg := t_message('Já existe um usuário com este crachá: {0}');
      v_msg.addParam(p_codBarraCracha);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  function getIdUsusarioIntegracao return number is
    v_idusuariointegr usuario.idusuario%type;
    v_msg             t_message;
  begin
    begin
      select c.idusuariointegracao
        into v_idusuariointegr
        from configuracao c
       where c.ativo = 'S'
         and c.idusuariointegracao is not null;
    exception
      when no_data_found then
        v_msg := t_message('Usuário de integração padrão não preenchido' ||
                           ' nas configurações gerais do sistema.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
    return v_idusuariointegr;
  end;

end;
/

