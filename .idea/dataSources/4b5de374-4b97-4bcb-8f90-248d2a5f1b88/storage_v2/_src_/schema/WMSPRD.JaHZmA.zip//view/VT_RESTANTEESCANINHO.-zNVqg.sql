create view VT_RESTANTEESCANINHO as
select a.codigointerno, a.produto, a.qtdefalta,
       pk_produto.ret_codbarra(a.idproduto, 1) barraunitaria,
       a.idescaninho h$idescaninho, pd.loteuniconovolume h$loteuniconovolume
  from (select iddepositante, idproduto, codigointerno, produto,
                sum(qtdenf - qtdeescaninho - qtdeconf) qtdefalta, idescaninho
           from (select lt.iddepositante, lt.idproduto, p.codigointerno,
                         p.descr produto, sum(m.quantidade) qtdenf,
                         0 qtdeescaninho, 0 qtdeconf, e.idendereco idescaninho
                    from movimentacao m, escaninho e, lote lt, produto p
                   where e.idendereco = m.idlocaldestino
                     and e.idnotafiscal = m.idnotafiscal
                     and e.idromaneio = m.idonda
                     and m.status in (0, 1, 2)
                     and lt.idlote = m.idlote
                     and p.idproduto = lt.idproduto
                   group by lt.iddepositante, lt.idproduto, p.codigointerno,
                            p.descr, e.idendereco
                  union all
                  select lt.iddepositante, p.idproduto, p.codigointerno,
                         p.descr produto, 0 qtdenf,
                         sum(c.quantidade) qtdeescaninho, 0 qtdeconf,
                         c.idescaninho idescaninho
                    from conteudoescaninho c, movimentacao m, lote lt, produto p
                   where m.id = c.idmovimentacao
                     and lt.idlote = m.idlote
                     and p.idproduto = lt.idproduto
                   group by lt.iddepositante, p.idproduto, p.codigointerno,
                            p.descr, c.idescaninho
                  union all
                  select lt.iddepositante, p.idproduto, p.codigointerno,
                         p.descr produto, 0 qtdenf, 0 qtdeescaninho,
                         sum(cv.quantidade) qtdeconf,
                         m.idlocalorigem idescaninho
                    from v_conteudovolume cv, movimentacao m, lote lt, produto p,
                         escaninho e
                   where m.idvolumeromaneio = cv.idvolumeromaneio
                     and m.status in (0, 1, 2)
                     and lt.idlote = cv.idlote
                     and p.idproduto = lt.idproduto
                     and e.idendereco = m.idlocalorigem
                     and e.idnotafiscal = m.idnotafiscal
                     and e.idromaneio = m.idonda
                   group by lt.iddepositante, p.idproduto, p.codigointerno,
                            p.descr, m.idlocalorigem)
          group by iddepositante, idproduto, codigointerno, produto, idescaninho) a, produtodepositante pd
 where qtdefalta > 0
   and pd.idproduto = a.idproduto
   and pd.identidade = a.iddepositante
/

