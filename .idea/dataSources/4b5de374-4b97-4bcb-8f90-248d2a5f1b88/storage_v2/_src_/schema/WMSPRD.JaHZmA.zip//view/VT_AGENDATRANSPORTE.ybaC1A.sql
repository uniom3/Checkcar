create view VT_AGENDATRANSPORTE as
select distinct a.rowid h$tableid, a.idagenda, a.status, a.titulo,
                decode(a.tipo, 0, 'RECEBIMENTO', 'EXPEDIÇÃO') tipo,
                a.dtcadastro, a.identidade iddepositante,
                e1.codigointerno coddepositante, e1.razaosocial depositante,
                rem.razaosocial remetente, e1.cgc cnpjdepositante,
                to_char(a.dtinicioagendamento, 'DD/MM/YYYY HH24:MI') dtinicioagendamento,
                to_char(a.dtfimagendamento, 'DD/MM/YYYY HH24:MI') dtfimagendamento,
                a.numnfs, a.iddoca, a.idtransportadora,
                e2.codigointerno codtransportadora,
                e2.razaosocial transportadora, e2.cgc cnpjtransportadora,
                a.contatotransportadora, a.veiculo placaveiculo,
                decode(a.modal, 0, dep.pesagemveiculoagendtransp, 0) pesaveiculo,
                decode(a.modal, 0, 'RODOVIÁRIO', 'FERROVIÁRIO') modal,
                a.qtdevolumes, a.descvolumes, a.observacao,
                a.idtiporecebimento, tr.descr tiporecebimento, a.idturno,
                tt.descricao turnotrabalho, u1.nomeusuario usuariocadastro,
                u2.nomeusuario usuariochegada, a.dtveiculochegada,
                u3.nomeusuario usuariopatio, a.dtveiculopatio,
                u4.nomeusuario usuariodoca, a.dtveiculodoca,
                u5.nomeusuario usuariofinalizado, a.dtfinalizado,
                u6.nomeusuario usuariocancelamento, a.dtcancelamento,
                m.descr motivocancelamento, a.idarmazem h$idarmazem,
                a.status h$status,
                (case
                   when a.status not in (4, 5) then
                    1
                   else
                    0
                 end) h$pendente,
                dep.finalizaragendaautomaticamente h$finalizaragenda,
                nvl2(c.idagenda, 0, 1) h$agendaexp,
                nvl2(lnf.idagendarecebimento, 0, 1) h$agendarec
  from agendatransporte a, entidade e1, entidade e2, tiporecebimento tr,
       turnotrabalho tt, usuario u1, usuario u2, usuario u3, usuario u4,
       usuario u5, usuario u6, entidade rem, motivo m, depositante dep,
       carga c, lotenf lnf
 where e1.identidade = a.identidade
   and e2.identidade = a.idtransportadora
   and dep.identidade = a.identidade
   and rem.identidade(+) = a.idremetente
   and tr.idtiporecebimento(+) = a.idtiporecebimento
   and tt.idturno = a.idturno
   and u1.idusuario = a.idusuariocadastro
   and u2.idusuario(+) = a.idusuariochegada
   and u3.idusuario(+) = a.idusuariopatio
   and u4.idusuario(+) = a.idusuariodoca
   and u5.idusuario(+) = a.idusuariofinalizado
   and u6.idusuario(+) = a.idusuariocancelamento
   and m.idmotivo(+) = a.idmotivocancelamento
   and c.idagenda(+) = a.idagenda
   and lnf.idagendarecebimento(+) = a.idagenda
/

