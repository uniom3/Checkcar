create view VT_DEPOSITANTETRANSPORTADORA as
select codigointerno codTransportadora, razaosocial transportadora,
       cgc cnpjtransportadora, e.identidade idtransportadora
  from tipo t, entidade e
 where t.descr = 'TRANSPORTADORA'
  and e.tipoentidade = t.idtipo
  and decode(e.ativo,'S',1,0) = 1
/

