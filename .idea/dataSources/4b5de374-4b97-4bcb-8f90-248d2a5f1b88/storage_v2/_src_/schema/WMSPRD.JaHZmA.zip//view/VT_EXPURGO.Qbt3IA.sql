create view VT_EXPURGO as
select id, descr, tabelaprincipal, tabelas, campofiltro, dias, objetivo,
       ultimaexec, ativo, visivel h$visivel, filtroespecial
  from expurgo
   where visivel > 0
/

