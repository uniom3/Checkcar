create view V_EXECUCAO_SERVICOAVULSO as
select es.id as "Id Execução", a.descr as "Armazem",
       e.razaosocial as "Depositante", sa.descricao as "Servico",
       to_char(es.data, 'dd/mm/yyyy') as "Data Execução",
       es.qtde as "Qtde Feita", u.nomeusuario as "Usuario",
       es.apurado as "Apurado", es.idservico as "Id Serviço",
       es.observacao "Observação"
  from execucaoservicoavulso es, servicoavulso sa, entidade e, usuario u,
       armazem a
 where u.idusuario = es.idusuario
   and sa.id = es.idservico
   and a.idarmazem = es.idarmazem
   and e.identidade = sa.iddepositante
 order by es.id
/

