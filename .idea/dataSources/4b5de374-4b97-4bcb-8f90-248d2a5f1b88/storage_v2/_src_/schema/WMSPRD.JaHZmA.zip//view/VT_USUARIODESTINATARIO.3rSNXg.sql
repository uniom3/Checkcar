create view VT_USUARIODESTINATARIO as
select e.codigointerno, e.razaosocial, e.fantasia, e.cgc, e.cic, e.inscrestadual, e.pessoa, e.identidade
  from entidade e
/

