create view V_PRODUTIVIDADE_CONFSAIDA as
select data, anomes, idusuario, usuario, nomeusuario, atividade, depositante,
       setor, regiao, pk_utilities.retornarTempo(tempogasto) tempogasto,
       qtdeitens, qtdeunidades, round(qtdevolumes, 6) qtdevolumes,
       round(pesokg, 4) pesokg, qtdeatividade
  from (select cs.data, cs.anomes, cs.idusuario, cs.usuario, cs.nomeusuario,
                cs.atividade, cs.depositante, cs.setor, cs.regiao,
                sum(cs.tempogasto) tempogasto, sum(cs.qtdeitens) qtdeitens,
                sum(cs.qtdeunidades) qtdeunidades,
                sum(cs.qtdevolumes) qtdevolumes, sum(cs.pesokg) pesokg,
                sum(cs.qtdeatividade) qtdeatividade
           from (select c.idonda, trunc(pp.data) data,
                         to_char(pp.data, 'yyyy/mm') anomes, c.idusuario,
                         u.nomeusuario usuario,
                         u.nomeusuariocompleto nomeusuario,
                         'CONFERÊNCIA DE SAIDA' atividade,
                         edep.razaosocial depositante, s.descr setor,
                         r.descr regiao, min(pp.data) horainicio,
                         max(pp.data) horafim,
                         (max(pp.data) - min(pp.data)) * 86400 tempogasto,
                         count(distinct pp.idproduto) qtdeitens,
                         sum(pp.qtde * e.fatorconversao) qtdeunidades,
                         count(distinct c.idvolumeromaneio) qtdevolumes,
                         nvl(sum(vr.peso), sum(pp.qtde * e.pesobruto)) / 1000 pesokg,
                         count(distinct c.idnotafiscal) qtdeatividade
                    from confpacking c, produtoconfpacking pp, usuario u,
                         local lo, setor s, regiaoarmazenagem r, embalagem e,
                         volumeromaneio vr, notafiscal nf, entidade edep
                   where c.status in (0, 1)
                     and pp.idconfpacking = c.id
                     and pp.status = 1
                     and u.idusuario = c.idusuario
                     and lo.id = c.idpacking
                     and s.idsetor(+) = lo.idsetor
                     and r.idregiao(+) = lo.idregiao
                     and e.idproduto = pp.idproduto
                     and e.barra = pp.barra
                     and vr.idvolumeromaneio(+) = c.idvolumeromaneio
                     and nf.idnotafiscal(+) = c.idnotafiscal
                     and edep.identidade(+) = nf.iddepositante
                   group by c.idonda, trunc(pp.data),
                            to_char(pp.data, 'yyyy/mm'), c.idusuario,
                            u.nomeusuario, u.nomeusuariocompleto, s.descr,
                            r.descr, edep.razaosocial) cs
          group by cs.data, cs.anomes, cs.idusuario, cs.usuario,
                   cs.nomeusuario, cs.atividade, cs.setor, cs.regiao,
                   cs.depositante)
 order by data, nomeusuario
/

