create view VB_LOCALAJUSTEENTRADA as
select l.idlocal,
       decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'BANCADA', 6,
               'RUA EXPEDIÇÃO') tipolocal, l.setor, l.tiposetor,
       l.idarmazem h$idarmazem, l.estado h$estado,
       sd.iddepositante h$iddepositante, l.id h$idendereco,
       l.idlocalFormatado f$idlocalFormatado, l.ordem h$ordem,
       l.idlocalFormatado f$idlocal, l.idlocal h$tableid
  from (select 'N' estado, l.idarmazem, l.idlocal, l.tipo, s.descr setor,
                ts.descr tiposetor, s.idsetor, l.id, l.idlocalformatado,
                l.ordem
           from local l, setor s, tiposetor ts
          where s.idtiposetor = ts.idtiposetor
            and l.ativo = 'S'
            and l.tipo < 3
            and l.buffer = 'N'
            and l.idsetor = s.idsetor
            and ts.normal = 'S'
            and s.devolucaofornecedor = 0
            and s.usoexclusivocxmov = 0
         union
         select 'D' estado, l.idarmazem, l.idlocal, l.tipo, s.descr setor,
                ts.descr tiposetor, s.idsetor, l.id, l.idlocalformatado,
                l.ordem
           from local l, setor s, tiposetor ts
          where s.idtiposetor = ts.idtiposetor
            and l.ativo = 'S'
            and l.tipo < 3
            and l.buffer = 'N'
            and l.idsetor = s.idsetor
            and ts.danificado = 'S'
            and s.devolucaofornecedor = 0
            and s.usoexclusivocxmov = 0
         union
         select 'T' estado, l.idarmazem, l.idlocal, l.tipo, s.descr setor,
                ts.descr tiposetor, s.idsetor, l.id, l.idlocalformatado,
                l.ordem
           from local l, setor s, tiposetor ts
          where s.idtiposetor = ts.idtiposetor
            and l.ativo = 'S'
            and l.tipo < 3
            and l.buffer = 'N'
            and l.idsetor = s.idsetor
            and ts.truncado = 'S'
            and s.devolucaofornecedor = 0
            and s.usoexclusivocxmov = 0
         union
         select 'T' estado, l.idarmazem, l.idlocal, l.tipo, s.descr setor,
                ts.descr tiposetor, s.idsetor, l.id, l.idlocalformatado,
                l.ordem
           from local l, setor s, tiposetor ts
          where s.idtiposetor = ts.idtiposetor
            and l.ativo = 'S'
            and l.tipo < 3
            and l.buffer = 'N'
            and l.idsetor = s.idsetor
            and ts.vencido = 'S'
            and s.devolucaofornecedor = 0
            and s.usoexclusivocxmov = 0) l, setordepositante sd
 where sd.idsetor = l.idsetor
/

