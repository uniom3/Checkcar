create view VT_COLMEIA as
select c.idcolmeia, c.cor, c.codhexadecimal, c.codhexadecimal colunacor,
       c.altura, c.largura, c.comprimento, c.pesomaximo, c.temperaturamin,
       c.temperaturamax, c.linha, c.coluna, c.usaimppadraovolume,
       c.imppadraovolume, c.usaimppadraodanfe, c.imppadraodanfe,
       c.usaimppadraopresente, c.imppadraopresente, c.idarmazem h$idarmazem, c.ativo
  from colmeia c
/

