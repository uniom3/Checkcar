create view VT_ERROGERACAOONDA as
select 1 H$ordem, nd.nf notafiscal, c.iditemnotafiscal item, p.codigointerno,
       p.descr produto, c.qtdepedido,
       nvl(c.qtdedisponivelpk, 0) qtdedisponivelpk,
       nvl(c.qtdedisponivelpl, 0) qtdedisponivelpl, '' tipoproblema,
       c.motivocorte detalhe, 0 H$idnotafiscal, c.iditemnotafiscal H$idnfdet,
       c.idromaneio H$IDONDA
  from corteromaneio c, produto p, nfdet nd
 where p.idproduto = c.idproduto
   and nd.idnfdet = c.iditemnotafiscal
union
select 2 H$ordem, nd.nf notafiscal, e.idnfdet item, p.codigointerno,
       p.descr produto, null qtdepedido, null qtdedisponivelpk,
       null qtdedisponivelpl, e.tipoproblema, e.detalhe,
       nd.nf H$idnotafiscal, nd.idnfdet H$idnfdet, e.idonda H$IDONDA
  from errogeracaoonda e, nfdet nd, produto p
 where classificacao = 'C'
   and nd.idnfdet = e.idnfdet
   and p.idproduto = nd.idproduto
/

