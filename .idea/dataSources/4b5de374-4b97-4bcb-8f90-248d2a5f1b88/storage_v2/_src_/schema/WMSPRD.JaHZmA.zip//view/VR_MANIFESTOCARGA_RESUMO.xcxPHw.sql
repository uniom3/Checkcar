create view VR_MANIFESTOCARGA_RESUMO as
select v.idcarga, v.tipodocumento, sum(v.valor) valor
  from v_manifesto_carga v
 group by v.idcarga, v.tipodocumento
 order by v.tipodocumento
/

