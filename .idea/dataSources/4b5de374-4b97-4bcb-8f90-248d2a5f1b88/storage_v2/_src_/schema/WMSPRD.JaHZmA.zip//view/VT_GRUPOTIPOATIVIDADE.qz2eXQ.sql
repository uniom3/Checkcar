create view VT_GRUPOTIPOATIVIDADE as
select g.idgrupo, g.descr grupo
  from grupo g
/

