create view V_STATUSCONTAGEMINVENTARIO as
select a.idinventario, a.idlocal, a.bloco, a.rua, a.predio, a.andar, a.apartamento,
       a.picking, a.qtdecontagemuserdiferente, a.qtdetotalcontagem,
       a.liberado, a.descricao, a.status, b.qtde, b.qtdeun, b.fator,
       b.usuario, b.usuarioqtde, l.idlocalformatado f$idlocal
  from ( -- faltando contar
         select idinventario, idarmazem, idlocal, bloco, rua, predio, andar,
                 apartamento, picking, qtdecontagemuserdiferente,
                 qtdetotalcontagem, liberado, 'FALTA CONTAR' descricao, 0 status
           from v_qtdecontageminventario
          where qtdetotalcontagem = 0
            and liberado = 0
         union
         -- faltando liberar com uma contagem
         select idinventario, idarmazem, idlocal, bloco, rua, predio, andar,
                apartamento, picking, qtdecontagemuserdiferente,
                qtdetotalcontagem, liberado, 'FALTA UMA CONTAGEM' descricao,
                1 status
           from v_qtdecontageminventario
          where qtdetotalcontagem = 1
            and liberado = 0
         union
         -- faltando liberar com duas contagem
         select idinventario, idarmazem, idlocal, bloco, rua, predio, andar,
                apartamento, picking, qtdecontagemuserdiferente,
                qtdetotalcontagem, liberado, 'COM 2 CONTAGENS' descricao,
                2 status
           from v_qtdecontageminventario
          where qtdetotalcontagem = 2
            and liberado = 0
         union
         -- faltando liberar com mais duas contagem
         select idinventario, idarmazem, idlocal, bloco, rua, predio, andar,
                apartamento, picking, qtdecontagemuserdiferente,
                qtdetotalcontagem, liberado, 'COM MAIS 2 CONTAGENS' descricao,
                3 status
           from v_qtdecontageminventario
          where qtdetotalcontagem > 2
            and liberado = 0) a,
       (select i.idinventario, i.idarmazem, i.idlocal,
                stragg(i.qtd * i.fator) qtdeun, stragg(i.fator) fator,
                stragg(i.qtd) qtde, stragg(u.nomeusuario) usuario, stragg(u.nomeusuario||'['||i.qtd * i.fator||']') usuarioqtde
           from invdet i, usuario u
          where i.ignorada = 'N'
            and u.idusuario = i.idusuario
          group by idinventario, idarmazem, idlocal) b, local l
 where b.idlocal(+) = a.idlocal
   and b.idarmazem(+) = a.idarmazem
   and b.idinventario(+) = a.idinventario
   and l.idlocal = a.idlocal
/

