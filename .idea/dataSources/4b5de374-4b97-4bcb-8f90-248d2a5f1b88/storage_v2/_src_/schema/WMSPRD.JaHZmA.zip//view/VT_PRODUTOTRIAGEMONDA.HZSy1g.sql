create view VT_PRODUTOTRIAGEMONDA as
select rp.codigointerno onda, p.codigointerno codproduto, p.descr produto,
       nd.barra, sum(nd.qtdeatendida) qtdeembalagem,
       sum(nd.qtdeatendida * e.fatorconversao) qtde,
       e.descrreduzido embalagem, e.fatorconversao,
       nf.idnotafiscal, rp.idromaneio h$idromaneio
  from romaneiopai rp, nfromaneio nfr, nfdet nd, produto p, embalagem e,
       notafiscal nf
 where nfr.idromaneio = rp.idromaneio
   and nd.nf = nfr.idnotafiscal
   and p.idproduto = nd.idproduto
   and e.idproduto = nd.idproduto
   and e.barra = nd.barra
   and nf.idnotafiscal = nd.nf
   and nf.lido <> 1
 group by rp.codigointerno, p.codigointerno, p.descr, nd.barra,
          e.descrreduzido, e.fatorconversao, nf.idnotafiscal, rp.idromaneio
/

