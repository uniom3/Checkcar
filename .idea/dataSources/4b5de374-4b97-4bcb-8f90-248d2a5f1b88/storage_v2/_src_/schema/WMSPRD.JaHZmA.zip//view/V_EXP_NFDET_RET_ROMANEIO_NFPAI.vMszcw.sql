create view V_EXP_NFDET_RET_ROMANEIO_NFPAI as
select distinct '7' i, nfi.codigointerno, nfi.numpedido, nfi.cnpj_depositante,
       nfi.cnpj_emitente, nfi.sequencia, nfi.tipo, nfd.idseq, nfd.barra,
       nfd.qtde, nvl(nfd.qtdeatendida, 0) qtdeatendida,
       nvl(nf.idnotafiscal, 0) idgcom, nf.identificadorpedido,
       substr(nfd.codigoindustria,0,20) codigoproduto, '*' f,
       nvl(nf.idnotafiscal, 0) idnfsilt, nfd.idprenf, rp.idromaneio,
       nfd.serie, nf.tiponf, nf.iddepositante, nfi.retorno,
       nfd.qtdecorteseparacaoaceita qtdecortefisico, nfp.idnotafiscal, nfd.idnfdet,
        pk_confsaida.retornarvolumesproduto(nfr.idromaneio, nfr.idnotafiscal,
                                            nfd.barra) volumes,
       nfd.codigoindustria AS codproduto                                                       
  from notafiscal nf, nfimpressao nfi, nfdetimpressao nfd, notafiscal nfp, nfromaneio nfr,
       romaneiopai rp
 where rp.idromaneio(+) = nfr.idromaneio
   and nfr.idnotafiscal = nfp.idnotafiscal
   and nfp.idpedidopai(+) = nf.idnotafiscal
   and nfd.barra is not null
   and nfd.idprenf = nfi.idprenf
   and nvl(nfi.importacao, 'N') = 'S'
   and nfi.idprenf = nf.idprenf
/

