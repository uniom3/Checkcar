create view VI_INT_ENVIO_AM_ASN_ITEM_INFO as
select agrupador id, idnotafiscal, lineitemsequencenumber, packageid,
       informacao, identificadorinfo
  from int_envio_am_asn_item_info
/

