create view VB_CONTRATODEPOSITANTE as
select c.id idcontrato, c.identidadepagadora identidade, c.descricao,
       c.numero, ep.codigointerno, ep.razaosocial entidadepagadora,
       ep.cgc cnpjpagadora
  from contrato c, entidade ep
 where c.situacao not in (2, 3)
   and ep.identidade = c.identidadepagadora
union
select c.id idcontrato, cd.iddepositante identidade, c.descricao, c.numero,
       ep.codigointerno, ep.razaosocial entidadepagadora,
       ep.cgc cnpjpagadora
  from contratodepositante cd, contrato c, entidade ep
 where c.id = cd.idcontrato
   and c.identidadepagadora <> cd.iddepositante
   and c.situacao not in (2, 3)
   and ep.identidade = c.identidadepagadora
/

