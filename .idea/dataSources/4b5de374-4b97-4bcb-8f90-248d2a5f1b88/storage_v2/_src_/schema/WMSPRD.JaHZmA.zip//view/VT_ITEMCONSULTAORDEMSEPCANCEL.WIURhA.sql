create view VT_ITEMCONSULTAORDEMSEPCANCEL as
select osci.id, osci.idordemseparacaocancelamento, osci.idproduto,
       osci.descricao, osci.qtde, osci.status, osci.etapa, osci.motivo,
       osci.datasolicitacao, osci.dataefetivacao
  from ordemseparacaocancelamentoitem osci
/

