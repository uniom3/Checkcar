create view VB_DIRETORIOSINTEGRACAO as
select id, upper(dir) diretorio from ( 
  select id, dirimportacao dir from configuracaointegracao
  union
  select id, dirbkpimportacao dir from configuracaointegracao
  union
  select id, direxportacao dir from configuracaointegracao
  union
  select id, dirbkpimportacao dir from configuracaointegracao
  union
  select id, erro dir from configuracaointegracao)
 where dir is not null
/

