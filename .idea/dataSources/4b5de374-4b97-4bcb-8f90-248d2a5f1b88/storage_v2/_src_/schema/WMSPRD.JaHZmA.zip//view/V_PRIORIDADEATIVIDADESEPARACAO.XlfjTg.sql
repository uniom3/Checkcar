create view V_PRIORIDADEATIVIDADESEPARACAO as
with w_tipoatividade as
 (select tag.idgrupo, g.descr grupo
    from tipoatividadegrupo tag, grupo g, tipoatividade ta
   where g.idgrupo = tag.idgrupo
     and ta.idtipoatividade = tag.idtipoatividade
     and ta.exibiratividadeunicapriorizar = 1
     and tag.idtipoatividade = 9),
w_usuario as
 (select u.idusuario, u.nomeusuario usuario,
         nu.nivel || ' - ' || nu.descricao nivel, u.departamento, u.email
    from usuario u, nivelusuario nu
   where u.idusuario > 0
     and nu.nivel(+) = u.nivel
     and u.ativo = 'S')
select u.idusuario, u.usuario, u.nivel, u.departamento, u.email,
       stragg(a.grupo) grupo
  from w_usuario u, grupousuario gu, w_tipoatividade a
 where gu.idusuario = u.idusuario
   and a.idgrupo = gu.idgrupo
 group by u.idusuario, u.usuario, u.nivel, u.departamento, u.email
/

