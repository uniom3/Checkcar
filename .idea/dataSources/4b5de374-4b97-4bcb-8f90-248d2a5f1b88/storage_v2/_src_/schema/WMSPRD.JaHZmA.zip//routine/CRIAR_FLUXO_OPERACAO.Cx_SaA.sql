create procedure criar_fluxo_operacao
(
  p_idFluxo        in number,
  p_descricaoFluxo in varchar2
) is
  V_PULMAO         number := 0;
  V_BUFFER_DOCA    number := 1;
  V_BUFFER_COLMEIA number := 2;
  V_BUFFER_PICKING number := 3;
  V_STAGE          number := 4;
  V_PICKING        number := 5;
  V_DOCA           number := 6;
  V_COLMEIA        number := 7;
  V_PACKING        number := 8;
  --V_SERVICO        number := 9;

  v_idFluxo number;

  v_idSeqOper number;

  v_qtde number;

  function getNomeFluxo(p_id number) return varchar2 is
  begin
    if (p_id = 0) then
      return 'Pulm?o > Doca';
    end if;
  
    if (p_id = 1) then
      return 'Pulm?o > Packing > Doca';
    end if;
  
    if (p_id = 2) then
      return 'Pulm?o > Buffer de Doca > Doca';
    end if;
  
    if (p_id = 3) then
      return 'Pulm?o > Picking > Doca';
    end if;
  
    if (p_id = 4) then
      return 'Pulm?o > Picking > Colmeia > Doca';
    end if;
  
    if (p_id = 5) then
      return 'Pulm?o > Stage > Packing > Doca';
    end if;
  
    if (p_id = 6) then
      return 'Pulm?o > Buffer de Picking > Picking > Doca';
    end if;
  
    if (p_id = 7) then
      return 'Pulm?o > Buffer de Picking > Picking > Colmeia > Doca';
    end if;
  
    if (p_id = 8) then
      return 'Pulm?o > Buffer de Colmeia > Colmeia > Doca';
    end if;
  
    if (p_id = 9) then
      raise_application_error(-20000,
                              'FLUXO DE OPERAC?O UTILIZANDO SERVICO ESTA PENDENTE DE CRIAC?O DE SCRIPT');
    end if;
  
    if (p_id = 10) then
      return 'Pulm?o > Picking > Packing > Doca';
    end if;
  
    if (p_id = 11) then
      return 'Pulm?o > Colmeia > Doca';
    end if;
  
    raise_application_error(-20000,
                            'INFORME CORRETAMENTE O ID DE UM FLUXO, ID INFORMADO: ' || p_id);
  end getNomeFluxo;

  function insereSequenciaOperacao
  (
    p_desc    varchar2,
    v_idFluxo number
  ) return number is
    v_idSequenciaOperacao number;
    v_proximaOrdem        number;
  begin
    begin
      select nvl(max(so.ordem), 0) + 1
        into v_proximaOrdem
        from sequenciaoperacao so
       where so.idfluxo = v_idFluxo;
    exception
      when others then
        v_proximaOrdem := 1;
    end;
  
    select seq_sequenciaoperacao.nextval
      into v_idSequenciaOperacao
      from dual;
  
    insert into sequenciaoperacao
      (id, descr, idfluxo, ordem)
    values
      (v_idSequenciaOperacao, p_desc, v_idFluxo, v_proximaOrdem);
  
    return v_idSequenciaOperacao;
  
  end insereSequenciaOperacao;

  procedure insereSequenciaEtapa
  (
    p_idSequenciaOperacao number,
    p_etapa               number,
    p_ordem               number,
    p_idregiao            number,
    p_moverProdutos       number
  ) is
    v_sequenciaetapa number;
  begin
    select seq_sequenciaetapa.nextval
      into v_sequenciaetapa
      from dual;
  
    insert into sequenciaetapa
      (id, idsequencia, idetapa, ordem, idregiao, movertodosprodutos)
    values
      (v_sequenciaetapa, p_idSequenciaOperacao, p_etapa, p_ordem,
       p_idregiao, p_moverProdutos);
  
  end insereSequenciaEtapa;

  procedure validarParametros is
  begin
    if (v_idFluxo is not null) then
      select count(1)
        into v_qtde
        from fluxooperacao f
       where f.id = v_idFluxo;
    
      if (v_qtde = 0) then
        raise_application_error(-20000, 'FLUXO DE OPERAC?O N?O ENCONTRADO.');
      end if;
    end if;
  
    select count(1)
      into v_qtde
      from gtt_selecao;
  
    if (v_qtde = 0) then
      raise_application_error(-20000,
                              'NENHUM FLUXO INFORMADO PARA CADASTRO.');
    end if;
  
    if (v_idFluxo is null and p_descricaoFluxo is null) then
      raise_application_error(-20000,
                              'INFORME O NOME PARA O FLUXO OU UM IDFLUXO EXISTENTE');
    end if;
  end validarParametros;

begin
  v_idFluxo := p_idFluxo;

  validarParametros;

  /*novo fluxo*/
  if (v_idFluxo is null) then
    select seq_fluxooperacao.nextval
      into v_idFluxo
      from dual;
  
    insert into fluxooperacao
      (id, descr)
    values
      (v_idFluxo, upper(replace(p_descricaoFluxo, ' > ', '>')));
  end if;

  for c in (select g.idselecionado idx
              from gtt_selecao g)
  loop
  
    v_idSeqOper := insereSequenciaOperacao(getNomeFluxo(c.idx), v_idFluxo);
  
    if (c.idx = 0) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 1, null, 0);
    end if;
  
    if (c.idx = 1) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PACKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 2, null, 0);
    end if;
  
    if (c.idx = 2) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_BUFFER_DOCA, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 2, null, 0);
    end if;
  
    if (c.idx = 3) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PICKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 2, null, 0);
    end if;
  
    if (c.idx = 4) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PICKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_COLMEIA, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 3, null, 0);
    end if;
  
    if (c.idx = 5) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_STAGE, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PACKING, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 3, null, 0);
    end if;
  
    if (c.idx = 6) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_BUFFER_PICKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PICKING, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 3, null, 0);
    end if;
  
    if (c.idx = 7) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_BUFFER_PICKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PICKING, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_COLMEIA, 3, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 4, null, 0);
    end if;
  
    if (c.idx = 8) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_BUFFER_COLMEIA, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_COLMEIA, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 3, null, 0);
    end if;
  
    if (c.idx = 9) then
      null;
    end if;
  
    if (c.idx = 10) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PICKING, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_PACKING, 2, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 3, null, 0);
    end if;
  
    if (c.idx = 11) then
      insereSequenciaEtapa(v_idSeqOper, V_PULMAO, 0, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_COLMEIA, 1, null, 0);
      insereSequenciaEtapa(v_idSeqOper, V_DOCA, 2, null, 0);
    end if;
  
  end loop;

  select count(distinct se.idetapa)
    into v_qtde
    from fluxooperacao fo, sequenciaoperacao so, sequenciaetapa se
   where so.idfluxo = fo.id
     and se.idsequencia = so.id
     and fo.id = v_idFluxo
     and se.idetapa in (V_PACKING, V_COLMEIA);

  if (v_qtde > 1) then
    raise_application_error(-20000,
                            'FLUXO DE OPERAC?O ESTA INVALIDO (PACKING E COLMEIA)');
  end if;

end criar_fluxo_operacao;
/

