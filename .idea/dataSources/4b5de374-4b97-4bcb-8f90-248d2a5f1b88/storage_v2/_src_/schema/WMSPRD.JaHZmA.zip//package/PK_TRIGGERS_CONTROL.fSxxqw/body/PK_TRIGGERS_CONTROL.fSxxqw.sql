create package body PK_TRIGGERS_CONTROL as

  procedure disableTrigger(p_triggerName in varchar2) is
  begin
    insert into gtt_disable_triggers
      (triggerName)
    values
      (p_triggerName);
  end;

  function isTriggerDisable(p_triggerName in varchar2) return boolean is
    v_triggerDisable number;
  begin
    select count(*)
      into v_triggerDisable
      from dual
     where exists
     (select 1
              from gtt_disable_triggers g
             where upper(g.triggername) = upper(p_triggerName));
  
    if (v_triggerDisable = 1) then
      return true;
    else
      return false;
    end if;
  end;

  procedure enableTrigger(p_triggerName in varchar2) is
  begin
    delete from gtt_disable_triggers g
     where g.triggerName = p_triggerName;
  end;

  procedure enableAllTrigger is
  begin
    delete from gtt_disable_triggers;
  end;

  function isOutraColunaAlteradaTrigger
  (
    p_tabela varchar2,
    p_coluna varchar2
  ) return boolean is
    v_count number := 0;
  begin
    if (updating) then
      for r in (select u.column_name
                  from user_tab_columns u
                 where upper(u.table_name) = upper(p_tabela))
      loop
        if updating(r.column_name)
           and upper(p_coluna) <> upper(r.column_name) then
          v_count := v_count + 1;
        end if;
      end loop;
    end if;
  
    return v_count > 0;
  
  end isOutraColunaAlteradaTrigger;

end;
/

