create view VI_INT_ENVIO_PN_CS as
select agrupador id, filetype, shipmentnumber, pickingnumber,
                         customerorder, forwardagentcode, routecode,
                         packagenumber, trackingnumber, shipmentnumberblank,
                         packagetype, position, sku, lotnumber, quantity,
                         locationtype
           from int_envio_pn_cs

/

