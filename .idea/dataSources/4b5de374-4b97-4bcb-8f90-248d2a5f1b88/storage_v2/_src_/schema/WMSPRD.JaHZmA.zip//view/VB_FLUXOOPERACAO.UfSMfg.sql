create view VB_FLUXOOPERACAO as
select descr fluxo, id, pk_armazem.retornarsequenciafluxo(id) sequencia,
       decode(usoInterno, 3, 1, 0) conferenciaPesagem,
       usoInterno H$usoInterno
  from fluxooperacao
/

