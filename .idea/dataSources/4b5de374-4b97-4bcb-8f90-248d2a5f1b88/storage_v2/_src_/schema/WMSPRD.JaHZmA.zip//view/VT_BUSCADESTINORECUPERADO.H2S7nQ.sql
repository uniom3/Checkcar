create view VT_BUSCADESTINORECUPERADO as
select l.idlocal, l.bloco, l.rua, l.predio, l.andar, l.apartamento,
       decode(mod(l.predio, 2), 0, 'PAR', 'ÍMPAR') lado,
       decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDIÇÃO', 7, 'STAGE', 8, 'PACKING', 9, 'SERVIÇO', 10,
               'CONFERÊNCIA') tipolocal, s.descr setor,
       r.descr regiaoexpedicao, l.tipo, l.id h$idendereco,
       l.idregiao h$idregiao, l.idsetor h$idsetor, l.idarmazem h$idarmazem,
       l.idlocalformatado f$idlocal, l.ordem h$ordem,
       sd.iddepositante h$iddepositante
  from local l, setor s, tiposetor ts, regiaoarmazenagem r,
       setordepositante sd
 where l.ativo = 'S'
   and l.tipo < 3
   and l.buffer = 'N'
   and s.idsetor = l.idsetor
   and s.ativo = 'S'
   and s.devolucaofornecedor = 0
   and s.usoexclusivocxmov = 0
   and ts.idtiposetor = s.idtiposetor
   and ts.normal = 'S'
   and r.idregiao = l.idregiao
   and sd.idsetor = s.idsetor
/

