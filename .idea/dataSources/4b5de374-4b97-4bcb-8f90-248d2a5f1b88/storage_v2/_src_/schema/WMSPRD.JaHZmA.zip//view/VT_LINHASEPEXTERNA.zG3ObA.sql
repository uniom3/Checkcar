create view VT_LINHASEPEXTERNA as
select l.id, l.descricao, l.codintegracao, l.reabastecepickingauto,
       l.permitedesmarcarnfsepext
  from linhasepexterna l
/

