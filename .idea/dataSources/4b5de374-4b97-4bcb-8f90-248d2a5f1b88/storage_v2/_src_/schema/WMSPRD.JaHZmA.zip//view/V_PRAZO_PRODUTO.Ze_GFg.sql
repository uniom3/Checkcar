create view V_PRAZO_PRODUTO as
select ll.idarmazem, ll.idlote, l.idproduto, p.codigointerno codproduto,
       p.codreferencia, p.descr produto, dep.razaosocial depositante,
       trunc(l.dtvenc) datavencimento,
       case
          when l.dtvenc is null then
           'SEM DATA VENCIMENTO'
          when (nvl(trunc(l.dtvenc), trunc(sysdate)) <= trunc(sysdate)) then
           'VENCIDO'
          when round((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30,
                     2) <= p.prazocritico then
           'CRÍTICO'
          when (round((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30,
                      2) <= p.prazocomercializacao)
               and ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30 >
               p.prazocritico) then
           'COMERCIALIZAÇÃO'
          when ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30) >
               p.prazocomercializacao then
           'NORMAL'
        end prazo,
       case
          when l.dtvenc is null then
           4
          when (nvl(trunc(l.dtvenc), trunc(sysdate)) <= trunc(sysdate)) then
           3
          when round((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30,
                     2) <= p.prazocritico then
           2
          when (round((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30,
                      2) <= p.prazocomercializacao)
               and ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30 >
               p.prazocritico) then
           1
          when ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30) >
               p.prazocomercializacao then
           0
        end status,
       sum(ll.estoque - ll.pendencia + ll.adicionar) estoquedisponivel,
       dep.identidade iddepositante
  from lotelocal ll, lote l, produto p, entidade dep
 where p.idproduto = l.idproduto
   and l.idlote = ll.idlote
   and dep.identidade = l.iddepositante
   and ll.estoque - ll.pendencia + ll.adicionar > 0
 group by ll.idarmazem, ll.idlote, l.idproduto, p.codigointerno,
          p.codreferencia, p.descr, trunc(l.dtvenc),
          case
            when l.dtvenc is null then
             'SEM DATA VENCIMENTO'
            when (nvl(trunc(l.dtvenc), trunc(sysdate)) <= trunc(sysdate)) then
             'VENCIDO'
            when round((nvl(trunc(l.dtvenc), trunc(sysdate)) -
                       trunc(sysdate)) / 30, 2) <= p.prazocritico then
             'CRÍTICO'
            when (round((nvl(trunc(l.dtvenc), trunc(sysdate)) -
                        trunc(sysdate)) / 30, 2) <= p.prazocomercializacao)
                 and ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30 >
                 p.prazocritico) then
             'COMERCIALIZAÇÃO'
            when ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30) >
                 p.prazocomercializacao then
             'NORMAL'
          end,
          case
            when l.dtvenc is null then
             4
            when (nvl(trunc(l.dtvenc), trunc(sysdate)) <= trunc(sysdate)) then
             3
            when round((nvl(trunc(l.dtvenc), trunc(sysdate)) -
                       trunc(sysdate)) / 30, 2) <= p.prazocritico then
             2
            when (round((nvl(trunc(l.dtvenc), trunc(sysdate)) -
                        trunc(sysdate)) / 30, 2) <= p.prazocomercializacao)
                 and ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30 >
                 p.prazocritico) then
             1
            when ((nvl(trunc(l.dtvenc), trunc(sysdate)) - trunc(sysdate)) / 30) >
                 p.prazocomercializacao then
             0
          end, dep.razaosocial, dep.identidade
/

