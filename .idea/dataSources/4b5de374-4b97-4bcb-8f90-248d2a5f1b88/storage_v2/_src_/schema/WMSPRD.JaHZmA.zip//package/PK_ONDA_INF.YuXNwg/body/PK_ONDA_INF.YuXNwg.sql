create package body PK_ONDA_INF is

  procedure preencherPaletSepNFOnda(p_idonda in number) is
    type t_PaletSeparacao is table of paletseparacao%rowtype;
    v_PaletSeparacao t_PaletSeparacao := t_PaletSeparacao();
    i                number;
    v_qtdesepunid    number;
    v_qtdesep        number;
    v_qtdenf         number;
    v_qtdediff       number;
    v_msg            t_message;
  
    function retDepositanteLote(p_idlote in number) return number is
      v_iddepositante number;
    begin
      select lt.iddepositante
        into v_iddepositante
        from lote lt
       where lt.idlote = p_idlote;
    
      return v_iddepositante;
    end;
  
    function retSepararLotesCompletos(p_iddepositante in number)
      return number is
      v_seplotescompletos number;
    begin
      select d.separarlotescompletos
        into v_seplotescompletos
        from depositante d
       where d.identidade = p_iddepositante;
    
      return v_seplotescompletos;
    end;
  begin
    -- Excluindo os dados já lançados
    delete from paletseparacaonf
     where idromaneio = p_idonda;
  
    -- Incluindo na matriz as quantidades que se encontram na paletseparacao
    for c_separacao in (select ps.idlote, ps.idproduto,
                               round(sum(ps.qtdeunit), 6) qtdeunit, descr
                          from paletseparacao ps, lote l
                         where ps.idromaneio = p_idonda
                           and l.idlote = ps.idlote
                           and l.tipolote = 'L'
                         group by ps.idlote, ps.idproduto, descr
                         order by ps.idproduto, descr)
    loop
      v_PaletSeparacao.Extend;
      i := v_PaletSeparacao.Count;
      v_PaletSeparacao(i).idromaneio := p_idonda;
      v_PaletSeparacao(i).idproduto := c_separacao.idproduto;
      v_PaletSeparacao(i).qtdeunit := c_separacao.qtdeunit;
      v_PaletSeparacao(i).idlote := c_separacao.idlote;
    end loop;
  
    -- Incluindo os lotes separados por item das notas fiscais
    for c_nota in (select pn.idromaneio, pn.idnotafiscal, pn.idproduto,
                          pn.barra, sum(pn.qtdeunid) qtdeunid,
                          pn.fatorconversao, pn.idnfdet, pn.iddepositante,
                          pn.idlote
                     from (select n.idromaneio, n.idnotafiscal, n.idproduto,
                                   n.barra, sum(n.qtdeunid) qtdeunid,
                                   n.fatorconversao, n.idnfdet, n.iddepositante,
                                   null idlote
                              from (select nr.idromaneio, nr.idnotafiscal,
                                            nd.idproduto, nd.barra,
                                            (nd.qtdeatendida * em.fatorconversao) qtdeunid,
                                            em.fatorconversao, nd.idnfdet,
                                            nf.iddepositante
                                       from nfromaneio nr, nfdet nd, embalagem em,
                                            produto p, notafiscal nf
                                      where nd.nf = nr.idnotafiscal
                                        and em.idproduto = nd.idproduto
                                        and em.barra = nd.barra
                                        and p.idproduto = nd.idproduto
                                        and nf.idnotafiscal = nd.nf
                                        and p.kitexpexplodida = 'N'
                                        and nr.idromaneio = p_idonda
                                     union all
                                     select nr.idromaneio, nr.idnotafiscal,
                                            nd.idproduto, nd.barra,
                                            sum(sle.qtde) * -1 qtdeunid,
                                            em.fatorconversao, nd.idnfdet,
                                            nf.iddepositante
                                       from nfromaneio nr, nfdet nd, embalagem em,
                                            produto p, notafiscal nf,
                                            separacaoespecifica s,
                                            seploteindsepespecif sle,
                                            sepespporloteindustria sl
                                      where nd.nf = nr.idnotafiscal
                                        and em.idproduto = nd.idproduto
                                        and em.barra = nd.barra
                                        and p.idproduto = nd.idproduto
                                        and nf.idnotafiscal = nd.nf
                                        and p.kitexpexplodida = 'N'
                                        and nr.idromaneio = p_idonda
                                        and s.id = sle.idsepespecifica
                                        and sle.idseploteind =
                                            sl.idsepespporloteindustria
                                        and sl.idnfdet = nd.idnfdet
                                      group by nr.idromaneio, nr.idnotafiscal,
                                               nd.idproduto, nd.barra,
                                               em.fatorconversao, nd.idnfdet,
                                               nf.iddepositante) n
                             group by n.idromaneio, n.idnotafiscal, n.idproduto,
                                      n.barra, n.fatorconversao, n.idnfdet,
                                      n.iddepositante
                            having sum(n.qtdeunid) > 0
                            union all
                            select nr.idromaneio, nr.idnotafiscal, kp.idproduto,
                                   kp.barra,
                                   (nd.qtdeatendida * em.fatorconversao) *
                                    (kp.qtde * ek.fatorconversao) qtdeunid,
                                   em.fatorconversao, nd.idnfdet,
                                   nf.iddepositante, null idlote
                              from nfromaneio nr, nfdet nd, embalagem em,
                                   produto p, kitproduto kp, embalagem ek,
                                   notafiscal nf
                             where nd.nf = nr.idnotafiscal
                               and em.idproduto = nd.idproduto
                               and em.barra = nd.barra
                               and p.idproduto = nd.idproduto
                               and nf.idnotafiscal = nd.nf
                               and p.kitexpexplodida = 'S'
                               and kp.idprodutokit = nd.idproduto
                               and ek.idproduto = kp.idproduto
                               and ek.barra = kp.barra
                               and nr.idromaneio = p_idonda
                            union all
                            select nr.idromaneio, nr.idnotafiscal, nd.idproduto,
                                   nd.barra, sle.qtde qtdeunid,
                                   em.fatorconversao, nd.idnfdet,
                                   nf.iddepositante, s.idlote idlote
                              from nfromaneio nr, nfdet nd, embalagem em,
                                   produto p, notafiscal nf,
                                   separacaoespecifica s,
                                   seploteindsepespecif sle,
                                   sepespporloteindustria sl
                             where nd.nf = nr.idnotafiscal
                               and em.idproduto = nd.idproduto
                               and em.barra = nd.barra
                               and p.idproduto = nd.idproduto
                               and nf.idnotafiscal = nd.nf
                               and p.kitexpexplodida = 'N'
                               and nr.idromaneio = p_idonda
                               and s.id = sle.idsepespecifica
                               and sle.idseploteind =
                                   sl.idsepespporloteindustria
                               and sl.idnfdet = nd.idnfdet) pn
                    group by pn.idromaneio, pn.idnotafiscal, pn.idproduto,
                             pn.barra, pn.fatorconversao, pn.idnfdet,
                             pn.iddepositante, pn.idlote
                    order by 2, 3, 9)
    loop
      v_qtdenf := c_nota.qtdeunid;
      for i in 1 .. v_PaletSeparacao.Count
      loop
        if ((v_PaletSeparacao(i).idproduto = c_nota.idproduto) and
           (retDepositanteLote(v_PaletSeparacao(i).idlote) =
           c_nota.iddepositante)) then
          if v_PaletSeparacao(i).qtdeunit > 0 then
          
            if (c_nota.idlote is null OR
               c_nota.idlote = v_PaletSeparacao(i).idlote) then
            
              if v_qtdenf > v_PaletSeparacao(i).qtdeunit then
                v_qtdesepunid := v_PaletSeparacao(i).qtdeunit;
              else
                if (retSepararLotesCompletos(c_nota.iddepositante) = 1) then
                  v_qtdesepunid := v_PaletSeparacao(i).qtdeunit;
                else
                  v_qtdesepunid := v_qtdenf;
                end if;
              end if;
              v_qtdesep := round(v_qtdesepunid / c_nota.fatorconversao, 6);
            
              if round(v_qtdesepunid, 6) > 0 then
                insert into paletseparacaonf
                  (idseparacao, idromaneio, idnotafiscal, idproduto, idlote,
                   barra, qtde, qtdeunidade, idnfdet)
                values
                  (seq_paletseparacaonf.nextval, p_idonda,
                   c_nota.idnotafiscal, c_nota.idproduto,
                   v_PaletSeparacao(i).idlote, c_nota.barra, v_qtdesep,
                   round(v_qtdesepunid, 6), c_nota.idnfdet);
              end if;
            
              v_PaletSeparacao(i).qtdeunit := v_PaletSeparacao(i)
                                              .qtdeunit - v_qtdesepunid;
              v_qtdenf := v_qtdenf - v_qtdesepunid;
              exit when v_qtdenf <= 0;
            
            end if;
          
          end if;
        end if;
      end loop;
    end loop;
  
    v_qtdediff := 0;
  
    select count(1)
      into v_qtdediff
      from dual
     where exists (select t.idproduto
              from (select pnf.idproduto, sum(pnf.qtdeunidade) qtde
                       from paletseparacaonf pnf
                      where pnf.idromaneio = p_idonda
                      group by pnf.idproduto
                     union all
                     select ps.idproduto, sum(ps.qtdeunit * -1) qtde
                       from paletseparacao ps
                      where ps.idromaneio = p_idonda
                      group by ps.idproduto) t
             group by t.idproduto
            having sum(t.qtde) <> 0);
  
    if v_qtdediff > 0 then
    
      v_msg := t_message('As quantidades solicitadas em nota/pedido e reservadas para ' ||
                         'separação estão divergentes. Valide a parametrização para ter certeza ' ||
                         'que será possível atender as quantidades solicitadas.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  procedure preencherInfSeparacao
  (
    p_idonda         in number,
    p_idconfiguracao in number
  ) is
    cursor c_emb
    (
      p_produto in number,
      p_rest    in number
    ) is
      select e.barra, e.fatorconversao
        from embalagem e
       where e.idproduto = p_produto
         and trunc(p_rest / e.fatorconversao) > 0
         and e.ativo = 'S'
       order by e.fatorconversao desc, nvl(e.barrainterna, 0) asc;
  
    v_tipoVisualizacao      number;
    v_tipoprocessoseparacao number;
  
    procedure limparDados is
    begin
      delete from mapaseparacaoonda
       where idonda = p_idonda;
    
      delete from mapasepondapedido
       where idonda = p_idonda;
    
      delete from paletseparacao
       where idromaneio = p_idonda;
    
      delete from paletseparacaocliente
       where idromaneio = p_idonda;
    
      delete from paletseparacaonf
       where idromaneio = p_idonda;
    
      delete from produtopalet
       where idromaneio = p_idonda;
    
      delete from palet
       where idromaneio = p_idonda;
    
      delete from romaneio
       where idromaneio = p_idonda;
    
      delete from gtt_mapaseparacaoonda;
    
      delete from gtt_paletseparacao;
    
      delete from gtt_produtopalet;
    
      delete from gtt_mapasonda;
    end limparDados;
  
    procedure preencherDadosIniciais is
    begin
      insert into gtt_produtopalet
        (idromaneio, iddepositante, iddestinatario, idproduto, barra, qtde,
         qtdeunit)
        select nfr.idromaneio, nf.iddepositante, nf.destinatario,
               nd.idproduto, nd.barra, sum(nd.qtdeatendida) qtde,
               sum(nd.qtdeatendida * e.fatorconversao) qtdeunit
          from nfromaneio nfr, nfdet nd, notafiscal nf, embalagem e
         where nfr.idnotafiscal = nf.idnotafiscal
           and nf.idnotafiscal = nd.nf
           and e.barra = nd.barra
           and e.idproduto = nd.idproduto
           and nfr.idromaneio = p_idonda
         group by nfr.idromaneio, 1, nf.iddepositante, nf.destinatario,
                  nd.idproduto, nd.barra;
    
      select co.modovisualizarqtdeseparacao, co.tipoprocessoseparacao
        into v_tipoVisualizacao, v_tipoprocessoseparacao
        from configuracaoonda co
       where co.idconfiguracaoonda = p_idconfiguracao;
    
      insert into gtt_mapasonda
        (idonda, idarmazem, idnotafiscal, ident_entrega, idenderecoorigem,
         idlocalorigem, idenderecodestino, tiporegiaoorigem, bufferorigem,
         identificador, etapa, idproduto, barra, fatorLote, fracionado,
         idlote, industria, dtvenc, ordem, qtde, qtdeMovimentadaUnit)
        select m.idonda, lo.idarmazem, nf.idnotafiscal, nf.ident_entrega,
               m.idlocalorigem idenderecoorigem, lo.idlocal idlocalorigem,
               m.idlocaldestino idenderecodestino, ra.tipo tiporegiaoorigem,
               lo.buffer bufferorigem, m.identificador, m.etapa, l.idproduto,
               l.barra, e.fatorconversao, decode(p.fracionado, 'S', 1, 0),
               l.idlote,
               decode(v_tipoprocessoseparacao, 0, null, l.descr) industria,
               decode(v_tipoprocessoseparacao, 0, null, l.dtvenc) dtvenc,
               m.ordem, sum(m.quantidade / e.fatorconversao) qtde,
               sum(m.qtdemovimentada) qtdeMovimentadaUnit
          from movimentacao m, local lo, local ld, lote l, embalagem e,
               notafiscal nf, regiaoarmazenagem ra, produto p
         where m.idonda = p_idonda
           and m.status in (0, 1, 2)
           and m.etapa in (1, 2) --and l.idproduto = 275
           and lo.id = m.idlocalorigem
           and ld.id = m.idlocaldestino
           and l.idlote = m.idlote
           and e.barra = l.barra
           and e.idproduto = l.idproduto
           and nf.idnotafiscal = m.idnotafiscal
           and ra.idregiao = lo.idregiao
           and p.idproduto = l.idproduto
         group by m.idonda, lo.idarmazem, nf.idnotafiscal, nf.ident_entrega,
                  m.idlocalorigem, lo.idlocal, m.idlocaldestino, ra.tipo,
                  lo.buffer, m.identificador, m.etapa, l.idproduto, l.barra,
                  e.fatorconversao, decode(p.fracionado, 'S', 1, 0),
                  l.idlote,
                  decode(v_tipoprocessoseparacao, 0, null, l.descr),
                  decode(v_tipoprocessoseparacao, 0, null, l.dtvenc),
                  m.ordem;
    end preencherDadosIniciais;
  
    procedure inserirRomaneio is
    begin
      insert into romaneio
        (idromaneio, idproduto, barra, qtdeaseparar, qtdeconf)
        select g.idromaneio, g.idproduto, g.barra,
               sum(g.qtdeunit) qtdeseparar, 0 qtdeconf
          from gtt_produtopalet g
         group by g.idromaneio, g.idproduto, g.barra;
    end inserirRomaneio;
  
    procedure inserirProdutoPalete is
    begin
      insert into produtopalet
        (idromaneio, idpalet, iddepositante, identidade, idproduto, barra,
         qtde, liberado)
        select g.idromaneio, 1 palet, g.iddepositante, g.iddestinatario,
               g.idproduto, g.barra, sum(g.qtde) qtde, 'N' liberado
          from gtt_produtopalet g
         group by g.idromaneio, g.iddepositante, g.iddestinatario,
                  g.idproduto, g.barra;
    end inserirProdutoPalete;
  
    procedure inserirPalete is
    begin
      insert into palet
        (idromaneio, idpalet, liberado, separado, recontagem, emconferencia,
         prioridade, fichaseparacao)
      values
        (p_idonda, 1, 'N', 'N', 'S', 'N', 1, 1);
    end inserirPalete;
  
    procedure inserirPaletSepCliente is
    begin
      insert into paletseparacaocliente
        (idromaneio, idpalet, idarmazem, idlocal, identidade, idproduto,
         barra, qtde, ordem)
        select g.idonda, 1 palet, g.idarmazem, g.idlocalorigem,
               g.ident_entrega, g.idproduto, g.barra,
               sum(round(g.qtde, 6)) qtde, 1 ordem
          from gtt_mapasonda g
         group by g.idonda, g.idarmazem, g.idlocalorigem, g.idproduto,
                  g.barra, g.ident_entrega;
    end inserirPaletSepCliente;
  
    procedure inserirMapasPaletSep is
      v_msg t_message;
    
      procedure distribuirPorEmb is
        r_emb           c_emb%rowtype;
        v_qtdeRestante  number;
        v_qtdeUtilizada number;
      begin
        for c_mapasOnda in (select g.idonda, g.idarmazem, g.idenderecoorigem,
                                   g.idlocalorigem, g.idenderecodestino,
                                   g.tiporegiaoorigem, g.bufferorigem,
                                   g.identificador, g.idproduto, g.barra,
                                   g.fatorLote, g.fracionado, g.ordem,
                                   g.etapa, g.industria, g.idlote,
                                   sum(g.qtdeMovimentadaUnit) qtdeUnit
                              from gtt_mapasOnda g
                             where g.fracionado = 0
                             group by g.idonda, g.idarmazem,
                                      g.idenderecoorigem, g.idlocalorigem,
                                      g.idenderecodestino, g.tiporegiaoorigem,
                                      g.bufferorigem, g.identificador,
                                      g.idproduto, g.barra, g.fatorLote,
                                      g.fracionado, g.ordem, g.etapa,
                                      g.industria, g.idlote)
        loop
          v_qtdeRestante := c_mapasOnda.qtdeUnit;
        
          open c_emb(c_mapasOnda.idproduto, v_qtdeRestante);
          fetch c_emb
            into r_emb;
          while (v_qtdeRestante > 0)
                and (c_emb%found)
          loop
            v_qtdeUtilizada := trunc(v_qtdeRestante / r_emb.fatorconversao);
            if v_qtdeUtilizada > 0 then
              v_qtdeRestante := v_qtdeRestante -
                                (v_qtdeUtilizada * r_emb.fatorconversao);
            
              insert into gtt_paletseparacao
                (idarmazem, idlocal, idlote, idproduto, idromaneio, idpalet,
                 barra, ordem, qtde, qtdeunit, separado, processado,
                 liberado)
              values
                (c_mapasOnda.idarmazem, c_mapasOnda.idlocalorigem,
                 c_mapasOnda.idlote, c_mapasOnda.idproduto,
                 c_mapasOnda.idonda, 1, r_emb.barra, c_mapasOnda.ordem,
                 v_qtdeUtilizada, (v_qtdeUtilizada * r_emb.fatorconversao),
                 'N', 'N', 'N');
            
              insert into gtt_mapaseparacaoonda
                (idonda, idlote, identificador, etapa, ordem, idlocalorigem,
                 idlocaldestino, idproduto, qtde, qtdeunit, barra, industria)
              values
                (c_mapasOnda.idonda, c_mapasOnda.idlote,
                 c_mapasOnda.identificador, c_mapasOnda.etapa,
                 c_mapasOnda.ordem, c_mapasOnda.idenderecoorigem,
                 c_mapasOnda.idenderecodestino, c_mapasOnda.idproduto,
                 v_qtdeUtilizada, (v_qtdeUtilizada * r_emb.fatorconversao),
                 r_emb.barra, c_mapasOnda.industria);
            end if;
          
            fetch c_emb
              into r_emb;
          end loop;
        
          close c_emb;
        
          if v_qtdeRestante <> 0 then
            v_msg := t_message('Erro ao distribuir quantidades de mapas de onda.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end loop;
      end distribuirPorEmb;
    
      procedure distribuirPorUnid is
      begin
        insert into gtt_paletseparacao
          (idarmazem, idlocal, idlote, idproduto, idromaneio, idpalet,
           barra, ordem, qtde, qtdeunit, separado, processado, liberado)
          select p.idarmazem, p.idlocalorigem, p.idlote, p.idproduto,
                 p.idonda, 1,
                 pk_produto.RetornarCodBarraMenorFator(p.idproduto), p.ordem,
                 p.qtdeUnit, p.qtdeUnit, 'N', 'N', 'N'
            from (select g.idarmazem, g.idlocalorigem, g.idlote, g.idproduto,
                          g.idonda, g.ordem,
                          sum(g.qtdeMovimentadaUnit) qtdeUnit
                     from gtt_mapasOnda g
                    where g.fracionado = 1
                    group by g.idarmazem, g.idlocalorigem, g.idlote,
                             g.idproduto, g.idonda, g.ordem) p;
      
        insert into gtt_mapaseparacaoonda
          (idonda, identificador, etapa, ordem, idlocalorigem,
           idlocaldestino, idproduto, qtde, qtdeunit, barra, industria)
          select p.idonda, p.identificador, p.etapa, p.ordem,
                 p.idenderecoorigem, p.idenderecodestino, p.idproduto,
                 p.qtdeUnit, p.qtdeUnit,
                 pk_produto.RetornarCodBarraMenorFator(p.idproduto),
                 p.industria
            from (select g.idonda, g.identificador, g.etapa, g.ordem,
                          g.idenderecoorigem, g.idenderecodestino, g.idproduto,
                          sum(g.qtdeMovimentadaUnit) qtdeUnit, g.industria
                     from gtt_mapasOnda g
                    where g.fracionado = 1
                    group by g.idonda, g.identificador, g.etapa, g.ordem,
                             g.idenderecoorigem, g.idenderecodestino,
                             g.idproduto, g.industria) p;
      end distribuirPorUnid;
    
      procedure inserirDados is
      begin
        insert into paletseparacao
          (idarmazem, idlocal, idlote, idproduto, idromaneio, idpalet,
           barra, ordem, separado, processado, liberado, qtde, qtdeunit)
          select p.idarmazem, p.idlocal, p.idlote, p.idproduto, p.idromaneio,
                 p.idpalet, p.barra, p.ordem, p.separado, p.processado,
                 p.liberado, sum(p.qtde), sum(p.qtdeUnit)
            from gtt_paletseparacao p
           group by p.idarmazem, p.idlocal, p.idlote, p.idproduto,
                    p.idromaneio, p.idpalet, p.barra, p.ordem, p.separado,
                    p.processado, p.liberado;
      
        insert into mapaseparacaoonda
          (idmapaseparacaoonda, idonda, identificador, etapa, ordem,
           idlocalorigem, idlocaldestino, idproduto, barra, industria, qtde,
           qtdeunit)
          select seq_mapaseparacaoonda.nextval, m.idonda, m.identificador,
                 m.etapa, m.ordem, m.idlocalorigem, m.idlocaldestino,
                 m.idproduto, m.barra, m.industria, m.qtde, m.qtdeUnit
            from (select g.idonda, g.identificador, g.etapa, g.ordem,
                          g.idlocalorigem, g.idlocaldestino, g.idproduto,
                          g.barra, g.industria, sum(g.qtde) qtde,
                          sum(g.qtdeUnit) qtdeUnit
                     from gtt_mapaseparacaoonda g
                    group by g.idonda, g.identificador, g.etapa, g.ordem,
                             g.idlocalorigem, g.idlocaldestino, g.idproduto,
                             g.barra, g.industria) m;
      end inserirDados;
    begin
      distribuirPorEmb;
    
      distribuirPorUnid;
    
      inserirDados;
    end inserirMapasPaletSep;
  
    procedure inserirMapaSepCli is
      v_msg t_message;
    
      procedure distribuirPorEmb is
        r_emb           c_emb%rowtype;
        v_qtdeRestante  number;
        v_qtdeUtilizada number;
      begin
        if v_tipoVisualizacao not in (2, 3) then
          return;
        end if;
      
        for c_mapasOnda in (select g.idonda, g.identificador, g.etapa,
                                   g.ordem, g.idenderecoorigem idlocalorigem,
                                   g.idenderecodestino idlocaldestino,
                                   g.idproduto, g.idnotafiscal, g.industria,
                                   g.dtvenc, g.idlote,
                                   sum(g.qtdeMovimentadaUnit) qtdeUnit
                              from gtt_mapasOnda g
                             where g.fracionado = 0
                             group by g.idonda, g.identificador, g.etapa,
                                      g.ordem, g.idenderecoorigem,
                                      g.idenderecodestino, g.idproduto,
                                      g.idnotafiscal, g.industria, g.dtvenc,
                                      g.idlote)
        loop
          v_qtdeRestante := c_mapasOnda.qtdeUnit;
        
          open c_emb(c_mapasOnda.idproduto, v_qtdeRestante);
          fetch c_emb
            into r_emb;
          while (v_qtdeRestante > 0)
                and (c_emb%found)
          loop
            v_qtdeUtilizada := trunc(v_qtdeRestante / r_emb.fatorconversao);
            if v_qtdeUtilizada > 0 then
              v_qtdeRestante := v_qtdeRestante -
                                (v_qtdeUtilizada * r_emb.fatorconversao);
            
              insert into gtt_mapasepondapedido
                (idonda, identificador, etapa, ordem, idlocalorigem,
                 idlocaldestino, idproduto, barra, idnotafiscal, industria,
                 dtvenc, idlote, qtde, qtdeunit)
              values
                (c_mapasOnda.idonda, c_mapasOnda.identificador,
                 c_mapasOnda.etapa, c_mapasOnda.ordem,
                 c_mapasOnda.idlocalorigem, c_mapasOnda.idlocaldestino,
                 c_mapasOnda.idproduto, r_emb.barra,
                 c_mapasOnda.idnotafiscal, c_mapasOnda.industria,
                 c_mapasOnda.dtvenc, c_mapasOnda.idlote, v_qtdeUtilizada,
                 (v_qtdeUtilizada * r_emb.fatorconversao));
            
            end if;
          
            fetch c_emb
              into r_emb;
          end loop;
        
          close c_emb;
        
          if v_qtdeRestante <> 0 then
            v_msg := t_message('Erro ao distribuir quantidades de mapas de onda.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end loop;
      end distribuirPorEmb;
    
      procedure distribuirPorLote is
      begin
        if v_tipoVisualizacao not in (4) then
          return;
        end if;
      
        insert into gtt_mapasepondapedido
          (idonda, identificador, etapa, ordem, idlocalorigem,
           idlocaldestino, idproduto, barra, idnotafiscal, industria, dtvenc,
           idlote, qtde, qtdeunit)
          select g.idonda, g.identificador, g.etapa, g.ordem,
                 g.idenderecoorigem idlocalorigem,
                 g.idenderecodestino idlocaldestino, g.idproduto, g.barra,
                 g.idnotafiscal, g.industria, g.dtvenc, g.idlote,
                 sum(g.qtdeMovimentadaUnit / g.fatorlote),
                 sum(g.qtdeMovimentadaUnit) qtdeUnit
            from gtt_mapasOnda g
           where g.fracionado = 0
           group by g.idonda, g.identificador, g.etapa, g.ordem,
                    g.idenderecoorigem, g.idenderecodestino, g.idproduto,
                    g.barra, g.idnotafiscal, g.industria, g.dtvenc, g.idlote;
      end distribuirPorLote;
    
      procedure distribuirPorUnid is
      begin
        insert into gtt_mapasepondapedido
          (idonda, identificador, etapa, ordem, idlocalorigem,
           idlocaldestino, idproduto, barra, idnotafiscal, industria, dtvenc,
           idlote, qtde, qtdeunit)
          select p.idonda, p.identificador, p.etapa, p.ordem,
                 p.idlocalorigem, p.idlocaldestino, p.idproduto,
                 pk_produto.RetornarCodBarraMenorFator(p.idproduto),
                 p.idnotafiscal, p.identificador, p.dtvenc, p.idlote,
                 qtdeUnit, qtdeUnit
            from (select g.idonda, g.identificador, g.etapa, g.ordem,
                          g.idenderecoorigem idlocalorigem,
                          g.idenderecodestino idlocaldestino, g.idproduto,
                          g.idnotafiscal, g.industria, g.dtvenc, g.idlote,
                          sum(g.qtdeMovimentadaUnit) qtdeUnit
                     from gtt_mapasOnda g
                    where g.fracionado = 1
                       or (g.fracionado = 0 and
                          v_tipoVisualizacao not in (2, 3, 4))
                    group by g.idonda, g.identificador, g.etapa, g.ordem,
                             g.idenderecoorigem, g.idenderecodestino,
                             g.idproduto, g.idnotafiscal, g.industria,
                             g.dtvenc, g.idlote) p;
      end distribuirPorUnid;
    
      procedure inserirDados is
      begin
        insert into mapasepondapedido
          (idmapasepondapedido, idonda, identificador, etapa, ordem,
           idlocalorigem, idlocaldestino, idproduto, barra, idnotafiscal,
           industria, dtvenc, idlote, qtde, qtdeunit)
          select seq_mapaseparacaoonda.nextval, m.idonda, m.identificador,
                 m.etapa, m.ordem, m.idlocalorigem, m.idlocaldestino,
                 m.idproduto, m.barra, m.idnotafiscal, m.industria, m.dtvenc,
                 m.idlote, m.qtde, m.qtdeunit
            from (select g.idonda, g.identificador, g.etapa, g.ordem,
                          g.idlocalorigem, g.idlocaldestino, g.idproduto,
                          g.barra, g.idnotafiscal, g.industria, g.dtvenc,
                          g.idlote, sum(g.qtde) qtde, sum(g.qtdeunit) qtdeunit
                     from gtt_mapasepondapedido g
                    group by g.idonda, g.identificador, g.etapa, g.ordem,
                             g.idlocalorigem, g.idlocaldestino, g.idproduto,
                             g.barra, g.idnotafiscal, g.industria, g.dtvenc,
                             g.idlote) m;
      end inserirDados;
    begin
      distribuirPorEmb;
    
      distribuirPorLote;
    
      distribuirPorUnid;
    
      inserirDados;
    end inserirMapaSepCli;
  begin
    limparDados;
  
    preencherDadosIniciais;
  
    inserirRomaneio;
  
    inserirPalete;
  
    inserirProdutoPalete;
  
    inserirPaletSepCliente;
  
    inserirMapasPaletSep;
  
    inserirMapaSepCli;
  
    preencherPaletSepNFOnda(p_idonda);
  end;

  procedure posFormarOnda
  (
    p_idonda         in number,
    p_idconfiguracao in number,
    p_idUsuario      in number,
    p_tipoOnda       in number
  ) is
  
    r_onda     romaneiopai%rowtype;
    r_confonda configuracaoonda%rowtype;
    v_msg      t_message;
    v_qtdePS   number;
  
    C_TIPOONDA_EXPEDICAO           constant number := 0;
    C_FATURAR_PEDIDO_APOS_FORMONDA constant number := 2;
  
    procedure getConfiguracaoOnda
    (
      p_idOnda   in number,
      r_confonda in out configuracaoonda%rowtype
    ) is
    begin
      select c.*
        into r_confonda
        from romaneiopai r, configuracaoonda c
       where r.idromaneio = p_idOnda
         and c.idconfiguracaoonda = r.idconfiguracaoonda;
    end getConfiguracaoOnda;
  
    procedure carregarOndaEconfOnda is
    begin
      select *
        into r_onda
        from romaneiopai r
       where r.idromaneio = p_idonda
       for update;
    
      getConfiguracaoOnda(p_idOnda, r_confonda);
    end carregarOndaEconfOnda;
  
    procedure calcularNumeroVolumes is
    
      v_loteuniconovolume number;
      v_qtdeNaoCalculada  number;
      v_statusonda        number;
      v_volume            number;
    
      --cursor para trazer dados com fator igual a 1 e caixa fechada
      -- deve olhar neste caso para a barra do lote e nao para o lote Original
      cursor comFatorIgual1 is
        select m.idnotafiscal, l.idproduto, l.dtvenc, l.descr,
               sum(m.quantidade) qtdeVolumes, l.idlote
          from GTT_MOVIMENTACAOVOLUME m, lote l, produtodepositante pd,
               embalagem e
         where m.idonda = r_onda.idromaneio
           and m.etapa = 1
           and m.utilizado = 0
           and l.idlote = m.idlote
           and e.idproduto = l.idproduto
           and e.barra = l.barra
           and pd.idproduto = l.idproduto
           and pd.identidade = l.iddepositante
           and pd.loteuniconovolume = 1
           and e.fatorconversao = 1
           and e.caixafechada = 'S'
         group by m.idonda, m.idnotafiscal, l.idproduto, l.descr, l.dtvenc,
                  l.idlote;
    
      --cursor para trazer dados com fator maior que 1 
      cursor comFatorMaiorQue1 is
        select m.idnotafiscal, l.idproduto, l.dtvenc, l.descr,
               trunc(sum((m.quantidade / eo.fatorconversao))) qtdeVolumes,
               l.idlote
          from GTT_MOVIMENTACAOVOLUME m, lote l, embalagem eo,
               produtodepositante pd
         where m.idonda = r_onda.idromaneio
           and m.etapa = 1
           and m.utilizado = 0
           and l.idlote = m.idlote
           and eo.idproduto = l.idproduto
           and eo.barra = l.barraoriginal
           and pd.idproduto = l.idproduto
           and pd.identidade = l.iddepositante
           and pd.loteuniconovolume = 1
           and eo.fatorconversao > 1
         group by m.idonda, m.idnotafiscal, l.idproduto, l.descr, l.dtvenc,
                  l.idlote;
    
      --cursor para trazer dados do resto do fator maior   
      cursor comRestoIgual1 is
        select J.idnotafiscal, J.idproduto, J.dtvenc, J.descr,
               sum(J.qtdeVolumes) quantidade, max(fatorconversao) fator
          from (select x.idnotafiscal, x.idproduto, x.dtvenc, x.descr,
                        sum(x.qtdeVolumes) qtdeVolumes, x.fatorconversao
                   from (select m.idnotafiscal, l.idproduto, l.dtvenc, l.descr,
                                 ((sum((m.quantidade / eo.fatorconversao)) -
                                  trunc(sum((m.quantidade / eo.fatorconversao)))) *
                                  eo.fatorconversao) qtdeVolumes,
                                 eo.fatorconversao, l.idlote
                            from GTT_MOVIMENTACAOVOLUME m, lote l, embalagem eo,
                                 produtodepositante pd
                           where m.idonda = r_onda.idromaneio
                             and m.etapa = 1
                             and m.utilizado = 1
                             and l.idlote = m.idlote
                             and eo.idproduto = l.idproduto
                             and eo.barra = l.barraoriginal
                             and pd.idproduto = l.idproduto
                             and pd.identidade = l.iddepositante
                             and pd.loteuniconovolume = 1
                             and eo.fatorconversao > 1
                           group by m.idonda, m.idnotafiscal, l.idproduto,
                                    l.descr, l.dtvenc, eo.fatorconversao,
                                    l.idlote) x
                  group by x.idnotafiscal, x.idproduto, x.dtvenc, x.descr,
                           x.fatorconversao
                 union all
                 select m.idnotafiscal, l.idproduto, l.dtvenc, l.descr,
                        sum(m.quantidade) qtdeVolumes,
                        pk_onda.fc_fator(r_onda.idromaneio, l.idproduto,
                                          l.iddepositante, l.descr, l.dtvenc) as fatorconversao
                   from GTT_MOVIMENTACAOVOLUME m, lote l, embalagem eo,
                        produtodepositante pd
                  where m.idonda = r_onda.idromaneio
                    and m.etapa = 1
                    and m.utilizado = 0
                    and l.idlote = m.idlote
                    and eo.idproduto = l.idproduto
                    and eo.barra = l.barraoriginal
                    and pd.idproduto = l.idproduto
                    and pd.identidade = l.iddepositante
                    and pd.loteuniconovolume = 1
                    and eo.fatorconversao = 1
                  group by m.idonda, m.idnotafiscal, l.idproduto, l.descr,
                           l.dtvenc,
                           pk_onda.fc_fator(r_onda.idromaneio, l.idproduto,
                                             l.iddepositante, l.descr, l.dtvenc)) J
         group by J.idnotafiscal, J.idproduto, J.dtvenc, J.descr;
    
    begin
    
      --recupera status da onda
      select statusonda
        into v_statusonda
        from romaneiopai
       where idromaneio = r_onda.idromaneio;
    
      --se gerada com corte sai da rotina
      if (v_statusonda = 6) then
        return;
      end if;
    
      --se a configuracao de onda esta marcada para calcular volume
      if (r_confonda.calcularnumerovolumes = 0) then
        return;
      end if;
    
      --indefinido
      select sum(1)
        into v_loteuniconovolume
        from nfromaneio nr, notafiscal nf, nfdet nd, produtodepositante pd
       where nr.idromaneio = r_onda.idromaneio
         and nr.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = nd.nf
         and nd.nf = nr.idnotafiscal
         and pd.idproduto = nd.idproduto
         and pd.identidade = nf.iddepositante
         and pd.loteuniconovolume = 0;
    
      if (v_loteuniconovolume > 0) then
        return;
      end if;
    
      /*
       Atualiza a gtt para gerar volume
      */
    
      insert into GTT_MOVIMENTACAOVOLUME
        (select idonda, idnotafiscal, etapa, idlote, 0 as utilizado,
                k.quantidade
           from movimentacao k
          where idonda = r_onda.idromaneio);
      /*Na GTT o campo Utilizado: 0 - nao utilizado, 1 - utilizado parcial, 2 - utilizado*/
    
      /*
      Para lotes que entraram com embalagens de fator de conversão igual a um, configuradas como caixa fechada, cada unidade será considerada como um volume. 
      O resultado das quantidades deve ser agrupado previamente por Onda, Nota Fiscal ou Pedido, Produto, Lote Indústria, Vencimento.
      */
    
      for calcFat1 in comFatorIgual1
      loop
        update nfromaneio nr
           set nr.qtdevolumescalculado = nvl(nr.qtdevolumescalculado, 0) +
                                         calcFat1.qtdeVolumes
         where idnotafiscal = calcFat1.idnotafiscal;
      
        update GTT_MOVIMENTACAOVOLUME
           set UTILIZADO = 2
         where IDONDA = r_onda.idromaneio
           and IDLOTE = calcFat1.idlote;
      
      end loop;
    
      /*
      Para lotes que entraram com embalagens de fator de conversão maior que um,configuradas como caixa fechada,
      será dividida a quantidade unitária pelo fator de conversão, sendo que o resultado da divisão sem resto, será o número de volumes contabilizado, sendo o resto da divisão separado para aplicação da "Regra 3". 
      O resultado das quantidades deve ser agrupado previamente por Onda, Nota Fiscal ou Pedido, Produto, Lote Indústria, Vencimento.
      */
      for calcFatMaior1 in comFatorMaiorQue1
      loop
        update nfromaneio nr
           set nr.qtdevolumescalculado = nvl(nr.qtdevolumescalculado, 0) +
                                         calcFatMaior1.qtdeVolumes
         where idnotafiscal = calcFatMaior1.idnotafiscal;
      
        update GTT_MOVIMENTACAOVOLUME
           set UTILIZADO = 1
         where IDONDA = r_onda.idromaneio
           and IDLOTE = calcFatMaior1.idlote;
      
      end loop;
    
      /*
      Para lotes com fator de conversão igual a um e não configurados como caixa fechada OU quantidades que são resto da divisão da "Regra 2", 
      serão somadas as quantidades, agrupando previamente por Onda, Nota Fiscal ou Pedido, Produto, Lote Indústria, Vencimento.
      Posteriormente será dividida a quantidade unitária pelo fator de conversão obtido pela regra abaixo, arredondando o resultado para um número acima caso o resultado seja fracionado.
      */
    
      for comResto in comRestoIgual1
      loop
      
        -- seta a variavel v_volume como 1 e depois calcula o volume  e se tiver resto ainda soma mais um volume
        v_volume := 1;
      
        if comResto.fator > 1 then
        
          if ((comResto.quantidade / comResto.fator) -
             trunc(comResto.quantidade / comResto.fator)) > 0 then
            v_volume := trunc(comResto.quantidade / comResto.fator) + 1;
          else
            v_volume := trunc(comResto.quantidade / comResto.fator);
          end if;
        
        end if;
      
        update nfromaneio nr
           set nr.qtdevolumescalculado = nvl(nr.qtdevolumescalculado, 0) +
                                         v_volume
         where idnotafiscal = comResto.idnotafiscal;
      
      end loop;
    
      --valida se tem nota sem calculo de volume
      select count(idnotafiscal)
        into v_qtdeNaoCalculada
        from nfromaneio
       where idromaneio = r_onda.idromaneio
         and (qtdevolumescalculado is null or qtdevolumescalculado = 0);
    
      if (v_qtdeNaoCalculada > 0) then
        v_msg := t_message('Erro ao calcular quantidade de volumes na notafiscal. Geracao interrompida.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end calcularNumeroVolumes;
  
    procedure faturarNotasAposFormacao is
    
      r_infoRomaneio pk_integracao.t_inforomaneio;
    
    begin
    
      if r_onda.statusonda = 1 then
      
        r_inforomaneio.idarmazem            := r_onda.idarmazem;
        r_inforomaneio.idromaneio           := r_onda.idromaneio;
        r_inforomaneio.codigointerno        := r_onda.codigointerno;
        r_inforomaneio.tituloromaneio       := r_onda.tituloromaneio;
        r_inforomaneio.tipo                 := r_onda.tipo;
        r_inforomaneio.separado             := r_onda.separado;
        r_inforomaneio.pesagemliberada      := r_onda.pesagemliberada;
        r_inforomaneio.idusuarioconferencia := r_onda.idusuarioconferencia;
        r_inforomaneio.statusonda           := r_onda.statusonda;
        r_inforomaneio.idconfiguracaoonda   := r_onda.idconfiguracaoonda;
      
        for c_nfr in (select nfr.idnotafiscal
                        from nfromaneio nfr, romaneiopai rp, notafiscal nf,
                             depositante d, configuracaoonda co
                       where nfr.idromaneio = r_onda.idromaneio
                         and nf.idnotafiscal = nfr.idnotafiscal
                         and rp.idromaneio = nfr.idromaneio
                         and rp.idconfiguracaoonda = co.idconfiguracaoonda
                         and d.identidade = nf.iddepositante
                         and decode(co.momentofaturamentopedido, 5,
                                    d.momentofaturamentopedido,
                                    co.momentofaturamentopedido) =
                             C_FATURAR_PEDIDO_APOS_FORMONDA
                         and d.faturamentoautomoatico > 0)
        loop
          pk_integracao.expFaturamentoPedido(c_nfr.idnotafiscal,
                                             r_onda.idromaneio, null, null,
                                             r_inforomaneio);
        end loop;
      
      end if;
    
    end faturarNotasAposFormacao;
  begin
    carregarOndaEconfOnda;
  
    select count(1)
      into v_qtdePS
      from paletseparacaonf p
     where p.idromaneio = p_idonda;
  
    if v_qtdePS > 0 then
      return;
    end if;
  
    if p_tipoOnda = C_TIPOONDA_EXPEDICAO then
      preencherInfSeparacao(p_idonda, p_idconfiguracao);
    
      pk_coberturafiscal.geracaoNFRetornoArmazenagem(p_idonda, p_idUsuario);
    
      calcularNumeroVolumes;
    end if;
  
    faturarNotasAposFormacao;
  
    pk_utilities.GeraLog(p_idUsuario, 'Gerados dados pós formação de ondas para a onda de id: ' || p_idOnda, p_idOnda,
                         'FO');
  end posFormarOnda;

  procedure agendarPosFormarOnda
  (
    p_idonda         in number,
    p_idconfiguracao in number,
    p_idUsuario      in number,
    p_tipoOnda       in number
  ) is
    PRAGMA AUTONOMOUS_TRANSACTION;
  
    X NUMBER;
  begin
  
    SYS.DBMS_JOB.SUBMIT(job => X,
                        what => '
declare
  v_existeRomaneio number;
  v_qtde           number;
begin
  v_existeRomaneio := 0;
  v_qtde           := 0;
  while (v_existeRomaneio = 0 and v_qtde <= 4)
  loop
    select count(1)
      into v_existeRomaneio
      from romaneiopai
     where idromaneio = ' || p_idonda || ';
  
    if v_existeRomaneio = 0 then
      dbms_lock.sleep(5);
      v_qtde := v_qtde + 1;
    else
      pk_onda_inf.posFormarOnda(' || p_idonda || ',
                                ' ||
                                 p_idconfiguracao || ',
                                ' ||
                                 p_idUsuario || ', 
                                ' ||
                                 p_tipoOnda || ');
    end if;
  
  end loop;
  commit;
end;
', next_date => sysdate, interval => null,
                        no_parse => FALSE);
    COMMIT;
  end agendarPosFormarOnda;

end PK_ONDA_INF;
/

