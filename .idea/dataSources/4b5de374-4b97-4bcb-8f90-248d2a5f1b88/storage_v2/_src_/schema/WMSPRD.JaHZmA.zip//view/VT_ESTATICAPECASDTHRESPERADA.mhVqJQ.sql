create view VT_ESTATICAPECASDTHRESPERADA as
select t.dataesperadaembarque, t.horaesperadaembarque, sum(t.qtde) qtde_pecas,
       sum(decode(t.estoqueverificado, 'N', t.qtde, 0)) -
        sum(decode(t.statusnf, 'X', t.qtde, 0)) falta_liberar_estoque,
       sum(decode(t.estoqueverificado, 'S', t.qtde, 0)) estoque_liberado,
       sum(decode(t.statusnf, 'X', t.qtde, 0)) canceladas,
       sum(case
              when (t.estoqueverificado <> 'X') then
               0
              when (select count(1)
                      from nfdet
                     where nf = t.idnotafiscal
                       and qtdeatendida > 0) = 0 then
               t.qtde
              else
               0
            end) nao_liberada,
       sum(decode(t.idromaneio, null, 0, t.qtde)) em_onda,
       sum(decode(t.separado, '0', t.qtde, 0)) falta_separar,
       sum(decode(t.separado, '1', t.qtde, 0)) separados,
       sum(decode(t.conferido, '1', t.qtde, 0)) conferidos,
       sum(decode(t.statusdoc, '9', t.qtde, 0)) expedidos
  from (select trunc(nf.dataesperadaembarque) dataesperadaembarque,
                to_number(to_char(nf.dataesperadaembarque, 'hh24')) horaesperadaembarque,
                nf.idnotafiscal, nd.qtde, nf.estoqueverificado, nf.statusnf,
                rp.idromaneio, s.separado, s.conferido, nfi.statusdoc
         
           from notafiscal nf, nfdet nd, nfimpressao nfi, nfromaneio nfr,
                romaneiopai rp, saidapornf s,
                (select rc.identidade, stragg(r.descr) rota,
                         stragg(r.codigo) codrota
                    from rotacliente rc, rotas r
                   where r.idrota = rc.idrota
                   group by rc.identidade) r
          where r.identidade(+) = nf.ident_entrega
            and nd.nf = nf.idnotafiscal
            and rp.idromaneio(+) = nfr.idromaneio
            and nfr.idnotafiscal(+) = nf.idnotafiscal
            and s.idnotafiscal(+) = nf.idnotafiscal
            and nfi.idprenf = nf.idprenf
            and trunc(nf.dataesperadaembarque) >= trunc(sysdate - 10)
            and nvl(nf.sequencia, ' ') not like 'AJUSTE%'
            and nvl(nf.sequencia, ' ') not like 'DEV%'
            and nvl(nf.sequencia, ' ') not like 'AVARIA%'
            and nf.tipo = 'S'
            and trunc(nf.dataesperadaembarque) >= trunc(sysdate - 1)) t
 group by t.dataesperadaembarque, t.horaesperadaembarque
 order by t.dataesperadaembarque, t.horaesperadaembarque
/

