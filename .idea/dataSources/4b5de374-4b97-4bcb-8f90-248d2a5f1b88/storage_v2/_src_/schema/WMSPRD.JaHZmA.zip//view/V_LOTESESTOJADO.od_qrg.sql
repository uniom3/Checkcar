create view V_LOTESESTOJADO as
select "MARCADO", "IDLOTE", "LOTEINDUSTRIA", "CODIGOINTERNO",
       "IDLOCALFORMATADO", "QTDEUTILIZADA", "QTDEDISPONIVEL", "DESCR",
       "IDPRODUTO", "IDLOCAL", "IDENDERECO", "H$IDARMAZEM",
       "H$IDDEPOSITANTE"
  from (select 0 marcado, lt.idlote, lt.descr loteindustria, p.codigointerno,
                l.idlocalformatado, 0 qtdeutilizada,
                (nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                 nvl(ll.adicionar, 0)) qtdedisponivel, p.descr, lt.idproduto,
                l.idlocal, ll.idendereco, lt.idarmazem h$idarmazem,
                lt.iddepositante h$iddepositante
           from lote lt, produto p, lotelocal ll, local l
          where p.idproduto = lt.idproduto
            and ll.idlote = lt.idlote
            and l.id = ll.idendereco
            and exists (select 1
                   from receitaestojamentolote re, ordemservico os
                  where re.idlote = lt.idlote
                    and re.idos = os.idordemservico)
         
         union
         
         select 0 marcado, lt.idlote, lt.descr loteindustria, p.codigointerno,
                l.idlocalformatado, 0 qtdeutilizada,
                (nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                 nvl(ll.adicionar, 0)) qtdedisponivel, p.descr, lt.idproduto,
                l.idlocal, ll.idendereco, lt.idarmazem h$idarmazem,
                lt.iddepositante h$iddepositante
           from lote lt, produto p, lotelocal ll, local l
          where p.idproduto = lt.idproduto
            and ll.idlote = lt.idlote
            and l.id = ll.idendereco
            and not exists (select 1
                   from receitaestojamentolote r
                  where r.idlote = lt.idlote)
            and exists
          (select 1
                   from receitaestojamentolote re, ordemservico os
                  where re.idlote = pk_lote.getIdLoteAnterior(lt.idlote)
                    and re.idos = os.idordemservico)) v
 order by v.idlote desc
/

