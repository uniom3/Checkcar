create view VT_PRODUTIVIDADECONFSAIDA as
select a.idarmazem h$idarmazem, to_char(a.datahora, 'yyyy/mm') anomes,
       u.nomeusuario usuario, a.liberado, a.idusuario,
       count(a.idromaneio) QTDEROMANEIO, sum(a.volumes) qtdevolumes,
       sum(a.linhas) qtdelinhas, sum(a.qtdeproduto) qtdeproduto,
       sum(a.pesoromaneio) pesoliquido, sum(a.pesobalanca) pesobruto,
       round(sum(a.tempo), 2) minutos
  from (select rp.idarmazem, rp.idromaneio, rp.codigointerno codromaneio,
                c.datahora, nvl(v.peso, 0) pesobalanca,
                rp.pesoteorico pesoromaneio, v.qtdevolumes volumes,
                c.idusuario, c.liberado, c.tempo, c.linhas, c.qtdeproduto
           from romaneiopai rp, palet p,
                (select cp.idromaneio, cp.idpalet, cp.idconf, cp.idusuario,
                         cp.liberado, max(cp.datahora) datahora, count(*) linhas,
                         sum(cp.qtde) qtdeproduto,
                         (max(cp.datahora) - min(cp.datahora)) * 24 * 60 tempo
                    from confpalet cp
                   group by cp.idromaneio, cp.idpalet, cp.idconf, cp.idusuario,
                            cp.liberado) c,
                (select idromaneio, sum(peso) peso, count(idvolume) qtdevolumes
                    from volumeromaneio
                   group by idromaneio) v
          where v.idromaneio(+) = rp.idromaneio
            and c.idpalet(+) = p.idpalet
            and c.idromaneio(+) = p.idromaneio
            and p.idromaneio = rp.idromaneio
            and decode(rp.liberado, 'S', 1, 0) = 1
            and decode(rp.processado, 'X', 0, 1) = 1) a, usuario u
 where u.idusuario = a.idusuario
 group by a.idarmazem, to_char(a.datahora, 'yyyy/mm'), u.nomeusuario,
          a.liberado, a.idusuario
/

