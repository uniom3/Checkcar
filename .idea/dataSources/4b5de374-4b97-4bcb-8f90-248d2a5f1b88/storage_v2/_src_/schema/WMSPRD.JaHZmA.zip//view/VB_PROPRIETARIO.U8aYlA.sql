create view VB_PROPRIETARIO as
select razaosocial, identidade
   from entidade
/

