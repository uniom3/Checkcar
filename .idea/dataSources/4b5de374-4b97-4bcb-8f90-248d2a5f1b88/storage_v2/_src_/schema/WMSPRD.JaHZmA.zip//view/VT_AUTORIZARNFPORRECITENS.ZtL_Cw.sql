create view VT_AUTORIZARNFPORRECITENS as
select nd.rowid h$tableid,
         (case
            when (nf.ordemtransferencia = 1) then
             decode(((nd.qtde * e.fatorconversao) -
                    nvl((select sum(i.qtde)
                           from tdnitemnfdet i
                          where i.idnfdet = nd.idnfdet), 0)), 0, 1, 0)
            else
             decode(((nd.qtde * e.fatorconversao) -
                    nvl((select sum(i.qtde)
                           from itemopanfdet i
                          where i.idnfdet = nd.idnfdet), 0)), 0, 1, 0)
          end) avisoassociado, nf.codigointerno notafiscal,
         nf.sequencia serie, nd.numeroordemcompra pedido,
         p.codigointerno codproduto, p.descr produto, nd.barra,
         nd.qtde * e.fatorconversao qtdeunit,
         (case
            when (nf.ordemtransferencia = 1) then
             nvl((select sum(i.qtde)
                   from tdnitemnfdet i
                  where i.idnfdet = nd.idnfdet), 0)
            else
             nvl((select sum(i.qtde)
                   from itemopanfdet i
                  where i.idnfdet = nd.idnfdet), 0)
          end) qtdeassociada, e.descrreduzido embalagem, nd.qtde,
         e.fatorconversao fatorconversao, nd.precounitbruto valorunitbruto,
         nd.porcdesconto percentualdesconto,
         nd.precounitliquido valorunitliquido,
         nvl(nd.total, 0) valortotalbruto, nd.desconto valordesconto,
         nd.totalliquido valortotalliquido, e.apresentacao,
         nd.classificacaofiscal classificacaofiscal, nd.st csticms,
         nd.baseicms bcicms, nd.valoricms icms, nd.aliqicms aliqicms, nd.ipi,
         nd.aliqipi aliqipi, nd.idproduto, nd.idnfdet, nf.idnotafiscal,
         nf.iddepositante h$iddepositante,
         (case
            when (nf.ordemtransferencia = 1) then
             (select count(*)
                from dual
               where exists
               (select 1
                        from ordemtransferencia ot, ordemtransferenciaitem oti
                       where oti.idordemtransferencia = ot.idordemtransferencia
                         and (ot.idarmazem = nf.idarmazem or
                             nf.idarmazem is null)
                         and oti.idproduto = nd.idproduto))
            else
             (select count(*)
                from dual
               where exists (select 1
                        from ordemcompra o, itemordemcompra i
                       where i.idordemcompra = o.idordemcompra
                         and (o.iddepositante = nf.iddepositante or
                             o.iddepositante is null)
                         and (o.idarmazem = nf.idarmazem or
                             nf.idarmazem is null)
                         and i.idproduto = nd.idproduto))
          end) h$existeOrdemParaAssociar,
         (case
            when (nf.ordemtransferencia = 1) then
             (nd.qtde * e.fatorconversao) -
             nvl((select sum(i.qtde)
                   from tdnitemnfdet i
                  where i.idnfdet = nd.idnfdet), 0)
            else
             (nd.qtde * e.fatorconversao) -
             nvl((select sum(i.qtde)
                   from itemopanfdet i
                  where i.idnfdet = nd.idnfdet), 0)
          end) h$qtderestante
    from notafiscal nf, nfdet nd, produto p, embalagem e, gtt_selecao g
   where nd.nf = nf.idnotafiscal
     and p.idproduto = nd.idproduto
     and e.idproduto = nd.idproduto
     and e.barra = nd.barra
     and g.idselecionado = nd.nf
/

