create view V_EXPNOTAFISCAL as
select n.idprenf, n.codigointerno numero, n.sequencia serie,
       n.dataimportacao, n.tipo, e.codigointerno codigoemitente,
       e.razaosocial nomeemitente, e.fantasia fantasitaemitente,
       e.pessoa pessoaemitente,
       nvl(n.cnpj_emitente, decode(e.pessoa, 'J', e.cgc, e.cic)) cnpjemitente,
       e.inscrestadual inscrestadualemitente,
       e.inscrmunicipal inscrmunicipalemitente, ee.endereco endemitente,
       ee.bairro bairroemitente, ee.cep cepemitente,
       ee.cidade cidadeemitente, ee.uf ufemitente,
       ee.complemento complementoemitente, n.nome_dest nomedestinatario,
       n.fantasia_dest fantasiadestinatario,
       n.pessoa_dest pessoadestinatario, n.cnpj_dest cnpjdestinatario,
       n.inscrestadual_dest inscrestadualdestinatario,
       n.inscrmunicipal_dest inscrmunicipaldestinatario,
       n.endereco_dest enddestinatario, n.bairro_dest bairrodestinatario,
       n.cep_dest cepdestinatario, n.cidade_dest cidadedestinatario,
       n.estado_dest ufdestinatario,
       n.complementoend_dest complementodestinatario,
       d.codigointerno codigodepositante, d.razaosocial nomedepositante,
       d.fantasia fantasitadepositante, d.pessoa pessoadepositante,
       nvl(n.cnpj_depositante, decode(d.pessoa, 'J', d.cgc, d.cic)) cnpjdepositante,
       d.inscrestadual inscrestadualdepositante,
       d.inscrmunicipal inscrmunicipaldepositante,
       ed.endereco enddepositante, ed.bairro bairrodepositante,
       ed.cep cepdepositante, ed.cidade cidadedepositante,
       ed.uf ufdepositante, ed.complemento complementodepositante
  from nfimpressao n, notafiscal nf, entidade e, v_endereco ee, entidade d,
       v_endereco ed
 where ed.identidade(+) = nf.iddepositante
   and d.identidade = nf.iddepositante
   and ee.identidade(+) = nf.remetente
   and e.identidade = nf.remetente
   and nf.idprenf = n.idprenf
   and nvl(n.exportado, 'N') = 'N'
   and nvl(n.importacao, 'N') = 'S'
/

