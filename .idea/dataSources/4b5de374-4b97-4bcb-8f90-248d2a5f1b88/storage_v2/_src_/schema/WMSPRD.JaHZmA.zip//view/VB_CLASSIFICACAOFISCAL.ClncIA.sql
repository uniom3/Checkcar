create view VB_CLASSIFICACAOFISCAL as
select idclassificacao, codigo, descr classfiscal, letra
  from classificacaofiscal
/

