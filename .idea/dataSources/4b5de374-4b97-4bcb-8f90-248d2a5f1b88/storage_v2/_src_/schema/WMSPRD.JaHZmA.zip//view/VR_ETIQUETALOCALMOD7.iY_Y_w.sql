create view VR_ETIQUETALOCALMOD7 as
select l.idlocal, l.idlocalformatado idlocalformatado
  from gtt_selecao g, local l
 where l.id = g.idselecionado
 order by l.idlocal

/

