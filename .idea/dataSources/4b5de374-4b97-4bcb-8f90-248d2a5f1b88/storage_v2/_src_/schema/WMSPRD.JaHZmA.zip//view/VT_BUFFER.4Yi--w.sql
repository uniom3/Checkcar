create view VT_BUFFER as
select l.id h$id, l.idarmazem h$idarmazem, l.idlocal,
       decode(l.ativo, 'S', 1, 0) ativo, s.descr setor, l.idsetor,
       l.tipo h$tipo, r.idregiao h$idregiao, r.descr regiao,
       decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') tipolocal,
       l.idlocalformatado f$idlocal, l.ordem h$ordem, l.bufferesteira
  from local l, setor s, regiaoarmazenagem r
 where s.idsetor(+) = l.idsetor
   and r.idregiao(+) = l.idregiao
   and l.tipo in (0, 1, 3)
   and l.buffer = 'S'
/

