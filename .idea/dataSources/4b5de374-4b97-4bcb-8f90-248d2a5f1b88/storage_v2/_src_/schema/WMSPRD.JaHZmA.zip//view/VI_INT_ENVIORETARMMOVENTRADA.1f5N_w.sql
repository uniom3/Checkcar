create view VI_INT_ENVIORETARMMOVENTRADA as
select id, '@' I, '"' || serie || '"' serie,
       '"' || numdocumento || '"' numdocumento,
       '"' || datasaida || '"' datasaida,
       '"' || dataemissao || '"' dataemissao,
       '"' || uforigem || '"' uforigem,
       '"' || codmunicipioorigem || '"' codmunicipioorigem,
       '"' || totalcontabil || '"' totalcontabil,
       '"' || cancelado || '"' cancelado, '"' || cnpj || '"' cnpj,
       '"' || baseicms || '"' baseicms, '"' || valoricms || '"' valoricms,
       '"' || isentasicms || '"' isentasicms,
       '"' || outrasicms || '"' outrasicms,
       '"' || baseicmssubstituido || '"' baseicmssubstituido,
       '"' || icmssubstituido || '"' icmssubstituido, '"' || pis || '"' pis,
       '"' || cofins || '"' cofins
  from int_envioretmovarm_entrada
/

