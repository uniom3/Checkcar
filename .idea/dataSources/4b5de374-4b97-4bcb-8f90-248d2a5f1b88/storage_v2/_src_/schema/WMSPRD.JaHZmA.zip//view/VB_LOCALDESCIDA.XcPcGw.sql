create view VB_LOCALDESCIDA as
select idlocal, 'DOCA' tipo, d.descr doca, id h$idlocaldescida,
       a.descr h$armazem, lpad(l.localintegracao, 3, 0) h$localintegracao,
       l.id h$tableid, a.idarmazem h$idarmazem
  from local l, armazem a, doca d, setor s, regiaoarmazenagem r
 where d.idendereco(+) = l.id
   and a.idarmazem = l.idarmazem
   and l.ativo = 'S'
   and l.tipo = 4
   and s.idsetor = l.idsetor
   and r.idregiao = l.idregiao
/

