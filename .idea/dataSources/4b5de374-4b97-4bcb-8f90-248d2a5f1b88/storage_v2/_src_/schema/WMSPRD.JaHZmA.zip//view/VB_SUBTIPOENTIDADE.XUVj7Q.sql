create view VB_SUBTIPOENTIDADE as
select idsubtipo idsubtipo, descr subtipo
  from subtipo
/

