create view VT_CONFMODSEPONDA as
select cmo.id, cmo.bloco, cmo.rua,
       decode(ars.tipo, 1, 'Rainbow Rack', 2, 'Pallet Rack', 0, 'Pallet Floor') Tipo,
       decode(cmo.crescente, 0, 'Decrescente', 1, 'Crescente') Sentido,
       cmo.possuitrilho
  from configuracaomodoseparacaoonda cmo, areaseparacao ars
 where ars.bloco = cmo.bloco
/

