create view VI_INT_ENVIO_EMBALAGEM as
select agrupador id, 5 i, idproduto, barra, dr, descr, apresentacao,
       pk_produto.validaFatorConversao(fatorconv) fatorconv, altura, largura, comprimento,
       compra, venda, lastro, qtdecamada, pesobruto, pesoliquido, su, empmax,
       ativo, etiqueta, caixafechada, controlaestoque, seqemb,
       excluirembalagem, codprodutodep, codproduto, dr2, idreplicacao
  from int_envio_embalagem
/

