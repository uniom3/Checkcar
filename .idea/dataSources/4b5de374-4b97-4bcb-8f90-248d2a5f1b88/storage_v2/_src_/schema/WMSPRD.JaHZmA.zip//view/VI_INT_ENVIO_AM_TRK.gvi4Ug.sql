create view VI_INT_ENVIO_AM_TRK as
select distinct agrupador id, cnpjarmazem, cnpjtransportadora,
                cnpjdepositante, cnpjremetente, numerocoleta,
                numerocoletatransportador, quantidadevolumes, pesobruto,
                cubagemtotal, quantidadenotasfiscais, rgmotorista,
                nomemotorista, placaveiculo, dataliberacao, dataembarque,
                embarqueliberado, cnpjcpfdestinatario, numero, serie,
                chaveacesso, numeropedido, quantidadevolumesnf, pesobrutonf,
                cubagemtotalnf, nomedestinatario, nomefantasiadestinatario,
                logradouro, numeroendereco, complemento, bairro, cep, cidade,
                estado, telefone, basedecalculoicmsst, valoricmsst,
                basedecalculoicms, valortotalicms, valortotalprodutos,
                valortotalnfe, idnotafiscal, icmstransporte, dataHoraEmissao,
                cTipoEmbarque, xTipoEmbarque, cProd, cEANTrib, xProd, CFOP,
                NCM, vProd, numerocontrato, codigoadministrativo, nomerem,
                logradourorem, numeroenderecorem, complementorem, bairrorem,
                ceprem, cidaderem, estadorem, telefonerem, emailrem,
                cartaopostagem,
                decode(pesobrutoum, 0, 'GR', 1, 'KG', 'TON') pesobrutoum,
                decode(cubagemtotalum, 0, 'CM3', 'M3') cubagemtotalum,
                c.enviardadoscontrato, c.enviardadosremetente, i.basesigla,
                i.dhminimaentrega, i.dhmaximaentrega, c.envdtmaxminentrega,
                i.iedestinatario, i.ciffob
  from int_envio_am_trk i, entidade e, configuracaoxtrk c
 where i.cnpjtransportadora = e.cgc
   and e.idconfigxtrk = c.id
   and (exists
        (select 1
           from servicotransportadora s, transpdepositante td,
                servicotranspredespacho sr
          where td.idtranspdepositante = s.idtranspdepositante
            and sr.idservicotransportadora(+) = s.idservicotransportadora
            and ((td.idtransportadora = e.identidade) or
                (sr.idtransportadora = e.identidade))) or exists
        (select 1
           from depositante dp, entidade ed, configuracaoxtrk cfx
          where dp.identidade = ed.identidade
            and ed.cgc = i.cnpjdepositante
            and dp.idconfigxtrk = cfx.id
            and cfx.tipointegracaoembtransp = 2))
/

