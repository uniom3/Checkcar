create view V_DETMOV_SAIDA as
select nf.idnotafiscal id,
       trunc(nvl(nvl(rp.dataprocessamento, nf.dataemissao), nf.datacadastro)) datamov,
       nf.iddepositante identidade, nf.remetente, nf.destinatario,
       to_char(trunc(nvl(nvl(rp.dataprocessamento, nf.dataemissao), nf.datacadastro)), 'mm/yyyy') mesmov,
       to_char(to_date(to_char(trunc(nvl(nvl(rp.dataprocessamento, nf.dataemissao), nf.datacadastro)), 'mm/yyyy'), 'mm/yyyy'), 'Month "de" yyyy') mes,
       nf.idoperacao classificacao, NFD.idproduto, 'SAIDA' TipoMov,
       sum(nfd.qtdeatendida * e.fatorconversao) totalprod, sum(nfd.qtdeatendida) qtdenf, e.barra, e.fatorconversao, e.descrreduzido embalagem,
       sum(nvl((e.pesobruto * nfd.qtdeatendida) / 1000, 0)) totalpeso,
       sum(round((e.altura * e.largura * e.comprimento * nfd.qtdeatendida) /
                  1000000000, 3)) totalvolume, 1 totalnf,
       nf.codigointerno numnf
  from notafiscal nf, nfdet nfd, embalagem e,
       (select idnotafiscal,
                trunc(max(rp.dataprocessamento)) dataprocessamento
           from nfromaneio nfr, romaneiopai rp
          where rp.idromaneio = nfr.idromaneio
          group by idnotafiscal) rp
 where nf.tipo = 'S'
   and ((nf.statusnf = 'P') or (nf.reentrega = 'S'))
   and nfd.nf = nf.idnotafiscal
   and e.barra = nfd.barra
   and e.idproduto = nfd.idproduto
   and rp.idnotafiscal = nf.idnotafiscal
 group by nf.idnotafiscal,
          trunc(nvl(nvl(rp.dataprocessamento, nf.dataemissao), nf.datacadastro)),
          nf.iddepositante, nf.remetente, nf.destinatario, nf.idoperacao, NFD.idproduto, nf.codigointerno, e.barra, e.fatorconversao, e.descrreduzido
/

