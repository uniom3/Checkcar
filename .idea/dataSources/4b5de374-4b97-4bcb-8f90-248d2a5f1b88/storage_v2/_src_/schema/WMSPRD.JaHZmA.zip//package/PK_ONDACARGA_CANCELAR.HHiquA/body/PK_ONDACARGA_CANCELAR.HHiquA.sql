create package body PK_ONDACARGA_CANCELAR is

  C_TIPOONDA_ONDA             constant number := 0;
  C_TIPOONDA_CARGA            constant number := 1;
  C_CORTEFISICO_AGUARSOLUCAO  constant number := 0;
  C_STATUSSEPARACAO_CANCELADA constant number := 3;

  C_ONDA_REMOVER_NF constant number := 0;
  C_ONDA_CANCELAR   constant number := 1;

  procedure regerarMovimentacao
  (
    p_idOnda         in romaneiopai.idromaneio%type,
    p_idNotaFiscal   in notafiscal.idnotafiscal%type,
    p_tipoCancelarNF in number
  ) is
  
    reg_separacao  separacaoporcarga%rowtype;
    v_qtderetirada number;
    emb_menorFator embalagem%rowtype;
    v_msg          t_message;
  
    /* separacao que tem que ser alterada */
    cursor crs_sep_alterar
    (
      pc_idOnda       number,
      pc_idNotafiscal number
    ) is
      select distinct sc.idseparacaoporcarga, ra.idonda, pa.idlote,
                      pa.idarmazem
        from paleteondanf pa, reservaestoqueondacarga ra,
             separacaoporcarga sc
       where pa.idpaleteondanf = ra.idpaleteondanf
         and ra.idseparacaoporcarga = sc.idseparacaoporcarga
         and ra.idonda = pc_idOnda
         and pa.idnotafiscal = pc_idNotafiscal
       order by 1;
  
    cursor crs_palete_alterar
    (
      pc_idSeparacaoOndaCarga number,
      pc_idNotaFiscal         number
    ) is
      select po.idpaleteondanf, po.idonda, po.idnotafiscal, po.idlote,
             po.idlocal, po.idarmazem, po.qtde, po.placa, po.idpalete,
             po.paletecompleto, po.idpaleteauxiliar, po.pesounitario
        from paleteondanf po, reservaestoqueondacarga rs
       where po.idpaleteondanf = rs.idpaleteondanf
         and rs.idseparacaoporcarga = pc_idSeparacaoOndaCarga
         and po.idonda = p_idOnda
         and po.idnotafiscal <> pc_idNotaFiscal;
  
    reg_alterar      crs_sep_alterar%rowtype;
    v_idpaleteondanf paleteondanf.idpaleteondanf%type;
    v_qtdUnidade     number;
  
  begin
    open crs_sep_alterar(p_idOnda, p_idNotaFiscal);
    loop
      fetch crs_sep_alterar
        into reg_alterar;
      exit when crs_sep_alterar%notfound;
      -- recupera a separacao/tarefa que será alterada
      select *
        into reg_separacao
        from separacaoporcarga sc
       where sc.idseparacaoporcarga = reg_alterar.idseparacaoporcarga;
    
      -- recupera a quantidade que deverá ser removida 
      select sum(rs.qtde)
        into v_qtderetirada
        from paleteondanf po, reservaestoqueondacarga rs
       where po.idpaleteondanf = rs.idpaleteondanf
         and rs.idseparacaoporcarga = reg_alterar.idseparacaoporcarga
         and po.idnotafiscal = p_idNotaFiscal;
    
      -- retorna quantidade em unidade
      select (e.fatorconversao * reg_separacao.qtde)
        into v_qtdUnidade
        from embalagem e
       where e.barra = reg_separacao.barra
         and e.idproduto = reg_separacao.idproduto;
    
      select *
        into emb_menorFator
        from embalagem e
       where e.idproduto = reg_separacao.idproduto
         and e.barra =
             pk_produto.RetornarCodBarraMenorFator(reg_separacao.idproduto);
    
      if ((v_qtdUnidade > v_qtderetirada) and
         p_tipoCancelarNF = C_ONDA_REMOVER_NF) then
      
        -- cancela a separação/tarefa
        update separacaoporcarga sc
           set sc.status = 3
         where sc.idseparacaoporcarga = reg_alterar.idseparacaoporcarga;
      
        -- prepara uma nova separacao/tarefa com o restane
        select seq_separacaoporcarga.nextval
          into reg_separacao.idseparacaoporcarga
          from dual;
      
        reg_separacao.qtde := v_qtdUnidade - v_qtderetirada;
      
        if (mod(reg_separacao.qtde, emb_menorFator.Fatorconversao) <> 0) then
          v_msg := t_message('Não foi possível encontrar um fator de conversão correspondente.');
          raise_application_error(-20000, v_msg.formatMessage);
        else
          reg_separacao.barra := emb_menorFator.Barra;
        end if;
      
        insert into separacaoporcarga
        values reg_separacao;
      
        -- regera paleteondanf e reservaestoqueondacarga
        for dados in crs_palete_alterar(reg_alterar.idseparacaoporcarga,
                                        p_idNotaFiscal)
        loop
          insert into paleteondanf
            (idpaleteondanf, idonda, idnotafiscal, idlote, idlocal,
             idarmazem, qtde, placa, idpalete, paletecompleto,
             idpaleteauxiliar, pesounitario)
          values
            (seq_paleteondanf.nextval, dados.idonda, dados.idnotafiscal,
             dados.idlote, dados.idlocal, dados.idarmazem, dados.qtde,
             dados.placa, dados.idpalete, dados.paletecompleto,
             dados.idpaleteauxiliar, dados.pesounitario)
          returning idpaleteondanf into v_idpaleteondanf;
        
          insert into reservaestoqueondacarga
            select reg_separacao.idseparacaoporcarga, v_idpaleteondanf,
                   idonda, idlote, idlocal, idarmazem, qtde
              from reservaestoqueondacarga r
             where r.idpaleteondanf = dados.idpaleteondanf
               and r.idseparacaoporcarga = reg_alterar.idseparacaoporcarga;
        
        end loop;
      else
        -- cancela a separação/tarefa
        update separacaoporcarga sc
           set sc.status = 3
         where sc.idseparacaoporcarga = reg_alterar.idseparacaoporcarga;
      end if;
    end loop;
    close crs_sep_alterar;
  
  end regerarMovimentacao;

  -- Cancelar Movimentações
  procedure cancelarMovimentacoes
  (
    p_idonda         in number,
    p_idnotafiscal   in number,
    p_idusuario      in number,
    p_iddepositante  in number,
    p_tipoCancelarNF in number
  ) is
    CONFESCAN_CANCELADO   constant number := 7;
    CONFMONTVOL_CANCELADO constant number := 6;
    v_idlocalretornarestoque local.idlocal%type;
    v_configuracaoonda       configuracaoonda%rowtype;
    v_rastrearinfoespecifica number;
    v_msg                    t_message;
  begin
  
    begin
      select co.*
        into v_configuracaoOnda
        from configuracaoonda co, romaneiopai rp
       where co.idconfiguracaoonda = rp.idconfiguracaoonda
         and rp.idromaneio = p_idOnda;
    exception
      when no_data_found then
        v_msg := t_message('Configuração de Onda não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    -- Aqui a ideia e encontrar onde esta o estoque e aplicar as regras dependendo da sua posicao no armazem.
    for cm in (select f.idarmazem, f.idlocal, f.idlote, f.qtde,
                      f.estoquemovimentado, f.idproduto,
                      f.qtderetiraradicionarpicking
                 from (select fs.idarmazem, fs.idlocal, fs.idlote,
                               sum(fs.qtde) qtde, fs.estoquemovimentado,
                               fs.idproduto, fs.qtderetiraradicionarpicking
                          from (select rs.idarmazem, o.idlocal, rs.idlote,
                                        rs.qtde,
                                        decode(sc.status, 0, 'N', 'S') estoquemovimentado,
                                        sc.idproduto,
                                        0 qtderetiraradicionarpicking
                                   from paleteondanf o,
                                        reservaestoqueondacarga rs,
                                        separacaoporcarga sc
                                  where rs.idpaleteondanf = o.idpaleteondanf
                                    and rs.idseparacaoporcarga =
                                        sc.idseparacaoporcarga
                                    and sc.status in (0, 1)
                                    and o.idnotafiscal = p_idnotafiscal
                                    and rs.idonda = p_idonda
                                 
                                 union all
                                 
                                 select rs.idarmazem, ld.idlocal, rs.idlote,
                                        rs.qtde, 'S' estoquemovimentado,
                                        sc.idproduto,
                                        0 qtderetiraradicionarpicking
                                   from paleteondanf o,
                                        reservaestoqueondacarga rs,
                                        separacaoporcarga sc, destinosaidaonda ds,
                                        local ld
                                  where rs.idpaleteondanf = o.idpaleteondanf
                                    and rs.idseparacaoporcarga =
                                        sc.idseparacaoporcarga
                                    and sc.idonda = ds.idonda
                                    and ds.iddoca = ld.id
                                    and rs.idarmazem = ld.idarmazem
                                    and sc.status = 2
                                    and o.idnotafiscal = p_idnotafiscal
                                    and rs.idonda = p_idOnda) fs
                         group by fs.idarmazem, fs.idlocal, fs.idlote,
                                  fs.estoquemovimentado, fs.idproduto,
                                  fs.qtderetiraradicionarpicking
                         order by fs.idarmazem, fs.idlocal) f
                where f.qtde > 0
                order by f.idarmazem, f.idlocal, f.idlote)
    loop
      -- todos os casos devem retirar pendencia
      pk_estoque.retirar_pendencia(cm.idarmazem, cm.idlocal, cm.idlote,
                                   cm.qtde, p_idusuario,
                                   'NOTA FISCAL CANCELADA, REMOVIDO PENDENCIA PARA NOTAFISCAL ID:' ||
                                    p_idnotafiscal || ', ONDA:' || p_idonda);
    
      -- verifica se o estoque já foi movimentado e determina o local de retorno 
      if (cm.estoquemovimentado = 'S') then
        pk_onda_cancelar.getLocalRetornoEstoque(v_configuracaoonda,
                                                p_idonda, p_idnotafiscal,
                                                p_iddepositante,
                                                cm.idarmazem, cm.idproduto,
                                                cm.idlote, cm.qtde,
                                                cm.idlocal,
                                                v_idlocalretornarestoque);
      
        -- se o local que o estoque esta é o mesmo local de retorno do produto nao faz nada.
        -- caso contrario o estoque e movido para o local de retorno 
        if (v_idlocalretornarestoque <> cm.idlocal) then
          pk_estoque.retirar_estoque(cm.idarmazem, cm.idlocal, cm.idlote,
                                     cm.qtde, p_idusuario,
                                     'NOTA FISCAL CANCELADA, REMOVIDO ESTOQUE PARA NOTAFISCAL ID:' ||
                                      p_idnotafiscal || ', ONDA:' ||
                                      p_idonda, 'N', null);
        
          pk_estoque.incluir_estoque(cm.idarmazem, v_idlocalretornarestoque,
                                     cm.idlote, cm.qtde, p_idusuario,
                                     'NOTA FISCAL CANCELADA, ADICIONADO ESTOQUE PARA NOTAFISCAL ID:' ||
                                      p_idnotafiscal || ', ONDA:' ||
                                      p_idonda, 'N', null);
        
          --verifica se existe separacao especifica para o lote e se existir efetua as mudancas
          pk_lote.AlterarSeparacaoEspecifica(cm.idlote, cm.idarmazem,
                                             cm.idlocal,
                                             v_idlocalretornarestoque);
        
          insert into cancelamentoonda
            (id, idarmazem, idendorigem, idenddestino, idlote, qtde,
             idnotafiscal, idonda)
          values
            (seq_cancelamentoonda.nextval, cm.idarmazem, cm.idlocal,
             v_idlocalretornarestoque, cm.idlote, cm.qtde, p_idnotafiscal,
             p_idonda);
        end if;
      end if;
    
      v_rastrearinfoespecifica := pk_lote.getRastrearInfoEspecifica(cm.idlote);
      if (v_rastrearinfoespecifica = 0) then
        update estoqueinformacaoespecifica es
           set es.conferido        = 0,
               es.idconfpacking    = null,
               es.idnotafiscal     = null,
               es.idescaninho      = null,
               es.idvolumeromaneio = null,
               es.confmontvol      = 0,
               es.nrooperacao      = p_idnotafiscal,
               es.operacao         = 'RETIRADA NOTA FISCAL DA ONDA'
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      elsif (v_rastrearinfoespecifica = 1) then
        update estoqueinformacaoespecifica es
           set es.conferido        = 0,
               es.idconfpacking    = null,
               es.idlote           = null,
               es.idnotafiscal     = null,
               es.idescaninho      = null,
               es.idvolumeromaneio = null,
               es.confmontvol      = 0,
               es.nrooperacao      = p_idnotafiscal,
               es.operacao         = 'RETIRADA NOTA FISCAL DA ONDA'
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      elsif (v_rastrearinfoespecifica = 2) then
      
        insert into historicoestoqueinfespec
          (id, idarmazem, idproduto, identidade, idinfomaterial,
           identificadorinfo, numerooperacao, operacao, dataoperacao,
           valorantes, valordepois, idloteantes, idlotedepois,
           conferidoantes, conferidodepois, expedidoantes, expedidodepois)
          select seq_historicoestoqueinfespec.nextval, e.idarmazem,
                 e.idproduto, e.identidade, e.idinfomaterial,
                 e.identificadorinfo, p_idnotafiscal,
                 'RETIRADA NOTA FISCAL DA ONDA', sysdate, e.valor, e.valor,
                 e.idlote, e.idlote, e.conferido, e.conferido, e.expedida,
                 e.expedida
            from estoqueinformacaoespecifica e
           where e.idlote = cm.idlote
             and e.idnotafiscal = p_idnotafiscal;
      
        delete estoqueinformacaoespecifica es
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      end if;
    
    end loop;
  
    if (p_tipoCancelarNF = C_ONDA_REMOVER_NF) then
      regerarMovimentacao(p_idonda, p_idnotafiscal, p_tipoCancelarNF);
    end if;
  
    -- quando a onda é do tipo "Pedido Clube de Compra" existem volumes gerados
    update volumeromaneio vr
       set vr.statusvolume = 1
     where vr.idnotafiscal = p_idnotafiscal;
  
  end cancelarMovimentacoes;

  procedure cancelarNotaFiscal
  (
    p_idonda         in number,
    p_idnotafiscal   in number,
    p_idusuario      in number,
    p_tipoCancelarNF in number
  ) is
  
    r_notafiscal       notafiscal%rowtype;
    v_possuifalta      number;
    v_idpontoalerta    number;
    v_statusonda       number;
    v_NFRetArmazenagem number;
    v_msg              t_message;
  
  begin
  
    -- valida  se existe corte físcio para a onda e não por nota.                                
    select count(*)
      into v_possuifalta
      from cortefisico c
     where c.idonda = p_idonda
       and c.status = C_CORTEFISICO_AGUARSOLUCAO;
  
    if (v_possuifalta > 0) then
      v_msg := t_message('Não é permitido cancelar a nota fiscal com id {0}.' ||
                         'Ela possui registro de corte fisico pendente de resolução. Resolva o corte primeiro.');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Validar Status NF e roteirizacao
    pk_onda_cancelar.validarStatusNF(r_notafiscal, p_idnotafiscal,
                                     v_idpontoalerta);
  
    -- Verificar se a nota fiscal de venda possui nota fiscal de remessa por conta de terceiro
    pk_onda_cancelar.cancNotaFiscalRemessaTerceiro(r_notafiscal.idnotafiscal,
                                                   p_idusuario);
    -- retinar Pontos de Alerta
    pk_onda_cancelar.removerPontoAlerta(v_idpontoalerta);
    -- Remover a NF da Coleta 
    pk_onda_cancelar.validarNfColetaAutomatica(p_idonda, p_idnotafiscal);
    pk_onda_cancelar.retirarNfDaCaleta(p_idnotafiscal);
    -- Cancelar troca de Lotes
    pk_onda_cancelar.cancelarTrocaLote(p_idonda, p_idnotafiscal);
    -- Cancelar/regerar moviemntações de estoque
    cancelarMovimentacoes(p_idonda, p_idnotafiscal, p_idusuario,
                          r_notafiscal.iddepositante, p_tipoCancelarNF);
    pk_remanejamento.desfazerRemanejamento(p_idonda, p_idusuario, 1,
                                           p_idnotafiscal);
    pk_remanejamento.desfazRemanejBuffPickParaPick(p_idonda, p_idnotafiscal,
                                                   p_idusuario);
    pk_onda_cancelar.retirarBaixaEfetiva(p_idonda, p_idnotafiscal,
                                         p_idusuario);
    pk_onda_cancelar.voltarImpressaoNF(p_idNotaFiscal);
  
    update notafiscal nf
       set nf.imprimeetiquetatransportador = 0,
           nf.qtdevolumescontrolado        = null
     where nf.idnotafiscal = p_idnotafiscal;
  
    select r.statusonda
      into v_statusOnda
      from romaneiopai r
     where r.idromaneio = p_idonda;
  
    pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    update nfdet
       set qtdeatendida = 0
     where nf = p_idnotafiscal;
    pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    update nfdetimpressao
       set qtdeatendida = 0
     where idprenf = r_notafiscal.idprenf;
  
    -- se o status da onda for EM_FORMACAO(0)  significa que o cancelamento esta sendo
    -- chamado pela formacao da onda e ela possui corte. Neste caso as notas fiscais não devem
    -- ser retiradas da onda, somente o estoque deve ser retirado a reserva.
    if (v_statusOnda not in (0, 6)) then
      select count(*)
        into v_NFRetArmazenagem
        from dual
       where exists (select 1
                from retornosimbolico rs, notafiscal nf, operacao op,
                     depositante d, regime r
               where rs.idnotafiscalretorno = p_idnotafiscal
                 and nf.idnotafiscal = rs.idnotafiscalvenda
                 and op.idoperacao = nf.idoperacao
                 and d.identidade = nf.iddepositante
                 and r.idregime = d.idregime
                 and r.classificacao = 'A'
                 and op.tipooper in ('TA', 'G'));
    
      if v_NFRetArmazenagem = 1 then
        pk_notafiscal.desfazerNFRetArmazenagemOnda(p_idonda, p_idnotafiscal,
                                                   p_idusuario);
      end if;
    
      -- Verificando se existem notas de retorno simbólico geradas para a nota de venda (Séculus)
      for c_NFRetSimb in (select rs.idnotafiscalretorno
                            from retornosimbolico rs, notafiscal nf,
                                 operacao op, depositante d, regime r
                           where rs.idnotafiscalvenda = p_idnotafiscal
                             and nf.idnotafiscal = rs.idnotafiscalretorno
                             and op.idoperacao = nf.idoperacao
                             and d.identidade = nf.iddepositante
                             and r.idregime = d.idregime
                             and r.classificacao = 'A'
                             and r.contribuinteicms = 'S'
                             and op.tipooper = 'TS')
      loop
        pk_notafiscal.cancelarNfe(c_NFRetSimb.idnotafiscalretorno,
                                  p_idusuario);
      end loop;
    end if;
  
    -- Exclui as convocações ativa se existir
    for c_ativ in (select distinct rp.codigointerno, sc.palete
                     from separacaoporcarga sc, paleteondanf pf,
                          reservaestoqueondacarga re, romaneiopai rp
                    where rp.idromaneio = sc.idonda
                      and re.idseparacaoporcarga = sc.idseparacaoporcarga
                      and re.idpaleteondanf = pf.idpaleteondanf
                      and pf.idnotafiscal = p_idnotafiscal
                      and sc.idonda = p_idonda
                      and sc.status = 3
                    order by sc.palete)
    loop
      pk_convocacao.apagaConfPaleteCarga(p_idusuario, c_ativ.codigointerno,
                                         c_ativ.palete);
    end loop;
  
  end cancelarNotaFiscal;

  /*
  *  Rotina responsavel por remover uma nota fiscal da onda
  */
  procedure removerNotaFiscalOndaCarga
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
  
    v_configuracaoOnda   configuracaoonda%rowtype;
    v_movNaoCancelada    romaneiopai.statusonda%type;
    v_idconfiguracaoonda number;
    v_msg                t_message;
  
    procedure finalizarConvocacaoAtivaSep is
    begin
      for c_tarefa in (select count(sc.idseparacaoporcarga) as total,
                              count(case
                                       when sc.status in (2, 3) then
                                        1
                                     end) as separado, sc.tarefa
                         from separacaoporcarga sc, paleteondanf po,
                              reservaestoqueondacarga rs
                        where sc.idseparacaoporcarga =
                              rs.idseparacaoporcarga
                          and po.idpaleteondanf = rs.idpaleteondanf
                          and rs.idonda = p_idOnda
                          and po.idnotafiscal <> p_idNotaFiscal
                        group by sc.tarefa)
      loop
        if (c_tarefa.total = c_tarefa.separado) then
          pk_convocacao.finalizaseparacaoonda(p_idusuario, p_idOnda,
                                              c_tarefa.tarefa);
        
        end if;
      end loop;
    end finalizarConvocacaoAtivaSep;
  begin
    -- Retornar Configurações Onda
    begin
      select co.*
        into v_configuracaoOnda
        from configuracaoonda co, romaneiopai rp
       where co.idconfiguracaoonda = rp.idconfiguracaoonda
         and rp.idromaneio = p_idOnda;
    exception
      when no_data_found then
        v_msg := t_message('Configuração de Onda não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_configuracaoOnda.Tipoonda <> C_TIPOONDA_CARGA) then
      v_msg := t_message('Processo não concluído, tipo Onda diferente de Expedição por Carga.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Realizando lock da onda com retirada de nf para não ocorrer concorrência
    -- foi utilizado parametro já existente somente para o lock
    select o.statusonda
      into v_movNaoCancelada
      from romaneiopai o
     where o.idromaneio = p_idonda
       for update;
  
    -- Valida status da onda para cancelamento
    pk_onda_cancelar.validarOndaParaCancelamento(p_idonda,
                                                 pk_onda_cancelar.C_ORIGEM_RETIRAR_NOTA);
  
    cancelarNotaFiscal(p_idonda, p_idnotafiscal, p_idusuario,
                       C_ONDA_REMOVER_NF);
    pk_onda_cancelar.retirarAdicionarDoPicking(p_idonda, p_idusuario);
  
    insert into nfretirada
      (idromaneio, idnotafiscal)
    values
      (p_idonda, p_idnotafiscal);
  
    update nfimpressao nfi
       set nfi.statusdoc = 12
     where nfi.idprenf in
           (select nf.idprenf
              from notafiscal nf
             where nf.idnotafiscal = p_idnotafiscal);
  
    delete from nfromaneio nfr
     where nfr.idromaneio = p_idonda
       and nfr.idnotafiscal = p_idnotafiscal;
  
    delete from saidapornf s
     where s.idonda = p_idonda
       and s.idnotafiscal = p_idnotafiscal;
  
    pk_onda_cancelar.calcularTitulosPesoNF(p_idonda, p_idnotafiscal);
    pk_onda_cancelar.atualizaSepConfPesDaOnda(p_idonda, p_idusuario);
    finalizarConvocacaoAtivaSep;
    pk_onda_cancelar.verificarSeDeveCancelarOnda(p_idonda);
    pk_onda_cancelar.verificarSeDeveProcessarOnda(p_idonda);
  
    begin
      select r.idconfiguracaoonda
        into v_idconfiguracaoonda
        from romaneiopai r
       where r.idromaneio = p_idonda
         and r.tipo = 1;
    exception
      when no_data_found then
        v_msg := t_message('Onda não encontrada para o id {0}');
        v_msg.addParam(p_idonda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    pk_onda_cancelar.regraSubPedido(p_idonda, p_idnotafiscal, p_idusuario);
  
    select count(*)
      into v_movNaoCancelada
      from separacaoporcarga sc, paleteondanf po, reservaestoqueondacarga rs
     where sc.idseparacaoporcarga = rs.idseparacaoporcarga
       and po.idpaleteondanf = rs.idpaleteondanf
       and rs.idonda = p_idOnda
       and po.idnotafiscal = p_idNotaFiscal
       and sc.status <> 3;
  
    if (v_movNaoCancelada > 0) then
      v_msg := t_message('Ocorreu uma falha no cancelamento da onda. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end removerNotaFiscalOndaCarga;

  /*
  * Rotina responsavel por cancelar a onda
  */
  procedure cancelarOnda
  (
    p_idonda    in number,
    p_idusuario in number,
    p_origem    in number
  ) is
    type t_lista is table of number;
    v_statusOnda       number;
    v_movNaoCancelada  number;
    v_listanf          t_lista;
    v_configuracaoOnda configuracaoonda%rowtype;
    v_msg              t_message;
  begin
  
    select co.*
      into v_configuracaoOnda
      from configuracaoonda co, romaneiopai ro
     where co.idconfiguracaoonda = ro.idconfiguracaoonda
       and ro.idromaneio = p_idonda;
  
    if (v_configuracaoOnda.Tipoonda <> C_TIPOONDA_CARGA) then
      v_msg := t_message('Processo não concluído, tipo Onda diferente de Expedição por Carga.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Realizando lock da onda em cancelamento para não ocorrer concorrência
    select o.statusonda
      into v_statusOnda
      from romaneiopai o
     where o.idromaneio = p_idonda
       for update;
  
    pk_utilities.GeraLog(p_idusuario,
                         'INICIOU O CANCELAMENTO DA ONDA ID: ' || p_idonda,
                         p_idonda, 'CO');
  
    pk_onda_cancelar.validarOndaParaCancelamento(p_idonda, p_origem);
    pk_onda_cancelar.validarNotasParaCancelarOnda(p_idonda);
  
    -- Armazena dados para exibição nos dados das ondas canceladas
    insert into histromaneiopai
      (idromaneio, pedido, notafiscal, depositante, transportadora,
       destinatario, coleta)
      select rp.idromaneio, nf.numpedidofornecedor pedido,
             nf.codigointerno notafiscal, dep.razaosocial depositante,
             transp.razaosocial transportadora,
             dest.razaosocial destinatario, stragg(cr.carga) coleta
        from romaneiopai rp, nfromaneio nfr, notafiscal nf, entidade dep,
             entidade dest, entidade transp, cargaromaneio cr
       where rp.idromaneio = p_idonda
         and nfr.idromaneio = rp.idromaneio
         and nf.idnotafiscal = nfr.idnotafiscal
         and dep.identidade = nf.iddepositante
         and dest.identidade = nf.destinatario
         and transp.identidade = nf.transportadoranotafiscal
         and cr.idromaneio(+) = nfr.idromaneio
         and cr.idnotafiscal(+) = nfr.idnotafiscal
       group by rp.idromaneio, nf.numpedidofornecedor, nf.codigointerno,
                dep.razaosocial, transp.razaosocial, dest.razaosocial;
  
    -- Limpando Gtt para iniciar seu preenchimento na rotina de cancelar nota fiscal
    -- Não colocado o delete dentro da rotina devido a chamar várias vezes alimentando
    -- Obs: chamada também no retirarNotaFiscal
    delete from gtt_retirar_adicionar_onda;
  
    for c in (select nfr.idnotafiscal
                from nfromaneio nfr
               where nfr.idromaneio = p_idonda)
    loop
      cancelarNotaFiscal(p_idonda, c.idnotafiscal, p_idusuario,
                         C_ONDA_CANCELAR);
    end loop;
  
    for c in (select nfr.idnotafiscal
                from nfromaneio nfr
               where nfr.idromaneio = p_idonda)
    loop
      regerarMovimentacao(p_idonda, c.idnotafiscal, C_ONDA_CANCELAR);
    end loop;
  
    pk_onda_cancelar.retirarAdicionarDoPicking(p_idonda, p_idusuario);
  
    select r.statusonda
      into v_statusOnda
      from romaneiopai r
     where r.idromaneio = p_idonda;
  
    -- se o status da onda for EM_FORMACAO(0)  significa que o cancelamento esta sendo
    -- chamado pela formacao da onda e ela possui corte. Neste caso as notas fiscais não devem
    -- ser retiradas da onda, somente o estoque deve ser retirado a reserva.
    if (v_statusOnda = 0) then
      update romaneiopai r
         set r.statusonda = 6
       where r.idromaneio = p_idonda;
    else
      insert into nfretirada
        (idromaneio, idnotafiscal)
        select idromaneio, idnotafiscal
          from nfromaneio
         where idromaneio = p_idonda;
    
      for c_nfonda in (select nf.idprenf
                         from nfromaneio nfr, notafiscal nf
                        where nf.idnotafiscal = nfr.idnotafiscal
                          and nfr.idromaneio = p_idonda)
      loop
        update nfimpressao nfi
           set nfi.statusdoc = 12
         where nfi.idprenf = c_nfonda.idprenf;
      end loop;
    
      select nfr.idnotafiscal
        BULK COLLECT
        INTO v_listanf
        from nfromaneio nfr
       where nfr.idromaneio = p_idonda;
    
      delete from nfromaneio nfr
       where nfr.idromaneio = p_idonda;
    
      for i in 1 .. v_listanf.count
      loop
        update notafiscal n
           set n.statusnf           = decode(n.digitada, 'S', 'N', 'I'),
               n.statusroteirizacao = 0,
               n.lido               = 0
         where n.idnotafiscal = v_listanf(i);
      
      end loop;
    
      delete from saidapornf s
       where s.idonda = p_idonda;
    
      update romaneiopai r
         set r.statusonda        = 5,
             r.pesoteorico       = 0,
             r.qtdematerial      = 0,
             r.qtdetotalmaterial = 0
       where r.idromaneio = p_idonda;
    
      pk_convocacao.apagarConvocacaoOnda(p_idusuario, p_idonda);
    
      for c in (select distinct po.idnotafiscal
                  from paleteondanf po, reservaestoqueondacarga rs
                 where po.idpaleteondanf = rs.idpaleteondanf
                   and rs.idonda = p_idonda)
      loop
        pk_onda_cancelar.regraSubPedido(p_idonda, c.idnotafiscal,
                                        p_idusuario);
      end loop;
    end if;
  
    select count(*)
      into v_movNaoCancelada
      from separacaoporcarga sc, paleteondanf po, reservaestoqueondacarga rs,
           nfromaneio nfr
     where sc.idseparacaoporcarga = rs.idseparacaoporcarga
       and po.idpaleteondanf = rs.idpaleteondanf
       and rs.idonda = p_idOnda
       and nfr.idromaneio = po.idonda
       and nfr.idnotafiscal = po.idnotafiscal
       and sc.status <> 3;
  
    if (v_movNaoCancelada > 0) then
      v_msg := t_message('Ocorreu uma falha no cancelamento da onda. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_utilities.GeraLog(p_idusuario,
                         'FINALIZOU O CANCELAMENTO DA ONDA ID: ' ||
                          p_idonda, p_idonda, 'CO');
  
  end cancelarOnda;

end PK_ONDACARGA_CANCELAR;
/

