create view VI_INT_OR_N as
select n.NROOR "OR", n.NOTAFISCAL, n.SERIE, n.CNPJ_EMITENTE, n.ID, '*' F,
       idreplicacao
  from int_envio_or_n n
/

