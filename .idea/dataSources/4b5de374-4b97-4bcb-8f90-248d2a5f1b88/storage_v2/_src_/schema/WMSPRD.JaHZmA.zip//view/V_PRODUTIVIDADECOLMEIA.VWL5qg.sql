create view V_PRODUTIVIDADECOLMEIA as
select ps.data, ps.regiaoorigem, ps.separador,
       sum(ps.qtdeunitaria) qtdeunitaria
  from (select trunc(ce.data) data, rg.descr regiaoorigem,
                u.nomeusuario separador, sum(ce.qtdeemvolume) qtdeunitaria
           from confescaninho ce, local l,
                regiaoarmazenagem rg, usuario u
          where ce.status not in (3, 7)
            and l.id = ce.idescaninho
            and rg.idregiao = l.idregiao
            and u.idusuario = ce.idusuario
            and trunc(ce.data) >= trunc(sysdate - 7)
          group by trunc(ce.data), rg.descr, u.nomeusuario) ps
 group by ps.data, ps.regiaoorigem, ps.separador
 order by ps.data
/

