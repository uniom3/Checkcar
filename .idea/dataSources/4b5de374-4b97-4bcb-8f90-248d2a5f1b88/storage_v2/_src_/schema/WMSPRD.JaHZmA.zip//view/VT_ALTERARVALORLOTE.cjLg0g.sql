create view VT_ALTERARVALORLOTE as
select a.iddepositante, a.depositante, a.cnpj, a.codigoProduto, a.produto,
       a.idlote, a.loteindustria, a.qtdeentrada,
       (a.qtdeemestoqueun / a.fatorconversao) quantidadeEstoque, a.barra,
       a.descrreduzido, a.fatorconversao,
       trunc(a.valorunitario, 2) valorunitario,
       trunc(((a.qtdeemestoqueun / a.fatorconversao) * a.valorunitario), 2) valortotal,
       a.dtentrada,
       trunc(nvl((select avg((lt.valorlote /
                              decode(lc.estoque, 0, 1, lc.estoque)))
                    from lote lt, lotelocal lc, embalagem e
                   where lt.iddepositante = a.iddepositante
                     and lt.idproduto = a.idproduto
                     and lt.idarmazem = a.idarmazem
                     and lc.idlote = lt.idlote
                     and lc.idarmazem = lt.idarmazem
                     and lc.estoque > 0
                     and nvl(lt.valorlote, 0) > 0
                     and e.idproduto = lt.idproduto
                     and e.barra = lt.barra), 0), 2) valormedioun,
       a.idarmazem h$idarmazem
  from (select lt.iddepositante, ed.razaosocial depositante, ed.cgc cnpj,
                prod.codigointerno codigoProduto, prod.idproduto, lt.idlote,
                lt.descr loteindustria, lt.qtdeentrada, e.barra,
                prod.descr produto, e.descrreduzido, e.fatorconversao,
                lc.estoque qtdeemestoqueun,
                (nvl(lt.valorlote, 0) /
                 decode(lt.qtdeentrada, 0, 1 * e.fatorconversao,
                         lt.qtdeentrada * e.fatorconversao)) valorunitario,
                lt.dtentrada, lt.idarmazem
           from lote lt, lotelocal lc, depositante d, regime r, entidade ed,
                embalagem e, produto prod
          where d.identidade = lt.iddepositante
            and lc.idlote = lt.idlote
            and lc.idarmazem = lt.idarmazem
            and r.idregime = d.idregime
            and r.classificacao = 'F'
            and ed.identidade = d.identidade
            and e.idproduto = lt.idproduto
            and e.barra = lt.barra
            and prod.idproduto = lt.idproduto) a
/

