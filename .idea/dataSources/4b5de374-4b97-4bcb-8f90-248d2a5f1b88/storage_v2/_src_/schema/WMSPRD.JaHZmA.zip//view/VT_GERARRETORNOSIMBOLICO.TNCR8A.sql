create view VT_GERARRETORNOSIMBOLICO as
select nf.idnotafiscal h$tableid, nf.idnotafiscal,
       nf.codigointerno notafiscal, nf.sequencia serie,
       nf.dataemissao dtemissao, dest.razaosocial destinatario,
       dep.razaosocial depositante, nf.totalprodutos valorproduto,
       nf.idarmazem h$idarmazem
  from notafiscal nf, entidade dest, entidade dep, depositante d, regime r,
       (select r.idnotafiscalvenda
           from retornosimbolico r, notafiscal n
          where n.idnotafiscal = r.idnotafiscalretorno
            and n.statusnf <> 'X') rs, saidapornf snf
 where nf.tipo = 'S'
   and (case
         when d.momentodispretornosimbolico = 0
              and nf.statusnf = 'P' then
          1
         when d.momentodispretornosimbolico = 1 then
          1
         when d.momentodispretornosimbolico = 2
              and nvl(snf.separado, 0) = 1 then
          1
         when d.momentodispretornosimbolico = 3
              and nvl(snf.pesado, 0) = 1 then
          1
         else
          0
       end) = 1
   and nf.crossdocking = 'N'
   and nvl(nf.sequencia, 'X') not like '%AJUSTE%'
   and (nf.remetente = nf.iddepositante or exists
        (select 1
           from operacao o
          where o.idoperacao = nf.idoperacao
            and o.idcfop in ('5914', '6914')))
   and dep.identidade = nf.iddepositante
   and dest.identidade = nf.destinatario
   and d.identidade = nf.iddepositante
   and rs.idnotafiscalvenda(+) = nf.idnotafiscal
   and rs.idnotafiscalvenda is null
   and r.idregime = d.idregime
   and r.classificacao = 'A'
   and nvl(nf.retornoarmazenagem, 'N') = 'N'
   and snf.idnotafiscal(+) = nf.idnotafiscal
   and exists (select 1
          from nfromaneio
         where idnotafiscal = nf.idnotafiscal)
/

