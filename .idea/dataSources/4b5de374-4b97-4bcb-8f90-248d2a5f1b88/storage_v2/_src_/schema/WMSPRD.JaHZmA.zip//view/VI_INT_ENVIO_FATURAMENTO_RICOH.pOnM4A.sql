create view VI_INT_ENVIO_FATURAMENTO_RICOH as
select i.id, '00' tiporegistro, ' ' filler, i.numeropedido, i.qtdevolumes
  from int_envio_faturamento_ricoh i
/

