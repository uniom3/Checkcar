create view VT_EFD as
select e.agrupador, e.datageracao, e.datainicial dtinicio,
       e.datafinal dttermino, u.nomeusuario usuariogeracao,
       e.qtdenf qtdenfefd, e.idarmazem h$idarmazem
  from efd e, integracao i, armazem a, usuario u
 where i.agrupador = e.agrupador
   and u.idusuario = e.idusuario
   and a.idarmazem = e.idarmazem
/

