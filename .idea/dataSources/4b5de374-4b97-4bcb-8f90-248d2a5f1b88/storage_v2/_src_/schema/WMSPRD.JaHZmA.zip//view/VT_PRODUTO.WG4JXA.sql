create view VT_PRODUTO as
select p.rowid h$tableid, p.idproduto, p.codigointerno codproduto,
       p.descr produto, p.descrvoicepicking, p.codreferencia, t.descr tipo,
       st.descr subtipo, f.razaosocial familia, sf.descr subfamilia,
       m.descr marca, sm.descr submarca,
       cf.codigo || ' - ' || cf.descr classificacaofiscal,
       cm.nome classificacaomaterial, p.segregado, p.pesavel, p.fracionado,
       p.produtocritico, p.otimizaseparacao, p.kitexpexplodida,
       p.auditoriadeentrada, p.movestoque, p.multiendereco, p.precadastro,
       p.ativo, p.baterialitio, p.fatorlitio, p.pontoreabastecimento,
       p.pontoressuprimento pontoressuprimento,
       pk_produto.retornardescrreduzidaefator(p.idproduto) descrlimiteressuprimento,
       p.prazovalidade, p.prazocomercializacao, p.prazocritico,
       p.itemadicional, p.descritemadicional, p.ncm, ce.codigo cest,
       substr(p.ncm, 1, 2) generoproduto, p.codigolistaservico, p.codseloipi,
       p.codigoprodanvisa, p.precomaximoconsumidor, p.motivoisencao,
       p.codigoinmetro, p.datacadastro, p.dataalteracao,
       decode(sign((select count('x')
                       from nfdet
                      where idproduto = p.idproduto) - 1), -1, 'N', 'S') h$temmovimentacao,
       decode(p.ativo, 'N', 0, 1) h$ativo, p.codigoinmetro h$codigoinmetro
  from produto p, tipoproduto t, subtipoproduto st, entidade f,
       subfamilia sf, marca m, submarca sm, classificacaofiscal cf,
       classificacaomaterial cm, codigoespecificadost ce
 where t.idtipo = p.idtipo
   and st.idtipo = p.idtipo
   and st.idsubtipo = p.idsubtipo
   and f.identidade = p.idfamilia
   and sf.idsubfamilia(+) = p.idsubfamilia
   and m.idmarca(+) = p.idmarca
   and sm.idsubmarca(+) = p.idsubmarca
   and cf.idclassificacao(+) = p.idclassificacao
   and cm.id(+) = p.idclassificacaomat
   and ce.idcodigo(+) = p.idcest
/

