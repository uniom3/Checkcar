create view VT_OSCLASSIFICACAO as
select os.rowid h$tableid, os.idordemservico, os.datacadastro dtcadastro,
       e.razaosocial depositante,
       decode(os.tiposervico, 'O', 'Classificação', 'R', 'Reclassificação',
               'T', 'Mistura') tiposervico,
       decode(os.situacao, 'A', 'Aguardando', 'P', 'Processada') situacao,
       os.idlotenf, rp.codigointerno onda,
       nf.codigointerno notafiscalentrada, p.descr produto,
       os.dataprocessamento dtprocessamento, os.identidade iddepositante,
       os.idproduto, os.idnotafiscal, os.idosmistura,
       os.idromaneio h$idromaneio, os.situacao h$situacao,
       os.tiposervico h$tiposervico, os.idarmazem h$idarmazem,
       decode(count(cml.idlote), 0, 0, 1) h$lotevinculado
  from ordemservico os, entidade e, romaneiopai rp, notafiscal nf, produto p,
       classificacaomisturalote cml
 where e.identidade = os.identidade
   and rp.idromaneio(+) = os.idromaneio
   and os.tiposervico in ('O', 'R')
   and nf.idnotafiscal(+) = os.idnotafiscal
   and p.idproduto(+) = os.idproduto
   and cml.idordemservico(+) = os.idordemservico
 group by os.rowid, os.idordemservico, os.datacadastro, e.razaosocial,
          os.tiposervico, os.situacao, os.idlotenf, rp.codigointerno,
          nf.codigointerno, p.descr, os.dataprocessamento, os.identidade,
          os.idproduto, os.idnotafiscal, os.idromaneio, os.situacao,
          os.tiposervico, os.idarmazem, os.idosmistura
/

