create view VB_GERENCIADORRELATORIO as
select g.idrelatorio idetiqueta, g.descr, g.personalizada, g.tiporelatorio
  from gerenciadorrelatorio g
 where g.ativo = 1
/

