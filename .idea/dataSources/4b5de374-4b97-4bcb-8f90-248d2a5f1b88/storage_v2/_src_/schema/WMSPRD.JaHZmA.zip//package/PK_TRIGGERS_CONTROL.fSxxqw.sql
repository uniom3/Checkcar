create package PK_TRIGGERS_CONTROL is

  type T_BEFORE_AJUSTEMOVTOENTRADA is record(
    validarInfoEspecifica boolean := true);

  r_before_ajustemovtoentrada T_BEFORE_AJUSTEMOVTOENTRADA;

  procedure disableTrigger(p_triggerName in varchar2);

  function isTriggerDisable(p_triggerName in varchar2) return boolean;

  procedure enableTrigger(p_triggerName in varchar2);

  procedure enableAllTrigger;

  function isOutraColunaAlteradaTrigger
  (
    p_tabela varchar2,
    p_coluna varchar2
  ) return boolean;

end PK_TRIGGERS_CONTROL;
/

