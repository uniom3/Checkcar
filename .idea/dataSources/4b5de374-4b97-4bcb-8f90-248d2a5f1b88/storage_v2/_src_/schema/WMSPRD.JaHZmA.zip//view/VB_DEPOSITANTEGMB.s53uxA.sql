create view VB_DEPOSITANTEGMB as
select e.identidade, e.razaosocial depositante, cgc, cic, e.inscrestadual,
       e.pessoa, d.filtraentidadedepositante h$filtraentidadedepositante,
       d.filtratranspsemvinculodep h$filtratranspsemvinculodep,
       d.transpcadastrada h$transpcadastrada, r.classificacao h$regime,
       nvl(e.simples, 'S') h$impostosimples, nvl(e.irrf, 0) h$irrf,
       nvl(r.contribuinteicms, 'N') h$contribuinteicms,
       decode(d.utilizaopa, 0, 'N', 'S') h$utilizaopa,
       d.obrigaremetenteor h$obrigaremetenteor,
       d.OBRIGACHAVEACESSONF h$OBRIGACHAVEACESSONF,
       d.utilizaretencaoexpedicao H$UTILIZARETENCAOEXPEDICAO,
       e.estrangeiro h$estrangeiro
  from entidade e, depositante d, regime r
 where e.ativo = 'S'
   and d.identidade = e.identidade
   and r.idregime = d.idregime
   and r.classificacao = 'A'
   and r.contribuinteicms = 'N'
/

