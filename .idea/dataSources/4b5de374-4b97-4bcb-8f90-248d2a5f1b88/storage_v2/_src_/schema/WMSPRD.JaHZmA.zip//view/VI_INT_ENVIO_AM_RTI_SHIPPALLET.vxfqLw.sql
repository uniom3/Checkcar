create view VI_INT_ENVIO_AM_RTI_SHIPPALLET as
select agrupador id, palletid
  from int_envio_am_rti_shippallet
/

