create view VT_HISTORICOETIQUETATRANSP as
select (select u.nomeusuario
           from usuario u
          where u.idusuario = h.idusuariologado) usuario,
       (select u.nomeusuario
           from usuario u
          where u.idusuario = h.idsupervisor) supervisor, h.qtdesugerida,
       h.qtdeimpressa, h.dataconfirmacao, h.origemconfirmacao,
       e.idnotafiscal h$idnota, h.id h$tableid
  from historicoetiqtransportador h, etiquetatransportador e
 where h.idetiquetatransp = e.id
/

