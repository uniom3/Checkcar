create view VR_RELATORIOTICKETBALANCA as
select (select entconf.razaosocial
           from configuracao conf, entidade entconf
          where conf.idproprietario = entconf.identidade) proprietariosistema,
       entarm.razaosocial entidadearmazem,
       decode((select count(1)
                 from vt_endereco
                where h$identidade = entarm.identidade), 0, '', 1,
               (select (tipo_endereco || decode(tipo_endereco, null, '', ' ') ||
                         logradouro || ', ' || numero ||
                         decode(complemento, null, '', ', ') || complemento ||
                         decode(bairro, null, '', ' - ') || bairro)
                   from vt_endereco
                  where h$identidade = entarm.identidade),
               nvl((select (tipo_endereco ||
                            decode(tipo_endereco, null, '', ' ') || logradouro || ', ' ||
                            numero || decode(complemento, null, '', ', ') ||
                            complemento || decode(bairro, null, '', ' - ') ||
                            bairro)
                      from vt_endereco v
                     where h$identidade = entarm.identidade
                       and enderecofiscal = 1), '')) enderecoarmazem,
       decode((select count(1)
                 from vt_endereco
                where h$identidade = entarm.identidade), 0, '', 1,
               (select (cidade || ' - ' || estadocidade)
                   from vt_endereco
                  where h$identidade = entarm.identidade),
               nvl((select (cidade || ' - ' || estadocidade)
                      from vt_endereco v
                     where h$identidade = entarm.identidade
                       and enderecofiscal = 1), '')) cidadearmazem,
       decode(ag.modal, 0, 'RODOVIÁRIO', 'FERROVIÁRIO') tipoveiculo,
       v.veiculo placaveiculo, entmot.razaosocial motorista, entmot.rg,
       (ag.idtransportadora || ' - ' || v.transportadora) transportadora,
       v.tipo operacao, v.depositante clientefornecedor,
       ag.descvolumes produto, ag.numnfs notafiscal,
       v.pesoprimeirapesagem pesoentrada,
       ag.idusuariopripesagem usupesoentrada,
       to_char(v.dtprimeirapesagem, 'DD/MM/RRRR') datapesoentrada,
       to_char(v.dtprimeirapesagem, 'HH24:MI') horapesoentrada,
       v.pesosegundapesagem pesosaida, ag.idusuariosecpesagem usupesosaida,
       to_char(v.dtsegundapesagem, 'DD/MM/RRRR') datapesosaida,
       to_char(v.dtsegundapesagem, 'HH24:MI') horapesosaida,
       v.pesorealkg pesoliquido, v.pesoteoricokg pesoinformado,
       v.divergenciapesagem divergencia,
       v.percentudaldivergencia divergenciaperc, ag.observacao observacao,
       ag.idagenda idagenda
  from vt_gerenciadorpesagemtransp v, agendatransporte ag, armazem a,
       entidade entarm, entidade entmot
 where v.idagenda = ag.idagenda
   and v.h$idarmazem = a.idarmazem
   and a.identidade = entarm.identidade
   and ag.idmotorista = entmot.identidade(+)
/

