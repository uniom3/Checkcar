create package pk_usuario is

  procedure atribuirPermissao
  (
    p_idinterface in number,
    p_idgrupo     in number
  );

  procedure retirarPermissao
  (
    p_idinterface in number,
    p_idgrupo     in number
  );

  procedure removerUsuarioDoGrupo
  (
    p_idgrupo   in grupousuario.idgrupo%type,
    p_idusuario in grupousuario.idusuario%type
  );

  procedure inserirUsuarioNoGrupo
  (
    p_idgrupo   in grupousuario.idgrupo%type,
    p_idusuario in grupousuario.idusuario%type
  );

  function getUsuario(p_idusuario in number) return varchar2;

  procedure vincularTipoAtividade
  (
    p_idgrupo         in number,
    p_idtipoatividade in number
  );

  procedure desvincularTipoAtividade
  (
    p_idgrupo         in number,
    p_idtipoatividade in number
  );

  procedure validarAcessoModulo
  (
    p_idUsuario   in number,
    p_nomeUsuario in varchar2,
    p_modulo      in varchar2,
    p_tipoLogin   in number
  );

  function doLogin
  (
    p_usuario in varchar2,
    p_senha   in varchar2,
    p_modulo  in varchar2
  ) return number;

  procedure gravarHistAlteracaoSenha
  (
    p_idusuarioalteracao in usuario.idusuario%type,
    p_idusuarioalterado  in usuario.idusuario%type,
    p_novasenha          in usuario.senha%type
  );

  procedure validarRegrasSenha
  (
    p_idusuarioalterado in usuario.idusuario%type,
    p_novaSenhaCript    in usuario.senha%type,
    p_novaSenha         in usuario.senha%type
  );

  function gerarSenha return varchar2;

  procedure alterarSenha
  (
    p_idusuarioalterado in usuario.idusuario%type,
    p_novaSenhaCript    in usuario.senha%type,
    p_novaSenha         in usuario.senha%type
  );

  procedure alterarSenhaCodigo
  (
    p_codigo         in usuario.codigoredefinirsenha%type,
    p_novaSenhaCript in usuario.senha%type,
    p_novaSenha      in usuario.senha%type
  );

  procedure redefinirSenhaEmail
  (
    p_idusuario         in number,
    p_codigoRecuperacao in varchar2
  );

  procedure enviarSenhaTemporariaPorEmail
  (
    p_idUsuario     in number,
    p_idUsuarioDest in number,
    p_senha         in varchar2
  );

  procedure removerUsuario
  (
    p_idUsuario         in number,
    p_idUsuarioExcluido in number
  );

  procedure validarCodBarraCracha
  (
    p_idUsuario      in number,
    p_codBarraCracha in varchar2
  );
  
  function getIdUsusarioIntegracao return number;
  
end;
/

