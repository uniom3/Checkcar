create package body pk_regiaoArmazenagem is

  procedure atualizaLocal
  (
    p_idRegiao   in number,
    p_idEndereco in number
  ) is
  
    v_msg t_message;
  
    function podeVincularRegiao
    (
      p_idRegiao   in number,
      p_idEndereco in number
    ) return boolean is
    
      v_regiaoRetorno number;
      v_pulmao        number;
    
    begin
    
      select count(1)
        into v_regiaoRetorno
        from configuracaoonda c
       where c.idregiaoretornoestoque = p_idRegiao;
    
      select count(1)
        into v_pulmao
        from local l
       where l.id = p_idEndereco
         and l.tipo in (1, 2);
    
      if (v_regiaoRetorno > 0 and v_pulmao = 0) then
        return false;
      else
        return true;
      end if;
    
    end podeVincularRegiao;
  
  begin
    -- Aqui está desvinculando um endereço
    if (nvl(p_idRegiao, 0) = 0) then
      update local l
         set l.idRegiao = null
       where l.id = p_idEndereco;
       
      update local lc
            set lc.idregiao = null
          where lc.id in ( select l.id
                             from local l
                            where l.idlocaldoca = p_idEndereco
                              and l.tipo = C_SUBDOCA);   
    
    else
      -- Aqui está vinculando um endereço
      if (podeVincularRegiao(p_idRegiao, p_idEndereco)) then
        update local l
           set l.idregiao = p_idRegiao
         where l.id = p_idEndereco;
         
         update local lc
            set lc.idregiao = p_idRegiao
          where lc.id in ( select l.id
                             from local l
                            where l.idlocaldoca = p_idEndereco
                              and l.tipo = C_SUBDOCA);  
                                          
      else
        v_msg := t_message('Somente endereços de Pulmão podem ser vinculados a região de ' ||
                           chr(13) ||
                           'armazenagem configurada como Região de Retorno de Estoque.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  end atualizaLocal;

end pk_regiaoArmazenagem;
/

