create view VI_INT_ENVIO_EFD_0450 as
select distinct '0450' reg, lpad(nf.idnotafiscal || '', 6, '0') cod_inf,
                translate(nvl(nf.observacao, 'NÃO INFORMADO'), chr(10) || chr(13), ' ') txt, nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento
  from notafiscal nf, depositante dp, regime re, operacao o,
       nfremarmazenagem nr
 where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
       nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
   and o.idoperacao = nf.idoperacao
   and decode(nf.statusnf, 'P', 1, 0) = 1
   and decode(nf.retornoreentrega, 'N', 1, 0) = 1
   and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and decode(re.classificacao, 'A', 1, 0) = 1
   and o.idoperacao = nf.idoperacao
   and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
   and nr.idnfremessa(+) = nf.idnotafiscal
 group by '0400', nvl(nf.observacao, 'NÃO INFORMADO'), nf.idarmazem,
          trunc(nvl(nr.datacobertura, nf.datacadastro)),
          lpad(nf.idnotafiscal || '', 6, '0')
/

