create view VT_GERENCIADORSEPARACAODET as
select dep.fantasia depositante, n.numPedidoFornecedor as pedido,
       n.codigointerno as notaFiscal, n.sequencia as serie,
       n.estado as estado, dest.fantasia as destinatario,
       transp.fantasia as transportadora,
       d.ondaexclusiva as depOndaExclusiva, n.dataentrega as dataEntrega,
       transp.razaosocial as razaoSocialTransportadora,
       dest.codigointerno as codigoCliente, dest.cgc cnpjDestinatario,
       dep.identidade as idDepositante,
       dep.razaosocial as razaoSocialDepositante, dep.cgc as cnpjDepositante,
       n.dataprocessamento as dataCadastro, n.dataemissao as DataEmissao,
       n.freteporconta as tipoFrete, n.totalgeral as totalGeral,
       d.diasrestricao as diasRestricao, n.pesobruto as pesoBruto,
       pa.mensagem as pontoAlerta, n.idnotafiscal as idnotafiscal,
       transp.identidade as idTransportadora, n.statusnf as status,
       nfr.idromaneio h$idromaneio
  from nfromaneio nfr, notafiscal n, entidade dep, entidade dest,
       entidade transp, depositante d, pontoalerta pa
 where n.idnotafiscal = nfr.idnotafiscal
   and dep.identidade = n.iddepositante
   and dest.identidade = n.destinatario
   and transp.identidade = n.transportadoranotafiscal
   and d.identidade = dep.identidade
   and pa.idnotafiscal(+) = n.idnotafiscal
/

