create view VT_ROTAPRECARGA as
select r.codigo codrota, r.descr rota, r.ativo, tr.descr tiporota,
       r.idrota h$idrota, r.idtiporota h$idtiporota
  from rotas r, tiporota tr
 where r.ativo = 'S'
   and tr.idtiporota(+) = r.idtiporota
/

