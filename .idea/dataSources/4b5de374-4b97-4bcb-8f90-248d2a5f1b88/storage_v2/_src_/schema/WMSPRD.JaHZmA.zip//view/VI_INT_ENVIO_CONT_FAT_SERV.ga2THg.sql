create view VI_INT_ENVIO_CONT_FAT_SERV as
select id, data, cnpjdepositante, numerocontrato, idfatura, inicioapuracao,
       terminoapuracao, dataapuracao, valor, status, cnpjunidade, sigla,
       codendereco, vencimento, desconto, valorliquido, codenderecofat,
       parcial, codigounidade, codigodepositante, idresultadointegracao,
       status_integracao, data_integracao, msg_erro, codigocomplementar,
       idreplicacao
  from int_envio_fatura_servico
/

