create view VT_DOCATRANSPORTADORA as
select l.idlocal, decode(l.tipo, 4, 'DOCA', 6, 'RUA EXPEDIÇÃO') tipo,
       d.descr doca, l.id h$idendereco, l.idarmazem h$idarmazem,
       l.ordem h$ordem, l.idlocalformatado f$idlocal
  from local l, doca d, armazem a
 where d.idendereco(+) = l.id
   and a.idarmazem = l.idarmazem
   and l.tipo = decode(a.utilizaruaexpedicao, 0, 4, 6)
/

