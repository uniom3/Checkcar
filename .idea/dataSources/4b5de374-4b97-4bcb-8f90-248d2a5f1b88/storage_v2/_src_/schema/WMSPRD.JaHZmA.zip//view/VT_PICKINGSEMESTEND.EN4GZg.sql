create view VT_PICKINGSEMESTEND as
select l.idlocal, p.codigointerno codProduto, p.descr produto, e.razaosocial,
       s.descr setor, r.descr regiao, p.idproduto, e.identidade,
       l.idlocalformatado f$idlocal, pck.idprodutolocal idPicking,
       pck.idprodutolocal h$tableid, pck.idarmazem h$idarmazem
  from produtolocal pck, local l, setor s, regiaoarmazenagem r, produto p,
       entidade e
 where l.id = pck.idendereco
   and s.idsetor(+) = l.idsetor
   and r.idregiao(+) = l.idregiao
   and p.idproduto = pck.idproduto
   and e.identidade = pck.identidade
   and not exists (select nvl(sum(ll.estoque + ll.adicionar), 0)
          from lotelocal ll, lote lt
         where ll.idlocal = l.idlocal
           and ll.idlote = lt.idlote
           and ll.idarmazem = pck.idarmazem having
         nvl(sum(ll.estoque + ll.adicionar), 0) = 0)
   and exists (select nvl(sum(ll.estoque + ll.adicionar), 0)
          from lotelocal ll, lote lt
         where ll.idlocal = l.idlocal
           and ll.idlote = lt.idlote
           and lt.idproduto = pck.idproduto
           and lt.iddepositante = pck.identidade having
         nvl(sum(ll.estoque + ll.adicionar), 0) = 0)
/

