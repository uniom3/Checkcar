create view VT_ETIQUETAGEMVOLUME as
select pe.barra barrapreetiqueta, vr.codbarra codbarravolume, rp.codigointerno onda,
       nf.numpedidofornecedor pedido, nf.codigointerno notafiscal,
       nf.sequencia serie, vr.statusvolume cancelado,
       he.idusuarioetiquetagem, he.dataetiquetagem, rp.idarmazem h$idarmazem
  from historicoetiquetagemvolume he, volumeromaneio vr, romaneiopai rp,
       notafiscal nf, preetiquetagenerica pe
 where pe.id = vr.idpreetiquetagenerica
   and nf.idnotafiscal(+) = vr.idnotafiscal
   and rp.idromaneio = vr.idromaneio
   and vr.idvolumeromaneio = he.idvolumeromaneio
/

