create view VT_GMB as
select h$tableid, idnotafiscal id, idprenf, tipo, notafiscal numero, cnpjdepositante,
       depositante, cnpjemitente, emitente, cnpjdestinatario, destinatario,
       cnpjentrega, entrega, estadonf, dtemissao, status, idlotenf,
       vlrprodutos, valortotal, digitada, usuariocadastro,
       transportadora, nrooperacao, valortotalcalc,
       valorprodutocalc, valorprodutobruto, valortotaldescontos,
       dtsaidaentrada, dtentrada, dtprocessamento,
       operacao, cfop, usuariocancelamento, motivocancelamento,
       dtcancelamento, iddepositante, idremetente, iddestinatario,
       identrega, h$idarmazem, h$statusnf, h$estado, h$tipo,
       h$tipooperacao, h$idnotafiscalvinculada, h$existenfvinculada,
       h$naopermitedesfazercancdoc
  from v_notafiscal
 where h$tipooperacao = 'G'
/

