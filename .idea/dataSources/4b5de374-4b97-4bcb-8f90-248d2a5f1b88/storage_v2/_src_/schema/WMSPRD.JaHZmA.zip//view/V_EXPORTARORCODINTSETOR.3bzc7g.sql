create view V_EXPORTARORCODINTSETOR as
select lnf.idlotenf, p.codigointerno, sum(ma.qtde * e.fatorconversao) qtde,
       lt.estado, e.barra, s.codigointegracao
  from lotenf lnf, orlote ol, lote lt, embalagem e, produto p,
       mapaalocacao ma, local l, setor s
 where ol.idlotenf = lnf.idlotenf
   and lt.idlote = ol.idlote
   and lt.tipolote = 'L'
   and p.idproduto = lt.idproduto
   and e.barra = lt.barra
   and e.idproduto = lt.idproduto
   and ma.idlote = lt.idlote
   and l.idlocal = ma.idlocal
   and l.idarmazem = ma.idarmazem
   and s.idsetor = l.idsetor
 group by lnf.idlotenf, p.codigointerno, lt.estado, e.barra,
          s.codigointegracao
union
select lnf.idlotenf, p.codigointerno,
       sum(lf.qtdeentrada * e.fatorconversao) qtde, lf.estado, e.barra,
       s.codigointegracao
  from lotenf lnf, orlote ol, lote lp, lote lf, embalagem e, produto p,
       mapaalocacao ma, local l, setor s
 where ol.idlotenf = lnf.idlotenf
   and lp.idlote = ol.idlote
   and lp.tipolote = 'P'
   and lf.idpalet = lp.idlote
   and p.idproduto = lf.idproduto
   and e.barra = lf.barra
   and e.idproduto = lf.idproduto
   and ma.idlote = lp.idlote
   and l.idlocal = ma.idlocal
   and l.idarmazem = ma.idarmazem
   and s.idsetor = l.idsetor
 group by lnf.idlotenf, p.codigointerno, lf.estado, e.barra,
          s.codigointegracao
/

