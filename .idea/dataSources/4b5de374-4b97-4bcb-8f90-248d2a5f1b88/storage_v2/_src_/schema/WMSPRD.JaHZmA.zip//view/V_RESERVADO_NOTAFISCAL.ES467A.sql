create view V_RESERVADO_NOTAFISCAL as
select nf.iddepositante, nvl(nf.estado, 'N') estado, nfd.idproduto,
       sum(nfd.qtdeatendida * e.fatorconversao) qtde
  from notafiscal nf, nfdet nfd, embalagem e
 where nf.statusnf not in ('C', 'X', 'P')
   and nf.tipo = 'S'
   and nf.estoqueverificado = 'S'
   and nfd.nf = nf.idnotafiscal
   and e.idproduto = nfd.idproduto
   and e.barra = nfd.barra
   and not exists (select 1
          from retornosimbolico
         where idnotafiscalvenda = nf.idnotafiscal)
 group by nf.iddepositante, nvl(nf.estado, 'N'), nfd.idproduto
/

