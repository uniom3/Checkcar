create view VE_ESTOQUE_LIB_EXPEDICAO as
select a.idarmazem IDUNIDADE, ea.cgc CNPJ_ARMAZEM, a.idarmazem,
       p.codigointerno COD_PRODUTO, P.IDPRODUTO, p.descr PROD_DESCR,
       e.barra barra_produto, e.fatorconversao fator_conversao,
       e.descrreduzido unidade_medida, ed.identidade IDDEPOSITANTE,
       ed.cgc CNPJ_DEPOSITANTE, em.estado estado_material,
       pk_notafiscal.getQTDDisponivel(p.idproduto, a.idarmazem, d.identidade,
                                       em.estado) qtdedisponivel_un
  from armazem a, entidade ea, entidade ed, depositante d, produto p,
       embalagem e,
       (select 'N' estado
           from dual
         union all
         select 'T' estado
           from dual
         union all
         select 'D' estado
           from dual) em
 where a.identidade = ea.identidade
   and ed.identidade = d.identidade
   and p.idproduto = e.idproduto
   and e.barra = pk_produto.RetornarCodBarraMenorFator(p.idproduto)
/

