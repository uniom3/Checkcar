create view VT_DEVOLUCAOINSUCESSOENTREGA as
select ie.id idinsucessoentrega, ie.data datacriacao, ie.codigointerno,
       TO_CHAR(ie.datasolicitacao, 'DD/MM/RRRR') datasolicitacao,
       ie.codigocontroletransmissao, ie.numeroordemcliente,
       ie.codigoordemseparacao, ie.vendorpartyid, d.razaosocial depositante,
       DECODE(ie.status, 0, 'Pendente', 1, 'Executado', 2, 'Cancelado', 3,
               'Finalizado') status, ie.idarmazem h$idarmazem,
       ie.status h$status
  from insucessoentrega ie, entidade d
 where d.identidade = ie.iddepositante
/

