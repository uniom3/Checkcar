create view VB_MODELOVEICULO as
select idModelo, descr from modelo
/

