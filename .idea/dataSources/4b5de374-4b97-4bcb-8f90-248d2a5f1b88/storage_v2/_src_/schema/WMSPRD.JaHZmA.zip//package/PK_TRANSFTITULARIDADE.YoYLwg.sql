create package pk_transftitularidade is

  C_STATUS_CANCELADO          constant number := 0;
  C_STATUS_AG_RESERVA_ESTOQUE constant number := 1;
  C_STATUS_AG_FATURAMENTO     constant number := 2;
  C_STATUS_AG_DOC_ENTRADA     constant number := 3;
  C_STATUS_AG_EFETIVACAO      constant number := 4;
  C_STATUS_CONCLUIDO          constant number := 5;
  C_GERARNF_ENTRADA_SIM       constant number := 1;

  procedure inserirTransferenciaLiberacao(p_idUsuarioReserva in number);

  procedure cancelarTransferenciaPendente(p_idUsuario in number);

  procedure vinculaNotaEntrada
  (
    p_idTransfTitularidade in number,
    p_idNotaFiscal         in number,
    p_idUsuario            in number
  );

  procedure desvinculaNotaEntrada
  (
    p_idTransfTitularidade in number,
    p_idNotaFiscal         in number,
    p_idUsuario            in number
  );

  procedure validarNfEmTransferencia(p_idprenf in number);

  procedure transTitularidadeFaturamento(p_idNotaFiscal in number);

  procedure reservarEstoque
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  );

  procedure efetivarTransferencia
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  );

  function isTransfTitularidade(p_idonda in number) return boolean;

  procedure cancelarTransferencia
  (
    p_idTransfTitularidade number,
    p_idUsuario            number
  );

  function getTransfTitularidadeStatus(p_idonda in number) return number;

  procedure gerarNfEntrada
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  );

end pk_transftitularidade;
/

