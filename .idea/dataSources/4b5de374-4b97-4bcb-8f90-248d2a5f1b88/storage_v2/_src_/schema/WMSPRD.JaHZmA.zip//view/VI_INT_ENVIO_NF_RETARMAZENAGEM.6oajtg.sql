create view VI_INT_ENVIO_NF_RETARMAZENAGEM as
select id, idnotafiscal, '@' I, sequencia serie, codigointerno numeronf, codigointerno numeronf2,
       dataemissao datasaida, dataemissao, uforigem, cidadeorigem, ufdestino, cidadedestino,
       replace(trim(to_char(valorcontabil, '999999999999990D00')), ',', '.') valorcontabil,
       cancelado nfcancelada, cnpjdestinatario
  from int_envio_nf_armazenagem
/

