create view VB_EMBALAGEM as
select e.barra, e.descrreduzido embalagem, e.fatorconversao,
       e.idproduto h$idproduto, e.descr h$descricao
  from embalagem e, produto p
 where e.ativo = 'S'
   and e.idproduto = p.idproduto
   and p.ativo = 'S'
/

