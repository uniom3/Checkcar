create view V_INDICADORES_ROMANEIOPORDIA as
select 10 ordem, 'ROMANEIO POR DIA' titulo,
       'Romaneios formados por dia. Ultimos 7 dias' descricao,
       to_char(data, 'DD/MM/YYYY') dado, total valor, 0 tipo, null unidade,
       null inivermelho, null fimvermelho, null iniamarelo, null fimamarelo,
       null iniverde, null fimverde, null valorcockpit, idarmazem, data
  from (select trunc(r.datageracao) data, count(r.idromaneio) total,
                r.idarmazem
           from romaneiopai r
          where r.datageracao >= sysdate - 7
            and r.statusonda <> 5
          group by trunc(r.datageracao), r.idarmazem)
/

