create package pk_teste is
  procedure criarNotaFiscal;
end pk_teste;
/

