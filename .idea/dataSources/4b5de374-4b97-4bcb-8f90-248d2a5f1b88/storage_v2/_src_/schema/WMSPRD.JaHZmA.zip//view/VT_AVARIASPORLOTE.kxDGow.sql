create view VT_AVARIASPORLOTE as
select lr.idlote, p.codigointerno codproduto, p.descr produto,
       e.razaosocial depositante,
       decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'T',
               'VENCIDO/TRUNCADO') ESTADO,
       decode(l.itemadicional, 'S', 'SIM', 'NAO') itemadicional,
       l.dtvenc datavenclote, lr.qtde qtdeavaria, c.idcontroleavaria,
       to_char(c.dataavaria, 'dd/mm/yyyy') dataavaria,
       decode(c.estado, 'D', 'DANIFICADO', 'T', 'VENCIDO/TRUNCADO') estadoavaria,
       c.idarmazemorigem, a.descr armazem, c.idlocalorigem,
       u.nomeusuario usuario, c.motivo, l.iddepositante, p.idproduto,
       lr.idremanejamento, lo.idlocalformatado f$idlocalorigem,
       lo.ordem h$ordemorigem
  from controleavaria c, remanejamento r, loteremanejamento lr, armazem a,
       lote l, entidade e, produto p, usuario u, local lo
 where p.idproduto = l.idproduto
   and e.identidade = l.iddepositante
   and a.idarmazem = c.idarmazemorigem
   and l.idlote = lr.idlote
   and u.idusuario = c.idusuario
   and lr.idremanejamento = r.idremanejamento
   and r.idcontroleavaria = c.idcontroleavaria
   and lo.idlocal = c.idlocalorigem
   and lo.idarmazem = c.idarmazemorigem
/

