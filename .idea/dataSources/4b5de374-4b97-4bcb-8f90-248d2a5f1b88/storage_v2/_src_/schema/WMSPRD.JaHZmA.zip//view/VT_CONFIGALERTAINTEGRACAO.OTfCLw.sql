create view VT_CONFIGALERTAINTEGRACAO as
select cai."IDCONFIGURACAOALERTA", cai."DESCR", lia.extensao "TIPOARQUIVO",
       cai."TIPOALERTA", cai."TIPOERRO", cai."HORAINICIO", cai."HORAFIM",
       cai."TEMPOALERTA", cai."DATAHORAULTIMAIMPORTACAO", cai."ATIVO",
       (select stragg(u.nomeusuario)
           from usuarioconfigalertaint ua, usuario u
          where u.idusuario = ua.idusuario
            and ua.idconfigalertaint = cai.idconfiguracaoalerta) usuarios,
       (select stragg(d.razaosocial)
           from depconfigalertaint da, entidade d
          where d.identidade = da.iddepositante
            and da.idconfigalertaint = cai.idconfiguracaoalerta) depositantes,
       lia.idextensao h$idextensao, cai.tipoalerta h$tipoalerta,
       cai.tipoerro h$tipoerro
  from configalertaint cai, layoutintegracaoalerta lia
 where lia.idextensao = cai.tipoarquivo
/

