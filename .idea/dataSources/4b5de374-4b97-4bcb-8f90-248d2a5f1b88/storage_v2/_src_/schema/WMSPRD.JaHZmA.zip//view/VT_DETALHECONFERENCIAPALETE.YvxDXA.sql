create view VT_DETALHECONFERENCIAPALETE as
select r.codigointerno onda, p.palete, c.numeroconferencia, cdet.data,
       u.nomeusuario usuario, nvl(prod.codigointerno, ' ') codigointerno,
       nvl(prod.descr, ' ') produto, nvl(cdet.barra, ' ') barra,
       cdet.loteindustria,
       stragg(im.informacao ||
               decode(spec.valorinformacao, null, null, ' : ') ||
               spec.valorinformacao) informacaoespecifica,
       (cdet.quantidade * e.fatorconversao) qtde, cdet.status,
       c.idpaleteconferencia h$idpaleteconferencia,
       cdet.id h$idconfexpedicaocargadet, p.idonda h$idonda
  from romaneiopai r, paleteconferencia p, confexpedicaocarga c,
       confexpedicaocargadet cdet, usuario u, produto prod, embalagem e,
       confexpedicaocargainfoespec spec, informacaomaterial im
 where r.idromaneio = p.idonda
   and c.idpaleteconferencia = p.id
   and cdet.idconfexpedicaocarga = c.id
   and u.idusuario = cdet.idusuario
   and prod.idproduto = cdet.idproduto
   and e.idproduto = cdet.idproduto
   and e.barra = cdet.barra
   and spec.idconfexpedicaocargadet(+) = cdet.id
   and im.idinfomaterial(+) = spec.idinfomaterial
 group by r.codigointerno, p.palete, c.numeroconferencia, cdet.data,
          u.nomeusuario, prod.codigointerno, prod.descr, cdet.barra,
          cdet.loteindustria, (cdet.quantidade * e.fatorconversao),
          cdet.status, c.idpaleteconferencia, cdet.id, p.idonda
/

