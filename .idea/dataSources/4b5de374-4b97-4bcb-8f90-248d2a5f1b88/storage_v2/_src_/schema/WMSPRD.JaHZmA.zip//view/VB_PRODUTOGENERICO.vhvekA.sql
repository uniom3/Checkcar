create view VB_PRODUTOGENERICO as
select pd.codigointerno codproduto, pr.descr produto, pd.idproduto,
       pd.identidade h$identidade, rownum H$unique
  from produtodepositante pd, produto pr
 where pr.idproduto = pd.idproduto
   and pd.generico = 'S'
/

