create view VB_DOCA as
select do.descr doca, lo.idlocal, lo.idarmazem h$idarmazem,
       do.iddoca h$iddoca
  from doca do, local lo, armazem arm
 where do.idarmazem = lo.idarmazem
   and do.idendereco = lo.id
   and lo.idarmazem = arm.idarmazem
   and lo.ativo = 'S'
   and ((lo.tipo = 4) or (lo.tipo = case
         when (arm.utilizaruaexpedicao = 1) then
          6
         else
          4
       end))
/

