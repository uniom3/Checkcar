create view V_CONFERENCIAENTRADAITEM as
select a.codigoitem, a.descricaoitem, a.lotefornecedor, a.datavencimentolote,
       a.qtdeunidaderecebida, a.padraocaixaunrecebida,
       (a.lastro || 'x' || a.qtdecamada) padraopaletsistema,
       (a.qtdeunidaderecebida / (a.lastro * a.qtdecamada)) padraopaleteunrecebida,
       a.idnotafiscal
  from (select p.codigointerno codigoitem, upper(p.descr) descricaoitem,
                lt.descr lotefornecedor, lt.dtvenc datavencimentolote,
                sum(orld.qtde / emb.fatorconversao) qtdeunidaderecebida,
                emb.descrreduzido padraocaixaunrecebida, emb.lastro,
                emb.qtdecamada, orld.idnotafiscal
           from origemlotedetalhado orld, lote lt, produto p, embalagem emb
          where 1 = 1
            and lt.idlote = orld.idlote
            and decode(lt.tipolote, 'L', 1, 0) = 1
            and p.idproduto = orld.idproduto
            and emb.idproduto = orld.idproduto
            and emb.barra = lt.barra
          group by p.codigointerno, p.descr, lt.descr, lt.dtvenc,
                   emb.descrreduzido, emb.lastro, emb.qtdecamada,
                   orld.idnotafiscal) a
/

