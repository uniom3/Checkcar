create view VT_TIPOENDERECO as
select idtipoendereco, descr, completo
  from tipoendereco
/

