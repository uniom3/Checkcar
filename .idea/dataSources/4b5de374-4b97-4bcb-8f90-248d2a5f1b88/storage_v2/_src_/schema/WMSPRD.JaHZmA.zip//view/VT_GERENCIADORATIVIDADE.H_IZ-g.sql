create view VT_GERENCIADORATIVIDADE as
select a.idatividade, ta.descricao tipoatividade, a.descricao,
       decode(a.status, 'A', 'PENDENTE', 'E', 'EM EXECUÇÃO', 'F',
               'FINALIZADA') status,
       to_char(a.datacriacao, 'yyyy/mm/dd hh24:mm:ss') gerada_em,
       pk_utilities.F_TEMPO_ENTRE(NVL(H.DATAINICIO, SYSDATE), A.DATACRIACAO) tempo_de_espera,
       pk_utilities.F_TEMPO_ENTRE(NVL(H.DATAFIM, sysdate), H.DATAINICIO) tempo_execucao,
       to_char(h.datafim, 'dd/mm/yyyy hh24:mm:ss') fim,
       pk_utilities.F_TEMPO_ENTRE(NVL(A.DATAFINALIZACAO, sysdate),
                                   a.datacriacao) tempo_total,
       pk_convocacao.gruposAtividade(a.idtipoatividade) grupousuario,
       pk_convocacao.usuariosAtividade(a.idatividade) usuario,
       to_char(h.datainicio, 'dd/mm/yyyy hh24:mm:ss') inicio,
       a.datacriacao dtcriacao, a.datafinalizacao dtfinalizacao,
       trunc(nvl(a.datafinalizacao, sysdate) - a.datacriacao) * 24 +
        trunc(24 * ((nvl(a.datafinalizacao, sysdate) - a.datacriacao) -
              trunc(nvl(a.datafinalizacao, sysdate) - a.datacriacao))) || ':' ||
        lpad(trunc(60 *
                   ((24 *
                   ((nvl(a.datafinalizacao, sysdate) - a.datacriacao) -
                   trunc(nvl(a.datafinalizacao, sysdate) - a.datacriacao))) -
                   trunc(24 *
                          ((nvl(a.datafinalizacao, sysdate) - a.datacriacao) -
                          trunc(nvl(a.datafinalizacao, sysdate) -
                                 a.datacriacao))))), 2, '0') tempo,
       d.razaosocial depositante, nf.codigointerno notafiscal,
       a.idoperacao idoperacao, nvl(nfr.qtdevolumescalculado, 0) qtdeVolumes,
       nf.numpedidofornecedor pedido, imp.cidade_entrega cidade,
       imp.estado_entrega estado, nf.datafaturamento,
       a.idtipoatividade h$idtipoatividade, a.status h$status,
       a.idarmazem h$idarmazem, a.idregiaoorigem, ro.descr regiaoorigem,
       a.idregiaodestino, rd.descr regiaodestino
  from atividade a, tipoatividade ta, notafiscal nf, entidade d,
       nfromaneio nfr, romaneiopai r, nfimpressao imp, regiaoarmazenagem ro,
       regiaoarmazenagem rd, historicoatividade h
 where ta.idtipoatividade = a.idtipoatividade
   and h.idatividade(+) = a.idatividade
   and nf.idnotafiscal(+) = a.idnotafiscal
   and d.identidade(+) = nf.iddepositante
   and nfr.idnotafiscal(+) = nf.idnotafiscal
   and r.idromaneio(+) = nfr.idromaneio
   and imp.idprenf(+) = nf.idprenf
   and ro.idregiao(+) = a.idregiaoorigem
   and rd.idregiao(+) = a.idregiaodestino
/

