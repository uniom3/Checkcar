create view V_ESTOQUEPICKING as
select ll.idarmazem, lt.iddepositante, lt.idproduto, lt.estado,
       ll.idendereco, ll.idlocal, ll.idlote,
       (ll.estoque - ll.pendencia + ll.adicionar) disponivel,
       (select count(*)
           from dual
          where exists (select 1
                   from setorrecebimento sr, tiporecebimento tr
                  where sr.idsetor = lo.idsetor
                    and sr.idtiporecebimento = tr.idtiporecebimento
                    and tr.classificacao = 'E')) setortipoencomenda,
       nvl(lt.dtvenc, sysdate) dtvenc, trunc(lt.dtentrada) dtentrada, lo.rua,
       lo.predio, lo.andar, lo.apartamento, lt.liberado situacaolote,
       lo.idsetor, s.tipopermitirpickingsetor tipoPicking,
       sd.codintegracao codSetorEstoque
  from lotelocal ll, lote lt, local lo, setor s, setordepositante sd,
       regiaoarmazenagem ra, setorproduto sp
 where (ll.estoque - ll.pendencia + ll.adicionar) > 0
   and lt.idlote = ll.idlote
   and lt.tipolote = 'L'
   and lo.idlocal = ll.idlocal
   and lo.idarmazem = ll.idarmazem
   and lo.tipo = 0
   and lo.buffer = 'N'
   and lo.ativo = 'S'
   and s.idsetor = lo.idsetor
   and s.ativo = 'S'
   and s.expedicao = 'S'
   and sd.iddepositante = lt.iddepositante
   and sd.idsetor = s.idsetor
   and ra.idregiao = lo.idregiao
   and sp.idsetor = lo.idsetor
   and sp.idproduto = lt.idproduto
   and not exists (select 1
          from estoqueinformacaoespecifica es
         where es.idlote = lt.idlote
           and es.temporario = 1)
/

