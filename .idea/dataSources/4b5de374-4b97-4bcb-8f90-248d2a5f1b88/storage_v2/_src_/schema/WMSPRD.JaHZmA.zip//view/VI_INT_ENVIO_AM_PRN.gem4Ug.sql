create view VI_INT_ENVIO_AM_PRN as
select agrupador id, vendorpartyid, vendorpartytype, warehouselocationid,
       returnrequestid, returnshipmentid, billofladingid, carriername,
       shipmenttrackingid, shipmentdatetime
  from int_envio_am_prn
/

