create view VT_NIVELPRIORIDADEENTREGA as
select nps.idprioridadeseparacao h$idprioridadeseparacao,
       ps.idArmazem h$idArmazem,
       nps.idinformacao h$idinformacao, nps.id, nps.idinformacao idEntidade,
       e.codigointerno, e.razaosocial "Entrega (Loja)", nps.prioridade
  from prioridadeseparacao ps, nivelprioridadeseparacao nps, entidade e
 where nps.idprioridadeseparacao = ps.id
   and nps.idinformacao = e.identidade
 order by nps.prioridade
/

