create view VT_PENDENCIAESCOPOINVENTARIO as
select l.idlocal || s.descr || r.descr || i.idinventario || p.idproduto h$tableId,
       d.razaosocial depositante, l.idlocal, l.rua, l.predio, l.andar,
       l.apartamento, decode(mod(l.predio, 2), 0, 'PAR', 'ÍMPAR') lado,
       decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') tipo,
       s.descr setor, r.descr regiao, e.razaosocial familia, l.ativo,
       l.motivobloqueio, l.tipo h$tipo, l.idarmazem h$idarmazem,
       i.idinventario h$idinventario, p.codigointerno codproduto,
       p.descr produto, p.idproduto, l.idlocalformatado f$idlocal
  from inventario i, invdet iv, lotelocal ll, lote lt, produtodepositante pd,
       local l, setor s, regiaoarmazenagem r, entidade e, produto p,
       entidade d
 where iv.idinventario = i.idinventario
   and iv.erroinfespecifica = 'E'
   and l.tipo in (0, 1, 2)
   and (ll.estoque + ll.adicionar) > 0
   and exists (select 1
          from invdet ivc
         where ivc.idinvdet = iv.idinvdet
           and ivc.idcorrespondente = iv.idinvdet)
   and ll.idarmazem = i.idarmazem
   and lt.idlote = ll.idlote
   and lt.iddepositante = iv.identidade
   and lt.idproduto = iv.idproduto
   and pd.identidade = lt.iddepositante
   and pd.idproduto = lt.idproduto
   and l.idarmazem = ll.idarmazem
   and l.idlocal = ll.idlocal
   and s.idsetor(+) = l.idsetor
   and r.idregiao(+) = l.idregiao
   and e.identidade(+) = l.idfamilia
   and p.idproduto = lt.idproduto
   and not exists (select 1
          from escopoinventario es
         where es.idinventario = i.idinventario
           and es.idarmazem = ll.idarmazem
           and es.idlocal = ll.idlocal)
   and ((pd.rastrearinfoespecifica = 0 and not exists
        (select es.idinfomaterial, upper(es.valor)
            from estoqueinformacaoespecifica es
           where es.idlote = lt.idlote
          minus
          select ivs.idinfomaterial, upper(ivs.valor)
            from invdetinfespvalor ivs
           where ivs.idinvdet = iv.idinvdet)) or
       (pd.rastrearinfoespecifica = 1))
   and d.identidade = iv.identidade
 group by l.idlocal, l.rua, l.predio, l.andar, l.apartamento,
          decode(mod(l.predio, 2), 0, 'PAR', 'ÍMPAR'),
          decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                  'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA',
                  6, 'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING'), s.descr,
          r.descr, e.razaosocial, l.ativo, l.motivobloqueio, l.tipo,
          l.idarmazem, i.idinventario, p.codigointerno, p.descr, p.idproduto,
          l.idlocalformatado, d.razaosocial
/

