create view V_DETALHE_SAIDA as
select doc.idnotafiscal id,
       trunc(nvl(rp.dataprocessamento, nvl(doc.dataemissao, doc.datacadastro))) datamov,
       doc.iddepositante identidade, doc.remetente, doc.destinatario,
       to_char(trunc(nvl(rp.dataprocessamento, nvl(doc.dataemissao, doc.datacadastro))), 'mm/yyyy') mesmov,
       to_char(to_date(to_char(trunc(nvl(rp.dataprocessamento, nvl(doc.dataemissao, doc.datacadastro))), 'mm/yyyy'), 'mm/yyyy'), 'Month "de" yyyy') mes,
       doc.descr classificacao, doc.idproduto, 'SAIDA' TipoMov,
       doc.qtde totalprod, doc.peso totalpeso, doc.volume totalvolume,
       1 totalnf, doc.codigointerno numnf
  from (select nr.idromaneio, n.idnotafiscal, n.codigointerno, n.dataemissao,
                n.datacadastro, n.iddepositante, n.remetente,
                n.destinatario, o.descr, d.idproduto, 
                sum(nvl(d.qtdeatendida, 0) * nvl(e.fatorconversao, 0)) qtde,
                sum(nvl((e.pesobruto * d.qtdeatendida) / 1000, 0)) peso,
                sum(round((e.altura * e.largura * e.comprimento *
                           d.qtdeatendida) / 1000000000, 3)) volume
           from nfromaneio nr, notafiscal n, nfdet d, embalagem e, operacao o
          where n.idnotafiscal = nr.idnotafiscal
            and d.nf = n.idnotafiscal
            and e.idproduto = d.idproduto
            and e.barra = d.barra
            and o.idoperacao(+) = n.idoperacao
            and n.tipo = 'S'
            and nvl(o.tipooper, 0) not in ('TS', 'TA')
            and n.statusnf = 'P'
            and d.qtdeatendida > 0
          group by nr.idromaneio, n.idnotafiscal, n.codigointerno,
                   n.dataemissao, n.datacadastro, n.iddepositante,
                   n.remetente, n.destinatario, o.descr, d.idproduto
         union all
         select a.idromaneio, nf.idnotafiscal, nf.codigointerno,
                nf.dataemissao, nf.datacadastro, nf.iddepositante,
                nf.remetente, nf.destinatario, o.descr, d.idproduto,
                sum(nvl(d.qtdeatendida, 0) * nvl(e.fatorconversao, 0)) qtde,
                sum(nvl((e.pesobruto * d.qtdeatendida) / 1000, 0)) peso,
                sum(round((e.altura * e.largura * e.comprimento *
                           d.qtdeatendida) / 1000000000, 3)) volume
           from (select distinct idromaneio, rs.idnotafiscalretorno idnotafiscal
                    from nfromaneio nr, notafiscal n, operacao o,
                         retornosimbolico rs
                   where n.idnotafiscal = nr.idnotafiscal
                     and o.idoperacao(+) = n.idoperacao
                     and rs.idnotafiscalretorno = n.idnotafiscal
                     and n.tipo = 'S'
                     and nvl(o.tipooper, 0) = 'TA'
                     and n.statusnf = 'P') a, notafiscal nf, operacao o,
                nfdet d, embalagem e
          where nf.idnotafiscal = a.idnotafiscal
            and o.idoperacao(+) = nf.idoperacao
            and d.nf = nf.idnotafiscal
            and e.idproduto = d.idproduto
            and e.barra = d.barra
            and d.qtdeatendida > 0
          group by a.idromaneio, nf.idnotafiscal, nf.codigointerno,
                   nf.dataemissao, nf.datacadastro, nf.iddepositante,
                   nf.remetente, nf.destinatario, o.descr, d.idproduto) doc, romaneiopai rp
 where rp.idromaneio = doc.idromaneio
/

