create view VB_CONFIGURACAOONDA as
select co.idconfiguracaoonda, co.descr descricao,
       co.usoexclusivokitsestojamento H$USOEXCLUSIVOKITSESTOJAMENTO,
       a.idarmazem H$IDARMAZEM,
       a.utilizakitsestojamentoonda H$UTILIZAKITSESTOJAMENTOONDA,
       co.ativo h$ativo, co.controlapeso h$controlapeso
  from armazem a, configuracaoonda co
/

