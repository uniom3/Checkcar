create view VT_INVENTARIOIMPCAMPOSNULO as
select i.idinvdet, i.barra, i.estado, i.qtde, i.identidade, i.fator,
       i.idlocal, i.idarmazem, i.idinventario, i.idproduto, p.codigointerno,
       p.descr,
       trim(decode(i.idlocal, null, 'LOCAL NULO') ||
             decode(I.QTDE, null, 'QUANTIDADE NULA') ||
             decode(I.BARRA, null, 'EMBALAGEM NULA')) logerro
  from importarinvdet i, produto p
 where p.idproduto(+) = i.idproduto
   and ((i.idlocal is null) or (i.qtde is null) or (i.barra is null))
/

