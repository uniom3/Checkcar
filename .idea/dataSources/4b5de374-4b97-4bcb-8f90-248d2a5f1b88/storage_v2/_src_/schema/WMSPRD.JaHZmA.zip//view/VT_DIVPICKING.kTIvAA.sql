create view VT_DIVPICKING as
select e.identidade iddepositante, e.razaosocial depositante, inv.idinventario h$idinventario, invd.idlocal localcont,
       linv.idlocalformatado f$localcont, linv.ordem h$ordemcont,
       pinv.codigointerno codprodcont, pinv.descr produtocont,
       stragg(distinct lpk.idlocalformatado) pickingcorreto,
       stragg(distinct ppkloc.codigointerno) codprodpk,
       stragg(distinct ppkloc.descr) produtopk, pinv.idproduto idprodutocont,
       stragg(distinct ppkloc.idproduto) idprodutopk
  from inventario inv, invdet invd, produto pinv, produtolocal pkloc,
       produto ppkloc, produtolocal pkcerto, local linv, local lpk, entidade e
 where invd.idinventario = inv.idinventario
   and pinv.idproduto = invd.idproduto
   and pkloc.idarmazem = invd.idarmazem
   and pkloc.identidade = invd.identidade
   and pkloc.idproduto = invd.idproduto
   and ppkloc.idproduto = pkloc.idproduto
   and pkcerto.idproduto = invd.idproduto
   and pkcerto.identidade = invd.identidade
   and decode(invd.ignorada, 'N', 0, 1) = 0
   and linv.idlocal = invd.idlocal
   and linv.idarmazem = invd.idarmazem
   and linv.picking = 'S'
   and lpk.idlocal = pkcerto.idlocal
   and lpk.idarmazem = pkcerto.idarmazem
   and not exists (select 1
          from produtolocal pk
         where pk.idproduto = invd.idproduto
           and pk.idarmazem = invd.idarmazem
           and pk.idlocal = invd.idlocal
           and pk.identidade = invd.identidade)
   and e.identidade = invd.identidade
 group by inv.idinventario, invd.idlocal, linv.idlocalformatado, linv.ordem,
          pinv.codigointerno, pinv.descr, pinv.idproduto, e.identidade, e.razaosocial
/

