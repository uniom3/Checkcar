create view V_EXPORTAREMBARQUE as
select a.cgc cnpj_armazem, dp.cgc cnpj_depositante, r.cgc cnpj_remetente,
       decode(d.pessoa, 'J', d.cgc, d.cic) cnpj_destinatario,
       decode(t.pessoa, 'J', t.cgc, t.cic) cnpj_transportadora,
       nf.codigointerno numnf, nf.sequencia serienf,
       nf.numpedidofornecedor numpedido, c.horaliberacao dataliberacao,
       c.idcarga, c.codigointerno numcoleta,
       nvl(count(vo.idvolume), 0) qtdevolume,
       nvl(sum(vo.peso), pk_notafiscal.get_peso_notafiscal(nf.idnotafiscal)) pesovolume,
       c.rgmotorista, c.motorista, substr(c.placa, 0, 9) placa,
       c.embarqueliberado, c.finalizado, c.datafinalizada, nf.iddepositante,
       nf.idnotafiscal
  from carga c, cargaromaneio cr, notafiscal nf, entidade dp, entidade r,
       entidade d, entidade t, armazem ar, entidade a, volumeromaneio vo,
       depositante dep
 where cr.idcarga = c.idcarga
   and nf.idnotafiscal = cr.idnotafiscal
   and dp.identidade = nf.iddepositante
   and r.identidade = nf.remetente
   and d.identidade = nf.destinatario
   and t.identidade(+) = c.idtransportadora
   and ar.idarmazem = c.idarmazem
   and a.identidade = ar.identidade
   and vo.idromaneio(+) = cr.idromaneio
   and vo.idnotafiscal(+) = cr.idnotafiscal
   and dep.identidade = dp.identidade
   and dep.exportaautembarque > 0
   and nvl(vo.statusvolume, 0) = 0
 group by a.cgc, dp.cgc, r.cgc, decode(d.pessoa, 'J', d.cgc, d.cic),
          decode(t.pessoa, 'J', t.cgc, t.cic), nf.codigointerno,
          nf.sequencia, nf.numpedidofornecedor, c.horaliberacao, c.idcarga,
          c.codigointerno, c.rgmotorista, c.motorista, c.placa,
          c.embarqueliberado, c.finalizado, c.datafinalizada,
          pk_notafiscal.get_peso_notafiscal(nf.idnotafiscal),
          nf.iddepositante, nf.idnotafiscal
/

