create view VR_MANIFESTOCARGA_COLETA as
select c.idcarga, c.idusuario, c.placa, c.codigointerno, c.liberado, c.data,
       c.tipoentrega, c.idusuariolib, c.finalizado,
       decode(c.situacao, 'F', 'FORMADA', 'S', 'SAIDA', 'E', 'ENTRADA', 'P',
               'PERNOITE') situacaodec, c.situacao, c.tipocarga,
       u.nomeusuario, c.idmotorista, e.razaosocial entidade, c.obs,
       c.idtransportadora, t.razaosocial transportadora, c.nomecontato,
       c.numcoleta, c.datasolicitacao, c.motorista, v.placa placaveiculo,
       nvl(c.motorista, m.razaosocial) motoristaagregado,
       pk_romaneio.pegar_romaneios(c.idcarga) codintroma, c.totalpeso,
       c.totalvolume, c.totalvalor, c.embarqueliberado,
       c.retornotransportadora, c.diasparado, c.horasaida, c.horaretorno
  from carga c, usuario u, entidade e, entidade t, veiculo v, entidade m
 where u.idusuario(+) = c.idusuario
   and e.identidade(+) = c.identidade
   and t.identidade(+) = c.idtransportadora
   and v.placa(+) = c.placa
   and m.identidade(+) = c.idmotorista
/

