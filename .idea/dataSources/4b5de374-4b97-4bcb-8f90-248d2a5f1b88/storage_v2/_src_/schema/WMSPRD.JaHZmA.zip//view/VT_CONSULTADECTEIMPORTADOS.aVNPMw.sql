create view VT_CONSULTADECTEIMPORTADOS as
select c.id idcte, c.nct, c.serie, c.dhemi, c.chaveacessocte, c.vprest
  from cte c
/

