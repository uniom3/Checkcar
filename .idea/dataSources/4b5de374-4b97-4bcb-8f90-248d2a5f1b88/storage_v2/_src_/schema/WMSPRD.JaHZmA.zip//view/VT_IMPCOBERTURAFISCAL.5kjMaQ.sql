create view VT_IMPCOBERTURAFISCAL as
select i.id h$id, i.cnpj_depositante CNPJDEPOSITANTE,
       i.cnpj_unidade CNPJARMAZEM, i.codigointerno NRONOTAFISCAL, i.serie,
       i.data_emissao DATAEMISSAO, i.baseicms BCICMS, i.valoricms ICMS,
       i.basesubstituicao BCICMSST, i.valorsubstituicao ICMSST,
       i.totalipi IPI, i.vlrtotalprodutos VLRPRODUTOS,
       i.vlrtotalgeral TOTALGERAL, i.pis, i.cofins, i.cs CONTRIBUICAOSOCIAL,
       i.ir IMPOSTORENDA, i.valoriss, i.valorservicos VALORSERVICOS,
       i.estado ESTADOMATERIAL, i.chaveacessonfe,
       i.codigoindustria CODPRODUTODEP, i.descr_prod DESCPRODUTO, i.barra,
       i.classificacaofiscal, i.qtdeitem, i.vlrunititem VALORUNITARIO,
       i.vlrtotalitem VLRITEM, i.aliqicms, i.aliqipi, i.vlrdesc VLRDESCITEM,
       i.porcdesconto PERCENTUALDESCONTO, i.desconto VALORDESCONTO,
       i.totalliquidoitem VALORTOTALLIQUIDO, i.st_3 SITUACAOTRIBUTARIA,
       i.ipi IPIITEM, i.utilizado, i.loteindustria, i.idnfdet
  from int_coberturafiscal i
/

