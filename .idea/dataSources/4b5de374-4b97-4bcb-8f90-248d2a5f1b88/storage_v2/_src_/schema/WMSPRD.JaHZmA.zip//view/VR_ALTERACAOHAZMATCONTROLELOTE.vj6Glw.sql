create view VR_ALTERACAOHAZMATCONTROLELOTE as
select distinct i.data dataImpCatalog, amh.agrupador, i.arquivo,
                amh.idproduto, p.descr, p.codigointerno asinProduto,
                amh.possuiestoque, amh.idclassmatperigosoantes,
                amh.idclassmatperigosodepois, amh.descrclassmatperigosoantes,
                amh.descrclassmatperigosodepois, amh.htrcantes,
                amh.htrcdepois, amh.excecaoantes, amh.excecaodepois,
                amh.prazovalidadeantes, amh.prazovalidadedepois,
                amh.coletadtavencloteantes, amh.coletadtavenclotedepois,
                amh.prazocomercializacaoantes,
                amh.prazocomercializacaodepois, amh.prazocriticoantes,
                amh.prazocriticodepois, pd.identidade iddepositante
  from am_catalogfeed_histaltprdhazm amh, produto p, produtodepositante pd,
       integracao i
 where amh.idproduto = p.idproduto
   and pd.idproduto = p.idproduto
   and pd.materialperigoso = 1
   and amh.agrupador = i.agrupador
 order by i.data
/

