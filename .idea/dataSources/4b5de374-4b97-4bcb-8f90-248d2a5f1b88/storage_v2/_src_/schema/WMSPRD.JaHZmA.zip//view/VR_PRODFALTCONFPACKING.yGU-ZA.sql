create view VR_PRODFALTCONFPACKING as
select distinct conf.nomeusuario conferente, sep.nomeusuario separador, cp.idpacking,
       m.idonda, rp.codigointerno onda,
       lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0') codbarratarefa,
       ra.descr regiaoorigem
  from movimentacao m, confpacking cp, usuario conf, usuario sep, local lo,
       regiaoarmazenagem ra, romaneiopai rp
 where m.idonda = cp.idonda
   and m.etapa = 1
   and conf.idusuario = cp.idusuario
   and sep.idusuario = m.idusuario
   and lo.id = m.idlocalorigem
   and ra.idregiao = lo.idregiao
   and rp.idromaneio = m.idonda
/

