create view VI_INT_ENVIO_AM_OFR_INFESPEC as
select agrupador id, lineitemsequencenumber, itemid, sequencenumber,
       itemtype, itemvalue, datacadastro
  from int_envio_am_ofr_infespec
/

