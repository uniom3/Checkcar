create view VT_TAREFASEPESTACAONAOLIB as
select m.idonda, rp.codigointerno onda, nf.codigointerno numNF,
       nf.numpedidofornecedor pedido,
       (lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0')) tarefa,
       rp.datageracao, ra.descr regiao,
       stragg(distinct e.descricao) estacoes, ra.idregiao,
       nf.idarmazem h$idarmazem
  from saidapornf snf, romaneiopai rp, movimentacao m, estacaolocal el,
       estacao e, notafiscal nf, local lo, regiaoarmazenagem ra
 where m.idnotafiscal = snf.idnotafiscal
   and m.idonda = rp.idromaneio
   and el.idendereco = m.idlocalorigem
   and e.id = el.idestacao
   and nf.idnotafiscal = snf.idnotafiscal
   and lo.id = m.idlocalorigem
   and ra.idregiao = lo.idregiao
   and decode(rp.processado, 'N', 0, 1) = 0
   and rp.statusonda in (1)
   and m.status in (0, 1, 2)
   and snf.separado = 0
   and not exists (select 1
          from tarefacaixavolume tcv
         where tcv.idonda = rp.idromaneio
           and tcv.tarefa = (lpad(m.idonda, 10, '0') ||
               lpad(m.identificador, 4, '0')))
 group by m.idonda, rp.codigointerno, nf.codigointerno,
          nf.numpedidofornecedor, rp.datageracao, ra.descr,
          (lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0')),
          ra.idregiao, nf.idarmazem
 order by rp.datageracao
/

