create view VI_INT_ENVIORETARMMOVSAIDA as
select id, '@' I, 'S' S, '"' || serie || '"' serie,
       '"' || numdocumento || '"' numdocumento,
       '"' || datasaida || '"' datasaida,
       '"' || dataemissao || '"' dataemissao,
       '"' || uforigem || '"' uforigem, '"' || ufdestino || '"' ufdestino,
       '"' || codmunicipioorigem || '"' codmunicipioorigem,
       '"' || codmunicipiodestino || '"' codmunicipidestino,
       '"' || totalcontabil || '"' totalcontabil,
       '"' || cancelado || '"' cancelado, '"' || cnpj || '"' cnpj,
       '"' || baseicms || '"' baseicms, '"' || valoricms || '"' valoricms,
       '"' || isentasicms || '"' isentasicms,
       '"' || outrasicms || '"' outrasicms,
       '"' || baseicmssubstituido || '"' baseicmssubstituido,
       '"' || icmssubstituido || '"' icmssubstituido, '"' || pis || '"' pis,
       '"' || cofins || '"' cofins
  from int_envioretmovarm_saida
/

