create package pk_servico is

  -- constaints publicas
  C_SIM                         CONSTANT CHAR(1) := 'S';
  C_NAO                         CONSTANT CHAR(1) := 'N';
  C_PROCESSADO                  CONSTANT CHAR(1) := 'P';
  C_SAIDA                       CONSTANT CHAR(1) := 'S';
  C_NORMAL                      CONSTANT CHAR(1) := 'N';
  C_ENTRADA                     CONSTANT CHAR(1) := 'E';
  C_CARGA                       CONSTANT CHAR(1) := 'C';
  C_FINALIZADO                  CONSTANT CHAR(1) := 'F';
  C_GERADO                      CONSTANT CHAR(1) := 'G';
  C_ERRO                        CONSTANT CHAR(1) := 'S';
  C_FATURADO                    CONSTANT CHAR(1) := 'S';
  C_MOVINTERNO                  CONSTANT CHAR(1) := 'I';
  C_SEPARACAO                   CONSTANT CHAR(1) := 'S';
  c_bom                         constant char(1) := 'N';
  c_reentrega                   constant char(1) := 'R';
  c_aberto                      constant char(1) := 'A';
  c_kit                         constant char(1) := 'K';
  C_KIT_COM_RASTREABILIDADE     constant char(1) := 'I';
  C_DESMONTAGEMKIT              constant char(1) := 'D';
  C_ESTOJAMENTO                 constant char(1) := 'E';
  C_DESESTOJAMENTO              constant char(1) := 'J';
  c_quarentena                  constant char(1) := 'B';
  c_importada                   constant char(1) := 'I';
  c_compra                      constant char(1) := 'C';
  c_interno                     constant char(1) := 'I';
  c_chirink                     constant char(1) := 'C';
  c_conserto                    constant char(1) := 'M';
  c_descrconserto               constant varchar2(8) := 'CONSERTO';
  pendente                      CONSTANT char(1) := 'P';
  C_AGUARDANDO                  CONSTANT char(1) := 'A';
  c_liberado                    CONSTANT char(1) := 'L';
  c_cadastrado                  CONSTANT char(1) := 'C';
  C_REALIZA_CONTROLE_FISCAL_KIT constant number := 1;
  C_GARANTIR_UM_VENCLOTEIND_KIT constant number := 1;
  -- Variavel Global
  v_romaneio number;
  v_nf       number;

  E_ERROCORTE exception;
  C_ERROCORTE constant number := -20101;

  pragma exception_init(E_ERROCORTE, -20101);

  v_lotenf number;

  type tErro is record(
    msgGrupo   varchar2(250),
    msgDetalhe varchar2(1000));

  type tListaErro is table of tErro;
  listaErro tListaErro := tListaErro();

  procedure processar_kitproduto
  (
    p_idordemservico   in ordemservico.idordemservico%type,
    p_usuario          in usuario.idusuario%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  );

  procedure excluir_os
  (
    p_idusuario      in number,
    p_idordemservico in number
  );

  /*
   * Verifica se existe produtos vinculados a OS
  */
  function totalprodutosvinculados(p_ordemservico in number) return number;

  /*
   * Rotina que Desvincuala OR da OS
  */
  procedure desvincularor
  (
    p_ordemservico in number,
    p_orold        in number,
    p_usuario      in number
  );

  /*
   * Rotina que Desvincula Romaneio da OS
  */
  procedure desvincularromaneio
  (
    p_romaneio     in number,
    p_ordemservico in number,
    p_usuario      in number
  );

  /*
   * Rotina que Vincula Romaneio
  */
  procedure vincularromaneio
  (
    p_placaveiculo in veiculo.placa%type,
    p_usuario      in number,
    p_armazem      in number,
    p_doca         in number,
    p_dtromaneio   in date,
    p_idos         in number
  );

  /*
   * Rotina que Vincula Nota Fical
  */
  procedure vincularnf
  (
    p_romaneio  in number,
    p_usuario   in number,
    p_entidade  in number,
    p_data      in date,
    p_os        in number,
    p_idarmazem in number := null
    
  );

  procedure vincularor
  (
    p_os       in number,
    p_data     in date,
    p_usuario  in number,
    p_armazem  in number,
    p_doca     in number,
    p_entidade in number
  );

  /*
   * Insere as informacoes na tabela ordemprodutonotafiscal
  */
  procedure InserirOrdemProdutoNotaFiscal(p_OrdemServicoNF in ordemprodutonotafiscal%rowtype);

  /*
   * Rotina responsavel por gerar a ordem de produção de kit para um produto
  */
  procedure GerarProducaoKit
  (
    p_idnotafiscal in number,
    p_depositante  in number,
    p_estado       lote.estado%type,
    p_idproduto    in number,
    p_qtde         in number,
    p_usuario      in number
  );

  /*
   * Insere a Ordem de Serviço
  */
  function InserirOrdemServico(p_ordemservico ordemservico%rowtype)
    return number;

  /*
   * Insere o produto na ordem de servico
  */
  procedure InserirOrdemServicoProduto(p_ordemproduto ordemproduto%rowtype);

  /*
   * Apaga as informacoes na tabela ordemprodutonotafiscal
  */
  procedure ApagarOrdemProdutoNotaFiscal(p_idnotafiscal in number);

  /*
   * Retira a nf da quarentena caso a or seja de kit e a nf esteja bloqueada
  */
  procedure RetirarNFQuarentenaKit(p_idlotenf in number);

  /*
   * Inclui produtos na tabela de SEPARACAOESPECIFICA
  */
  procedure IncluirSeparacaoEspecifica(p_idnotafiscal in notafiscal.idnotafiscal%type);

  /*
   * Gerar/Processar OS
  */
  procedure GerarOS
  (
    p_idordemservico in number,
    p_tipoos         in varchar2,
    p_usuario        in number,
    p_tipokitmontado out number,
    p_kitsmontados   out number,
    p_atualizakit    in number,
    p_commit         in varchar2 := c_sim
  );

  /*
   * Processar OS tipo Conserto/Manutencção/Laboratorio
  */
  procedure processar_Conserto(p_idordemservico in number);

  /*
   * Verifica se existe lotes vinculados a OS
  */
  function totallotesvinculados(p_ordemservico in number) return number;

  /*
   * Finalizar OS Conserto
  */
  procedure FinalizaOS(p_idordemservico in number);

  /*
   * Importar OS Conserto por nro serie
  */
  procedure ImportaOS_Serie
  (
    p_cnpjdepositante entidade.cgc%type,
    p_serie           lote.descr%type,
    p_produto         produto.codigointerno%type,
    p_usuario         number,
    p_tipomaterial    number := 0,
    p_cnpjunidade     entidade.cgc%type
  );

  /*
   * Importar OS Conserto por produto
  */
  procedure ImportaOS_Produto
  (
    p_cnpjdepositante entidade.cgc%type,
    p_produto         produto.codigointerno%type,
    p_qtde            number,
    p_usuario         number,
    p_cnpjunidade     entidade.cgc%type
  );

  /*
   * Liberar OS de Desmontagem de Kits
  */
  procedure CLiberarOSDesmKits
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  );

  /*
   * Cadastrar NF de Saida e Romaneio da Desmontagem dos Kits
  */
  procedure gerarExpedicaoDesmKit
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  );

  /*
   * Cadastrar NF de Entrada e OR da Desmontagem dos Kits
  */
  procedure CGerOROSDesmKits
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  );

  /*
   * Vincular lotes de composicao de montagem a OS
  */
  procedure VinculaLotesCompMontagem
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_idlote  in number,
    p_usuario in number
  );

  /*
   * Desvincular lotes de composicao de montagem a OS
  */
  procedure DesvinculaLotesMontagem
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_idlote  in number,
    p_usuario in number
  );

  /*
   * Liberar OS de Canibalizacao para execucao
  */
  procedure CtrlLiberarOSCanibExecucao
  (
    p_idOS      in number,
    p_idUsuario in number
  );

  /*
   * Suspender OS de Canibalizacao
  */
  procedure CtrlSuspenderExecOSCanib
  (
    p_idOS      in number,
    p_idUsuario in number
  );

  /*
   * Processar OS de Canibalizacao
  */
  procedure CtrProcessarOSCanib
  (
    p_idOS      in number,
    p_idUsuario in number
  );

  /*
   * Desmontar Material
  */
  procedure DesmontarMaterial
  (
    p_idOS      in number,
    p_idUsuario in number,
    p_erro      out varchar2
  );

  /*
   * Rotina responsável por transferir a cobertura fiscal dos lotes de desmontagem de kit
  */
  procedure transferirCoberturaDesmontagem(p_idordemservico in number);

  procedure suspenderOSDesmontagemKit
  (
    p_idordemservico in number,
    p_idusuario      in number
  );

  procedure LiberarOSDesmontagemExecucao
  (
    p_idordemservico in number,
    p_idusuario      in number
  );

  procedure processarOSDesmontManualmente
  (
    p_idordemservico in number,
    p_idusuario      in number
  );

  function isOrdemServicoAguardando(p_idOrdemServico in number) return number;

  procedure excluirOsClassificacao
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  );

  procedure excluirOsMistura
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  );

  procedure excluirOsReclassificacao
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  );

  procedure vincularLotesOsClassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idNotaFiscal   in number
  );

  procedure vincularLotesOsMistura
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  );

  procedure vincularLotesOsReclassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idOsMistura    in number
  );

  procedure desvincularLtsOsClassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idNotaFiscal   in number
  );

  procedure desvincularLtsOsMistura
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  );

  procedure desvinculaLtsOsReclassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  );

  procedure executarOrdemServico
  (
    p_idOrdemServico in number,
    p_idUsuario      in number,
    p_commit         in varchar2 := c_sim
  );

  procedure gerarSeparacaoMistura(p_idromaneio in number);

  procedure addProdutosOs
  (
    p_ordemServico  in number,
    p_produto       in number,
    p_quantidade    in number,
    p_idDepositante in number
  );

  function temLtIndCompDiferente(p_idLoteKit in number) return number;

  procedure formarOndaOrdemServico
  (
    p_idOnda         in out number,
    p_idConfigOnda   in number,
    p_idOrdemServico in number,
    p_tipoServico    in ordemservico.tiposervico%type,
    p_idNotaFiscal   in number,
    p_idUsuario      in number,
    p_osCombo        in number := 0
  );

  procedure executarEstojamento
  (
    p_idordemservico   in ordemservico.idordemservico%type,
    p_usuario          in usuario.idusuario%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  );

  procedure executarDesestojamento
  (
    p_idordemservico in ordemservico.idordemservico%type,
    p_usuario        in usuario.idusuario%type
  );

  procedure vincularLotesOsDesestojamento
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  );

  procedure desvincularLtsOsDesestojamento
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  );

  procedure validarMisturaLoteIndOnda
  (
    p_idordemservico   in number,
    p_idOnda           in number,
    p_tipoServico      in ordemservico.tiposervico%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  );

  procedure gerarEstojamento
  (
    p_idordemservico in number,
    p_tipoos         in varchar2,
    p_usuario        in number,
    p_tipokitmontado out number,
    p_kitsmontados   out number,
    p_quantidade     in number,
    p_commit         in varchar2 := c_nao
  );

  function getSeqLoteIndOS
  (
    p_idArmazem     in number,
    p_idDepositante in number,
    p_idOS          in number,
    p_idUsuario     in number
  ) return number;

  function getCloneOS(p_idOS in number) return number;

  procedure cancelarOS
  (
    p_idordemservico in number,
    p_usuario        in number
  );

end pk_servico;
/

