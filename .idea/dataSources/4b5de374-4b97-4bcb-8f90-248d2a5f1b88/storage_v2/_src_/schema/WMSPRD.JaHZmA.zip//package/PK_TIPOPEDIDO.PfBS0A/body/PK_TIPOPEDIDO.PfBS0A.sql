create package body PK_TIPOPEDIDO is

  v_msg t_message;

  procedure validarAlteraRemoveTipoPedido
  (
    p_idClassTipoPedido  in number,
    p_idusuario          in number,
    p_naoPermitirAlterar in boolean := false
  ) is
  begin
    for rec_nf in (select nf.idnotafiscal, nf.codigointerno,
                          nf.statusroteirizacao
                     from notafiscal nf
                    where nf.idtipopedido = p_idClassTipoPedido
                      and nf.statusroteirizacao <> 0
                      and nf.statusnf not in ('P', 'X')
                      and not exists
                    (select 1
                             from transferenciatitularidade tt
                            where tt.idnotafiscalsaida = nf.idnotafiscal
                              and tt.status not in (0, 5)))
    loop
      if (p_naoPermitirAlterar) then
        v_msg := t_message('Esta Classificação Tipo de Pedido não pode ser alterada/excluída por possuir notas vinculadas já liberadas para expedição vinculadas a ela.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (rec_nf.statusroteirizacao = 1) then
        pk_utilities.GeraLog(p_idusuario,
                             'Classificação Tipo Pedido ID: ' ||
                              p_idClassTipoPedido ||
                              ' foi alterada enquanto a NF de ID: ' ||
                              rec_nf.idnotafiscal || ' e Numero: ' ||
                              rec_nf.codigointerno ||
                              ' estava liberada mas não roteirizada.',
                             rec_nf.idnotafiscal, 'NF');
      end if;
    end loop;
  end;

  procedure addSetorTipoPedido
  (
    p_idClassTipoPedido in number,
    p_idSetor           in number,
    p_prioridade        in number
  ) is
    v_msg t_message;
  begin
    if (p_prioridade is null) then
      v_msg := t_message('Proridade não definida para o Setor.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    merge into setorclassificacaotipopedido sctp
    using (select p_idClassTipoPedido idtipopedido, p_idsetor idsetor
             from dual) a
    on (sctp.idtipopedido = a.idtipopedido and sctp.idsetor = a.idsetor)
    when matched then
      update
         set sctp.prioridade = p_prioridade
    when not matched then
      insert
        (idtipopedidosetorprior, idtipopedido, idsetor, prioridade)
      values
        (seq_setorclasstipopedido.nextval, p_idClassTipoPedido, p_idSetor,
         p_prioridade);
  end;

  procedure removeSetorTipoPedido
  (
    p_idClassTipoPedido in number,
    p_idSetor           in number,
    p_idusuario         in number
  ) is
  begin
    validarAlteraRemoveTipoPedido(p_idClassTipoPedido, p_idusuario);
  
    delete from setorclassificacaotipopedido sc
     where sc.idtipopedido = p_idClassTipoPedido
       and sc.idsetor = p_idSetor;
  end;

  procedure aumentarPrioriSetorTipoPedido(p_idTipoPedidoSetorPrior in number) is
    v_prioridade number;
  begin
    select sc.prioridade
      into v_prioridade
      from setorclassificacaotipopedido sc
     where sc.idtipopedidosetorprior = p_idTipoPedidoSetorPrior;
  
    if (v_prioridade = 1) then
      return;
    end if;
  
    update setorclassificacaotipopedido sc
       set sc.prioridade = sc.prioridade - 1
     where sc.idtipopedidosetorprior = p_idTipoPedidoSetorPrior;
  end;

  procedure diminuirPrioriSetorTipoPedido(p_idTipoPedidoSetorPrior in number) is
  begin
    update setorclassificacaotipopedido sc
       set sc.prioridade = sc.prioridade + 1
     where sc.idtipopedidosetorprior = p_idTipoPedidoSetorPrior;
  end;

  procedure validarTransTitulo
  (
    p_idClassTipoPedido  in number,
    p_transfTitularidade in number
  ) is
    v_transfTitularidade     number;
    v_andamentoTransferencia number;
  begin
    if (p_idClassTipoPedido > 0) then
      begin
        select cl.transferenciatitularidade
          into v_transfTitularidade
          from classificacaotipopedido cl
         where cl.idtipopedido = p_idClassTipoPedido;
      exception
        when no_data_found then
          v_transfTitularidade := 0;
      end;
    
      if (p_transfTitularidade <> v_transfTitularidade) then
        begin
          select 1
            into v_andamentoTransferencia
            from transferenciatitularidade transf, notafiscal nf
           where transf.idnotafiscalsaida = nf.idnotafiscal
             and nf.idtipopedido = p_idClassTipoPedido
             and transf.status not in (0, 5);
        exception
          when no_data_found then
            begin
              select 1
                into v_andamentoTransferencia
                from transferenciatitularidade transf, notafiscal nf
               where transf.idnotafiscalentrada = nf.idnotafiscal
                 and nf.idtipopedido = p_idClassTipoPedido
                 and transf.status not in (0, 5);
            exception
              when no_data_found then
                v_andamentoTransferencia := 0;
            end;
        end;
        if (v_andamentoTransferencia > 0) then
          v_msg := t_message('Existe controle de transferência de titularidade em andamento para esse tipo de pedido.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end if;
  end validarTransTitulo;

  function finalizarPontoAlerta
  (
    p_usuario      in varchar2,
    p_senha        in varchar2,
    p_idTipoPedido in number,
    p_operacao     in number,
    p_filtro1      in number default null,
    p_filtro2      in number default null,
    p_filtro3      in number default null
  ) return varchar2 is
  
    r_classiftipopedido classificacaotipopedido%rowtype;
    r_usuario           usuario%rowtype;
    v_msg               t_message;
    v_erro              varchar2(1000) := null;
  
    procedure validaUsuario
    (
      p_tipousuario in number,
      p_erro        out varchar2
    ) is
    begin
      p_erro := null;
    
      begin
        select u.*
          into r_usuario
          from usuario u
         where u.nomeusuario = upper(p_usuario)
           and u.senha = p_senha;
      exception
        when no_data_found then
          p_erro := 'Usuário ou senha invalidos.';
      end;
    
      if (r_usuario.nivel > p_tipousuario and p_erro is null) then
        p_erro := 'O nivel de acesso do usuario ' || r_usuario.nomeusuario ||
                  ' não permite finalizar o ponto de alerta.';
      end if;
    end;
  
  begin
    begin
      select c.*
        into r_classiftipopedido
        from classificacaotipopedido c
       where c.idtipopedido = p_idTipoPedido;
    exception
      when no_data_found then
        v_msg := t_message('Ponto de alerta da classificação de pedido não encontrado. idtipopedido: {0}');
        v_msg.addParam(p_idTipoPedido);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if p_operacao = C_OPERACAO_PACKING then
    
      if r_classiftipopedido.nivellibpacking is null then
        return 'Nível de liberação de usuário para packing não encontrado.';
      end if;
    
      validaUsuario(r_classiftipopedido.nivellibpacking, v_erro);
    
      if v_erro is not null then
        return v_erro;
      end if;
    
      if (nvl(p_filtro1, 0) <> 0 and nvl(p_filtro2, 0) <> 0 and
         nvl(p_filtro3, 0) <> 0) then
        update confpacking
           set usuarioliberacao = r_usuario.idusuario,
               dataliberacao    = sysdate
         where idnotafiscal = p_filtro1
           and idOnda = p_filtro2
           and status = 0
           and idpacking = p_filtro3
           and usuarioliberacao is null
           and dataliberacao is null;
      
        pk_utilities.GeraLog(p_usuario,
                             'Finalização do Ponto de Alerta no Packing pelo idusuário: ' ||
                              p_usuario || ' do idOnda: ' || p_filtro2 ||
                              ' da nota: ' || p_filtro1 || ' no idpacking: ' ||
                              p_filtro3, p_filtro3, 'LS');
      
      end if;
    
    elsif p_operacao = C_OPERACAO_COLMEIA then
    
      if r_classiftipopedido.nivellibcolmeia is null then
        return 'Nível de liberação de usuário para colmeia não encontrado.';
      end if;
    
      validaUsuario(r_classiftipopedido.nivellibcolmeia, v_erro);
    
      if v_erro is not null then
        return v_erro;
      end if;
    
      if (nvl(p_filtro1, 0) <> 0 and nvl(p_filtro2, 0) <> 0) then
        update confescaninho g
           set usuarioliberacao = r_usuario.idusuario,
               dataliberacao    = sysdate
         where idnotafiscal = p_filtro1
           and idescaninho = p_filtro2
           and status = 2
           and usuarioliberacao is null
           and dataliberacao is null;
      
        pk_utilities.GeraLog(p_usuario,
                             'Finalização do Ponto de Alerta na Colmeia pelo idusuário: ' ||
                              p_usuario || ' do idescaninho: ' || p_filtro2 ||
                              ' da nota: ' || p_filtro1, p_filtro2, 'LS');
      
      end if;
    
    end if;
  
    return null;
  end;

  function pontoAlertaLiberado
  (
    p_operacao in number,
    p_filtro1  in number default null,
    p_filtro2  in number default null,
    p_filtro3  in number default null
  ) return number is
  
    v_pontoalertaliberado number;
  
  begin
  
    if p_operacao = C_OPERACAO_PACKING then
    
      begin
        select 1
          into v_pontoalertaliberado
          from confpacking
         where idnotafiscal = p_filtro1
           and idonda = p_filtro2
           and status <> 2
           and idpacking = p_filtro3
           and usuarioliberacao is not null
           and dataliberacao is not null;
      exception
        when no_data_found then
          v_pontoalertaliberado := 0;
      end;
    elsif p_operacao = C_OPERACAO_COLMEIA then
    
      begin
        select distinct 1
          into v_pontoalertaliberado
          from confescaninho g
         where idescaninho = p_filtro1
           and idnotafiscal = p_filtro2
           and usuarioliberacao is not null
           and dataliberacao is not null;
      exception
        when no_data_found then
          v_pontoalertaliberado := 0;
      end;
    
    end if;
  
    return v_pontoalertaliberado;
  
  end;
end;
/

