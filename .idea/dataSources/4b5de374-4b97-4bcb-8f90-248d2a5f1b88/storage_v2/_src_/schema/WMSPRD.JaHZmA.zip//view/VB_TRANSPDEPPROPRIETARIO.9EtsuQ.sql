create view VB_TRANSPDEPPROPRIETARIO as
select e.rowid h$tableid, e.razaosocial, e.identidade, e.fantasia, e.cgc, t.descr tipo,
       e.inscrestadual, e.codigointerno
  from entidade e, tipo t, depositante d
 where e.tipoentidade = t.idtipo
   and d.identidade = e.identidade
union
select e.rowid h$tableid, e.razaosocial, e.identidade, e.fantasia, e.cgc, t.descr tipo,
       e.inscrestadual, e.codigointerno
  from entidade e, tipo t
 where e.tipoentidade = t.idtipo
   and t.descr like '%TRANSPOR%'
union
select e.rowid h$tableid, e.razaosocial, e.identidade, e.fantasia, e.cgc, t.descr tipo,
       e.inscrestadual, e.codigointerno
  from entidade e, tipo t
 where e.tipoentidade = t.idtipo
   and t.descr like '%PROPRIET%'
/

