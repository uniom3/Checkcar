create view V_EXP_INVENTARIO as
select 'I' I, e.cgc CNPJDEPOSITANTE,
       SUBSTR(v.codigointerno, 0, 20) as codigointerno, v.estoque,
       v.inventario,
       PK_PRODUTO.ret_codbarra_tratando_erro(v.idproduto, 1) BARRA,
       substr(v.descr, 0, 80) as descr, v.idinventario, '*' F, v.idproduto,
       v.estado, v.codigointerno as codinterno, v.descr as descrprod
  from v_compestinvExp v, inventario i, entidade e
 where v.idinventario = i.idinventario
   and e.identidade = v.identidade
/

