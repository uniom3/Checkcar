create view VT_REMANEJAMENTO_DET as
select lr.idremanejamento h$idremanejamento, lr.idlote, lo.descr lote,
       lr.qtde, p.codigointerno codigoproduto, p.descr produto,
       e.descr embalagem, e.descrreduzido embreduzida, e.apresentacao,
       e.fatorconversao, (lr.qtde / e.fatorconversao) qtde_emb,
       p.idproduto h$idproduto, lo.iddepositante h$iddepositante
  from loteremanejamento lr, lote lo, produto p, embalagem e
 where lo.idlote = lr.idlote
   and e.idproduto = lo.idproduto
   and e.barra = lo.barra
   and p.idproduto = lo.idproduto
/

