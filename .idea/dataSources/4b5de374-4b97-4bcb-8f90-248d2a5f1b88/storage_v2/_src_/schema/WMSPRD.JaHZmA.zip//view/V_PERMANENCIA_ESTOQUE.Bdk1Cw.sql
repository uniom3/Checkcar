create view V_PERMANENCIA_ESTOQUE as
select p.idproduto, p.codigointerno codprod, p.descr produto, count(l.idlote) totallote,
       sum(s.datasaida - e.dataentrada) totaldias,
       round(sum(s.datasaida - e.dataentrada) / count(l.idlote), 2) mediadias
  from lote l,
       (select l.idlote, trunc(ll.dtalocacao) dataentrada
           from lote l, mapaalocacao ma, lotelocal ll
          where ma.idlote = l.idlote
            and ll.idarmazem = ma.idarmazem
            and ll.idlocal = ma.idlocal
            and ll.idlote = ma.idlote
            and l.tipopalet <>'X' /*in ('I','C')*/) e,
       (select hs.idlote, max(trunc(hs.dataestoque)) datasaida
           from historicoestoque hs, paletseparacao ps
          where hs.estoqueapos = 0
            and hs.estoqueanterior <> 0
            and ps.idarmazem = hs.idarmazem
            and ps.idlocal = hs.idlocal
            and ps.idlote = hs.idlote
            and hs.idlote not in (select idlote
                                    from lotelocal
                                   where estoque <> 0
                                     and idlote = hs.idlote)
          group by hs.idlote) s, produto p
 where e.idlote = l.idlote
   and s.idlote = l.idlote
   and p.idproduto = l.idproduto
 group by p.idproduto, p.codigointerno, p.descr

/

