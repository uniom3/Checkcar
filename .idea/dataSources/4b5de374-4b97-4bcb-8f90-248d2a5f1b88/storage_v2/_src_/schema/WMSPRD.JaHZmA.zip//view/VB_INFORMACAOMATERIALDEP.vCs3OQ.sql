create view VB_INFORMACAOMATERIALDEP as
select imd.idinfomaterial, im.informacao, imd.valorunico,
       imd.identidade h$identidade, imd.idproduto h$idproduto,
       imd.imprimeetiqueta h$imprimeetiqueta, im.sequencia h$sequencia
  from informacaomatdep imd, informacaomaterial im
 where imd.idinfomaterial = im.idinfomaterial
 order by sequencia
/

