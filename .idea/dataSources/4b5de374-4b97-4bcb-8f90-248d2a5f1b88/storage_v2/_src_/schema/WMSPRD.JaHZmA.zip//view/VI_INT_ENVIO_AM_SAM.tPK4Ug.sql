create view VI_INT_ENVIO_AM_SAM as
select agrupador id, agrupador, vendorpartyid, warehouselocationid,
       marketplaceid, samplingeffectivedatetime
  from int_envio_am_sam
/

