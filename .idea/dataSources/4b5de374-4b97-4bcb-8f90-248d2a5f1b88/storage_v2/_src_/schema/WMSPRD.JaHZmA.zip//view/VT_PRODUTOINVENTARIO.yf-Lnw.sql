create view VT_PRODUTOINVENTARIO as
select (select count(1)
           from produtoinventario
          where idinventario = i.idinventario
            and idproduto = p.idproduto) marcado, p.idproduto,
       p.codigointerno codproduto, p.descr produto, p.codreferencia,
       t.descr tipo, st.descr subtipo, f.razaosocial familia,
       sf.descr subfamilia, m.descr marca, sm.descr submarca,
       cf.codigo || ' - ' || cf.descr classificacaofiscal,
       cm.nome classificacaomaterial, i.idinventario h$idinventario
  from inventario i, produto p, tipoproduto t, subtipoproduto st, entidade f,
       subfamilia sf, marca m, submarca sm, classificacaofiscal cf,
       classificacaomaterial cm
 where t.idtipo = p.idtipo
   and st.idtipo = p.idtipo
   and st.idsubtipo = p.idsubtipo
   and f.identidade = p.idfamilia
   and sf.idsubfamilia(+) = p.idsubfamilia
   and m.idmarca(+) = p.idmarca
   and sm.idsubmarca(+) = p.idsubmarca
   and cf.idclassificacao(+) = p.idclassificacao
   and cm.id(+) = p.idclassificacaomat
   and exists (select 1
          from embalagem
         where idproduto = p.idproduto)
   and exists (select 1
          from depositanteinventario di, produtodepositante pd
         where di.idinventario = i.idinventario
           and pd.identidade = di.identidade
           and pd.idproduto = p.idproduto)
/

