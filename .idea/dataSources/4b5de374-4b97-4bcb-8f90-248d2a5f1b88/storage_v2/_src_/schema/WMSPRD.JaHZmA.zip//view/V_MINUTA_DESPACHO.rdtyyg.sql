create view V_MINUTA_DESPACHO as
select distinct c.idcarga, c.codigointerno, c.rgmotorista, c.data,
                c.motorista, c.placa, rp.idromaneio, nf.iddepositante,
                nf.destinatario iddestinatario, nf.codigointerno numnf,
                nf.totalgeral,
                decode(nf.freteporconta, 1, 'POR CONTA DO EMITENTE', 2,
                        'POR CONTA DO DESTINATARIO', nf.freteporconta) frete,
                nf.idprenf, t.razaosocial transportadora,
                r.razaosocial remetente, er.logradouro enderem,
                er.numero nrorem, er.complemento comprem, er.cep ceprem,
                br.descr bairrorem, cr.descr cidaderem,
                cr.estadocidade ufrem, d.razaosocial destinatario,
                ed.logradouro endedest, ed.numero nrodest,
                ed.complemento compdest, ed.cep cepdest, bd.descr bairrodest,
                cd.descr cidadedest, cd.estadocidade ufdest,
                dp.razaosocial depositante, c.nomecontato, ct.numcoleta,
                cv.descr tipoveiculo, ct.datasolicitacao,
                nfi.instrucao22 importante,
                decode(rp.tipo, 0, vr.qtdevolume, vnf.qtdevolume) qtdevolume,
                nvl(decode(rp.tipo, 0, vr.pesovolume, vnf.pesovolume),
                     pk_notafiscal.get_peso_notafiscal(nf.idnotafiscal)) pesovolume,
                rp.pesoteorico, c.obs,
                nvl(nf.numpedidofornecedor, 'NAO ENV.') numpedidofornecedor
  from carga c, notafiscalcarga nfc,
       (select idnotafiscal, max(idromaneio) idromaneio
           from nfromaneio
          group by idnotafiscal) nfr, romaneiopai rp, notafiscal nf,
       entidade t, entidade r, endereco er, bairro br, cidade cr, entidade d,
       endereco ed, bairro bd, cidade cd, entidade dp,
       (select t.idcarga, t.numcoleta, t.datasolicitacao, t.nomecontato,
                t.dataprevista, t.obs, t.idclassificacao, t.datacadastro
           from contatotransportadora t
          where t.idcontatotransportadora =
                (select max(idcontatotransportadora)
                   from contatotransportadora
                  where idcarga = t.idcarga)) ct, classificacaoveiculo cv,
       nfimpressao nfi,
       (select vo.idromaneio, count(vo.idvolume) qtdevolume,
                sum(vo.peso) pesovolume, sum(tc.peso) pesocaixa,
                sum(vo.pesoauditado) pesovolumeauditado
           from volumeromaneio vo, tipocaixavolume tc
          where tc.idtipocaixavolume = vo.idtipocaixavolume
          group by idromaneio) vr,
       (select vo.idnotafiscal, count(vo.idvolume) qtdevolume,
                sum(vo.peso) pesovolume, sum(tc.peso) pesocaixa,
                sum(vo.pesoauditado) pesovolumeauditado
           from volumeromaneio vo, tipocaixavolume tc
          where tc.idtipocaixavolume = vo.idtipocaixavolume
          group by vo.idnotafiscal) vnf
 where vnf.idnotafiscal(+) = nf.idnotafiscal
   and vr.idromaneio(+) = rp.idromaneio
   and nfi.idprenf = nf.idprenf
   and cv.idclassificacao(+) = ct.idclassificacao
   and ct.idcarga(+) = c.idcarga
   and dp.identidade = nf.iddepositante
   and cd.idcidade(+) = bd.idcidade
   and bd.idbairro(+) = ed.idbairro
   and ed.idendereco(+) = pk_entidade.f_ret_idendereco(d.identidade)
   and ed.identidade(+) = d.identidade
   and d.identidade = nf.destinatario
   and cr.idcidade(+) = br.idcidade
   and br.idbairro(+) = er.idbairro
   and er.idendereco(+) = pk_entidade.f_ret_idendereco(r.identidade)
   and er.identidade(+) = r.identidade
   and r.identidade = nf.remetente
   and t.identidade(+) = c.idtransportadora
   and nf.idnotafiscal = nfc.idnotafiscal
   and rp.idromaneio = nfr.idromaneio
   and nfr.idnotafiscal = nfc.idnotafiscal
   and nfc.idcarga = c.idcarga
 order by dp.razaosocial, d.razaosocial, nf.codigointerno
/

