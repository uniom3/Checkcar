create package body PK_PICKING_DINAMICO is

  C_REMOVER_PICKING constant number := 0;
  C_INSERIR_PICKING constant number := 1;

  function inserir_picking_dinamico_auto
  (
    p_idProduto       in number,
    p_idDepositante   in number,
    p_idarmazem       in number,
    p_tipoPicking     in setor.tipopermitirpickingsetor%type,
    p_loteunico       pk_lote.t_loteunico := null,
    p_idTipoPedido    in number := null,
    p_UtzCodIntDepErp in number,
    p_CodDepErpSenior in varchar2
  ) return varchar2 is
  
    cursor c_SelecionarLocal
    (
      p_idProduto     number,
      p_idDepositante number,
      p_idArmazem     number,
      p_estado        varchar
    ) is
      select loc.idlocal, loc.idarmazem, loc.ordem, loc.prioridade
        from (select l.idlocal, l.pesomaximo, l.idarmazem, l.volumemaximo,
                      l.ordem, 0 prioridade
                 from local l
                where exists (select 1
                         from setordepositante sd
                        where sd.idsetor = l.idsetor
                          and sd.iddepositante = p_idDepositante)
                  and exists (select 1
                         from setorproduto sp
                        where sp.idsetor = l.idsetor
                          and sp.idproduto = p_idProduto)
                  and l.picking = 'S'
                  and l.buffer = 'N'
                  and l.idarmazem = p_idArmazem
                  and l.idlocal = l.idlocal
                  and l.ativo = 'S'
                  and l.tipo = 0
                  and not exists
                (select 1
                         from produtolocal p
                        where p.idlocal = l.idlocal)
                  and ((not exists (select 1
                                      from lotelocal ll
                                     where ll.idlocal = l.idlocal)) OR
                      (exists
                       (select 1
                           from lotelocal ll
                          where ll.idlocal = l.idlocal
                            and ll.estoque + ll.adicionar - ll.pendencia = 0)))
                  and exists
                (select 1
                         from setor s, tiposetor ts
                        where s.idtiposetor = ts.idtiposetor
                          and s.idsetor = l.idsetor
                          and s.tipopermitirpickingsetor = p_tipoPicking
                          and decode(nvl(s.expedicao, 'S'), 'S', 1, 0) = 1
                          and decode(s.ativo, 'S', 1, 0) = 1
                          and ((decode(ts.normal, 'S', 'N', '0') = p_estado) or
                              (decode(ts.vencido, 'S', 'T', '0') = p_estado) or
                              (decode(ts.danificado, 'S', 'D', '0') =
                              p_estado)))
               union
               select l.idlocal, l.pesomaximo, l.idarmazem, l.volumemaximo,
                      l.ordem, 1 prioridade
                 from local l, depositante d
                where exists (select 1
                         from setordepositante sd
                        where sd.idsetor = l.idsetor
                          and sd.iddepositante = p_idDepositante)
                  and exists (select 1
                         from setorproduto sp
                        where sp.idsetor = l.idsetor
                          and sp.idproduto = p_idProduto)
                  and l.picking = 'S'
                  and l.buffer = 'N'
                  and l.idarmazem = p_idArmazem
                  and l.idlocal = l.idlocal
                  and d.identidade = p_idDepositante
                  and d.pickingmultiplo = 'S'
                  and l.ativo = 'S'
                  and l.tipo = 0
                  and exists
                (select 1
                         from produtolocal p
                        where p.idlocal = l.idlocal)
                  and ((not exists (select 1
                                      from lotelocal ll
                                     where ll.idlocal = l.idlocal)) OR
                      (exists
                       (select 1
                           from lotelocal ll
                          where ll.idlocal = l.idlocal
                            and ll.estoque + ll.adicionar - ll.pendencia = 0)))
                  and exists
                (select 1
                         from setor s, tiposetor ts
                        where s.idtiposetor = ts.idtiposetor
                          and s.idsetor = l.idsetor
                          and s.tipopermitirpickingsetor = p_tipoPicking
                          and decode(nvl(s.expedicao, 'S'), 'S', 1, 0) = 1
                          and decode(s.ativo, 'S', 1, 0) = 1
                          and ((decode(ts.normal, 'S', 'N', '0') = p_estado) or
                              (decode(ts.vencido, 'S', 'T', '0') = p_estado) or
                              (decode(ts.danificado, 'S', 'D', '0') =
                              p_estado)))
               union
               select l.idlocal, l.pesomaximo, l.idarmazem, l.volumemaximo,
                      l.ordem, 2 prioridade
                 from local l, depositante d
                where exists (select 1
                         from setordepositante sd
                        where sd.idsetor = l.idsetor
                          and sd.iddepositante = p_idDepositante)
                  and exists (select 1
                         from setorproduto sp
                        where sp.idsetor = l.idsetor
                          and sp.idproduto = p_idProduto)
                  and l.picking = 'S'
                  and l.buffer = 'N'
                  and l.idarmazem = p_idArmazem
                  and l.idlocal = l.idlocal
                  and d.identidade = p_idDepositante
                  and d.pickingmultiplo = 'S'
                  and l.ativo = 'S'
                  and l.tipo = 0
                  and not exists
                (select 1
                         from produtolocal p
                        where p.idlocal = l.idlocal)
                  and ((exists (select 1
                                  from lotelocal ll
                                 where ll.idlocal = l.idlocal)) OR
                      (exists
                       (select 1
                           from lotelocal ll
                          where ll.idlocal = l.idlocal
                            and ll.estoque + ll.adicionar - ll.pendencia > 0)))
                  and exists
                (select 1
                         from setor s, tiposetor ts
                        where s.idtiposetor = ts.idtiposetor
                          and s.idsetor = l.idsetor
                          and s.tipopermitirpickingsetor = p_tipoPicking
                          and decode(nvl(s.expedicao, 'S'), 'S', 1, 0) = 1
                          and decode(s.ativo, 'S', 1, 0) = 1
                          and ((decode(ts.normal, 'S', 'N', '0') = p_estado) or
                              (decode(ts.vencido, 'S', 'T', '0') = p_estado) or
                              (decode(ts.danificado, 'S', 'D', '0') =
                              p_estado)))
               union
               select l.idlocal, l.pesomaximo, l.idarmazem, l.volumemaximo,
                      l.ordem, 3 prioridade
                 from local l, depositante d
                where exists (select 1
                         from setordepositante sd
                        where sd.idsetor = l.idsetor
                          and sd.iddepositante = p_idDepositante)
                  and exists (select 1
                         from setorproduto sp
                        where sp.idsetor = l.idsetor
                          and sp.idproduto = p_idProduto)
                  and l.picking = 'S'
                  and l.buffer = 'N'
                  and l.idarmazem = p_idArmazem
                  and l.idlocal = l.idlocal
                  and d.identidade = p_idDepositante
                  and d.pickingmultiplo = 'S'
                  and l.ativo = 'S'
                  and l.tipo = 0
                  and exists
                (select 1
                         from produtolocal p
                        where p.idlocal = l.idlocal)
                  and ((exists (select 1
                                  from lotelocal ll
                                 where ll.idlocal = l.idlocal)) OR
                      (exists
                       (select 1
                           from lotelocal ll
                          where ll.idlocal = l.idlocal
                            and ll.estoque + ll.adicionar - ll.pendencia > 0)))
                  and exists
                (select 1
                         from setor s, tiposetor ts
                        where s.idtiposetor = ts.idtiposetor
                          and s.idsetor = l.idsetor
                          and s.tipopermitirpickingsetor = p_tipoPicking
                          and decode(nvl(s.expedicao, 'S'), 'S', 1, 0) = 1
                          and decode(s.ativo, 'S', 1, 0) = 1
                          and ((decode(ts.normal, 'S', 'N', '0') = p_estado) or
                              (decode(ts.vencido, 'S', 'T', '0') = p_estado) or
                              (decode(ts.danificado, 'S', 'D', '0') =
                              p_estado)))) loc, local lc
       where 1 = 1
         and lc.idlocal = loc.idlocal
         and lc.idarmazem = loc.idarmazem
         and ((nvl(p_idTipoPedido, 0) = 0) or exists
              (select 1
                 from setorclassificacaotipopedido sctp
                where sctp.idtipopedido = p_idTipoPedido
                  and sctp.idsetor = lc.idsetor))
         and exists
       (select 1
                from setordepositante sd
               where sd.idsetor = lc.idsetor
                 and sd.iddepositante = p_idDepositante
                 and ((p_UtzCodIntDepErp = 0) OR
                     ((p_UtzCodIntDepErp = 1) AND
                     (sd.codintegracao = p_CodDepErpSenior))))
         and ((not exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi,
                       gtt_assist_formacao_onda gf
                 WHERE (gi.parametro = pk_armazem.C_GTT_ASSIST_BLOCOINICIO and
                       gf.parametro = pk_armazem.C_GTT_ASSIST_BLOCOFIM))) OR
             (exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi,
                       gtt_assist_formacao_onda gf
                 WHERE gi.parametro = pk_armazem.C_GTT_ASSIST_BLOCOINICIO
                   and gf.parametro = pk_armazem.C_GTT_ASSIST_BLOCOFIM
                   AND LPAD(lc.BLOCO, LENGTH(lc.MASCARABLOCO), ' ') BETWEEN
                       LPAD(gi.varchar2value, LENGTH(lc.MASCARABLOCO), ' ') AND
                       LPAD(gf.varchar2value, LENGTH(lc.MASCARABLOCO), ' '))))
         and ((not exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi,
                       gtt_assist_formacao_onda gf
                 WHERE (gi.parametro = pk_armazem.C_GTT_ASSIST_RUAINICIO and
                       gf.parametro = pk_armazem.C_GTT_ASSIST_RUAFIM))) OR
             (exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi,
                       gtt_assist_formacao_onda gf
                 WHERE gi.parametro = pk_armazem.C_GTT_ASSIST_RUAINICIO
                   and gf.parametro = pk_armazem.C_GTT_ASSIST_RUAFIM
                   AND LPAD(lc.RUA, LENGTH(lc.MASCARARUA), ' ') BETWEEN
                       LPAD(gi.varchar2value, LENGTH(lc.MASCARARUA), ' ') AND
                       LPAD(gf.varchar2value, LENGTH(lc.MASCARARUA), ' '))))
         and ((not exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi
                 WHERE gi.parametro = pk_armazem.C_GTT_ASSIST_TIPOLOCAL)) OR
             (exists
              (SELECT 1
                  FROM gtt_assist_formacao_onda gi
                 WHERE gi.parametro = pk_armazem.C_GTT_ASSIST_TIPOLOCAL
                   and decode(lc.tipo, 0, 2, 1, 1, 2, 1) = gi.numbervalue)))
       order by loc.prioridade, loc.ordem asc;
  
    r_SelecionarLocal c_SelecionarLocal%rowType;
    v_msgErro         varchar2(4000);
    v_compativel      boolean;
    v_idlocalPicking  local.idlocal%type;
  
    v_msg t_message;
  
  begin
    open c_SelecionarLocal(p_idproduto, p_iddepositante, p_idarmazem,
                           nvl(p_loteunico.estado, 'N'));
    fetch c_SelecionarLocal
      into r_SelecionarLocal;
  
    if (c_SelecionarLocal%notfound) then
      close c_SelecionarLocal;
      v_msg := t_message('Não foi possível selecionar um local para cadastrar picking dinâmico para alocar o lotes do produto Id:{0} para Depositante Id:{1} no Armazém Id:{2}.');
      v_msg.addParam(p_idproduto);
      v_msg.addParam(p_iddepositante);
      v_msg.addParam(p_idarmazem);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_loteunico.idProduto is not null) then
      while c_SelecionarLocal%found
      loop
      
        v_compativel := pk_lote.isLocalPodeReceberLoteUnico(p_loteunico,
                                                            p_idarmazem,
                                                            r_SelecionarLocal.Idlocal,
                                                            v_msgErro);
      
        if (v_compativel) then
          v_idlocalPicking := r_SelecionarLocal.Idlocal;
          exit;
        end if;
      
        fetch c_SelecionarLocal
          into r_SelecionarLocal;
      end loop;
    ELSE
      v_idlocalPicking := r_SelecionarLocal.Idlocal;
    end if;
  
    if (v_idlocalPicking is null) then
      v_msg := t_message('Não foi possível selecionar um local para cadastrar picking dinâmico para alocar o lotes do produto Id:{0} para Depositante Id:{1} no Armazém Id:{2}.');
      v_msg.addParam(p_idproduto);
      v_msg.addParam(p_iddepositante);
      v_msg.addParam(p_idarmazem);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_armazem.criarPickingProduto(p_idarmazem, r_SelecionarLocal.Idlocal,
                                   p_iddepositante, p_idproduto);
  
    return v_idlocalPicking;
  end;

  procedure inserir_picking_dinamico is
    cursor c_picking is
      select g.idproduto, g.iddepositante, g.idlocal, g.idarmazem
        from gtt_picking_dinamico g, local lo, produtodepositante pd
       where g.operacao = C_INSERIR_PICKING
         and lo.idarmazem = g.idarmazem
         and lo.idlocal = g.idlocal
         and lo.tipo = 0
         and lo.buffer = 'N'
         and pd.identidade = g.iddepositante
         and pd.idproduto = g.idproduto
         and pd.pickingdinamico = 1
         and not exists (select 1
                from produtolocal pl
               where pl.idproduto = g.idproduto
                 and pl.idarmazem = g.idarmazem
                 and pl.idlocal = g.idlocal);
  
    r_picking c_picking%rowtype;
  
  begin
    for r_picking in c_picking
    loop
      pk_armazem.criarPickingProduto(r_picking.idarmazem, r_picking.idlocal,
                                     r_picking.iddepositante,
                                     r_picking.idproduto);
    end loop;
  end;

  procedure deletar_picking_dinamico is
    v_estoque       number;
    v_tem_outro_pk  number;
    v_estoque_local number;
  begin
  
    for c in (select g.idproduto, g.iddepositante, g.idlocal, g.idarmazem,
                     pd.pickingdinamico, s.tipopermitirpickingsetor
                from gtt_picking_dinamico g, depositante d,
                     produtodepositante pd, local lo, setor s
               where d.identidade = g.iddepositante
                 and pd.identidade = d.identidade
                 and pd.idproduto = g.idproduto
                 and lo.idlocal = g.idlocal
                 and lo.idarmazem = g.idarmazem
                 and s.idsetor = lo.idsetor
                 and g.operacao = C_REMOVER_PICKING)
    loop
      if c.pickingdinamico = 1 then
        select nvl(sum(ll.estoque + ll.adicionar), 0)
          into v_estoque
          from lotelocal ll, lote l
         where l.idlote = ll.idlote
           and l.idproduto = c.idproduto
           and l.iddepositante = c.iddepositante;
      
        select nvl(sum(ll.estoque + ll.adicionar), 0)
          into v_estoque_local
          from lotelocal ll, lote l
         where l.idlote = ll.idlote
           and ll.idlocal = c.idlocal
           and l.idproduto = c.idproduto
           and l.iddepositante = c.iddepositante;
      
        select count(*)
          into v_tem_outro_pk
          from produtolocal pl, local lo, setor s
         where pl.idproduto = c.idproduto
           and pl.identidade = c.iddepositante
           and pl.idlocal <> c.idlocal
           and lo.idlocal = pl.idlocal
           and lo.idarmazem = pl.idarmazem
           and s.idsetor = lo.idsetor
           and s.tipopermitirpickingsetor = c.tipopermitirpickingsetor;
      
        if v_estoque = 0 then
          delete from produtolocal pd
           where pd.idproduto = c.idproduto
             and pd.idarmazem = c.idarmazem
             and pd.identidade = c.iddepositante
             and not exists
           (select 1
                    from pickingpicktolightonda po
                   where po.idprodutolocal = pd.idprodutolocal);
        
        elsif ((v_estoque > 0) and (v_estoque_local = 0) and
              (v_tem_outro_pk > 0)) then
          delete from produtolocal pd
           where pd.idproduto = c.idproduto
             and pd.idlocal = c.idlocal
             and pd.idarmazem = c.idarmazem
             and pd.identidade = c.iddepositante
             and not exists
           (select 1
                    from pickingpicktolightonda po
                   where po.idprodutolocal = pd.idprodutolocal);
        end if;
      end if;
    end loop;
  
    delete from gtt_picking_dinamico;
  end;

  /*procedure deletar_picking_dinamico
  (
    p_idlote    in number,
    p_idarmazem in number,
    p_idlocal   in local.idlocal%type
  ) is
    v_pk_dinamico   number;
    v_iddepositante number;
    v_idproduto     number;
    v_estoque       number;
    v_tem_outro_pk  number;
    v_estoque_local number;
  begin
    --PICKING DINAMICO
    --verifica se o armazem opera com picking dinamico
    select ll.idproduto, ll.iddepositante, count(*)
      into v_idproduto, v_iddepositante, v_pk_dinamico
      from lote ll, produtodepositante pd
     where ll.idlote = p_idlote
       and pd.identidade = ll.iddepositante
       and pd.idproduto = ll.idproduto
       and pd.pickingdinamico = 1
     group by ll.idproduto, ll.iddepositante;
  
    if v_pk_dinamico > 0 then
      select nvl(sum(ll.estoque + ll.adicionar), 0)
        into v_estoque
        from lotelocal ll, lote l
       where l.idlote = ll.idlote
         and l.idproduto = v_idproduto
         and l.iddepositante = v_iddepositante;
    
      select nvl(sum(ll.estoque + ll.adicionar), 0)
        into v_estoque_local
        from lotelocal ll, lote l
       where l.idlote = ll.idlote
         and ll.idlocal = p_idlocal
         and l.idproduto = v_idproduto
         and l.iddepositante = v_iddepositante;
    
      select count(*)
        into v_tem_outro_pk
        from produtolocal pl
       where pl.idproduto = v_idproduto
         and pl.identidade = v_iddepositante
         and pl.idlocal <> p_idlocal;
    
      if v_estoque = 0 then
        delete from produtolocal pd
         where pd.idproduto = v_idproduto
           and pd.idarmazem = p_idarmazem;
      elsif ((v_estoque > 0) and (v_estoque_local = 0) and
            (v_tem_outro_pk > 0)) then
        delete from produtolocal pd
         where pd.idproduto = v_idproduto
           and pd.idlocal = p_idlocal
           and pd.idarmazem = p_idarmazem;
      end if;
    end if;
  exception
    when no_data_found then
      return;
  end;*/

  procedure addGttPickingDinamico
  (
    p_idproduto     in number,
    p_idDepositante in number,
    p_idLocal       in varchar2,
    p_idArmazem     in number,
    p_Operacao      in number
  ) is
  begin
    begin
      insert into GTT_PICKING_DINAMICO
        (idproduto, iddepositante, idlocal, idArmazem, operacao)
      values
        (p_idproduto, p_idDepositante, p_idLocal, p_idArmazem, p_Operacao);
    exception
      when DUP_VAL_ON_INDEX then
        return;
    end;
  end addGttPickingDinamico;

end PK_PICKING_DINAMICO;
/

