create view VT_LOGINTEGRACAO as
select l.data, decode(l.tipo, 'S', 'SUCESSO', 'E', 'ERRO', l.tipo) tipo,
       l.idprenf, l.numpedido pedido, l.numnf notafiscal,
       l.codprod codproduto, l.barra, upper(l.arquivo) arquivo,
       upper(l.extencaoarq) extensao, l.texto, l.descr, l.sql,
       u.nomeusuario usuario, l.idusuario, l.idlogintegracao idlog,
       l.agrupador, l.tipo h$tipo, l.agrupador h$agrupador,
       l.data h$dtPeriodo, l.rowid h$tableid
  from logintegracao l, usuario u
 where u.idusuario(+) = l.idusuario
/

