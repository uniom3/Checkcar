create view V_COMPESTINV as
select di.identidade, cont.idinventario, cont.idproduto, pr.codigointerno,
       pr.codreferencia, pr.descr, sum(cont.qtdeunid) inventario,
       sum(nvl(est.estoque, 0)) estoque,
       sum(cont.qtdeunid - nvl(est.estoque, 0)) diferenca,
       (cont.idinventario || cont.idproduto) linha
  from (select id.idinventario, id.idproduto, id.identidade,
                sum(id.qtd * id.fator) qtdeunid
           from invdetliberado id
          group by id.idinventario, id.idproduto, id.identidade) cont,
       (select idinventario, idproduto, identidade, sum(estoque) estoque
           from invest
          group by idinventario, idproduto, identidade) est, produto pr,
       inventario iv, depositanteinventario di
 where iv.idinventario = cont.idinventario
   and di.idinventario = iv.idinventario
   and est.idinventario = iv.idinventario
   and est.idproduto(+) = cont.idproduto
   and pr.idproduto = cont.idproduto
 group by di.identidade, cont.idinventario, cont.idproduto, pr.codigointerno,
          pr.codreferencia, pr.descr
/

