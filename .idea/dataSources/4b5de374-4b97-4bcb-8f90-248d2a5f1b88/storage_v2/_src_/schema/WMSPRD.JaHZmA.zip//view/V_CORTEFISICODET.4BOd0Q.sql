create view V_CORTEFISICODET as
select r.codigointerno onda, nf.numpedidofornecedor pedido, nf.idnotafiscal,
       f.codbarratarefa tarefa,
       stragg(distinct los.idlocalformatado) local_sep,
       stragg(distinct lo.idlocalformatado) local_corte,
       p.codigointerno codproduto, p.descr produto,
       (f.qtdeseparacao - nvl(f.qtdeconfirmada, f.qtdeencontrada)) qtdecorte,
       stragg(distinct us.nomeusuario) separador,
       stragg(distinct ur.nomeusuario) usuario_resolucao,
       decode(lo.tipo, 0, 'Separação', 1, 'Separação', 2, 'Separação', 8,
               'Packing', 'Local Não Fornecido') tipolocalcorte,
       decode(f.status, 0, 'AGUARDANDO', 1, 'ACEITO', 'RECUSADO') status,
       stragg(distinct u.nomeusuario) conferente, f.data datacorte,
       f.dataresolucao
  from cortefisico f, romaneiopai r, local lo, regiaoarmazenagem rao,
       regiaoarmazenagem rad, produto p, usuario u, embalagem e,
       notafiscal nf, cortefisiconf fn, resestoquecortefisiconf res,
       v_tarefas_onda m, usuario us, local los, v_tarefas_onda mn,
       usuario ur, confpacking cp
 where r.idromaneio = f.idonda
   and lo.id = f.idenderecofalta
   and rao.idregiao = f.idregiaoorigem
   and rad.idregiao = f.idregiaodestino
   and p.idproduto = f.idproduto
   and e.idproduto(+) = f.idproduto
   and e.barra(+) = f.barra
   and fn.idnotafiscal = nf.idnotafiscal
   and fn.idcortefisico = f.id
   and fn.qtdeseparacao <> fn.qtdeutilizada
   and res.idcortefisiconf = fn.id
   and m.id = res.idmovimentacaoafetada
   and us.idusuario = m.idusuario
   and los.id = m.idlocalorigem
   and mn.id(+) = res.idmovimentacaonova
   and ur.idusuario(+) = f.idusuarioresolucao
   and cp.codbarratarefa(+) = f.codbarratarefa
   and cp.idonda(+) = f.idonda
   and u.idusuario(+) = cp.idusuario
 group by r.codigointerno, nf.numpedidofornecedor, nf.idnotafiscal,
          f.codbarratarefa, p.codigointerno, p.descr,
          (f.qtdeseparacao - nvl(f.qtdeconfirmada, f.qtdeencontrada)),
          decode(lo.tipo, 0, 'Separação', 1, 'Separação', 2, 'Separação', 8,
                  'Packing', 'Local Não Fornecido'),
          decode(f.status, 0, 'AGUARDANDO', 1, 'ACEITO', 'RECUSADO'), f.data,
          f.dataresolucao
 order by f.data desc
/

