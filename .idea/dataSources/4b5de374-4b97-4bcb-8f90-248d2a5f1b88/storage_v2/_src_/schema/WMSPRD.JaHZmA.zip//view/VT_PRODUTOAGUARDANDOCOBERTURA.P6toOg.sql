create view VT_PRODUTOAGUARDANDOCOBERTURA as
select rownum h$tableid, c.idlotenf, c.codproduto, c.descricao produto,
       round(c.qtdeacobrir, 6) qtdeacobrir, c.vlrunit valorunitario,
       c.embalagem, c.fatorconversao, c.qtdeacobrirunid, c.numnf notafiscal,
       c.serie, c.dataemissao dtemissao, c.cnpjdepositante, c.depositante,
       c.emitente, c.destinatario, c.emitentefantasia fantasiaemitente,
       c.idproduto, c.iddepositante, c.idnotafiscal, c.idarmazem h$idarmazem,
       c.loteindustria, c.dtvenc
  from v_cobertura_notafiscal c
/

