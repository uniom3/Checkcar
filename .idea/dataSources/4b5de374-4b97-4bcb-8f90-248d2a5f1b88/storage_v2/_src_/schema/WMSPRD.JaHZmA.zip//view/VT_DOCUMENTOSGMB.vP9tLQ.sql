create view VT_DOCUMENTOSGMB as
select h$tableid, tipo, notafiscal numero, dataesperadaembarque,
       cnpjdepositante, depositante, cnpjemitente, emitente, estadonf,
       valortotal, estoqueverificado, picktolight, datacadastro,
       usuariocadastro, transportadora, imprimeetiquetatransportador,
       (pesobruto / 1000) pesobrutokg, (pesoliquido / 1000) pesoliquidokg,
       operacao, cfop, usuariocancelamento, motivocancelamento,
       dtcancelamento, observacao, iddepositante, idremetente,
       idtransportadora, idnotafiscal id, h$idarmazem, h$statusnf, h$estado,
       h$tipo, h$tipooperacao, h$idnotafiscalvinculada, h$existenfvinculada,
       h$naoPermiteDesfazerCancDoc, h$qtcorteliberacao, idprenf h$idprenf,
       digitada h$digitada, h$permiteexclusaogmbepedretarm,
       h$exigesenhaexclugmbepedretarm
  from v_notafiscal
 where trim(h$tipooperacao) = 'G'
/

