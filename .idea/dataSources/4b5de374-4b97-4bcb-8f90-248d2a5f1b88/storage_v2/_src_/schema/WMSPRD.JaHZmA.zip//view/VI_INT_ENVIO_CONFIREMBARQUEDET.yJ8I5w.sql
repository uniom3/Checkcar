create view VI_INT_ENVIO_CONFIREMBARQUEDET as
select i.cnpj_armazem, i.cnpj_depositante, i.cnpj_remetente,
       i.cnpj_destinatario, i.cnpj_transportadora, i.numeronf, i.serienf,
       i.numpedido, i.idcarga, i.dataliberacao, i.numcoleta,
       substr(i.codproduto, 0, 20) codproduto, i.codbarras, i.qtde,
       i.informacaoespecifica, i.agrupador id, '*' f,
       i.codproduto codigoproduto, i.idreplicacao, i.idnotafiscal
  from int_envio_embarquedet i
/

