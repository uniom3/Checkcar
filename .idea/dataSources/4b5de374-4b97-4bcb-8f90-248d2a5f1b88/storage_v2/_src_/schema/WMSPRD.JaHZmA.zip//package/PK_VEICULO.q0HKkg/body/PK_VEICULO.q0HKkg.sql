create package body pk_veiculo is

  v_msg t_message;

  /*
   * Retorna o Volume Total dos Palets do Veiculo.
  */
  function ret_vol_veiculo(p_placa in varchar2) return number is
    v_vol number;
  begin
    begin
      select round((sum((altura * largura * comprimento) -
                         ((altura * largura * comprimento) *
                         (toleranciamed / 100)))) / 1000000000, 2)
        into v_vol
        from veiculopalet
       where placa = p_placa;
    exception
      when others then
        v_vol := 0;
    end;
    return v_vol;
  end;

  /*
   * retorna a qtde maxima de palets para o veiculo
  */
  function ret_nummaxpalet(p_placa in veiculo.placa%type) return number is
    v_palet number;
  begin
    begin
      select v.nummaxpalet
        into v_palet
        from veiculo v
       where v.placa = p_placa;
    exception
      when others then
        v_palet := 0;
    end;
    return v_palet;
  end;

  function pegaveiculopadrao return varchar2 is
    cursor c_veiculo is
      select v.placa
        from veiculo v
       where v.generico = 'S'
       order by v.placa;
  
    r_veiculo c_veiculo%rowtype;
  
  begin
    if c_veiculo%isopen then
      close c_veiculo;
    end if;
    open c_veiculo;
    fetch c_veiculo
      into r_veiculo;
  
    return r_veiculo.placa;
  end;

  function pegar_motorista_veiculo(p_veiculo in varchar2) return varchar2 is
    cursor c_mot(p_veiculo in varchar2) is
      select e.razaosocial
        from pessoasveiculo pv, entidade e
       where e.identidade = pv.identidade
         and pv.placa = p_veiculo;
    --         and pv.tipo = 1;
  
    r_mot   c_mot%rowtype;
    v_campo varchar2(255);
    S       varchar2(10000);
  begin
    if c_mot%isopen then
      close c_mot;
    end if;
    open c_mot(p_veiculo);
    fetch c_mot
      into r_mot;
    if c_mot%found then
      while c_mot%found
      loop
        v_campo := r_mot.razaosocial;
      
        if S is null then
          S := v_campo;
        else
          S := S || ', ' || v_campo;
        end if;
        fetch c_mot
          into r_mot;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
   * Retorna o id do motorista para o veiculo informado
  */
  function pegar_idmotorista(p_veiculo in varchar2) return number is
    cursor c_mot(p_veiculo in varchar2) is
      select identidade
        from pessoasveiculo
       where placa = p_veiculo;
    --and tipo = 1; -- motorista
  
    v_motorista number;
  begin
    if c_mot%isopen then
      close c_mot;
    end if;
    open c_mot(p_veiculo);
    fetch c_mot
      into v_motorista;
    if c_mot%found then
      return v_motorista;
    else
      return null;
    end if;
  end;

  procedure removerVeiculo(p_placaVeiculo in varchar2) is
    v_qtdeVeiculos number;
  begin
    select count(placa)
      into v_qtdeVeiculos
      from romaneiopai r
     where r.placa = p_placaVeiculo;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Este veículo já foi utilizado em romaneio. Não pode ser excluído.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(placa)
      into v_qtdeVeiculos
      from abastecimento a
     where a.placa = p_placaVeiculo;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Este veículo tem histórico de abastecimento. Não pode ser excluído.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(placa)
      into v_qtdeVeiculos
      from veiculopalet vp
     where vp.placa = p_placaVeiculo;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Este veículo tem palet vinculado. Não pode ser excluído.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from pessoasveiculo pv
     where pv.placa = p_placaVeiculo;
  
    delete from veiculo v
     where v.placa = p_placaVeiculo;
  end;

  procedure addMotoristaVeiculo
  (
    p_placaVeiculo in varchar2,
    p_idEntidade   in number
  ) is
  begin
    insert into pessoasveiculo
      (placa, identidade, tipo)
    values
      (p_placaVeiculo, p_idEntidade, null);
  end;

  procedure removeMotoristaVeiculo
  (
    p_placaVeiculo in varchar2,
    p_idEntidade   in number
  ) is
  begin
    delete from pessoasveiculo
     where placa = p_placaVeiculo
       and identidade = p_idEntidade;
  end;

  procedure removerClassificacaoVeiculo
  (
    p_idClassificacao in number,
    p_idUsuario       in number
  ) is
    v_qtdeVeiculos       number;
    v_descrClassificacao varchar2(60);
  begin
    select count(*)
      into v_qtdeVeiculos
      from veiculo v
     where v.idclassificacao = p_idClassificacao;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Esta classificação está vinculada a um veículo. Não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_qtdeVeiculos
      from carga c
     where c.idclassificacao = p_idClassificacao;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Esta classificação está vinculada a uma expedição. Não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_qtdeVeiculos
      from contatotransportadora c
     where c.idclassificacao = p_idClassificacao;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Esta classificação está vinculada a um contato de transportadora. Não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_qtdeVeiculos
      from lotenf l
     where l.idclassificacao = p_idClassificacao;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Esta classificação está vinculada a uma ordem de recebimento. Não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_qtdeVeiculos
      from rotaclassificacao r
     where r.idclassificacao = p_idClassificacao;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Esta classificação está vinculada a uma classe de veículo para uma rota. Não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select descr
      into v_descrClassificacao
      from classificacaoveiculo c
     where c.idclassificacao = p_idClassificacao;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'O usuário ID: ' || p_idUsuario ||
                          ' apagou a Classificação de veículo ID: ' ||
                          p_idClassificacao || ', Descrição: ' ||
                          v_descrClassificacao, p_idClassificacao, 'EV');
  
    delete from classificacaoveiculo cv
     where cv.idclassificacao = p_idClassificacao;
  end;

  procedure removerModeloVeiculo
  (
    p_idModelo  in number,
    p_idUsuario in number
  ) is
    v_qtdeVeiculos number;
    v_descrModelo  varchar2(20);
  begin
    select count(*)
      into v_qtdeVeiculos
      from veiculo v
     where v.idmodelo = p_idModelo;
  
    if (v_qtdeVeiculos > 0) then
      v_msg := t_message('Este modelo está vinculado a um veículo. Não pode ser excluído.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select descr
      into v_descrModelo
      from modelo m
     where m.idmodelo = p_idModelo;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'O usuário ID: ' || p_idUsuario ||
                          ' apagou o Modelo de veículo ID: ' || p_idModelo ||
                          ', Descrição: ' || v_descrModelo, p_idModelo, 'EV');
  
    delete from modelo m
     where m.idmodelo = p_idModelo;
  end;

  procedure removerVeiculoPalete
  (
    p_placa     in varchar2,
    p_idPalet   in number,
    p_idUsuario in number
  ) is
    v_qtdNota number;
  begin
    select count(*)
      into v_qtdNota
      from paleteondanf pnf
     where pnf.placa = p_placa
       and pnf.idpalete = p_idPalet;
  
    if (v_qtdNota > 0) then
      v_msg := t_message('Este palete está vinculado a uma nota fiscal. Não pode ser excluído.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from veiculopalet vp
     where vp.placa = p_placa
       and vp.idpalet = p_idPalet;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'O usuário ID: ' || p_idUsuario ||
                          ' apagou a placa: ' || p_placa || ', idPalete: ' ||
                          p_idPalet, p_idPalet, 'EP');
  end removerVeiculoPalete;

  procedure validarCadastroPalete
  (
    p_placa       in varchar2,
    p_altura      in number,
    p_largura     in number,
    p_comprimento in number,
    p_edicao      in number,
    p_idPalete    in number
  ) is
    v_nummaxpalete         number;
    v_qtdecadastrada       number;
    v_cubagemveiculo       number;
    v_cubagemOutrosPaletes number;
    v_cubagemNovoPalete    number;
    v_cubagemTotalNova     number;
  begin
    if (p_edicao = 0) then
      select ret_nummaxpalet(p_placa)
        into v_nummaxpalete
        from dual;
    
      select count(1)
        into v_qtdecadastrada
        from veiculopalet vp
       where vp.placa = p_placa;
    
      v_qtdecadastrada := v_qtdecadastrada + 1;
    
      if (v_qtdecadastrada > v_nummaxpalete) then
        v_msg := t_message('O cadastro do palete atual ultrapassa o número máximo de palete permitido: {0}');
        v_msg.addParam(v_nummaxpalete);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    select (v.altintcarreta * v.largintcarreta * v.compintcarreta)
      into v_cubagemveiculo
      from veiculo v
     where v.placa = p_placa;
  
    select nvl(sum(vp.largura * vp.altura * vp.comprimento), 0)
      into v_cubagemOutrosPaletes
      from veiculopalet vp
     where vp.placa = p_placa
       and vp.idpalet <> p_idPalete;
  
    v_cubagemNovoPalete := (p_altura * p_largura * p_comprimento);
    v_cubagemTotalNova  := v_cubagemOutrosPaletes + v_cubagemNovoPalete;
  
    if (v_cubagemTotalNova > v_cubagemveiculo) then
      v_msg := t_message('A soma das cubagens dos paletes cadastrados mais a cubagem do palete atual ultrapassam a cubagem do veículo.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

end pk_veiculo;
/

