create TYPE BODY T_LIST_MESSAGE_PARAM AS
    constructor function T_LIST_MESSAGE_PARAM return self as result is
    begin
      lista := T_VA_MESSAGE_PARAM();
      return;
    end T_LIST_MESSAGE_PARAM;
  
    MEMBER procedure addParam(p_value in varchar2) is
    begin
      lista.extend();
      lista(lista.last) := p_value;
    end addParam;
  
    MEMBER procedure addParam(p_value in number) is
    begin
      lista.extend();
      lista(lista.last) := to_char(p_value);
    end addParam;
  
    MEMBER procedure addParam(p_value in date) is
    begin
      lista.extend();
      if (trunc(P_value) = p_value) then
        lista(lista.last) := to_char(p_value, 'DD/MM/YYYY');
      else
        lista(lista.last) := to_char(p_value, 'DD/MM/YYYY HH24:MI:SS');
      end if;
    
    end addParam;
  END;

/

