create package body pk_romaneio is

  C_MANUAL     constant number := 0;
  C_AUTOMATICA constant number := 1;

  cursor c_embalagem
  (
    p_produto in number,
    p_qtde    in number
  ) is
    select barra, fatorconversao,
           nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
           nvl(pesobruto, 0) peso
      from embalagem
     where trunc(p_qtde / fatorconversao) > 0
       and ativo = 'S'
       and idproduto = p_produto
     order by fatorconversao desc, 3, 4, nvl(barrainterna, 0) asc, 1;

  r_embalagem c_embalagem%rowtype;

  function isOrdemServico(p_idromaneio in number) return boolean is
    v_romaneioos number;
  begin
    select count(*)
      into v_romaneioos
      from romaneiopai rp, ordemservico os
     where os.idromaneio = rp.idromaneio
       and rp.idromaneio = p_idromaneio;
  
    return v_romaneioos > 0;
  end;

  -- Refactored procedure getQtdeEmbalagem  
  procedure getQtdeEmbalagem
  (
    p_idproduto           in number,
    p_barra               in embalagem.barra%type,
    p_qtde                in number,
    p_qtdeembalagem       in out number,
    p_embalagemencontrada in out boolean
  ) is
    cursor c_embalagem2
    (
      p_produto in number,
      p_barra   in embalagem.barra%type
    ) is
      select barra, fatorconversao,
             nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
             nvl(pesobruto, 0) peso
        from embalagem
       where ativo = 'S'
         and barra = p_barra
         and idproduto = p_produto
       order by fatorconversao desc, 3, 4, nvl(barrainterna, 0) asc, 1;
  begin
    p_embalagemencontrada := false;
    if p_barra is null then
      open c_embalagem(p_idproduto, p_qtde);
      fetch c_embalagem
        into r_embalagem;
    
      p_embalagemencontrada := c_embalagem%found;
      close c_embalagem;
    
      if p_embalagemencontrada then
        p_qtdeembalagem := trunc(p_qtde / r_embalagem.fatorconversao);
      end if;
    else
      open c_embalagem2(p_idproduto, p_barra);
      fetch c_embalagem2
        into r_embalagem;
    
      p_embalagemencontrada := c_embalagem2%found;
      close c_embalagem2;
    
      if p_embalagemencontrada then
        p_qtdeembalagem := p_qtde / r_embalagem.fatorconversao;
      end if;
    end if;
  end getQtdeEmbalagem;

  function gerarPaletPorClassificacao(p_romaneio in number) return boolean is
    v_palletsporclassificacao number;
  begin
    select a.palletsporclassificacao
      into v_palletsporclassificacao
      from romaneiopai r, armazem a
     where r.idromaneio = p_romaneio
       and a.idarmazem = r.idarmazem;
  
    return v_palletsporclassificacao = 1;
  end;

  /*
  * Retorna as notas fiscais do romaneio
  */
  function Dados_NF_Romaneio
  (
    p_romaneio in number,
    p_campo    in number
  ) return clob is
    cursor c_nf(p_romaneio in number) is
      select nf.codigointerno, nf.dataprocessamento,
             dep.razaosocial depositante, cli.razaosocial cliente,
             tra.razaosocial transportadora, emi.razaosocial emitente
        from nfromaneio nfr, notafiscal nf, entidade dep, entidade cli,
             entidade tra, entidade emi
       where emi.identidade = nf.remetente
         and tra.identidade(+) = nf.transportadoranotafiscal
         and cli.identidade = nf.destinatario
         and dep.identidade = nf.iddepositante
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
  
    cursor c_dep(p_romaneio in number) is
      select distinct dep.razaosocial
        from nfromaneio nfr, notafiscal nf, entidade dep
       where dep.identidade = nf.iddepositante
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
  
    r_nf    c_nf%rowtype;
    v_campo varchar2(255);
    S       clob;
  begin
    if p_campo <> 2 then
      if c_nf%isopen then
        close c_nf;
      end if;
      open c_nf(p_romaneio);
      fetch c_nf
        into r_nf;
      if c_nf%found then
        while c_nf%found
        loop
          case
            when p_campo = 1 then
              v_campo := r_nf.codigointerno;
            when p_campo = 3 then
              v_campo := r_nf.cliente;
            when p_campo = 4 then
              v_campo := r_nf.transportadora;
            when p_campo = 5 then
              v_campo := r_nf.emitente;
            when p_campo = 6 then
              v_campo := r_nf.dataprocessamento;
          end case;
        
          if S is null then
            S := v_campo;
          else
            S := S || ',' || v_campo;
          end if;
          fetch c_nf
            into r_nf;
        end loop;
        return S;
      else
        return '';
      end if;
    else
      if c_dep%isopen then
        close c_dep;
      end if;
      open c_dep(p_romaneio);
      fetch c_dep
        into v_campo;
      close c_dep;
      return v_campo;
    end if;
  end;

  /*
  * rotina responsavel por retirar as notas fiscais do romaneio ao desfazer o romaneio
  */
  procedure retirarNFRomaneio
  (
    p_romaneio   in number,
    p_usuario    in number,
    p_voltanotas in char
  ) is
    v_qtdenfcarga number;
    v_msg         t_message;
  begin
  
    for c_nf in (select nfr.idnotafiscal, nfr.idcarga,
                        nvl(nfc.embarqueliberado, 'N') embarqueliberado
                   from (select nr.idromaneio, nr.idnotafiscal, cr.idcarga
                            from nfromaneio nr, cargaromaneio cr
                           where cr.idromaneio(+) = nr.idromaneio) nfr,
                        notafiscalcarga nfc
                  where nfr.idromaneio = p_romaneio
                    and nfc.idcarga(+) = nfr.idcarga
                    and nfc.idnotafiscal(+) = nfr.idnotafiscal)
    loop
      if (c_nf.embarqueliberado = 'N')
         or not (pk_carga.isColetaAutomatica(null, p_romaneio, null)) then
      
        -- Alterando carga para não ocorrer erro na trigger
        update carga
           set embarqueliberado = 'N'
         where idcarga = c_nf.idcarga
           and embarqueliberado = 'S';
      
        delete from cargaromaneio
         where idromaneio = p_romaneio
           and idnotafiscal = c_nf.idnotafiscal;
      
        delete from notafiscalcarga
         where idnotafiscal = c_nf.idnotafiscal
           and idcarga = c_nf.idcarga;
      
        update carga
           set embarqueliberado = 'S'
         where idcarga = c_nf.idcarga
           and exists (select 1
                  from notafiscalcarga
                 where idcarga = c_nf.idcarga
                   and embarqueliberado = 'S');
      
        --Verificar se existe nf na carga, senão apaga a carga
        if c_nf.idcarga is not null then
          select count(idnotafiscal)
            into v_qtdenfcarga
            from notafiscalcarga
           where idcarga = c_nf.idcarga;
        
          begin
            if v_qtdenfcarga > 0 then
              -- atualiza os dados da carga
              atualizar_carga(c_nf.idcarga);
            
              delete from manifestocarga
               where idromaneio = p_romaneio;
            else
            
              delete from manifestocarga
               where idromaneio = p_romaneio;
            
              delete from contatotransportadora
               where idcarga = c_nf.idcarga;
            
              delete from conhecimentocarga
               where idcarga = c_nf.idcarga;
            
              update romaneiopai
                 set idcarga = null
               where idcarga = c_nf.idcarga;
            
              update conhecimentoeletronico
                 set idcarga = null
               where idcarga = c_nf.idcarga;
            
              update fechamentocarga
                 set idcarga = null
               where idcarga = c_nf.idcarga;
            
              delete from carga
               where idcarga = c_nf.idcarga;
            end if;
          exception
            when others then
              v_msg := t_message('O ROMANEIO NAO PODE SER DESFEITO.' ||
                                 chr(13) || 'OPERACAO CANCELADA.');
              raise_application_error(-20100, v_msg.formatMessage);
          end;
        end if;
      
        pk_notafiscal.retirar_nf_romaneio(p_romaneio, c_nf.idnotafiscal,
                                          p_usuario, p_voltanotas);
        pk_confsaida.cancelarPedidoRetorno(p_romaneio, c_nf.idnotafiscal);
      
        --atualiza que o romaneio foi desfeito
        update pacotenotafiscal p
           set p.finalizado = c_normal
         where p.idnotafiscal = c_nf.idnotafiscal
           and p.idpacote in (select idpacote
                                from romaneiopai
                               where idromaneio = p_romaneio
                                 and idpacote = p.idpacote);
      
        update ocorrenciaentrega
           set idromaneioreentrega = null
         where idromaneioreentrega = p_romaneio;
      else
        v_msg := t_message('O ROMANEIO NAO PODE SER DESFEITO. O ROMANEIO ESTA COM O EMBARQUE LIBERADO.' ||
                           chr(13) || 'OPERACAO CANCELADA.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end loop;
  end;

  /*
   * rotina responsavel por desfazer o romaneio.
  */
  procedure desfazer_romaneio
  (
    p_romaneio   in number,
    p_usuario    in number,
    p_commit     in romaneiopai.faturado%type,
    p_voltanotas in char := 'N'
  ) is
    v_codigointerno        romaneiopai.codigointerno%type;
    v_tituloromaneio       romaneiopai.tituloromaneio%type;
    v_cargas               varchar2(400);
    v_qtdevolumes          number;
    v_qtdeconheletronico   number;
    v_cargasconheletronico varchar2(400);
    v_qtde_rem             number;
    v_idinventario         number;
    v_msg                  t_message;
  
    function enderecosEmInventario
    (
      p_romaneio     in number,
      v_idinventario in out number
    ) return boolean is
    begin
      select stragg(idinventario)
        into v_idinventario
        from (select distinct i.idinventario idinventario
                 from paletseparacao ps, escopoinventario ei, inventario i
                where ps.idromaneio = p_romaneio
                  and i.idinventario = ei.idinventario
                  and ei.idlocal = ps.idlocal
                  and ei.idarmazem = ps.idarmazem
                  and i.situacao in ('L', 'B'));
    
      return v_idinventario is not null;
    end;
  begin
  
    pk_notafiscal.desfazerNFRetArmazenagemRom(p_romaneio, null, p_usuario,
                                              'TA');
  
    if enderecosEmInventario(p_romaneio, v_idinventario) then
      v_msg := t_message('Existem endereços envolvidos na separação do romaneio que econtram-se ' ||
                         ' em contagem no inventário id: {0}');
      v_msg.addParam(v_idinventario);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select codigointerno, tituloromaneio
      into v_codigointerno, v_tituloromaneio
      from romaneiopai
     where idromaneio = p_romaneio;
  
    select stragg(idcarga), nvl(sum(qtdevolume), 0) qtdevolume
      into v_cargas, v_qtdevolumes
      from (select idcarga, count(idvolume) qtdevolume
               from volumeromaneioexcluido
              where idromaneio = p_romaneio
              group by idcarga);
  
    if v_qtdevolumes > 0 then
      v_msg := t_message('Existe(m) {0}' ||
                         ' volume(s) para ser(em) retirado(s) da(s) coleta(s): {1}' ||
                         chr(13) ||
                         'Para desfazer o romaneio será necessário retirá-lo(s) da(s) coleta(s).');
      v_msg.addParam(v_qtdevolumes);
      v_msg.addParam(v_cargas);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      select stragg(idcarga), qtdeconheletronico
        into v_cargasconheletronico, v_qtdeconheletronico
        from (select distinct idcarga,
                               count(distinct idcarga) qtdeconheletronico
               
                 from conhecimentoeletronico c
                where idcarga in (select distinct idcarga
                                    from cargaromaneio
                                   where idromaneio = p_romaneio)
                  and status in (0, 1, 2, 3)
                group by idcarga) s
       group by s.qtdeconheletronico;
    exception
      when no_data_found then
        v_qtdeconheletronico := 0;
    end;
  
    if v_qtdeconheletronico > 0 then
      v_msg := t_message('As cargas {0}' ||
                         ' possuem conhecimento de transporte (CTE), por favor cancele o conhecimento de transporte para desfazer o romaneio ');
      v_msg.addParam(v_cargasconheletronico);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Insere os remanejamentos do romaneio
    delete from gtt_selecao;
  
    insert into gtt_selecao
      select distinct lr.idremanejamento
        from paletseparacao ps, loteremanejamento lr, remanejamento r
       where r.cadmanual = 'N'
         and r.status <> 'F'
         and r.idremanejamento = lr.idremanejamento
         and lr.idlote = ps.idlote
         and ps.idromaneio = p_romaneio
      union
      select distinct idremanejamento
        from remanejamentoromaneio
       where idromaneio = p_romaneio;
  
    select count(*)
      into v_qtde_rem
      from remanejamento r
     where not exists
     (select 1
              from loteremanejamento lr
             where lr.idremanejamento = r.idremanejamento)
       and idremanejamento in (select idselecionado
                                 from gtt_selecao);
  
    if v_qtde_rem > 0 then
      v_msg := t_message('REMANEJAMENTO SEM LOTES. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from volumeromaneiosum
     where idromaneio = p_romaneio;
  
    delete from volumeromaneio
     where idromaneio = p_romaneio;
  
    delete from atividade
     where idoperacao = to_char(v_codigointerno)
       and idtipoatividade in (3, 5);
  
    retirarNFRomaneio(p_romaneio, p_usuario, p_voltanotas);
  
    --atualiza a situação do pacote finalizado para recebido
    update pacote p
       set p.situacao = c_recebido
     where p.situacao = c_finalizado
       and p.idpacote in (select idpacote
                            from romaneiopai
                           where idromaneio = p_romaneio
                             and idpacote = p.idpacote);
  
    delete from clienteromaneio
     where idromaneio = p_romaneio;
  
    -- apaga as informacoes do pallet
    apagar_pallet_romaneio(p_romaneio, p_usuario);
  
    delete from romaneio
     where idromaneio = p_romaneio;
  
    select count(*)
      into v_qtde_rem
      from remanejamento r
     where not exists
     (select 1
              from loteremanejamento lr
             where lr.idremanejamento = r.idremanejamento)
       and idremanejamento in (select idselecionado
                                 from gtt_selecao);
  
    if v_qtde_rem > 0 then
      v_msg := t_message('REMANEJAMENTO SEM LOTES. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_remanejamento.desfazerRemanejamento(p_romaneio, p_usuario, 0, null);
  
    select count(*)
      into v_qtde_rem
      from remanejamento r
     where not exists
     (select 1
              from loteremanejamento lr
             where lr.idremanejamento = r.idremanejamento)
       and idremanejamento in (select idselecionado
                                 from gtt_selecao);
  
    if v_qtde_rem > 0 then
      v_msg := t_message('REMANEJAMENTO SEM LOTES. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from retiradanotafiscal
     where idromaneio = p_romaneio;
  
    update ordemservico
       set idromaneio = null
     where idromaneio = p_romaneio
       and tiposervico = 'D';
  
    delete from notafiscal nf
     where nf.idnotafiscal =
           (select nr.idnotafiscal
              from nfromaneio nr, ordemservico o
             where nr.idromaneio = p_romaneio
               and o.idromaneio = nr.idromaneio
               and o.tiposervico = c_desmontagem_kit
               and nr.idnotafiscal = nf.idnotafiscal);
  
    delete from pontoalerta p
     where idnotafiscal in
           (select idnotafiscal
              from nfromaneio n
             where idromaneio = p_romaneio
               and n.idnotafiscal = p.idnotafiscal);
  
    liberarCaixaSeparacacao(p_romaneio);
  
    delete from caixaseparacaoromaneio
     where idromaneio = p_romaneio;
  
    update divergenciasaida
       set idonda = null
     where idonda = p_romaneio;
  
    delete produtoalteradosep
     where idromaneio = p_romaneio;
  
    delete from auditoriaromaneioocorrencia aro
     where aro.idromaneio = p_romaneio;
  
    update loteremanejamento lr
       set lr.idromaneio = null
     where lr.idromaneio = p_romaneio;
  
    update remanejamento r
       set r.idromaneio = null
     where r.idromaneio = p_romaneio;
  
    delete from remanejamentoromaneio rr
     where rr.idromaneio = p_romaneio;
  
    delete from romaneiopai
     where idromaneio = p_romaneio;
  
    -- gerando log de desfazer romaneio
    pk_utilities.GeraLog(p_usuario,
                         'DESFEZ O ROMANEIO ID: ' || p_romaneio ||
                          ' ROMANEIO NUM: ' || v_codigointerno || ' E ' ||
                          v_tituloromaneio, p_romaneio, 'RP');
  
    if p_commit = c_sim then
      commit;
    end if;
  exception
    when no_data_found then
      v_msg := t_message('O ROMANEIO NAO PODE SER DESFEITO.' || chr(13) ||
                         'OPERACAO CANCELADA.');
      raise_application_error(-20100, v_msg.formatMessage);
  end;

  /*
   * Atualiza os Dados da Carga
  */
  procedure atualizar_carga(p_carga in number) is
    cursor c_nfdet(p_carga in number) is
      select sum(pesototal) pesototal, sum(valortotal) valortotal,
             sum(volumetotal) volumetotal
        from (select v.idromaneio, sum(v.pesobruto) pesototal,
                      sum(v.valor) valortotal, sum(v.volume) volumetotal
                 from v_manifesto_carga v
                where idcarga = p_carga
                group by v.idromaneio);
  
    r_nfdet c_nfdet%rowtype;
  begin
    open c_nfdet(p_carga);
    fetch c_nfdet
      into r_nfdet;
  
    update carga
       set totalpeso   = nvl(r_nfdet.pesototal, 0),
           totalvolume = nvl(r_nfdet.volumetotal, 0),
           totalvalor  = nvl(r_nfdet.valortotal, 0)
     where idcarga = p_carga;
  
    close c_nfdet;
  end;

  /*
   * Rotina responsavel por inserir as nfs dos depositantes no romaneio
  */
  procedure inserir_depositante_romaneio
  (
    p_romaneio    in out number,
    p_rota        in number,
    p_tipocarga   in varchar2,
    p_depositante in number,
    p_usuario     in number,
    p_ordem       in number
  ) is
  begin
    if p_ordem = 1 then
      -- crescente
      for c_cli in (select rc.identidade
                      from rotacliente rc, notafiscal nf, nfimpressao nfi
                     where idrota = p_rota
                       and nf.iddepositante = p_depositante
                       and nf.tipo = c_sim
                       and nf.statusroteirizacao = 1
                       and nf.Ident_Entrega = rc.identidade
                       and nfi.idprenf = nf.idprenf
                       and nvl(nfi.tipocarga, 'SEM TIPO') =
                           nvl(p_tipocarga, 'SEM TIPO')
                     order by rc.ordem)
      loop
        inserir_nfromaneio_tipocarga(p_romaneio, c_cli.identidade,
                                     p_depositante, p_usuario, p_tipocarga);
      end loop;
    else
      for c_cli in (select rc.identidade
                      from rotacliente rc, notafiscal nf, nfimpressao nfi
                     where idrota = p_rota
                       and nf.iddepositante = p_depositante
                       and nf.tipo = c_sim
                       and nf.statusroteirizacao = 1
                       and nf.Ident_Entrega = rc.identidade
                       and nfi.idprenf = nf.idprenf
                       and nvl(nfi.tipocarga, 'SEM TIPO') =
                           nvl(p_tipocarga, 'SEM TIPO')
                     order by rc.ordem desc)
      loop
        inserir_nfromaneio_tipocarga(p_romaneio, c_cli.identidade,
                                     p_depositante, p_usuario, p_tipocarga);
      end loop;
    end if;
  end;

  /*
   * Insere as Notas Fiscais ao Romaneio passando o tipo da carga
  */
  procedure inserir_nfromaneio_tipocarga
  (
    p_romaneio    in out number,
    p_entidade    in number,
    p_depositante in number,
    p_usuario     in number,
    p_tipocarga   in varchar2
  ) is
  
    v_seq           number;
    r_romaneio      romaneiopai%rowtype;
    v_tipoconfsaida number;
  begin
    v_seq := RetornarOrdemEntrega(p_romaneio, p_entidade);
  
    if v_seq is null then
      v_seq := RetornarOrdemEntregaMaxima(p_romaneio);
    end if;
  
    if p_romaneio <= 0 then
      r_romaneio.idromaneio     := p_romaneio;
      r_romaneio.codigointerno  := p_romaneio;
      r_romaneio.idusuario      := p_usuario;
      r_romaneio.tituloromaneio := p_romaneio;
    
      p_romaneio := inserir_romaneiopai(r_romaneio);
    end if;
  
    for c_nf in (select nf.idnotafiscal
                   from notafiscal nf, nfimpressao nfi
                  where nf.iddepositante = p_depositante
                    and nf.ident_entrega = p_entidade
                    and nf.tipo = c_sim
                    and nf.statusroteirizacao = 1
                    and nfi.idprenf = nf.idprenf
                    and nvl(nfi.tipocarga, 'SEM TIPO') =
                        nvl(p_tipocarga, 'SEM TIPO'))
    loop
      begin
        savepoint po1;
      
        insert into nfromaneio
          (idromaneio, idnotafiscal, sequencia)
        values
          (p_romaneio, c_nf.idnotafiscal, v_seq);
      
        update notafiscal
           set statusnf           = C_CARGA,
               statusroteirizacao = 2
         where idnotafiscal = c_nf.idnotafiscal;
      
        update nfimpressao nfi
           set nfi.statusdoc = 1
         where nfi.idprenf in
               (select nf.idprenf
                  from notafiscal nf
                 where nf.idnotafiscal = c_nf.idnotafiscal);
      
      exception
        when dup_val_on_index then
          rollback to po1;
      end;
      begin
        select nvl(a.tipoconfsaida, 0)
          into v_tipoconfsaida
          from armazem a, notafiscal nf
         where nf.idarmazem = a.idarmazem
           and nf.idnotafiscal = c_nf.idnotafiscal;
      exception
        when others then
          v_tipoconfsaida := 0;
      end;
    
      if v_tipoconfsaida = 2 then
        InsereClienteRomaneio(p_romaneio, c_nf.idnotafiscal);
      end if;
    end loop;
  
  end;

  /*
   * Insere as Notas Fiscais ao Romaneio
  */
  procedure inserir_nfromaneio
  (
    p_romaneio in out number,
    p_entidade in number,
    p_nf       in number,
    p_usuario  in number,
    p_seq      in number,
    p_commit   in varchar2 := 'S'
  ) is
  
    v_seq              number;
    r_romaneio         romaneiopai%rowtype;
    v_codintnotafiscal number;
    v_codintromaneio   varchar2(20);
    v_tipoconfsaida    number;
    v_idprenf          number;
    v_msg              t_message;
  begin
    -- Loca a inserção da NF para não permitir a formação de mais de um romaneio com a mesma NF
    update notafiscal
       set statusnf = statusnf
     where idnotafiscal = p_nf
    returning idprenf into v_idprenf;
  
    -- Verificação se a NF  está liberada.
    begin
      select nf.codigointerno
        into v_codintnotafiscal
        from notafiscal nf
       where nvl(nf.estoqueverificado, 'N') = 'N'
         and nf.idnotafiscal = p_nf;
    exception
      when no_data_found then
        v_codintnotafiscal := null;
    end;
  
    if (v_codintnotafiscal is not null) then
      v_msg := t_message('A NF: {0} NÃO SE ENCONTRA LIBERADA.' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_codintnotafiscal);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    -- Verificação se a NF  ja esta num Romaneio não processado.
    begin
      select nf.codigointerno, rp.codigointerno
        into v_codintnotafiscal, v_codintromaneio
        from romaneiopai rp, nfromaneio nfr, notafiscal nf
       where rp.idromaneio = nfr.idromaneio
         and nfr.idnotafiscal = nf.idnotafiscal
         and rp.processado = 'N'
         and nf.idnotafiscal = p_nf
         and rownum = 1;
    exception
      when no_data_found then
        v_codintnotafiscal := null;
        v_codintromaneio   := null;
    end;
  
    if ((v_codintnotafiscal is not null) or (v_codintromaneio is not null)) then
      v_msg := t_message('A NF: {0}' || ' JA ESTA NO ROMANEIO: {1}' ||
                         ' QUE AINDA NÃO FOI PROCESSADO.' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_codintnotafiscal);
      v_msg.addParam(v_codintromaneio);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    if p_seq > 0 then
      v_seq := p_seq;
    elsif p_seq = 0 then
      v_seq := RetornarOrdemEntrega(p_romaneio, p_entidade);
    end if;
  
    if v_seq is null then
      v_seq := RetornarOrdemEntregaMaxima(p_romaneio);
    end if;
  
    if p_romaneio <= 0 then
      r_romaneio.idromaneio     := p_romaneio;
      r_romaneio.codigointerno  := p_romaneio;
      r_romaneio.idusuario      := p_usuario;
      r_romaneio.tituloromaneio := p_romaneio;
    
      p_romaneio := inserir_romaneiopai(r_romaneio);
    end if;
  
    insert into nfromaneio
      (idromaneio, idnotafiscal, sequencia)
    values
      (p_romaneio, p_nf, v_seq);
  
    update notafiscal
       set statusnf           = C_CARGA,
           statusroteirizacao = 2
     where idnotafiscal = p_nf;
  
    update nfimpressao
       set status = 'N'
     where idprenf = v_idprenf;
  
    -- O update desse campo deve ser separado devido a clausula da trigger T_BEFORE_NFIMPRESSAO
    update nfimpressao nfi
       set nfi.statusdoc = 1
     where nfi.idprenf = v_idprenf;
  
    begin
      select nvl(a.tipoconfsaida, 0)
        into v_tipoconfsaida
        from armazem a, notafiscal nf
       where nf.idarmazem = a.idarmazem
         and nf.idnotafiscal = p_nf;
    exception
      when others then
        v_tipoconfsaida := 0;
    end;
  
    if v_tipoconfsaida = 2 then
      InsereClienteRomaneio(p_romaneio, p_nf);
    end if;
  
    if p_commit = c_sim then
      commit;
    end if;
  
  end;

  /*
   * Rotina que cadastra o romaneiopai
  */
  function inserir_romaneiopai(p_romaneio in romaneiopai%rowtype)
    return number is
    v_romaneio number;
  begin
    select seq_romaneio.nextval
      into v_romaneio
      from dual;
  
    insert into romaneiopai
      (idromaneio, datageracao, processado, codigointerno, idusuario,
       gerado, placa, idarmazem, iddoca, tituloromaneio, faturado, coletado,
       idpacote, idlocal, calculanumpalet, reentrega)
    values
      (v_romaneio, sysdate, 'N', v_romaneio, p_romaneio.idusuario, 'A',
       p_romaneio.placa, p_romaneio.idarmazem, p_romaneio.iddoca,
       p_romaneio.tituloromaneio, nvl(p_romaneio.faturado, 'N'),
       nvl(p_romaneio.coletado, 'N'), p_romaneio.idpacote,
       p_romaneio.idlocal, nvl(p_romaneio.calculanumpalet, 'N'),
       nvl(p_romaneio.reentrega, 'N'));
  
    return v_romaneio;
  end;

  /*
   * Retorna o volume das notas fiscais pendentes para geracao
  */
  function vol_total_rota(p_rota in number) return number is
    cursor c_emb_prod
    (
      p_produto in number,
      p_rest    in number
    ) is
      select barra, fatorconversao,
             nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
             nvl(pesobruto, 0) peso
        from embalagem
       where trunc(p_rest / fatorconversao) > 0
         and ativo = C_SIM
         and idproduto = p_produto
       order by fatorconversao desc, nvl(barrainterna, 0) asc;
  
    r_emb_prod c_emb_prod%rowtype;
    v_tot_vol  number := 0;
    v_totu     number;
    v_qtde     number;
  begin
    for c_prod in (select rc.ordem, nf.iddepositante, nfd.idproduto,
                          p.codigointerno codprod, p.descr produto,
                          sum(nvl(e.fatorconversao, 0) * nfd.qtdeatendida) qtde
                     from rotacliente rc, notafiscal nf, nfdet nfd,
                          embalagem e, produto p
                    where p.idproduto = nfd.idproduto
                      and e.barra = nfd.barra
                      and e.idproduto = nfd.idproduto
                      and nfd.nf = nf.idnotafiscal
                      and nf.ident_entrega = rc.identidade
                      and nf.idnotafiscal not in
                          (select idnotafiscal
                             from nfromaneio)
                      and nf.statusnf in (C_NORMAL, C_IMPORTADO)
                      and nf.tipo = C_SIM
                      and rc.idrota = p_rota
                    group by rc.ordem, nf.iddepositante, nfd.idproduto,
                             p.codigointerno, p.descr
                    order by rc.ordem desc)
    loop
      v_totu := 0;
      if c_emb_prod%isopen then
        close c_emb_prod;
      end if;
      open c_emb_prod(c_prod.idproduto, c_prod.qtde);
      fetch c_emb_prod
        into r_emb_prod;
      while ((c_prod.qtde - v_totu) > 0)
      loop
        v_qtde    := trunc((c_prod.qtde - v_totu) /
                           r_emb_prod.fatorconversao);
        v_totu    := v_totu + v_qtde * r_emb_prod.fatorconversao;
        v_tot_vol := v_tot_vol + v_qtde * r_emb_prod.volume;
        fetch c_emb_prod
          into r_emb_prod;
      end loop;
    end loop;
    return v_tot_vol;
  end;

  /*
   * Exclui uma NF ou Todas as NFs do Cliente do Romaneio
  */
  procedure excluir_nfromaneio
  (
    p_romaneio in out number,
    p_entidade in number,
    p_nf       in number,
    p_usuario  in number
  ) is
    cursor c_nfr(p_roma in number) is
      select idromaneio
        from nfromaneio
       where idromaneio = p_roma;
  
  begin
    if p_nf <= 0 then
      for c_nf in (select nf.idnotafiscal
                     from notafiscal nf, nfromaneio nfroma
                    where nf.tipo = C_SIM
                      and nf.statusnf = C_CARGA
                      and nf.ident_entrega = p_entidade
                      and nfroma.idromaneio = p_romaneio
                      and nf.idnotafiscal = nfroma.idnotafiscal)
      loop
        pk_notafiscal.retirar_nf_romaneio(p_romaneio, c_nf.idnotafiscal,
                                          p_usuario, 'N');
      end loop;
    else
      pk_notafiscal.retirar_nf_romaneio(p_romaneio, p_nf, p_usuario, 'N');
    end if;
  
    delete from clienteromaneio
     where idromaneio = p_romaneio
       and ident_entrega not in
           (select nf.ident_entrega
              from notafiscal nf, nfromaneio nfr
             where nf.idnotafiscal = nfr.idnotafiscal
               and nfr.idromaneio = p_romaneio);
    -- verifica se o romaneio ainda possui notas vinculadas
    if c_nfr%isopen then
      close c_nfr;
    end if;
    open c_nfr(p_romaneio);
    fetch c_nfr
      into p_romaneio;
    p_romaneio := nvl(p_romaneio, 0);
  end;

  /*
   * Rotina Responsavel por alterar a ordem de entrega dos clientes
   * na formacao de carga.
  */
  procedure alterar_ordem_entrega
  (
    p_romaneio in number,
    p_ent      in number,
    p_seq      in number,
    p_ordem    in number
  ) is
    cursor c_seq_ant_nf
    (
      p_romaneio in number,
      p_seq      in number
    ) is
      select distinct ident_entrega, nfroma.sequencia
        from nfromaneio nfroma, notafiscal nf
       where nfroma.idromaneio = p_romaneio
         and nfroma.sequencia < p_seq
         and nf.idnotafiscal = nfroma.idnotafiscal
       order by nfroma.sequencia desc;
  
    cursor c_seq_prox_nf
    (
      p_romaneio in number,
      p_seq      in number
    ) is
      select distinct ident_entrega, nfroma.sequencia
        from nfromaneio nfroma, notafiscal nf
       where nfroma.idromaneio = p_romaneio
         and nfroma.sequencia > p_seq
         and nf.idnotafiscal = nfroma.idnotafiscal
       order by nfroma.sequencia;
  
    r_seq_ant_nf  c_seq_ant_nf%rowtype;
    r_seq_prox_nf c_seq_prox_nf%rowtype;
  begin
    if p_ordem = 1 then
      -- cima
      -- pega os valores da sequencia anterior no romaneio
      if c_seq_ant_nf%isopen then
        close c_seq_ant_nf;
      end if;
      open c_seq_ant_nf(p_romaneio, p_seq);
      fetch c_seq_ant_nf
        into r_seq_ant_nf;
      if c_seq_ant_nf%notfound then
        r_seq_ant_nf.ident_entrega := 0;
        r_seq_ant_nf.sequencia     := 0;
      end if;
      -- verifica qual registro e o anterior
      update nfromaneio
         set sequencia = r_seq_ant_nf.sequencia
       where idromaneio = p_romaneio
         and idnotafiscal in (select idnotafiscal
                                from notafiscal
                               where ident_entrega = p_ent);
      update nfromaneio
         set sequencia = p_seq
       where idromaneio = p_romaneio
         and idnotafiscal in
             (select idnotafiscal
                from notafiscal
               where ident_entrega = r_seq_ant_nf.ident_entrega);
    else
      -- baixo
      -- pega os valores da proxima sequencia no romaneio
      if c_seq_prox_nf%isopen then
        close c_seq_prox_nf;
      end if;
      open c_seq_prox_nf(p_romaneio, p_seq);
      fetch c_seq_prox_nf
        into r_seq_prox_nf;
      if c_seq_prox_nf%isopen then
        close c_seq_prox_nf;
      end if;
      -- verifica qual registro e o anterior
      -- usa a tabela de notafiscal
      update nfromaneio
         set sequencia = r_seq_prox_nf.sequencia
       where idromaneio = p_romaneio
         and idnotafiscal in (select idnotafiscal
                                from notafiscal
                               where ident_entrega = p_ent);
      update nfromaneio
         set sequencia = p_seq
       where idromaneio = p_romaneio
         and idnotafiscal in
             (select idnotafiscal
                from notafiscal
               where ident_entrega = r_seq_prox_nf.ident_entrega);
    end if;
  
  end;

  /*
   * Sumariza o Romaneio baseando-se nas nfs vinculadas ao romaneio
  */
  procedure Atualizar_Produtos_Romaneio
  (
    p_romaneio in romaneiopai%rowtype,
    p_commit   in varchar2 := c_sim
  ) is
    v_msg t_message;
  begin
    if (p_romaneio.idromaneio is not null)
       and (p_romaneio.processado = c_normal) then
      -- apaga a sumarizacao do romaneio
      delete from romaneio
       where idromaneio = p_romaneio.idromaneio;
      -- gera a sumarizacao do romaneio novamente.
      insert into romaneio
        (idromaneio, idproduto, barra, qtdeaseparar, qtdeconf)
        select p_romaneio.idromaneio, idproduto, barra, sum(qtdeatendida), 0
          from (select n.idproduto, n.barra, sum(qtdeatendida) qtdeatendida
                   from nfromaneio nfr, nfdet n, produto p
                  where p.kitexpexplodida = 'N'
                    and p.idproduto = n.idproduto
                    and n.qtdeatendida > 0
                    and n.nf = nfr.idnotafiscal
                    and nfr.idromaneio = p_romaneio.idromaneio
                  group by n.idproduto, n.barra
                 union all
                 select kp.idproduto, kp.barra,
                        sum(kp.qtde * (n.qtdeatendida * e.fatorconversao))
                   from nfromaneio nfr, nfdet n, embalagem e, produto p,
                        kitproduto kp
                  where kp.idprodutokit = n.idproduto
                    and p.kitexpexplodida = 'S'
                    and p.idproduto = n.idproduto
                    and e.barra = n.barra
                    and e.idproduto = n.idproduto
                    and n.qtdeatendida > 0
                    and n.nf = nfr.idnotafiscal
                    and nfr.idromaneio = p_romaneio.idromaneio
                  group by kp.idproduto, kp.barra)
         group by idproduto, barra;
    
      if p_commit = C_SIM then
        commit;
      end if;
    elsif p_romaneio.processado = 'P' then
      v_msg := t_message('Romaneio ja processado.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    elsif p_romaneio.processado = 'X' then
      v_msg := t_message('Romaneio Cancelado.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    else
      v_msg := t_message('Romaneio nao encontado.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  end;

  /*
  * Rotina usada para ordenar as notas fiscais de acordo com a ordem de entrega
  * das rotas
  */
  procedure ordenar_notas_romaneio(p_romaneio in number) is
    v_seq      number;
    v_entidade number;
    v_rota     number;
  begin
    v_seq      := 1;
    v_entidade := 0;
    v_rota     := 0;
    for c_r in (select distinct seq_roma, v.identidade, r.idrota, r.ordem
                  from v_romaneiopai v, rotacliente r
                 where idromaneio = p_romaneio
                   and r.identidade = v.identidade
                 order by r.idrota, r.ordem)
    loop
      if (v_rota <> c_r.idrota)
         or (v_entidade <> c_r.identidade) then
        update nfromaneio
           set sequencia = v_seq
         where idromaneio = p_romaneio
           and idnotafiscal in
               (select idnotafiscal
                  from notafiscal n
                 where ident_entrega = c_r.identidade);
        v_seq      := v_seq + 1;
        v_rota     := c_r.idrota;
        v_entidade := c_r.identidade;
      end if;
    end loop;
  end;

  /*
   * Retorna o Volume total do romaneio, esta rotina simula a formacao de carga.
   * Pegando as embalagens disponiveis e os volumes respectivos.
   * Ex. se pedir 5 display ao inves de calcular o volume dessas embalagens
   * o sistema calcula o volume de uma caixa (5 display = 1 caixa)
  */
  function vol_total_romaneio
  (
    p_romaneio  in number,
    p_segregado in varchar2
  ) return number is
  
    v_volumetotal number;
  
    function retVolumeRomaneio
    (
      p_idromaneio       number,
      p_segregado        in char,
      p_otimizaseparacao in char,
      p_fracionado       in char
    ) return number is
    
      cursor c_embalagem
      (
        p_idproduto in number,
        p_barra     in embalagem.barra%type,
        p_qtde      in number
      ) is
        select barra, fatorconversao,
               nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
               nvl(pesobruto, 0) peso
          from embalagem
         where trunc(p_qtde / fatorconversao) > 0
           and ativo = 'S'
           and idproduto = p_idproduto
           and decode(p_barra, '', '0', barra) =
               decode(p_barra, '', '0', p_barra)
         order by fatorconversao desc, 3, 4, nvl(barrainterna, 0) asc, 1;
    
      r_embalagem    c_embalagem%rowtype;
      v_volume       number := 0;
      v_qtderestante number;
      v_qtde         number;
      v_msg          t_message;
    begin
      for c_produto in (select nfr.sequencia, nfd.idproduto,
                               p.codigointerno codprod, p.descr produto,
                               decode(p_otimizaseparacao, 'S', '', e.barra) barra,
                               sum(nfd.qtdeatendida * e.fatorconversao) qtde,
                               nvl(e.altura, 0) * nvl(e.largura, 0) *
                                nvl(e.comprimento, 0) volume
                          from nfromaneio nfr, notafiscal nf, nfdet nfd,
                               embalagem e, produto p
                         where p.kitexpexplodida = 'N'
                           and p.fracionado = p_fracionado
                           and p.otimizaseparacao like p_otimizaseparacao
                           and nvl(p.segregado, 'N') = p_segregado
                           and p.idproduto = nfd.idproduto
                           and e.barra = nfd.barra
                           and e.idproduto = nfd.idproduto
                           and nfd.nf = nf.idnotafiscal
                           and nf.idnotafiscal = nfr.idnotafiscal
                           and nfr.idromaneio = p_idromaneio
                         group by nfr.sequencia, nfd.idproduto,
                                  decode(p_otimizaseparacao, 'S', '', e.barra),
                                  p.codigointerno, p.descr,
                                  nvl(e.altura, 0) * nvl(e.largura, 0) *
                                   nvl(e.comprimento, 0)
                        union all
                        select nfr.sequencia, kp.idproduto,
                               pk.codigointerno codprod, pk.descr produto,
                               decode(p_otimizaseparacao, 'S', '', ek.barra),
                               sum((nfd.qtdeatendida * e.fatorconversao) *
                                    (kp.qtde * ek.fatorconversao)) qtde,
                               nvl(ek.altura, 0) * nvl(ek.largura, 0) *
                                nvl(ek.comprimento, 0) volume
                          from nfromaneio nfr, notafiscal nf, nfdet nfd,
                               embalagem e, produto p, kitproduto kp,
                               embalagem ek, produto pk
                         where pk.idproduto = kp.idproduto
                           and ek.barra = kp.barra
                           and ek.idproduto = kp.idproduto
                           and kp.idprodutokit = nfd.idproduto
                           and p.kitexpexplodida = 'S'
                           and pk.fracionado = p_fracionado
                           and pk.otimizaseparacao like p_otimizaseparacao
                           and nvl(pk.segregado, 'N') = p_segregado
                           and p.idproduto = nfd.idproduto
                           and e.barra = nfd.barra
                           and e.idproduto = nfd.idproduto
                           and nfd.nf = nf.idnotafiscal
                           and nf.idnotafiscal = nfr.idnotafiscal
                           and nfr.idromaneio = p_idromaneio
                         group by nfr.sequencia, kp.idproduto,
                                  decode(p_otimizaseparacao, 'S', '',
                                          ek.barra), pk.codigointerno,
                                  pk.descr,
                                  nvl(ek.altura, 0) * nvl(ek.largura, 0) *
                                   nvl(ek.comprimento, 0)
                         order by 1 desc)
      loop
        if (p_fracionado = 'N') then
        
          v_qtderestante := c_produto.qtde;
        
          while v_qtderestante > 0
          loop
            open c_embalagem(c_produto.idproduto, c_produto.barra,
                             v_qtderestante);
          
            fetch c_embalagem
              into r_embalagem;
          
            if c_embalagem%found then
              close c_embalagem;
              if r_embalagem.volume > 0 then
                v_qtde         := trunc(v_qtderestante /
                                        r_embalagem.fatorconversao);
                v_qtderestante := v_qtderestante -
                                  (v_qtde * r_embalagem.fatorconversao);
                v_volume       := v_volume + (v_qtde * r_embalagem.volume);
              else
                v_msg := t_message('O VOLUME DO PRODUTO {0} - {1}' ||
                                   ' NAO PODE SER MENOR OU IGUAL A ZERO' ||
                                   chr(13) || 'ATUALIZE O CADASTRO');
                v_msg.addParam(c_produto.codprod);
                v_msg.addParam(c_produto.produto);
                raise_application_error(-20000, v_msg.formatMessage);
              end if;
            else
              v_msg := t_message('NÃO FOI ENCONTRADA EMBALAGEM COM ' ||
                                 'FATOR DE CONVERSÃO MENOR OU IGUAL A ' ||
                                 '{0} PARA O PRODUTO ' || '{1} - {2}' ||
                                 chr(13) || 'REVISE O CADASTRO');
              v_msg.addParam(v_qtderestante);
              v_msg.addParam(c_produto.codprod);
              v_msg.addParam(c_produto.produto);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end loop;
        else
          v_qtde   := c_produto.qtde;
          v_volume := v_volume + (v_qtde * c_produto.volume);
        end if;
      end loop;
      return v_volume;
    end;
  
  begin
    -- volume produtos que otimiza separacao
    v_volumetotal := retVolumeRomaneio(p_romaneio, p_segregado, 'S', 'N');
  
    -- volume produtos que não otimiza separacao
    v_volumetotal := v_volumetotal +
                     retVolumeRomaneio(p_romaneio, p_segregado, 'N', 'N');
  
    -- volume produtos fracionados
    v_volumetotal := v_volumetotal +
                     retVolumeRomaneio(p_romaneio, p_segregado, '%', 'S');
  
    return v_volumetotal;
  end;

  procedure formarRomaneioNormal
  (
    p_romaneiopai    in out romaneiopai%rowtype,
    p_usuario        in number,
    p_gerarcarga     in varchar2,
    p_commit         in varchar2,
    p_checarqtde     in char,
    p_estado         in char,
    p_atualizarprod  in char,
    p_veiculodoca    in char,
    p_gerarseparacao in varchar2
  ) is
    v_estado lote.estado%type;
    v_carga  number;
    v_msg    t_message;
  
    procedure atualizarDadosNotaFiscal
    (
      p_idromaneio in number,
      p_placa      in varchar2
    ) is
    begin
      for c in (select nf.idnotafiscal, nf.idprenf,
                       nvl(d.atualizapesonf, 'N') atualizapesonf,
                       sum((nd.qtdeatendida * e.fatorconversao) *
                            e.pesobruto) peso, nf.statusroteirizacao
                  from nfromaneio nfr, notafiscal nf, entidade e,
                       depositante d, nfdet nd, embalagem e
                 where e.barra = nd.barra
                   and e.idproduto = nd.idproduto
                   and nd.nf = nf.idnotafiscal
                   and d.identidade = nf.iddepositante
                   and nvl(e.emitenfe, 0) = 0
                   and e.identidade = nf.remetente
                   and nf.reentrega = 'N'
                   and nf.idnotafiscal = nfr.idnotafiscal
                   and nfr.idromaneio = p_idromaneio
                 group by nf.idnotafiscal, nf.idprenf,
                          nvl(d.atualizapesonf, 'N'), nf.statusroteirizacao)
      
      loop
      
        if c.statusroteirizacao = 0 then
          v_msg := t_message('Operação cancelada!' || chr(13) ||
                             'Verifique o estoque dos produtos envolvidos na operação.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        update nfimpressao
           set veiculo     = p_placa,
               pesoliquido = decode(nvl(pesoliquido, 0),
                                    decode(c.atualizapesonf, 'S', c.peso,
                                            pesoliquido), pesoliquido)
         where idprenf = c.idprenf;
      
        update notafiscal
           set placaveiculo = p_placa,
               pesoliquido  = decode(nvl(pesoliquido, 0),
                                     decode(c.atualizapesonf, 'S', c.peso,
                                             pesoliquido), pesoliquido)
         where idnotafiscal = c.idnotafiscal;
      end loop;
    end;
  
    function cargaFinalizadaEmbarque(p_idcarga in number) return boolean is
      v_finalizada number;
    begin
      select count(*)
        into v_finalizada
        from carga c
       where c.embarqueliberado = 'S'
         and c.finalizado = 'N'
         and c.idcarga = p_idcarga;
    
      return v_finalizada > 0;
    end;
  begin
    pk_utilities.GeraLog(p_usuario,
                         'Iniciou a formação de romaneio ' ||
                          p_romaneiopai.idromaneio, p_romaneiopai.idromaneio,
                         'XX');
  
    -- checar qtde atendida das nfs
    -- se tiver algum produto com qtde atendida NULA da erro!
    if p_checarqtde = 'S' then
      checar_nf_qtdeatendida(p_romaneiopai.idromaneio);
    end if;
  
    if p_estado = 'X' then
      v_estado := estado_notafiscal_romaneio(p_romaneiopai.idromaneio);
    else
      v_estado := p_estado;
    end if;
  
    -- Libera ou ocupa a doca e veiculo do romaneio
    if p_veiculodoca = 'S' then
      alterar_veiculo_doca_romaneio(p_romaneiopai);
    end if;
  
    -- Sumariza o Romaneio
    if p_atualizarprod = 'S' then
      Atualizar_Produtos_Romaneio(p_romaneiopai, 'N');
    end if;
  
    criar_pallet_romaneio(p_romaneiopai, p_usuario, v_estado, c_nao,
                          p_gerarseparacao);
  
    -- atualiza o codigo do romaneio
    Atualizar_Num_Romaneio(p_romaneiopai);
  
    -- Estabelecer a relação de lotes por notas do romaneio
    identificarlotes(p_romaneiopai.idromaneio);
  
    -- verifica se ha necessidade de inserir a carga
    v_carga := Inserir_Carga(p_romaneiopai, p_usuario, p_gerarcarga);
  
    inserirNFCarga(p_romaneiopai.idromaneio, v_carga);
  
    atualizarDadosNotaFiscal(p_romaneiopai.idromaneio, p_romaneiopai.placa);
  
    calculaValoresRomaneio(p_romaneiopai.idromaneio);
  
    --verifica se as notas do romaneio ja foram faturadas.
    VerificaNFRomaneio(p_romaneiopai);
  
    AtualizarRomaneio(p_romaneiopai);
  
    if p_gerarcarga = 'S' then
      CriarManifestoCarga(v_carga, 0);
    end if;
  
    -- Verifica se a carga achada para o romaneio não foi finalizada durante sua formação
    if cargaFinalizadaEmbarque(v_carga) then
      v_msg := t_message('Romaneio não pode ser formado pois a carga ' ||
                         '{0} do romaneio foi autorizada para embarque durante sua formação.' ||
                         CHR(13) || 'Tente formar o romaneio novamente.');
      v_msg.addParam(v_carga);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- gerando log de geracao do romaneio
    pk_utilities.GeraLog(p_usuario,
                         'Gerou o Romaneio ID: ' ||
                          p_romaneiopai.idromaneio || ' Romaneio NUM: ' ||
                          p_romaneiopai.codigointerno,
                         p_romaneiopai.idromaneio, 'RP');
  
    GeraConvocacaoAtiva(p_romaneiopai.idromaneio, p_usuario,
                        p_gerarseparacao);
  
    pk_utilities.GeraLog(p_usuario,
                         'Terminou a formação de romaneio ' ||
                          p_romaneiopai.idromaneio, p_romaneiopai.idromaneio,
                         'XX');
  
    if p_commit = 'S' then
      commit;
    end if;
  end;

  procedure formarRomaneioReentrega
  (
    p_romaneiopai       in romaneiopai%rowtype,
    p_usuario           in number,
    p_gerarcarga        in char,
    p_criarNovoRomaneio in boolean,
    p_commit            in char
  ) is
  
    r_romaneiopai   romaneiopai%rowtype;
    v_geraseparacao char(1);
  
    function gerarSeparacaoRomaneio(p_idromaneio in number) return char is
      v_controlaareaespera char(1);
    begin
      begin
        select nvl(d.controlaareaespera, 'N') controlaareaespera
          into v_controlaareaespera
          from nfromaneio nfr, notafiscal nf, depositante d, notafiscal nfe
         where nfe.idnotafiscalvinculada = nf.idnotafiscal
           and d.identidade = nf.iddepositante
           and nf.idnotafiscal = nfr.idnotafiscal
           and nfr.idromaneio = p_idromaneio;
      exception
        when no_data_found then
          v_controlaareaespera := 'N';
      end;
      return v_controlaareaespera;
    end;
  
    function conferesaidareentrega(p_idromaneio in number) return boolean is
      v_qtde number;
    begin
      select count(nfr.idnotafiscal)
        into v_qtde
        from nfromaneio nfr, notafiscal nf, depositante d
       where d.confsaidareentrega = 'S'
         and d.identidade = nf.iddepositante
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_idromaneio;
    
      return v_qtde > 0;
    end;
  
    procedure separarNotasReentrega
    (
      p_idromaneio          in number,
      p_idromaneioreentrega in number
    ) is
    begin
      for c in (select nfr.idnotafiscal
                  from nfromaneio nfr, notafiscal nf
                 where nf.reentrega = 'S'
                   and nf.idnotafiscal = nfr.idnotafiscal
                   and nfr.idromaneio = p_idromaneio)
      loop
        atualizaDocumentoRomaneio(p_idromaneio, c.idnotafiscal, 1);
      
        update nfromaneio
           set idromaneio = p_idromaneioreentrega
         where idnotafiscal = c.idnotafiscal
           and idromaneio = p_idromaneio;
      
        atualizaDocumentoRomaneio(p_idromaneioreentrega, c.idnotafiscal, 0);
      end loop;
    end;
  
    procedure inserirVolumes(p_idromaneioreentrega in number) is
    begin
    
      insert into volumeromaneiosum
        (idtipocaixavolume, idromaneio, qtde)
        select vrs.idtipocaixavolume, p_idromaneioreentrega, vrs.qtde
          from nfromaneio nfrr, nfromaneio nfr, romaneiopai rp,
               volumeromaneiosum vrs
         where nfrr.idromaneio = p_idromaneioreentrega
           and nfr.idnotafiscal = nfrr.idnotafiscal
           and rp.idromaneio = nfr.idromaneio
           and rp.idromaneio = vrs.idromaneio
           and rp.reentrega = 'N';
    
      insert into volumeromaneio
        (idromaneio, idvolume, idtipocaixavolume, peso, codbarra,
         datapesagem, idusuario, data, idusuariorepesagem, datarepesagem,
         idusuarioconferencia, conferido, dataconferencia, nrocorreio,
         pesoauditado, idvolumeromaneio, idnotafiscal, impresso,
         pesagemliberada, statusvolume, idcarga, numero, pesoteorico,
         pesocaixa, auditoria, idusuarioentdoca, dataentvolumedoca,
         alturacaixa, larguracaixa, comprimentocaixa, codbarratipo,
         idusuariocancelamento, datacancelamento, idusuariopesagem,
         impressoentrega, idusuarioimpentrega, dataimpentrega,
         idenderecoanterior, idcodrasttransdep, controlaembrulhopresente)
        select p_idromaneioreentrega, vr.idvolume, vr.idtipocaixavolume,
               vr.peso, vr.codbarra, vr.datapesagem, vr.idusuario, vr.data,
               vr.idusuariorepesagem, vr.datarepesagem,
               vr.idusuarioconferencia, vr.conferido, vr.dataconferencia,
               vr.nrocorreio, vr.pesoauditado, seq_volumeromaneio.nextval,
               vr.idnotafiscal, vr.impresso, vr.pesagemliberada,
               vr.statusvolume, vr.idcarga, vr.numero, vr.pesoteorico,
               vr.pesocaixa, vr.auditoria, vr.idusuarioentdoca,
               vr.dataentvolumedoca, vr.alturacaixa, vr.larguracaixa,
               vr.comprimentocaixa, vr.codbarratipo,
               vr.idusuariocancelamento, vr.datacancelamento,
               vr.idusuariopesagem, vr.impressoentrega,
               vr.idusuarioimpentrega, vr.dataimpentrega,
               vr.idenderecoanterior, vr.idcodrasttransdep,
               vr.controlaembrulhopresente
          from nfromaneio nfrr, nfromaneio nfr, romaneiopai rp,
               volumeromaneio vr
         where nfrr.idromaneio = p_idromaneioreentrega
           and nfr.idnotafiscal = nfrr.idnotafiscal
           and rp.idromaneio = nfr.idromaneio
           and rp.idromaneio = vr.idromaneio
           and rp.reentrega = 'N';
    
    end;
  begin
    -- Criar o romaneio de reentrega
    r_romaneiopai                        := p_romaneiopai;
    r_romaneiopai.tituloromaneio         := 'REENTREGA - ' ||
                                            r_romaneiopai.tituloromaneio;
    r_romaneiopai.reentrega              := 'S';
    r_romaneiopai.idusuario              := p_usuario;
    r_romaneiopai.gerado                 := 'S';
    r_romaneiopai.faturado               := 'S';
    r_romaneiopai.dataenviadofaturamento := sysdate;
  
    if p_criarNovoRomaneio then
      r_romaneiopai.idromaneio := inserir_romaneiopai(r_romaneiopai);
    
      separarNotasReentrega(p_romaneiopai.idromaneio,
                            r_romaneiopai.idromaneio);
      -- separar notas fiscais de reentrega 
    
    end if;
  
    -- atualizando o idromaneio para a ocorrencia
    update ocorrenciaentrega o
       set o.idromaneioreentrega = r_romaneiopai.idromaneio
     where exists (select 1
              from nfromaneio nfr
             where nfr.idromaneio = r_romaneiopai.idromaneio
               and nfr.idnotafiscal = o.idnotafiscal);
  
    update notafiscal n
       set n.retornoreentrega = 'N'
     where exists (select 1
              from nfromaneio nfr, notafiscal nf
             where nf.reentrega = 'S'
               and nf.tiponf = 'N'
               and nf.idnotafiscal = nfr.idnotafiscal
               and nfr.idromaneio = r_romaneiopai.idromaneio
               and nfr.idnotafiscal = n.idnotafiscal);
  
    if conferesaidareentrega(r_romaneiopai.idromaneio) then
      r_romaneiopai.liberado := 'N';
    else
      r_romaneiopai.liberado        := 'S';
      r_romaneiopai.separado        := 'S';
      r_romaneiopai.pesagemliberada := 'S';
    end if;
  
    v_geraseparacao := gerarSeparacaoRomaneio(r_romaneiopai.idromaneio);
  
    if v_geraseparacao = 'N'
       and r_romaneiopai.pesagemliberada = 'S' then
      --Inserir volumes conforme o romaneio que não é de reentrega.
      inserirVolumes(r_romaneiopai.idromaneio);
    end if;
  
    formarRomaneioNormal(r_romaneiopai, p_usuario, p_gerarcarga, p_commit,
                         'S', 'X', 'S', 'S', v_geraseparacao);
  end;

  /*
   * Rotina responsavel por formar o romaneio, dependendo da configuracao
   * setada no sistema (tab. configuracao) o romaneio de separacao ja
   * sera criado.
  */
  procedure formar_Romaneio
  (
    p_romaneio       in number,
    p_usuario        in number,
    p_gerarcarga     in varchar2,
    p_commit         in varchar2 := 'S',
    p_checarqtde     in char := 'S',
    p_estado         in char := 'X',
    p_atualizarprod  in char := 'S',
    p_veiculodoca    in char := 'S',
    p_gerarseparacao in varchar2 := 'S'
  ) is
    r_romaneiopai     romaneiopai%rowtype;
    v_qtdenfnormal    number;
    v_qtdenfreentrega number;
  
    procedure verificarQtdeNotasFiscais
    (
      p_idromaneio      in number,
      p_qtdenfnormal    in out number,
      p_qtdenfreentrega in out number
    ) is
    begin
      select sum(decode(nf.reentrega, 'N', count(nfr.idnotafiscal), 0)) normal,
             sum(decode(nf.reentrega, 'S', count(nfr.idnotafiscal), 0)) reentrega
        into p_qtdenfnormal, p_qtdenfreentrega
        from nfromaneio nfr, notafiscal nf
       where nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_idromaneio
       group by nf.reentrega;
    end;
  
  begin
    r_romaneiopai := carregar_romaneio(p_romaneio);
  
    verificarQtdeNotasFiscais(p_romaneio, v_qtdenfnormal, v_qtdenfreentrega);
  
    if (v_qtdenfnormal > 0)
       and (v_qtdenfreentrega > 0) then
      formarRomaneioReentrega(r_romaneiopai, p_usuario, p_gerarcarga, true,
                              p_commit);
    
      formarRomaneioNormal(r_romaneiopai, p_usuario, p_gerarcarga, p_commit,
                           p_checarqtde, p_estado, p_atualizarprod,
                           p_veiculodoca, p_gerarseparacao);
    
    elsif v_qtdenfnormal > 0 then
      formarRomaneioNormal(r_romaneiopai, p_usuario, p_gerarcarga, p_commit,
                           p_checarqtde, p_estado, p_atualizarprod,
                           p_veiculodoca, p_gerarseparacao);
    else
      formarRomaneioReentrega(r_romaneiopai, p_usuario, p_gerarcarga, false,
                              p_commit);
    end if;
  
  end;

  /*
   * Atualiza o Codigo do Romaneio
  */
  procedure Atualizar_Num_Romaneio(p_romaneio in out romaneiopai%rowtype) is
    -- cursor de configuracao de operacao
    cursor c_configoper is
      select nvl(c.nummaxromaneio, 1000) nummaxromaneio,
             nvl(c.numromaneio, 0) + 1 numromaneio,
             nvl(c.palletaltura, 0) * nvl(c.palletlargura, 0) *
              nvl(c.palletcomprimento, 0) volume, palletcc, padraoseparacao
        from configoper c
       where c.ativo = C_SIM
         for update;
  
    r_oper c_configoper%rowtype;
  begin
    open c_configoper;
    fetch c_configoper
      into r_oper;
  
    if c_configoper%notfound then
      r_oper.nummaxromaneio := 1000;
      r_oper.numromaneio    := 1;
    end if;
  
    if r_oper.numromaneio >= r_oper.nummaxromaneio then
      r_oper.numromaneio := 1;
    end if;
  
    -- loop que controla o numero do romaneio nao deixando ele terminar com 0 e 1
    while mod(r_oper.numromaneio, 10) in (0, 1)
    loop
      r_oper.numromaneio := r_oper.numromaneio + 1;
    end loop;
  
    update configoper
       set numromaneio    = r_oper.numromaneio,
           nummaxromaneio = r_oper.nummaxromaneio
     where ativo = 'S';
  
    update logromaneiocorte lr
       set lr.codigointerno = r_oper.numromaneio
     where lr.idromaneio = p_romaneio.idromaneio;
  
    -- atualiza as infomacoes do romaeniopai
    p_romaneio.codigointerno := r_oper.numromaneio;
  
    -- fecha os cursores
    close c_configoper;
  exception
    when dup_val_on_index then
      close c_configoper;
      Atualizar_Num_Romaneio(p_romaneio);
  end;

  /*
   * Libera ou ocupa a doca e veiculo do romaneio
  */
  procedure alterar_veiculo_doca_romaneio(r_romaneio in romaneiopai%rowtype) is
  begin
    -- libera o veiculo e a doca setada para as nfs do romaneio
    -- este procedimento e feito caso seja necessario alterar o veiculo ou a doca do romaneio
  
    -- libera os veiculos setados para as nf¿s
    /*  update veiculo
         set disponivel = C_SIM
       where placa in
             (select distinct nf.placaveiculo
                from nfromaneio nfr, notafiscal nf
               where nf.idnotafiscal = nfr.idnotafiscal
                 and nfr.idromaneio = r_romaneio.idromaneio);
    
      -- libera as docas setadas para as nfs
      update doca
         set liberada = C_SIM
       where (idarmazem, iddoca) in
             (select distinct nf.idarmazem, nf.iddoca
                from nfromaneio nfr, notafiscal nf
               where nf.idnotafiscal = nfr.idnotafiscal
                 and nfr.idromaneio = r_romaneio.idromaneio);
    */
    -- atualiza as nfs
    update notafiscal
       set idarmazem    = nvl(r_romaneio.idarmazem, idarmazem),
           iddoca       = nvl(r_romaneio.iddoca, iddoca),
           placaveiculo = nvl(r_romaneio.placa, placaveiculo)
     where idnotafiscal in
           (select idnotafiscal
              from nfromaneio
             where idromaneio = r_romaneio.idromaneio);
  
    -- aloca os recursos usados
    /*    update veiculo
       set disponivel = C_NORMAL
     where placa = r_romaneio.placa;
    
    update doca
       set liberada = C_NORMAL
     where iddoca = r_romaneio.iddoca
       and idarmazem = r_romaneio.idarmazem;*/
  end;

  /*
   * Gera as inf. de separacao do romaneio, como palet, mapa de separacao, produto por cliente, etc.
  */
  procedure criar_pallet_romaneio
  (
    p_romaneio       in out romaneiopai%rowtype,
    p_usuario        in number,
    p_estado         lote.estado%type,
    p_commit         in varchar2 := c_sim,
    p_gerarseparacao in varchar2 := 'S'
  ) is
    v_num_pallet number := 0;
  begin
    -- verifica se vai ser gerado o palet de separacao junto com a criacao do romaneio
    if p_gerarseparacao = 'S' then
      -- verifica as restricoes de picking
      verificar_restricao_picking(p_romaneio.idromaneio);
    
      /*
       * cria os palets considerando a ordem de entrega, volume e peso das mercadorias
       * cricao dos palets de produtos nao segregados (toxicos)
      */
      formar_pallet_ordem_entrega(p_romaneio.idromaneio, v_num_pallet,
                                  p_romaneio.nummaxpalet,
                                  p_romaneio.calculanumpalet);
    
      -- cria o romaneio de separacao
      criar_pallet_separacao(p_romaneio, p_usuario, p_estado, p_commit);
    
      if p_commit = 'S' then
        AtualizarRomaneio(p_romaneio);
        commit;
      end if;
    end if;
  end;

  /*
   * Apaga as informacoes do palet
  */
  procedure apagar_pallet_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
  begin
    excluir_pallet_separacao(p_romaneio, p_usuario);
  
    delete from lotepallet
     where idpallet in (select id
                          from palet
                         where idromaneio = p_romaneio);
  
    delete from corteromaneio
     where idromaneio = p_romaneio;
  
    delete from estornopalet
     where idromaneio = p_romaneio;
  
    delete from ocorrenciasaida
     where idromaneio = p_romaneio;
  
    delete from ocorrenciasaidanf
     where idromaneio = p_romaneio;
  
    delete from ocorrenciasaidaentrega
     where idromaneio = p_romaneio;
  
    delete from custoconferencia
     where idromaneio = p_romaneio;
  
    -- apaga lote de expedição rastreada
    delete from confpaletregiao
     where idconfregiao in (select idconfregiao
                              from confregiao
                             where idromaneio = p_romaneio);
  
    delete from confregiao
     where idromaneio = p_romaneio;
  
    delete from confpaletloteentrega
     where idromaneio = p_romaneio;
  
    delete from confpaletlote
     where idromaneio = p_romaneio;
  
    delete from logconfpaletregiao
     where idromaneio = p_romaneio;
  
    delete from logconfpalet
     where idromaneio = p_romaneio;
  
    delete from logconfpaletnf
     where idromaneio = p_romaneio;
  
    delete from logconfpaletentrega
     where idromaneio = p_romaneio;
  
    delete from confpalet
     where idromaneio = p_romaneio;
  
    delete from confpaletnf
     where idromaneio = p_romaneio;
  
    delete from confpaletentrega
     where idromaneio = p_romaneio;
  
    delete from produtopalet
     where idromaneio = p_romaneio;
  
    delete from fichaseparacao
     where idromaneio = p_romaneio;
  
    delete from palet
     where idromaneio = p_romaneio;
  end;

  -- Refactored procedure inserirReabastecimentoPK 
  procedure inserirReabastecimentoPK(p_idromaneio in number) is
  begin
    delete from gtt_reabastecer_picking;
    -- insere a quantidade de estoque dos produtos presentes no romaneio
    insert into gtt_reabastecer_picking
      (idarmazem, idlocal, idlote, iddepositante, idproduto, dtvenc, barra,
       estado, picking, fc, lastro, qtdecamada, descricaolote, est,
       dtentrada)
      select idarmazem, idlocal, idlote, iddepositante, idproduto, dtvenc,
             barra, estado, picking, fc, lastro, qtdecamada, descricaolote,
             disp - (disp - case
                when disp <= qtdedisponivel then
                 disp
                else
                 qtdedisponivel
              end) est, dtentrada
        from (select distinct ll.idarmazem, ll.idlocal, ll.idlote,
                               l.iddepositante, l.idproduto,
                               nvl(l.dtvenc, sysdate) dtvenc, l.barra,
                               e.fatorconversao fc, e.lastro, e.qtdecamada,
                               l.estado, lo.picking, l.descr descricaolote,
                               nvl(l.qtdedisponivel, 0) qtdedisponivel,
                               ((ll.estoque - ll.pendencia + ll.adicionar) -
                                nvl(se.qtde, 0)) disp, l.dtentrada
                 from romaneio r, lote l, lotelocal ll, local lo, embalagem e,
                      setor s,
                      (select se.idlote, sum(nvl(se.qtde, 0)) qtde
                          from (select nf.idnotafiscal, nf.iddepositante,
                                        nf.estado
                                   from notafiscal nf
                                  where nf.statusroteirizacao = 1
                                    and nf.reentrega = 'N') n,
                               separacaoespecifica se
                         where se.idnotafiscal = n.idnotafiscal
                         group by se.idlote) se, regiaoarmazenagem ra
                where r.idromaneio = p_idromaneio
                  and l.idproduto = r.idproduto
                  and l.tipolote = 'L'
                  and l.liberado = 'S'
                  and ll.idlote = l.idlote
                  and (ll.estoque - ll.pendencia + ll.adicionar) > 0
                  and lo.idarmazem = ll.idarmazem
                  and lo.idlocal = ll.idlocal
                  and lo.ativo = 'S'
                  and lo.tipo in (0, 1, 2)
                  and lo.buffer = 'N'
                  and e.idproduto = l.idproduto
                  and e.barra = l.barra
                  and se.idlote(+) = l.idlote
                  and s.idsetor(+) = lo.idsetor
                  and ra.idregiao = lo.idregiao
                  and nvl(s.expedicao, 'S') = 'S'
                  and not exists (select 1
                         from receitaestojamentolote rel
                        where rel.idlote = l.idlote)
                  and not exists
                (select idsetor
                         from tiporecebimento tr, setorrecebimento sr
                        where tr.classificacao in ('R', 'E')
                          and sr.idtiporecebimento = tr.idtiporecebimento
                          and sr.idsetor = lo.idsetor)
                  and not exists
                (select 1
                         from conferenciaentradadet d, compmontagem c
                        where d.idlotenf = c.idlotenf
                          and d.idconferenciaentrada = c.idconferenciaentrada
                          and d.idcontagem = c.idcontagem
                          and d.idlote = l.idlote)
                  and not exists
                (select 1
                         from conferenciaentradadet d, montagem c
                        where d.idlotenf = c.idlotenf
                          and d.idconferenciaentrada = c.idconferenciaentrada
                          and d.idcontagem = c.idcontagem
                          and d.idlote = l.idlote)
                  and ((ll.estoque - ll.pendencia + ll.adicionar) -
                      nvl(se.qtde, 0)) > 0);
  end inserirReabastecimentoPK;

  function retonarQtdeAbastecimento
  (
    p_tipo           in number,
    p_idproduto      in number,
    p_qtde           in out number,
    p_qtdeestoque    in number,
    p_fatorconversao in number,
    p_estanteria     char := null,
    p_lastro         in number := null,
    p_camada         in number := null,
    p_qtdeutilizada  in out number
  ) return number is
    v_qtde               number := 0;
    v_qtdeabastecer      number := 0;
    v_pontoressuprimento number;
    v_fatorconversao     number;
    v_msg                t_message;
    v_qtdeatual          number := 0;
  begin
    /* 
    Quanto p_tipo for:
    0 - Reabastece com a qtde do lote 
    1 - Reabastece por embalagem
    2 - Reabastece por lastro
    3 - Reabastece sob demanda
    */
  
    if p_tipo = 0 then
      v_qtdeabastecer := p_qtdeestoque;
      p_qtdeutilizada := p_qtdeutilizada + p_qtdeestoque;
    elsif p_tipo < 3 then
      v_qtdeatual := p_qtdeutilizada;
      while (p_qtde > p_qtdeutilizada)
            and (v_qtdeabastecer < p_qtdeestoque)
      loop
        if p_tipo = 1 then
          v_qtde          := p_fatorconversao;
          v_qtdeabastecer := v_qtdeabastecer + v_qtde;
        else
          if p_estanteria = 'S' then
            v_qtde          := (p_lastro * p_fatorconversao);
            v_qtdeabastecer := v_qtdeabastecer + v_qtde;
          else
            v_qtde          := (p_lastro * p_camada * p_fatorconversao);
            v_qtdeabastecer := v_qtdeabastecer + v_qtde;
          end if;
        end if;
      
        if v_qtdeabastecer > p_qtdeestoque then
          v_qtde          := p_qtdeestoque;
          v_qtdeabastecer := p_qtdeestoque;
          p_qtdeutilizada := v_qtdeatual + p_qtdeestoque;
        else
          p_qtdeutilizada := p_qtdeutilizada + v_qtde;
        end if;
      end loop;
    else
      select p.pontoressuprimento * max(e.fatorconversao) pontoressuprimento,
             max(e.fatorconversao) fatorconversao
        into v_pontoressuprimento, v_fatorconversao
        from produto p, embalagem e
       where e.ativo = 'S'
         and e.idproduto(+) = p.idproduto
         and p.idproduto = p_idproduto
       group by p.pontoressuprimento;
    
      if (v_fatorconversao is not null)
         and (v_pontoressuprimento is not null) then
        if p_qtde < v_pontoressuprimento then
          v_qtde := v_pontoressuprimento - p_qtdeutilizada;
        
          p_qtde := v_pontoressuprimento;
        else
          v_qtde := p_qtde - p_qtdeutilizada;
        end if;
      
        if v_qtde >= p_qtdeestoque then
          v_qtde := p_qtdeestoque;
        else
          if trunc(v_qtde / v_fatorconversao) < (v_qtde / v_fatorconversao) then
            v_qtde := (trunc(v_qtde / v_fatorconversao) * v_fatorconversao) +
                      v_fatorconversao;
          end if;
        
          if (v_qtde + p_qtdeutilizada) > v_pontoressuprimento
             and nvl(v_pontoressuprimento, 0) > 0 then
            v_qtde := v_qtde - v_fatorconversao;
          end if;
        end if;
      
        v_qtdeabastecer := v_qtde;
      
        p_qtdeutilizada := p_qtdeutilizada + v_qtde;
      elsif v_fatorconversao is null then
        v_msg := t_message('Não existe fator de conversão para o produto de id: ' ||
                           '{0}.' || chr(13) || 'Operação Cancelada.');
        v_msg.addParam(p_idproduto);
        raise_application_error(-20100, v_msg.formatMessage);
      elsif v_pontoressuprimento is null then
        v_msg := t_message('O Limite de Ressuprimento não foi definido para o produto de id: ' ||
                           '{0}.' || chr(13) || 'Operação Cancelada.');
        v_msg.addParam(p_idproduto);
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end if;
  
    return v_qtdeabastecer;
  end;

  procedure criarRemanejamento
  (
    p_idromaneio     in number,
    p_idarmazem      in number,
    p_idlocalorigem  in local.idlocal%type,
    p_idlocaldestino in local.idlocal%type,
    p_idusuario      in number,
    p_idlote         in number,
    p_qtdeabastecer  in number,
    p_commit         in char
  ) is
    v_textoRemanejamento varchar2(100);
    v_idremanejamento    number;
    v_regiaoorigem       varchar2(1000);
    v_ruaorigem          local.rua%type;
    v_regiaodestino      varchar2(1000);
    v_ruadestino         local.rua%type;
  begin
    if p_qtdeabastecer > 0 then
      select decode(r.tipo, 0, 'Reabastecimento para romaneio.',
                     'Reabastecimento para onda.')
        into v_textoRemanejamento
        from romaneiopai r
       where r.idromaneio = p_idromaneio;
    
      v_idremanejamento := pk_remanejamento.cadastrar_remanejamento(p_idarmazem,
                                                                    p_idarmazem,
                                                                    p_idlocalorigem,
                                                                    p_idlocaldestino,
                                                                    p_idusuario,
                                                                    p_idromaneio,
                                                                    v_textoRemanejamento,
                                                                    p_commit,
                                                                    'S');
      --Apenas para locar a registro da rotina para não executar finalização do remanejamento durante formação do romaneio. 
      update remanejamento
         set status = status
       where idremanejamento = v_idremanejamento;
    
      begin
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, idromaneio)
        values
          (v_idremanejamento, p_idlote, p_qtdeabastecer, 'N', p_idromaneio);
      
      exception
        when dup_val_on_index then
          update loteremanejamento lr
             set lr.qtde = lr.qtde + p_qtdeabastecer
           where lr.idremanejamento = v_idremanejamento
             and lr.idlote = p_idlote;
      end;
    
      -- insere lotes filhos de montagem  
      pk_remanejamento.Associar(v_idremanejamento, p_idlote);
    
      begin
        insert into remanejamentoromaneio
          (idremanejamento, idromaneio, idlote, qtde, data)
        values
          (v_idremanejamento, p_idromaneio, p_idlote, p_qtdeabastecer,
           sysdate);
      exception
        when dup_val_on_index then
          update remanejamentoromaneio rr
             set rr.qtde = rr.qtde + p_qtdeabastecer
           where rr.idremanejamento = v_idremanejamento
             and rr.idromaneio = p_idromaneio
             and rr.idlote = p_idlote;
      end;
    
      select r.descr, lo.rua
        into v_regiaoorigem, v_ruaorigem
        from regiaoarmazenagem r, local lo
       where lo.idregiao = r.idregiao
         and lo.idlocal = p_idlocalorigem
         and lo.idarmazem = p_idarmazem;
    
      select r.descr, ld.rua
        into v_regiaodestino, v_ruadestino
        from regiaoarmazenagem r, local ld
       where ld.idregiao = r.idregiao
         and ld.idlocal = p_idlocaldestino
         and ld.idarmazem = p_idarmazem;
    
      /* -- atualiza a tabela temporária incluindo o lote que foi para o picking e retirando o lote que saiu do pulmao
      insert into gtt_reabastecer_picking
        (idarmazem, idlocal, idlote, iddepositante, idproduto, dtvenc,
         barra, estado, picking, fc, lastro, qtdecamada, descricaolote,
         est)
      values
        (p_idarmazem, p_idlocaldestino, p_idlote,
         c_reab.iddepositante, c_reab.idproduto, r_estlocal.dtvenc,
         r_estlocal.barra, r_estlocal.estado, 'S', r_estlocal.fc,
         r_estlocal.lastro, r_estlocal.qtdecamada,
         r_estlocal.descricaolote, v_qtde_abastecer);*/
    
      update gtt_reabastecer_picking
         set est = est - p_qtdeabastecer
       where idarmazem = p_idarmazem
         and idlocal = p_idlocalorigem
         and idlote = p_idlote;
    end if;
  end;

  /*
   * reabastece o picking para a formacao do romaneio
  */
  procedure reabastecer_picking
  (
    p_romaneio in number,
    p_usuario  in number,
    p_estado   in lote.estado%type,
    p_commit   in varchar2 := 'S'
  ) is
    cursor c_picking
    (
      p_prod        in number,
      p_armazem     in number,
      p_depositante in number
    ) is
      select pl.idlocal, l.estanteria
        from local l, produtolocal pl, setor s, tiposetor ts,
             regiaoarmazenagem ra
       where pl.idarmazem = p_armazem
         and pl.idproduto = p_prod
         and pl.identidade = p_depositante
         and l.idarmazem = pl.idarmazem
         and l.idlocal = pl.idlocal
         and ra.idregiao = l.idregiao
         and l.picking = 'S'
         and l.tipo = 0
         and l.buffer = 'N'
         and l.ativo = 'S'
         and s.idsetor = l.idsetor
         and ts.idtiposetor = s.idtiposetor
         and ts.normal = 'S'
         and s.expedicao = 'S';
  
    r_picking        c_picking%rowtype;
    v_qtdeutilizada  number := 0;
    v_qtdepick       number := 0;
    v_qtdepulmao     number := 0;
    v_qtdeabastecer  number := 0;
    v_texto          varchar2(20);
    v_disponivellote number;
    v_msg            t_message;
  
    function temOrdemServico(p_romaneio in number) return boolean is
      v_idOS number;
    begin
      begin
        v_idOS := 0;
        select idordemservico
          into v_idOS
          from ordemservico
         where idromaneio = p_romaneio;
      
      exception
        when others then
          v_idOS := 0;
      end;
      return v_idOS > 0;
    end;
  
    procedure retornarQtdePickingPulmao
    (
      p_idarmazem     in number,
      p_idproduto     in number,
      p_iddepositante in number,
      p_estado        lote.estado%type,
      p_qtdepicking   in out number,
      p_qtdepulmao    in out number
    ) is
    begin
      select sum(decode(picking, 'S', sum(est), 0)) estoquepicking,
             sum(decode(picking, 'N', sum(est), 0)) estoquepulmao
        into p_qtdepicking, p_qtdepulmao
        from gtt_reabastecer_picking
       where idarmazem = p_idarmazem
         and idproduto = p_idproduto
         and iddepositante = p_iddepositante
         and estado = p_estado
       group by picking;
    exception
      when no_data_found then
        p_qtdepicking := 0;
        p_qtdepulmao  := 0;
    end;
  
  begin
    if (not temOrdemServico(p_romaneio))
       and (p_estado = 'N') then
    
      inserirReabastecimentoPK(p_romaneio);
    
      for c_reab in (select codromaneio, iddepositante, idromaneio, idproduto,
                            sum(qtde) qtde, codigointerno, depositante,
                            idarmazem, tiporeabastecimento
                       from (select r.codigointerno codromaneio,
                                     nf.iddepositante, r.idromaneio,
                                     nfd.idproduto,
                                     sum(nfd.qtdeatendida * e.fatorconversao) -
                                      nvl(se.qtde, 0) qtde, p.codigointerno,
                                     ent.razaosocial depositante, r.idarmazem,
                                     decode(p.fracionado, 'S', 0,
                                             decode(d.reabastecerporembalagem,
                                                     'S', 1,
                                                     decode(d.reabastecersomentedemanda,
                                                             'N', 2, 3))) tiporeabastecimento
                                from romaneiopai r, nfromaneio nfr,
                                     notafiscal nf, nfdet nfd, embalagem e,
                                     produto p, entidade ent, depositante d,
                                     (select l.idproduto, sum(se.qtde) qtde
                                         from nfromaneio nfr,
                                              separacaoespecifica se, lote l
                                        where nfr.idromaneio = p_romaneio
                                          and se.idnotafiscal = nfr.idnotafiscal
                                          and l.idlote = se.idlote
                                        group by l.idproduto) se
                               where r.idromaneio = p_romaneio
                                 and nfr.idromaneio = r.idromaneio
                                 and nf.idnotafiscal = nfr.idnotafiscal
                                 and nfd.nf = nf.idnotafiscal
                                 and e.idproduto = nfd.idproduto
                                 and e.barra = nfd.barra
                                 and p.idproduto = nfd.idproduto
                                 and ent.identidade = nf.iddepositante
                                 and d.identidade = nf.iddepositante
                                 and d.usapicking = 'S'
                                 and nf.reentrega = 'N'
                                 and se.idproduto(+) = nfd.idproduto
                                 and p.kitexpexplodida = 'N'
                               group by r.codigointerno, r.idarmazem,
                                        nf.iddepositante, ent.razaosocial,
                                        r.idromaneio, nfd.idproduto,
                                        p.codigointerno, nvl(se.qtde, 0),
                                        decode(p.fracionado, 'S', 0,
                                                decode(d.reabastecerporembalagem,
                                                        'S', 1,
                                                        decode(d.reabastecersomentedemanda,
                                                                'N', 2, 3)))
                              union all
                              select r.codigointerno codromaneio,
                                     nf.iddepositante, r.idromaneio,
                                     pk.idproduto,
                                     sum((nfd.qtdeatendida * e.fatorconversao) *
                                          (kp.qtde * nvl(ek.fatorconversao, 0))) -
                                      nvl(se.qtde, 0) qtde, pk.codigointerno,
                                     ent.razaosocial depositante, r.idarmazem,
                                     decode(p.fracionado, 'S', 0,
                                             decode(d.reabastecerporembalagem,
                                                     'S', 1,
                                                     decode(d.reabastecersomentedemanda,
                                                             'N', 2, 3))) tiporeabastecimento
                                from romaneiopai r, nfromaneio nfr,
                                     notafiscal nf, nfdet nfd, embalagem e,
                                     produto p, entidade ent, depositante d,
                                     (select l.idproduto, sum(se.qtde) qtde
                                         from nfromaneio nfr,
                                              separacaoespecifica se, lote l
                                        where nfr.idromaneio = p_romaneio
                                          and se.idnotafiscal = nfr.idnotafiscal
                                          and l.idlote = se.idlote
                                        group by l.idproduto) se, kitproduto kp,
                                     produto pk, embalagem ek
                               where r.idromaneio = p_romaneio
                                 and nfr.idromaneio = r.idromaneio
                                 and nf.idnotafiscal = nfr.idnotafiscal
                                 and nfd.nf = nf.idnotafiscal
                                 and e.idproduto = nfd.idproduto
                                 and e.barra = nfd.barra
                                 and p.idproduto = nfd.idproduto
                                 and ent.identidade = nf.iddepositante
                                 and d.identidade = nf.iddepositante
                                 and d.usapicking = 'S'
                                 and nf.reentrega = 'N'
                                 and se.idproduto(+) = pk.idproduto
                                 and p.kitexpexplodida = 'S'
                                 and kp.idprodutokit = nfd.idproduto
                                 and pk.idproduto = kp.idproduto
                                 and ek.barra = kp.barra
                                 and ek.idproduto = kp.idproduto
                               group by r.codigointerno, r.idarmazem,
                                        nf.iddepositante, ent.razaosocial,
                                        r.idromaneio, pk.idproduto,
                                        pk.codigointerno, nvl(se.qtde, 0),
                                        decode(p.fracionado, 'S', 0,
                                                decode(d.reabastecerporembalagem,
                                                        'S', 1,
                                                        decode(d.reabastecersomentedemanda,
                                                                'N', 2, 3))))
                      group by codromaneio, iddepositante, idromaneio,
                               idproduto, codigointerno, depositante,
                               idarmazem, tiporeabastecimento)
      loop
        -- verifica as qtde de estoque
        retornarQtdePickingPulmao(c_reab.idarmazem, c_reab.idproduto,
                                  c_reab.iddepositante, p_estado, v_qtdepick,
                                  v_qtdepulmao);
      
        -- registra os campos qtdes
        pk_utilities.geralog(p_usuario,
                             'IDPRODUTO =' || c_reab.idproduto ||
                              '; QTDEPEDIDA =' || c_reab.qtde ||
                              '; QTDEPULMAO =' || v_qtdepulmao ||
                              '; QTDEPICK =' || v_qtdepick, p_romaneio, 'ER');
      
        -- verifica se ha necessidade de abastecer
        if c_reab.qtde > v_qtdepick then
          if c_reab.qtde <= (v_qtdepick + v_qtdepulmao) then
          
            open c_picking(c_reab.idproduto, c_reab.idarmazem,
                           c_reab.iddepositante);
            fetch c_picking
              into r_picking;
          
            if c_picking%notfound then
              select decode(p_estado, 'N', 'BOM', 'D', 'DANIFICADO', 'T',
                             'TRUNCADO', 'VENCIDO')
                into v_texto
                from dual;
            
              v_msg   := t_message(v_texto);
              v_texto := v_msg.formatMessage;
            
              v_msg := t_message('Picking não encontrado do produto codigo interno: ' ||
                                 '{0}' || chr(13) || ' e depositante {1}' ||
                                 chr(13) ||
                                 'Verifique se o picking do produto está cadastrado para o depositante,' ||
                                 chr(13) ||
                                 ' se o endereço está ativo, se o endereço está vinculado ao setor do depositante e' ||
                                 chr(13) || ' se o estado do setor é {2}.');
              v_msg.addParam(c_reab.codigointerno);
              v_msg.addParam(c_reab.depositante);
              v_msg.addParam(v_texto);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
            v_qtdeutilizada := v_qtdepick;
          
            -- seleciona os lotes disponivel para remanejamento
            for r_estlocal in (select idlote, dtvenc, idlocal, idproduto,
                                      barra, fc, lastro, qtdecamada,
                                      descricaolote, estado, dtentrada,
                                      sum(est) est
                                 from gtt_reabastecer_picking r
                                where iddepositante = c_reab.iddepositante
                                  and idproduto = c_reab.idproduto
                                  and estado = 'N'
                                  and idarmazem = c_reab.idarmazem
                                  and picking = 'N'
                                group by idlote, dtvenc, idlocal, idproduto,
                                         barra, fc, lastro, qtdecamada,
                                         descricaolote, estado, dtentrada
                               having sum(est) > 0
                                order by trunc(nvl(dtvenc, sysdate)),
                                         dtentrada, idlote)
            loop
              if (r_estlocal.lastro is not null)
                 and (r_estlocal.qtdecamada is not null) then
                v_qtdeabastecer := 0;
              
                v_disponivellote := pk_lote.RetornarQtdeDisponivel(r_estlocal.idlote);
              
                if r_estlocal.est > v_disponivellote then
                  r_estlocal.est := v_disponivellote;
                end if;
              
                if r_estlocal.est > 0 then
                  v_qtdeabastecer := retonarQtdeAbastecimento(c_reab.tiporeabastecimento,
                                                              c_reab.idproduto,
                                                              c_reab.qtde,
                                                              r_estlocal.est,
                                                              r_estlocal.fc,
                                                              r_picking.estanteria,
                                                              r_estlocal.lastro,
                                                              r_estlocal.qtdecamada,
                                                              v_qtdeutilizada);
                
                  -- insere o remanejamednto
                  criarRemanejamento(p_romaneio, c_reab.idarmazem,
                                     r_estlocal.idlocal, r_picking.idlocal,
                                     p_usuario, r_estlocal.idlote,
                                     v_qtdeabastecer, p_commit);
                end if;
              else
                v_msg := t_message('O produto com codigo de barra {0}' ||
                                   'esta com lastro ou camada Nulo. Verifique e tente novamente.');
                v_msg.addParam(pk_produto.retornar_codbarra(r_estlocal.idproduto,
                                                            r_estlocal.fc));
                raise_application_error(-20000, v_msg.formatMessage);
              
              end if;
            
              exit when v_qtdeutilizada >= c_reab.qtde;
            end loop;
            close c_picking;
          end if;
        end if;
      end loop;
    end if;
  end;

  -- Refactored procedure novoPallet 
  procedure novoPallet
  (
    p_romaneio       in number,
    p_segregado      in varchar2,
    p_num_palet      in out number,
    p_nummaxpalet    in number,
    p_calc_num_palet in varchar2,
    v_vol_rest       in out number,
    v_vol_total      in out number,
    v_vol_aloc       in out number,
    v_vol_palet      in out number
  ) is
    v_msg t_message;
  
    cursor c_vol_palet
    (
      p_romaneio in number,
      p_numpalet in number
    ) is
      select nvl(vp.altura, 0) * nvl(vp.largura, 0) *
              nvl(vp.comprimento, 0) -
              (nvl(vp.altura, 0) * nvl(vp.largura, 0) *
               nvl(vp.comprimento, 0) * (nvl(vp.toleranciamed, 0) / 100)) volume
        from romaneiopai rp, veiculopalet vp
       where vp.idpalet = p_numpalet
         and vp.placa = rp.placa
         and rp.idromaneio = p_romaneio;
  begin
    p_num_palet := p_num_palet + 1;
  
    insert into palet
      (idromaneio, idpalet, liberado, separado, recontagem)
    values
      (p_romaneio, p_num_palet, c_normal, c_normal, 'S');
  
    -- verifica se o numero de palet foi ultrapassado
    if p_segregado = 'N'
       and p_calc_num_palet = 'N' then
      if p_nummaxpalet < p_num_palet then
        v_msg := t_message('numero maximo de palet ultrapassado no caminhao.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
    -- verifica se eh o sistema que vai calcular o numero de palets.
    open c_vol_palet(p_romaneio, p_num_palet);
    fetch c_vol_palet
      into v_vol_palet;
  
    if c_vol_palet%found then
      close c_vol_palet;
      if p_calc_num_palet = c_sim then
        v_vol_rest := v_vol_palet;
      else
        -- calcula o volume do palet
        if (p_nummaxpalet - p_num_palet) > 0 then
          v_vol_rest := (v_vol_total - v_vol_aloc) /
                        (p_nummaxpalet - (p_num_palet - 1));
          if v_vol_rest < 0 then
            v_vol_rest := v_vol_total - v_vol_aloc;
          end if;
        else
          v_vol_rest := (v_vol_total - v_vol_aloc);
        end if;
      
        if v_vol_rest < 0 then
          v_msg := t_message('Volume Restante do Palet Nao Pode Ser Menor Que Zero. Operacao Cancelada');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    else
      close c_vol_palet;
      v_msg := t_message('Informações do Palet {0}' ||
                         ' não cadastradas para o Romaneio de ID: {1}.');
      v_msg.addParam(p_num_palet);
      v_msg.addParam(p_romaneio);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  -- Refactored procedure criarPallet 
  procedure criarPallet
  (
    p_romaneio        in number,
    p_segregado       in varchar2,
    p_num_palet       in out number,
    p_nummaxpalet     in number,
    p_calc_num_palet  in varchar2,
    p_peso_max        in number,
    p_idclassificacao in number
  ) is
  
    v_embalagemencontrada boolean;
  
    v_novo_palet       boolean := true;
    v_totu             number;
    v_vol_rest         number := 0;
    v_voltotalromaneio number := 0;
    v_vol_aloc         number := 0;
    v_qtde             number;
    v_vol_palet        number := 0;
    v_tot_peso         number := 0;
    v_vol_tot_palet    number := 0;
    v_pes_tot_palet    number := 0;
    v_msg              t_message;
  
    procedure inserirProdutoRomaneio
    (
      p_romaneio        in number,
      p_segregado       in varchar2,
      p_idclassificacao in number
    ) is
    begin
      delete from gtt_produtoromaneio
       where idromaneio = p_romaneio;
    
      insert into gtt_produtoromaneio
        (idromaneio, iddepositante, ident_entrega, idproduto, codprod,
         produto, barra, qtde, sequencia)
        select p_romaneio idromaneio, iddepositante, ident_entrega,
               idproduto, codprod, produto, barra, sum(qtde) qtde, sequencia
          from (select nfr.sequencia, nf.iddepositante, nf.ident_entrega,
                        nfd.idproduto, p.codigointerno codprod,
                        p.descr produto,
                        decode(p.otimizaseparacao || p.fracionado, 'SN', null,
                                nfd.barra) barra,
                        sum(nvl(e.fatorconversao, 0) * nfd.qtdeatendida) qtde
                   from nfromaneio nfr, notafiscal nf, nfdet nfd, produto p,
                        embalagem e
                  where nfr.idromaneio = p_romaneio
                    and nf.idnotafiscal = nfr.idnotafiscal
                    and nfd.nf = nfr.idnotafiscal
                    and nfd.qtdeatendida > 0
                    and p.idproduto = nfd.idproduto
                    and nvl(p.segregado, 'N') = p_segregado
                    and e.idproduto = nfd.idproduto
                    and e.barra = nfd.barra
                    and p.kitexpexplodida = 'N'
                    and decode(p_idclassificacao, 0, 0, p.idclassificacaomat) =
                        decode(p_idclassificacao, 0, 0, p_idclassificacao)
                  group by nfr.sequencia, nfd.idproduto, p.codigointerno,
                           p.descr, nf.iddepositante, nf.ident_entrega,
                           decode(p.otimizaseparacao || p.fracionado, 'SN',
                                   null, nfd.barra)
                 union all
                 select nfr.sequencia, nf.iddepositante, nf.ident_entrega,
                        kp.idproduto, pk.codigointerno codprod,
                        pk.descr produto,
                        decode(pk.otimizaseparacao || pk.fracionado, 'SN',
                                null, ek.barra) barra,
                        sum((nvl(e.fatorconversao, 0) * nfd.qtdeatendida) *
                             (kp.qtde * nvl(ek.fatorconversao, 0))) qtde
                   from nfromaneio nfr, notafiscal nf, nfdet nfd, produto p,
                        embalagem e, kitproduto kp, embalagem ek, produto pk
                  where nfr.idromaneio = p_romaneio
                    and nf.idnotafiscal = nfr.idnotafiscal
                    and nfd.nf = nfr.idnotafiscal
                    and nfd.qtdeatendida > 0
                    and p.idproduto = nfd.idproduto
                    and nvl(p.segregado, 'N') = p_segregado
                    and e.idproduto = nfd.idproduto
                    and e.barra = nfd.barra
                    and p.kitexpexplodida = 'S'
                    and kp.idprodutokit = nfd.idproduto
                    and ek.barra = kp.barra
                    and ek.idproduto = kp.idproduto
                    and pk.idproduto = kp.idproduto
                    and decode(p_idclassificacao, 0, 0, p.idclassificacaomat) =
                        decode(p_idclassificacao, 0, 0, p_idclassificacao)
                  group by nfr.sequencia, kp.idproduto, pk.codigointerno,
                           pk.descr, nf.iddepositante, nf.ident_entrega,
                           decode(pk.otimizaseparacao || pk.fracionado, 'SN',
                                   null, ek.barra))
         group by iddepositante, ident_entrega, idproduto, codprod, produto,
                  barra, sequencia
         order by idproduto desc;
    end;
  
  begin
    v_voltotalromaneio := vol_total_romaneio(p_romaneio, p_segregado);
  
    inserirProdutoRomaneio(p_romaneio, p_segregado, p_idclassificacao);
  
    -- lista todos os produtos do romaneio.
    for c_prod in (select idromaneio, iddepositante, ident_entrega, idproduto,
                          codprod, produto, barra, qtde, sequencia
                     from gtt_produtoromaneio
                    where idromaneio = p_romaneio
                    order by sequencia desc, idproduto desc)
    loop
    
      getQtdeEmbalagem(c_prod.idproduto, c_prod.barra, c_prod.qtde, v_qtde,
                       v_embalagemencontrada);
    
      if v_embalagemencontrada then
      
        v_totu := 0;
      
        while (c_prod.qtde - v_totu) > 0
        loop
          -- verifica se precisa criar um novo palet
          if v_novo_palet then
            v_vol_tot_palet := 0;
            v_pes_tot_palet := 0;
            novoPallet(p_romaneio, p_segregado, p_num_palet, p_nummaxpalet,
                       p_calc_num_palet, v_vol_rest, v_voltotalromaneio,
                       v_vol_aloc, v_vol_palet);
            v_novo_palet := false;
          end if;
        
          -- verifica se da para colocar o produto no palet
          if (v_vol_rest >= r_embalagem.volume * v_qtde)
             and ((v_tot_peso + r_embalagem.peso * v_qtde) <= p_peso_max) then
            -- pode incluir todo o produto da embalagem selecionada no pallet
          
            v_vol_tot_palet := v_vol_tot_palet +
                               r_embalagem.volume * v_qtde;
            v_pes_tot_palet := v_pes_tot_palet + r_embalagem.peso * v_qtde;
            v_totu          := v_totu + v_qtde * r_embalagem.fatorconversao;
            v_tot_peso      := v_tot_peso + r_embalagem.peso * v_qtde;
            v_vol_rest      := v_vol_rest - r_embalagem.volume * v_qtde;
          
            -- insere as informacoes do produto no palet
            inserir_produto_palet(p_romaneio, p_num_palet,
                                  c_prod.iddepositante, c_prod.ident_entrega,
                                  c_prod.idproduto, r_embalagem.barra,
                                  v_qtde);
          
            if (c_prod.qtde - v_totu) > 0 then
              open c_embalagem(c_prod.idproduto, c_prod.qtde - v_totu);
              fetch c_embalagem
                into r_embalagem;
              close c_embalagem;
            
              v_qtde := trunc((c_prod.qtde - v_totu) /
                              r_embalagem.fatorconversao);
            end if;
          elsif ((v_tot_peso + r_embalagem.peso * v_qtde) <= p_peso_max) then
            while (v_qtde > 0)
                  and (v_novo_palet = false)
            loop
              if (v_vol_rest - r_embalagem.volume) < 0 then
                -- não cabe uma unidade da embalagem do produto
              
                v_novo_palet := true;
              
                v_vol_aloc := v_vol_aloc + v_vol_tot_palet;
                v_tot_peso := v_tot_peso + v_pes_tot_palet;
              
                v_pes_tot_palet := 0;
                v_vol_tot_palet := 0;
                v_vol_rest      := 0;
              else
                -- cabe uma unidade da embalagem do produto
                v_qtde          := v_qtde - 1;
                v_vol_rest      := v_vol_rest - r_embalagem.volume;
                v_totu          := v_totu + r_embalagem.fatorconversao;
                v_tot_peso      := v_tot_peso + r_embalagem.peso;
                v_vol_tot_palet := v_vol_tot_palet + r_embalagem.volume;
                v_pes_tot_palet := v_pes_tot_palet + r_embalagem.peso;
              
                -- insere as informacoes do produto no palet
                inserir_produto_palet(p_romaneio, p_num_palet,
                                      c_prod.iddepositante,
                                      c_prod.ident_entrega, c_prod.idproduto,
                                      r_embalagem.barra, 1);
              end if;
            end loop;
          else
            -- nao suporta o peso da carga
            v_msg := t_message('Peso maximo ultrapassado!');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end loop;
      else
        v_msg := t_message('Embalagens nao encontrada na separacao para o produto de codigo ' ||
                           '{0} e nome: {1} qtde: {2}.' ||
                           ' Verifique se o produto possui alguma embalagem com o FC menor que a qtde do produto.');
        v_msg.addParam(c_prod.codprod);
        v_msg.addParam(c_prod.produto);
        v_msg.addParam(c_prod.qtde);
        raise_application_error(-20099, v_msg.formatMessage);
      end if;
    end loop;
  
  end criarPallet;

  /*
   * Forma o palet, respeitando a ordem de entrega.
  */
  procedure formar_pallet_ordem_entrega
  (
    p_romaneio       in number,
    p_num_palet      in out number,
    p_nummaxpalet    in number,
    p_calc_num_palet in varchar2
  ) is
  
    v_peso_max                number;
    v_produtosemclassificacao number;
    v_tipoporta               number;
    v_msg                     t_message;
  begin
    begin
      select v.lotacao
        into v_peso_max
        from romaneiopai rp, veiculo v
       where v.placa = rp.placa
         and rp.idromaneio = p_romaneio;
    exception
      when no_data_found then
        v_msg := t_message('Peso não cadastrado para o veiculo do Romaneio de ID: {0}');
        v_msg.addParam(p_romaneio);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if not gerarPaletPorClassificacao(p_romaneio) then
      criarPallet(p_romaneio, 'N', p_num_palet, p_nummaxpalet,
                  p_calc_num_palet, v_peso_max, 0);
    
      criarPallet(p_romaneio, 'S', p_num_palet, p_nummaxpalet,
                  p_calc_num_palet, v_peso_max, 0);
    else
      select count(*)
        into v_produtosemclassificacao
        from nfromaneio nfr, nfdet n, produto p
       where nfr.idromaneio = p_romaneio
         and n.nf = nfr.idnotafiscal
         and p.idproduto = n.idproduto
         and p.idclassificacaomat is null;
    
      if (v_produtosemclassificacao > 0) then
        v_msg := t_message('Existem produtos no romaneio que não possuem cadastro de classificação do material.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select v.tipoporta
        into v_tipoporta
        from romaneiopai r, veiculo v
       where r.idromaneio = p_romaneio
         and r.placa = v.placa;
    
      if (v_tipoporta = 0) then
        insert into gtt_classificacaomaterial
          select id, rownum ordem
            from (select cm.id
                     from classificacaomaterial cm
                    order by cm.ordem);
      else
        insert into gtt_classificacaomaterial
          select id, rownum ordem
            from (select cm.id, rownum sequencia
                     from classificacaomaterial cm
                    order by cm.ordem)
           where mod(sequencia, 2) = 1;
      
        insert into gtt_classificacaomaterial
          select id,
                 (select (count(*))
                     from gtt_classificacaomaterial) + rownum
            from (select cm.id, rownum sequencia
                     from classificacaomaterial cm
                    order by cm.ordem desc)
           where mod(sequencia, 2) = 0;
      end if;
    
      for c_class in (select g.idclassificacao
                        from gtt_classificacaomaterial g
                       where g.idclassificacao in
                             (select distinct p.idclassificacaomat
                                from nfromaneio nfr, nfdet n, produto p
                               where nfr.idromaneio = p_romaneio
                                 and n.nf = nfr.idnotafiscal
                                 and p.idproduto = n.idproduto))
      loop
        criarPallet(p_romaneio, c_normal, p_num_palet, p_nummaxpalet,
                    p_calc_num_palet, v_peso_max, c_class.idclassificacao);
      
        criarPallet(p_romaneio, C_SIM, p_num_palet, p_nummaxpalet,
                    p_calc_num_palet, v_peso_max, c_class.idclassificacao);
      end loop;
    end if;
  
  end;

  /*
   * verifica a restricao de picking para os produtos do romaneio
   * verifica se os produtos possuem qtde de picking maior do que a permitida por depositante
  */
  procedure verificar_restricao_picking(p_romaneio in number) is
    cursor c_pk is
      select p.idproduto, p.codigointerno, p.descr produto,
             e.razaosocial depositante, pd.qtdemaxpicking,
             count(pl.idproduto)
        from produtolocal pl, local l, produto p, entidade e, depositante d,
             setor s, tiposetor ts, produtodepositante pd,
             (select distinct idproduto, rp.idarmazem, n.iddepositante
                 from romaneiopai rp, romaneio r, nfromaneio nr, notafiscal n
                where r.idromaneio = rp.idromaneio
                  and nr.idromaneio = rp.idromaneio
                  and n.idnotafiscal = nr.idnotafiscal
                  and rp.idromaneio = p_romaneio) rp
       where d.usapicking = 'S'
         and d.identidade = e.identidade
         and e.identidade = pl.identidade
         and p.idproduto = pl.idproduto
         and nvl(l.ativo, 'N') = 'S'
         and l.idsetor = s.idsetor
         and ts.idtiposetor = s.idtiposetor
         and ts.normal = 'S'
         and l.idlocal = pl.idlocal
         and l.idarmazem = pl.idarmazem
         and rp.idproduto = pl.idproduto
         and rp.idarmazem = pl.idarmazem
         and rp.iddepositante = e.identidade
         and pd.identidade = rp.iddepositante
         and pd.idproduto = rp.idproduto
       group by pl.identidade, e.razaosocial, p.idproduto, p.codigointerno,
                p.descr, pd.qtdemaxpicking
      having count(pl.idproduto) > decode(nvl(pd.qtdemaxpicking, 0), 0, 9999999, pd.qtdemaxpicking);
  
    r_pk   c_pk%rowtype;
    v_erro varchar2(2000) := null;
    v_msg  t_message;
  begin
    open c_pk;
    fetch c_pk
      into r_pk;
  
    while c_pk%found
    loop
      if v_erro is null then
        v_erro := r_pk.codigointerno || ' - ' || r_pk.produto || chr(13);
      else
        v_erro := v_erro || r_pk.codigointerno || ' - ' || r_pk.produto ||
                  chr(13);
      end if;
      fetch c_pk
        into r_pk;
    end loop;
  
    close c_pk;
    if v_erro is not null then
      v_msg := t_message('Erro na geracao do Romaneio.' || chr(13) ||
                         'Qtde de picking maior que a permitida pelo depositante.' ||
                         chr(13) || 'Qtde de PK: {0}' || ' - {1}' ||
                         chr(13) || 'foram encontrado(s) os produto(s): ' ||
                         chr(13) || '{2}');
      v_msg.addParam(r_pk.qtdemaxpicking);
      v_msg.addParam(r_pk.depositante);
      v_msg.addParam(v_erro);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  /*
   * Distribui o peso entre os palets
  */
  procedure distribuir_peso_veiculo
  (
    p_romaneio  in number,
    p_recursivo in boolean,
    p_commit    in varchar2
  ) is
    cursor c_peso_palet(p_romaneio in number) is
      select decode(mod(pl.idpalet, 2), 0, c_par, c_impar) lado,
             sum(e.pesobruto * pl.qtde) peso
        from produtopalet pl, embalagem e
       where e.barra = pl.barra
         and e.idproduto = pl.idproduto
         and pl.idromaneio = p_romaneio
       group by decode(mod(pl.idpalet, 2), 0, c_par, c_impar);
  
    cursor c_palet(p_romaneio in number) is
      select pl.idpalet, sum(e.pesobruto * pl.qtde) peso
        from produtopalet pl, embalagem e
       where e.barra = pl.barra
         and e.idproduto = pl.idproduto
         and pl.idromaneio = p_romaneio
       group by pl.idpalet;
  
    v_peso_dir          number;
    v_peso_esq          number;
    v_peso              c_peso_palet%rowtype;
    v_palet_equilibrado boolean;
    v_palet             c_palet%rowtype;
    v_palet_esq         c_palet%rowtype;
    v_lado              char(1);
    v_dif               number;
    v_dif1              number;
    v_perc              number;
    v_perc1             number;
  begin
    -- abre as informacoes de peso totalizadas por lado....
    if c_peso_palet%isopen then
      close c_peso_palet;
    end if;
    open c_peso_palet(p_romaneio);
    fetch c_peso_palet
      into v_peso;
    while c_peso_palet%found
    loop
      if v_peso.lado = C_PAR then
        v_peso_dir := v_peso.peso;
      else
        v_peso_esq := v_peso.peso;
      end if;
      fetch c_peso_palet
        into v_peso;
    end loop;
    -- se tiver muita diferenca entre os lados, inicia o processo de troca de palets
    if (v_peso_esq > (v_peso_dir + (v_peso_dir * c_perc_tolerancia)))
       or (v_peso_dir > (v_peso_esq + (v_peso_esq * c_perc_tolerancia))) then
      if v_peso_esq > v_peso_dir then
        v_lado := C_ESQUERDA;
        v_dif  := v_peso_esq - v_peso_dir;
        v_perc := (100 * v_dif) / v_peso_esq;
      else
        v_lado := C_DIREITA;
        v_dif  := v_peso_dir - v_peso_esq;
        v_perc := (100 * v_dif) / v_peso_dir;
      end if;
      if c_palet%isopen then
        close c_palet;
      end if;
      open c_palet(p_romaneio);
      fetch c_palet
        into v_palet;
      v_palet_equilibrado := false;
      while (c_palet%found)
            and (v_palet_equilibrado = false)
      loop
        if mod(v_palet.idpalet, 2) = 0 then
          -- palet do lado direito, iniciar o algoritimo de troca
          if ((v_palet_esq.peso > v_palet.peso) and (v_lado = C_ESQUERDA))
             or
             ((v_palet_esq.peso < v_palet.peso) and (v_lado = C_DIREITA)) then
            /* se o lado esquerdo for o mais pesado e o palet esquerdo for mais pesado que o do lado direito ou
               o lado direito for o mais pesado e o palet do lado direito for mais pesado que o do lado esquerdo...
               entao inicia-se a troca
            */
            v_dif1 := (v_peso_esq - v_palet_esq.peso + v_palet.peso) -
                      (v_peso_dir - v_palet.peso + v_palet_esq.peso);
            if v_dif1 < 0 then
              v_dif1 := v_dif1 * -1;
            end if;
            if (v_peso_esq - v_palet_esq.peso + v_palet.peso) >
               (v_peso_dir - v_palet.peso + v_palet_esq.peso) then
              v_perc1 := (100 * v_dif1) /
                         (v_peso_esq - v_palet_esq.peso + v_palet.peso);
            else
              v_perc1 := (100 * v_dif1) /
                         (v_peso_dir - v_palet.peso + v_palet_esq.peso);
            end if;
            if v_perc1 < v_perc then
              v_peso_esq := v_peso_esq - v_palet_esq.peso + v_palet.peso;
              v_peso_dir := v_peso_dir - v_palet.peso + v_palet_esq.peso;
              -- rotina que faz a alteracao dos palets nas tabelas
              update palet
                 set idpalet = v_palet_esq.idpalet
               where idromaneio = p_romaneio
                 and idpalet = v_palet.idpalet; -- troca o numero do palet direito com o palet esquerdo
              update palet
                 set idpalet = v_palet.idpalet
               where idromaneio = p_romaneio
                 and idpalet = v_palet_esq.idpalet; -- troca o numero do palet esquerdo com o palet direito
            
              v_dif := v_peso_esq - v_peso_dir;
              if v_dif < 0 then
                v_dif := v_dif * -1;
              end if;
              if v_peso_esq > v_peso_dir then
                v_perc1 := (100 * v_dif) / v_peso_esq;
              else
                v_perc1 := (100 * v_dif) / v_peso_dir;
              end if;
            
              -- verifica se o caminhao ja esta equilibrado
              if not ((v_peso_esq >
                  (v_peso_dir + (v_peso_dir * c_perc_tolerancia))) or
                  (v_peso_dir >
                  (v_peso_esq + (v_peso_esq * c_perc_tolerancia)))) then
                v_palet_equilibrado := true;
              end if;
            end if;
          end if;
        else
          v_palet_esq := v_palet;
        end if;
        fetch c_palet
          into v_palet;
      end loop;
      if (c_palet%notfound)
         and (v_palet_equilibrado = false)
         and (p_recursivo = true) then
        distribuir_peso_veiculo(p_romaneio, false, 'N');
      end if;
    end if;
    if p_commit = 'S' then
      commit;
    end if;
  end;

  /*
   * Responsavel por ordenar a separacao dos palets
  */
  procedure ordenar_palet_separacao(p_romaneio in number) is
    cursor c_local_c
    (
      p_romaneio in number,
      p_palet    in number,
      p_rua      in local.rua%type
    ) is
      select distinct ps.idarmazem, ps.idlocal, ps.idproduto, ps.barra
        from paletseparacao ps, local l
       where l.idlocal = ps.idlocal
         and l.idarmazem = ps.idarmazem
         and lpad(l.rua, 5, ' ') = p_rua
         and ps.idromaneio = p_romaneio
       order by ps.idlocal;
  
    cursor c_local_d
    (
      p_romaneio in number,
      p_palet    in number,
      p_rua      in local.rua%type
    ) is
      select distinct ps.idarmazem, ps.idlocal, ps.idproduto, ps.barra
        from paletseparacao ps, local l
       where l.idlocal = ps.idlocal
         and l.idarmazem = ps.idarmazem
         and lpad(l.rua, 5, ' ') = p_rua
         and ps.idromaneio = p_romaneio
       order by ps.idlocal desc;
  
    r_local     c_local_c%rowtype;
    v_palet     number;
    v_ordemsep  number;
    v_crescente boolean;
  begin
    v_palet := 0;
    -- verifica as ruas q vao ser separadas.
    for c_roma in (select ps.idpalet, lpad(l.rua, 5, ' ') rua
                     from paletseparacao ps, local l
                    where l.idlocal = ps.idlocal
                      and nvl(l.ativo, 'N') = 'S'
                      and l.idarmazem = ps.idarmazem
                      and ps.idromaneio = p_romaneio
                    group by ps.idpalet, lpad(l.rua, 5, ' ')
                    order by ps.idpalet, lpad(l.rua, 5, ' '))
    loop
      if (v_palet <> c_roma.idpalet) then
        v_crescente := true;
        v_ordemsep  := 1;
        v_palet     := c_roma.idpalet;
      end if;
    
      if v_crescente then
        v_crescente := false;
      
        open c_local_c(p_romaneio, c_roma.idpalet, c_roma.rua);
        fetch c_local_c
          into r_local;
      
        while c_local_c%found
        loop
          update paletseparacao
             set ordem = v_ordemsep
           where idlocal = r_local.idlocal
             and idarmazem = r_local.idarmazem
             and idpalet = v_palet
             and idromaneio = p_romaneio;
        
          update paletseparacaocliente
             set ordem = v_ordemsep
           where idlocal = r_local.idlocal
             and idarmazem = r_local.idarmazem
             and idpalet = v_palet
             and idromaneio = p_romaneio;
        
          v_ordemsep := v_ordemsep + 1;
        
          fetch c_local_c
            into r_local;
        end loop;
      
        close c_local_c;
      else
        v_crescente := true;
      
        open c_local_d(p_romaneio, c_roma.idpalet, c_roma.rua);
        fetch c_local_d
          into r_local;
      
        while c_local_d%found
        loop
          update paletseparacao
             set ordem = v_ordemsep
           where idromaneio = p_romaneio
             and idpalet = v_palet
             and idarmazem = r_local.idarmazem
             and idlocal = r_local.idlocal;
        
          update paletseparacaocliente
             set ordem = v_ordemsep
           where idromaneio = p_romaneio
             and idpalet = v_palet
             and idarmazem = r_local.idarmazem
             and idlocal = r_local.idlocal;
        
          v_ordemsep := v_ordemsep + 1;
        
          fetch c_local_d
            into r_local;
        end loop;
      
        close c_local_d;
      end if;
    end loop;
  end;

  -- Refactored procedure validarSeparacaoProduto 
  procedure validarSeparacaoProduto
  (
    p_idromaneio    in number,
    p_idpalet       in number,
    p_iddepositante in number,
    p_identidade    in number,
    p_idproduto     in number,
    p_barra         in embalagem.barra%type,
    p_estado        in lote.estado%type,
    p_qtde          in number,
    p_totalsep      in number,
    p_idarmazem     in number,
    p_corte         in out boolean
  ) is
  begin
    if p_totalsep = p_qtde then
      update produtopalet
         set gerado = 'S'
       where idromaneio = p_idromaneio
         and idpalet = p_idpalet
         and iddepositante = p_iddepositante
         and identidade = p_identidade
         and idproduto = p_idproduto
         and barra = p_barra;
    else
      -- insere na tabela de corte de romaneio
      p_corte := true;
      inserir_corte_romaneio(p_idromaneio, p_idpalet, p_idarmazem,
                             p_iddepositante, p_idproduto, p_barra, p_qtde,
                             p_estado,
                             'TOTAL SEPARADO DIFERENTE DO TOTAL PEDIDO');
      -- zera a qtde atendida na nfdet e nfdetimpressao
      ZerarQtdeAtendidaNF(p_idromaneio, p_idproduto, p_estado);
    end if;
  end validarSeparacaoProduto;

  /*
   * Cria os palets para separacao
  */
  procedure criar_pallet_separacao
  (
    p_romaneio in out romaneiopai%rowtype,
    p_usuario  in number,
    p_estado   in lote.estado%type,
    p_commit   in varchar2 := c_sim
  ) is
    v_totalseparado number := 0;
    v_corte         boolean := false;
    v_separacao     number;
    v_qtderestante  number := 0;
    v_qtde          number;
    v_idinventario  number;
    v_qtdePaletSep  number;
    v_msg           t_message;
  begin
    reabastecer_picking(p_romaneio.idromaneio, p_usuario, p_estado, 'N');
  
    insert into gtt_separacaoespecifica
      (idromaneio, iddepositante, ident_entrega, idproduto, idlote, qtde,
       idarmazem, idlocal)
      select nfr.idromaneio, l.iddepositante, nf.ident_entrega, l.idproduto,
             l.idlote, se.qtde, se.idarmazem, se.idlocal
        from nfromaneio nfr, notafiscal nf, separacaoespecifica se, lote l
       where l.idlote = se.idlote
         and se.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio.idromaneio;
  
    --Verifica se existe separação específica de lotes bloqueados
    if sql%rowcount > 0 then
      for c_lote_esp in (select l.idlote, nf.idnotafiscal,
                                decode(l.liberado, 'S', 1, 0) liberado
                           from nfromaneio nfr, notafiscal nf,
                                separacaoespecifica se, lote l
                          where l.idlote = se.idlote
                            and se.idnotafiscal = nf.idnotafiscal
                            and nf.idnotafiscal = nfr.idnotafiscal
                            and nf.idinventario is null
                            and nfr.idromaneio = p_romaneio.idromaneio)
      loop
        if c_lote_esp.liberado = 0 then
          v_msg := t_message('O Romaneio não pode ser formado devido ao lote ' ||
                             '{0} que contém separação específica para a nota fiscal id: ' ||
                             '{1} encontrar-se bloqueado. Operação Cancelada.');
          v_msg.addParam(c_lote_esp.idlote);
          v_msg.addParam(c_lote_esp.idnotafiscal);
          raise_application_error(-20001, v_msg.formatMessage);
        
        end if;
      end loop;
    end if;
  
    begin
      select nvl(idinventario, 0)
        into v_idinventario
        from nfromaneio nfr, notafiscal nf
       where nfr.idromaneio = p_romaneio.idromaneio
         and nf.idnotafiscal = nfr.idnotafiscal;
    exception
      when too_many_rows then
        v_idinventario := 0;
    end;
  
    for c_prod in (select rp.idarmazem, pp.idpalet, pp.identidade,
                          pp.idproduto, pp.barra, pp.iddepositante,
                          pp.qtde * e.fatorconversao qtde, e.fatorconversao
                     from romaneiopai rp, produtopalet pp, embalagem e
                    where e.barra = pp.barra
                      and e.idproduto = pp.idproduto
                      and pp.idromaneio = rp.idromaneio
                      and rp.idromaneio = p_romaneio.idromaneio
                    order by pp.idpalet, pp.iddepositante, pp.identidade,
                             pp.idproduto)
    loop
      v_qtderestante  := c_prod.qtde;
      v_totalseparado := 0;
    
      -- localiza as separacao especifica co produto
      for c_sepespecifica in (select idlote, qtde,
                                     decode(v_idinventario, 0, null,
                                             idarmazem) idarmazem,
                                     decode(v_idinventario, 0, null, idlocal) idlocal
                                from gtt_separacaoespecifica
                               where idromaneio = p_romaneio.idromaneio
                                 and iddepositante = c_prod.iddepositante
                                 and ident_entrega = c_prod.identidade
                                 and idproduto = c_prod.idproduto
                                 and qtde > 0)
      loop
        if v_qtderestante > c_sepespecifica.qtde then
          v_qtde := c_sepespecifica.qtde;
        else
          v_qtde := v_qtderestante;
        end if;
      
        v_qtdePaletSep := preencher_pallet_separacao(p_romaneio.idromaneio,
                                                     c_prod.idpalet,
                                                     c_prod.idarmazem,
                                                     c_prod.iddepositante,
                                                     c_prod.idproduto,
                                                     p_estado, v_qtde,
                                                     c_prod.barra,
                                                     c_prod.fatorconversao,
                                                     p_usuario,
                                                     c_sepespecifica.idlote,
                                                     c_prod.identidade,
                                                     p_romaneio.reentrega,
                                                     c_sepespecifica.idlocal);
      
        update gtt_separacaoespecifica
           set qtde = qtde - v_qtdePaletSep
         where idromaneio = p_romaneio.idromaneio
           and iddepositante = c_prod.iddepositante
           and ident_entrega = c_prod.identidade
           and idproduto = c_prod.idproduto
           and idlote = c_sepespecifica.idlote
           and nvl(idlocal, 0) = nvl(c_sepespecifica.idlocal, 0);
      
        v_totalseparado := v_totalseparado + v_qtdePaletSep;
      
        v_qtderestante := v_qtderestante - v_qtdePaletSep;
      
        exit when v_qtderestante = 0;
      end loop;
    
      if v_qtderestante > 0
         and v_idinventario = 0 then
        v_totalseparado := v_totalseparado +
                           preencher_pallet_separacao(p_romaneio.idromaneio,
                                                      c_prod.idpalet,
                                                      c_prod.idarmazem,
                                                      c_prod.iddepositante,
                                                      c_prod.idproduto,
                                                      p_estado,
                                                      v_qtderestante,
                                                      c_prod.barra,
                                                      c_prod.fatorconversao,
                                                      p_usuario, null,
                                                      c_prod.identidade,
                                                      p_romaneio.reentrega);
      
      end if;
    
      validarSeparacaoProduto(p_romaneio.idromaneio, c_prod.idpalet,
                              c_prod.iddepositante, c_prod.identidade,
                              c_prod.idproduto, c_prod.barra, p_estado,
                              c_prod.qtde, v_totalseparado, c_prod.idarmazem,
                              v_corte);
    end loop;
  
    --Insere na tabela de Log de Romaneio com corte
    InsereLogRomaneioCorte(p_romaneio.idromaneio);
  
    -- Exclui as pendencias geradas dos produtos que foram cortados
    --e exclui as informacoes do palet para o produto
    excluir_prod_cortado_romaneio(p_romaneio.idromaneio, p_usuario);
  
    -- Verifica se e necessario a distribuicao da qtde de produto
    -- no pallet de separacao Ex. 1,5cx = 1 caixa e 2 dp
    recalcularQtdePaletSeparacao(p_romaneio.idromaneio);
  
    RecalculaPaletSepCliente(p_romaneio.idromaneio);
  
    -- vincula os volumes cuja os pais (lote) foram adicionados no romaneio
    VincularVolumeNoRomaneio(p_romaneio.idromaneio, p_usuario);
  
    -- ordena o romaneio de separacao colocando uma rua crescente e proxima de-crescente
    ordenar_palet_separacao(p_romaneio.idromaneio);
  
    -- atualiza a tabela paletseparacao por cliente
    --RecalculaPaletSepCliente(p_romaneio.idromaneio);
  
    select count(idromaneio) cont
      into v_separacao
      from paletseparacao
     where idromaneio = p_romaneio.idromaneio;
  
    if v_corte
       or (v_separacao = 0) then
      -- informa que o romaneio foi formado com erro.
      p_romaneio.gerado := c_sim;
      p_romaneio.erro   := c_sim;
    else
      -- informa que o romaneio foi formado.
      p_romaneio.gerado := c_sim;
      p_romaneio.erro   := c_nao;
    end if;
  
    AtualizarRomaneio(p_romaneio);
  
    if p_commit = 'S' then
      commit;
    end if;
  end;

  procedure recalcularQtdePaletSeparacao(p_romaneio in number) is
    cursor c_lote is
      select idlote, qtde
        from gtt_estoque
       order by qtde desc;
  
    v_qtde number;
  
    r_lote                c_lote%rowtype;
    v_qtdeunitario        number;
    v_embalagemencontrada boolean;
    v_qtdeembalagem       number;
    v_qtdeutilizada       number;
    v_qtderestanteLote    number;
    v_qtdecx              number;
    v_qtdetotalprod       number;
  
    procedure prepararPaletSeparacao
    (
      p_romaneio  in number,
      p_idpalet   in number,
      p_idarmazem in number,
      p_idlocal   in varchar2,
      p_idproduto in number
    ) is
    begin
      delete from gtt_estoque;
    
      insert into gtt_estoque
        (idlote, qtde)
        select idlote, qtdeunit
          from paletseparacao
         where idromaneio = p_romaneio
           and idpalet = p_idpalet
           and idarmazem = p_idarmazem
           and idlocal = p_idlocal
           and idproduto = p_idproduto;
    
      apaga_palet_separacao(p_romaneio, p_idpalet, p_idarmazem, p_idlocal,
                            p_idproduto);
    end;
  begin
    for c_paletsep in (select ps.idpalet, ps.idarmazem, ps.idlocal,
                              ps.idproduto, sum(qtdeunit) qtde
                         from paletseparacao ps, produto p
                        where p.otimizaseparacao = 'S'
                          and p.fracionado = 'N'
                          and p.idproduto = ps.idproduto
                          and ps.idromaneio = p_romaneio
                          and ps.separado = 'N'
                        group by ps.idpalet, ps.idarmazem, ps.idlocal,
                                 ps.idproduto)
    loop
      v_qtde := c_paletsep.qtde;
    
      prepararPaletSeparacao(p_romaneio, c_paletsep.idpalet,
                             c_paletsep.idarmazem, c_paletsep.idlocal,
                             c_paletsep.idproduto);
    
      getQtdeEmbalagem(c_paletsep.idproduto, null, v_qtde, v_qtdeembalagem,
                       v_embalagemencontrada);
      v_qtdeunitario  := v_qtdeembalagem * r_embalagem.fatorconversao;
      v_qtdetotalprod := v_qtdeunitario;
    
      open c_lote;
      fetch c_lote
        into r_lote;
      v_qtderestanteLote := r_lote.qtde;
    
      while c_lote%found
      loop
        if v_qtderestanteLote > v_qtdeunitario then
          v_qtdeutilizada := v_qtdeunitario;
        else
          v_qtdeutilizada := v_qtderestanteLote;
        end if;
      
        v_qtdecx := round(v_qtdeutilizada / r_embalagem.fatorconversao, 6);
      
        if v_qtdeutilizada > v_qtdetotalprod then
          v_qtdecx := round(v_qtdetotalprod / r_embalagem.fatorconversao, 6);
        end if;
      
        v_qtdeunitario     := v_qtdeunitario - v_qtdeutilizada;
        v_qtde             := v_qtde - v_qtdeutilizada;
        v_qtderestanteLote := v_qtderestanteLote - v_qtdeutilizada;
        v_qtdetotalprod    := v_qtdetotalprod -
                              (v_qtdecx * r_embalagem.fatorconversao);
        v_qtdeembalagem    := v_qtdeembalagem - v_qtdecx;
      
        if (v_qtdeunitario = 0)
           and (v_qtdeembalagem > 0) then
          v_qtdecx := v_qtdecx + v_qtdeembalagem;
        end if;
      
        inserir_pallet_separacao(p_romaneio, c_paletsep.idpalet,
                                 c_paletsep.idarmazem, c_paletsep.idlocal,
                                 r_lote.idlote, c_paletsep.idproduto,
                                 r_embalagem.barra, v_qtdecx,
                                 v_qtdeutilizada);
      
        if v_qtde > 0
           and v_qtdeunitario = 0 then
          getQtdeEmbalagem(c_paletsep.idproduto, null, v_qtde,
                           v_qtdeembalagem, v_embalagemencontrada);
          v_qtdeunitario  := v_qtdeembalagem * r_embalagem.fatorconversao;
          v_qtdetotalprod := v_qtdeunitario;
        end if;
        if v_qtderestanteLote = 0 then
          fetch c_lote
            into r_lote;
          v_qtderestanteLote := r_lote.qtde;
        end if;
      end loop;
      close c_lote;
    end loop;
  end;

  /*
   * Rotina responsavel por localizar os enderecos disponiveis
   * no estoque e inserir na tabela paletseparacao ou separacaoespecifica
  */
  function preencher_pallet_separacao
  (
    p_romaneio       in number,
    p_pallet         in number,
    p_armazem        in number,
    p_depositante    in number,
    p_produto        in number,
    p_estado         in varchar2,
    p_qtde           in number,
    p_barra          in embalagem.barra%type,
    p_fatorconversao in number,
    p_usuario        in number,
    p_idlote         in number,
    p_identidade     in number,
    p_reentrega      in char,
    p_idlocal        in local.idlocal%type := ''
  ) return number is
  
    cursor c_estoque
    (
      p_idarmazem     in number,
      p_iddepositante in number,
      p_idproduto     in number,
      p_estado        in lote.estado%type,
      p_idlote        in number,
      p_reentrega     in char,
      p_idinventario  in number,
      p_idlocal       in local.idlocal%type
    ) is
      select idlocal, dtvenc, idlote, idproduto, barra, fc, disp
        from (select ll.idlocal, l.dtvenc, ll.idlote, l.idproduto, l.barra,
                      e.fatorconversao fc,
                      (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
                       (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) disp, rua,
                      predio, andar, apartamento, l.dtentrada
                 from lotelocal ll, lote l, local lo, embalagem e,
                      depositante d, setor s, regiaoarmazenagem ra
                where ra.idregiao = lo.idregiao
                  and nvl(s.expedicao, 'S') = 'S'
                  and s.idsetor(+) = lo.idsetor
                  and d.identidade = l.iddepositante
                  and e.idproduto = l.idproduto
                  and e.barra = l.barra
                  and ((lo.picking like
                      decode(p_idlote, null,
                               decode(d.usapicking, 'S', 'S', '%'), '%')) or
                      (p_estado in ('D', 'T')))
                  and lo.ativo = 'S'
                  and lo.tipo in (0, 1, 2)
                  and lo.buffer = 'N'
                  and lo.idarmazem = ll.idarmazem
                  and lo.idlocal = ll.idlocal
                  and ((l.idlote = p_idlote) or (p_idlote is null))
                  and l.estado = p_estado
                  and l.idproduto = p_idproduto
                  and l.iddepositante = p_iddepositante
                  and l.tipolote = 'L'
                  and l.liberado = 'S'
                  and l.idlote = ll.idlote
                  and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
                      (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0
                  and ll.idarmazem = p_idarmazem
                  and (((not exists
                       (select 1
                            from tiporecebimento tr, setorrecebimento sr
                           where tr.classificacao = 'R'
                             and sr.idtiporecebimento = tr.idtiporecebimento
                             and sr.idsetor = lo.idsetor)) and
                      (p_reentrega = 'N')) or (p_reentrega = 'S'))
                  and not exists (select 1
                         from receitaestojamentolote rel
                        where rel.idlote = l.idlote)
                  and not exists
                (select 1
                         from conferenciaentradadet cd
                        where (idlotenf, idconferenciaentrada, idcontagem) in
                              (select idlotenf, idconferenciaentrada, idcontagem
                                 from compmontagem)
                          and cd.idlote = ll.idlote
                          and nvl(ignorada, 'N') = 'N')
                  and p_idinventario = 0
                     
                  and not exists
                (select 1
                         from configuracaoonda co, pickingpicktolightonda ptl,
                              produtolocal pl
                        where pl.idlocal = p_idlocal
                          and pl.idarmazem = l.idarmazem
                          and pl.idproduto = l.idproduto
                          and pl.identidade = l.iddepositante
                          and pl.idprodutolocal = ptl.idprodutolocal
                          and ptl.idconfiguracaoonda = co.idconfiguracaoonda
                          and co.exclusivopicktolight = 1)
               
               union all
               select ll.idlocal, l.dtvenc, ll.idlote, l.idproduto, l.barra,
                      e.fatorconversao fc,
                      (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
                       (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) disp, rua,
                      predio, andar, apartamento, l.dtentrada
                 from lotelocal ll, lote l, local lo, embalagem e,
                      depositante d, setor s, regiaoarmazenagem ra
                where ra.idregiao = lo.idregiao
                  and s.idsetor(+) = lo.idsetor
                  and d.identidade = l.iddepositante
                  and e.idproduto = l.idproduto
                  and e.barra = l.barra
                  and lo.tipo in (0, 1, 2)
                  and lo.buffer = 'N'
                  and lo.idarmazem = ll.idarmazem
                  and lo.idlocal = ll.idlocal
                  and ((l.idlote = p_idlote) or (p_idlote is null))
                  and ll.idlocal = p_idlocal
                  and l.estado = p_estado
                  and l.idproduto = p_idproduto
                  and l.iddepositante = p_iddepositante
                  and l.tipolote = 'L'
                  and l.idlote = ll.idlote
                  and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
                      (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0
                  and ll.idarmazem = p_idarmazem
                  and p_idinventario > 0)
       order by nvl(dtvenc, sysdate), dtentrada, idlote, rua, predio, andar,
                apartamento;
  
    r_estoque        c_estoque%rowtype;
    v_qtd_sep        number;
    v_restante       number;
    v_tot_sep        number;
    v_disponivellote number;
    v_sepesp         number;
    v_idinventario   number;
  
    function retornarQtdeSepEspecifica
    (
      p_idromaneio in number,
      p_idarmazem  in number,
      p_idlocal    in local.idlocal%type,
      p_idlote     in number
    ) return number is
      v_sepesp number;
    
    begin
      begin
        select sum(se.qtde)
          into v_sepesp
          from separacaoespecifica se
         where se.idarmazem = p_idarmazem
           and se.idlocal = p_idlocal
           and se.idlote = p_idlote
           and exists
         (select nf.idnotafiscal, nf.iddepositante, nf.estado
                  from notafiscal nf
                 where nf.estoqueverificado = 'S'
                   and nf.tipo = 'S'
                   and nf.reentrega = 'N'
                   and nf.statusnf in ('N', 'I', 'C')
                   and nf.idnotafiscal = se.idnotafiscal
                   and not exists
                 (select 1
                          from nfromaneio nfr, romaneiopai rp
                         where rp.gerado = 'S'
                           and rp.processado = 'N'
                           and nfr.idromaneio = rp.idromaneio
                           and nfr.idnotafiscal = nf.idnotafiscal
                        union
                        select 1
                          from nfromaneio nfr
                         where idromaneio = p_idromaneio
                           and nfr.idnotafiscal = nf.idnotafiscal
                        union
                        select idpedidopai
                          from notafiscal nfp, nfromaneio nfr, romaneiopai rp
                         where rp.gerado = 'S'
                           and rp.processado = 'N'
                           and rp.idromaneio = nfr.idromaneio
                           and nfr.idnotafiscal = nfp.idnotafiscal
                           and nfp.idpedidopai = nf.idnotafiscal));
      exception
        when no_data_found then
          v_sepesp := 0;
      end;
      return v_sepesp;
    end;
  begin
    v_tot_sep  := 0;
    v_restante := p_qtde;
  
    begin
      select nvl(idinventario, 0)
        into v_idinventario
        from nfromaneio nfr, notafiscal nf
       where nfr.idromaneio = p_romaneio
         and nf.idnotafiscal = nfr.idnotafiscal;
    exception
      when too_many_rows then
        v_idinventario := 0;
    end;
  
    -- abre o cursor do estoque
    open c_estoque(p_armazem, p_depositante, p_produto, p_estado, p_idlote,
                   p_reentrega, v_idinventario, p_idlocal);
    fetch c_estoque
      into r_estoque;
  
    while (c_estoque%found)
          and (v_tot_sep < p_qtde)
    loop
      -- pegando a quantidade em separação especifica
      v_sepesp := retornarQtdeSepEspecifica(p_romaneio, p_armazem,
                                            r_estoque.idlocal,
                                            r_estoque.idlote);
    
      -- subtraindo o que está em separação especifica da quantidade disponível do lote
      r_estoque.disp := r_estoque.disp - nvl(v_sepesp, 0);
    
      if v_idinventario = 0 then
        v_disponivellote := pk_lote.RetornarQtdeDisponivel(r_estoque.idlote);
      
        if r_estoque.disp > v_disponivellote then
          r_estoque.disp := v_disponivellote;
        end if;
      end if;
    
      if r_estoque.disp > 0 then
        if v_restante <= r_estoque.disp then
          v_qtd_sep := v_restante;
        else
          v_qtd_sep := r_estoque.disp;
        end if;
        -- coloca o lote para separacao
        inserir_pallet_separacao(p_romaneio, p_pallet, p_armazem,
                                 r_estoque.idlocal, r_estoque.idlote,
                                 r_estoque.idproduto, p_barra,
                                 v_qtd_sep / p_fatorconversao, v_qtd_sep);
      
        -- inserir_pallet_separacaocliente  
        inserir_pallet_separacao_cli(p_romaneio, p_pallet, p_armazem,
                                     r_estoque.idlocal, r_estoque.idproduto,
                                     p_barra, p_identidade,
                                     v_qtd_sep / p_fatorconversao);
      
        -- atualiza a pendencia de estoque.
        pk_estoque.incluir_pendencia(p_armazem, r_estoque.idlocal,
                                     r_estoque.idlote, v_qtd_sep, p_usuario,
                                     'adicionado pendencia ref. romaneio ID: ' ||
                                      p_romaneio);
      
        v_tot_sep  := v_tot_sep + v_qtd_sep;
        v_restante := v_restante - v_qtd_sep;
      end if;
      fetch c_estoque
        into r_estoque;
    end loop;
  
    close c_estoque;
    return v_tot_sep;
  end;

  /*
   * Rotina responsavel por inserir a ordem de separacao por cliente (Separacao por Cliente)
  */
  procedure inserir_pallet_separacao_cli
  (
    p_romaneio in number,
    p_idpalet  in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_produto  in number,
    p_barra    in embalagem.barra%type,
    p_cliente  in number,
    p_qtde     in number,
    p_ordem    in number := null
  ) is
  begin
    --     ordem,        idlote,       liberado,       impresso  
  
    insert into paletseparacaocliente
      (idromaneio, idpalet, idarmazem, idlocal, identidade, idproduto,
       barra, qtde, ordem)
    values
      (p_romaneio, p_idpalet, p_armazem, p_local, p_cliente, p_produto,
       p_barra, round(p_qtde, 6), p_ordem);
  exception
    when dup_val_on_index then
      update paletseparacaocliente
         set qtde = qtde + round(p_qtde, 6)
       where idromaneio = p_romaneio
         and idpalet = p_idpalet
         and idarmazem = p_armazem
         and idlocal = p_local
         and idproduto = p_produto
         and barra = p_barra
         and identidade = p_cliente;
  end;

  /*
   * Rotina responsavel por inserir na tabela de palet separacao
  */
  procedure inserir_pallet_separacao
  (
    p_romaneio in number,
    p_idpalet  in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_lote     in number,
    p_produto  in number,
    p_barra    in embalagem.barra%type,
    p_qtde     in number,
    p_qtdeunit in number
  ) is
  begin
    insert into paletseparacao
      (idromaneio, idpalet, idarmazem, idlocal, idlote, qtde, qtdeunit,
       separado, idproduto, barra)
    values
      (p_romaneio, p_idpalet, p_armazem, p_local, p_lote, round(p_qtde, 6),
       round(p_qtdeunit, 6), c_normal, p_produto, p_barra);
  
    delete from paletseparacao
     where (qtde = 0 or qtdeunit = 0)
       and idromaneio = p_romaneio
       and idlote = p_lote
       and idpalet = p_idpalet;
  exception
    when dup_val_on_index then
      update paletseparacao
         set qtde     = qtde + round(p_qtde, 6),
             qtdeunit = qtdeunit + round(p_qtdeunit, 6)
       where idromaneio = p_romaneio
         and idpalet = p_idpalet
         and idarmazem = p_armazem
         and idlocal = p_local
         and idlote = p_lote
         and idproduto = p_produto
         and barra = p_barra;
    
      delete from paletseparacao
       where ((qtde = 0) or (qtdeunit = 0))
         and idromaneio = p_romaneio
         and idlote = p_lote
         and idpalet = p_idpalet;
  end;

  /*
   * Insere os cortes do romaneio
  */
  procedure inserir_corte_romaneio
  (
    p_romaneio   in number,
    p_pallet     in number,
    p_armazem    in number,
    p_entidade   in number,
    p_produto    in number,
    p_barra      in embalagem.barra%type,
    p_qtdepedido in number,
    p_estado     in lote.estado%type,
    p_motivo     in varchar2
  ) is
    v_estoque_pk number := 0;
    v_estoque_pl number := 0;
  begin
    -- carrega as informacoes de estoque para o produto
    begin
      select sum(decode(lo.picking, 'S', sum(ll.estoque), 0)) estoquepicking,
             sum(decode(lo.picking, 'N', sum(ll.estoque), 0)) estoquepulmao
        into v_estoque_pk, v_estoque_pl
        from lotelocal ll, lote l, local lo
       where lo.tipo in (0, 1, 2)
         and lo.idlocal = ll.idlocal
         and lo.idarmazem = ll.idarmazem
         and l.tipolote = 'L'
         and l.liberado = 'S'
         and l.estado = p_estado
         and l.iddepositante = p_entidade
         and l.idproduto = p_produto
         and l.idlote = ll.idlote
         and ll.idarmazem = p_armazem
       group by lo.picking;
    exception
      when no_data_found then
        v_estoque_pk := 0;
        v_estoque_pl := 0;
    end;
  
    -- insere os cortes de geracao
    insert into corteromaneio
      (idcorte, idromaneio, idpalet, identidade, idproduto, barra,
       datacorte, qtdepedido, qtdedisponivelpk, qtdedisponivelpl,
       motivocorte)
    values
      (seq_corteromaneio.nextval, p_romaneio, p_pallet, p_entidade,
       p_produto, p_barra, sysdate, p_qtdepedido, v_estoque_PK, v_estoque_pl,
       p_motivo);
  end;

  /*
   * Apaga os produtos que tiveram cortes no romaneio
  */
  procedure excluir_prod_cortado_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
    v_inventario number;
    v_msg        t_message;
  begin
    select count(*)
      into v_inventario
      from dual
     where exists (select 1
              from nfromaneio nfr, notafiscal nf
             where nf.idnotafiscal = nfr.idnotafiscal
               and nfr.idromaneio = p_romaneio
               and nf.idinventario is not null);
  
    for c in (select idarmazem, idlocal, idlote, idproduto,
                     sum(qtdeunit) qtde
                from paletseparacao
               where idromaneio = p_romaneio
                 and idlote in (select l.idlote
                                  from corteromaneio cr, lote l
                                 where l.idproduto = cr.idproduto
                                   and cr.idromaneio = p_romaneio)
               group by idarmazem, idlocal, idlote, idproduto)
    loop
      if v_inventario = 1 then
        v_msg := t_message('Nao foi encontrado o estado NF vinculada no romaneio com ID: {0}');
        v_msg.addParam(p_romaneio);
        raise_application_error(-20001, v_msg.formatMessage);
      end if;
    
      -- atualiza a pendencia de estoque.
      pk_estoque.retirar_pendencia(c.idarmazem, c.idlocal, c.idlote, c.qtde,
                                   p_usuario,
                                   'RETIRADA PENDENCIA EM FUNCAO DE CORTE NO ROMANEIO ID:  ' ||
                                    p_romaneio);
    
      -- apaga as informacoes da tab. de separacao
      delete from paletseparacao
       where idromaneio = p_romaneio
         and idlote = c.idlote;
    
      -- apaga as informacoes da tab. de produto do palet
      delete from produtopalet
       where idromaneio = p_romaneio
         and idproduto = c.idproduto;
    end loop;
  end;

  /*
   * Retorna o Estado de Lote que vai ser usado para a Geracao do Romaneio
  */
  function estado_notafiscal_romaneio(p_romaneio in number)
    return lote.estado%type is
    v_estado lote.estado%type;
    v_msg    t_message;
  begin
    select distinct nvl(nf.estado, 'N')
      into v_estado
      from romaneiopai rp, nfromaneio nr, notafiscal nf
     where nf.idnotafiscal = nr.idnotafiscal
       and nr.idromaneio = rp.idromaneio
       and rp.idromaneio = P_ROMANEIO;
    return v_estado;
  exception
    when no_data_found then
      v_msg := t_message('Nao foi encontrado o estado NF vinculada no romaneio com ID: {0}');
      v_msg.addParam(p_romaneio);
      raise_application_error(-20001, v_msg.formatMessage);
    when too_many_rows then
      v_msg := t_message('Erro ao Gerar os Palets Do Romaneio. Mais de Um Estado de Lote Definido. Operacao Cancelada');
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  /*
   * Insere os Produtos na tabela de informacoes de produtos no palet
  */
  procedure inserir_produto_palet
  (
    p_romaneio    in number,
    p_pallet      in number,
    p_depositante in number,
    p_cliente     in number,
    p_produto     in number,
    p_barra       in embalagem.barra%type,
    p_qtde        in number
  ) is
  begin
    insert into produtopalet
      (idromaneio, idpalet, iddepositante, identidade, idproduto, barra,
       qtde, liberado)
    values
      (p_romaneio, p_pallet, p_depositante, p_cliente, p_produto, p_barra,
       p_qtde, c_normal);
  exception
    when dup_val_on_index then
      update produtopalet
         set qtde = qtde + p_qtde
       where idromaneio = p_romaneio
         and idpalet = p_pallet
         and iddepositante = p_depositante
         and identidade = p_cliente
         and idproduto = p_produto
         and barra = p_barra;
  end;

  function ret_rotacliente(p_idcliente in number) return string is
    v_rota varchar(1000);
  begin
    select stragg(descr)
      into v_rota
      from (select r.descr
               from rotacliente c, rotas r
              where c.identidade = p_idcliente
                and r.idrota = c.idrota
              order by r.descr);
  
    return v_rota;
  end;

  function ret_codrotacliente(p_idcliente in number) return string is
    v_codrota varchar(1000);
  begin
    select stragg(codigo)
      into v_codrota
      from (select r.codigo
               from rotacliente c, rotas r
              where c.identidade = p_idcliente
                and r.idrota = c.idrota
              order by r.codigo);
  
    return v_codrota;
  end;

  function ret_TelefRepres
  (
    p_idcliente  in number,
    p_idromaneio in number
  ) return string is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct ni.telefone_representante telefone
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf       c_nf%rowtype;
    v_telefone varchar(1000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_idromaneio, p_idcliente);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_telefone is null then
          v_telefone := r_nf.telefone;
        else
          v_telefone := v_telefone || ',' || r_nf.telefone;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_telefone;
    else
      return '';
    end if;
  end;

  function ret_NomeRepres
  (
    p_idcliente  in number,
    p_idromaneio in number
  ) return string is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct ni.nomerepresentante
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf   c_nf%rowtype;
    v_nome varchar(1000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_idromaneio, p_idcliente);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nome is null then
          v_nome := r_nf.nomerepresentante;
        else
          v_nome := v_nome || ',' || r_nf.nomerepresentante;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nome;
    else
      return '';
    end if;
  end;

  /*
   * Re-Ordena os Clientes na Rota
  */
  procedure ReOrdenarClienteRota(p_rota in number) is
    v_id number := 1;
  begin
    for c in (select identidade, nvl(rc.ordem, 999999999) ordem
                from rotacliente rc
               where rc.idrota = p_rota
               order by nvl(rc.ordem, 999999999))
    loop
      update rotacliente
         set ordem = v_id
       where idrota = p_rota
         and identidade = c.identidade;
      v_id := v_id + 1;
    end loop;
  
  end;

  -- Refactored procedure verificarDivergenciaSaida 
  function verificarDivergenciaSaida(p_idromaneio in number) return boolean is
    v_qtde number;
  begin
    -- Verifica divergencia entre as notas e a paletseparacao
    select count(*)
      into v_qtde
      from (select idromaneio, idproduto, round(sum(qtdenf)) qtdenf,
                    round(sum(qtdeps)) qtdeps
               from (select nfr.idromaneio, nd.idproduto,
                             sum(nd.qtdeatendida * e.fatorconversao) qtdenf,
                             0 qtdeps
                        from romaneiopai rp, nfromaneio nfr, nfdet nd,
                             embalagem e, produto p
                       where decode(rp.reentrega, 'N', 0, 1) = 0
                         and nfr.idromaneio = rp.idromaneio
                         and nd.nf = nfr.idnotafiscal
                         and e.barra = nd.barra
                         and e.idproduto = nd.idproduto
                         and p.idproduto = nd.idproduto
                         and p.kitexpexplodida = 'N'
                       group by nfr.idromaneio, nd.idproduto
                      union all
                      select nfr.idromaneio, kp.idproduto,
                             sum(nd.qtdeatendida * e.fatorconversao * kp.qtde *
                                  ek.fatorconversao) qtdenf, 0 qtdeps
                        from nfromaneio nfr, nfdet nd, produto p, embalagem e,
                             kitproduto kp, produto pk, embalagem ek
                       where nd.nf = nfr.idnotafiscal
                         and p.idproduto = nd.idproduto
                         and p.kitexpexplodida = 'S'
                         and e.barra = nd.barra
                         and e.idproduto = nd.idproduto
                         and kp.idprodutokit = p.idproduto
                         and pk.idproduto = kp.idproduto
                         and ek.idproduto = kp.idproduto
                         and ek.barra = kp.barra
                       group by nfr.idromaneio, kp.idproduto
                      union all
                      select ps.idromaneio, ps.idproduto, 0 qtdenf,
                             sum(ps.qtde * e.fatorconversao) qtdeps
                        from romaneiopai rp, paletseparacao ps, lote l,
                             embalagem e
                       where decode(rp.reentrega, 'N', 0, 1) = 0
                         and ps.idromaneio = rp.idromaneio
                         and l.idlote = ps.idlote
                         and l.tipolote = 'L'
                         and e.barra = ps.barra
                         and e.idproduto = ps.idproduto
                       group by ps.idromaneio, ps.idproduto)
              group by idromaneio, idproduto
             having round(sum(qtdenf)) <> round(sum(qtdeps)))
     where idromaneio = p_idromaneio;
  
    return v_qtde = 0;
  
  end verificarDivergenciaSaida;

  /*
   * Processa romaneio
  */
  procedure processar_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
  
    r_romaneiopai       romaneiopai%rowtype;
    v_possuidivergencia number;
    v_total             number;
  
    v_erro      varchar(2000);
    v_msg       t_message;
    v_templtsep boolean;
  
    function verificarGeracaodeVolumes
    (
      p_romaneio in romaneiopai%rowtype,
      p_erro     in out varchar2
    ) return boolean is
    
      function depositanteRealizaColeta(p_idromaneio in number)
        return boolean is
        v_qtde number;
      begin
        select count(distinct dp.identidade) qtde
          into v_qtde
          from romaneiopai rp, depositante dp, nfromaneio nr, notafiscal nf,
               ordemservico os
         where rp.idromaneio = p_idromaneio
           and rp.idromaneio = nr.idromaneio
           and nf.idnotafiscal = nr.idnotafiscal
           and dp.identidade = nf.iddepositante
           and dp.realizacoleta = 'S'
           and os.idromaneio(+) = rp.idromaneio
           and os.idordemservico is null;
      
        return v_qtde > 0;
      end;
    
      function temVolumeGerado(p_idromaneio in number) return boolean is
        v_qtde number;
      begin
        select count(v.idvolume)
          into v_qtde
          from volumeromaneio v
         where v.idromaneio = p_idromaneio;
      
        return v_qtde > 0;
      end;
    
      function depositanteControlaVolume(p_idromaneio in number)
        return boolean is
        v_qtde number;
      begin
        select count(distinct dp.identidade)
          into v_qtde
          from nfromaneio nr, notafiscal nf, depositante dp
         where dp.controlapeso = 'S'
           and dp.realizacoleta = 'S'
           and dp.identidade = nf.iddepositante
           and nf.idnotafiscal = nr.idnotafiscal
           and nr.idromaneio = p_idromaneio;
      
        return v_qtde > 0;
      end;
    begin
      if not isOrdemServico(p_romaneio.idromaneio) then
        if depositanteRealizaColeta(p_romaneio.idromaneio) then
          if temVolumeGerado(p_romaneio.idromaneio) then
            if depositanteControlaVolume(p_romaneio.idromaneio)
               and (p_romaneio.pesagemliberada = 'N') then
              p_erro := 'O ROMANEIO NÃO PODE SER PROCESSADO, POIS OS VOLUMES NÃO FORAM PESADOS.';
            end if;
          else
            p_erro := 'NÃO FOI POSSÍVEL PROCESSAR O ROMANEIO ID:' ||
                      p_romaneio.idromaneio || ' ROMANEIO NUM ' ||
                      p_romaneio.codigointerno || '.' || chr(13) ||
                      'O DEPOSITANTE REALIZA COLETA E NÃO GERA VOLUMES.';
          end if;
        else
          if temVolumeGerado(p_romaneio.idromaneio) then
            p_erro := 'NÃO FOI POSSÍVEL PROCESSAR O ROMANEIO ID:' ||
                      p_romaneio.idromaneio || ' ROMANEIO NUM ' ||
                      p_romaneio.codigointerno || chr(13) || '.' ||
                      'FORAM GERADOS VOLUMES PARA DEPOSITANTES QUE NÃO GERAM VOLUMES.';
          end if;
        end if;
      end if;
    
      return p_erro is not null;
    end;
  
    function verificarRetiradaNF
    (
      p_romaneio in romaneiopai%rowtype,
      p_erro     in out varchar2
    ) return boolean is
      v_idlotenf number;
    begin
      select lnf.idlotenf
        into v_idlotenf
        from retiradanotafiscal rnf, lotenf lnf
       where lnf.idlotenf = rnf.idlotenf
         and nvl(lnf.flaglibnf, 0) <> 2
         and rnf.idromaneio = p_romaneio.idromaneio;
    
      p_erro := 'NÃO FOI POSSÍVEL PROCESSAR O ROMANEIO ID:' ||
                p_romaneio.idromaneio || 'ROMANEIO NUM ' ||
                p_romaneio.codigointerno || chr(13) || '.' || ' A OR ' ||
                v_idlotenf || ' NÃO FOI CONFERIDA.';
    
      return true;
    exception
      when no_data_found then
        return false;
    end;
  
    function temCorteFisico(p_idromaneio in number) return boolean is
      v_possuidivergencia number;
    begin
      select count(*)
        into v_possuidivergencia
        from cortefisico
       where idonda = p_idromaneio
         and status = 0;
    
      return v_possuidivergencia > 0;
    end;
    -- Pode Processar Pendencia?
    procedure retirarPendenciaEstoque
    (
      p_idarmazem in number,
      p_idlocal   in local.idlocal%type,
      p_idlote    in number,
      p_qtde      in number,
      p_idusuario in number,
      p_romaneio  romaneiopai%rowtype
    ) is
      v_erro          varchar2(2500) := null;
      v_codprod       produto.codigointerno%type;
      v_produto       produto.descr%type;
      v_tipoLocal     number;
      v_LocalBuffer   varchar2(1);
      v_idProduto     number;
      v_idDepositante number;
      v_tipoMaquina   number;
    
      function temRemanejamento
      (
        p_idromaneio in number,
        p_erro       in out varchar2
      ) return boolean is
        v_remanejamento varchar2(2500) := null;
      
      begin
        for c_remanej in (select r.idremanejamento, stragg(lr.idlote) idlote
                            from remanejamento r, loteremanejamento lr
                           where r.status in ('A', 'G')
                             and lr.idremanejamento = r.idremanejamento
                             and exists
                           (select 1
                                    from paletseparacao
                                   where idromaneio = p_idromaneio
                                     and idlote = lr.idlote)
                           group by r.idremanejamento)
        loop
          if (length(v_remanejamento || 'REMANEJAMENTO: ' ||
                     c_remanej.idremanejamento || ' - LOTES: ' ||
                     c_remanej.idlote || chr(13)) >= 2300) then
            exit;
          else
            v_remanejamento := v_remanejamento || 'REMANEJAMENTO: ' ||
                               c_remanej.idremanejamento || ' - LOTES: ' ||
                               c_remanej.idlote || chr(13);
          end if;
        end loop;
        if v_remanejamento is not null then
          p_erro := 'O ROMANEIO ID: ' || p_idromaneio ||
                    ' POSSUI LOTES EM REMANEJAMENTO(S) ABERTO(S).' ||
                    chr(13) || trim(v_remanejamento) ||
                    '. FAVOR REMANEJAR OS REMANEJAMENTOS ENCONTRADOS.';
        end if;
        return p_erro is not null;
      end;
    
      function temOndaPendente
      (
        p_idarmazem  in number,
        p_idlocal    in local.idlocal%type,
        p_idlote     in number,
        p_idromaneio in number,
        p_erro       in out varchar2
      ) return boolean is
        v_movimentacao varchar2(2000) := null;
      begin
        for c_onda in (select distinct rp.codigointerno, m.idlote, ld.idlocal
                         from movimentacao m, local ld, romaneiopai rp
                        where m.status in (0, 1)
                          and m.idlote = p_idlote
                          and ld.id = m.idlocaldestino
                          and ld.idarmazem = p_idarmazem
                          and ld.idlocal = p_idlocal
                          and rp.idromaneio = m.idonda
                        order by rp.codigointerno, m.idlote)
        loop
          v_movimentacao := v_movimentacao || ' ONDA: ' ||
                            c_onda.codigointerno || ' - LOTE: ' ||
                            c_onda.idlote || ' - LOCAL: ' || c_onda.idlocal ||
                            chr(13);
        end loop;
      
        if v_movimentacao is not null then
          p_erro := 'O ROMANEIO ID: ' || p_idromaneio ||
                    ' POSSUI LOTES EM SEPARACAO DE ONDA PENDENTE.' ||
                    chr(13) || trim(v_movimentacao) ||
                    '. FAVOR SEPARAR AS ONDAS ENCONTRADAS.';
        end if;
      
        return p_erro is not null;
      end;
    
      function temOSmisturaClassificacao(p_idRomaneio number) return boolean is
        v_total number;
      begin
      
        select count(*)
          into v_total
          from ordemservico os
         where os.idromaneio = p_idRomaneio
           and os.tiposervico in ('O', 'T', 'R');
      
        return v_total > 0;
      end temOSmisturaClassificacao;
    
      procedure adicionaEstoqueDestinoMaquina
      (
        p_idarmazem  number,
        p_idlote     number,
        p_qtde       number,
        p_idusuario  number,
        p_idRomaneio number
      ) is
        v_idlocalMaquina local.idlocal%type;
        v_msg            t_message;
        v_tipoMaquina    ordemservico.tiposervico%type;
        C_MISTURA         constant number := 11;
        C_CLASSIFICACAO   constant number := 12;
        C_RECLASSIFICACAO constant number := 13;
      
      begin
      
        begin
          select o.tiposervico
            into v_tipoMaquina
            from ordemservico o
           where o.idromaneio = p_idRomaneio;
        
          /*
             Atualmente teremos somente um endereço de mistura e um de classificacao
            caso futuramente existir mais de um endereço, será necessário refatoração.
          */
        
          select idlocal
            into v_idlocalMaquina
            from local l
           where l.tipo = decode(v_tipoMaquina, 'O', C_CLASSIFICACAO, 'T',
                                 C_MISTURA, C_RECLASSIFICACAO)
             and l.ativo = 'S'
             and l.idarmazem = p_idarmazem
             and rownum = 1;
        
          pk_estoque.incluir_estoque(p_idarmazem, v_idlocalMaquina,
                                     p_idlote, p_qtde, p_idusuario,
                                     'ADICIONADO ESTOQUE REFERENTE A MOVIMENTAÇÃO PARA O LOCAL DE MÁQUINA');
        
          pk_estoque.incluir_pendencia(p_idarmazem, v_idlocalMaquina,
                                       p_idlote, p_qtde, p_idusuario,
                                       'ADICIONADO PENDÊNCIA REFERENTE A MOVIMENTAÇÃO PARA O LOCAL DE MÁQUINA');
        
        exception
          when no_data_found then
            v_msg := t_message('Não foi encontrado locais do tipo máquina (Classificação ou Mistura) no cadastro de locais.');
          
            raise_application_error(-20100, v_msg.formatMessage);
        end;
      
      end adicionaEstoqueDestinoMaquina;
    
    begin
      begin
        select lo.tipo, lo.buffer
          into v_tipoLocal, v_LocalBuffer
          from local lo
         where lo.idlocal = p_idlocal
           and lo.idarmazem = p_idarmazem;
      
        pk_estoque.retirar_pendencia(p_idarmazem, p_idlocal, p_idlote,
                                     p_qtde, p_idusuario,
                                     'RETIRADA PENDENCIA EM FUNCAO DO PROCESSAMENTO DO ROMANEIO: ' ||
                                      p_romaneio.codigointerno);
      
        pk_estoque.retirar_estoque(p_idarmazem, p_idlocal, p_idlote, p_qtde,
                                   p_idusuario,
                                   'RETIRADA ESTOQUE EM FUNCAO DO PROCESSAMENTO DO ROMANEIO: ' ||
                                    p_romaneio.codigointerno, 'S');
        if (temOSmisturaClassificacao(p_romaneio.idromaneio)) then
          adicionaEstoqueDestinoMaquina(p_idarmazem, p_idlote, p_qtde,
                                        p_idusuario, p_romaneio.idromaneio);
        end if;
      
        if ((v_tipoLocal = 0) AND (v_LocalBuffer = 'N')) then
          select lt.idproduto, lt.iddepositante
            into v_idProduto, v_idDepositante
            from lote lt
           where lt.idlote = p_idlote
             and lt.idarmazem = p_idarmazem;
        
          pk_picking_dinamico.addGttPickingDinamico(v_idProduto,
                                                    v_idDepositante,
                                                    p_idlocal, p_idarmazem,
                                                    0);
          pk_picking_dinamico.deletar_picking_dinamico;
        end if;
      
      exception
        when others then
          if temRemanejamento(p_romaneio.idromaneio, v_erro) then
            raise_application_error(-20008, v_erro);
          elsif temOndaPendente(p_idarmazem, p_idlocal, p_idlote,
                                p_romaneio.idromaneio, v_erro) then
            raise_application_error(-20009, v_erro);
          else
            select p.codigointerno, p.descr
              into v_codprod, v_produto
              from lote l, produto p
             where l.idlote = p_idlote
               and p.idproduto = l.idproduto;
          
            v_msg := t_message('ERRO AO PROCESSAR O ESTOQUE DO PRODUTO: ' ||
                               chr(13) || '{0} - {1}' || chr(13) ||
                               'IDLOCAL: {2}' ||
                               ' - LOTE: {3} - QTDE: {4}{5}');
            v_msg.addParam(v_codprod);
            v_msg.addParam(v_produto);
            v_msg.addParam(p_idlocal);
            v_msg.addParam(p_idlote);
            v_msg.addParam(p_qtde);
            v_msg.addParam(SQLERRM);
            raise_application_error(-20010, v_msg.formatMessage);
          end if;
      end;
    end;
  
    procedure finalizarProcessamentoRomaneio
    (
      p_idromaneio in number,
      p_idusuario  in number
    ) is
      v_qtdenfcarga number;
    begin
      for c in ( /*Nota Fiscal em processamento*/
                select nfr.idnotafiscal
                  from nfromaneio nfr
                 where nfr.idromaneio = p_idromaneio
                union
                /*Nota Fiscal de Venda da Nota Fiscal em processamento*/
                select rs.idnotafiscalvenda idnotafiscal
                  from nfromaneio nfr, retornosimbolico rs
                 where nfr.idromaneio = p_idromaneio
                   and rs.idnotafiscalretorno = nfr.idnotafiscal
                 group by rs.idnotafiscalvenda
                union
                /*Pedido Pai da Nota Fiscal em processamento*/
                select nfsub.idpedidopai idnotafiscal
                  from nfromaneio nfr, notafiscal nf, notafiscal nfsub
                 where nfr.idromaneio = p_idromaneio
                   and nf.idnotafiscal = nfr.idnotafiscal
                   and nfsub.idpedidopai = nf.idpedidopai
                   and nfsub.idnotafiscal <> nfr.idnotafiscal having
                 sum(decode(nfsub.statusnf, 'P', 0, 1)) = 0
                 group by nfsub.idpedidopai
                union
                /*Pedido Pai da Nota Fiscal de Venda da Nota Fiscal em processamento*/
                select nfsub.idpedidopai idnotafiscal
                  from nfromaneio nfr, retornosimbolico rs, notafiscal nf,
                        notafiscal nfsub
                 where nfr.idromaneio = p_idromaneio
                   and rs.idnotafiscalretorno = nfr.idnotafiscal
                   and nf.idnotafiscal = rs.idnotafiscalvenda
                   and nfsub.idpedidopai = nf.idpedidopai
                   and nfsub.idnotafiscal <> nfr.idnotafiscal having
                 sum(decode(nfsub.statusnf, 'P', 0, 1)) = 0
                 group by nfsub.idpedidopai)
      loop
        -- Processando nota fiscal
        update notafiscal nf
           set nf.statusnf = 'P'
         where decode(nf.statusnf, 'P', 1, 0) = 0
           and nf.idnotafiscal = c.idnotafiscal;
      end loop;
    
      update romaneiopai
         set processado            = c_sim,
             dataprocessamento     = sysdate,
             idusuarioprocromaneio = p_idusuario
       where idromaneio = p_romaneio;
    
      if r_romaneiopai.reentrega = c_sim then
        -- finalizando ocorrencias de reentrega
        update ocorrenciaentrega
           set finalizado = c_sim
         where idromaneioreentrega = p_idromaneio;
      end if;
    
      for c_carga in (select distinct nfc.idcarga
                        from nfromaneio nfr, notafiscalcarga nfc, carga c
                       where c.finalizado = 'N'
                         and c.idcarga = nfc.idcarga
                         and nfc.idnotafiscal = nfr.idnotafiscal
                         and nfr.idromaneio = p_idromaneio)
      loop
        select count(*) total
          into v_qtdenfcarga
          from notafiscalcarga nfc, notafiscal nf
         where nf.statusnf = 'C'
           and nf.idnotafiscal = nfc.idnotafiscal
           and nfc.idcarga = c_carga.idcarga;
      
        if v_qtdenfcarga = 0 then
          update carga c
             set finalizado      = c_sim,
                 situacao        = c_sim,
                 idusuariocoleta = p_idusuario,
                 liberado        = c_sim,
                 datafinalizada  = sysdate
           where c.idcarga = c_carga.idcarga;
        end if;
      end loop;
    end;
  
    procedure devincularAssociacaoEndereco
    (
      p_romaneio  in romaneiopai%rowtype,
      p_idusuario in number
    ) is
    begin
      -- verifica se existe algum endereco com algum irmao associado e que ja nao tenha estoque. 
      -- Caso exista e necessario retirar a associacao de enderecos irmaos.
      for c in (select distinct lo.idarmazem, lo.idlocal, lo.idlocalpai
                  from paletseparacao ps, local lo
                 where ps.idromaneio = p_romaneio.idromaneio
                   and lo.idarmazempai = ps.idarmazem
                   and lo.idlocalpai = ps.idlocal
                   and not exists (select 1
                          from v_estoque_local ll
                         where ll.idarmazem = ps.idarmazem
                           and ll.idlocal = ps.idlocal
                           and ll.disp > 0))
      loop
        update local
           set idarmazempai = null,
               idlocalpai   = null
         where idarmazem = c.idarmazem
           and idlocal = c.idlocal;
      
        pk_utilities.geralog(p_idusuario,
                             'RETIROU A ASSOCIACAO DO ENDERECO IRMAO ' ||
                              c.idlocal || ' COM O ENDERECO PAI ' ||
                              c.idlocalpai ||
                              ' DEVIDO AO PROCESSAMENTO DO ROMANEIO ID: ' ||
                              p_romaneio.idromaneio || ' CODIGO INTERNO: ' ||
                              p_romaneio.codigointerno || ' .',
                             p_romaneio.idromaneio, 'ES');
      end loop;
    end;
  
  begin
    -- Travando registro para que não ocorra duplicação de processamento
    select idromaneio
      into r_romaneiopai.idromaneio
      from romaneiopai
     where idromaneio = p_romaneio
       for update;
  
    -- carregando as informacoes do romaneio
    r_romaneiopai := carregar_romaneio(p_romaneio);
  
    select count(*)
      into v_total
      from nfromaneio nfr, notafiscal nf
     where nfr.idromaneio = p_romaneio
       and nf.idnotafiscal = nfr.idnotafiscal
       and nf.idinventario is not null;
  
    --Se o tipo for romaneio (0) for romaneio processa
    if r_romaneiopai.tipo = 0 then
      if v_total = 0 then
        if r_romaneiopai.liberado = 'N' then
          v_msg := t_message('ESTE ROMANEIO NÃO FOI CONFERIDO. OPERAÇÃO CANCELADA.');
          raise_application_error(-20001, v_msg.formatMessage);
        elsif r_romaneiopai.faturado <> 'S' then
          v_msg := t_message('ESTE ROMANEIO NÃO PODE SER PROCESSADO, POIS EXISTEM PEDIDOS QUE NÃO FORAM FATURADOS VINCULADOS A ELE.');
          raise_application_error(-20002, v_msg.formatMessage);
        elsif r_romaneiopai.processado = 'S' then
          v_msg := t_message('ESTE ROMANEIO JÁ FOI PROCESSADO. OPERAÇÃO CANCELADA.');
          raise_application_error(-20003, v_msg.formatMessage);
        elsif verificarGeracaodeVolumes(r_romaneiopai, v_erro) then
          raise_application_error(-20004, v_erro);
        elsif verificarRetiradaNF(r_romaneiopai, v_erro) then
          raise_application_error(-20005, v_erro);
        elsif temCorteFisico(p_romaneio) then
          v_msg := t_message('EXISTEM DIVERGÊNCIAS DE SAÍDA NÃO RESOLVIDAS. OPERAÇÃO CANCELADA.');
          raise_application_error(-20006, v_msg.formatMessage);
        end if;
      end if;
    
      v_templtsep := false;
      for c_rdet in (select ps.idarmazem, ps.idlocal, ps.idlote,
                            round(ps.qtdeunit, 6) qtde, ps.idproduto,
                            ps.barra
                       from paletseparacao ps
                      where ps.idromaneio = p_romaneio)
      loop
        v_templtsep := true;
        if c_rdet.qtde > 0 then
          retirarPendenciaEstoque(c_rdet.idarmazem, c_rdet.idlocal,
                                  c_rdet.idlote, c_rdet.qtde, p_usuario,
                                  r_romaneiopai);
        
          pk_lote.atualizarSaldoNotaFiscal(c_rdet.idlote, null, c_rdet.qtde,
                                           'PROCESSAMENTO ROMANEIO',
                                           p_romaneio);
        else
          v_msg := t_message('O ROMANEIO ID: {0}' ||
                             ' NÃO PODE SER PROCESSADO, POIS A QTDE DE SEPARACAO DO IDPRODUTO: ' ||
                             '{1} NO LOCAL: {2} E LOTE: {3} NÃO PODE SER ZERO.');
          v_msg.addParam(p_romaneio);
          v_msg.addParam(c_rdet.idproduto);
          v_msg.addParam(c_rdet.idlocal);
          v_msg.addParam(c_rdet.idlote);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    
      if not verificarDivergenciaSaida(r_romaneiopai.idromaneio)
         and v_templtsep then
        v_msg := t_message('O ROMANEIO ID: {0}' ||
                           ' NÃO PODE SER PROCESSADO, POIS EXISTEM DIVERGÊNCIAS ENTRE A QUANTIDADE SEPARADA E A QUANTIDADE SOLICITADA.');
        v_msg.addParam(p_romaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      finalizarProcessamentoRomaneio(p_romaneio, p_usuario);
    
      devincularAssociacaoEndereco(r_romaneiopai, p_usuario);
    
      pk_utilities.geralog(p_usuario,
                           'PROCESSOU ROMANEIO ID: ' ||
                            r_romaneiopai.idromaneio || ' CODIGO INTERNO: ' ||
                            r_romaneiopai.codigointerno || ' .',
                           r_romaneiopai.idromaneio, 'ES');
    end if;
  end;

  /*
   * Carrega todos as informacoes da romaneiopai
  */
  function carregar_romaneio(p_romaneio in number) return romaneiopai%rowtype is
    cursor c_romaneio(p_romaneio in number) is
      select idromaneio, idusuario, idmestre, codigointerno, datageracao,
             dataprocessamento, tituloromaneio, calculanumpalet, processado,
             gerado, liberado, erro, faturado, impseparacao, impconferencia,
             impabastecimento, idarmazem, iddoca, placa, nummaxpalet,
             reentrega, pesagemliberada, idusuarioprocromaneio, idlocal,
             tipo, separado
        from romaneiopai
       where idromaneio = p_romaneio;
  
    r_romaneio c_romaneio%rowtype;
    v_romaneio romaneiopai%rowtype;
  begin
    open c_romaneio(p_romaneio);
    fetch c_romaneio
      into r_romaneio;
  
    if c_romaneio%found then
      v_romaneio.idromaneio            := r_romaneio.idromaneio;
      v_romaneio.idusuario             := r_romaneio.idusuario;
      v_romaneio.idmestre              := r_romaneio.idmestre;
      v_romaneio.codigointerno         := r_romaneio.codigointerno;
      v_romaneio.datageracao           := r_romaneio.datageracao;
      v_romaneio.dataprocessamento     := r_romaneio.dataprocessamento;
      v_romaneio.tituloromaneio        := r_romaneio.tituloromaneio;
      v_romaneio.calculanumpalet       := r_romaneio.calculanumpalet;
      v_romaneio.processado            := r_romaneio.processado;
      v_romaneio.gerado                := r_romaneio.gerado;
      v_romaneio.liberado              := r_romaneio.liberado;
      v_romaneio.erro                  := r_romaneio.erro;
      v_romaneio.faturado              := r_romaneio.faturado;
      v_romaneio.impseparacao          := r_romaneio.impseparacao;
      v_romaneio.impconferencia        := r_romaneio.impconferencia;
      v_romaneio.impabastecimento      := r_romaneio.impabastecimento;
      v_romaneio.idarmazem             := r_romaneio.idarmazem;
      v_romaneio.iddoca                := r_romaneio.iddoca;
      v_romaneio.idlocal               := r_romaneio.idlocal;
      v_romaneio.placa                 := r_romaneio.placa;
      v_romaneio.nummaxpalet           := r_romaneio.nummaxpalet;
      v_romaneio.reentrega             := r_romaneio.reentrega;
      v_romaneio.pesagemliberada       := r_romaneio.pesagemliberada;
      v_romaneio.idusuarioprocromaneio := r_romaneio.idusuarioprocromaneio;
      v_romaneio.tipo                  := r_romaneio.tipo;
      v_romaneio.separado              := r_romaneio.separado;
    else
      v_romaneio := null;
    end if;
  
    close c_romaneio;
  
    return v_romaneio;
  end;

  /*
   * Processa romaneio a partir da carga
  */
  procedure processar_romaneio_carga
  (
    p_carga   in number,
    p_usuario in number,
    p_origem  in number,
    p_motivo  in number default -1
  ) is
    v_naoconferido             varchar2(1000);
    v_qtdeOndas                number := 0;
    v_cargaFinalizada          char(1);
    v_idagenda                 number;
    v_statusagenda             number;
    v_finalizaAgendaAutomatico number;
    v_pesarVeiculo             boolean;
    v_dataFinalConf            date;
    v_dataInicioExec           date := sysdate;
    v_msg                      t_message;
    v_idarmazem                armazem.idarmazem%type;
    v_existecortevolume        number;
    v_idNotaFiscalCancErp      notafiscal.idnotafiscal%type;
    v_naoExportouRti           varchar2(1000);
  
    AGENDA_CANCELADA             constant number := 5;
    AGENDA_SEGUNDA_PESAGEM_LIB   constant number := 9;
    AGENDA_SEGUNDA_PESAG_LIB_DIV constant number := 11;
    PROCESSAR_COLETA             constant number := 0;
    C_TRUE                       constant number := 1;
    C_FALSE                      constant number := 0;
  
    C_ENCONTROU_AUTOMACAO boolean := false;
  
    procedure processarCargaCfPessagemPedPai is
      v_idpedidopai  notafiscal.idnotafiscal%type;
      v_idnotafiscal notafiscal.idnotafiscal%type;
      v_tiponf       notafiscal.tiponf%type;
    
      C_NOTAFISCAL          constant char := 'N';
      C_PEDIDO              constant char := 'P';
      C_NAO_CONFERE_PESAGEM constant number := 0;
    
      procedure getPedidoOriginal is
      begin
        begin
          select pp.idnotafiscal, nf.idnotafiscal, nf.tiponf
            into v_idpedidopai, v_idnotafiscal, v_tiponf
            from notafiscalcarga nfc, notafiscal nf, nfromaneio nfr,
                 notafiscal pp, romaneiopai rp, configuracaoonda co
           where nfc.idcarga = p_carga
             and pp.tiponf = C_PEDIDO
             and co.conferenciapesagem > 0
             and nf.idnotafiscal = nfc.idnotafiscal
             and nfr.idnotafiscal = nf.idpedidopai
             and pp.idnotafiscal = nfr.idnotafiscal
             and rp.idromaneio = nfr.idromaneio
             and co.idconfiguracaoonda = rp.idconfiguracaoonda;
        exception
          when too_many_rows then
            v_msg := t_message('Conferência pesagem  não permite mais de uma nf na coleta.');
            raise_application_error(-20000, v_msg.formatMessage);
          when no_data_found then
            v_idpedidopai  := 0;
            v_idnotafiscal := 0;
            v_tiponf       := '0';
        end;
      end getPedidoOriginal;
    
      function isTodosSubPedidosFaturados return boolean is
        v_retorno number;
      begin
        begin
          select 1
            into v_retorno
            from (select count(*) qtde
                     from notafiscal nf
                    where nf.idpedidopai = v_idpedidopai) p,
                 (select count(*) qtde
                     from notafiscal nf
                    where nf.idpedidopai = v_idpedidopai
                      and nf.tiponf = C_NOTAFISCAL) f
           where p.qtde - f.qtde = 0;
        exception
          when no_data_found then
            v_retorno := 0;
        end;
        return v_retorno = 1;
      end isTodosSubPedidosFaturados;
    
      function isConsumidaTodaQtdPedOriginal return boolean is
        v_retorno number;
      begin
        begin
          select 1
            into v_retorno
            from (select nvl(sum(nd.qtde * e.fatorconversao), 0) total
                     from notafiscal nf, nfdet nd, embalagem e
                    where nf.idnotafiscal = v_idpedidopai
                      and nf.tiponf = C_PEDIDO
                      and nd.nf = nf.idnotafiscal
                      and e.idproduto = nd.idproduto
                      and e.barra = nd.barra) nfp,
                 (select nvl(sum(nd.qtde * e.fatorconversao), 0) total
                     from notafiscal nf, nfdet nd, embalagem e
                    where nf.idpedidopai = v_idpedidopai
                      and nd.nf = nf.idnotafiscal
                      and e.idproduto = nd.idproduto
                      and e.barra = nd.barra) nfsvinc
           where nfp.total - nfsvinc.total = 0;
        exception
          when no_data_found then
            v_retorno := 0;
        end;
        return v_retorno = 1;
      end isConsumidaTodaQtdPedOriginal;
    
      procedure processarPedidoOriginal is
        v_idonda number;
      
        procedure conferirNotaFiscalOnda is
          v_total number;
          C_CONFERIDA_NF constant number := 1;
          C_NF_PESADA    constant number := 1;
        
        begin
          select nfr.idromaneio
            into v_idonda
            from nfromaneio nfr
           where nfr.idnotafiscal = v_idpedidopai;
        
          pk_triggers_control.disableTrigger('T_INSERIR_NFROMANEIO');
          update nfromaneio nfr
             set nfr.conferido = 'S'
           where nfr.idnotafiscal = v_idpedidopai
             and nfr.idromaneio = v_idonda;
          pk_triggers_control.enableTrigger('T_INSERIR_NFROMANEIO');
        
          select sum(d.qtde * e.fatorconversao)
            into v_total
            from nfdet d, embalagem e
           where d.nf = v_idpedidopai
             and e.barra = d.barra
             and e.idproduto = d.idproduto;
        
          pk_triggers_control.disableTrigger('T_alteraSaidaPorNF');
          update saidapornf s
             set s.qtdeconferida = v_total,
                 s.conferido     = C_CONFERIDA_NF,
                 s.pesado        = C_NF_PESADA
           where s.idnotafiscal in
                 (select n.idnotafiscal
                    from (select nfp.idnotafiscal
                             from notafiscal nfp
                            where nfp.idnotafiscal = v_idpedidopai
                           union all
                           select nfs.idnotafiscal
                             from notafiscal nfs
                            where nfs.idpedidopai = v_idpedidopai) n
                   group by n.idnotafiscal)
             and s.idonda = v_idonda;
          pk_triggers_control.enableTrigger('T_alteraSaidaPorNF');
        end conferirNotaFiscalOnda;
      
      begin
        conferirNotaFiscalOnda;
        pk_onda.processarNotaFiscal(v_idpedidopai, p_usuario, 'N');
      end processarPedidoOriginal;
    
      function isSubPedidosProcessados return boolean is
        v_retorno number;
      begin
        begin
          select count(*)
            into v_retorno
            from (select pp.idnotafiscal
                     from notafiscalcarga nfc, notafiscal nf, notafiscal pp
                    where nfc.idcarga = p_carga
                      and nf.idnotafiscal = nfc.idnotafiscal
                      and pp.idnotafiscal = nf.idpedidopai) p, notafiscal nf,
                 notafiscalcarga nfc, carga c
           where nfc.idcarga <> p_carga
             and c.finalizado = 'N'
             and nf.idpedidopai = p.idnotafiscal
             and nfc.idnotafiscal = nf.idnotafiscal
             and c.idcarga = nfc.idcarga;
        exception
          when no_data_found then
            v_retorno := 0;
        end;
        return v_retorno = 0;
      end isSubPedidosProcessados;
    
    begin
      getPedidoOriginal;
    
      if (v_idpedidopai = C_NAO_CONFERE_PESAGEM) then
        return;
      end if;
    
      if (v_tiponf <> C_NOTAFISCAL) then
        v_msg := t_message('O pedido {0} que encontra-se na coleta, não está faturado.');
        v_msg.addParam(v_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (not isTodosSubPedidosFaturados) then
        return;
      end if;
    
      if (not isConsumidaTodaQtdPedOriginal) then
        return;
      end if;
    
      if (not isSubPedidosProcessados) then
        return;
      end if;
    
      processarPedidoOriginal;
    
    end processarCargaCfPessagemPedPai;
  
    function isNFCancERP
    (
      p_idcarga      in carga.idcarga%type,
      p_idNotaFiscal out notafiscal.idnotafiscal%type
    ) return boolean is
      v_canceladoERP number;
    begin
      v_canceladoERP := C_FALSE;
    
      select count(1), max(nf.idnotafiscal)
        into v_canceladoERP, p_idNotaFiscal
        from notafiscal nf, cargaromaneio cr, carga c
       where nf.idnotafiscal = cr.idnotafiscal
         and cr.idcarga = c.idcarga
         and nf.canceladoerp = C_TRUE
         and c.idcarga = p_idcarga;
    
      return v_canceladoERP = C_TRUE;
    end;
  
  begin
  
    if (isNFCancERP(p_carga, v_idNotaFiscalCancErp)) then
      v_msg := t_message('O Pedido ou Nota fiscal id {0} foi cancelado pelo ERP e deve ser retirado da onda.');
      v_msg.addParam(v_idNotaFiscalCancErp);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Travando registro de carga para que não seja alterado por outra rotina (finalizar embarque)  
    select ca.finalizado, ca.idagenda, ca.idarmazem
      into v_cargaFinalizada, v_idagenda, v_idarmazem
      from carga ca
     where ca.idcarga = p_carga
       for update;
  
    processarCargaCfPessagemPedPai;
  
    if (v_cargaFinalizada = 'S') then
      v_msg := t_message('A coleta já esta processada.' || chr(13) ||
                         'IDCARGA: {0}');
      v_msg.addParam(p_carga);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- se exitir notasfiscais de onda na carga verifica se o servico do tsunami esta ativo
    select count(distinct rp.idromaneio)
      into v_qtdeOndas
      from notafiscalcarga nfc, nfromaneio nfr, romaneiopai rp
     where rp.idromaneio = nfr.idromaneio
       and nfr.idnotafiscal = nfc.idnotafiscal
       and nfc.idcarga = p_carga
       and rp.tipo = 1;
  
    if v_qtdeOndas > 0 then
      if pk_job.isTsunamiAtivo = FALSE then
        v_msg := t_message('NAO FOI POSSIVEL PROCESSAR ESTA CARGA POIS O SERVICO DO MODULO TSUNAMI NAO ESTA ATIVO, OPERACAO CANCELADA.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end if;
  
    if (pk_carga.isSolicitacaoCancelamento(p_carga) > 0) then
      v_msg := t_message('NÃO FOI POSSIVEL PROCESSAR ESTA CARGA POIS A(S) NOTA(S) FISCAL(IS) {0}' ||
                         ' E SEUS VOLUMES ESTÃO COM SOLICITAÇÃO DE CANCELAMENTO, RETIRE-OS DA CARGA PARA QUE SEJA POSSÍVEL PROCESSAR A COLETA.');
      v_msg.addParam(pk_carga.getNotasSolicitacaoCancel(p_carga));
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    if (not pk_carga.isValidaRegistroLacres(v_idarmazem, p_carga)) then
      v_msg := t_message('Nenhum lacre foi coletado na carga: {0}');
      v_msg.addParam(p_carga);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_existecortevolume
      from dual
     where exists (select 1
              from volumeromaneio vr, cortefisicovolume cfv
             where vr.idcarga = p_carga
               and cfv.idvolumeromaneio = vr.idvolumeromaneio
               and cfv.status = 0);
  
    if (v_existecortevolume > 0) then
      v_msg := t_message('EXISTE UM OU MAIS REGISTRO(S) DE CORTE FÍSICO DE VOLUME PARA A CARGA QUE AINDA NÃO FOI RESOLVIDO.' ||
                         chr(13) ||
                         'PARA PROCESSAR A CARGA, RESOLVA O CORTE PRIMEIRO. OPERAÇÃO CANCELADA.' ||
                         chr(13) || 'IDCARGA: {0}');
      v_msg.addParam(p_carga);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- conferindo se existem romaneios sem serem coletados
    for c_rom in (select distinct rp.codigointerno
                    from notafiscalcarga nfc, nfromaneio nfr, romaneiopai rp
                   where rp.liberado = 'N'
                     and rp.idromaneio = nfr.idromaneio
                     and nfr.idnotafiscal = nfc.idnotafiscal
                     and nfc.idcarga = p_carga
                     and rp.tipo = 0)
    loop
      if v_naoconferido is not null then
        v_naoconferido := v_naoconferido || ', ' || c_rom.codigointerno;
      else
        v_naoconferido := c_rom.codigointerno;
      end if;
    end loop;
  
    if v_naoconferido is not null then
      v_msg := t_message('EXISTE(M) ROMANEIO(S) NAO CONFERIDO(S).' ||
                         chr(13) || 'ROMANEIOS: {0}' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_naoconferido);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    -- verifica se existem notas fiscais não conferidas
    for c_nf in (select distinct nf.codigointerno
                   from notafiscalcarga nfc, nfromaneio nfr, saidapornf s,
                        notafiscal nf
                  where nf.idnotafiscal = nfr.idnotafiscal
                    and s.conferido = 0
                    and s.idnotafiscal = nfr.idnotafiscal
                    and s.idonda = nfr.idromaneio
                    and nfr.idnotafiscal = nfc.idnotafiscal
                    and nfc.idcarga = p_carga)
    loop
      if v_naoconferido is not null then
        v_naoconferido := v_naoconferido || ', ' || c_nf.codigointerno;
      else
        v_naoconferido := c_nf.codigointerno;
      end if;
    end loop;
  
    if v_naoconferido is not null then
      v_msg := t_message('EXISTE(M) NOTA(S) FISCAL(IS) NAO CONFERIDA(S).' ||
                         chr(13) || 'NOTAS FISCAIS: {0}' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_naoconferido);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    -- verifica se existem volumes não conferidos para a coleta
    for c_vl in (select vr.codbarra
                   from notafiscalcarga nfc, volumeromaneio vr
                  where nfc.idcarga = p_carga
                    and nfc.embarqueliberado = 'S'
                    and vr.idnotafiscal = nfc.idnotafiscal
                    and vr.conferido = 'N'
                    and vr.statusvolume = 0)
    loop
      if v_naoconferido is not null then
        v_naoconferido := v_naoconferido || ', ' || c_vl.codbarra;
      else
        v_naoconferido := c_vl.codbarra;
      end if;
    end loop;
  
    if v_naoconferido is not null then
      v_msg := t_message('EXISTE(M) VOLUME(S) NAO CONFERIDO(S) E O DEPOSITANTE ' ||
                         'NÃO PERMITE O PROCESSAMENTO DE COLETA SEM COLETAR OS VOLUMES.' ||
                         chr(13) || 'VOLUMES: {0}' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_naoconferido);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    -- verificar se o existem pedidos não faturados na coleta
    for c_ped in (select nf.codigointerno
                    from notafiscalcarga nfc, notafiscal nf, armazem a
                   where nfc.idnotafiscal = nf.idnotafiscal
                     and nf.idarmazem = a.idarmazem
                     and a.permitirvincularpedidocoleta = 1
                     and nfc.idcarga = p_carga
                     and nf.tiponf = 'P')
    loop
    
      if v_naoconferido is not null then
        v_naoconferido := v_naoconferido || ', ' || c_ped.codigointerno;
      else
        v_naoconferido := c_ped.codigointerno;
      end if;
    end loop;
  
    if v_naoconferido is not null then
      v_msg := t_message('EXISTE(M) PEDIDO(S) NÃO FATURADO(S).' || chr(13) ||
                         'PEDIDO(S): {0}' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_naoconferido);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    for c_roma in (select distinct nfr.idromaneio, nfc.idcarga
                     from notafiscalcarga nfc, nfromaneio nfr, romaneiopai rp
                    where rp.processado = 'N'
                      and rp.idromaneio = nfr.idromaneio
                      and nfr.idnotafiscal = nfc.idnotafiscal
                      and nfc.idcarga = p_carga
                      and not exists
                    (select 1
                             from nfromaneio nr, notafiscalcarga nc, carga c
                            where nvl(c.finalizado, 'N') = 'N'
                              and c.idcarga(+) = nc.idcarga
                              and nvl(nc.idcarga, 0) <> nfc.idcarga
                              and nc.idnotafiscal(+) = nr.idnotafiscal
                              and nr.idromaneio = nfr.idromaneio))
    loop
      processar_romaneio(c_roma.idromaneio, p_usuario);
    
      update romaneiopai
         set coletado        = C_SIM,
             datacoleta      = SYSDATE, -- DATA DE COLETA
             idusuariocoleta = p_usuario
       where idromaneio = c_roma.idromaneio;
    end loop;
  
    -- Verifica notas que não são de retorno de armazenagem para a geração de retorno simbólico
    for c in (select nfr.idromaneio, nfr.idnotafiscal
                from nfromaneio nfr, notafiscalcarga nfc
               where nfc.idnotafiscal = nfr.idnotafiscal
                 and nfc.idcarga = p_carga
                 and not exists
               (select 1
                        from retornosimbolico rs
                       where rs.idnotafiscalretorno = nfr.idnotafiscal))
    loop
      pk_notafiscal.GerarNFRetornoArmazenagemOnda(c.idromaneio,
                                                  c.idnotafiscal, p_usuario);
    end loop;
  
    -- Verificar se existe Ordem de Devolução (Vendor Return) que não exportou RTI
    for c_ordemDevolucao in (select distinct od.codigointerno
                               from carga c, notafiscalcarga nfc,
                                    notafiscal nf, ordemdevolucao od,
                                    depositante d
                              where c.idcarga = p_carga
                                and nfc.idcarga = c.idcarga
                                and nf.idnotafiscal = nfc.idnotafiscal
                                and od.idnotafiscal = nf.idnotafiscal
                                and od.exportourti = C_NAO_NUMBER
                                and od.status <> C_ORDEM_DEVOLUCAO_CANCELADA
                                and d.identidade = nf.iddepositante
                                and d.exportsolicfaturaretfornecxrti =
                                    C_SIM_NUMBER)
    loop
      if v_naoExportouRti is not null then
        v_naoExportouRti := v_naoExportouRti || ', ' ||
                            c_ordemDevolucao.codigointerno;
      else
        v_naoExportouRti := c_ordemDevolucao.codigointerno;
      end if;
    end loop;
  
    if v_naoExportouRti is not null then
      v_msg := t_message('EXISTE(M) ORDEM(S) DE DEVOLUÇÃO QUE NÃO EXPORTOU(RAM) RTI.' ||
                         chr(13) || 'ORDEM(S): {0}' || chr(13) ||
                         'OPERACAO CANCELADA.');
      v_msg.addParam(v_naoExportouRti);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select max(vrm.dataconferencia)
      into v_dataFinalConf
      from volumeromaneio vrm
     where vrm.idcarga = p_carga;
  
    update carga
       set finalizado           = c_sim,
           situacao             = c_sim,
           idusuariocoleta      = p_usuario,
           liberado             = c_sim,
           datafinalizada       = sysdate,
           conferenciavolume    = 2,
           datafinalconferencia = v_dataFinalConf
     where idcarga = p_carga;
  
    --CHAMAR PROCESSAMENTO DA ONDA
    if (v_qtdeOndas > 0) then
      -- verificar se existe agendamento de transporte para tratar a alteração de status
      if (v_idagenda is null) then
        pk_job.JobCriarTarefa(1, 'idCarga=' || p_carga, p_usuario,
                              'Processamento automatico da coleta: ' ||
                               p_carga);
      else
        select a.status, d.finalizaragendaautomaticamente
          into v_statusagenda, v_finalizaAgendaAutomatico
          from agendatransporte a, depositante d
         where a.idagenda = v_idagenda
           and d.identidade = a.identidade;
      
        -- verifica se depositante realiza pesagem de veículo e se o modal de transporte é rodoviário
        v_pesarVeiculo := pk_agendamento.isPesagemVeiculoAgendamento(v_idagenda) and
                          pk_agendamento.isModalRodoviario(v_idagenda);
      
        --origem 0: tela de gerenciador de coleta | 1: coletor de dados      
        if (p_origem = 0) then
          -- processa coleta somente se a segunda pesagem estiver liberada
          if (v_pesarVeiculo and
             (v_statusagenda not in
             (AGENDA_CANCELADA, AGENDA_SEGUNDA_PESAGEM_LIB,
                AGENDA_SEGUNDA_PESAG_LIB_DIV))) then
            v_msg := t_message('NÃO FOI POSSÍVEL PROCESSAR A COLETA {0}' ||
                               ', POIS A SEGUNDA PESAGEM DO VEÍCULO NÃO FOI LIBERADA.');
            v_msg.addParam(p_carga);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          if (v_statusagenda <> AGENDA_CANCELADA and
             v_finalizaAgendaAutomatico = 1) then
            pk_agendamento.finalizarAgendamento(v_idagenda, p_usuario);
          end if;
        elsif (p_origem = 1) then
          -- se finaliza o agendamento automático mas não pesa veículo, então, finaliza o agendamento
          if ((v_statusagenda <> AGENDA_CANCELADA) and
             (v_finalizaAgendaAutomatico = 1) and (not v_pesarVeiculo)) then
            pk_agendamento.finalizarAgendamento(v_idagenda, p_usuario);
          end if;
        end if;
      
        pk_job.JobCriarTarefa(1, 'idCarga=' || p_carga, p_usuario,
                              'Processamento automatico da coleta: ' ||
                               p_carga);
      end if;
    end if;
  
    pk_convocacao.finalizacoleta(p_usuario, p_carga);
  
    pk_convocacao.finalizaColetaSobDemanda(p_usuario, p_carga);
  
    --apaga os registros da tabela int_automacao_esteira se a coleta for processada manualmente
    if (p_motivo > -1) then
      for cur_automacao_esteira in (select *
                                      from int_automacao_esteira i
                                     where i.idoperacao = p_carga
                                       and (i.tipooperacao = 6 and
                                           i.integrado = 0)
                                        or exists
                                     (select 1
                                              from volumeromaneio v
                                             where v.idcarga = p_carga
                                               and v.idvolume = i.idoperacao
                                               and i.integrado = 0))
      
      loop
        C_ENCONTROU_AUTOMACAO := true;
      
        insert into historico_automacao_esteira
          (id, data, evento, esteira, codintegracao, identificador,
           integrado, pesagemliberada, idoperacao, tipooperacao,
           usuariologado)
        values
          (seq_hist_automacao_esteira.nextval, sysdate, 1,
           cur_automacao_esteira.esteira,
           cur_automacao_esteira.codintegracao,
           cur_automacao_esteira.identificador,
           cur_automacao_esteira.integrado,
           cur_automacao_esteira.pesagemliberada,
           cur_automacao_esteira.idoperacao, 8, user);
      
        delete int_automacao_esteira d
         where d.id = cur_automacao_esteira.id;
      end loop;
    
      if C_ENCONTROU_AUTOMACAO then
        update carga c
           set c.IDMOTIVOPROCESSARCOLETA = p_motivo
         where c.idcarga = p_carga;
      end if;
    end if;
  
    pk_integracao.ExportarColeta(p_carga, p_usuario);
  
    pk_integracao.exportaConfirmacaoEmbarque(p_carga, p_usuario);
  
    -- Essa validação pode ser realizada aqui pois já existe uma validação
    -- ao vincular notas na carga para que notas de vendor return não se
    -- misturem com outro tipo de nota
    if (coletaPossuiVendorReturn(p_carga)) then
    
      for c_romaneio in (select distinct nfr.idromaneio
                           from notafiscalcarga nfc, notafiscal nf,
                                nfromaneio nfr
                          where nfc.idcarga = p_carga
                            and nf.idnotafiscal = nfc.idnotafiscal
                            and nfr.idnotafiscal = nf.idnotafiscal)
      loop
        pk_integracao.exportarPRN(c_romaneio.idromaneio);
      end loop;
    
    else
      if (p_origem <> 2) then
        pk_integracao.exportarTRK(p_carga, PROCESSAR_COLETA);
      end if;
    
      pk_integracao.exportarASN(p_carga);
    end if;
  
    pk_utilities.gerarLogTempoExecucao('Finalização da Coleta [idCarga: ' ||
                                       p_carga ||
                                       '] [rotina: processar_romaneio_carga]',
                                       v_dataInicioExec, sysdate, p_carga);
  
  end processar_romaneio_carga;

  procedure finalizaVolumeColeta(p_carga in number) is
    v_dataFinalConf date;
  begin
    select max(vrm.dataconferencia)
      into v_dataFinalConf
      from volumeromaneio vrm
     where vrm.idcarga = p_carga;
  
    update carga
       set conferenciavolume    = 2,
           datafinalconferencia = v_dataFinalConf
     where idcarga = p_carga;
  end;

  /*
   * Redistribui as qtdes do Pallet separacao nao deixando que fique qtde
   * quebradas
  */
  procedure redistribuir_qtde_separacao
  (
    p_romaneio in number,
    p_pallet   in number,
    p_lote     in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_produto  in number,
    p_barra    in string,
    p_qtde     in number
  ) is
    cursor c_emb
    (
      p_produto in number,
      p_rest    in number
    ) is
      select barra, fatorconversao
        from embalagem
       where idproduto = p_produto
         and trunc(p_rest / fatorconversao) > 0
         and ativo = c_sim
       order by fatorconversao desc, nvl(barrainterna, 0) asc;
  
    r_emb       c_emb%rowtype;
    v_qtde      number := 0;
    v_qtdea     number := 0;
    v_embalagem embalagem%rowtype;
  begin
    -- apaga a embalagem atual de separacao
    delete from paletseparacao
     where idromaneio = p_romaneio
       and idpalet = p_pallet
       and idlote = p_lote
       and idarmazem = p_armazem
       and idlocal = p_local
       and idproduto = p_produto
       and barra = p_barra;
  
    -- parametro p_qtde esta em unidades... !!
    v_qtde := p_qtde;
  
    if c_emb%isopen then
      close c_emb;
    end if;
    open c_emb(p_produto, v_qtde);
    fetch c_emb
      into r_emb;
    while (v_qtde > 0)
          and (c_emb%found)
    loop
      if trunc(v_qtde / r_emb.fatorconversao) > 0 then
        v_qtdea := trunc(v_qtde / r_emb.fatorconversao);
        v_qtde  := v_qtde - (v_qtdea * r_emb.fatorconversao);
      
        inserir_pallet_separacao(p_romaneio, p_pallet, p_armazem, p_local,
                                 p_lote, p_produto, r_emb.barra, v_qtdea,
                                 v_qtdea * r_emb.fatorconversao);
      end if;
      fetch c_emb
        into r_emb;
    end loop;
    if v_qtde > 0 then
      -- se mesmo assim ficar sobrando qtde a ser inserida e
      -- inserido para separacao a qtde em unidades
      v_embalagem := pk_produto.CarregarEmbalagem(p_produto, 1);
      inserir_pallet_separacao(p_romaneio, p_pallet, p_armazem, p_local,
                               p_lote, p_produto, v_embalagem.barra, v_qtde,
                               v_qtde);
    end if;
  end;

  /*
   * Verifica se e necessario a distribuicao das qtde de produto
   * no pallet de separacao Ex. 1,5cx = 1 caixa e 2 dp
  */
  procedure verificar_qtde_separacao(p_romaneio in number) is
    cursor c_emb
    (
      p_produto        in number,
      p_fatorconversao in number,
      p_rest           in number
    ) is
      select barra, fatorconversao
        from embalagem
       where idproduto = p_produto
         and trunc(p_rest / fatorconversao) > 0
         and fatorconversao > p_fatorconversao
         and ativo = c_sim
       order by fatorconversao desc, nvl(barrainterna, 0) asc;
  
    cursor c_lote
    (
      p_romaneio in number,
      p_palet    in number,
      p_armazem  in number,
      p_local    in local.idlocal%type,
      p_produto  in number,
      p_barra    in embalagem.barra%type
    ) is
      select idlote, qtdeunit qtde, ps.ordem
        from paletseparacao ps
       where ps.idromaneio = p_romaneio
         and ps.idpalet = p_palet
         and ps.idarmazem = p_armazem
         and ps.idlocal = p_local
         and ps.idproduto = p_produto
         and ps.barra = p_barra
       order by qtdeunit desc;
  
    r_emb  c_emb%rowtype;
    r_lote c_lote%rowtype;
  
    v_qtde_emb  number := 0;
    v_qtde_lote number := 0;
  begin
    for c_sep in (select idpalet, idlote, idarmazem, idlocal, idproduto,
                         barra, qtdeunit
                    from paletseparacao ps
                   where ps.idromaneio = p_romaneio)
    loop
      redistribuir_qtde_separacao(p_romaneio, c_sep.idpalet, c_sep.idlote,
                                  c_sep.idarmazem, c_sep.idlocal,
                                  c_sep.idproduto, c_sep.barra,
                                  c_sep.qtdeunit);
    end loop;
  
    for c_sep in (select ps.idpalet, ps.idarmazem, ps.idlocal, ps.idproduto,
                         ps.barra, e.fatorconversao, sum(ps.qtdeunit) qtde
                    from paletseparacao ps, embalagem e
                   where ps.idromaneio = p_romaneio
                     and e.idproduto = ps.idproduto
                     and e.barra = ps.barra
                   group by ps.idpalet, ps.idarmazem, ps.idlocal,
                            ps.idproduto, ps.barra, e.fatorconversao)
    loop
      if c_emb%isopen then
        close c_emb;
      end if;
      open c_emb(c_sep.idproduto, c_sep.fatorconversao, c_sep.qtde);
      fetch c_emb
        into r_emb;
    
      if (c_emb%found) then
        v_qtde_emb := trunc(c_sep.qtde / r_emb.fatorconversao);
      
        if c_lote%isopen then
          close c_lote;
        end if;
        open c_lote(p_romaneio, c_sep.idpalet, c_sep.idarmazem,
                    c_sep.idlocal, c_sep.idproduto, c_sep.barra);
        fetch c_lote
          into r_lote;
        while (c_lote%found)
              and (v_qtde_emb > 0)
        loop
          v_qtde_lote := round(r_lote.qtde / r_emb.fatorconversao, 5);
          v_qtde_emb  := v_qtde_emb - v_qtde_lote;
        
          delete from paletseparacao
           where idromaneio = p_romaneio
             and idpalet = c_sep.idpalet
             and idarmazem = c_sep.idarmazem
             and idlocal = c_sep.idlocal
             and idlote = r_lote.idlote
             and idproduto = c_sep.idproduto
             and barra = c_sep.barra;
        
          inserir_pallet_separacao(p_romaneio, c_sep.idpalet,
                                   c_sep.idarmazem, c_sep.idlocal,
                                   r_lote.idlote, c_sep.idproduto,
                                   r_emb.barra, v_qtde_lote, r_lote.qtde);
        
          update paletseparacao
             set ordem = r_lote.ordem
           where idromaneio = p_romaneio
             and idpalet = c_sep.idpalet
             and idarmazem = c_sep.idarmazem
             and idlocal = c_sep.idlocal
             and idlote = r_lote.idlote
             and idproduto = c_sep.idproduto
             and barra = c_sep.barra;
        
          fetch c_lote
            into r_lote;
        end loop;
      end if;
    end loop;
  end;

  /*
   * Retorna o Pallet que esta o cliente
  */
  function cliente_palet
  (
    p_romaneio in number,
    p_entidade in number
  ) return varchar2 is
    cursor c_p
    (
      p_romaneio in number,
      p_entidade in number
    ) is
      select distinct trim(to_char(pa.idpalet)) numero, pa.idpalet num
        from produtopalet pp, palet pa
       where pp.idromaneio = pa.idromaneio
         and pp.idpalet = pa.idpalet
         and pp.idromaneio = p_romaneio
         and pp.identidade = p_entidade
       order by pa.idpalet;
    v_return varchar2(400);
    r_p      c_p%rowtype;
    v_i      number;
  begin
    if c_p%isopen then
      close c_p;
    end if;
    open c_p(p_romaneio, p_entidade);
    fetch c_p
      into r_p;
    v_i := 1;
    while c_p%found
    loop
      if v_i = 1 then
        v_return := r_p.numero;
      else
        v_return := v_return || ', ' || r_p.numero;
      end if;
      fetch c_p
        into r_p;
      v_i := v_i + 1;
    end loop;
    return v_return;
  end;

  /*
   * Insere Uma Nova Carga
  */
  function Inserir_Carga
  (
    p_romaneio   in romaneiopai%rowtype,
    p_usuario    in number,
    p_gerarcarga in varchar2
  ) return number is
  
    v_carga           number;
    v_kminicial       number;
    v_motorista       number;
    v_idenderecodoca  number;
    v_listaNotaFiscal pk_carga.tIdNotaFiscal;
    index_i           number;
  
    function podeInserirCarga(p_idromaneio in number) return boolean is
      v_qtde number;
    begin
      select sum(qtde)
        into v_qtde
        from (select count(o.idordemservico) qtde
                 from ordemservico o
                where o.idromaneio = p_idromaneio
               union
               select count(nf.idnotafiscal) qtde
                 from nfromaneio nfr, notafiscal nf
                where nf.idinventario is not null
                  and nf.idnotafiscal = nfr.idnotafiscal
                  and nfr.idromaneio = p_idromaneio);
    
      return v_qtde = 0;
    end;
  begin
    v_carga := null;
  
    if podeInserirCarga(p_romaneio.idromaneio) then
      begin
        select v.kmatual
          into v_kminicial
          from veiculo v
         where placa = p_romaneio.placa;
      exception
        when others then
          v_kminicial := 0;
      end;
    
      -- seleciona o motorista padrao pro veiculo
      v_motorista := pk_veiculo.pegar_idmotorista(p_romaneio.placa);
    
      begin
        select d.idendereco
          into v_idenderecodoca
          from doca d
         where d.iddoca = p_romaneio.iddoca;
      exception
        when others then
          v_idenderecodoca := null;
      end;
    
      index_i := 1;
    
      if (pk_carga.isColetaAutomatica(null, p_romaneio.idromaneio, null)) then
        for adicionar_nf in (select nfr.idnotafiscal
                               from nfromaneio nfr, notafiscal nf,
                                    depositante d
                              where nfr.idromaneio = p_romaneio.idromaneio
                                and nf.idnotafiscal = nfr.idnotafiscal
                                and d.identidade = nf.iddepositante
                                and d.tipocoleta = 1)
        loop
          v_listaNotaFiscal(index_i) := adicionar_nf.idnotafiscal;
          index_i := index_i + 1;
        end loop;
      
        pk_carga.gerarColetaAutomatica(v_listaNotaFiscal, p_usuario);
      
      elsif p_gerarcarga = 'S' then
        select seq_carga.nextval
          into v_carga
          from dual;
      
        insert into carga
          (idcarga, liberado, data, tipoentrega, tipocarga, idarmazem,
           iddoca, idlocaldoca, idusuario, placa, codigointerno, kminicial,
           finalizado, idmotorista, cadastro)
        values
          (v_carga, c_normal, sysdate, c_normal, c_normal,
           p_romaneio.idarmazem, p_romaneio.iddoca, v_idenderecodoca,
           p_usuario, p_romaneio.placa, p_romaneio.codigointerno,
           v_kminicial, c_nao, v_motorista, 'A');
      
      end if;
    
      if v_carga = 0 then
        v_carga := null;
      end if;
    end if;
  
    return v_carga;
  end;

  function pegar_romaneios(p_coleta in number) return varchar2 is
    cursor c_coleta(p_coleta in number) is
      select distinct r.codigointerno
        from carga c, notafiscalcarga nfc,
             (select idnotafiscal, max(idromaneio) idromaneio
                 from nfromaneio
                group by idnotafiscal) nfr, romaneiopai r
       where r.idromaneio = nfr.idromaneio
         and nfr.idnotafiscal = nfc.idnotafiscal
         and nfc.idcarga = c.idcarga
         and c.idcarga = p_coleta;
  
    r_coleta c_coleta%rowtype;
    v_campo  varchar2(255);
    S        varchar2(10000);
  begin
    if c_coleta%isopen then
      close c_coleta;
    end if;
    open c_coleta(p_coleta);
    fetch c_coleta
      into r_coleta;
    if c_coleta%found then
      while c_coleta%found
      loop
        v_campo := r_coleta.codigointerno;
      
        if S is null then
          S := v_campo;
        else
          S := S || ',' || v_campo;
        end if;
        fetch c_coleta
          into r_coleta;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
   * Retorna o id das NFs para o Destinatario no romaneio
  */
  function Retornar_idNF_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct nf.idnotafiscal
        from nfromaneio nfr, notafiscal nf
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
  
    r_nf c_nf%rowtype;
    v_nf varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nf is null then
          v_nf := r_nf.idnotafiscal;
        else
          v_nf := v_nf || ',' || r_nf.idnotafiscal;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nf;
    else
      return '';
    end if;
  end;

  /*
   * Retorna o codigo das NFs para o Destinatario no romaneio
  */
  function Retornar_NF_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct decode(ni.tiponf, 'P', nf.numpedidofornecedor,
                              nf.codigointerno) codigointerno
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf c_nf%rowtype;
    v_nf varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nf is null then
          v_nf := r_nf.codigointerno;
        else
          v_nf := v_nf || ',' || r_nf.codigointerno;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nf;
    else
      return '';
    end if;
  end;

  /*
   * Retorna o nome das transportadoras para o Destinatario no romaneio
  */
  function Retornar_Transp_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct e.razaosocial
        from nfromaneio nfr, notafiscal nf, entidade e
       where e.identidade = nf.transportadoranotafiscal
         and nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
  
    r_nf c_nf%rowtype;
    v_nf varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nf is null then
          v_nf := r_nf.razaosocial;
        else
          v_nf := v_nf || ',' || r_nf.razaosocial;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nf;
    else
      return '';
    end if;
  end;

  /*
   * Verifica se existe algum item das nfs com qtde atendida nula
  */
  procedure checar_nf_qtdeatendida(p_romaneio in number) is
    cursor c_nfd(p_romaneio in number) is
      select distinct nf.codigointerno
        from nfdet nd, nfromaneio nfr, notafiscal nf
       where nf.idnotafiscal = nd.nf
         and nfr.idromaneio = p_romaneio
         and nd.nf = nfr.idnotafiscal
         and nd.qtdeatendida is null;
  
    r_nfd c_nfd%rowtype;
    v_nf  varchar2(20000);
    v_msg t_message;
  begin
    if c_nfd%isopen then
      close c_nfd;
    end if;
    open c_nfd(p_romaneio);
    fetch c_nfd
      into r_nfd;
    if c_nfd%found then
      while c_nfd%found
      loop
        if v_nf is null then
          v_nf := r_nfd.codigointerno;
        else
          v_nf := v_nf || ',' || r_nfd.codigointerno;
        end if;
        fetch c_nfd
          into r_nfd;
      end loop;
      v_msg := t_message('Erro ao Gerar o Romaneio, Existem Produtos Com a Qtde Atendida Nula.' ||
                         chr(13) || 'Nota(s) Fiscal(is): {0}');
      v_msg.addParam(v_nf);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  /*
   * Funcao que retornas as Rotas vinculadas a NF
  */
  function Retornar_Rota(p_idententrega in number) return varchar2 is
    cursor c_rota(p_idententrega in number) is
      select distinct nvl(codigo, 'Codigo nao cadastrado') codigo
        from rotas r, rotacliente rc
       where rc.idrota = r.idrota
         and rc.identidade = p_idententrega;
    r_rota c_rota%rowtype;
    v_rota varchar2(2000) := NULL;
  begin
    if c_rota%isopen then
      close c_rota;
    end if;
    open c_rota(p_idententrega);
    fetch c_rota
      into r_rota;
    if c_rota%found then
      while c_rota%found
      loop
        if v_rota is null then
          v_rota := r_rota.codigo;
        else
          v_rota := v_rota || ', ' || r_rota.codigo;
        end if;
        fetch c_rota
          into r_rota;
      end loop;
      return v_rota;
    else
      return '';
    end if;
  end;

  /*
   * Funcao que retorna as Pre-cargas vinculadas a NF
  */
  function Retornar_PreCarga(p_idententrega in number) return varchar2 is
    cursor c_pre(p_idententrega in number) is
      select p.descr
        from rotas r, rotacliente rc, precargarota pr, precarga p
       where p.idprecarga = pr.idprecarga
         and pr.idrota = r.idrota
         and rc.idrota = r.idrota
         and rc.identidade = p_idententrega;
    r_pre c_pre%rowtype;
    v_pre varchar2(2000) := NULL;
  begin
    if c_pre%isopen then
      close c_pre;
    end if;
    open c_pre(p_idententrega);
    fetch c_pre
      into r_pre;
    if c_pre%found then
      while c_pre%found
      loop
        if v_pre is null then
          v_pre := r_pre.descr;
        else
          v_pre := v_pre || ', ' || r_pre.descr;
        end if;
        fetch c_pre
          into r_pre;
      end loop;
      return v_pre;
    else
      return '';
    end if;
  end;

  /*
   * Funcao que retorna a data maxima da separacao do romaneio
  */
  function Retornar_DtMaxSep(p_idromaneio in number) return date is
    cursor c_psep(p_idromaneio in number) is
      select max(dtfim) data
        from paletseparacao
       where idromaneio = p_idromaneio;
    r_psep c_psep%rowtype;
  begin
    if c_psep%isopen then
      close c_psep;
    end if;
    open c_psep(p_idromaneio);
    fetch c_psep
      into r_psep;
    return r_psep.data;
  end;

  /*
   * Funcao que retorna a data maxima da conferencia liberada
  */
  function Retornar_DtMaxConf(p_idromaneio in number) return date is
    cursor c_conf(p_idromaneio in number) is
      select max(datahora) data
        from confpalet
       where idromaneio = p_idromaneio
         and liberado = 'S';
  
    r_conf c_conf%rowtype;
  begin
    if c_conf%isopen then
      close c_conf;
    end if;
    open c_conf(p_idromaneio);
    fetch c_conf
      into r_conf;
    return r_conf.data;
  end;

  /*
   * Atualiza na nf a qtde atendida em funcao do corte de algum
   * produto na formacao de carga
  */
  procedure ZerarQtdeAtendidaNF
  (
    p_romaneio in number,
    p_produto  in number,
    p_estado   lote.estado%type
  ) is
  
  begin
    /*  
    N - Cancela Toda a Nota Fiscal, 
    I - Cancela Somente o Item, 
    Q - Libera somente a qtde disponivel em estoque.
    */
  
    for c_nf in (select nf.idprenf, nf.idnotafiscal, nfd.idproduto,
                        decode(d.tipocorte, 'N', null, nfd.barra) barra,
                        sum(nfd.qtde) qtde,
                        sum(nfd.qtde * e.fatorconversao) qtdeunit,
                        e.fatorconversao, d.tipocorte, p.descr
                   from nfromaneio nfr, notafiscal nf, nfdet nfd, produto p,
                        embalagem e, depositante d
                  where d.identidade = nf.iddepositante
                    and e.barra = nfd.barra
                    and e.idproduto = nfd.idproduto
                    and p.idproduto = nfd.idproduto
                    and nfd.idproduto = p_produto
                    and nfd.nf = nf.idnotafiscal
                    and nf.idnotafiscal = nfr.idnotafiscal
                    and nfr.idromaneio = p_romaneio
                  group by nf.idprenf, nfd.idproduto,
                           decode(d.tipocorte, 'N', null, nfd.barra),
                           e.fatorconversao, d.tipocorte, nf.idnotafiscal,
                           p.descr)
    loop
      if c_nf.tipocorte = 'N' then
        for c_nota in (select nf.idprenf, nfd.nf, nfd.idproduto,
                              decode(c_nf.tipocorte, 'N', null, nfd.barra) barra,
                              sum(nfd.qtde) qtde,
                              sum(nfd.qtde * e.fatorconversao) qtdeunit,
                              e.fatorconversao, nf.iddepositante
                         from nfromaneio nfr, notafiscal nf, nfdet nfd,
                              embalagem e
                        where e.barra = nfd.barra
                          and e.idproduto = nfd.idproduto
                          and nfd.nf = nf.idnotafiscal
                          and nf.idnotafiscal = c_nf.idnotafiscal
                          and nf.idnotafiscal = nfr.idnotafiscal
                          and nfr.idromaneio = p_romaneio
                        group by nf.idprenf, nfd.nf, nfd.idproduto,
                                 decode(c_nf.tipocorte, 'N', null, nfd.barra),
                                 e.fatorconversao, nf.iddepositante)
        loop
          update romaneio
             set qtdeaseparar = qtdeaseparar - c_nota.qtde
           where idromaneio = p_romaneio
             and idproduto = c_nota.idproduto
             and qtdeaseparar > 0;
        
          for c_prod in (select distinct pp.idpalet, rp.idarmazem
                           from romaneiopai rp, produtopalet pp
                          where rp.idromaneio = p_romaneio
                            and pp.idproduto = c_nota.idproduto
                            and pp.idromaneio = rp.idromaneio
                            and pp.iddepositante = c_nota.iddepositante)
          loop
            inserir_corte_romaneio(p_romaneio, c_prod.idpalet,
                                   c_prod.idarmazem, c_nota.iddepositante,
                                   c_nota.idproduto, c_nota.barra,
                                   c_nota.qtdeunit, p_estado,
                                   'CORTE DO PRODUTO ID:' || p_produto ||
                                    ' DESCR.:' || c_nf.descr ||
                                    ' OCASIONOU CORTE TOTAL DA NOTA ID:' ||
                                    c_nf.idnotafiscal);
          end loop;
        end loop;
      
        update nfdet
           set qtdeatendida = 0
         where nf = c_nf.idnotafiscal;
      
        update nfdetimpressao
           set qtdeatendida = 0
         where idprenf = c_nf.idprenf;
      
        --Desabilitar a validação alteração do status roteirização
        if isOrdemServico(p_romaneio) then
          pk_triggers_control.disableTrigger('t_alterar_nf');
        end if;
      
        update notafiscal n
           set estoqueverificado  = c_cancelado,
               dataverificacao    = sysdate,
               motivocorte        = 'CORTE PELO ROMANEIO ' || p_romaneio,
               statusroteirizacao = 0
         where idnotafiscal = c_nf.idnotafiscal;
      
        pk_triggers_control.enableTrigger('t_alterar_nf');
      
      else
        pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
      
        update romaneio
           set qtdeaseparar = qtdeaseparar - c_nf.qtde
         where idromaneio = p_romaneio
           and idproduto = p_produto
           and qtdeaseparar > 0;
      
        update nfdet
           set qtdeatendida = 0
         where nf = c_nf.idnotafiscal
           and idproduto = p_produto
           and barra = c_nf.barra;
      
        update nfdetimpressao
           set qtdeatendida = 0
         where idprenf = c_nf.idprenf
           and barra = c_nf.barra;
        pk_triggers_control.enableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
      end if;
    end loop;
  
    -- apaga os produtos q estao sem qtde
    delete from romaneio
     where idromaneio = p_romaneio
       and idproduto = p_produto
       and nvl(qtdeaseparar, 0) <= 0;
  
    -- retira as notas fiscais que nao atendeu nenhum item do romaneio
    for c_nfrom in (select d.nf, nf.iddepositante
                      from nfdet d, nfromaneio nr, notafiscal nf
                     where nr.idromaneio = p_romaneio
                       and nf.idnotafiscal = nr.idnotafiscal
                       and d.nf = nf.idnotafiscal
                     group by d.nf, nf.iddepositante
                    having sum(d.qtdeatendida) = 0)
    loop
      -- v_romaneio := p_romaneio;
    
      --Desabilitar a validação alteração do status roteirização
      if isOrdemServico(p_romaneio) then
        pk_triggers_control.disableTrigger('t_alterar_nf');
      end if;
    
      update notafiscal n
         set estoqueverificado  = c_cancelado,
             dataverificacao    = sysdate,
             motivocorte        = 'CORTE PELO ROMANEIO ' || p_romaneio,
             statusroteirizacao = 0
       where idnotafiscal = c_nfrom.nf;
    
      if pk_triggers_control.isTriggerDisable('t_alterar_nf') then
        pk_triggers_control.enableTrigger('t_alterar_nf');
      end if;
    
    end loop;
  end;

  /*
   * Rotina que exclui os palets
  */
  procedure excluir_pallet_separacao
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
  begin
    for c in (select idarmazem, idlocal, idlote, sum(qtdeunit) qtde
                from paletseparacao
               where idromaneio = p_romaneio
               group by idarmazem, idlocal, idlote)
    loop
      -- atualiza a pendencia de estoque.
      pk_estoque.retirar_pendencia(c.idarmazem, c.idlocal, c.idlote, c.qtde,
                                   p_usuario,
                                   'retirado pendencia ref. romaneio ID: ' ||
                                    p_romaneio);
    
    end loop;
  
    -- apaga as informações de lotes separados por nota fiscal
    delete paletseparacaonf
     where idromaneio = p_romaneio;
  
    delete from paletseparacao
     where idromaneio = p_romaneio;
  
    delete from paletseparacaocliente
     where idromaneio = p_romaneio;
  end;

  /*
   * Rotina que exclui a  tabela lotepallet
  */
  procedure excluir_lotepallet
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
  begin
    for c in (select ll.idarmazem, ll.idlocal, ll.idlote, sum(lp.qtde) qtde
                from palet p, lotepallet lp, lotelocal ll
               where p.idromaneio = p_romaneio
                 and lp.idpallet = p.id
                 and ll.idlotelocal = lp.idlotelocal
               group by ll.idarmazem, ll.idlocal, ll.idlote)
    loop
      -- atualiza a pendencia de estoque.
      pk_estoque.retirar_pendencia(c.idarmazem, c.idlocal, c.idlote, c.qtde,
                                   p_usuario,
                                   'retirado pendencia ref. romaneio ID: ' ||
                                    p_romaneio);
    
    end loop;
  
    delete from lotepallet
     where idpallet in (select id
                          from palet
                         where idromaneio = p_romaneio);
  end;

  procedure desfazerreentrega
  (
    p_idocorrenciaentrega in number,
    p_usuario             in number
  ) is
    cursor c_ocorrenciaentrega(p_ocorr in number) is
      select idnotafiscal, idromaneioreentrega, idlotenf, finalizado
        from ocorrenciaentrega
       where idocorrenciaentr = p_ocorr;
  
    cursor c_or(p_idlotenf in number) is
      select idlotenf, flaglibnf
        from lotenf
       where idlotenf = p_idlotenf;
  
    r_ocorrenciaentrega c_ocorrenciaentrega%rowtype;
    r_or                c_or%rowtype;
    v_numocorrencia     number;
    v_msg               t_message;
  begin
    if c_ocorrenciaentrega%isopen then
      close c_ocorrenciaentrega;
    end if;
    open c_ocorrenciaentrega(p_idocorrenciaentrega);
    fetch c_ocorrenciaentrega
      into r_ocorrenciaentrega;
    if c_ocorrenciaentrega%found then
      if r_ocorrenciaentrega.finalizado = C_NAO then
        -- verifica se existem mais de uma ocorrencia para o mesmo romaneio
        select count(nvl(idocorrenciaentr, 0))
          into v_numocorrencia
          from ocorrenciaentrega
         where idromaneioreentrega =
               r_ocorrenciaentrega.idromaneioreentrega;
        if v_numocorrencia > 1 then
          v_msg := t_message('Este romaneio nao pode ser desfeito, pois possui mais de uma ocorrencia vinculada.');
          raise_application_error(-20345, v_msg.formatMessage);
        elsif v_numocorrencia = 1 then
          -- desfazendo romaneio de reentrega
          update ocorrenciaentrega
             set idromaneioreentrega = null
           where idocorrenciaentr = p_idocorrenciaentrega;
          desfazer_romaneio(r_ocorrenciaentrega.idromaneioreentrega,
                            p_usuario, c_sim);
        end if;
        -- voltando situacao da nota fiscal
        update notafiscal
           set statusnf           = C_PROCESSADO,
               reentrega          = C_NAO,
               statusroteirizacao = 2
         where idnotafiscal = r_ocorrenciaentrega.idnotafiscal;
      
        if c_or%isopen then
          close c_or;
        end if;
        open c_or(r_ocorrenciaentrega.idlotenf);
        fetch c_or
          into r_or;
        if r_or.flaglibnf = 0 then
          pk_recebimento.Desfazer_or(r_ocorrenciaentrega.idlotenf,
                                     p_usuario);
        
        elsif r_or.flaglibnf = 1
              or r_or.flaglibnf = 2 then
          v_msg := t_message('A OR nao pode ser desfeita pois ja existe conferencia.');
          raise_application_error(-20345, v_msg.formatMessage);
        end if;
        -- excluindo ocorrencia
        delete from ocorrenciaentrega
         where idocorrenciaentr = p_idocorrenciaentrega;
      end if;
    end if;
  end;

  /*
   * Rotina que cancela a NF caso a somatoria da Qtde atendida for 0 (Zero)
  */
  procedure CancelarNFCorteTotal
  (
    p_idromaneio in number,
    p_idusuario  in number
  ) is
  begin
    for c_nf in (select nf.idnotafiscal, nf.idprenf
                   from notafiscal nf, nfdet nfd, nfromaneio nfr
                  where nfd.nf = nf.idnotafiscal
                    and nf.idnotafiscal = nfr.idnotafiscal
                    and nfr.idromaneio = p_idromaneio
                  group by nf.idnotafiscal, nf.idprenf
                 having sum(nfd.qtdeatendida) = 0)
    loop
      update notafiscal nf
         set nf.statusnf           = C_CANCELADO,
             nf.idusuariocanc      = p_idusuario,
             datacancelamento      = sysdate,
             nf.motivocorte        = 'CANCELADO PELO WMS - CORTE TOTAL DOS PRODUTOS',
             nf.statusroteirizacao = 0
       where idnotafiscal = c_nf.idnotafiscal;
    
      update nfimpressao
         set status                = C_CANCELADO,
             motivocancelamento    = 'CANCELADO PELO WMS - CORTE TOTAL DOS PRODUTOS',
             datacancelamento      = sysdate,
             idusuariocancelamento = p_idusuario
       where idprenf = c_nf.idprenf;
    
      update nfimpressao
         set statusdoc = 10
       where idprenf = c_nf.idprenf;
    end loop;
  end;

  /*
   * Func?o que Retorna sequencia maxima da nfromaneio
  */

  function RetornarOrdemEntregaMaxima(p_romaneio in number) return number is
    cursor c_seq_max(p_romaneio in number) is
      select max(sequencia) + 1
        from nfromaneio
       where idromaneio = p_romaneio;
  
    v_seq number;
  begin
    if c_seq_max%isopen then
      close c_seq_max;
    end if;
    open c_seq_max(p_romaneio);
    fetch c_seq_max
      into v_seq;
    if (c_seq_max%notfound)
       or (v_seq is null) then
      v_seq := 1;
    end if;
    close c_seq_max;
  
    return v_seq;
  end;

  /*
   * Funcao que Retorna sequencia da nfromaneio
  */
  function RetornarOrdemEntrega
  (
    p_romaneio in number,
    p_entidade in number
  ) return number is
    cursor c_seq
    (
      p_romaneio in number,
      p_entidade in number
    ) is
      select distinct sequencia
        from nfromaneio
       where idromaneio = p_romaneio
         and idnotafiscal in
             (select idnotafiscal
                from notafiscal
               where tipo = c_sim
                 and statusnf = c_carga
                 and ident_entrega = p_entidade);
    v_seq number;
  begin
    if c_seq%isopen then
      close c_seq;
    end if;
    open c_seq(p_romaneio, p_entidade);
    fetch c_seq
      into v_seq;
    close c_seq;
  
    return v_seq;
  end;

  /*
   * Rotina que retira NF da Carga
  */
  procedure retirarNFCarga
  (
    p_idromaneio   in number,
    p_idnotafiscal in number,
    p_idusuario    in number,
    p_idlotenf     out number
  ) is
  
    v_romaneio            romaneiopai.codigointerno%type;
    v_notafiscal          notafiscal.codigointerno%type;
    v_estado              notafiscal.estado%type;
    v_faturado            romaneiopai.faturado%type;
    v_idcarga             number;
    v_qtderestante        number;
    r_romaneiopai         romaneiopai%rowtype;
    v_idromaneio          number;
    v_doca                doca%rowtype;
    v_veiculo             veiculo.placa%type;
    v_idnotafiscalretorno number;
    v_idnotafiscal        notafiscal.idnotafiscal%type;
    v_msg                 t_message;
  
    procedure getDadosNotaFiscal
    (
      p_idromaneio   in number,
      p_idnotafiscal in number,
      p_romaneio     out romaneiopai.codigointerno%type,
      p_notafiscal   out notafiscal.codigointerno%type,
      p_estado       out notafiscal.estado%type,
      p_faturado     out romaneiopai.faturado%type,
      p_idarmazem    out romaneiopai.idarmazem%type,
      p_iddoca       out romaneiopai.iddoca%type,
      p_idlocal      out romaneiopai.idlocal%type,
      p_placa        out romaneiopai.placa%type,
      p_idcarga      out number
    ) is
    begin
      select rp.codigointerno, nf.codigointerno, nf.estado, rp.faturado,
             rp.idarmazem, rp.iddoca, rp.idlocal, rp.placa,
             nvl(cr.idcarga, 0) idcarga
        into p_romaneio, p_notafiscal, p_estado, p_faturado, p_idarmazem,
             p_iddoca, p_idlocal, p_placa, p_idcarga
        from nfromaneio nfr, romaneiopai rp, notafiscal nf, cargaromaneio cr
       where cr.idromaneio(+) = nfr.idromaneio
         and cr.idnotafiscal(+) = nfr.idnotafiscal
         and nf.idnotafiscal = nfr.idnotafiscal
         and rp.idromaneio = nfr.idromaneio
         and nfr.idromaneio = p_idromaneio
         and nfr.idnotafiscal = p_idnotafiscal;
    exception
      when no_data_found then
        v_msg := t_message('Nota Fiscal não foi encontrada no Romaneio.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    procedure temConhecimentoEntronico(p_idnotafiscal in number) is
      v_cargasconheletronico varchar2(400);
    begin
      select stragg(idcarga)
        into v_cargasconheletronico
        from (select distinct idcarga
                 from conhecimentoeletronico c, conhecimentoeletroniconf cnf
                where c.status in (1, 2, 3)
                  and cnf.idconhecimento = c.id
                  and cnf.idnotafiscal = p_idnotafiscal);
    
      if v_cargasconheletronico is not null then
        v_msg := t_message('As cargas {0}' ||
                           ' possuem conhecimento de transporte (CTE), por favor cancele o conhecimento de transporte para desfazer o romaneio.');
        v_msg.addParam(v_cargasconheletronico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    function podeRetirarNF
    (
      p_idromaneio   in number,
      p_idnotafiscal in number
    ) return boolean is
      v_qtdenf number;
    begin
      select count(idnotafiscal)
        into v_qtdenf
        from nfromaneio
       where idromaneio = p_idromaneio
         and idnotafiscal <> p_idnotafiscal;
    
      return v_qtdenf > 0;
    end;
  
    -- Refactored procedure retirarProdutoPalet 
    procedure retirarProdutoPalet
    (
      p_idromaneio    in number,
      p_iddepositante in number,
      p_identidade    in number,
      p_idproduto     in number,
      p_barra         in embalagem.barra%type,
      p_qtde          in number
    ) is
      v_qtderestante        number;
      v_qtde                number;
      v_qtdeproduto         number;
      v_qtdeembalagem       number;
      v_embalagemencontrada boolean;
    begin
      v_qtderestante := p_qtde;
    
      for c_produtopalet in (select pp.idpalet, pp.iddepositante,
                                    pp.identidade, pp.idproduto, pp.barra,
                                    pp.qtde, e.fatorconversao,
                                    round(pp.qtde * e.fatorconversao) qtdeunitaria
                               from produtopalet pp, embalagem e, produto p
                              where p.idproduto = e.idproduto
                                and e.barra = pp.barra
                                and e.idproduto = pp.idproduto
                                and pp.identidade = p_identidade
                                and pp.iddepositante = p_iddepositante
                                and pp.barra = nvl(p_barra, pp.barra)
                                and pp.idproduto = p_idproduto
                                and pp.idromaneio = p_idromaneio
                              order by pp.idpalet, e.fatorconversao)
      loop
        if c_produtopalet.qtdeunitaria > v_qtderestante then
          v_qtde := v_qtderestante;
        
          if c_produtopalet.fatorconversao = 1 then
            update produtopalet
               set qtde = qtde - v_qtde
             where barra = c_produtopalet.barra
               and idproduto = c_produtopalet.idproduto
               and identidade = c_produtopalet.identidade
               and iddepositante = c_produtopalet.iddepositante
               and idpalet = c_produtopalet.idpalet
               and idromaneio = p_idromaneio;
          else
            v_qtdeproduto := c_produtopalet.qtdeunitaria - v_qtderestante;
          
            delete from produtopalet
             where barra = c_produtopalet.barra
               and idproduto = c_produtopalet.idproduto
               and identidade = c_produtopalet.identidade
               and iddepositante = c_produtopalet.iddepositante
               and idpalet = c_produtopalet.idpalet
               and idromaneio = p_idromaneio;
          
            while v_qtdeproduto > 0
            loop
              getQtdeEmbalagem(c_produtopalet.idproduto, null,
                               v_qtdeproduto, v_qtdeembalagem,
                               v_embalagemencontrada);
            
              inserir_produto_palet(p_idromaneio, c_produtopalet.idpalet,
                                    c_produtopalet.iddepositante,
                                    c_produtopalet.identidade,
                                    c_produtopalet.idproduto,
                                    r_embalagem.barra, v_qtdeembalagem);
            
              v_qtdeproduto := v_qtdeproduto - (v_qtdeembalagem *
                               r_embalagem.fatorconversao);
            end loop;
          end if;
        else
          v_qtde := c_produtopalet.qtdeunitaria;
        
          delete from produtopalet
           where barra = c_produtopalet.barra
             and idproduto = c_produtopalet.idproduto
             and identidade = c_produtopalet.identidade
             and iddepositante = c_produtopalet.iddepositante
             and idpalet = c_produtopalet.idpalet
             and idromaneio = p_idromaneio;
        end if;
      
        v_qtderestante := v_qtderestante - v_qtde;
      
        exit when v_qtderestante = 0;
      end loop;
    end;
  
    procedure retirarPaletSeparacao
    (
      p_idromaneio    in number,
      p_idnotafiscal  in number,
      p_iddepositante in number,
      p_idproduto     in number,
      p_barra         in embalagem.barra%type,
      p_qtde          in number
    ) is
      v_qtderestante number;
      v_qtde         number;
    begin
      v_qtderestante := p_qtde;
    
      for c_paletseparacao in (select ps.idpalet, l.iddepositante,
                                      ps.idarmazem, ps.idlocal, ps.idlote,
                                      ps.idproduto, ps.barra, ps.qtde,
                                      ps.qtdeunit qtdeunitaria, ps.idusuario,
                                      ps.ordem, ps.dtinicio, ps.dtfim,
                                      ps.separado, ps.processado, ps.liberado,
                                      e.fatorconversao
                                 from paletseparacao ps, lote l, embalagem e
                                where e.barra = ps.barra
                                  and e.idproduto = ps.idproduto
                                  and l.iddepositante = p_iddepositante
                                  and l.idlote = ps.idlote
                                  and ps.barra = nvl(p_barra, ps.barra)
                                  and ps.idproduto = p_idproduto
                                  and ps.idromaneio = p_idromaneio
                                order by ps.idpalet, ps.qtdeunit)
      loop
        if c_paletseparacao.qtdeunitaria > v_qtderestante then
          v_qtde := v_qtderestante;
        
          update paletseparacao
             set qtde     = qtde -
                            (v_qtde / c_paletseparacao.fatorconversao),
                 qtdeunit = qtdeunit - v_qtde
           where barra = c_paletseparacao.barra
             and idproduto = c_paletseparacao.idproduto
             and idlote = c_paletseparacao.idlote
             and idlocal = c_paletseparacao.idlocal
             and idarmazem = c_paletseparacao.idarmazem
             and idpalet = c_paletseparacao.idpalet
             and idromaneio = p_idromaneio;
        else
          v_qtde := c_paletseparacao.qtdeunitaria;
        
          delete from paletseparacao
           where barra = c_paletseparacao.barra
             and idproduto = c_paletseparacao.idproduto
             and idlote = c_paletseparacao.idlote
             and idlocal = c_paletseparacao.idlocal
             and idarmazem = c_paletseparacao.idarmazem
             and idpalet = c_paletseparacao.idpalet
             and idromaneio = p_idromaneio;
        end if;
      
        v_qtderestante := v_qtderestante - v_qtde;
      
        pk_estoque.retirar_pendencia(c_paletseparacao.idarmazem,
                                     c_paletseparacao.idlocal,
                                     c_paletseparacao.idlote, v_qtde,
                                     p_idusuario,
                                     'RETIRADA PENDENCIA PELA RETIRADA DA NOTA FISCAL ID: ' ||
                                      p_idnotafiscal || ' DO ROMANEIO ID: ' ||
                                      p_idromaneio);
      
        exit when v_qtderestante = 0;
      end loop;
    
    end;
  
    procedure retirarPaletSeparacaoCliente
    (
      p_idromaneio in number,
      p_identidade in number,
      p_idproduto  in number,
      p_barra      in embalagem.barra%type,
      p_qtde       in number
    ) is
      v_qtderestante        number;
      v_qtde                number;
      v_qtdeproduto         number;
      v_qtdeembalagem       number;
      v_embalagemencontrada boolean;
    begin
      v_qtderestante := p_qtde;
    
      for c_paletseparacao in (select psc.idpalet, psc.identidade,
                                      psc.idarmazem, psc.idlocal,
                                      psc.idproduto, psc.barra, psc.qtde,
                                      e.fatorconversao,
                                      psc.qtde * e.fatorconversao qtdeunitaria
                                 from paletseparacaocliente psc, embalagem e,
                                      produto p
                                where p.idproduto = e.idproduto
                                  and e.barra = psc.barra
                                  and e.idproduto = psc.idproduto
                                  and psc.identidade = p_identidade
                                  and psc.barra = nvl(p_barra, psc.barra)
                                  and psc.idproduto = p_idproduto
                                  and psc.idromaneio = p_idromaneio
                                order by psc.idpalet, e.fatorconversao)
      loop
        if c_paletseparacao.qtdeunitaria > v_qtderestante then
          v_qtde := v_qtderestante;
        
          if c_paletseparacao.fatorconversao = 1 then
            update paletseparacaocliente
               set qtde = qtde - v_qtde
             where barra = c_paletseparacao.barra
               and idproduto = c_paletseparacao.idproduto
               and identidade = c_paletseparacao.identidade
               and idlocal = c_paletseparacao.idlocal
               and idarmazem = c_paletseparacao.idarmazem
               and idpalet = c_paletseparacao.idpalet
               and idromaneio = p_idromaneio;
          else
            v_qtdeproduto := c_paletseparacao.qtdeunitaria - v_qtderestante;
          
            delete from paletseparacaocliente
             where barra = c_paletseparacao.barra
               and idproduto = c_paletseparacao.idproduto
               and identidade = c_paletseparacao.identidade
               and idlocal = c_paletseparacao.idlocal
               and idarmazem = c_paletseparacao.idarmazem
               and idpalet = c_paletseparacao.idpalet
               and idromaneio = p_idromaneio;
          
            while v_qtdeproduto > 0
            loop
              getQtdeEmbalagem(c_paletseparacao.idproduto, null,
                               v_qtdeproduto, v_qtdeembalagem,
                               v_embalagemencontrada);
            
              inserir_pallet_separacao_cli(p_idromaneio,
                                           c_paletseparacao.idpalet,
                                           c_paletseparacao.idarmazem,
                                           c_paletseparacao.idlocal,
                                           c_paletseparacao.idproduto,
                                           r_embalagem.barra,
                                           c_paletseparacao.identidade,
                                           v_qtdeembalagem);
            
              v_qtdeproduto := v_qtdeproduto - (v_qtdeembalagem *
                               r_embalagem.fatorconversao);
            end loop;
          end if;
        else
          v_qtde := c_paletseparacao.qtdeunitaria;
        
          delete from paletseparacaocliente
           where barra = c_paletseparacao.barra
             and idproduto = c_paletseparacao.idproduto
             and identidade = c_paletseparacao.identidade
             and idlocal = c_paletseparacao.idlocal
             and idarmazem = c_paletseparacao.idarmazem
             and idpalet = c_paletseparacao.idpalet
             and idromaneio = p_idromaneio;
        end if;
      
        v_qtderestante := v_qtderestante - v_qtde;
      
        exit when v_qtderestante = 0;
      end loop;
    end;
  
    function controlaAreaEspera(p_idnotafiscal in number) return boolean is
      v_controla char(2);
    begin
      select d.controlaareaespera || d.retirarnfromcontresp
        into v_controla
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and nf.idnotafiscal = p_idnotafiscal;
    
      return v_controla = 'SS';
    
    end;
  
  begin
    --verifica a nota de venda
    begin
      v_idnotafiscalretorno := p_idnotafiscal;
      select rs.idnotafiscalvenda
        into v_idnotafiscal
        from retornosimbolico rs
       where rs.idnotafiscalretorno = p_idnotafiscal;
    
      pk_notafiscal.desfazerNFRetArmazenagemRom(p_idromaneio,
                                                v_idnotafiscalretorno,
                                                p_idusuario, 'TA');
    exception
      when no_data_found then
        v_idnotafiscal := p_idnotafiscal;
    end;
  
    getDadosNotaFiscal(p_idromaneio, v_idnotafiscal, v_romaneio,
                       v_notafiscal, v_estado, v_faturado, v_doca.idarmazem,
                       v_doca.iddoca, v_doca.idendereco, v_veiculo,
                       v_idcarga);
  
    temConhecimentoEntronico(v_idnotafiscal);
  
    if podeRetirarNF(p_idromaneio, v_idnotafiscal) then
      -- pega os produtos que estao na nota fiscal a ser retirada
      for c_nf in (select nfd.idproduto, nfd.barra, p.codigointerno codprod,
                          p.descr produto, nf.ident_entrega, nf.iddepositante,
                          sum(nfd.qtdeatendida) qtdeatendida,
                          sum(nfd.qtdeatendida * e.fatorconversao) qtde,
                          decode(p.otimizaseparacao || p.fracionado, 'SN',
                                  null, nfd.barra) barraotimizada
                     from notafiscal nf, nfdet nfd, embalagem e, produto p
                    where p.idproduto = nfd.idproduto
                      and e.idproduto = nfd.idproduto
                      and e.barra = nfd.barra
                      and nfd.nf = nf.idnotafiscal
                      and nfd.qtdeatendida > 0
                      and nf.idnotafiscal = v_idnotafiscal
                    group by nfd.nf, nfd.idproduto, nfd.barra,
                             p.codigointerno, p.descr, nf.ident_entrega,
                             nf.iddepositante,
                             decode(p.otimizaseparacao || p.fracionado, 'SN',
                                     null, nfd.barra))
      loop
        -- subtrai a qtde do romaneio
        update romaneio
           set qtdeaseparar = qtdeaseparar - c_nf.qtdeatendida
         where barra = c_nf.barra
           and idproduto = c_nf.idproduto
           and idromaneio = p_idromaneio;
      
        retirarProdutoPalet(p_idromaneio, c_nf.iddepositante,
                            c_nf.ident_entrega, c_nf.idproduto,
                            c_nf.barraotimizada, c_nf.qtde);
      
        retirarPaletSeparacao(p_idromaneio, v_idnotafiscal,
                              c_nf.iddepositante, c_nf.idproduto,
                              c_nf.barraotimizada, c_nf.qtde);
      
        retirarPaletSeparacaoCliente(p_idromaneio, c_nf.ident_entrega,
                                     c_nf.idproduto, c_nf.barraotimizada,
                                     c_nf.qtde);
      
      end loop;
    
      recalcularQtdePaletSeparacao(p_idromaneio);
      ordenar_palet_separacao(p_idromaneio);
    
      delete from romaneio
       where idromaneio = p_idromaneio
         and qtdeaseparar = 0;
    
      delete from cargaromaneio
       where idromaneio = p_idromaneio
         and idnotafiscal = v_idnotafiscal;
    
      delete from notafiscalcarga
       where idnotafiscal = v_idnotafiscal
         and idcarga = v_idcarga;
    
      update nfimpressao nfi
         set nfi.statusdoc = 12
       where nfi.idprenf in
             (select nf.idprenf
                from notafiscal nf
               where nf.idnotafiscal = v_idnotafiscal);
    
      delete from nfromaneio
       where idnotafiscal = v_idnotafiscal
         and idromaneio = p_idromaneio;
    
      update notafiscal
         set iddoca             = null,
             placaveiculo       = null,
             statusroteirizacao = 1
       where idnotafiscal = v_idnotafiscal;
    
      identificarlotes(p_idromaneio);
    
      r_romaneiopai := carregar_romaneio(p_idromaneio);
    
      VerificaNFRomaneio(r_romaneiopai);
    
      AtualizarRomaneio(r_romaneiopai);
    
      if not verificarDivergenciaSaida(p_idromaneio) then
        -- Verifica divergencia entre as notas e a paletseparacao
      
        v_msg := t_message('O ROMANEIO ID: {0} NÃO PODE SER PROCESSADO. ' ||
                           'POIS EXISTEM DIVERGENCIAS ENTRE A QUANTIDADE SEPARADA' ||
                           ' E A QUANTIDADE SOLICITADA.');
        v_msg.addParam(p_idromaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if controlaAreaEspera(v_idnotafiscal) then
        -- cria romaneio para baixar o estoque dos produtos da nf, 
        -- pois vai ser necessario entrar com ela novamente no estoque atraves de conferencia
        inserir_nfromaneio_notafiscal(v_idromaneio, v_idnotafiscal,
                                      p_idusuario, 'N');
      
        update romaneiopai
           set idarmazem      = v_doca.idarmazem,
               iddoca         = v_doca.iddoca,
               idlocal        = v_doca.idendereco,
               placa          = v_veiculo,
               faturado       = v_faturado,
               tituloromaneio = 'RETIRADA DE NOTA FISCAL DO ROMANEIO' ||
                                v_romaneio
         where idromaneio = v_idromaneio;
      
        r_romaneiopai := carregar_romaneio(v_idromaneio);
      
        formarRomaneioNormal(r_romaneiopai, p_idusuario, 'N', 'N', 'S', 'X',
                             'S', 'S', 'S');
      
        pk_confsaida.gerarcontagem(v_idromaneio, p_idusuario);
      
        processar_romaneio(v_idromaneio, p_idusuario);
      
        -- Cria OR e vincula a NF
        pk_recebimento.criar_or_vincularnf(v_idnotafiscal, p_idusuario,
                                           'RETIRADA DA NF ' ||
                                            v_notafiscal || ' DO ROMANEIO: ' ||
                                            v_romaneio, p_idlotenf, 'N');
      end if;
    
      pk_utilities.GeraLog(p_idusuario,
                           'RETIRADA A NOTA FISCAL ' || v_notafiscal ||
                            ' DE IDNOTAFISCAL: ' || v_idnotafiscal ||
                            ' DO ROMANEIO ' || v_romaneio ||
                            ' DE IDROMANEIO: ' || p_idromaneio,
                           v_idnotafiscal, 'RN');
    
    else
      v_msg := t_message('A Nota Fiscal {0} de idNotaFiscal: {1}' ||
                         ' é a unica do romaneio e não pode ser retirada. Para retirá-la desfaça o Romaneio: ' ||
                         '{2} de idRomaneio: {3}');
      v_msg.addParam(v_notafiscal);
      v_msg.addParam(v_idnotafiscal);
      v_msg.addParam(v_romaneio);
      v_msg.addParam(p_idromaneio);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  /*
  * Cria os Romaneio baseado no Retorno dos Pacotes do Sistema Roterizador
  */
  procedure FormarRomaneioPacote
  (
    p_idpacote    in number,
    p_numromaneio in number,
    p_idusuario   in number,
    p_armazem     in number,
    p_doca        in number,
    p_idlocal     in number
  ) is
    cursor c_veiculo(p_placa in veiculo.placa%type) is
      Select placa
        from veiculo v
       where placa = p_placa;
  
    r_veiculo     c_veiculo%rowtype;
    r_romaneiopai romaneiopai%rowtype;
    v_idromaneio  number;
    v_msg         t_message;
  begin
    for c_romaneiopacote in (select distinct pn.numromaneio, pn.placaveiculo
                               from pacotenotafiscal pn, notafiscal nf
                              where nf.idnotafiscal = pn.idnotafiscal
                                and pn.numromaneio = p_numromaneio
                                and pn.idpacote = p_idpacote)
    loop
      -- cadastra o romaneiopai
      if c_romaneiopacote.numromaneio is null then
        v_msg := t_message('Informacoes do Pacote incompletas. Operacao Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
      if c_veiculo%isopen then
        close c_veiculo;
      end if;
      open c_veiculo(c_romaneiopacote.placaveiculo);
      fetch c_veiculo
        into r_veiculo;
      if c_veiculo%notfound then
        v_msg := t_message('Nao existe um veiculo cadastrado com a placa: {0}');
        v_msg.addParam(c_romaneiopacote.placaveiculo);
        raise_application_error(-20123, v_msg.formatMessage);
      end if;
      r_romaneiopai.idusuario := p_idusuario;
      r_romaneiopai.placa     := c_romaneiopacote.placaveiculo;
      r_romaneiopai.idarmazem := p_armazem;
      r_romaneiopai.iddoca    := p_doca;
      r_romaneiopai.idpacote  := p_idpacote;
      r_romaneiopai.idlocal   := p_idlocal;
      v_idromaneio            := inserir_romaneiopai(r_romaneiopai);
    
      -- Selecionar o as Nota Fiscais e Cargas Retornadas para o Pacote
      for c_pacotenf in (select pn.idnotafiscal, pn.ordementrega,
                                nf.destinatario, nf.iddepositante
                           from pacotenotafiscal pn, notafiscal nf
                          where nf.idnotafiscal = pn.idnotafiscal
                            and pn.numromaneio =
                                c_romaneiopacote.numromaneio
                            and pn.idpacote = p_idpacote
                            and pn.finalizado = 'N')
      loop
        if c_pacotenf.ordementrega is null then
          v_msg := t_message('Informacoes do Pacote incompletas. Operacao Cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
        -- insere as notas fiscais no romaneio baseadas na ordem de entraga indicada
        inserir_nfromaneio(v_idromaneio, c_pacotenf.destinatario,
                           c_pacotenf.idnotafiscal, p_idusuario,
                           c_pacotenf.ordementrega, c_nao);
        --atualiza que o romaneio foi formado
        pk_integracao.FinalizarPacoteNotaFiscal(p_idpacote,
                                                c_pacotenf.idnotafiscal);
      end loop;
      -- Gera o romaneio
      Formar_Romaneio(v_idromaneio, p_idusuario, 'S', 'N');
      -- Atualizando numero do romaneio
      update romaneiopai
         set codigointerno = c_romaneiopacote.numromaneio
       where idromaneio = v_idromaneio;
      -- Atualiza o numero da carga
      update carga
         set codigointerno = c_romaneiopacote.numromaneio
       where idcarga in (select idcarga
                           from romaneiopai
                          where idromaneio = v_idromaneio);
      -- Atualizando  numero do romaneio de reentrega
      update romaneiopai
         set codigointerno = c_romaneiopacote.numromaneio || 'R'
      
       where idcarga = (select idcarga
                          from romaneiopai
                         where idromaneio = v_idromaneio
                           and reentrega = c_nao)
         and reentrega = c_sim;
    end loop;
    FinalizaPacote(p_idpacote);
    commit;
  end;

  /*
  *Rotina que verifica se o pacote ja foi todo formado e finaliza o mesmo
  */
  procedure FinalizaPacote(p_idpacote in number) is
    v_restante number;
  begin
    for c in (select idnotafiscal
                from pacotenotafiscal pn
               where pn.idpacote = p_idpacote
                 and pn.numromaneio = '0'
                 and pn.finalizado = 'N')
    loop
      pk_integracao.FinalizarPacoteNotaFiscal(p_idpacote, c.idnotafiscal);
    end loop;
  
    select count(p.idnotafiscal) restante
      into v_restante
      from pacotenotafiscal p
     where p.idpacote = p_idpacote
       and nvl(p.finalizado, 'N') <> 'S';
    if v_restante = 0 then
      update pacote
         set situacao = 'F'
       where idpacote = p_idpacote;
    end if;
  end;

  /*
   * Rotina que verifica as notas do romaneio ja foram faturadas, processa as mesmas e fatura o romaneio
  */
  procedure VerificaNFRomaneio(p_romaneio in out romaneiopai%rowtype) is
    v_restante number;
  begin
    -- atualiza o status da Nota Fiscal para processada  
    update notafiscal
       set impresso = 'S'
     where idnotafiscal in
           (select nf.idnotafiscal
              from nfromaneio nfr, notafiscal nf, entidade e, operacao oper,
                   armazem a
             where nf.idnotafiscal = nfr.idnotafiscal
               and e.identidade = nf.remetente
               and oper.idoperacao = nf.idoperacao
               and a.idarmazem = nf.idarmazem
               and nfr.idromaneio = p_romaneio.idromaneio
               and ((nf.tiponf in ('N', 'E') and e.imprimenf = 'N' and
                   oper.tipooper <> 'G') or
                   (nf.iddepositante = nf.destinatario and
                   nf.remetente = a.identidade and oper.tipooper = 'TA' and
                   p_romaneio.tipo = 0)));
  
    update nfimpressao
       set situacaoimpressao = 'I'
     where idprenf in
           (select nf.idprenf
              from nfromaneio nfr, notafiscal nf, entidade e, operacao oper,
                   armazem a
             where nf.idnotafiscal = nfr.idnotafiscal
               and e.identidade = nf.remetente
               and oper.idoperacao = nf.idoperacao
               and a.idarmazem = nf.idarmazem
               and nfr.idromaneio = p_romaneio.idromaneio
               and ((nf.tiponf in ('N', 'E') and e.imprimenf = 'N') or
                   (nf.iddepositante = nf.destinatario and
                   nf.remetente = a.identidade and oper.tipooper = 'TA' and
                   p_romaneio.tipo = 0)));
  
    -- Atualizando o romaneio para faturado
    select count(nf.idnotafiscal) restante
      into v_restante
      from nfromaneio nfr, notafiscal nf
     where nvl(nf.impresso, 'N') <> 'S'
       and nf.idnotafiscal = nfr.idnotafiscal
       and nfr.idromaneio = p_romaneio.idromaneio;
  
    if v_restante = 0 then
      p_romaneio.faturado := 'S';
    end if;
  end;

  /*
   * Rotina que verifica as diferencas nas qtdes da nf com a que estao na Separacao especifica
  */
  procedure VerificaDiferencaQtde(p_romaneio in number) is
    cursor c_dif(p_romaneio in number) is
      select nf.nf, nf.idproduto, nf.qtdenf, nvl(sep.qtdesep, 0) qtdesep
        from (Select nfd.nf, nfd.idproduto,
                      sum(nfd.qtdeatendida * e.fatorconversao) qtdenf
                 from nfdet nfd, embalagem e
                where e.idproduto = nfd.idproduto
                  and e.barra = nfd.barra
                  and nfd.nf in
                      (Select distinct s.idnotafiscal
                         from separacaoespecifica s, nfromaneio nfr
                        where nfr.idromaneio = p_romaneio
                          and s.idnotafiscal = nfr.idnotafiscal)
                group by nfd.nf, nfd.idproduto) nf,
             (Select se.idnotafiscal, l.idproduto, sum(se.qtde) qtdesep
                 from nfromaneio nfr, separacaoespecifica se, lote l
                where l.idlote = se.idlote
                  and se.idnotafiscal = nfr.idnotafiscal
                  and nfr.idromaneio = p_romaneio
                group by se.idnotafiscal, l.idproduto) sep
       where sep.idnotafiscal(+) = nf.nf
         and sep.idproduto(+) = nf.idproduto
         and nf.qtdenf <> nvl(sep.qtdesep, 0);
    r_dif c_dif%rowtype;
  
    v_msg t_message;
  begin
    if c_dif%isopen then
      close c_dif;
    end if;
    open c_dif(p_romaneio);
    fetch c_dif
      into r_dif;
  
    if c_dif%found then
      v_msg := t_message('QTDE INFORMADA NA NOTA FISCAL DIFERENTE DA QTDE A SEPARAR.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  procedure CriarManifestoCarga
  (
    p_idcarga      in number,
    p_idnotafiscal in number
  ) is
  begin
    if p_idnotafiscal = 0 then
      insert into manifestocarga
        (idmanifesto, idromaneio, codcli, razaosocial, idcarga, data,
         identidade, descrpalet, seq_roma, obs, nfnumformulario, valor,
         pesob, formularios, volume, cidade, datageracao, totalpalet, modelo,
         depositante, tiponf, descrtiponf, somavalortiponf, tipodocumento,
         paginageomapa, placa, motorista, reentrega, sequencia, idnotafiscal)
        select seq_manifesto.nextval, v.idromaneio, v.codcli, v.razaosocial,
               v.idcarga, v.data, v.identidade, v.descrpalet, v.seq_roma,
               v.obs, v.nfnumformulario, v.valor, v.pesobruto, v.formularios,
               v.volume, v.cidade, v.datageracao, v.totalpalet, v.modelo,
               v.depositante, v.tiponf, v.descrtiponf, v.somavalortiponf,
               v.tipodocumento, v.paginageomapa, v.placa, v.motorista,
               v.reentrega, v.sequencia, v.idnotafiscal
          from v_manifesto_carga v
         where v.idcarga = p_idcarga;
    else
      insert into manifestocarga
        (idmanifesto, idromaneio, codcli, razaosocial, idcarga, data,
         identidade, descrpalet, seq_roma, obs, nfnumformulario, valor,
         pesob, formularios, volume, cidade, datageracao, totalpalet, modelo,
         depositante, tiponf, descrtiponf, somavalortiponf, tipodocumento,
         paginageomapa, placa, motorista, reentrega, sequencia, idnotafiscal)
        select seq_manifesto.nextval, v.idromaneio, v.codcli, v.razaosocial,
               v.idcarga, v.data, v.identidade, v.descrpalet, v.seq_roma,
               v.obs, v.nfnumformulario, v.valor, v.pesobruto, v.formularios,
               v.volume, v.cidade, v.datageracao, v.totalpalet, v.modelo,
               v.depositante, v.tiponf, v.descrtiponf, v.somavalortiponf,
               v.tipodocumento, v.paginageomapa, v.placa, v.motorista,
               v.reentrega, v.sequencia, v.idnotafiscal
          from v_manifesto_carga v
         where v.idcarga = p_idcarga
           and v.idnotafiscal = p_idnotafiscal;
    end if;
  end;

  procedure criar_pallet_reentrega(p_romaneio in number) is
    v_num_pallet number;
    r_romaneio   romaneiopai%rowtype;
  begin
    -- pega as informacoes do romaneio;
    r_romaneio := carregar_romaneio(p_romaneio);
  
    v_num_pallet := 0;
    /*
     * cria os palets considerando a ordem de entrega, volume e peso das mercadorias
     * cricao dos palets de produtos nao segregados (toxicos)
    */
    formar_pallet_ordem_entrega(p_romaneio, v_num_pallet,
                                r_romaneio.nummaxpalet,
                                r_romaneio.calculanumpalet);
  end;

  procedure IncluirNF_NovaCarga
  (
    p_entidade    in number,
    p_depositante in number,
    p_nf          in number,
    p_usuario     in number,
    p_carga       in number,
    p_tipoocorr   in string,
    p_tipocarga   in string
  ) is
  
    cursor c_carga(p_carga in number) is
      select placa, idarmazem, iddoca
        from carga
       where idcarga = p_carga;
  
    r_carga              c_carga%rowtype;
    v_romaneio           number;
    v_conferereentrega   char(1);
    v_controlaareaespera char(1);
  begin
    if pk_carga.podeInserirNFCarga(p_nf) then
      if p_tipoocorr = 'R' then
        update notafiscal
           set reentrega        = 'S',
               retornoreentrega = 'N'
         where idnotafiscal = p_nf;
      end if;
      v_romaneio := -1;
    
      -- Atualiza Armazém da Carga
      update carga
         set idarmazem =
             (select idarmazem
                from notafiscal
               where idnotafiscal = p_nf)
       where idcarga = p_carga;
    
      -- Insere nf ao romaneio
      inserir_nfromaneio(v_romaneio, p_entidade, p_nf, p_usuario, 0, 'N');
      -- pegar placa do veiculo da carga
      if c_carga%isopen then
        close c_carga;
      end if;
      open c_carga(p_carga);
      fetch c_carga
        into r_carga;
    
      update romaneiopai
         set placa     = r_carga.placa,
             idarmazem = nvl(r_carga.idarmazem, idarmazem),
             iddoca    = nvl(r_carga.iddoca, iddoca)
       where idromaneio = v_romaneio;
      -- Criar romaneio
      formar_romaneio(v_romaneio, p_usuario, C_NAO, C_NAO);
    
      --Controle de separação e conferência
      select d.confsaidareentrega, d.controlaareaespera
        into v_conferereentrega, v_controlaareaespera
        from depositante d
       where d.identidade = p_depositante;
    
      if (p_tipocarga = 'V') then
        if (nvl(v_conferereentrega, 'S') = C_SIM) then
          update romaneiopai
             set liberado = C_NAO,
                 separado = C_SIM
           where idromaneio = v_romaneio;
          -- Criar Palet e Pallet Produto
          criar_pallet_reentrega(v_romaneio);
        else
          update romaneiopai
             set liberado = C_SIM,
                 separado = C_SIM
           where idromaneio = v_romaneio;
        
          insert into notafiscalcarga
            (idcarga, idnotafiscal, embarqueliberado, ordem, imprelvolcarga)
          values
            (p_carga, p_nf, 'S', 1, 0);
        end if;
      elsif (p_tipocarga = 'C') then
        update romaneiopai
           set liberado = C_SIM,
               separado = C_SIM,
               idcarga  = p_carga
         where idromaneio = v_romaneio;
      
        insert into notafiscalcarga
          (idcarga, idnotafiscal, embarqueliberado, ordem, imprelvolcarga)
        values
          (p_carga, p_nf, 'S', 1, 0);
      end if;
    
      pk_carga.AtualizarValoresCarga(p_carga, v_romaneio, '+');
      -- Criar Manifesto Carga
      CriarManifestoCarga(p_carga, p_nf);
      commit;
    end if;
  end;

  /*
   * Retorna se o romaneio ja foi separado ou nao
  */
  function ret_romenio_separado(p_romaneio in number) return varchar2 is
    v_separado    number;
    v_naoseparado number;
  begin
    select count(*)
      into v_separado
      from palet
     where idromaneio = p_romaneio
       and separado = 'N';
  
    select count(*)
      into v_naoseparado
      from palet
     where idromaneio = p_romaneio
       and separado = 'S';
  
    if v_separado > 0 then
      return 'NAO';
    else
      if (v_separado = 0)
         and (v_naoseparado = 0) then
        return 'NAO';
      else
        return 'SIM';
      end if;
    end if;
  end;

  procedure apaga_palet_separacao
  (
    p_romaneio  in number,
    p_idpalet   in number,
    p_idarmazem in number,
    p_idlocal   in local.idlocal%type,
    p_idproduto in number
  ) is
  begin
    -- apaga a embalagem atual de separacao
    delete from paletseparacao
     where idromaneio = p_romaneio
       and idpalet = p_idpalet
       and idarmazem = p_idarmazem
       and idlocal = p_idlocal
       and idproduto = p_idproduto;
  end;

  function retornar_volume_nf_romaneio
  (
    p_romaneio in number,
    p_nf       in number
  ) return number is
    cursor c_emb_prod
    (
      p_produto in number,
      p_rest    in number
    ) is
      select barra, fatorconversao,
             nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
             nvl(pesobruto, 0) peso
        from embalagem
       where trunc(p_rest / fatorconversao) > 0
         and ativo = 'S'
         and idproduto = p_produto
       order by fatorconversao desc, nvl(barrainterna, 0) asc;
  
    r_emb_prod c_emb_prod%rowtype;
    v_tot_vol  number := 0;
    v_totu     number;
    v_qtde     number;
  begin
    for c_prod in (select nfr.sequencia, nf.iddepositante, nfd.idproduto,
                          p.codigointerno codprod, p.descr produto,
                          sum(nvl(e.fatorconversao, 0) * nfd.qtde) qtde
                     from nfromaneio nfr, notafiscal nf, nfdet nfd,
                          embalagem e, produto p
                    where p.idproduto = nfd.idproduto
                      and e.barra = nfd.barra
                      and e.idproduto = nfd.idproduto
                      and nfd.nf = nf.idnotafiscal
                      and nf.idnotafiscal = nfr.idnotafiscal
                      and nfr.idromaneio = p_romaneio
                      and nf.idnotafiscal = p_nf
                    group by nfr.sequencia, nfd.idproduto, p.codigointerno,
                             p.descr, nf.iddepositante
                    order by nfr.sequencia desc)
    loop
      v_totu := 0;
      if c_emb_prod%isopen then
        close c_emb_prod;
      end if;
      open c_emb_prod(c_prod.idproduto, c_prod.qtde);
      fetch c_emb_prod
        into r_emb_prod;
      while ((c_prod.qtde - v_totu) > 0)
      loop
        v_qtde    := trunc((c_prod.qtde - v_totu) /
                           r_emb_prod.fatorconversao);
        v_totu    := v_totu + v_qtde * r_emb_prod.fatorconversao;
        v_tot_vol := v_tot_vol + v_qtde * r_emb_prod.volume;
        if c_emb_prod%isopen then
          close c_emb_prod;
        end if;
        open c_emb_prod(c_prod.idproduto, v_qtde);
        fetch c_emb_prod
          into r_emb_prod;
      end loop;
    end loop;
    return v_tot_vol;
  end;

  function Retornar_Depositante(p_romaneio in number) return varchar2 is
    cursor c_dep(p_romaneio in number) is
      select distinct dep.razaosocial
        from nfromaneio nfr, notafiscal nf, entidade dep
       where dep.identidade = nf.iddepositante
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
  
    r_dep c_dep%rowtype;
    v_dep varchar2(255);
  begin
    if c_dep%isopen then
      close c_dep;
    end if;
    open c_dep(p_romaneio);
    fetch c_dep
      into r_dep;
    while c_dep%found
    loop
      if v_dep is null then
        v_dep := r_dep.razaosocial;
      else
        v_dep := v_dep || ',' || r_dep.razaosocial;
      end if;
      fetch c_dep
        into r_dep;
    end loop;
    close c_dep;
    return v_dep;
  end;

  /*
   * Insere as Notas Fiscais ao Romaneio
  */
  procedure inserir_nfromaneio_notafiscal
  (
    p_romaneio   in out number,
    p_notafiscal in number,
    p_usuario    in number,
    p_commit     in varchar2
  ) is
    v_seq      number;
    r_romaneio romaneiopai%rowtype;
    v_entidade number;
  begin
    select ident_entrega
      into v_entidade
      from notafiscal
     where idnotafiscal = p_notafiscal;
    v_seq := RetornarOrdemEntrega(p_romaneio, v_entidade);
  
    if v_seq is null then
      v_seq := RetornarOrdemEntregaMaxima(p_romaneio);
    end if;
  
    if nvl(p_romaneio, 0) <= 0 then
      r_romaneio.idromaneio     := p_romaneio;
      r_romaneio.codigointerno  := p_romaneio;
      r_romaneio.idusuario      := p_usuario;
      r_romaneio.tituloromaneio := p_romaneio;
    
      p_romaneio := inserir_romaneiopai(r_romaneio);
    end if;
  
    insert into nfromaneio
      (idromaneio, idnotafiscal, sequencia)
    values
      (p_romaneio, p_notafiscal, v_seq);
  
    update notafiscal
       set statusnf           = C_CARGA,
           statusroteirizacao = 2
     where idnotafiscal = p_notafiscal;
  
    update nfimpressao nfi
       set nfi.statusdoc = 1
     where nfi.idprenf in
           (select nf.idprenf
              from notafiscal nf
             where nf.idnotafiscal = p_notafiscal);
    if p_commit = 'S' then
      commit;
    end if;
  end;

  /*
   * Retorna a sigla de expedicao baseado no cep informado
  */
  function SiglaExpedicao(p_cep in varchar2) return varchar2 is
    cursor c_sigla(p_cep in varchar2) is
      select sigla
        from siglacep s
       where s.cepinicial <= p_cep
         and s.cepfinal >= p_cep;
  
    r_sigla c_sigla%rowtype;
    v_cep   varchar2(10);
  begin
    v_cep := p_cep;
    if length(trim(v_cep)) > 0 then
      select replace(v_cep, '-', '')
        into v_cep
        from dual;
      select replace(v_cep, '.', '')
        into v_cep
        from dual;
      select replace(v_cep, ',', '')
        into v_cep
        from dual;
    end if;
  
    if c_sigla%isopen then
      close c_sigla;
    end if;
    open c_sigla(v_cep);
    fetch c_sigla
      into r_sigla;
    if c_sigla%found then
      close c_sigla;
      return r_sigla.sigla;
    else
      close c_sigla;
      return null;
    end if;
  end;

  /*
   * Retorna a sigla de expedicao baseado no cep informado
  */
  function RetornarSiglaExpedicaoTransp
  (
    p_identidade in number,
    p_cep        in varchar2
  ) return varchar2 is
    cursor c_sigla
    (
      p_identidade in number,
      p_cep        in varchar2
    ) is
      select sigla
        from siglacep s
       where s.identidade = p_identidade
         and s.cepinicial <= p_cep
         and s.cepfinal >= p_cep;
  
    r_sigla c_sigla%rowtype;
    v_cep   varchar2(10);
  begin
    v_cep := p_cep;
    if length(trim(v_cep)) > 0 then
      select replace(v_cep, '-', '')
        into v_cep
        from dual;
      select replace(v_cep, '.', '')
        into v_cep
        from dual;
      select replace(v_cep, ',', '')
        into v_cep
        from dual;
    end if;
  
    if c_sigla%isopen then
      close c_sigla;
    end if;
    open c_sigla(p_identidade, v_cep);
    fetch c_sigla
      into r_sigla;
    if c_sigla%found then
      close c_sigla;
      return r_sigla.sigla;
    else
      close c_sigla;
      return null;
    end if;
  end;

  /*
   * Retorna a rota de expedicao baseado no cep informado
  */
  function RotaExpedicao(p_cep in varchar2) return varchar2 is
    cursor c_sigla(p_cep in varchar2) is
      select rota
        from siglacep s
       where s.cepinicial <= p_cep
         and s.cepfinal >= p_cep;
  
    r_sigla c_sigla%rowtype;
    v_cep   varchar2(10);
  begin
    v_cep := p_cep;
    if length(trim(v_cep)) > 0 then
      select replace(v_cep, '-', '')
        into v_cep
        from dual;
      select replace(v_cep, '.', '')
        into v_cep
        from dual;
      select replace(v_cep, ',', '')
        into v_cep
        from dual;
    end if;
  
    if c_sigla%isopen then
      close c_sigla;
    end if;
    open c_sigla(v_cep);
    fetch c_sigla
      into r_sigla;
    if c_sigla%found then
      close c_sigla;
      return r_sigla.rota;
    else
      close c_sigla;
      return null;
    end if;
  end;

  function RetornaNFRomaneio(p_romaneio in varchar2) return varchar2 is
    v_nf varchar2(1000);
  begin
    v_nf := '';
    for c_nf in (select distinct nf.codigointerno
                   from nfromaneio r, notafiscal nf
                  where r.idromaneio in (p_romaneio)
                    and nf.idnotafiscal = r.idnotafiscal)
    loop
      if length(trim(v_nf)) > 0 then
        v_nf := v_nf || ',' || to_char(c_nf.codigointerno);
      else
        v_nf := to_char(c_nf.codigointerno);
      end if;
    end loop;
  
    return trim(v_nf);
  end;

  function RetornaIDNFRomaneio(p_romaneio in varchar2) return varchar2 is
    v_nf varchar2(1000);
  begin
    v_nf := '';
    for c_nf in (select distinct nf.idnotafiscal
                   from nfromaneio r, notafiscal nf
                  where r.idromaneio in (p_romaneio)
                    and nf.idnotafiscal = r.idnotafiscal)
    loop
      if length(trim(v_nf)) > 0 then
        v_nf := v_nf || ',' || to_char(c_nf.idnotafiscal);
      else
        v_nf := to_char(c_nf.idnotafiscal);
      end if;
    end loop;
  
    return trim(v_nf);
  end;

  function RetornaQtdeNFRomaneio(p_romaneio in number) return number is
    v_qtdenf number;
  begin
    v_qtdenf := 0;
    begin
      select count(nf.codigointerno)
        into v_qtdenf
        from nfromaneio r, notafiscal nf
       where r.idromaneio = p_romaneio
         and nf.idnotafiscal = r.idnotafiscal;
    exception
      when others then
        v_qtdenf := 0;
    end;
  
    return v_qtdenf;
  end;

  /*
   * Rotina responsavel por vincular os volumes cuja os pais (lotes) foram vinculados ao romaneio
  */
  procedure VincularVolumeNoRomaneio
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
  begin
    for c in (select ps.idromaneio, ps.idpalet, ll.idarmazem, ll.idlocal,
                     ll.idlote, l.idproduto, l.barra, ll.disp
                from paletseparacao ps, lote l, depositante d,
                     (select ll.idarmazem, ll.idlocal, ll.idlote,
                              ll.estoque - ll.pendencia + ll.adicionar disp
                         from lotelocal ll, lote l
                        where l.idlote = ll.idlote
                          and l.tipolote = 'V'
                          and ll.estoque - ll.pendencia + ll.adicionar > 0) ll
               where ps.idromaneio = p_romaneio
                 and l.idpalet = ps.idlote
                 and l.tipolote = 'V'
                 and ll.idarmazem = ps.idarmazem
                 and ll.idlote = l.idlote
                 and l.idlote <> ps.idlote
                 and d.identidade = l.iddepositante
                 and d.pedidovenda = c_nao)
    loop
      -- coloca o lote para separacao
      inserir_pallet_separacao(p_romaneio, c.idpalet, c.idarmazem,
                               c.idlocal, c.idlote, c.idproduto, c.barra,
                               c.disp, c.disp);
      -- atualiza a pendencia de estoque.
      pk_estoque.incluir_pendencia(c.idarmazem, c.idlocal, c.idlote, c.disp,
                                   p_usuario,
                                   'adicionado pendencia ref. romaneio ID: ' ||
                                    p_romaneio);
    end loop;
  end;

  /*
   * Retorna STRING com os Pedidos do Romaneio
  */
  function RetornaPedidoRomaneio(p_romaneio in varchar2) return varchar2 is
    v_pedido varchar2(1000);
  begin
    v_pedido := '';
    for c_nf in (select distinct nf.pedido
                   from nfromaneio r, notafiscal nf
                  where r.idromaneio in (p_romaneio)
                    and nf.idnotafiscal = r.idnotafiscal)
    loop
      if length(trim(v_pedido)) > 0 then
        v_pedido := v_pedido || ',' || to_char(c_nf.pedido);
      else
        v_pedido := to_char(c_nf.pedido);
      end if;
    end loop;
  
    return trim(v_pedido);
  end;

  /*
   * Volta o estoque de um romaneio processado
  */
  procedure retornarRomaneioProcessado
  (
    p_idromaneio in romaneiopai.idromaneio%type,
    p_idusuario  in number
  ) is
    v_RomReentrega romaneiopai.reentrega%type;
    v_msg          t_message;
  begin
    select reentrega
      into v_RomReentrega
      from romaneiopai
     where idromaneio = p_idromaneio;
  
    if v_RomReentrega = 'N' then
      --verifica o ultimo romaneio de reentrega cadastrado para o romaneio principal
      for c_RomReentrega in (select rp.idromaneio idRomPai,
                                    rp.codigointerno CodRomPai,
                                    romreent.idromaneio idRomReent,
                                    romreent.codigointerno CodRomReent,
                                    to_char(romreent.datageracao,
                                             'dd/mm/yyyy hh24:mi:ss') datageracao
                               from romaneiopai rp,
                                    (select rp.idromaneio, rp.codigointerno,
                                             rp.datageracao
                                        from romaneiopai rp
                                       where rp.datageracao =
                                             (select max(rp.datageracao)
                                                from romaneiopai rp,
                                                     nfromaneio nfr
                                               where nfr.idromaneio =
                                                     rp.idromaneio
                                                 and rp.reentrega = 'S'
                                                 and nfr.idnotafiscal in
                                                     (select idnotafiscal
                                                        from nfromaneio
                                                       where idromaneio =
                                                             p_idromaneio))) romreent
                              where rp.idromaneio <> romreent.idromaneio
                                and rp.reentrega = 'N'
                                and rp.processado = 'S'
                                and rp.idromaneio = p_idromaneio)
      
      loop
        v_msg := t_message('Romaneio não pode ser cancelado pois existe romaneio de reentrega gerado para este romaneio.' ||
                           chr(13) || 'Romaneio Cód: {0} - Gerado em: {1}.' ||
                           chr(13) ||
                           'Para continuar com a operação o romaneio de reentrega deve ser desfeito.');
        v_msg.addParam(c_RomReentrega.CodRomReent);
        v_msg.addParam(c_RomReentrega.datageracao);
        raise_application_error(-20000, v_msg.formatMessage);
      end loop;
    else
      --verifica se existe romaneio de reentrega cadastrado após o romaneio
      for c_RomReentrega in (select romreent.idromaneio,
                                    romreent.codigointerno,
                                    to_char(romreent.datageracao,
                                             'dd/mm/yyyy hh24:mi:ss') datageracao
                               from romaneiopai rp,
                                    (select rp.idromaneio, rp.datageracao,
                                             rp.codigointerno
                                        from romaneiopai rp, nfromaneio nfr
                                       where nfr.idromaneio = rp.idromaneio
                                         and rp.reentrega = 'S'
                                         and nfr.idnotafiscal =
                                             (select idnotafiscal
                                                from nfromaneio
                                               where idromaneio = p_idromaneio)
                                       order by idromaneio desc) romreent
                              where rp.idromaneio = p_idromaneio
                                and rp.reentrega = 'S'
                                and rp.processado = 'S'
                                and rp.datageracao < romreent.datageracao
                                and rp.idromaneio <> romreent.idromaneio
                                and rownum = 1)
      loop
      
        v_msg := t_message('Romaneio não pode ser cancelado pois existe romaneio de reentrega gerado após este romaneio.' ||
                           chr(13) || 'Romaneio Cód: {0} - Gerado em: {1}.' ||
                           chr(13) ||
                           'Para continuar com a operação o romaneio de reentrega deve ser desfeito.');
        v_msg.addParam(c_RomReentrega.codigointerno);
        v_msg.addParam(c_RomReentrega.datageracao);
        raise_application_error(-20000, v_msg.formatMessage);
      end loop;
    
    end if;
  
    -- Desfazendo o Retorno Simbólico Gerado
    pk_notafiscal.desfazerNFRetArmazenagemRom(p_idromaneio, null,
                                              p_idusuario, 'TS');
  
    -- estornando estoque processado
    for c_lote in (select p.idarmazem, p.idlocal, p.idlote, p.qtdeunit,
                          p.idproduto, lt.iddepositante
                     from paletseparacao p, lote lt
                    where idromaneio = p_idromaneio
                      and lt.idlote = p.idlote)
    loop
    
      pk_picking_dinamico.addGttPickingDinamico(c_lote.idproduto,
                                                c_lote.iddepositante,
                                                c_lote.idlocal,
                                                c_lote.idarmazem, 1);
      -- retorna o estoque dos lotes
      pk_estoque.incluir_estoque(c_lote.idarmazem, c_lote.idlocal,
                                 c_lote.idlote, c_lote.qtdeunit, p_idusuario,
                                 'INCLUIDO ESTOQUE REFERENTE AO CANCELAMENTO DO PROCESSAMENTO DO ROMANEIO: ' ||
                                  p_idromaneio, 'S');
      pk_estoque.incluir_pendencia(c_lote.idarmazem, c_lote.idlocal,
                                   c_lote.idlote, c_lote.qtdeunit,
                                   p_idusuario,
                                   'INCLUIDO PENDENCIA REFERENTE AO CANCELAMENTO DO PROCESSAMENTO DO ROMANEIO: ' ||
                                    p_idromaneio);
    end loop;
  
    pk_picking_dinamico.inserir_picking_dinamico;
  
    -- retorna o romaneio para nao processado
    update romaneiopai
       set processado        = 'N',
           dataprocessamento = null
     where idromaneio = p_idromaneio;
    -- retorna a nota fiscal para nao processado 
    update notafiscal
       set statusnf = 'C'
     where idnotafiscal in
           (select idnotafiscal
              from nfromaneio
             where idromaneio = p_idromaneio)
        or idnotafiscal in
           (select nf.idpedidopai
              from notafiscal nf, nfromaneio nfr
             where nfr.idnotafiscal = nf.idnotafiscal
               and nfr.idromaneio = p_idromaneio)
        or idnotafiscal in
           (select rs.idnotafiscalvenda
              from nfromaneio nfr, retornosimbolico rs
             where nfr.idromaneio = p_idromaneio
               and rs.idnotafiscalretorno = nfr.idnotafiscal);
  
    -- retorna a NFImpressao para nao processado         
    update nfimpressao
       set status = 'N'
     where idprenf in (select nf.idprenf
                         from notafiscal nf, nfromaneio nfr
                        where nfr.idnotafiscal = nf.idnotafiscal
                          and nfr.idromaneio = p_idromaneio)
        or idprenf in (select nfp.idprenf
                         from notafiscal nfp, notafiscal nf, nfromaneio nfr
                        where nf.idpedidopai = nfp.idnotafiscal
                          and nfr.idnotafiscal = nf.idnotafiscal
                          and nfr.idromaneio = p_idromaneio)
        or idprenf in
           (select nf.idprenf
              from nfromaneio nfr, retornosimbolico rs, notafiscal nf
             where nf.idnotafiscal = rs.idnotafiscalvenda
               and rs.idnotafiscalretorno = nfr.idnotafiscal
               and nfr.idromaneio = p_idromaneio);
  
    pk_utilities.geralog(p_idusuario,
                         'CANCELADO O PROCESSAMENTO DO ROMANEIO: ' ||
                          p_idromaneio, p_idromaneio, 'CR');
  end;

  /*
   * Preenche o Palet Separacao Cliente apos Recalculo do PaletSeparacao
  */
  procedure RecalculaPaletSepCliente(p_idromaneio in number) is
    cursor c_produtos(p_idromaneio in number) is
      select n.ident_entrega, d.idproduto, p.otimizaseparacao,
             sum(d.qtdeatendida * e.fatorconversao) qtde
        from nfromaneio nr, notafiscal n, nfdet d, embalagem e, produto p,
             romaneiopai r
       where nr.idromaneio = p_idromaneio
         and n.idnotafiscal = nr.idnotafiscal
         and d.nf = n.idnotafiscal
         and e.idproduto = d.idproduto
         and e.barra = d.barra
         and p.idproduto = e.idproduto
         and d.qtdeatendida > 0
         and r.idromaneio = nr.idromaneio
         and r.processado <> 'S'
       group by n.ident_entrega, d.idproduto, p.otimizaseparacao
      union all
      select nf.ident_entrega, pk.idproduto, p.otimizaseparacao,
             sum(nfd.qtdeatendida * e.fatorconversao) qtde
        from nfromaneio nfr, notafiscal nf, nfdet nfd, produto p,
             embalagem e, kitproduto kp, embalagem ek, produto pk
       where nfr.idromaneio = p_idromaneio
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfd.nf = nfr.idnotafiscal
         and nfd.qtdeatendida > 0
         and p.idproduto = nfd.idproduto
         and nvl(p.segregado, 'N') = 'N'
         and e.idproduto = nfd.idproduto
         and e.barra = nfd.barra
         and p.kitexpexplodida = 'S'
         and kp.idprodutokit = nfd.idproduto
         and ek.barra = kp.barra
         and ek.idproduto = kp.idproduto
         and pk.idproduto = kp.idproduto
       group by nf.ident_entrega, pk.idproduto, p.otimizaseparacao;
  
    cursor c_palet
    (
      p_idromaneio in number,
      p_idproduto  in number,
      p_pallet     in number,
      p_identidade in number
    ) is
    
      select p.idarmazem, p.idlocal, p.idproduto, p.idpalet, p.ordem,
             --sum(p.qtde) qtde, 
             (sum(p.qtdeunit) -
              (select nvl(sum(psc.qtde), 0)
                  from paletseparacaocliente psc
                 where psc.idarmazem = p.idarmazem
                   and psc.idromaneio = p_idromaneio
                   and psc.idproduto = p_idproduto
                   and psc.idpalet = p_pallet
                   and psc.identidade = p_identidade
                   and psc.idlocal = p.idlocal)) qtdeunit
        from paletseparacao p
       where p.idromaneio = p_idromaneio
         and p.idproduto = p_idproduto
         and p.idpalet = p_pallet
       group by p.idarmazem, p.idlocal, p.idproduto, p.idpalet, p.ordem
       order by p.idlocal, sum(p.qtdeunit) desc;
  
    cursor c_embalagens(p_idproduto in embalagem.idproduto%type) is
      select idproduto, barra, apresentacao, fatorconversao, descrreduzido,
             ativo,
             nvl(altura, 0) * nvl(largura, 0) * nvl(comprimento, 0) volume,
             nvl(pesobruto, 0) peso
        from embalagem em
       where idproduto = p_idproduto
         and ativo = c_sim
       order by fatorconversao desc, 7, 8, nvl(barrainterna, 0) asc, 2;
  
    cursor c_lotepsc
    (
      p_idromaneio   in number,
      p_idproduto    in number,
      p_destinatario in number
    ) is
      select p.idromaneio, p.idproduto, p.barra, idlote
        from paletseparacao p
       where p.idromaneio = p_idromaneio
         and p.idproduto = p_idproduto
         and p.idpalet in
             (select idpalet
                from produtopalet pp
               where pp.idromaneio = p.idromaneio
                 and pp.idpalet = p.idpalet
                 and pp.idproduto = p.idproduto
                 and pp.identidade = p_destinatario);
  
    r_produtos   c_produtos%rowtype;
    r_palet      c_palet%rowtype;
    r_embalagens c_embalagens%rowtype;
    r_lotepsc    c_lotepsc%rowtype;
    type t_Palet is table of c_palet%rowtype;
    v_Palet t_Palet := t_Palet();
  
    v_qtde     number;
    v_qtdeprod number;
    v_indice   number;
    x          number;
    v_idlote   number;
    v_qtdePs   number;
  begin
    delete from paletseparacaocliente
     where idromaneio = p_idromaneio;
  
    open c_produtos(p_idromaneio);
  
    fetch c_produtos
      into r_produtos;
  
    while c_produtos%found
    loop
      -- Armazenando os dados do palet
      v_Palet.Delete;
      if c_Palet%isopen then
        close c_Palet;
      end if;
      v_qtdePs := 0;
    
      for c_prodPallet in (select p.idromaneio, p.idproduto, p.idpalet,
                                  p.identidade,
                                  (p.qtde * e.fatorconversao) qtdeuni
                             from produtopalet p, embalagem e
                            where e.idproduto = p.idproduto
                              and e.barra = p.barra
                              and p.idromaneio = p_idromaneio
                              and p.idproduto = r_produtos.idproduto
                              and p.identidade = r_produtos.ident_entrega)
      loop
        open c_Palet(c_prodPallet.Idromaneio, c_prodPallet.Idproduto,
                     c_prodPallet.Idpalet, c_prodPallet.Identidade);
        fetch c_Palet
          into r_Palet;
        v_qtdePs := c_prodPallet.Qtdeuni;
      
        while c_Palet%found
              and v_qtdePs > 0
        loop
          v_Palet.Extend;
          v_Palet(v_Palet.Count).idarmazem := r_Palet.idarmazem;
          v_Palet(v_Palet.Count).idlocal := r_Palet.idlocal;
          v_Palet(v_Palet.Count).idproduto := r_Palet.idproduto;
          v_Palet(v_Palet.Count).idpalet := r_Palet.idpalet;
          v_Palet(v_Palet.Count).ordem := r_Palet.ordem;
        
          v_qtdePs := v_qtdePs - r_Palet.qtdeunit;
        
          if (v_qtdePs >= 0) then
            v_Palet(v_Palet.Count).qtdeunit := r_Palet.qtdeunit;
          else
            v_Palet(v_Palet.Count).qtdeunit := c_prodPallet.Qtdeuni;
          end if;
        
          fetch c_Palet
            into r_Palet;
        
        end loop;
      
        if (c_Palet%notfound) then
          for c_semPallet in (select *
                                from (select p.idarmazem, p.idlocal,
                                              p.idproduto, p.idpalet, p.ordem,
                                              sum(p.qtdeunit) qtdeunit
                                         from paletseparacao p
                                        where p.idromaneio =
                                              c_prodPallet.Idromaneio
                                          and p.idproduto =
                                              c_prodPallet.Idproduto
                                          and p.idpalet <>
                                              c_prodPallet.Idpalet
                                        group by p.idarmazem, p.idlocal,
                                                 p.idproduto, p.idpalet,
                                                 p.ordem
                                       having sum(p.qtdeunit) = v_qtdePs
                                        order by p.idpalet)
                               where rownum = 1)
          loop
            v_Palet.Extend;
            v_Palet(v_Palet.Count).idarmazem := c_semPallet.idarmazem;
            v_Palet(v_Palet.Count).idlocal := c_semPallet.idlocal;
            v_Palet(v_Palet.Count).idproduto := c_semPallet.idproduto;
            v_Palet(v_Palet.Count).idpalet := c_semPallet.idpalet;
            v_Palet(v_Palet.Count).ordem := c_semPallet.ordem;
            v_Palet(v_Palet.Count).qtdeunit := v_qtdePs;
          end loop;
        end if;
        close c_Palet;
      end loop;
    
      if r_produtos.otimizaseparacao = 'S' then
        v_qtdeprod := r_produtos.qtde;
      
        -- Localizando as embalagens possíveis        
        if c_embalagens%isopen then
          close c_embalagens;
        end if;
        open c_embalagens(r_produtos.idproduto);
        fetch c_embalagens
          into r_embalagens;
        while c_embalagens%found
              and v_qtdeprod > 0
        loop
          if r_embalagens.fatorconversao <> 1 then
            v_qtde := trunc(v_qtdeprod / r_embalagens.fatorconversao);
          else
            v_qtde := v_qtdeprod;
          end if;
        
          -- Localizando o local disponivel
          v_indice := -1;
          for x in 1 .. v_Palet.count
          loop
            if trunc(v_Palet(x).qtdeunit / r_embalagens.fatorconversao) > 0 then
              if trunc(v_Palet(x).qtdeunit / r_embalagens.fatorconversao) <=
                 v_qtde then
                v_qtde := trunc(v_Palet(x)
                                .qtdeunit / r_embalagens.fatorconversao);
              end if;
              v_indice := x;
              exit;
            end if;
          end loop;
        
          if v_qtde > 0 then
            if v_indice <> -1 then
              -- Inserindo na tabela PALETSEPARACAOCLIENTE
              begin
                select idlote
                  into v_idlote
                  from paletseparacao
                 where idromaneio = p_idromaneio
                   and barra = r_embalagens.barra
                   and idproduto = v_Palet(v_indice).idproduto
                   and idarmazem = v_Palet(v_indice).idarmazem
                   and rownum = 1;
              exception
                when others then
                  if c_lotepsc%isopen then
                    close c_lotepsc;
                  end if;
                  open c_lotepsc(p_idromaneio, r_produtos.idproduto,
                                 r_produtos.ident_entrega);
                  fetch c_lotepsc
                    into r_lotepsc;
                  v_idlote := r_lotepsc.idlote;
              end;
              inserir_pallet_separacao_cli(p_idromaneio,
                                           v_Palet(v_indice).idpalet,
                                           v_Palet(v_indice).idarmazem,
                                           v_Palet(v_indice).idlocal,
                                           v_Palet(v_indice).idproduto,
                                           r_embalagens.barra,
                                           r_produtos.ident_entrega, v_qtde,
                                           v_Palet(v_indice).ordem);
            
              v_qtdeprod := v_qtdeprod -
                            (v_qtde * r_embalagens.fatorconversao);
              v_Palet(v_indice).qtdeunit := v_Palet(v_indice)
                                            .qtdeunit -
                                             (v_qtde *
                                              r_embalagens.fatorconversao);
              if v_Palet(v_indice).qtdeunit = 0 then
                close c_embalagens;
                open c_embalagens(r_produtos.idproduto);
              end if;
            end if;
          end if;
          fetch c_embalagens
            into r_embalagens;
        end loop;
        close c_embalagens;
      else
        -- Localizando os itens e unidades da nota
        for c_nota in (select nd.idproduto, sum(nd.qtde) qtde,
                              em.fatorconversao, em.barra
                         from nfromaneio nr, notafiscal nf, nfdet nd,
                              embalagem em
                        where nr.idromaneio = p_idromaneio
                          and nf.idnotafiscal = nr.idnotafiscal
                          and nf.ident_entrega = r_produtos.ident_entrega
                          and nd.nf = nr.idnotafiscal
                          and nd.idproduto = r_produtos.idproduto
                          and em.idproduto = nd.idproduto
                          and em.barra = nd.barra
                        group by nd.idproduto, em.fatorconversao, em.barra)
        loop
        
          v_qtdeprod := c_nota.qtde * c_nota.fatorconversao;
          -- Localizando as embalagens possíveis        
          if c_embalagens%isopen then
            close c_embalagens;
          end if;
          open c_embalagens(c_nota.idproduto);
          fetch c_embalagens
            into r_embalagens;
          while c_embalagens%found
                and v_qtdeprod > 0
          loop
            if r_embalagens.fatorconversao <= c_nota.fatorconversao then
              v_qtde := v_qtdeprod;
              if r_embalagens.fatorconversao <> 1 then
                v_qtde := trunc(v_qtdeprod / r_embalagens.fatorconversao);
              else
                v_qtde := v_qtdeprod;
              end if;
            
              -- Localizando o local disponivel
              v_indice := -1;
              for x in 1 .. v_Palet.count
              loop
                if trunc(v_Palet(x).qtdeunit / r_embalagens.fatorconversao) > 0 then
                  if trunc(v_Palet(x).qtdeunit / r_embalagens.fatorconversao) <=
                     v_qtde then
                    v_qtde := trunc(v_Palet(x)
                                    .qtdeunit / r_embalagens.fatorconversao);
                  end if;
                  v_indice := x;
                  exit;
                end if;
              end loop;
            
              if v_indice <> -1 then
                -- Inserindo na tabela PALETSEPARACAOCLIENTE
              
                begin
                  SELECT idlote
                    into v_idlote
                    FROM PALETSEPARACAO
                   where idromaneio = p_idromaneio
                     and barra = r_embalagens.barra
                     and idproduto = v_Palet(v_indice).idproduto
                     and idarmazem = v_Palet(v_indice).idarmazem
                     and rownum = 1;
                exception
                  when others then
                    if c_lotepsc%isopen then
                      close c_lotepsc;
                    end if;
                    open c_lotepsc(p_idromaneio, r_produtos.idproduto,
                                   r_produtos.ident_entrega);
                    fetch c_lotepsc
                      into r_lotepsc;
                    v_idlote := r_lotepsc.idlote;
                end;
                inserir_pallet_separacao_cli(p_idromaneio,
                                             v_Palet(v_indice).idpalet,
                                             v_Palet(v_indice).idarmazem,
                                             v_Palet(v_indice).idlocal,
                                             v_Palet(v_indice).idproduto,
                                             r_embalagens.barra,
                                             r_produtos.ident_entrega,
                                             v_qtde, v_Palet(v_indice).ordem);
              
                v_qtdeprod := v_qtdeprod -
                              (v_qtde * r_embalagens.fatorconversao);
                v_Palet(v_indice).qtdeunit := v_Palet(v_indice)
                                              .qtdeunit -
                                               (v_qtde *
                                                r_embalagens.fatorconversao);
                if v_Palet(v_indice).qtdeunit = 0 then
                  close c_embalagens;
                  open c_embalagens(r_produtos.idproduto);
                end if;
              end if;
            end if;
            fetch c_embalagens
              into r_embalagens;
          end loop;
          close c_embalagens;
        end loop;
      end if;
      fetch c_produtos
        into r_produtos;
    end loop;
    close c_produtos;
  end;

  /*
   * Retorna o numpedido das NFs para o Destinatario no romaneio
  */
  function Retornar_NumPedido_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct ni.numpedido
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf c_nf%rowtype;
    v_nf varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nf is null then
          v_nf := r_nf.numpedido;
        else
          v_nf := v_nf || ',' || r_nf.numpedido;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nf;
    else
      return '';
    end if;
  end;

  /*
   * Retorna Data de Importacao do pedido das NFs para o Destinatario no romaneio
  */
  function retornar_dtimppedido
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct to_char(ni.dataimportacao, 'DD/MM/YYYY') data
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf   c_nf%rowtype;
    v_data varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_data is null then
          v_data := r_nf.data;
        else
          v_data := v_data || ',' || r_nf.data;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_data;
    else
      return '';
    end if;
  end;

  /*
   * Retorna a paggeomapa das NFs para o Destinatario no romaneio
  */
  function Retornar_LocGeo_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct ni.paginageomapa
        from nfromaneio nfr, notafiscal nf, nfimpressao ni
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and ni.idprenf = nf.idprenf;
  
    r_nf c_nf%rowtype;
    v_nf varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_nf is null then
          v_nf := r_nf.paginageomapa;
        else
          v_nf := v_nf || ',' || r_nf.paginageomapa;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_nf;
    else
      return '';
    end if;
  end;

  /*
   * Retorna os tipos de documentos das NFs para o Destinatario no romaneio
  */
  function Retornar_TipoDocumento_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2 is
    cursor c_nf
    (
      p_romaneio     in number,
      p_destinatario in number
    ) is
      select distinct decode(TRIM(substr(nfi.tipodocumento, 1, 1)), 'D',
                              'DINHEIRO', 'C', 'CHEQUE', 'B', 'BOLETO',
                              nfi.tipodocumento) tipodocumento
        from nfromaneio nfr, notafiscal nf, nfimpressao nfi
       where nf.ident_entrega = p_destinatario
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio
         and nfi.idprenf = nf.idprenf;
  
    r_nf            c_nf%rowtype;
    v_tipodocumento varchar2(2000);
  begin
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_romaneio, p_destinatario);
    fetch c_nf
      into r_nf;
    if c_nf%found then
      while c_nf%found
      loop
        if v_tipodocumento is null then
          v_tipodocumento := r_nf.tipodocumento;
        else
          v_tipodocumento := v_tipodocumento || ',' || r_nf.tipodocumento;
        end if;
        fetch c_nf
          into r_nf;
      end loop;
      return v_tipodocumento;
    else
      return '';
    end if;
  end;

  -- Rotina responsável por finalizar fichas de separação do usuário em aberto
  procedure finalizarseparacao
  (
    p_id       in number,
    p_tipo     in varchar2,
    p_idregiao in number := null
  ) is
    cursor c_fichaf(p_idusuario in number) is
      select idfichaseparacao, situacao, idusuario, idromaneio, idpalet,
             idregiao
        from fichaseparacao
       where idusuario = p_idusuario
         and situacao = 'I';
  
    cursor c_fichafregiao
    (
      p_id       in number,
      p_idregiao in number
    ) is
      select idfichaseparacao, situacao, idusuario, idromaneio, idpalet,
             idregiao
        from fichaseparacao
       where idusuario = p_id
         and situacao = 'I'
         and idregiao = p_idregiao;
  
    r_ficha c_fichaf%rowtype;
  
    procedure finalizarfichas
    (
      r_ficha     in c_fichaf%rowtype,
      p_idusuario in number
    ) is
    begin
      update fichaseparacao
         set datafim  = sysdate,
             situacao = 'F'
       where idfichaseparacao = r_ficha.idfichaseparacao;
    
      update paletseparacao ps
         set dtfim    = sysdate,
             separado = 'S'
       where idromaneio = r_ficha.idromaneio
         and idpalet = r_ficha.idpalet
         and (r_ficha.idregiao is null or exists
              (select 1
                 from local lo
                where lo.idarmazem = ps.idarmazem
                  and lo.idlocal = ps.idlocal
                  and lo.idregiao = r_ficha.idregiao));
    
      update palet p
         set separado = 'S'
       where idromaneio = r_ficha.idromaneio
         and idpalet = r_ficha.idpalet
         and not exists (select 1
                from paletseparacao
               where idromaneio = p.idromaneio
                 and idpalet = p.idpalet
                 and nvl(separado, 'N') = 'N');
    
      if ret_romenio_separado(r_ficha.idromaneio) = 'SIM' then
        update romaneiopai rp
           set rp.separado           = 'S',
               rp.datafinalseparacao = sysdate,
               rp.idusuarioseparacao = p_idusuario
         where rp.idromaneio = r_ficha.idromaneio;
      end if;
    end;
  begin
    if p_tipo = 'F' then
      if p_idregiao is null then
        open c_fichaf(p_id);
        fetch c_fichaf
          into r_ficha;
      
        while c_fichaf%found
        
        loop
          finalizarFichas(r_ficha, p_id);
        
          fetch c_fichaf
            into r_ficha;
        end loop;
      
        close c_fichaf;
      else
        open c_fichafregiao(p_id, p_idregiao);
        fetch c_fichafregiao
          into r_ficha;
      
        while c_fichafregiao%found
        
        loop
          finalizarFichas(r_ficha, p_id);
        
          fetch c_fichafregiao
            into r_ficha;
        end loop;
      
        close c_fichafregiao;
      end if;
    end if;
  end;

  /* Rotina usada para ordenar as notas fiscais de acordo com a ordem de entrega
  * da nfromaneio
  */
  procedure ordenar_sequencia_romaneio(p_romaneio in number) is
    v_seq      number;
    v_entidade number;
  begin
    v_seq      := 1;
    v_entidade := 0;
    for c_r in (select nf.ident_entrega identidade
                  from nfromaneio nfr, notafiscal nf
                 where nfr.idromaneio = p_romaneio
                   and nf.idnotafiscal = nfr.idnotafiscal
                 order by nfr.sequencia)
    loop
      if (v_entidade <> c_r.identidade) then
        update nfromaneio
           set sequencia = v_seq
         where idromaneio = p_romaneio
           and idnotafiscal in
               (select idnotafiscal
                  from notafiscal n
                 where ident_entrega = c_r.identidade);
        v_seq      := v_seq + 1;
        v_entidade := c_r.identidade;
      end if;
    end loop;
  end;

  /*
   * Identifica os lotes por nota fiscal do romaneio
  */
  procedure identificarlotes(p_idromaneio in romaneiopai.idromaneio%type) is
    type t_PaletSeparacao is table of paletseparacao%rowtype;
    v_PaletSeparacao t_PaletSeparacao := t_PaletSeparacao();
    i                number;
    v_qtdesepunid    number;
    v_qtdesep        number;
    v_qtdenf         number;
  
    function retDepositanteLote(p_idlote in number) return number is
      v_iddepositante number;
    begin
      select lt.iddepositante
        into v_iddepositante
        from lote lt
       where lt.idlote = p_idlote;
    
      return v_iddepositante;
    end;
  begin
    -- Excluindo os dados já lançados
    delete from paletseparacaonf
     where idromaneio = p_idromaneio;
  
    -- Incluindo na matriz as quantidades que se encontram na paletseparacao
    for c_separacao in (select ps.idlote, ps.idproduto,
                               round(sum(ps.qtdeunit), 6) qtdeunit
                          from paletseparacao ps, lote l
                         where ps.idromaneio = p_idromaneio
                           and l.idlote = ps.idlote
                           and l.tipolote = 'L'
                         group by ps.idlote, ps.idproduto
                         order by ps.idproduto)
    loop
      v_PaletSeparacao.Extend;
      i := v_PaletSeparacao.Count;
      v_PaletSeparacao(i).idromaneio := p_idromaneio;
      v_PaletSeparacao(i).idproduto := c_separacao.idproduto;
      v_PaletSeparacao(i).qtdeunit := c_separacao.qtdeunit;
      v_PaletSeparacao(i).idlote := c_separacao.idlote;
    end loop;
  
    -- Incluindo os lotes separados por item das notas fiscais
    for c_nota in (select nr.idromaneio, nr.idnotafiscal, nd.idproduto,
                          nd.qtdeatendida, nd.barra,
                          (nd.qtdeatendida * em.fatorconversao) qtdeunid,
                          em.fatorconversao, nd.idnfdet, nf.iddepositante
                     from nfromaneio nr, nfdet nd, embalagem em, produto p,
                          notafiscal nf
                    where nd.nf = nr.idnotafiscal
                      and em.idproduto = nd.idproduto
                      and em.barra = nd.barra
                      and p.idproduto = nd.idproduto
                      and nf.idnotafiscal = nd.nf
                      and p.kitexpexplodida = 'N'
                      and nr.idromaneio = p_idromaneio
                   union all
                   select nr.idromaneio, nr.idnotafiscal, kp.idproduto,
                          nd.qtdeatendida * (kp.qtde * ek.fatorconversao) qtdeatendida,
                          kp.barra,
                          (nd.qtdeatendida * em.fatorconversao) *
                           (kp.qtde * ek.fatorconversao) qtdeunid,
                          em.fatorconversao, nd.idnfdet, nf.iddepositante
                     from nfromaneio nr, nfdet nd, embalagem em, produto p,
                          kitproduto kp, embalagem ek, notafiscal nf
                    where nd.nf = nr.idnotafiscal
                      and em.idproduto = nd.idproduto
                      and em.barra = nd.barra
                      and p.idproduto = nd.idproduto
                      and nf.idnotafiscal = nd.nf
                      and p.kitexpexplodida = 'S'
                      and kp.idprodutokit = nd.idproduto
                      and ek.idproduto = kp.idproduto
                      and ek.barra = kp.barra
                      and nr.idromaneio = p_idromaneio
                    order by 2, 3)
    loop
      v_qtdenf := c_nota.qtdeunid;
      for i in 1 .. v_PaletSeparacao.Count
      loop
        if ((v_PaletSeparacao(i).idproduto = c_nota.idproduto) and
           (retDepositanteLote(v_PaletSeparacao(i).idlote) =
           c_nota.iddepositante)) then
          if v_PaletSeparacao(i).qtdeunit > 0 then
            if v_qtdenf > v_PaletSeparacao(i).qtdeunit then
              v_qtdesepunid := v_PaletSeparacao(i).qtdeunit;
            else
              v_qtdesepunid := v_qtdenf;
            end if;
            v_qtdesep := round(v_qtdesepunid / c_nota.fatorconversao, 6);
          
            if round(v_qtdesepunid, 6) > 0 then
              insert into paletseparacaonf
                (idseparacao, idromaneio, idnotafiscal, idproduto, idlote,
                 barra, qtde, qtdeunidade, idnfdet)
              values
                (seq_paletseparacaonf.nextval, p_idromaneio,
                 c_nota.idnotafiscal, c_nota.idproduto,
                 v_PaletSeparacao(i).idlote, c_nota.barra, v_qtdesep,
                 round(v_qtdesepunid, 6), c_nota.idnfdet);
            end if;
          
            v_PaletSeparacao(i).qtdeunit := v_PaletSeparacao(i)
                                            .qtdeunit - v_qtdesepunid;
            v_qtdenf := v_qtdenf - v_qtdesepunid;
            exit when v_qtdenf = 0;
          end if;
        end if;
      end loop;
    end loop;
  
    -- Inserindo as notas de reentrega
    insert into paletseparacaonf
      (idseparacao, idromaneio, idnotafiscal, idproduto, idlote, barra,
       qtde, qtdeunidade, idnfdet)
      select seq_paletseparacaonf.nextval, p_idromaneio, psn.idnotafiscal,
             psn.idproduto, psn.idlote, psn.barra, round(psn.qtde, 6) qtde,
             round(psn.qtdeunidade, 6) qtdeunidade, psn.idnfdet
        from nfromaneio nfrr, nfromaneio nfr, paletseparacaonf psn
       where nfrr.idromaneio = p_idromaneio
         and nfr.idnotafiscal = nfrr.idnotafiscal
         and psn.idnotafiscal = nfr.idnotafiscal
         and psn.idromaneio = nfr.idromaneio
         and not exists (select 1
                from paletseparacaonf
               where idnotafiscal = nfrr.idnotafiscal
                 and idromaneio = nfrr.idromaneio)
         and round(psn.qtdeunidade, 6) > 0
         and exists (select 1
                from nfromaneio
               where idnotafiscal = nfr.idnotafiscal
               group by idnotafiscal
              having min(idromaneio) = nfr.idromaneio);
  end;

  procedure preencherPaletSepNFOnda(p_idromaneio in romaneiopai.idromaneio%type) is
    type t_PaletSeparacao is table of paletseparacao%rowtype;
    v_PaletSeparacao t_PaletSeparacao := t_PaletSeparacao();
    i                number;
    v_qtdesepunid    number;
    v_qtdesep        number;
    v_qtdenf         number;
    v_qtdediff       number;
    v_msg            t_message;
  
    function retDepositanteLote(p_idlote in number) return number is
      v_iddepositante number;
    begin
      select lt.iddepositante
        into v_iddepositante
        from lote lt
       where lt.idlote = p_idlote;
    
      return v_iddepositante;
    end;
  
    function retSepararLotesCompletos(p_iddepositante in number)
      return number is
      v_seplotescompletos number;
    begin
      select d.separarlotescompletos
        into v_seplotescompletos
        from depositante d
       where d.identidade = p_iddepositante;
    
      return v_seplotescompletos;
    end;
  begin
    -- Excluindo os dados já lançados
    delete from paletseparacaonf
     where idromaneio = p_idromaneio;
  
    -- Incluindo na matriz as quantidades que se encontram na paletseparacao
    for c_separacao in (select ps.idlote, ps.idproduto,
                               round(sum(ps.qtdeunit), 6) qtdeunit, descr
                          from paletseparacao ps, lote l
                         where ps.idromaneio = p_idromaneio
                           and l.idlote = ps.idlote
                           and l.tipolote = 'L'
                         group by ps.idlote, ps.idproduto, descr
                         order by ps.idproduto, descr)
    loop
      v_PaletSeparacao.Extend;
      i := v_PaletSeparacao.Count;
      v_PaletSeparacao(i).idromaneio := p_idromaneio;
      v_PaletSeparacao(i).idproduto := c_separacao.idproduto;
      v_PaletSeparacao(i).qtdeunit := c_separacao.qtdeunit;
      v_PaletSeparacao(i).idlote := c_separacao.idlote;
    end loop;
  
    -- Incluindo os lotes separados por item das notas fiscais
    for c_nota in (select pn.idromaneio, pn.idnotafiscal, pn.idproduto,
                          pn.barra, sum(pn.qtdeunid) qtdeunid,
                          pn.fatorconversao, pn.idnfdet, pn.iddepositante,
                          pn.idlote, pn.loteindustria
                     from (select n.idromaneio, n.idnotafiscal, n.idproduto,
                                   n.barra, sum(n.qtdeunid) qtdeunid,
                                   n.fatorconversao, n.idnfdet, n.iddepositante,
                                   null idlote, n.loteindustria
                              from (select nr.idromaneio, nr.idnotafiscal,
                                            nd.idproduto, nd.barra,
                                            (nd.qtdeatendida * em.fatorconversao) qtdeunid,
                                            em.fatorconversao, nd.idnfdet,
                                            nf.iddepositante,
                                            nfd.serie loteindustria
                                       from nfromaneio nr, nfdet nd, embalagem em,
                                            produto p, notafiscal nf,
                                            nfdetimpressao nfd
                                      where nd.nf = nr.idnotafiscal
                                        and em.idproduto = nd.idproduto
                                        and em.barra = nd.barra
                                        and p.idproduto = nd.idproduto
                                        and nf.idnotafiscal = nd.nf
                                        and p.kitexpexplodida = 'N'
                                        and nr.idromaneio = p_idromaneio
                                        and nfd.idnfdet = nd.idnfdet
                                     union all
                                     select nr.idromaneio, nr.idnotafiscal,
                                            nd.idproduto, nd.barra,
                                            sum(sle.qtde) * -1 qtdeunid,
                                            em.fatorconversao, nd.idnfdet,
                                            nf.iddepositante,
                                            nfd.serie loteindustria
                                       from nfromaneio nr, nfdet nd, embalagem em,
                                            produto p, notafiscal nf,
                                            separacaoespecifica s,
                                            seploteindsepespecif sle,
                                            sepespporloteindustria sl,
                                            nfdetimpressao nfd
                                      where nd.nf = nr.idnotafiscal
                                        and em.idproduto = nd.idproduto
                                        and em.barra = nd.barra
                                        and p.idproduto = nd.idproduto
                                        and nf.idnotafiscal = nd.nf
                                        and p.kitexpexplodida = 'N'
                                        and nr.idromaneio = p_idromaneio
                                        and s.id = sle.idsepespecifica
                                        and sle.idseploteind =
                                            sl.idsepespporloteindustria
                                        and sl.idnfdet = nd.idnfdet
                                        and nfd.idnfdet = nd.idnfdet
                                      group by nr.idromaneio, nr.idnotafiscal,
                                               nd.idproduto, nd.barra,
                                               em.fatorconversao, nd.idnfdet,
                                               nf.iddepositante, nfd.serie) n
                             group by n.idromaneio, n.idnotafiscal, n.idproduto,
                                      n.barra, n.fatorconversao, n.idnfdet,
                                      n.iddepositante, n.loteindustria
                            having sum(n.qtdeunid) > 0
                            union all
                            select nr.idromaneio, nr.idnotafiscal, kp.idproduto,
                                   kp.barra,
                                   (nd.qtdeatendida * em.fatorconversao) *
                                    (kp.qtde * ek.fatorconversao) qtdeunid,
                                   em.fatorconversao, nd.idnfdet,
                                   nf.iddepositante, null idlote,
                                   nfd.serie loteindustria
                              from nfromaneio nr, nfdet nd, embalagem em,
                                   produto p, kitproduto kp, embalagem ek,
                                   notafiscal nf, nfdetimpressao nfd
                             where nd.nf = nr.idnotafiscal
                               and em.idproduto = nd.idproduto
                               and em.barra = nd.barra
                               and p.idproduto = nd.idproduto
                               and nf.idnotafiscal = nd.nf
                               and p.kitexpexplodida = 'S'
                               and kp.idprodutokit = nd.idproduto
                               and ek.idproduto = kp.idproduto
                               and ek.barra = kp.barra
                               and nr.idromaneio = p_idromaneio
                               and nfd.idnfdet = nd.idnfdet
                            union all
                            select nr.idromaneio, nr.idnotafiscal, nd.idproduto,
                                   nd.barra, sle.qtde qtdeunid,
                                   em.fatorconversao, nd.idnfdet,
                                   nf.iddepositante, s.idlote idlote,
                                   nfd.serie loteindustria
                              from nfromaneio nr, nfdet nd, embalagem em,
                                   produto p, notafiscal nf,
                                   separacaoespecifica s,
                                   seploteindsepespecif sle,
                                   sepespporloteindustria sl,
                                   nfdetimpressao nfd
                             where nd.nf = nr.idnotafiscal
                               and em.idproduto = nd.idproduto
                               and em.barra = nd.barra
                               and p.idproduto = nd.idproduto
                               and nf.idnotafiscal = nd.nf
                               and p.kitexpexplodida = 'N'
                               and nr.idromaneio = p_idromaneio
                               and s.id = sle.idsepespecifica
                               and sle.idseploteind =
                                   sl.idsepespporloteindustria
                               and sl.idnfdet = nd.idnfdet
                               and nfd.idnfdet = nd.idnfdet) pn
                    group by pn.idromaneio, pn.idnotafiscal, pn.idproduto,
                             pn.barra, pn.fatorconversao, pn.idnfdet,
                             pn.iddepositante, pn.idlote, pn.loteindustria
                    order by 2, 3, 10, 9)
    loop
      v_qtdenf := c_nota.qtdeunid;
      for i in 1 .. v_PaletSeparacao.Count
      loop
        if ((v_PaletSeparacao(i).idproduto = c_nota.idproduto) and
           (retDepositanteLote(v_PaletSeparacao(i).idlote) =
           c_nota.iddepositante)) then
          if v_PaletSeparacao(i).qtdeunit > 0 then
          
            if (c_nota.idlote is null OR
               c_nota.idlote = v_PaletSeparacao(i).idlote) then
            
              if v_qtdenf > v_PaletSeparacao(i).qtdeunit then
                v_qtdesepunid := v_PaletSeparacao(i).qtdeunit;
              else
                if (retSepararLotesCompletos(c_nota.iddepositante) = 1) then
                  v_qtdesepunid := v_PaletSeparacao(i).qtdeunit;
                else
                  v_qtdesepunid := v_qtdenf;
                end if;
              end if;
              v_qtdesep := round(v_qtdesepunid / c_nota.fatorconversao, 6);
            
              if round(v_qtdesepunid, 6) > 0 then
                insert into paletseparacaonf
                  (idseparacao, idromaneio, idnotafiscal, idproduto, idlote,
                   barra, qtde, qtdeunidade, idnfdet)
                values
                  (seq_paletseparacaonf.nextval, p_idromaneio,
                   c_nota.idnotafiscal, c_nota.idproduto,
                   v_PaletSeparacao(i).idlote, c_nota.barra, v_qtdesep,
                   round(v_qtdesepunid, 6), c_nota.idnfdet);
              end if;
            
              v_PaletSeparacao(i).qtdeunit := v_PaletSeparacao(i)
                                              .qtdeunit - v_qtdesepunid;
              v_qtdenf := v_qtdenf - v_qtdesepunid;
              exit when v_qtdenf <= 0;
            
            end if;
          
          end if;
        end if;
      end loop;
    end loop;
  
    v_qtdediff := 0;
  
    select count(1)
      into v_qtdediff
      from dual
     where exists (select t.idproduto
              from (select pnf.idproduto, sum(pnf.qtdeunidade) qtde
                       from paletseparacaonf pnf
                      where pnf.idromaneio = p_idromaneio
                      group by pnf.idproduto
                     union all
                     select ps.idproduto, sum(ps.qtdeunit * -1) qtde
                       from paletseparacao ps
                      where ps.idromaneio = p_idromaneio
                      group by ps.idproduto) t
             group by t.idproduto
            having sum(t.qtde) <> 0);
  
    if v_qtdediff > 0 then
    
      v_msg := t_message('As quantidades solicitadas em nota/pedido e reservadas para ' ||
                         'separação estão divergentes. Valide a parametrização para ter certeza ' ||
                         'que será possível atender as quantidades solicitadas.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  /*
   * Atualiza o romaneiopai
  */
  procedure AtualizarRomaneio(p_romaneio in romaneiopai%rowtype) is
  begin
    update romaneiopai r
       set iddoca                 = p_romaneio.iddoca,
           idusuario              = p_romaneio.idusuario,
           placa                  = p_romaneio.placa,
           idmestre               = p_romaneio.idmestre,
           codigointerno          = p_romaneio.codigointerno,
           datageracao            = p_romaneio.datageracao,
           dataprocessamento      = p_romaneio.dataprocessamento,
           tituloromaneio         = p_romaneio.tituloromaneio,
           calculanumpalet        = p_romaneio.calculanumpalet,
           processado             = p_romaneio.processado,
           gerado                 = p_romaneio.gerado,
           liberado               = p_romaneio.liberado,
           erro                   = p_romaneio.erro,
           faturado               = p_romaneio.faturado,
           impseparacao           = p_romaneio.impseparacao,
           impconferencia         = p_romaneio.impconferencia,
           impabastecimento       = p_romaneio.impabastecimento,
           coletado               = nvl(p_romaneio.coletado, 'N'),
           datacoleta             = p_romaneio.datacoleta,
           idarmazem              = p_romaneio.idarmazem,
           nummaxpalet            = p_romaneio.nummaxpalet,
           dataenviadofaturamento = p_romaneio.dataenviadofaturamento,
           separado               = nvl(p_romaneio.separado, 'N'),
           reentrega              = p_romaneio.reentrega,
           idpacote               = p_romaneio.idpacote,
           embarqueliberado       = p_romaneio.embarqueliberado,
           idusuariocoleta        = p_romaneio.idusuariocoleta,
           impetiquetavolume      = p_romaneio.impetiquetavolume,
           dataliberacao          = p_romaneio.dataliberacao,
           pesagemliberada        = p_romaneio.pesagemliberada,
           dtpesagemliberada      = p_romaneio.dtpesagemliberada,
           idromaneiokit          = p_romaneio.idromaneiokit
     where idromaneio = p_romaneio.idromaneio;
  end;

  /*
   * Gera a convocacao ativa para o romaneio
  */
  procedure GeraConvocacaoAtiva
  (
    p_idromaneio     in number,
    p_usuario        in number,
    p_gerarseparacao in varchar2
  ) is
    b_usaSeparacao             boolean;
    v_codromaneio              romaneiopai.codigointerno%type;
    v_separacaoobrigatoria     char(1);
    v_idarmazem                number;
    v_modelorelatorioseparacao number;
    v_doca                     doca.descr%type;
    v_utilizaconferenciaregiao number;
    v_reentrega                romaneiopai.reentrega%type;
    v_liberado                 romaneiopai.liberado%type;
    v_tituloromaneio           romaneiopai.tituloromaneio%type;
  begin
    b_usaSeparacao := True;
  
    select c.modelorelatorioseparacao, c.separacaoobrigatoria,
           c.utilizaconferenciaregiao
      into v_modelorelatorioseparacao, v_separacaoobrigatoria,
           v_utilizaconferenciaregiao
      from configuracao c
     where c.ativo = 'S';
  
    select rp.codigointerno, rp.idarmazem, d.descr, rp.reentrega,
           rp.liberado, rp.tituloromaneio
      into v_codromaneio, v_idarmazem, v_doca, v_reentrega, v_liberado,
           v_tituloromaneio
      from romaneiopai rp, doca d
     where d.iddoca = nvl(rp.iddoca, d.iddoca)
       and d.idarmazem = rp.idarmazem
       and rp.idromaneio = p_idromaneio
       and rownum = 1;
  
    if p_gerarseparacao = 'S' then
      if (v_modelorelatorioseparacao = 4) then
        pk_convocacao.insereSepPorRegiao(p_usuario, v_codromaneio);
      else
        pk_convocacao.insereSeparacao(p_usuario, v_codromaneio,
                                      'Separar Romaneio ' || v_codromaneio,
                                      b_usaSeparacao);
      end if;
    end if;
  
    if (v_separacaoobrigatoria = 'N')
       or ((v_reentrega = 'S') and (v_liberado = 'N')) then
      if (v_utilizaconferenciaregiao = 1) then
        pk_convocacao.insereConfSaidaPorRegiao(p_usuario, v_codromaneio);
      else
        pk_convocacao.insereConfSaida(p_usuario, v_codromaneio,
                                      v_tituloromaneio ||
                                       ' - Conferir Romaneio ' ||
                                       v_codromaneio || ' (Doca ' || v_doca || ')',
                                      v_idarmazem);
      end if;
    end if;
  
  end;

  /*
   * Retorna iddepositante para romaneio.
  */
  function RetornarIdDepositante(p_romaneio in number) return number is
    v_dep number;
  begin
    for c_dep in (select distinct nf.iddepositante
                    from nfromaneio nfr, notafiscal nf
                   where nf.idnotafiscal = nfr.idnotafiscal
                     and nfr.idromaneio = p_romaneio)
    loop
      if v_dep is null then
        v_dep := c_dep.iddepositante;
      else
        v_dep := null;
      end if;
    end loop;
  
    return v_dep;
  end;

  /*
   * Retorna depositante para romaneio.
  */
  function RetornarDepositante(p_romaneio in number) return varchar2 is
    v_dep varchar2(1000);
  begin
    begin
      select distinct d.razaosocial
        into v_dep
        from nfromaneio nfr, notafiscal nf, entidade d
       where d.identidade = nf.iddepositante
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
    exception
      when too_many_rows then
        select decode(tipo, 0, 'ROMANEIO COM MAIS DE UM DEPOSITANTE', 1,
                       'ONDA COM MAIS DE UM DEPOSITANTE')
          into v_dep
          from romaneiopai rp
         where rp.idromaneio = p_romaneio;
    end;
  
    return v_dep;
  end;

  /*
   * Retorna destinatario para romaneio.
  */
  function RetornarIdDestinatario(p_romaneio in number) return number is
    v_dest number;
  begin
    for c_dest in (select distinct nf.destinatario
                     from nfromaneio nfr, notafiscal nf
                    where nf.idnotafiscal = nfr.idnotafiscal
                      and nfr.idromaneio = p_romaneio)
    loop
      if v_dest is null then
        v_dest := c_dest.destinatario;
      else
        v_dest := null;
      end if;
    end loop;
  
    return v_dest;
  end;

  /*
   * Retorna destinatario para romaneio.
  */
  function RetornarDestinatario(p_romaneio in number) return varchar2 is
    v_dest varchar2(1000);
  begin
    for c_dest in (select distinct d.razaosocial
                     from nfromaneio nfr, notafiscal nf, entidade d
                    where d.identidade = nf.destinatario
                      and nf.idnotafiscal = nfr.idnotafiscal
                      and nfr.idromaneio = p_romaneio)
    loop
      if v_dest is null then
        v_dest := c_dest.razaosocial;
      else
        v_dest := 'ROMANEIO COM MAIS DE UM DESTINATARIO';
      end if;
    end loop;
  
    return v_dest;
  end;

  /*
   * Retorna transportadora para romaneio.
  */
  function RetornarTransportadora(p_romaneio in number) return varchar2 is
    v_transp varchar2(1000);
  begin
    begin
      select distinct t.razaosocial
        into v_transp
        from nfromaneio nfr, notafiscal nf, entidade t
       where t.identidade = nf.transportadoranotafiscal
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = p_romaneio;
    
    exception
      when too_many_rows then
        select decode(tipo, 0, 'ROMANEIO COM MAIS DE UMA TRANSPORTADORA', 1,
                       'ONDA COM MAIS DE UMA TRANSPORTADORA')
          into v_transp
          from romaneiopai rp
         where rp.idromaneio = p_romaneio;
    end;
  
    return v_transp;
  end;

  /*
   * Retorna Entidade Entrega para romaneio.
  */
  function RetornarEntEntrega(p_romaneio in number) return varchar2 is
    v_dest varchar2(1000);
  begin
    for c_dest in (select distinct d.razaosocial
                     from nfromaneio nfr, notafiscal nf, entidade d
                    where d.identidade = nf.ident_entrega
                      and nf.idnotafiscal = nfr.idnotafiscal
                      and nfr.idromaneio = p_romaneio)
    loop
      if v_dest is null then
        v_dest := c_dest.razaosocial;
      else
        v_dest := 'ROMANEIO COM MAIS DE UM DESTINATARIO DE ENTREGA';
      end if;
    end loop;
  
    return v_dest;
  end;

  /*
   * Funcao que retorna os usuarios do paletseparacao
  */
  function RetornarUsuarioSepararao
  (
    p_romaneio in number,
    p_palet    in number
  ) return varchar2 is
    v_usuario varchar(5000);
  begin
    for c in (select u.nomeusuario
                from romaneiopai rp, usuario u
               where u.idusuario = rp.idusuarioseparacao
                 and rp.idromaneio = p_romaneio
              union
              select distinct u.nomeusuario
                from paletseparacao ps, usuario u
               where u.idusuario = ps.idusuario
                 and ps.idromaneio = p_romaneio
                 and ps.idpalet = p_palet)
    loop
      if v_usuario is null then
        v_usuario := c.nomeusuario;
      else
        v_usuario := v_usuario || ', ' || c.nomeusuario;
      end if;
    end loop;
    return v_usuario;
  end;

  /*
   * Rotina que vincula o usuario se vai separar ao palet
  */
  procedure AgendarUsuario
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
    v_separado char;
    v_msg      t_message;
  begin
    select separado
      into v_separado
      from romaneiopai
     where idromaneio = p_romaneio;
    if v_separado = 'N' then
      update palet
         set idusuario = p_usuario
       where idromaneio = p_romaneio;
      update romaneiopai
         set idusuarioseparacao = p_usuario
       where idromaneio = p_romaneio;
    else
      v_msg := t_message('ESTE ROMANEIO ENCONTRA-SE SEPARADO!');
      raise_application_error('-20001', v_msg.formatMessage);
    end if;
  end;

  -- Inicia a Separacao Manual
  procedure IniSeparacaoManual
  (
    p_idromaneio    in number,
    p_idusuario     in number,
    p_idusuariovinc in number
  ) is
  
    v_achou boolean;
    v_msg   t_message;
  begin
    for c_separacao in (select separado
                          from palet
                         where idromaneio = p_idromaneio
                           and separado = 'S')
    loop
      v_achou := True;
    end loop;
  
    if v_achou = True then
      v_msg := t_message('ESTE ROMANEIO ENCONTRA-SE SEPARADO!');
      raise_application_error('-20001', v_msg.formatMessage);
    end if;
  
    update palet
       set separado = 'N'
     where idromaneio = p_idromaneio
       and separado = 'N';
  
    update paletseparacao ps
       set ps.idusuario = p_idusuariovinc
     where ps.idromaneio = p_idromaneio
       and ps.separado = 'N';
  
    update romaneiopai
       set idusuarioseparacao  = p_idusuariovinc,
           datainicioseparacao = sysdate
     where idromaneio = p_idromaneio;
  
    -- Altera o romaneio de desmontagem de kit para em separação
    update ordemservico
       set situacao = 'S'
     where idromaneio = p_idromaneio
       and tiposervico = 'D';
  
    pk_utilities.GeraLog(p_idusuario,
                         'Iniciada a Separacao do Romaneio: ' ||
                          p_idromaneio || ' Pelo usuario: ' ||
                          p_idusuariovinc || '.', p_idromaneio, '');
  end;

  -- Finaliza a Separacao Manual
  procedure FinSeparacaoManual
  (
    p_idromaneio in number,
    p_idusuario  in number
  ) is
  
    v_achou      boolean;
    v_iduservinc number;
    v_tipo       number;
    v_msg        t_message;
  begin
    select rp.tipo
      into v_tipo
      from romaneiopai rp
     where rp.idromaneio = p_idromaneio;
  
    if v_tipo = 1 then
      v_msg := t_message('Separação Manual não pode ser realizada para onda.' ||
                         ' Operação Cancelada.');
      raise_application_error('-20001', v_msg.formatMessage);
    elsif v_tipo = 0 then
      for c_separacao in (select separado
                            from palet
                           where idromaneio = p_idromaneio
                             and separado = 'S')
      loop
        v_achou := True;
      end loop;
    
      if v_achou = True then
        v_msg := t_message('ESTE ROMANEIO ENCONTRA-SE SEPARADO!');
        raise_application_error('-20001', v_msg.formatMessage);
      end if;
    
      update paletseparacao
         set idusuario = p_idusuario,
             dtinicio  = sysdate,
             dtfim     = sysdate,
             separado  = 'S'
       where idromaneio = p_idromaneio;
    
      update palet
         set separado = 'S'
       where idromaneio = p_idromaneio
         and separado = 'N';
    
      update romaneiopai
         set datafinalseparacao  = sysdate,
             datainicioseparacao = nvl(datainicioseparacao, sysdate),
             idusuarioseparacao  = nvl(idusuarioseparacao, p_idusuario),
             separado            = 'S'
       where idromaneio = p_idromaneio;
    
      begin
        select r.idusuarioseparacao
          into v_iduservinc
          from romaneiopai r
         where idromaneio = p_idromaneio;
      exception
        when others then
          v_iduservinc := p_idusuario;
      end;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Finalizada a Separacao do Romaneio: ' ||
                            p_idromaneio || ' Pelo usuario: ' ||
                            v_iduservinc || '.', p_idromaneio, '');
    end if;
  end;

  /*
   * Rotina que troca o usuario da separacao
  */
  procedure TrocarUsuarioSeparacao
  (
    p_romaneio     in number,
    p_usuario      in number,
    p_usuariotroca in number
  ) is
    v_userantigo usuario.nomeusuario%type;
    v_usernovo   usuario.nomeusuario%type;
    v_msg        t_message;
  begin
    begin
      select distinct nomeusuario
        into v_userantigo
        from romaneiopai r, usuario u
       where u.idusuario = r.idusuarioseparacao
         and r.idromaneio = p_romaneio;
    exception
      when no_data_found then
        v_msg := t_message('USUARIO NAO ENCONTRADO NA SEPARACAO.');
        raise_application_error('-20001', v_msg.formatMessage);
    end;
    begin
      select nomeusuario
        into v_usernovo
        from usuario
       where idusuario = p_usuariotroca;
    exception
      when no_data_found then
        v_msg := t_message('USUARIO NAO ENCONTRADO.');
        raise_application_error('-20002', v_msg.formatMessage);
    end;
  
    update romaneiopai
       set idusuarioseparacao = p_usuariotroca
     where idromaneio = p_romaneio;
  
    update palet
       set idusuario = p_usuariotroca
     where idromaneio = p_romaneio;
  
    pk_utilities.GeraLog(p_usuario,
                         'TROCADO O USUARIO ' || v_userantigo || ' PELO ' ||
                          v_usernovo || ' DO ROMANEIO: ' || p_romaneio || '.',
                         p_romaneio, '');
  end;

  /*
   * Rotina que cancela a separacao do romaneio
  */
  procedure CancelarSeparacao
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
    v_conf number;
    v_msg  t_message;
  begin
    select count(idconf)
      into v_conf
      from confpalet
     where idromaneio = p_romaneio;
  
    if v_conf > 0 then
      v_msg := t_message('ESTA SEPARACAO NAO PODE SER CANCELADA POIS ESTA EM CONFERENCIA');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update palet
       set separado       = 'N',
           idusuario      = null,
           fichaseparacao = null
     where idromaneio = p_romaneio;
  
    update paletseparacao
       set separado  = 'N',
           idusuario = null,
           dtinicio  = null,
           dtfim     = null
     where idromaneio = p_romaneio;
  
    update romaneiopai
       set idusuarioseparacao  = null,
           datainicioseparacao = null,
           datafinalseparacao  = null
     where idromaneio = p_romaneio;
  
    pk_utilities.GeraLog(p_usuario,
                         'Cancelada a Separacao do Romaneio: ' ||
                          p_romaneio || '.', p_romaneio, '');
  
  end;

  /*
  * Retorna a uma coleta automatica
  */
  function RetornaColetaAutomatica(p_romaneio in number) return number is
    cursor c_carga(p_transportadora in number) is
      select c.idcarga
        from carga c
       where c.embarqueliberado = 'N'
         and c.finalizado = 'N'
         and c.idtransportadora = p_transportadora
         and c.idarmazem =
             (select idarmazem
                from romaneiopai rp
               where rp.idromaneio = p_romaneio);
  
    cursor c_notafiscal(p_romaneio in number) is
      select en.identidade transportadoranotafiscal, en.cgc cnpjtransp,
             nf.codigointerno, nvl(d.realizacoleta, 'N') realizacoleta
        from nfromaneio nfr, notafiscal nf, entidade e, entidade en,
             depositante d
       where nfr.idromaneio = p_romaneio
         and nf.idnotafiscal = nfr.idnotafiscal
         and e.identidade(+) = nf.transportadoranotafiscal
         and en.cgc(+) = e.cgc
         and en.iddepositante is null
         and d.identidade = nf.iddepositante;
  
    r_romaneio   romaneiopai%rowtype;
    r_notafiscal c_notafiscal%rowtype;
    r_carga      c_carga%rowtype;
    v_msg        t_message;
  begin
    r_romaneio := carregar_romaneio(p_romaneio);
    -- verifica se o romaneio possui nota fiscal vinculada 
    if c_notafiscal%isopen then
      close c_notafiscal;
    end if;
    open c_notafiscal(p_romaneio);
    fetch c_notafiscal
      into r_notafiscal;
    if (c_notafiscal%found)
       and (r_notafiscal.realizacoleta = 'S') then
      -- verifica se a nota fiscal do romaneio possui transportadora cadastrada
      if (r_notafiscal.transportadoranotafiscal is not null)
         and (r_notafiscal.cnpjtransp is not null) then
        -- verifica se existe alguma carga NAO LIBERADA PARA EMBARQUE 
        -- e que seja da mesma TRANSPORTADORA da nota fiscal
        if c_carga%isopen then
          close c_carga;
        end if;
        open c_carga(r_notafiscal.transportadoranotafiscal);
        fetch c_carga
          into r_carga;
        if c_carga%notfound then
          -- cria uma carga
          r_carga.idcarga := 0;
          /* else
          --Apenas para locar a registro para rotina não executar finalização da carga durante formação do romaneio.
          update carga
             set embarqueliberado = embarqueliberado
           where idcarga = r_carga.idcarga;*/
        end if;
      
      elsif r_notafiscal.transportadoranotafiscal is null then
        v_msg := t_message('ERRO AO VINCULAR ROMANEIO NUM: {0}' ||
                           ' A COLETA. NOTA FISCAL NUM: {1}' ||
                           ' NÃO POSSUI TRANSPORTADORA CADASTRADA.');
        v_msg.addParam(r_romaneio.codigointerno);
        v_msg.addParam(r_notafiscal.codigointerno);
        raise_application_error(-20000, v_msg.formatMessage);
      else
        v_msg := t_message('ERRO AO VINCULAR ROMANEIO NUM: {0}' ||
                           ' A COLETA. NOTA FISCAL NUM: {1}' ||
                           ' POSSUI TRANSPORTADORA COM CNPJ EM BRANCO.');
        v_msg.addParam(r_romaneio.codigointerno);
        v_msg.addParam(r_notafiscal.codigointerno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    elsif (r_notafiscal.realizacoleta = 'S') then
      v_msg := t_message('ERRO AO VINCULAR ROMANEIO NUM: {0}' ||
                         ' A COLETA. NAO FOI ENCONTRADA TRANSPORTADORA NAO VINCULADA A DEPOSITANTE.');
      v_msg.addParam(r_romaneio.codigointerno);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
    -- fecha os cursores
    if c_notafiscal%isopen then
      close c_notafiscal;
    end if;
    if c_carga%isopen then
      close c_carga;
    end if;
  
    return r_carga.idcarga;
  end;

  function RetornarIdNF(p_romaneio in varchar2) return number is
    v_nf    number;
    v_count number;
  begin
    v_nf    := 0;
    v_count := 0;
    for c_nf in (select distinct nf.idnotafiscal
                   from nfromaneio r, notafiscal nf
                  where r.idromaneio in (p_romaneio)
                    and nf.idnotafiscal = r.idnotafiscal)
    loop
      v_count := v_count + 1;
      v_nf    := c_nf.idnotafiscal;
    
    end loop;
    if v_count > 1 then
      v_nf := 0;
    end if;
    return v_nf;
  end;

  /*
  *  Funcao que retorno transportadora da nota fiscal
  */
  function RetornaTransportadora(p_romaneio in number) return number is
    v_transp number;
    v_count  number;
  begin
    v_count := 0;
    for c_nf in (select e.identidade transportadoranotafiscal
                   from nfromaneio nfr, notafiscal nf, entidade e
                  where nfr.idromaneio = p_romaneio
                    and nf.idnotafiscal = nfr.idnotafiscal
                    and e.identidade(+) = nf.transportadoranotafiscal
                    and e.iddepositante is null)
    loop
      v_count  := v_count + 1;
      v_transp := c_nf.transportadoranotafiscal;
    end loop;
  
    if v_count > 1 then
      v_transp := null;
    end if;
  
    return v_transp;
  end;

  procedure auditarromaneio
  (
    p_romaneio in number,
    p_usuario  in number
  ) is
    v_qtdevolumes number;
  begin
  
    select count(*) total
      into v_qtdevolumes
      from volumeromaneio
     where idromaneio = p_romaneio;
  
    delete from volumeromaneio
     where idromaneio = p_romaneio;
  
    update romaneiopai
       set auditarconfsaida   = 'S',
           idusuarioauditoria = p_usuario,
           liberado           = 'N',
           pesagemliberada    = 'N',
           dtpesagemliberada  = null
     where idromaneio = p_romaneio;
  
    update palet
       set liberado   = 'N',
           recontagem = 'S'
     where idromaneio = p_romaneio;
  
    update romaneio
       set qtdeconf = 0
     where idromaneio = p_romaneio;
  
    update confpalet
       set liberado = 'N'
     where idromaneio = p_romaneio;
  
    pk_utilities.GeraLog(p_usuario,
                         'USUARIO ID: ' || p_usuario ||
                          ' ENVIOU O ROMANEIO ID: ' || p_romaneio ||
                          ' PARA AUDITORIA COM QUANTIDADE ATUAL DE ' ||
                          v_qtdevolumes || ' VOLUMES', p_romaneio, '');
  end;

  /*
   * Rotina responsavel em alimentar as tabelas de separação a partir de romaneio formados pela nova rotina (Java)
  */
  procedure preencherInfSeparacao
  (
    p_romaneio       in number,
    p_idconfiguracao in number
  ) is
  begin
    delete from mapaseparacaoonda
     where idonda = p_romaneio;
  
    delete from mapasepondapedido
     where idonda = p_romaneio;
  
    delete from paletseparacao
     where idromaneio = p_romaneio;
  
    delete from paletseparacaocliente
     where idromaneio = p_romaneio;
  
    delete from paletseparacaonf
     where idromaneio = p_romaneio;
  
    delete from produtopalet
     where idromaneio = p_romaneio;
  
    delete from palet
     where idromaneio = p_romaneio;
  
    delete from paletseparacaonf
     where idromaneio = p_romaneio;
  
    delete from romaneio
     where idromaneio = p_romaneio;
  
    pk_onda.criarMapaSeparacaoOnda(p_romaneio, p_idconfiguracao);
    pk_onda.criarMapaSeparacaoOndaPedido(p_romaneio, p_idconfiguracao);
  
    insert into romaneio
      (idromaneio, idproduto, barra, qtdeaseparar, qtdeconf)
      select nfr.idromaneio, nd.idproduto, nd.barra,
             sum(nd.qtdeatendida * e.fatorconversao) qtdeaseparar,
             0 qtdeconf
        from nfromaneio nfr, nfdet nd, embalagem e
       where e.barra = nd.barra
         and e.idproduto = nd.idproduto
         and nfr.idnotafiscal = nd.nf
         and nfr.idromaneio = p_romaneio
       group by nfr.idromaneio, nd.idproduto, nd.barra;
  
    insert into produtopalet
      (idromaneio, idpalet, iddepositante, identidade, idproduto, barra,
       qtde, liberado)
      select nfr.idromaneio, 1 palet, nf.iddepositante, nf.destinatario,
             nd.idproduto, nd.barra, sum(nd.qtdeatendida) qtde, 'N' liberado
        from nfromaneio nfr, nfdet nd, notafiscal nf, embalagem e
       where nfr.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = nd.nf
         and e.barra = nd.barra
         and e.idproduto = nd.idproduto
         and nfr.idromaneio = p_romaneio
       group by nfr.idromaneio, 1, nf.iddepositante, nf.destinatario,
                nd.idproduto, nd.barra;
  
    insert into paletseparacaocliente
      (idromaneio, idpalet, idarmazem, idlocal, identidade, idproduto,
       barra, qtde, ordem)
      select m.idonda, 1 palet, lo.idarmazem, lo.idlocal, nf.ident_entrega,
             l.idproduto, l.barra,
             sum(round(m.quantidade / e.fatorconversao, 6)) qtde, 1 ordem
        from movimentacao m, lote l, local lo, embalagem e, notafiscal nf
       where nf.idnotafiscal = m.idnotafiscal
         and e.barra = l.barra
         and e.idproduto = l.idproduto
         and lo.id = m.idlocalorigem
         and l.idlote = m.idlote
         and m.etapa in (1, 2)
         and m.status in (0, 1, 2)
         and m.idonda = p_romaneio
       group by m.idonda, lo.idarmazem, lo.idlocal, l.idproduto, l.barra,
                nf.ident_entrega;
  
    preencherPaletSepNFOnda(p_romaneio);
  end;

  /*
   * Rotina responsavel em inserir notas fiscais na carga
  */
  procedure inserirNFCarga
  (
    p_romaneio in number,
    p_carga    in number
  ) is
    v_ordem      number;
    v_tipoColeta number;
  begin
    if p_carga is not null then
    
      if pk_carga.isColetaAutomatica(p_carga, null, null) then
        v_tipoColeta := C_AUTOMATICA;
      else
        v_tipoColeta := C_MANUAL;
      end if;
    
      select nvl(max(ordem), 0) + 1
        into v_ordem
        from notafiscalcarga
       where idcarga = p_carga;
    
      for c_nota in (select idnotafiscal
                       from nfromaneio
                      where idromaneio = p_romaneio)
      loop
        insert into notafiscalcarga
          (idcarga, idnotafiscal, ordem, embarqueliberado)
        values
          (p_carga, c_nota.idnotafiscal, v_ordem,
           decode(v_tipoColeta, C_AUTOMATICA, 'N', 'S'));
        v_ordem := v_ordem + 1;
      end loop;
    end if;
  end;

  /*
  * Verifica Remanejamentos Pendentes do Romaneio
  */
  procedure VerificaRemanejRomaneio
  (
    p_idromaneio   in number,
    p_complementar in varchar2
  ) is
    cursor c_remanej(p_idromaneio in number) is
      select distinct r.idremanejamento
        from remanejamento r, remanejamentoromaneio rr
       where rr.idremanejamento = r.idremanejamento
         and rr.idromaneio = p_idromaneio
         and r.status = C_AGUARDANDO
       order by r.idremanejamento;
  
    r_remanej         c_remanej%rowtype;
    v_idremanejamento varchar2(4000);
    v_msg             t_message;
  begin
    if c_remanej%isopen then
      close c_remanej;
    end if;
  
    open c_remanej(p_idromaneio);
    fetch c_remanej
      into r_remanej;
  
    if c_remanej%found then
      v_idremanejamento := ' ';
      while c_remanej%found
      loop
        if v_idremanejamento = ' ' then
          v_idremanejamento := to_char(r_remanej.idremanejamento);
        else
          if length(v_idremanejamento) + length(', ') +
             length(to_char(r_remanej.idremanejamento)) <= 4000 then
            v_idremanejamento := v_idremanejamento || ', ' ||
                                 to_char(r_remanej.idremanejamento);
          end if;
        end if;
      
        fetch c_remanej
          into r_remanej;
      end loop;
    
      v_msg := t_message('{0}' || CHR(13) ||
                         'EXISTEM PENDENCIAS DO(s) REMANEJAMENTO(s):' ||
                         CHR(13) || '{1}' || CHR(13) ||
                         'PARA ESTE ROMANEIO: ' || '{2}');
      v_msg.addParam(p_complementar);
      v_msg.addParam(v_idremanejamento);
      v_msg.addParam(p_idromaneio);
      raise_application_error(-20000, v_msg.formatMessage);
    
    end if;
  
  end;

  /*
  * Insere na tabela LogRomaneioCorte e LogDetRomaneioCorte
  */
  procedure InsereLogRomaneioCorte(p_idRomaneio in number) is
    v_idlogRomaneioCorte number;
  begin
    select seq_romaneiocorte.nextval
      into v_idlogRomaneioCorte
      from dual;
  
    insert into LogRomaneioCorte
      (idlogromcorte, idromaneio, codigointerno, tituloromaneio,
       datageracao)
      select v_idlogRomaneioCorte, rp.idromaneio, rp.codigointerno,
             rp.tituloromaneio, trunc(rp.datageracao) datageracao
        from romaneiopai rp
       where rp.idromaneio = p_idRomaneio;
  
    for c_DetRomaneioCorte in (select distinct nf.idnotafiscal,
                                               nf.codigointerno nf,
                                               nf.sequencia,
                                               trunc(nf.datasaidaentrada) datasaidaentrada,
                                               nf.iddepositante,
                                               nf.destinatario, nf.remetente,
                                               prod.idproduto, e.barra,
                                               re.qtdepedido,
                                               re.qtdedisponivelpk,
                                               re.qtdedisponivelpl,
                                               re.qtdepedido -
                                                re.qtdedisponivelpk qtdecorte
                                 from corteromaneio re, palet p, embalagem e,
                                      produto prod, entidade d,
                                      nfromaneio nfr, notafiscal nf,
                                      nfdet nfd, entidade c, romaneiopai rp
                                where p.idromaneio = re.idromaneio
                                  and p.idpalet = re.idpalet
                                  and e.idproduto = re.idproduto
                                  and e.barra = re.barra
                                  and prod.idproduto = re.idproduto
                                  and d.identidade = re.identidade
                                  and nfr.idromaneio = re.idromaneio
                                  and nf.idnotafiscal = nfr.idnotafiscal
                                  and nfd.nf = nf.idnotafiscal
                                  and nfd.idproduto = re.idproduto
                                  and c.identidade = nf.destinatario
                                  and rp.idromaneio = nfr.idromaneio
                                  and re.idromaneio = p_idromaneio)
    loop
      insert into LogDetRomaneioCorte
        (idlogdet, idlogcorteromaneio, idnotafiscal, numnf, seqnf,
         datageracao, iddepositante, destinatario, emitente, idproduto,
         barra, qtdepedido, qtdedisponivelpk, qtdedisponivelpl, qtdecorte)
      values
        (seq_detromaneiocorte.nextval, v_idlogromaneiocorte,
         c_detromaneiocorte.idnotafiscal, c_detromaneiocorte.nf,
         c_detromaneiocorte.sequencia, c_detromaneiocorte.datasaidaentrada,
         c_detromaneiocorte.iddepositante, c_detromaneiocorte.destinatario,
         c_detromaneiocorte.remetente, c_detromaneiocorte.idproduto,
         c_detromaneiocorte.barra, c_detromaneiocorte.qtdepedido,
         c_detromaneiocorte.qtdedisponivelpk,
         c_detromaneiocorte.qtdedisponivelpl, c_detromaneiocorte.qtdecorte);
    end loop;
  
  end;
  /*
   * Retornar consulta de reabastecimentos 
  */
  function ConsultaLoteReab(p_idremanejamento in number) return varchar2 is
    v_idLote varchar2(1000);
  begin
    v_idLote := '';
    for c_id in (select lr.idlote
                   from loteremanejamento lr
                  where lr.idremanejamento = p_idremanejamento)
    loop
      if length(trim(v_idLote)) > 0 then
        v_idLote := v_idLote || ',' || to_char(c_id.idlote);
      else
        v_idLote := to_char(c_id.idlote);
      end if;
    end loop;
  
    return v_idLote;
  end;

  function retornarFaturado(p_idromaneio in number) return char is
    v_vincularnfnaoimpressa number;
    v_faturado              char(1);
  begin
    for c in (select rp.faturado,
                     sum(decode(nf.impresso, 'N', 1, 0)) impresso,
                     d.vincularnfnaoimpressacarga
                from romaneiopai rp, nfromaneio nfr, notafiscal nf,
                     depositante d
               where rp.idromaneio = p_idromaneio
                 and nfr.idromaneio = rp.idromaneio
                 and nf.idnotafiscal = nfr.idnotafiscal
                 and d.identidade = nf.iddepositante
               group by rp.faturado, d.vincularnfnaoimpressacarga)
    loop
      if c.vincularnfnaoimpressacarga = 0 then
        if c.impresso > 0 then
          v_faturado := 'N';
        else
          v_faturado := 'S';
        end if;
      else
        v_faturado := c.faturado;
      end if;
    end loop;
    return v_faturado;
  end;

  /*
   * Retorna STRING com os Pedidos do Romaneio
  */
  function RetornaPedFornecRomaneio(p_romaneio in varchar2) return varchar2 is
    v_pedido varchar2(10000);
  begin
    v_pedido := '';
    for c_nf in (select distinct nf.numpedidofornecedor
                   from nfromaneio r, notafiscal nf
                  where r.idromaneio in (p_romaneio)
                    and nf.idnotafiscal = r.idnotafiscal)
    loop
      if length(trim(v_pedido)) > 0 then
        v_pedido := v_pedido || ',' || to_char(c_nf.numpedidofornecedor);
      else
        v_pedido := to_char(c_nf.numpedidofornecedor);
      end if;
    end loop;
  
    return trim(v_pedido);
  end;

  /*
  * Retorna a Doca da Onda
  */
  function RetornaDocaOnda
  (
    p_idonda            in number,
    id_transportadoranf in number,
    v_codvolume         in varchar2
  ) return varchar2 is
    v_doca varchar2(15);
  begin
    for c_doca in (select distinct d.descr
                     from volumeromaneio vr, destinosaidaonda ds, doca d
                    where ds.iddoca = d.idendereco
                      and ds.idonda = vr.idromaneio
                      and vr.codbarra = v_codvolume
                      and ds.identidade = id_transportadoranf
                      and ds.idonda = p_idonda)
    loop
      v_doca := c_doca.descr;
    end loop;
  
    return trim(v_doca);
  end;

  /*
  * Retorna Melhor Instrumento para Separacao do Material
  */
  function RetornaInstrumento
  (
    p_idarmazem in number,
    p_peso      in number,
    p_andar     in varchar2
  ) return varchar2 is
    v_instrumento varchar2(100);
  begin
    v_instrumento := '';
    for c_inst in (select descricao
                     from instrumentoseparacao
                    where idarmazem = p_idarmazem
                      and ativo = 1
                      and peso >= p_peso
                      and andar >= p_andar
                    order by peso, andar)
    loop
      --Retorna o melhor instrumento para separacao
      if v_instrumento is null then
        v_instrumento := c_inst.descricao;
      end if;
    
    end loop;
  
    return v_instrumento;
  end;

  procedure atualizaDocumentoRomaneio
  (
    p_idromaneio   in number,
    p_idnotafiscal in number,
    p_tipo         in number
  ) is
    v_notafiscal romaneiopai.notafiscal%type;
    v_numpedido  romaneiopai.numpedido%type;
  begin
    -- Inserção: Tipo = 0; 
    -- Exclusao: Tipo = 1;
  
    if p_tipo = 0 then
      select codigointerno notafiscal, numpedidofornecedor numpedido
        into v_notafiscal, v_numpedido
        from notafiscal
       where idnotafiscal = p_idnotafiscal;
    
      insert into documentoromaneio
        (idromaneio, idnotafiscal, notafiscal, numpedido)
      values
        (p_idromaneio, p_idnotafiscal, v_notafiscal, v_numpedido);
    
    else
      delete from documentoromaneio
       where idromaneio = p_idromaneio
         and idnotafiscal = p_idnotafiscal;
    end if;
  end;

  procedure atualizaCargaRomaneio
  (
    p_idcarga      in number,
    p_idnotafiscal in number,
    p_tipo         in number
  ) is
    v_carga      romaneiopai.carga%type;
    v_idromaneio number;
    v_achou      number;
    v_motorista  varchar2(500);
    v_placa      varchar2(50);
  begin
    -- Inserção: Tipo = 0; 
    -- Exclusao: Tipo = 1;
    if p_tipo = 0 then
      select c.codigointerno, m.razaosocial, c.placa
        into v_carga, v_motorista, v_placa
        from carga c, entidade m
       where m.identidade(+) = c.idmotorista
         and c.idcarga = p_idcarga;
    
      select max(nfr.idromaneio)
        into v_idromaneio
        from nfromaneio nfr
       where nfr.idnotafiscal = p_idnotafiscal;
    
      select count(*)
        into v_achou
        from cargaromaneio
       where idcarga = p_idcarga
         and idnotafiscal = p_idnotafiscal
         and idromaneio = v_idromaneio;
    
      if v_achou = 0 then
        insert into cargaromaneio
          (idromaneio, idnotafiscal, idcarga, carga, motorista, placa)
        values
          (v_idromaneio, p_idnotafiscal, p_idcarga, v_carga, v_motorista,
           v_placa);
      end if;
    
    else
      delete from cargaromaneio
       where idcarga = p_idcarga
         and idnotafiscal = p_idnotafiscal;
    end if;
  end;

  procedure InsereClienteRomaneio
  (
    p_idRomaneio in number,
    p_idNF       in number
  ) is
    v_identrega number;
    v_msg       t_message;
  begin
    begin
      select ident_entrega
        into v_identrega
        from notafiscal
       where idnotafiscal = p_idNF;
    
      insert into clienteromaneio
      values
        (p_idromaneio, v_identrega, 'N');
    exception
      when dup_val_on_index then
        begin
          update clienteromaneio
             set ident_entrega = v_identrega
           where idromaneio = p_idromaneio
             and ident_entrega = v_identrega;
        exception
          when others then
            v_msg := t_message('ERRO AO INSERIR NA CLIENTEROMANEIO. {0}');
            v_msg.addParam(SQLERRM);
            raise_application_error(-20000, v_msg.formatMessage);
        end;
    end;
  
  end;
  /*
   * Retorna Pessoa Destinatario para romaneio.
  */
  function RetornarPessoaDestinatario(p_romaneio in number) return varchar2 is
    v_dep varchar2(1000);
  begin
    for c_dep in (select distinct decode(d.pessoa, 'J', 'JURIDICA', 'F',
                                          'FISICA') pessoa
                    from nfromaneio nfr, notafiscal nf, entidade d
                   where d.identidade = nf.ident_entrega
                     and nf.idnotafiscal = nfr.idnotafiscal
                     and nfr.idromaneio = p_romaneio)
    loop
      if v_dep is null then
        v_dep := c_dep.pessoa;
      else
        v_dep := 'ROMANEIO COM MAIS DE UM DESTINATARIO';
      end if;
    end loop;
  
    return v_dep;
  end;

  function retornarPontoAlerta(p_idromaneio in number) return varchar2 is
    v_alerta varchar2(5000);
  begin
    for c in (select trim(p.mensagem) alerta
                from nfromaneio nfr, pontoalerta p
               where p.idnotafiscal = nfr.idnotafiscal
                 and nfr.idromaneio = p_idromaneio)
    loop
      if v_alerta is null then
        v_alerta := substr(c.alerta, 1, 5000);
      else
        v_alerta := substr(trim(v_alerta || chr(13) || c.alerta), 1, 5000);
      end if;
    end loop;
    return v_alerta;
  end;

  function isCaixaSeparacaoLiberada
  (
    p_barracaixaseparacao in caixaseparacao.barra%type,
    p_idcaixaseparacao    in out number,
    p_mensagem            out varchar2
  ) return boolean is
    v_liberado number;
    v_tipo     number;
    v_msg      t_message;
  begin
    begin
      select idcaixaseparacao, liberado, tipo
        into p_idcaixaseparacao, v_liberado, v_tipo
        from caixaseparacao
       where barra = p_barracaixaseparacao;
    exception
      when no_data_found then
        p_idcaixaseparacao := null;
        v_liberado         := 0;
        v_tipo             := 0;
    end;
  
    if p_idcaixaseparacao is not null then
      if v_tipo = 2 then
        if v_liberado = 0 then
          v_msg      := t_message('A Caixa de Separação não está Liberada.' ||
                                  chr(13) || 'Operação Cancelada.');
          p_mensagem := v_msg.formatMessage;
        end if;
      else
        v_msg      := t_message('Código de barra da Caixa de Separação não corresponde a uma caixa do tipo Conferência.' ||
                                chr(13) || 'Operação Cancelada.');
        p_mensagem := v_msg.formatMessage;
      end if;
    else
      v_msg      := t_message('Código de barra da Caixa de Separação não foi encontrado.' ||
                              chr(13) || 'Operação Cancelada.');
      p_mensagem := v_msg.formatMessage;
    end if;
  
    return p_mensagem is null;
  end;
  function validarBancada
  (
    p_idromaneio       in number,
    p_idcaixaseparacao in number,
    p_mensagem         out varchar2
  ) return boolean is
    v_qtdeendereco number;
    v_msg          t_message;
  begin
    select count(distinct idendereco)
      into v_qtdeendereco
      from (select distinct cx.idendereco
               from caixaseparacaoromaneio cxr, caixaseparacao cx
              where cx.idcaixaseparacao = cxr.idcaixaseparacao
                and cxr.idromaneio = p_idromaneio
             union
             select cx.idendereco
               from caixaseparacao cx
              where cx.idcaixaseparacao = p_idcaixaseparacao);
  
    if v_qtdeendereco > 1 then
      v_msg      := t_message('O Local de Bancada da Caixa de Separação é diferente das que já estão vinculadas.' ||
                              chr(13) || 'Operação Cancelada.');
      p_mensagem := v_msg.formatMessage;
    end if;
    return p_mensagem is null;
  end;

  procedure vincularCaixaSeparacaoRomaneio
  (
    p_idromaneio          in number,
    p_barracaixaseparacao in caixaseparacao.barra%type,
    p_mensagem            out varchar2
  ) is
    v_idcaixaseparacao number;
    v_msg              t_message;
  begin
    if isCaixaSeparacaoLiberada(p_barracaixaseparacao, v_idcaixaseparacao,
                                p_mensagem) then
      if validarBancada(p_idromaneio, v_idcaixaseparacao, p_mensagem) then
        begin
          insert into caixaseparacaoromaneio
            (idromaneio, idcaixaseparacao)
          values
            (p_idromaneio, v_idcaixaseparacao);
        
          update caixaseparacao
             set liberado = 0
          
           where idcaixaseparacao = v_idcaixaseparacao;
        exception
          when dup_val_on_index then
            v_msg      := t_message('A Caixa de Separação já está vinculada.' ||
                                    chr(13) || 'Operação Cancelada.');
            p_mensagem := v_msg.formatMessage;
        end;
      
      end if;
    end if;
  end;

  procedure liberarCaixaSeparacacao
  (
    p_idromaneio       in number,
    p_idcaixaseparacao in number := null
  ) is
  begin
    if p_idcaixaseparacao is null then
      update caixaseparacao cx
         set cx.liberado = 1
       where exists (select 1
                from caixaseparacaoromaneio cr
               where cr.idromaneio = p_idromaneio
                 and cr.idcaixaseparacao = cx.idcaixaseparacao)
         and not exists
       (select 1
                from caixaseparacaoromaneio cr, romaneiopai rp
               where rp.liberado = 'N'
                 and rp.idromaneio = cr.idromaneio
                 and cr.idcaixaseparacao = cx.idcaixaseparacao
                 and cr.idromaneio <> p_idromaneio);
    else
      update caixaseparacao cx
         set cx.liberado = 1
       where cx.idcaixaseparacao = p_idcaixaseparacao
         and not exists
       (select 1
                from caixaseparacaoromaneio cr, romaneiopai rp
               where rp.liberado = 'N'
                 and rp.idromaneio = cr.idromaneio
                 and cr.idromaneio <> p_idromaneio
                 and cr.idcaixaseparacao = cx.idcaixaseparacao);
    
    end if;
  end;

  procedure calculaValoresRomaneio(p_idromaneio in number) is
    v_qtdematerial      number;
    v_qtdeexemplares    number;
    v_pesoteorico       number;
    v_qtderemanejamento number;
  begin
    select count(distinct n.idproduto),
           sum(n.qtdeatendida * e.fatorconversao),
           sum(n.qtdeatendida * e.pesobruto / 1000)
      into v_qtdematerial, v_qtdeexemplares, v_pesoteorico
      from nfromaneio nfr, nfdet n, embalagem e
     where nfr.idromaneio = p_idromaneio
       and n.nf = nfr.idnotafiscal
       and e.idproduto = n.idproduto
       and e.barra = n.barra;
  
    select count(distinct r.idremanejamento)
      into v_qtderemanejamento
      from remanejamentoromaneio r
     where r.idromaneio = p_idromaneio;
  
    update romaneiopai
       set pesoteorico        = v_pesoteorico,
           qtdematerial       = v_qtdematerial,
           qtdetotalmaterial  = v_qtdeexemplares,
           qtderemanejamentos = v_qtderemanejamento
     where idromaneio = p_idromaneio;
  end;

  procedure AtualizaStatusAuditoria(p_idRomaneio in number) is
    v_qtde_nao_audit   number;
    v_qtde_ag_audit    number;
    v_qtde_em_audit    number;
    v_qtde_audit       number;
    v_status           number;
    v_idnotafiscal     number;
    v_auditarconfsaida char(1);
  begin
    select sum(decode(auditoria, 0, 1, 0)), sum(decode(auditoria, 1, 1, 0)),
           sum(decode(auditoria, 2, 1, 0)), sum(decode(auditoria, 3, 1, 0))
      into v_qtde_nao_audit, v_qtde_ag_audit, v_qtde_em_audit, v_qtde_audit
      from volumeromaneio vr
     where vr.idromaneio = p_idRomaneio
       and vr.statusvolume = 0;
  
    if (v_qtde_em_audit > 0) then
      v_status := 2;
    elsif (v_qtde_ag_audit > 0) then
      v_status := 1;
    elsif ((v_qtde_nao_audit > 0) and
          (v_qtde_audit + v_qtde_ag_audit + v_qtde_em_audit = 0)) then
      v_status := 0;
    else
      v_status := 3;
    end if;
  
    select decode(v_status, 0, 'N', 1, 'G', 2, 'S', 3, 'A')
      into v_auditarconfsaida
      from dual;
  
    update romaneiopai rp
       set rp.auditarconfsaida = v_auditarconfsaida
     where rp.idromaneio = p_idRomaneio
       and rp.auditarconfsaida <> v_auditarconfsaida;
  
    for c_nf in (select idnotafiscal
                   from nfromaneio
                  where idromaneio = p_idRomaneio)
    loop
      select sum(decode(auditoria, 0, 1, 0)),
             sum(decode(auditoria, 1, 1, 0)),
             sum(decode(auditoria, 2, 1, 0)),
             sum(decode(auditoria, 3, 1, 0))
        into v_qtde_nao_audit, v_qtde_ag_audit, v_qtde_em_audit,
             v_qtde_audit
        from volumeromaneio vr
       where vr.idnotafiscal = c_nf.idnotafiscal
         and vr.statusvolume = 0;
    
      if (v_qtde_em_audit > 0) then
        v_status := 2;
      elsif (v_qtde_ag_audit > 0) then
        v_status := 1;
      elsif ((v_qtde_nao_audit > 0) and
            (v_qtde_audit + v_qtde_ag_audit + v_qtde_em_audit = 0)) then
        v_status := 0;
      else
        v_status := 3;
      end if;
    
      update saidapornf s
         set s.auditado = v_status
       where s.idnotafiscal = v_idnotafiscal
         and s.auditado <> v_status;
    end loop;
  end;

  procedure AlterarQtdeSeparacao
  (
    p_idromaneio   in number,
    p_idpalet      in number,
    p_idlocal      in local.idlocal%type,
    p_idproduto    in number,
    p_barra        in varchar2,
    p_qtdeseparada in number,
    p_idusuario    in number
  ) is
    type t_paletseparacao is record(
      idromaneio    number,
      idpalet       number,
      idlocal       local.idlocal%type,
      idproduto     number,
      barra         embalagem.barra%type,
      qtdetotalun   number,
      idarmazem     number,
      estado        lote.estado%type,
      idnotafiscal  number,
      iddepositante number,
      identrega     number,
      idusuario     number,
      datainicio    paletseparacao.dtinicio%type,
      separado      number);
  
    r_paletseparacao  t_paletseparacao;
    v_qtdedistestoque number;
    v_romaneio        romaneiopai%rowtype;
    v_totalprodutops  number;
    v_totalprodutonf  number;
    v_msg             t_message;
  
    procedure validarDadosParaTrocaQtde
    (
      r_paletseparacao in out t_paletseparacao,
      p_qtdeseparada   in number
    ) is
      v_fracionado       produto.fracionado%type;
      v_percentual       number;
      v_qtdepermitida    number;
      v_totalseparar     number;
      v_qtdetotalseparar number;
    begin
      select fracionado
        into v_fracionado
        from produto
       where idproduto = p_idproduto;
    
      if (v_fracionado = 'N')
         and (mod(p_qtdeseparada, 1) <> 0) then
        v_msg := t_message('O produto: {0}, qtde: {1}' ||
                           ', não permite quantidade fracionada. Operação cancelada.');
        v_msg.addParam(r_paletseparacao.idproduto);
        v_msg.addParam(p_qtdeseparada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_paletseparacao.separado > 0 then
        v_msg := t_message('O produto ja foi separado. Operacao Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select distinct nf.idnotafiscal, nf.iddepositante,
                      nvl(d.percentualaceiteqtde, 0) percentualaceiteqtde,
                      nf.ident_entrega
        into r_paletseparacao.idnotafiscal, r_paletseparacao.iddepositante,
             v_percentual, r_paletseparacao.identrega
        from romaneiopai rp, nfromaneio nfr, notafiscal nf, depositante d
       where rp.tipo = 0
         and rp.idromaneio = p_idromaneio
         and nfr.idromaneio = rp.idromaneio
         and nf.idnotafiscal = nfr.idnotafiscal
         and nf.sequencia like 'RET%'
         and nf.nfpedido = 'S'
         and d.identidade = nf.iddepositante;
    
      if v_percentual = 0 then
        v_msg := t_message('O percentual de aceite de quantidade nao foi definido para o depositante id: {0}');
        v_msg.addParam(r_paletseparacao.iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select sum(qtdeunit) total
        into v_totalseparar
        from paletseparacao
       where idromaneio = r_paletseparacao.idromaneio
         and idpalet = r_paletseparacao.idpalet
         and idproduto = r_paletseparacao.idproduto;
    
      v_qtdepermitida := (v_totalseparar / 100) * v_percentual;
      v_qtdepermitida := v_qtdepermitida + v_totalseparar;
    
      if p_qtdeseparada <= r_paletseparacao.qtdetotalun then
        v_msg := t_message('A quantidade separada deve ser maior que {0}');
        v_msg.addParam(r_paletseparacao.qtdetotalun);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select sum(qtdeunit) total
        into v_qtdetotalseparar
        from paletseparacao
       where idromaneio = r_paletseparacao.idromaneio
         and idpalet = r_paletseparacao.idpalet
         and idproduto = r_paletseparacao.idproduto
         and separado = 'S';
    
      v_qtdetotalseparar := v_qtdetotalseparar + p_qtdeseparada;
      if v_qtdetotalseparar > v_qtdepermitida then
        v_msg := t_message('A quantidade separada deve ser menor que a quantidade permitida de ' ||
                           '{0} para o produto.');
        v_msg.addParam(v_qtdepermitida);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure atualizarPaleteSeparacao
    (
      r_paletseparacao  in t_paletseparacao,
      p_qtdeseparada    in number,
      p_qtdedistestoque in out number
    ) is
      v_diferenca number;
    begin
      select p_qtdeseparada - sum(qtdeunit) total
        into v_diferenca
        from paletseparacao
       where idromaneio = r_paletseparacao.idromaneio
         and idpalet = r_paletseparacao.idpalet
         and idlocal = r_paletseparacao.idlocal
         and idproduto = r_paletseparacao.idproduto;
    
      p_qtdedistestoque := v_diferenca;
      for c_rmp in (select *
                      from paletseparacao
                     where idromaneio = r_paletseparacao.idromaneio
                       and idpalet = r_paletseparacao.idpalet
                       and idlocal <> r_paletseparacao.idlocal
                       and idproduto = r_paletseparacao.idproduto
                       and separado = 'N')
      loop
        if (v_diferenca >= c_rmp.qtdeunit) then
          v_diferenca := v_diferenca - c_rmp.qtdeunit;
        
          delete from paletseparacao
           where idromaneio = c_rmp.idromaneio
             and idpalet = c_rmp.idpalet
             and idlocal = c_rmp.idlocal
             and idproduto = c_rmp.idproduto
             and barra = c_rmp.barra;
        
          delete from paletseparacaocliente
           where barra = c_rmp.barra
             and idproduto = c_rmp.idproduto
             and identidade = r_paletseparacao.identrega
             and idlocal = c_rmp.idlocal
             and idarmazem = c_rmp.idarmazem
             and idpalet = c_rmp.idpalet
             and idromaneio = c_rmp.idromaneio;
        
          update produtopalet
             set qtde = qtde - c_rmp.qtdeunit
           where barra = c_rmp.barra
             and idproduto = c_rmp.idproduto
             and identidade = r_paletseparacao.identrega
             and iddepositante = r_paletseparacao.iddepositante
             and idpalet = c_rmp.idpalet
             and idromaneio = c_rmp.idromaneio;
        
          pk_utilities.GeraLog(p_idusuario,
                               'EXCLUIU PALETSEPARACAO DO PRODUTO ID: ' ||
                                c_rmp.idproduto || ' NO IDLOCAL: ' ||
                                c_rmp.idlocal || ' QTDESEPARACAO: ' ||
                                c_rmp.qtdeunit || ' LOTE ID: ' ||
                                c_rmp.Idlote || ' DO ROMANEIO ID: ' ||
                                p_idromaneio, p_idromaneio, 'RP');
        
        end if;
      end loop;
    
      if v_diferenca > 0 then
        update nfdet
           set qtde         = qtde + v_diferenca,
               qtdeatendida = qtdeatendida + v_diferenca,
               qtdefaturada = qtdefaturada + v_diferenca
         where nf = r_paletseparacao.idnotafiscal
           and idproduto = r_paletseparacao.idproduto;
      
        pk_notafiscal.p_gerar_nfimpressao(r_paletseparacao.idnotafiscal);
      end if;
    end atualizarPaleteSeparacao;
  
    procedure alterarPaleteSeparacao
    (
      r_paletseparacao in out t_paletseparacao,
      p_idlote         in number,
      p_qtdedistribuir in out number,
      p_disponivel     in out number
    ) is
      v_barramenorfator embalagem.barra%type;
      v_qtdeutilizada   number;
    begin
      if p_disponivel > p_qtdedistribuir then
        v_qtdeutilizada := p_qtdedistribuir;
      else
        v_qtdeutilizada := p_disponivel;
      end if;
      p_qtdedistribuir := p_qtdedistribuir - v_qtdeutilizada;
    
      pk_estoque.incluir_pendencia(r_paletseparacao.idarmazem,
                                   r_paletseparacao.idlocal, p_idlote,
                                   v_qtdeutilizada,
                                   r_paletseparacao.idusuario,
                                   'INCLUIDO PENDENCIA EM FUNCAO DA ALTERACAO DA QTDE DO PRODUTO ID: ' ||
                                    r_paletseparacao.idproduto ||
                                    ' DO ROMANEIO ID: ' ||
                                    r_paletseparacao.idromaneio);
    
      inserir_pallet_separacao(r_paletseparacao.idromaneio,
                               r_paletseparacao.idpalet,
                               r_paletseparacao.idarmazem,
                               r_paletseparacao.idlocal, p_idlote,
                               r_paletseparacao.idproduto,
                               r_paletseparacao.barra, v_qtdeutilizada,
                               v_qtdeutilizada);
    
      inserir_pallet_separacao_cli(r_paletseparacao.idromaneio,
                                   r_paletseparacao.idpalet,
                                   r_paletseparacao.idarmazem,
                                   r_paletseparacao.idlocal,
                                   r_paletseparacao.idproduto,
                                   r_paletseparacao.barra,
                                   r_paletseparacao.identrega,
                                   v_qtdeutilizada);
    
      v_barramenorfator := pk_produto.RetornarCodBarraMenorFator(r_paletseparacao.idproduto);
      inserir_produto_palet(r_paletseparacao.idromaneio,
                            r_paletseparacao.idpalet,
                            r_paletseparacao.iddepositante,
                            r_paletseparacao.identrega,
                            r_paletseparacao.idproduto, v_barramenorfator,
                            v_qtdeutilizada);
    end alterarPaleteSeparacao;
  
    procedure usarMesmoLote
    (
      r_paletseparacao  in out t_paletseparacao,
      p_qtdedistestoque in out number
    ) is
      v_disponivel number;
    begin
      for c_ps in (select *
                     from paletseparacao
                    where idromaneio = r_paletseparacao.idromaneio
                      and idpalet = r_paletseparacao.idpalet
                      and idlocal = r_paletseparacao.idlocal
                      and idproduto = r_paletseparacao.idproduto)
      loop
        select (ll.estoque - ll.pendencia + ll.adicionar)
          into v_disponivel
          from lotelocal ll
         where ll.idlote = c_ps.idlote
           and ll.idlocal = c_ps.idlocal
           and ll.idarmazem = c_ps.idarmazem;
      
        if v_disponivel > 0 then
          alterarPaleteSeparacao(r_paletseparacao, c_ps.idlote,
                                 p_qtdedistestoque, v_disponivel);
        
          exit when p_qtdedistestoque = 0;
        end if;
      end loop;
    end usarMesmoLote;
  
    procedure usarLoteDisponivel
    (
      r_paletseparacao  in out t_paletseparacao,
      p_qtdedistestoque in out number
    ) is
    begin
      if p_qtdedistestoque > 0 then
        for c_est in (select (ll.estoque - ll.pendencia + ll.adicionar) disp,
                             ll.idlote
                        from lotelocal ll, lote l
                       where l.idlote = ll.idlote
                         and l.liberado = 'S'
                         and nvl(l.tipolote, 'L') = 'L'
                         and l.estado = r_paletseparacao.estado
                         and l.iddepositante =
                             r_paletseparacao.iddepositante
                         and l.idproduto = r_paletseparacao.idproduto
                         and ll.idlocal = r_paletseparacao.idlocal
                         and ll.idarmazem = r_paletseparacao.idarmazem
                         and (ll.estoque - ll.pendencia + ll.adicionar) > 0
                       order by nvl(l.dtvenc, sysdate), l.dtentrada, l.idlote)
        loop
          alterarPaleteSeparacao(r_paletseparacao, c_est.idlote,
                                 p_qtdedistestoque, c_est.disp);
        end loop;
      end if;
    
      if p_qtdedistestoque > 0 then
        v_msg := t_message('Não existe estoque disponível para alterar a qtde do produto em separacao.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end usarLoteDisponivel;
  
    procedure atualizarDadosRomaneio(r_paletseparacao in t_paletseparacao) is
      v_romaneio romaneiopai%rowtype;
    begin
      v_romaneio := carregar_romaneio(r_paletseparacao.idromaneio);
      Atualizar_Produtos_Romaneio(v_romaneio, 'N');
    
      recalcularQtdePaletSeparacao(r_paletseparacao.idromaneio);
      identificarlotes(r_paletseparacao.idromaneio);
    end atualizarDadosRomaneio;
  
  begin
    r_paletseparacao.idusuario := p_idusuario;
  
    begin
      select p.idromaneio, p.idpalet, p.idlocal, p.idproduto, p.barra,
             p.idarmazem, l.estado, min(dtinicio) datainicio,
             sum(p.qtdeunit) qtdetotalun,
             sum(decode(p.separado, 'S', 1, 0)) separado
        into r_paletseparacao.idromaneio, r_paletseparacao.idpalet,
             r_paletseparacao.idlocal, r_paletseparacao.idproduto,
             r_paletseparacao.barra, r_paletseparacao.idarmazem,
             r_paletseparacao.estado, r_paletseparacao.datainicio,
             r_paletseparacao.qtdetotalun, r_paletseparacao.separado
        from paletseparacao p, lote l
       where l.idlote = p.idlote
         and p.idromaneio = p_idromaneio
         and p.idpalet = p_idpalet
         and p.idlocal = p_idlocal
         and p.idproduto = p_idproduto
         and p.barra = p_barra
       group by p.idromaneio, p.idpalet, p.idlocal, p.idproduto, p.barra,
                p.idarmazem, l.estado, p.ordem;
    exception
      when no_data_found then
        v_msg := t_message('Palet Separacao não encontrado.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    validarDadosParaTrocaQtde(r_paletseparacao, p_qtdeseparada);
  
    atualizarPaleteSeparacao(r_paletseparacao, p_qtdeseparada,
                             v_qtdedistestoque);
  
    usarMesmoLote(r_paletseparacao, v_qtdedistestoque);
  
    usarLoteDisponivel(r_paletseparacao, v_qtdedistestoque);
  
    atualizarDadosRomaneio(r_paletseparacao);
  
    ordenar_palet_separacao(r_paletseparacao.idromaneio);
  
    update paletseparacao
       set idusuario = r_paletseparacao.idusuario,
           dtinicio  = r_paletseparacao.datainicio,
           dtfim     = sysdate,
           separado  = 'S'
     where idromaneio = r_paletseparacao.idromaneio
       and idpalet = r_paletseparacao.idpalet
       and idlocal = r_paletseparacao.idlocal
       and idproduto = r_paletseparacao.idproduto
       and barra = r_paletseparacao.barra;
  
    select sum(qtdeunit)
      into v_totalprodutops
      from paletseparacao
     where idromaneio = r_paletseparacao.idromaneio
       and idpalet = r_paletseparacao.idpalet
       and idproduto = r_paletseparacao.idproduto;
  
    select sum(qtde)
      into v_totalprodutonf
      from nfdet
     where nf = r_paletseparacao.idnotafiscal
       and idproduto = r_paletseparacao.idproduto;
  
    if v_totalprodutops <> v_totalprodutonf then
      v_msg := t_message('Qtde a separar é diferente da qtde do produto na nota fiscal de retorno.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      insert into produtoalteradosep
        (id, idromaneio, idnotafiscal, idproduto, qtdeseparacao,
         qtdeseparada, idusuario, data)
      values
        (seq_produtoalteradosep.nextval, r_paletseparacao.idromaneio,
         r_paletseparacao.idnotafiscal, r_paletseparacao.idproduto,
         r_paletseparacao.qtdetotalun, p_qtdeseparada,
         r_paletseparacao.idusuario, sysdate);
    exception
      when dup_val_on_index then
        update produtoalteradosep
           set qtdeseparacao = qtdeseparacao + r_paletseparacao.qtdetotalun,
               qtdeseparada  = qtdeseparada + p_qtdeseparada
         where idromaneio = r_paletseparacao.idromaneio
           and idnotafiscal = r_paletseparacao.idnotafiscal
           and idproduto = r_paletseparacao.idproduto;
    end;
  
    pk_utilities.GeraLog(p_idusuario,
                         'ALTEROU A QTDE DO PRODUTO ID: ' || p_idproduto ||
                          ' NO IDLOCAL: ' || p_idlocal || ' QTDESEPARACAO: ' ||
                          r_paletseparacao.qtdetotalun || ' QTDESEPARADA: ' ||
                          p_qtdeseparada || ' DO ROMANEIO ID: ' ||
                          p_idromaneio, p_idromaneio, 'RP');
  
  end;

  procedure alterarTitulo
  (
    p_idromaneio in number,
    p_titulo     in varchar2,
    p_idusuario  in number
  ) is
    v_codigo romaneiopai.codigointerno%type;
    v_titulo romaneiopai.tituloromaneio%type;
    v_status number;
    v_tipo   number;
    v_msg    t_message;
  begin
    select codigointerno, tituloromaneio,
           decode(tipo, 0,
                   decode(processado, 'S', 3,
                           decode(gerado, 'N', 0, 'A', 0,
                                   decode(erro, 'S', 6, 1))), statusonda),
           tipo
      into v_codigo, v_titulo, v_status, v_tipo
      from romaneiopai
     where idromaneio = p_idromaneio;
  
    if v_status not in (0, 1, 2, 4) then
      if v_tipo = 0 then
        v_msg := t_message('O STATUS DO ROMANEIO NÃO PERMITE ALTERAÇÃO DO TÍTULO. OPERAÇÃO CANCELADA.' ||
                           chr(13) || 'IDROMANEIO: {0}' || chr(13) ||
                           'ROMANEIO: {1}');
        v_msg.addParam(p_idromaneio);
        v_msg.addParam(v_codigo);
        raise_application_error(-20000, v_msg.formatMessage);
      else
        v_msg := t_message('O STATUS DA ONDA NÃO PERMITE ALTERAÇÃO DO TÍTULO. OPERAÇÃO CANCELADA.' ||
                           chr(13) || 'IDONDA: {0}' || chr(13) ||
                           'ONDA: {1}');
        v_msg.addParam(p_idromaneio);
        v_msg.addParam(v_codigo);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    update romaneiopai
       set tituloromaneio = p_titulo
     where idromaneio = p_idromaneio;
  
    for c_result in (select ro.idregiao idregiaoorigem, ro.descr regiaoorigem,
                            lo.buffer bufferorigem,
                            rd.idregiao idregiaodestino,
                            rd.descr regiaodestino, ld.buffer bufferdestino,
                            initcap(decode(lo.buffer, 'S',
                                            'BUFFER DE' || ro.descr, ro.descr)) ||
                             ' para ' ||
                             initcap(decode(ld.buffer, 'S',
                                            'BUFFER DE' || rd.descr, rd.descr)) descricao,
                            rp.codigointerno
                       from movimentacao m, local lo, regiaoarmazenagem ro,
                            local ld, regiaoarmazenagem rd, romaneiopai rp
                      where m.idonda = p_idromaneio
                        and m.idonda = rp.idromaneio
                        and lo.id = m.idlocalorigem
                        and ro.idregiao = lo.idregiao
                        and ld.id = m.idlocaldestino
                        and rd.idregiao = ld.idregiao
                        and (ld.idregiao not in
                            (select idregiao
                                from regiaoarmazenagem
                               where tipo = decode(ro.tipo, 7, null, 3)) or
                            (lo.buffer = 'N' and ld.buffer = 'N' and
                            ro.tipo in (0, 1) and rd.tipo = 3))
                        and not (lo.buffer = 'S' and
                             lo.idregiao in
                             (select idregiao
                                    from regiaoarmazenagem
                                   where tipo = 2) and ld.buffer = 'N' and
                             ld.idregiao in
                             (select idregiao
                                    from regiaoarmazenagem
                                   where tipo = 2))
                        and not (lo.buffer = 'N' and m.status = 1 and
                             lo.idregiao in
                             (select idregiao
                                    from regiaoarmazenagem
                                   where tipo = 0) and ld.buffer = 'N' and
                             ld.idregiao in
                             (select idregiao
                                    from regiaoarmazenagem
                                   where tipo = 2))
                        and not exists
                      (select 1
                               from pickingpicktolightonda ptl,
                                    produtolocal pl
                              where pl.idprodutolocal = ptl.idprodutolocal
                                and pl.idarmazem = lo.idarmazem
                                and pl.idlocal = lo.idlocal)
                      group by ro.idregiao, ro.descr, lo.buffer, rd.idregiao,
                               rd.descr, ld.buffer, ro.tipo, rd.tipo, lo.tipo,
                               lo.picking, ld.tipo, ld.picking,
                               decode(ro.tipo, 6, 99, 1, 0, 0, 1, ro.tipo),
                               rp.codigointerno
                      order by decode(ro.tipo, 6, 99, 1, 0, 0, 1, ro.tipo),
                               min(m.id))
    
    loop
      pk_convocacao.alterarAtividadeSeparacaoOnda(c_result.codigointerno,
                                                  c_result.idregiaoorigem,
                                                  c_result.idregiaodestino,
                                                  c_result.bufferorigem,
                                                  c_result.bufferdestino,
                                                  p_titulo || ' - Onda ' ||
                                                   c_result.codigointerno ||
                                                   ' - ' ||
                                                   c_result.descricao);
    end loop;
  
    if v_tipo = 0 then
      pk_utilities.GeraLog(p_idusuario,
                           'O TÍTULO DO ROMANEIO ' || v_codigo ||
                            ' E IDROMANEIO ' || p_idromaneio ||
                            ' FOI ALTERADO. ANTES:' || v_titulo ||
                            ' DEPOIS: ' || p_titulo || '.', p_idromaneio,
                           'RP');
    else
      pk_utilities.GeraLog(p_idusuario,
                           'O TÍTULO DA ONDA ' || v_codigo || ' E IDONDA ' ||
                            p_idromaneio || ' FOI ALTERADO. ANTES:' ||
                            v_titulo || ' DEPOIS: ' || p_titulo || '.',
                           p_idromaneio, 'RP');
    end if;
  end;

  procedure registrarControleSeparacao
  (
    p_idRomaneio       in number,
    p_idPalet          in number,
    p_idPlanoSeparacao in number,
    p_idUsuario        in number,
    p_idRegiao         in number,
    p_idUsuarioLogado  in number
  ) is
    r_fichaseparacao fichaseparacao%rowtype;
    v_codRomaneio    romaneiopai.codigointerno%type;
    v_mensagem       varchar2(4000);
    v_msg            t_message;
  
    procedure carregarFichaSeparacao is
    begin
      select fs.*
        into r_fichaseparacao
        from fichaseparacao fs
       where fs.idromaneio = p_idRomaneio
         and fs.idpalet = p_idPalet
         and fs.idusuario = p_idUsuario
         and (fs.idregiao = p_idRegiao or p_idRegiao is null)
         for update;
    exception
      when no_data_found then
        select nvl(max(prioridade), 0) + 1
          into r_fichaseparacao.prioridade
          from fichaseparacao fs
         where fs.idplanosepacacao = p_idPlanoSeparacao;
      
        select seq_fichaseparacao.nextval
          into r_fichaseparacao.idfichaseparacao
          from dual;
      
        r_fichaseparacao.idusuario        := p_idUsuario;
        r_fichaseparacao.idplanosepacacao := p_idPlanoSeparacao;
        r_fichaseparacao.idusuariocanc    := null;
        r_fichaseparacao.datainicio       := null;
        r_fichaseparacao.datafim          := null;
        r_fichaseparacao.situacao         := 'A';
        r_fichaseparacao.idromaneio       := p_idRomaneio;
        r_fichaseparacao.idpalet          := p_idPalet;
        r_fichaseparacao.idregiao         := p_idRegiao;
      
        insert into fichaseparacao
          (idfichaseparacao, idusuario, idplanosepacacao, idusuariocanc,
           datainicio, datafim, situacao, prioridade, idromaneio, idpalet,
           idregiao)
        values
          (r_fichaseparacao.idfichaseparacao, r_fichaseparacao.idusuario,
           r_fichaseparacao.idplanosepacacao, r_fichaseparacao.idusuariocanc,
           r_fichaseparacao.datainicio, r_fichaseparacao.datafim,
           r_fichaseparacao.situacao, r_fichaseparacao.prioridade,
           r_fichaseparacao.idromaneio, r_fichaseparacao.idpalet,
           r_fichaseparacao.idregiao);
    end;
  
    function temSeparacaoIniciada return boolean is
      v_sepIniciada number;
    begin
      select count(*)
        into v_sepIniciada
        from dual
       where exists (select 1
                from paletseparacao ps
               where idromaneio = p_idRomaneio
                 and idpalet = p_idPalet
                 and dtinicio is not null
                 and (exists (select 1
                                from local lo
                               where lo.idarmazem = ps.idarmazem
                                 and lo.idlocal = ps.idlocal
                                 and lo.idregiao = p_idRegiao) or
                      p_idRegiao is null));
    
      return v_sepIniciada = 1;
    end;
  
    procedure vincularAtividadeConvAtiva is
      v_idAtividade number;
    begin
      select idatividade
        into v_idAtividade
        from atividade
       where idtipoatividade = 5
         and idoperacao = to_char(v_codRomaneio)
         and idpalet = p_idPalet
         and idregiaoorigem = p_idRegiao;
    
      pk_convocacao.vincularusuario(v_idAtividade, p_idUsuario,
                                    p_idUsuarioLogado, v_mensagem);
    
      if v_mensagem is not null then
        raise_application_error(-20000, v_mensagem);
      end if;
    exception
      when no_data_found then
        null;
    end;
  
    procedure marcarSepIniciada is
    begin
      -- Iniciando separação da ficha
      update fichaseparacao
         set datainicio = sysdate,
             situacao   = 'I'
       where idfichaseparacao = r_fichaseparacao.idfichaseparacao;
    
      -- Iniciando separação na paletseparacao                          
      update paletseparacao ps
         set ps.dtinicio  = sysdate,
             ps.idusuario = p_idUsuario
       where ps.idromaneio = p_idRomaneio
         and ps.idpalet = p_idPalet
         and (exists
              (select 1
                 from local
                where idarmazem = ps.idarmazem
                  and idlocal = ps.idlocal
                  and idregiao = p_idRegiao) or p_idRegiao is null);
    
      update ordemservico
         set situacao = 'S'
       where idromaneio = p_idRomaneio
         and tiposervico = 'D';
    end;
  
    procedure marcarSepFinalizada is
    begin
      update fichaseparacao
         set datafim  = sysdate,
             situacao = 'F'
       where idfichaseparacao = r_fichaseparacao.idfichaseparacao;
    
      -- Finalizando separação na paletseparacao                          
      update paletseparacao ps
         set dtfim    = sysdate,
             separado = 'S'
       where ps.idromaneio = p_idRomaneio
         and ps.idpalet = p_idPalet
         and (exists
              (select 1
                 from local
                where idarmazem = ps.idarmazem
                  and idlocal = ps.idlocal
                  and idregiao = p_idRegiao) or p_idRegiao is null);
    
      -- Marca o palete como separado
      update palet p
         set p.separado = 'S'
       where p.idromaneio = p_idRomaneio
         and p.idpalet = p_idPalet
         and not exists (select 1
                from paletseparacao ps
               where ps.idromaneio = p.idromaneio
                 and ps.idpalet = p.idpalet
                 and ps.separado = 'N');
    end;
  
    function isConferenciaRegiao return boolean is
      v_utilizaconferenciaregiao number;
    begin
      select utilizaconferenciaregiao
        into v_utilizaconferenciaregiao
        from configuracao
       where ativo = 'S';
    
      return(v_utilizaconferenciaregiao = 1);
    end;
  
    procedure verificaSepRomaneio is
    begin
      update romaneiopai rp
         set separado           = 'S',
             idusuarioseparacao = p_idUsuario,
             datafinalseparacao = sysdate
       where idromaneio = p_idRomaneio
         and not exists (select 1
                from palet p
               where p.separado = 'N'
                 and p.idromaneio = rp.idromaneio);
    end;
  begin
    -- Carregando ficha de separação existente ou criando nova ficha caso não exista
    carregarFichaSeparacao;
  
    -- Verifica situação da ficha para decidir se iniciará a separação ou finalizará a separação
    if r_fichaseparacao.situacao = 'A' then
      -- Inicia a separação
      -- Realizando lock na paletseparacao para evitar concorrencia
      update paletseparacao ps
         set ps.idarmazem = ps.idarmazem
       where ps.idromaneio = p_idRomaneio
         and ps.idpalet = p_idPalet
         and (exists
              (select 1
                 from local
                where idarmazem = ps.idarmazem
                  and idlocal = ps.idlocal
                  and idregiao = p_idRegiao) or p_idRegiao is null);
    
      -- Verifica se a separação do Romaneio / Palet / Região foi iniciada pelo coletor
      if temSeparacaoIniciada then
        v_msg := t_message('A separação do Romaneio já foi iniciada por uma funcionalidade ' ||
                           'diferênte de Ficha de Separação (F10). Operação Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Finalizando todas as fichas não fechadas do usuário
      finalizarseparacao(p_idUsuario, 'F', null);
    
      -- Se a Região está preenchida, vincular atividade de convocação ativa
      if p_idRegiao is not null then
        -- Carregando código interno
        select rp.codigointerno
          into v_codRomaneio
          from romaneiopai rp
         where rp.idromaneio = p_idRomaneio;
      
        -- Vincular atividade de convocação ativa ao usuário
        vincularAtividadeConvAtiva;
      end if;
    
      -- Iniciar Separação
      marcarSepIniciada;
    elsif r_fichaseparacao.situacao = 'I' then
      -- Finaliza a separação
      marcarSepFinalizada;
    
      if p_idRegiao is not null then
        pk_convocacao.finalizarAtiSepPorRegiao(5, v_codRomaneio, p_idPalet,
                                               p_idRegiao, p_idUsuario);
      
        if isConferenciaRegiao then
          pk_convocacao.insereConfSaidaPorRegiao(p_idUsuario, v_codRomaneio);
        end if;
      end if;
    
      -- Verifica se o Romaneio pode ser marcado como Separado e Atualiza
      verificaSepRomaneio;
    else
      v_msg := t_message('Situação "{0}' ||
                         '" não esperada para ficha de separação. Operação cancelada.');
      v_msg.addParam(r_fichaseparacao.situacao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  function resumoTipoEmbalagem(p_idromaneio in romaneiopai.idromaneio%type)
    return varchar2 is
    v_retorno varchar2(4000) := '';
  begin
    for reg in (select descrreduzido, sum(qtde) qt
                  from vr_separacaocomponenteskit b
                 where idromaneio = p_idromaneio
                 group by descrreduzido)
    loop
      if (v_retorno) is null then
        v_retorno := reg.descrreduzido || ': ' || reg.qt;
      else
        v_retorno := v_retorno || ', ' || reg.descrreduzido || ': ' ||
                     reg.qt;
      end if;
    end loop;
    return v_retorno;
  end;

  function valorPesoCubado(p_barra in volumeromaneio.codbarra%type)
    return number is
  
    v_peso_aux number;
  
    cursor c_peso_cubado is
      select vr.alturacaixa as altura, vr.larguracaixa as largura,
             vr.comprimentocaixa as comprimento
        from volumeromaneio vr
       where vr.codbarra = p_barra
         and vr.statusvolume = 0;
    --
    r_peso_cubado c_peso_cubado%rowtype;
  
  begin
  
    open c_peso_cubado;
    fetch c_peso_cubado
      into r_peso_cubado;
    close c_peso_cubado;
  
    v_peso_aux := nvl(r_peso_cubado.altura, 0) *
                  nvl(r_peso_cubado.largura, 0) *
                  nvl(r_peso_cubado.comprimento, 0);
  
    v_peso_aux := v_peso_aux * 300;
    -- onde:
    -- 300 é o fator de conversão de metros cúbicos para peso cubado em metros cúbicos 
  
    return(round(v_peso_aux, 2));
  
  end;

  function coletaPossuiVendorReturn(p_carga in number) return boolean is
    v_count number;
  begin
  
    select count(1)
      into v_count
      from notafiscalcarga nfc, notafiscal nf, ordemdevolucao od
     where nfc.idcarga = p_carga
       and nf.idnotafiscal = nfc.idnotafiscal
       and od.idnotafiscal = nf.idnotafiscal
       and od.status <> C_ORDEM_DEVOLUCAO_CANCELADA;
  
    return v_count > 0;
  end coletaPossuiVendorReturn;

end pk_romaneio;
/

