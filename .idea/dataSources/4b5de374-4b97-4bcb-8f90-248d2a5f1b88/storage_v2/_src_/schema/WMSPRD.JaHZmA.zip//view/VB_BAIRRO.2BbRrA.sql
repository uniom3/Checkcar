create view VB_BAIRRO as
select descr bairro, idcidade h$idcidade, idbairro h$idbairro
  from bairro
/

