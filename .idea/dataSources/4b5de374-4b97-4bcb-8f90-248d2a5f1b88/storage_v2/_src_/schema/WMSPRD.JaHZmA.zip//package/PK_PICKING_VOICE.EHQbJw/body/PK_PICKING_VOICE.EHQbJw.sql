create package body PK_PICKING_VOICE is

  C_TYPE_ENDERECO_ORIGEM  constant number := 0;
  C_TYPE_PRODUTO          constant number := 1;
  C_TYPE_ENDERECO_DESTINO constant number := 2;
  C_TYPE_FINALIZADO       constant number := 3;

  C_INICIO           constant number := 0;
  C_PRONTO           constant number := 1;
  C_VOLTAR           constant number := 2;
  C_REPETIR          constant number := 3;
  C_REINICIAR        constant number := 4;
  C_COMANDO_INVALIDO constant number := 5;

  C_SEPARA_POR_LOTE_INDUSTRIA constant number := 1;
  C_COLETA_LOTE_INDUSTRIA     constant varchar2(1) := 'S';

  procedure inserirNavegacao
  (
    p_idRequest      pickingvoicenavigation.requestid%type,
    p_typeControl    pickingvoicenavigation.typecontrol%type,
    p_message        pickingvoicenavigation.message%type,
    p_voice          pickingvoicenavigation.voice%type,
    p_verifyingDigit in varchar2,
    p_title          in varchar2
  ) is
    v_idNavegacao number;
  begin
    select nvl(max(idnavigation), 0) + 1
      into v_idNavegacao
      from pickingvoicenavigation pvn
     where pvn.requestid = p_idRequest;
  
    insert into pickingvoicenavigation
      (idnavigation, requestid, typeControl, message, voice, success,
       verifyingDigit, title)
    values
      (v_idNavegacao, p_idRequest, p_typeControl, p_message, p_voice, 0,
       p_verifyingDigit, p_title);
    null;
  end inserirNavegacao;

  procedure gerarSeparacao(p_requestID in out number) is
    v_idEnderecoDestino        local.id%type;
    v_title                    varchar2(400);
    v_digitoVerificadorDestino local.digitoverificador%type;
    v_tipoProcessoSeparacao    number;
    v_loteIndustria            lote.descr%type;
  
    procedure gerarNavegacaoProduto
    (
      p_produto        produto.descr%type,
      p_qtdeMsg        in varchar,
      p_typeControl    in number,
      p_verifyingDigit in varchar2,
      p_title          in varchar2,
      p_loteIndustria  lote.descr%type := null
    ) is
      v_unidade       varchar2(9) := ' unidade';
      v_msgAlterada   varchar2(100);
      v_loteIndustria lote.descr%type;
    begin
    
      begin
        v_msgAlterada := p_qtdeMsg;
      
        if (to_number(p_verifyingDigit) > 1) then
          v_unidade := ' unidades';
        end if;
      
        if (p_verifyingDigit = 1) then
          v_msgAlterada := 'Pegue a quantidade de uma unidade';
        end if;
      
        if (p_verifyingDigit = 2) then
          v_msgAlterada := 'Pegue a quantidade de duas unidades';
        end if;
      
      exception
        when value_error then
          null;
      end;
    
      if (p_loteIndustria is not null) then
        v_loteIndustria := ' do lote indústria ' || p_loteIndustria;
      end if;
    
      inserirNavegacao(p_requestID, p_typeControl,
                       p_qtdeMsg || ' do produto ' ||
                        trim(replace(upper(p_produto), 'PRODUTO', '')) ||
                        v_loteIndustria,
                       replace(v_msgAlterada, ' UN', v_unidade) ||
                        ' do produto ' ||
                        trim(replace(upper(p_produto), 'PRODUTO', '')) ||
                        v_loteIndustria, p_verifyingDigit, p_title);
    
    end;
  
    function existeSeparacoesPendentes return boolean is
      v_total number;
    begin
      begin
        select count(*), p.requestid
          into v_total, p_requestID
          from pickingvoicenavigation p
         where p.success = 0
         group by p.requestid;
      
        if v_total > 0 then
          return true;
        end if;
      exception
        when no_data_found then
          return false;
      end;
    
      return false;
    end;
  
    procedure coletarInformacoes is
    begin
      begin
        select tipoprocessoseparacao
          into v_tipoProcessoSeparacao
          from atividadepickingvoice a, romaneiopai r, configuracaoonda c
         where r.idromaneio = a.idatividade
           and c.idconfiguracaoonda = r.idconfiguracaoonda
           and rownum = 1;
      exception
        when no_data_found then
          raise_application_error(-20000,
                                  'Nenhuma atividade pendente de execução');
      end;
    end;
  
  begin
    if (existeSeparacoesPendentes) then
      return;
    end if;
  
    coletarInformacoes;
  
    -- Regioes de separação
    for c_separacoes in (select v.idregiaoorigem, v.idregiaodestino,
                                v.idromaneio, v.regiaoorigem, v.regiaodestino
                           from v_separacoes_pendentes v)
    loop
    
      v_title := c_separacoes.regiaoorigem || ' para ' ||
                 c_separacoes.regiaodestino;
    
      --Endereços de origem da região de separação
      for c_enderecos in (select lo.id idEnderecoOrigem, m.idlocalorigem,
                                 m.idatividade,
                                 lo.digitoverificador digitoVerificadorOrigem
                            from (select m.idlocalorigem, a.IDATIVIDADE
                                     from movimentacao m,
                                          atividadepickingvoice a
                                    where m.idonda = a.idatividade
                                    and m.status not in (2, 3)
                                    group by m.idlocalorigem, a.idatividade) m,
                                 local lo
                           where lo.idregiao = c_separacoes.idregiaoorigem
                             and lo.id = m.idlocalorigem)
      loop
      
        gerarNavegacaoEndereco(p_requestID, c_enderecos.idEnderecoOrigem,
                               C_TYPE_ENDERECO_ORIGEM,
                               c_enderecos.digitoVerificadorOrigem, v_title);
      
        for c_produtos in (select v.loteindustria, v.qtde, v.qtdeFormatada,
                                  v.descr produto, v.iddepositante,
                                  pd.coletaloteindust
                             from v_produtos_mapa_separacao v,
                                  produtodepositante pd
                            where v.idlocalorigem =
                                  c_enderecos.idlocalorigem
                              and pd.identidade = v.iddepositante
                              and pd.idproduto = v.idproduto)
        loop
        
          if (v_tipoProcessoSeparacao = C_SEPARA_POR_LOTE_INDUSTRIA) then
            if (c_produtos.coletaloteindust = C_COLETA_LOTE_INDUSTRIA) then
              v_loteIndustria := c_produtos.loteIndustria;
            end if;
          end if;
        
          gerarNavegacaoProduto(c_produtos.produto,
                                'Pegue a quantidade de ' ||
                                 c_produtos.Qtdeformatada, C_TYPE_PRODUTO,
                                c_produtos.qtde, v_title, v_loteIndustria);
          v_loteIndustria := null;
        end loop;
      end loop;
    
      -- Endereços de entrega (Destino) packing/doca
      select ld.id, ld.digitoverificador
        into v_idEnderecoDestino, v_digitoVerificadorDestino
        from local ld, movimentacao m, atividadepickingvoice a
       where m.idlocaldestino = ld.id
         and m.idonda = a.idatividade
         and c_separacoes.idregiaodestino = ld.idregiao
       group by ld.id, ld.digitoverificador;
    
      gerarNavegacaoEndereco(p_requestID, v_idEnderecoDestino,
                             C_TYPE_ENDERECO_DESTINO,
                             v_digitoVerificadorDestino, v_title);
    end loop;
  
  end;

  procedure gerarNavegacaoEndereco
  (
    p_idRequest      in number,
    p_idEndereco     in local.id%type,
    p_typeControl    in number,
    p_verifyingDigit in varchar2,
    p_title          in varchar2
  ) is
    v_rua              local.rua%type;
    v_predio           local.predio%type;
    v_tipoEndereco     number;
    v_idlocalformatado varchar2(100);
  
    C_PICKING           constant number := 0;
    C_PULMAO_BLOCADO    constant number := 1;
    C_PULMAO_PALETIZADO constant number := 2;
    C_DOCA              constant number := 4;
    C_PACKING           constant number := 8;
  
    procedure gerarNavegacao
    (
      p_mensagem in pickingvoicenavigation.message%type,
      p_voice    in pickingvoicenavigation.voice%type,
      p_digito   in pickingvoicenavigation.verifyingdigit%type := null
    ) is
    begin
      inserirNavegacao(p_idRequest, p_typeControl, p_mensagem, p_voice,
                       nvl(p_digito, p_verifyingDigit), p_title);
    end;
  begin
  
    select l.tipo, l.idlocalformatado, l.rua, l.predio
      into v_tipoEndereco, v_idlocalformatado, v_rua, v_predio
      from local l
     where l.id = p_idEndereco;
  
    if (v_tipoEndereco = C_PACKING) then
      gerarNavegacao('Entregue os produtos no packing ' ||
                     v_idlocalformatado,
                     'Entregue os produtos no packing ' ||
                      v_idlocalformatado);
    end if;
  
    if (v_tipoEndereco = C_DOCA) then
      gerarNavegacao('Entregue os produtos na doca ' || v_idlocalformatado,
                     'Entregue os produtos na doca ' || v_idlocalformatado);
    end if;
  
    if (v_tipoEndereco in
       (C_PICKING, C_PULMAO_BLOCADO, C_PULMAO_PALETIZADO)) then
    
      gerarNavegacao('Vá até a rua ' || v_rua, 'Vá até a rua ' || v_rua,
                     'PRONTO');
      gerarNavegacao('Vá até o prédio ' || v_predio,
                     'Vá até o prédio ' || v_predio);
    end if;
  end;

  procedure executar
  (
    p_idRequest      in number,
    p_idNavegacao    in number,
    p_typeControl    in out pickingvoicenavigation.typecontrol%type,
    p_message        in out pickingvoicenavigation.message%type,
    p_voice          in out pickingvoicenavigation.voice%type,
    p_title          in out varchar2,
    p_verifyingDigit in out varchar2
    
  ) is
    v_idNavegacao number;
    v_max         number;
    procedure selecionaProximaNavigation is
    begin
      begin
        if (p_typeControl = C_TYPE_FINALIZADO) then
          p_message := 'Atividade finalizada com sucesso';
          p_voice   := 'Atividade finalizada com sucesso';
          delete from atividadepickingvoice;
          delete from pickingvoicenavigation;
          return;
        end if;
      
        select pvn.idnavigation, pvn.typecontrol, pvn.message, pvn.voice,
               pvn.title, pvn.verifyingdigit
          into v_idNavegacao, p_typeControl, p_message, p_voice, p_title,
               p_verifyingDigit
          from (select pvn.idnavigation, pvn.typecontrol, pvn.message,
                        pvn.voice, pvn.verifyingdigit, pvn.title
                   from pickingvoicenavigation pvn
                  where pvn.requestid = p_idRequest
                    and pvn.success = 0
                  order by idnavigation asc) pvn
         where rownum = 1;
      exception
        when no_data_found then
          raise_application_Error(-20000,
                                  'Nenhuma atividade pendente para execução');
      end;
    end;
  
    procedure alteraStatusNavigation is
    begin
    
      if (p_idNavegacao = C_INICIO) then
        return;
      end if;
    
      if (p_idNavegacao = C_COMANDO_INVALIDO) then
        p_message := 'Comando inválido. Repita por favor';
        p_voice   := 'Comando inválido. Repita por favor';
        return;
      end if;
    
      if (p_idNavegacao = C_PRONTO) then
      
        select max(idnavigation)
          into v_max
          from pickingvoicenavigation
         where requestid = p_idRequest;
      
        if (v_max = v_idNavegacao) then
          p_typeControl := C_TYPE_FINALIZADO;
        end if;
      
        update pickingvoicenavigation
           set success = 1
         where idnavigation = v_idNavegacao
           and requestid = p_idRequest;
      end if;
    
      if (p_idNavegacao = C_VOLTAR) then
        update pickingvoicenavigation
           set success = 0
         where idnavigation = v_idNavegacao - 1
           and requestid = p_idRequest;
      end if;
    
      if (p_idNavegacao = C_REPETIR) then
        update pickingvoicenavigation
           set success = 0
         where idnavigation = v_idNavegacao
           and requestid = p_idRequest;
      end if;
    
      if (p_idNavegacao = C_REINICIAR) then
        update pickingvoicenavigation
           set success = 0
         where requestid = p_idRequest;
      end if;
    
      selecionaProximaNavigation;
    end;
  
  begin
  
    selecionaProximaNavigation;
  
    alteraStatusNavigation;
  
  end;

  procedure gravarLogErro
  (
    p_msgErro   in varchar2,
    p_requestID in number
  ) is
    v_usuarioPrototipo number := 1;
  begin
    pk_utilities.GeraLog(v_usuarioPrototipo, 'Log: ' || p_msgErro,
                         p_requestID, 'PV');
  
  end;

  function getListaLogsErro return sys_refcursor is
    c_lista_logs sys_refcursor;
  begin
    open c_lista_logs for
      select log
        from loguser
       where tipolog = 'PV'
         and rownum < 20;
    return c_lista_logs;
  end;
end;
/

