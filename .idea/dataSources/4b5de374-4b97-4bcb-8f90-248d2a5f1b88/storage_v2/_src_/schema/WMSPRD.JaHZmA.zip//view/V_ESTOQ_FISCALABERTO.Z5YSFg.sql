create view V_ESTOQ_FISCALABERTO as
select ll.idarmazem, l.iddepositante, l.idlote, p.idproduto, p.codigointerno modelnumber, p.descr produto,
       sum(ll.estoque) estoque,
       sum((nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
            (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0))) disponivel
  from lotelocal ll, lote l, produto p
 where p.idproduto = l.idproduto
   and nvl(l.tipolote, 'L') = 'L'
   and l.idlote = ll.idlote
   and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
       (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0
 group by ll.idarmazem, l.iddepositante, l.idlote, p.idproduto, p.codigointerno, p.descr


/

