create view VT_PRODUTORECUPERADODET as
select decode(pd.idlote, null, 0, 1) marcado, e.idlote, e.estoquedisponivel,
       nvl(pd.qtde, 0) qtderecuperada, e. estado, p.codigointerno codproduto,
       p.descr produto, d.razaosocial depositante, e.loteindustria,
       e.dtvencimento, e.idproduto,
       e.idprodutorecuperado h$idprodutorecuperado,
       dp.fracionarlote h$fracionarlote
  from (select pr.idprodutorecuperado, ll.idarmazem, ll.idlocal, ll.idlote,
                round(ll.estoque + ll.adicionar - ll.pendencia, 6) estoquedisponivel,
                decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'T',
                        'VENCIDO/TRUNCADO', 'OUTROS') estado,
                l.descr loteindustria, l.dtvenc dtvencimento, l.idproduto,
                l.iddepositante
           from produtorecuperado pr, lotelocal ll, local lo, lote l
          where lo.idarmazem = pr.idarmazemorigem
            and lo.idlocal = pr.idlocalorigem
            and lo.ativo = 'S'
            and ll.idarmazem = lo.idarmazem
            and ll.idlocal = lo.idlocal
            and ((ll.estoque - ll.pendencia > 0) or exists
                 (select 1
                    from produtorecuperadodet
                   where idprodutorecuperado = pr.idprodutorecuperado
                     and idlote = ll.idlote))
            and l.idlote = ll.idlote
            and l.iddepositante = pr.iddepositante
            and l.tipolote = 'L'
            and l.estado in ('D', 'T')) e, produto p, entidade d,
       produtorecuperadodet pd, depositante dp
 where p.idproduto = e.idproduto
   and d.identidade = e.iddepositante
   and pd.idprodutorecuperado(+) = e.idprodutorecuperado
   and pd.idlote(+) = e.idlote
   and d.identidade = dp.identidade
   and not exists
 (select 1
          from ordemservico os, origemlote los, notafiscal nf
         where os.idlotenf = nf.idlotenf
           and os.tiposervico in ('E', 'I', 'J')
           and los.idlote = e.idlote
           and nf.idnotafiscal = los.idnotafiscal)
   and not exists
 (select 1
          from ordemservico os, origemlote los, notafiscal nf
         where os.idlotenf = nf.idlotenf
           and os.tiposervico in ('E', 'I', 'J')
           and los.idlote = pk_lote.getIdLoteAnterior(e.idlote)
           and nf.idnotafiscal = los.idnotafiscal)
/

