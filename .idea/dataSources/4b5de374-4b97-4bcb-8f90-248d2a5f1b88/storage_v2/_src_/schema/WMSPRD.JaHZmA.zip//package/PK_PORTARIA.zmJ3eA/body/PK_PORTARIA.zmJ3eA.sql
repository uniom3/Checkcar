create package body pk_portaria is
  /****************************************************************
  procedimento que realiza o controle de portaria
  chamada: controle de portaria
  ****************************************************************/
  procedure controla_portaria(p_idportaria in portaria.idportaria%type) is
  
    v_msg t_message;
  
    cursor c_portaria(p_port in portaria.idportaria%type) is
      select placaveiculo, tipomovto, datahora, pernoite
        from portaria
       where idportaria = p_port;
  
    cursor c_carga
    (
      p_placa1 in veiculo.placa%type,
      p_movto1 in string,
      p_movto2 in string
    ) is
      select c.idcarga, nvl(c.liberado, 'N') liberado, situacao
        from carga c
       where c.placa = trim(p_placa1)
         and ((situacao = p_movto1) or (situacao = p_movto2))
       order by horaliberacao desc;
  
    r_portaria c_portaria%rowtype;
    r_carga    c_carga%rowtype;
    v_situacao char(1) := 'E';
  begin
    if c_portaria%isopen then
      close c_portaria;
    end if;
    open c_portaria(p_idportaria);
    fetch c_portaria
      into r_portaria;
  
    if c_portaria%found then
      if trim(r_portaria.tipomovto) = 'E' then
        --O CAMINHAO ESTA CHEGANDO
        if c_carga%isopen then
          close c_carga;
        end if;
        open c_carga(r_portaria.placaveiculo, 'S', 'S');
        fetch c_carga
          into r_carga;
      
        while c_carga%found
        loop
          --caminhao esta entrando mais a entrega ira continuar
          if r_portaria.pernoite = 'S' then
            v_situacao := 'P';
          else
            v_situacao := 'E';
          end if;
        
          update carga
             set horaretorno = r_portaria.datahora,
                 situacao    = v_situacao
           where idcarga = r_carga.idcarga;
        
          insert into cargaportaria
          values
            (r_carga.idcarga, p_idportaria);
        
          fetch c_carga
            into r_carga;
        end loop;
        close c_carga;
      else
        --CAMINHAO INDO OU CONTINUANDO UMA ENTREGA
        if c_carga%isopen then
          close c_carga;
        end if;
        open c_carga(r_portaria.placaveiculo, 'F', 'P');
        fetch c_carga
          into r_carga;
        while c_carga%found
        loop
          --CAMINHAO TENTANDO SAIR SEM A CARGA ESTAR LIBERADA
          if r_carga.liberado = 'S' THEN
            update carga
               set horasaida = decode(horasaida, null, r_portaria.datahora,
                                      horasaida),
                   situacao  = 'S'
             where idcarga = r_carga.idcarga;
            insert into cargaportaria
            values
              (r_carga.idcarga, p_idportaria);
          else
            v_msg := t_message('CARGA NAO LIBERADA PARA SAIR. DIRIJA-SE AO DEPTO DE LOGISTICA');
            raise_application_error(-20454, v_msg.formatMessage);
          end if;
          fetch c_carga
            into r_carga;
        end loop;
        close c_carga;
      end if;
      commit;
    else
      v_msg := t_message('REGISTRO DE PORTARIA NAO ENCONTRADO.');
      raise_application_error(-20548, v_msg.formatMessage);
    end if;
  end;
END;
/

