create view VR_LIVROREGISTROENTRADAPOREMIT as
select lv.idlivrofiscal, sysdate dataimpressao, initcap(e.razaosocial) firma,
       e.cgc cnpjfirma, e.inscrestadual inscrestadualfirma, lv.ultimapagina,
       lv.datainicio || ' a ' || lv.datatermino periodo, il.codigoemitente,
       il.razaosocial emitente, 
       decode(il.uf, 
              'ND', 
              (nvl((select cid.estadocidade 
                      from endereco ende, cidade cid 
                     where ende.idcidade = cid.idcidade 
                       and ende.identidade = e.identidade), 
                    'ND')), 
              il.uf) uf,
       il.cnpjemitente,
       il.inscrestadual inscrestadualemit, il.dtdocumento, il.dtentrada
  from livrofiscal lv, itemlivrofiscalentrada il, entidade e
 where il.idlivrofiscal = lv.idlivrofiscal
   and e.identidade = lv.identidade
/

