create view VI_INT_ENVIO_EFD_0220 as
select distinct '0220' reg, trim(nvl(e.descrreduzido, ' ')) unid_conv,
                e.fatorconversao fat_conv, nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento
  from notafiscal nf, nfdet nd, embalagem e, depositante dp, regime re,
       operacao o, nfremarmazenagem nr
 where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
       nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
   and nd.nf = nf.idnotafiscal
   and e.idproduto = nd.idproduto
   and e.barra = nd.barra
   and decode(nf.statusnf, 'P', 1, 0) = 1
   and decode(nf.retornoreentrega, 'N', 1, 0) = 1
   and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and decode(re.classificacao, 'A', 1, 0) = 1
   and o.idoperacao = nf.idoperacao
   and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
   and nr.idnfremessa(+) = nf.idnotafiscal
 group by '0220', trim(nvl(e.descrreduzido, ' ')), e.fatorconversao,
          nf.idarmazem, trunc(nvl(nr.datacobertura, nf.datacadastro))
/

