create view VT_LIVROFISCAL as
select le.idlivrofiscal, upper(extract(year from le.datainicio)) ano,
       upper(to_char(le.datainicio, 'month',
                      'nls_date_language=''BRAZILIAN PORTUGUESE''')) mes,
       le.numero, to_char(le.datainicio, 'DD/MM/YYYY') datainicio,
       to_char(le.datatermino, 'DD/MM/YYYY') datatermino, le.status,
       e.razaosocial, e.cgc cnpj, e.inscrestadual,
       decode(e.identidade, t.identidadeantiga, t.identidadenova,
               e.identidade) identidade, le.datacadastro,
       uc.nomeusuario usuariocadastro, le.dataalteracaocad,
       ue.nomeusuario usuarioalteracao, le.datacancelamento,
       ux.nomeusuario usuariocancelamento, le.status h$status,
       le.tipo h$tipo, m.descr motivoocorrencia,
       le.ultimapagina h$ultimapagina,
       upper(extract(month from le.datainicio)) h$nmes
  from livrofiscal le, entidade e, usuario uc, usuario ue, usuario ux,
       motivo m, v_trocacnpjarmazem t
 where e.identidade = le.identidade
   and uc.idusuario = le.idusuariocadastro
   and ue.idusuario(+) = le.idusuarioalteracaocad
   and ux.idusuario(+) = le.idusuariocancelamento
   and m.idmotivo(+) = le.idmotivo
   and t.identidadeantiga(+) = e.identidade
/

