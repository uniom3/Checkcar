create view VT_RESUMOCONFERENCIABKLIST as
select max(rownum) || vb.idlotenf || vb.loteindustria || vb.idproduto ||
        nvl(sum(vb.qtdbklist), 0) h$tableid, vb.idlotenf, vb.depositante,
       stragg(distinct vb.notafiscal) notafiscal,
       stragg(distinct vb.serie) serie, vb.codproduto, vb.produto,
       vb.loteindustria, sum(vb.qtdbklist) qtdesperada,
       nvl(vc.qtdeconferencia, 0) qtdeconferencia,
       case
          when sum(vb.qtdbklist) < nvl(vc.qtdeconferencia, 0) then
           nvl(vc.qtdeconferencia, 0) - sum(vb.qtdbklist)
          else
           0
        end qtdconfmais,
       case
          when sum(vb.qtdbklist) > nvl(vc.qtdeconferencia, 0) then
           sum(vb.qtdbklist) - nvl(vc.qtdeconferencia, 0)
          else
           0
        end qtdconfmenos, vb.tipobacklist, vb.idproduto,
       to_char(vb.datavencimento, 'dd/mm/YYYY') datavencimento
  from v_backlistresumo vb, v_confbacklistresumo vc
 where vc.idlotenf(+) = vb.idlotenf
   and vc.loteindustria(+) = vb.loteindustria
   and vc.idproduto(+) = vb.idproduto
 group by vb.idlotenf, vb.loteindustria, vb.idproduto, vb.depositante,
          vb.codproduto, vb.produto, vc.qtdeconferencia, vb.tipobacklist,
          to_char(vb.datavencimento, 'dd/mm/YYYY')
/

