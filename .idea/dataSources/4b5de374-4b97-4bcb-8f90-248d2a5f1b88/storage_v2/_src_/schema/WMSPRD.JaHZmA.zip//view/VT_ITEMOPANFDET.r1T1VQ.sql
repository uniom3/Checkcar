create view VT_ITEMOPANFDET as
select inf.rowid h$tableid, nf.codigointerno notafiscal, nf.sequencia serie,
       d.razaosocial depositante, e.razaosocial emitente, dest.razaosocial destinatario, ent.razaosocial entrega,
       nf.dataemissao, nf.estoqueverificado,
       p.codigointerno codproduto, p.descr produto, nfd.barra,  
       t.descr tipo, st.descr subtipo, f.razaosocial familia, inf.qtde,
       inf.datacriacao, inf.dataalteracao, uc.nomeusuario usuariocriacao,
       ua.nomeusuario usuarioalteracao, ioc.idordemcompra,
       inf.iditemordemcompra, p.idproduto, nfd.idnfdet, nf.idnotafiscal
  from itemopanfdet inf, nfdet nfd, notafiscal nf, produto p, usuario uc,
       usuario ua, itemordemcompra ioc, gtt_selecao g, 
       entidade d, entidade e, entidade dest, entidade ent, 
       tipoproduto t, subtipoproduto st, entidade f
 where ioc.iditemordemcompra = inf.iditemordemcompra
   and ua.idusuario(+) = inf.idusuarioalteracao
   and uc.idusuario = inf.idusuariocriacao
   and p.idproduto = nfd.idproduto
   and nf.idnotafiscal = nfd.nf
   and nfd.idnfdet = inf.idnfdet
   and ent.identidade = nf.ident_entrega
   and dest.identidade = nf.destinatario
   and e.identidade = nf.remetente
   and d.identidade = nf.iddepositante
   and t.idtipo = p.idtipo
   and st.idtipo = p.idtipo
   and st.idsubtipo = p.idsubtipo
   AND f.identidade = p.idfamilia
   and g.idselecionado = inf.iditemordemcompra
/

