create view V_GERENCIADORREMANEJAMENTO as
select r.idremanejamento, r.idarmazemorigem, r.idlocalorigem,
       llo.bloco blocoorigem, llo.rua ruaorigem, llo.predio predioorigem,
       llo.andar andarorigem, llo.apartamento apartamentoorigem,
       decode(mod(llo.predio, 2), 0, 'PAR', 'ÍMPAR') ladoorigem,
       ro.descr regiaoorigem, r.idarmazemdestino, r.idlocaldestino,
       lld.bloco blocodestino, lld.rua ruadestino, lld.predio prediodestino,
       lld.andar andardestino, lld.apartamento apartamentodestino,
       decode(mod(lld.predio, 2), 0, 'PAR', 'ÍMPAR') ladodestino,
       rd.descr regiaodestino, r.datahora, r.agendado, r.cadmanual,
       r.idatividade, r.idusuario, r.status, r.horainicio, r.horafim,
       r.idusuariotela,
       decode(llo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') tipolocalorigem,
       decode(lld.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') tipolocaldestino,
       llo.tipo tipoorigem, lld.tipo tipodestino, rp.idromaneio,
       rr.codigointerno romaneio, ao.descr armazemorigem,
       ad.descr armazemdestino, u.nomeusuario, ut.nomeusuario usuariotela,
       r.descrpalet, r.adicionado, r.camada, r.planejado, r.confirmarqtde,
       llo.picking,
       (lpad(trunc(((r.horafim - r.horainicio) * 24), 0), 2, 0) || ':' ||
        lpad(trunc((mod((mod(r.horafim - r.horainicio, 1) * 24), 1) * 60), 0),
              2, 0) || ':' ||
        lpad(round((mod((mod((mod(r.horafim - r.horainicio, 1) * 24), 1) * 60),
                         1) * 60), 0), 2, 0)) tempooperacao,
       r.idusuarioinicio, r.idusuariofim, ui.nomeusuario usuarioinicio,
       uf.nomeusuario usuariofim, r.tipo,
       decode(r.tipo, 0, 'PADRÃO', 1, 'MUDANÇA DE SETOR', '2',
               'MUDANÇA DE SETOR DE ENCOMENDA') tipodec,
       so.descr setororigem, sd.descr setordestino,
       pk_remanejamento.retornarTarefa(r.idremanejamento, lld.id) tarefa,
       ad.remanejamentocoletor
  from remanejamento r, local lld, local llo, romaneiopai rp, armazem ao,
       armazem ad, usuario u, usuario ut, usuario ui, usuario uf, setor so,
       setor sd, regiaoarmazenagem ro, regiaoarmazenagem rd,
       (select rr.idremanejamento,
                stragg(distinct rp.codigointerno) codigointerno
           from remanejamentoromaneio rr, romaneiopai rp
          where rp.idromaneio = rr.idromaneio
          group by rr.idremanejamento) rr
 where lld.idarmazem = r.idarmazemdestino
   and lld.idlocal = r.idlocaldestino
   and llo.idarmazem = r.idarmazemorigem
   and llo.idlocal = r.idlocalorigem
   and rp.idromaneio(+) = r.idromaneio
   and ao.idarmazem = r.idarmazemorigem
   and ad.idarmazem = r.idarmazemdestino
   and u.idusuario(+) = r.idusuario
   and ut.idusuario(+) = r.idusuariotela
   and ui.idusuario(+) = r.idusuarioinicio
   and uf.idusuario(+) = r.idusuariofim
   and so.idsetor(+) = llo.idsetor
   and sd.idsetor(+) = lld.idsetor
   and ro.idregiao(+) = llo.idregiao
   and rd.idregiao(+) = lld.idregiao
   and rr.idremanejamento(+) = r.idremanejamento
/

