create view V_CONSUMOCAIXAVOLUME as
select idarmazem, armazem, idtipocaixavolume, caixa, tipo, anomes,
       sum(quantidade) quantidade, sum(valortotal) valortotal,
       avg(valormedio) valormedio
  from v_consumocaixavolumedet
 group by idarmazem, armazem, idtipocaixavolume, caixa, tipo, anomes
/

