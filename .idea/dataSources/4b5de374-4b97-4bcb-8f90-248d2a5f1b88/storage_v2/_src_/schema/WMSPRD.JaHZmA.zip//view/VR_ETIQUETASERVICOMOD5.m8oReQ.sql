create view VR_ETIQUETASERVICOMOD5 as
select l.idlocal, substr(p.descr, 1, 50) produto, p.codigointerno codproduto,
       0 h$tipo, l.idlocalformatado
  from gtt_selecao g, local l, produtolocal lp, produto p
 where l.id = g.idselecionado
   and lp.idarmazem(+) = l.idarmazem
   and lp.idlocal(+) = l.idlocal
   and p.idproduto(+) = lp.idproduto
union
select l.idlocal, '' produto, '' codproduto, 1 h$tipo, l.idlocalformatado
  from gtt_selecao g, local l
 where l.id = g.idselecionado
 order by idlocal, produto

/

