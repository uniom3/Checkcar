create view V_ENTRADAS as
select trunc(l.data) data, count(distinct l.idlotenf) qtdeor,
       tr.descr tiporecebimento,
       decode(tr.classificacao, 'C', 'ENTRADA POR COMPRA', 'D',
               'DEVOLUÇÃO PARCIAL', 'T', 'DEVOLUÇÃO TOTAL', 'R',
               'ENTRADA POR REENTREGA', 'A',
               'ENTRADA POR CROSS DOCKING DIRETO', 'X',
               'ENTRADA POR CROSS DOCKING COM PICKING DINÂMICO', 'M',
               'ENTRADA POR CROSS DOCKING ALOCAÇÃO MANUAL', 'I',
               'ENTRADA POR OPERACOES INTERNAS', 'Z',
               'CROSS DOCKING ALOCAÇÃO ENDEREÇOS BLOCADOS', 'E', 'ENCOMENDA') classificacao,
       count(distinct c.idproduto) qtdeprodutos,
       sum(c.qtde * e.fatorconversao) qtdetotalprodutos,
       round(sum((c.qtde * e.pesobruto) / 1000), 3) peso,
       round(sum(((e.altura * e.largura * e.comprimento) * c.qtde) /
                  1000000000), 3) volume,
       pk_utilities.formatarTempo(avg(l.datageracaolote - l.data)*24*60*60) mediarecebimento
  from lotenf l, tiporecebimento tr, conferenciaentradadet c, embalagem e,
       (select cd.idlotenf, cd.idproduto, cd.estado,
                max(cd.idconferenciaentrada) idconferenciaentrada
           from conferenciaentradadet cd
          where cd.status = 'S'
            and nvl(cd.ignorada, 'N') = 'N'
          group by cd.idlotenf, cd.idproduto, cd.estado) mc
 where e.barra = c.barra
   and e.idproduto = c.idproduto
   and c.idlotenf = mc.idlotenf
   and c.idconferenciaentrada = mc.idconferenciaentrada
   and c.idproduto = mc.idproduto
   and c.estado = mc.estado
   and nvl(c.ignorada, 'N') = 'N'
   and c.idlotenf(+) = l.idlotenf
   and tr.idtiporecebimento = l.idtiporecebimento
 group by trunc(l.data), tr.descr,
          decode(tr.classificacao, 'C', 'ENTRADA POR COMPRA', 'D',
                  'DEVOLUÇÃO PARCIAL', 'T', 'DEVOLUÇÃO TOTAL', 'R',
                  'ENTRADA POR REENTREGA', 'A',
                  'ENTRADA POR CROSS DOCKING DIRETO', 'X',
                  'ENTRADA POR CROSS DOCKING COM PICKING DINÂMICO', 'M',
                  'ENTRADA POR CROSS DOCKING ALOCAÇÃO MANUAL', 'I',
                  'ENTRADA POR OPERACOES INTERNAS', 'Z',
                  'CROSS DOCKING ALOCAÇÃO ENDEREÇOS BLOCADOS', 'E',
                  'ENCOMENDA')
/

