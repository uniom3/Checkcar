create package PK_TIPOPEDIDO is

  C_OPERACAO_PACKING   constant number := 0;
  C_OPERACAO_COLMEIA   constant number := 1;

  procedure validarAlteraRemoveTipoPedido
  (
    p_idClassTipoPedido  in number,
    p_idusuario          in number,
    p_naoPermitirAlterar in boolean := false
  );

  procedure addSetorTipoPedido
  (
    p_idClassTipoPedido in number,
    p_idSetor           in number,
    p_prioridade        in number
  );

  procedure removeSetorTipoPedido
  (
    p_idClassTipoPedido in number,
    p_idSetor           in number,
    p_idusuario         in number
  );

  procedure aumentarPrioriSetorTipoPedido(p_idTipoPedidoSetorPrior in number);

  procedure diminuirPrioriSetorTipoPedido(p_idTipoPedidoSetorPrior in number);

  procedure validarTransTitulo
  (
    p_idClassTipoPedido  in number,
    p_transfTitularidade in number
  );

  function finalizarPontoAlerta
  (
    p_usuario      in varchar2,
    p_senha        in varchar2,
    p_idTipoPedido in number,
    p_operacao     in number,
    p_filtro1      in number default null,
    p_filtro2      in number default null,
    p_filtro3      in number default null
  ) return varchar2;

  function pontoAlertaLiberado
  (
    p_operacao in number,
    p_filtro1  in number default null,
    p_filtro2  in number default null,
    p_filtro3  in number default null
  ) return number;

end;
/

