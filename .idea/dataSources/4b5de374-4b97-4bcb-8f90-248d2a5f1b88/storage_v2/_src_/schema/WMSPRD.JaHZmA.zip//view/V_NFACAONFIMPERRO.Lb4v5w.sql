create view V_NFACAONFIMPERRO as
select nf.idprenf, li.descr
  from notafiscal nf, depositante d,
       (select li.agrupador, li.descr, li.tipo,
                (select max(li2.idprenf)
                    from logintegracao li2
                   where 1 = 1
                     and li2.agrupador = li.agrupador) idprenf
           from logintegracao li
          where 1 = 1
            and li.tipo = 'E'
            and li.agrupador is not null
            and li.data >= (sysdate - 60 / 24 / 60)
            and ((upper(li.descr) like
                '%N_O SER_O LIDOS MAIS DADOS DO SOQUETE%') or
                (upper(li.descr) like '%NO MORE DATA TO READ FROM SOCKET%') or
                upper(li.descr) like ('%ORA-01722%'))) li
 where 1 = 1
   and d.identidade = nf.iddepositante
   and li.idprenf = nf.idprenf
   and nf.statusnf <> 'X'
   and nf.tipo = 'S'
   and d.acaonfimperro in (1, 2)
 group by nf.idprenf, li.descr
/

