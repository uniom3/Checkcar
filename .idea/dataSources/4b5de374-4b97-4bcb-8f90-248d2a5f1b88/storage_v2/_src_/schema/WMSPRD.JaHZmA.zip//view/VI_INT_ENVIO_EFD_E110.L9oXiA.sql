create view VI_INT_ENVIO_EFD_E110 as
select 'E110' reg, 0 vl_tot_debitos, 0 vl_aj_debitos, 0 vl_tot_aj_debitos,
       0 vl_estornos_cred, 0 vl_tot_creditos, 0 vl_aj_creditos,
       0 vl_tot_aj_creditos, 0 vl_estornos_deb, 0 vl_sld_credor_ant,
       0 vl_sld_apurado, 0 vl_tot_ded, 0 vl_icms_recolher,
       0 vl_sld_credor_transportar, 0 deb_esp
  from dual
/

