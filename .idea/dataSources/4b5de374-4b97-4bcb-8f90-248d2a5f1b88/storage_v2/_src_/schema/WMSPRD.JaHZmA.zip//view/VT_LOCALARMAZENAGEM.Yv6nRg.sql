create view VT_LOCALARMAZENAGEM as
select l.idlocal, l.bloco, l.rua, l.predio, l.andar, l.apartamento,
       decode(mod(l.predio, 2), 0, 'PAR', 'ÍMPAR') lado,
       decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDIÇÃO', 7, 'STAGE', 8, 'PACKING', 11, 'MISTURA', 12,
               'CLASSIFICAÇÃO', 13, 'RECLASSIFICAÇÂO', 14, 'MONTAGEM DE KIT',
               16, 'ESTOJAMENTO', 18, 'ETIQUETAGEM', 20,
               'MONTAGEM DE KIT COM RASTREABILIDADE') tipo, l.buffer,
       l.estanteria, l.ativo, s.descr setor, r.descr regiao,
       t.descricao descricaoestrutura, t.tipo tipoestrutura, l.altura,
       l.largura, l.comprimento, l.alturamanobra, l.pesomaximo,
       nvl(ll.estoque, 0) estoque, nvl(pl.qtdepicking, 0) qtdepicking,
       e.razaosocial familia, l.motivobloqueio, l.idsetor, l.id,
       l.tipo h$tipo, l.picking h$picking, l.idarmazem h$idarmazem,
       a.descr h$armazem, l.ordem h$ordem, l.idlocalformatado f$idlocal,
       l.idtipoestrutura h$idtipoestrutura, l.digitoverificador,
       e.id idestacaoseparacao, e.descricao estacaoseparacao
  from local l, setor s, entidade e, regiaoarmazenagem r,
       (select idarmazem, idlocal, count(idproduto) qtdepicking
           from produtolocal
          group by idarmazem, idlocal) pl,
       (select idarmazem, idlocal, 1 estoque
           from lotelocal
          where estoque > 0
          group by idarmazem, idlocal) ll, armazem a,
       tipoestruturaarmazenagem t, estacaolocal el, estacao e
 WHERE s.idsetor(+) = l.idsetor
   and e.identidade(+) = l.idfamilia
   and r.idregiao(+) = l.idregiao
   and pl.idarmazem(+) = l.idarmazem
   and pl.idlocal(+) = l.idlocal
   and ll.idarmazem(+) = l.idarmazem
   and ll.idlocal(+) = l.idlocal
   and (l.tipo < 3 or l.tipo in (11, 12, 13, 14, 16, 18, 20))
   and l.buffer = 'N'
   and a.idarmazem = l.idarmazem
   and t.id(+) = l.idtipoestrutura
   and el.idendereco(+) = l.id
   and e.id(+) = el.idestacao
/

