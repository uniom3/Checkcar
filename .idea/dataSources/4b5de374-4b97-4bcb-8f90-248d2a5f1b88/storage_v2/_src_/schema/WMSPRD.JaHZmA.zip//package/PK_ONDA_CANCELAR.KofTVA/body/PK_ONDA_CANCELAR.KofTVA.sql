create package body PK_ONDA_CANCELAR is

  -- Remove o ponto de alerta quando cancela uma notafiscal de onda 
  procedure removerPontoAlerta(v_idpontoalerta in number) is
  begin
    if (v_idpontoalerta is not null) then
      update pontoalerta p
         set p.idusuariolib      = null,
             p.dataliberacao     = null,
             p.idusuariomont     = null,
             p.dataliberacaomont = null
       where p.idpontoalerta = v_idpontoalerta;
    end if;
  end removerPontoAlerta;

  procedure cancelarPedido
  (
    p_idprenf   in number,
    p_idusuario in number
  ) is
    v_erro varchar2(1000);
    v_msg  t_message;
  begin
    pk_notafiscal.CancelaNF(p_idprenf, p_idusuario,
                            'CANCELAMENTO DE SEPARAÇÃO', 'N', 'N', v_erro);
  
    if v_erro is not null then
      v_msg := t_message(v_erro);
      raise_application_error(-20555, v_msg.formatMessage);
    end if;
  end cancelarPedido;

  -- Refactored procedure expCancelSubPedido 
  procedure expCancelSubPedido(r_notafiscal in notafiscal%rowtype) is
  begin
    if r_notafiscal.enviadofaturamento = 'S' then
      pk_integracao.ExportarCancelamento(r_notafiscal.idprenf);
    end if;
  end expCancelSubPedido;

  procedure zerarQtdeAtendSubPedido(r_notafiscal in notafiscal%rowtype) is
  begin
    if (r_notafiscal.enviadofaturamento = 'N') then
      update nfdet
         set qtdeatendida = 0
       where nf = r_notafiscal.idnotafiscal;
    
      update nfdetimpressao
         set qtdeatendida = 0
       where idprenf = r_notafiscal.idprenf;
    end if;
  end zerarQtdeAtendSubPedido;

  procedure expFatSubPedido
  (
    p_idonda     in number,
    r_notafiscal in notafiscal%rowtype
  ) is
    v_enviado char(1);
    v_nf      pk_integracao.t_infonotafiscal;
  begin
    for c_subpedido in (select nf.idnotafiscal, s.separado, s.pesado
                          from notafiscal nf, saidapornf s
                         where nf.idpedidopai = r_notafiscal.idpedidopai
                           and nf.enviadofaturamento = 'N'
                           and s.idnotafiscal = nf.idnotafiscal)
    loop
      v_nf.idnotafiscal := c_subpedido.idnotafiscal;
      v_nf.separado     := c_subpedido.separado;
      v_nf.pesado       := c_subpedido.pesado;
      pk_integracao.expFaturamentoPedido(c_subpedido.idnotafiscal, p_idonda,
                                         v_nf);
    end loop;
  
    select nf.enviadofaturamento
      into v_enviado
      from notafiscal nf
     where nf.idnotafiscal = r_notafiscal.idpedidopai;
  
    if (v_enviado = 'N') then
      v_nf.idnotafiscal := r_notafiscal.idpedidopai;
      v_nf.pesado       := 1;
      v_nf.separado     := 1;
    
      pk_integracao.expFaturamentoPedido(r_notafiscal.idpedidopai, p_idonda,
                                         v_nf);
    end if;
  end expFatSubPedido;

  procedure excluirSubPedidos(r_notafiscal in notafiscal%rowtype) is
  begin
    delete from nfimpressao nfi
     where exists (select 1
              from notafiscal nf
             where nf.idpedidopai = r_notafiscal.idpedidopai
               and nf.idprenf = nfi.idprenf);
  
    update notafiscal nf
       set nf.statusroteirizacao = 0,
           nf.statusnf           = decode(nf.digitada, 'S', 'N', 'I')
     where nf.idnotafiscal = r_notafiscal.idpedidopai
       and nf.statusroteirizacao <> 0;
  
    delete from separacaoespecifica s
     where s.idnotafiscal = r_notafiscal.idpedidopai
       and s.cadmanual = 'N';
  end excluirSubPedidos;

  procedure regraSubPedido
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    r_notafiscal            notafiscal%rowtype;
    v_statusonda            number;
    v_possuiSubPedPendente  number;
    v_possuiSubPedFaturado  number;
    v_idprenfpedpai         number;
    v_possuiSubPedidoNaOnda number;
  begin
    begin
      select *
        into r_notafiscal
        from notafiscal nf
       where nf.idnotafiscal = p_idnotafiscal;
    exception
      when no_data_found then
        return;
    end;
  
    if (r_notafiscal.idpedidopai is null) then
      return;
    end if;
  
    select rp.statusonda
      into v_statusonda
      from romaneiopai rp
     where rp.idromaneio = p_idonda;
  
    if (v_statusonda = 0) then
      return;
    end if;
  
    cancelarPedido(r_notafiscal.idprenf, p_idusuario);
    expCancelSubPedido(r_notafiscal);
    zerarQtdeAtendSubPedido(r_notafiscal);
  
    select count(*)
      into v_possuiSubPedPendente
      from notafiscal nf
     where nf.idpedidopai = r_notafiscal.idpedidopai
       and nf.enviadofaturamento = 'N'
       and exists
     (select 1
              from nfromaneio nfr
             where nfr.idromaneio = p_idonda
               and nfr.idnotafiscal = nf.idnotafiscal
               and nfr.idnotafiscal <> r_notafiscal.idnotafiscal);
  
    if (v_possuiSubPedPendente > 0) then
      return;
    end if;
  
    select count(*)
      into v_possuiSubPedFaturado
      from notafiscal nf
     where nf.idpedidopai = r_notafiscal.idpedidopai
       and nf.enviadofaturamento = 'S';
  
    if (v_possuiSubPedFaturado > 0) then
      expFatSubPedido(p_idonda, r_notafiscal);
    
      select count(*)
        into v_possuiSubPedidoNaOnda
        from nfromaneio nfr
       where nfr.idromaneio = p_idonda
         and exists
       (select 1
                from notafiscal nf
               where nf.idnotafiscal = nfr.idnotafiscal
                 and nf.idpedidopai = r_notafiscal.idpedidopai);
    
      if (v_possuiSubPedidoNaOnda > 0) then
        return;
      end if;
    
      select nf.idprenf
        into v_idprenfpedpai
        from notafiscal nf
       where nf.idnotafiscal = r_notafiscal.idpedidopai;
    
      cancelarPedido(v_idprenfpedpai, p_idusuario);
    else
      excluirSubPedidos(r_notafiscal);
    end if;
  end;

  -- Retirar a nota fiscal caso ela esteja vinculada a uma carga 
  procedure retirarNfDaCaleta(p_idnotafiscal in number) is
    r_carga carga%rowtype;
    v_msg   t_message;
  
    function isColetaVazia return boolean is
      v_nfs number;
    begin
      select count(*)
        into v_nfs
        from notafiscalcarga nfc
       where nfc.idcarga = r_carga.idcarga;
    
      return v_nfs = 0;
    end isColetaVazia;
  
  begin
    begin
      select ca.idcarga, ca.embarqueliberado, ca.finalizado
        into r_carga.idcarga, r_carga.embarqueliberado, r_carga.finalizado
        from carga ca
       where ca.idcarga in (select max(nfc.idcarga)
                              from notafiscalcarga nfc, carga c
                             where nfc.idnotafiscal = p_idnotafiscal
                               and c.idcarga = nfc.idcarga);
    
      if (r_carga.embarqueliberado = 'N' and r_carga.finalizado = 'N') then
        delete from notafiscalcarga nfc
         where nfc.idcarga = r_carga.idcarga
           and nfc.idnotafiscal = p_idnotafiscal;
      
        if (isColetaVazia) then
        
          update carga
             set idagenda = null
           where idcarga = r_carga.idcarga;
        
          delete from agendatransporte a
           where a.numerocoleta = '' || r_carga.idcarga;
        
          delete from contatotransportadora
           where idcarga = r_carga.idcarga;
        
          delete from cargaromaneio cr
           where cr.idcarga = r_carga.idcarga;
        
          delete from carga
           where idcarga = r_carga.idcarga;
        end if;
      else
        v_msg := t_message('Nota fiscal com id: {0} vinculada a carga id: {1}' ||
                           ' não pode ser retirada devido a carga ja ter embarque liberado.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(r_carga.idcarga);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    exception
      when no_data_found then
        r_carga.idcarga := null;
    end;
  end retirarNfDaCaleta;

  -- Refactored procedure retornoEstoqueParaPicking 
  procedure retornoEstoqueParaPicking
  (
    p_idonda                 in number,
    p_idnotafiscal           in number,
    p_iddepositante          in number,
    p_idproduto              in number,
    p_idlote                 in number,
    p_idarmazem              in number,
    p_idlocal                in local.idlocal%type,
    p_idlocalretornarestoque in out local.idlocal%type
  ) is
    C_TIPO_PICKING_MISTO    constant number := 0;
    C_TIPO_PICKING_UNIDADES constant number := 1;
  
    v_usapicking         depositante.usapicking%type;
    v_idencomenda        number;
    v_localatual         local%rowtype;
    v_enderecoCompativel boolean := false;
    r_loteUnico          pk_lote.t_loteunico;
    v_msgErro            varchar2(1000);
    v_idlocalpulmao      local.idlocal%type;
    v_tipoPickingProdDep produtodepositante.tipopicking%type;
  begin
    select *
      into v_localatual
      from local l
     where l.idlocal = p_idlocal
       and l.idarmazem = p_idarmazem;
  
    if (v_localatual.picking = 'S' and v_localatual.buffer = 'N') then
      p_idlocalretornarestoque := v_localatual.idlocal;
      return;
    end if;
  
    -- verifica se o estoque é de encomenda
    begin
      select lt.idencomenda
        into v_idencomenda
        from lote lt
       where lt.idlote = p_idlote;
    exception
      when no_data_found then
        v_idencomenda := 0;
    end;
  
    if (v_idencomenda > 0) then
      select distinct lo.idlocal
        into p_idlocalretornarestoque
        from movimentacao m, local lo
       where m.idonda = p_idonda
         and m.status in (0, 1, 2)
         and m.idlote = p_idlote
         and m.etapa = 1
         and m.idlocalorigem = lo.id;
    else
      select d.usapicking
        into v_usapicking
        from lote l, depositante d
       where l.idlote = p_idlote
         and d.identidade = l.iddepositante;
    
      select lt.descr, lt.dtvenc, lt.estado, pd.loteuniconoendereco,
             lt.idproduto, lt.iddepositante
        into r_loteUnico.loteindustria, r_loteUnico.dtvencimento,
             r_loteUnico.estado, r_loteUnico.loteuniconoendereco,
             r_loteUnico.idProduto, r_loteUnico.iddepositante
        from lote lt, produtodepositante pd
       where lt.idlote = p_idlote
         and pd.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante;
    
      begin
        --encontra qual o tipo de picking (que pode ser 0 - misto, 1 - unidades ou 2 - caixa) que deve retornar 
        --baseado de qual picking foi retirado o lote a ser devolvido de acordo com o local que se encontra o lote
        --buscando nas movimentações que a nota fiscal participou na onda
        select distinct s.tipopermitirpickingsetor
          into v_tipoPickingProdDep
          from grupomovimentacao gm, movimentacao m, local ld, setor s
         where gm.idgrupo in (select m.id
                                from movimentacao m, local lo
                               where m.idonda = p_idonda
                                 and m.idnotafiscal = p_idnotafiscal
                                 and m.status <> 3
                                 and lo.id = m.idlocaldestino
                                 and lo.idarmazem = p_idarmazem
                                 and lo.idlocal = p_idlocal)
           and m.id = gm.idmovimentacao
           and m.status <> 3
           and m.idlote = p_idlote
           and ld.id = m.idlocalorigem
           and ld.tipo = 0
           and (ld.buffer = 'N' or
               (ld.bufferesteira = 1 and ld.buffer = 'S'))
           and s.idsetor = ld.idsetor;
      exception
        when no_data_found then
          v_tipoPickingProdDep := 0;
      end;
    
      if (v_usapicking = 'S' and r_loteUnico.estado = 'N') then
      
        for c_endPicking in (select pl.idarmazem, pl.idlocal,
                                    s.tipopermitirpickingsetor
                               from produtolocal pl, local l, setor s
                              where pl.identidade = p_iddepositante
                                and pl.idproduto = p_idproduto
                                and pl.idarmazem = p_idarmazem
                                and l.idlocal = pl.idlocal
                                and l.idarmazem = pl.idarmazem
                                and l.ativo = 'S'
                                and l.tipo = 0
                                and s.tipopermitirpickingsetor =
                                    v_tipoPickingProdDep
                                and s.idsetor = l.idsetor
                                and s.expedicao = 'S'
                                and exists
                              (select 1
                                       from setor s, tiposetor ts
                                      where s.idtiposetor = ts.idtiposetor
                                        and s.idsetor = l.idsetor
                                        and ((decode(ts.normal, 'S', 'N', '0') =
                                            r_loteUnico.estado) or
                                            (decode(ts.vencido, 'S', 'T', '0') =
                                            r_loteUnico.estado) or
                                            (decode(ts.danificado, 'S', 'D',
                                                     '0') =
                                            r_loteUnico.estado))))
        loop
        
          v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                      c_endPicking.Idarmazem,
                                                                      c_endPicking.Idlocal,
                                                                      v_msgErro);
        
          if (v_enderecoCompativel) then
            p_idlocalretornarestoque := c_endPicking.Idlocal;
            return;
          end if;
        
        end loop;
      
        if (pk_onda.usaPickingDinamico(p_idproduto, p_iddepositante,
                                       p_idarmazem) = 1) then
        
          -- ATENÇÃO: EM RELAÇÃO AO PARAMETRO v_tipoPickingProdDep
          --se o produto depositante trabalha com picking misto (0), encontra picking e um setor do tipo misto (0), 
          --se o produto depositante trabalha com segregado, encontra sempre picking de unidades (1)
          --por isso foi passado diretamente o parametro do produtodepositante (que pode ser 0 ou 1) 
          --para encontrar o tipo de picking (que pode ser 0, 1 ou 2)
          p_idlocalretornarestoque := pk_picking_dinamico.inserir_picking_dinamico_auto(p_idproduto,
                                                                                        p_iddepositante,
                                                                                        p_idarmazem,
                                                                                        v_tipoPickingProdDep,
                                                                                        r_loteUnico);
        
        end if;
      
      else
      
        begin
          select lo.idlocal
            into v_idlocalpulmao
            from movimentacao m, local lo
           where m.idonda = p_idonda
             and m.idnotafiscal = p_idnotafiscal
             and m.idlote = p_idlote
             and m.etapa = 1
             and lo.id = m.idlocalorigem
             and lo.ativo = 'S'
             and rownum = 1;
        exception
          when no_data_found then
            select lo.idlocal
              into v_idlocalpulmao
              from paleteondanf m, local lo
             where m.idonda = p_idonda
               and m.idnotafiscal = p_idnotafiscal
               and m.idlote = p_idlote
               and lo.idlocal = m.idlocal
               and lo.idarmazem = m.idarmazem
               and rownum = 1;
        end;
      
        v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                    p_idarmazem,
                                                                    v_idlocalpulmao,
                                                                    v_msgErro);
      
        if (v_enderecoCompativel) then
          p_idlocalretornarestoque := v_idlocalpulmao;
          return;
        else
          for c_endPulmao in (select lo.idarmazem, lo.idlocal
                                from local lo, setor s, setorproduto sp,
                                     setordepositante sd
                               where sd.iddepositante = p_iddepositante
                                 and sd.idsetor = s.idsetor
                                 and sp.idproduto = p_idproduto
                                 and sp.idsetor = s.idsetor
                                 and s.expedicao = 'S'
                                 and s.idsetor = lo.idsetor
                                 and lo.idarmazem = p_idarmazem
                                 and lo.ativo = 'S'
                                 and lo.tipo in (1, 2)
                                 and lo.idlocal <> v_idlocalpulmao
                                 and exists
                               (select 1
                                        from setor s, tiposetor ts
                                       where s.idtiposetor = ts.idtiposetor
                                         and s.idsetor = lo.idsetor
                                         and ((decode(ts.normal, 'S', 'N', '0') =
                                             r_loteUnico.estado) or
                                             (decode(ts.vencido, 'S', 'T',
                                                      '0') =
                                             r_loteUnico.estado) or
                                             (decode(ts.danificado, 'S', 'D',
                                                      '0') =
                                             r_loteUnico.estado)))
                               order by sp.prioridade, lo.idlocal)
          loop
            v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                        c_endPulmao.idarmazem,
                                                                        c_endPulmao.idlocal,
                                                                        v_msgErro);
          
            if (v_enderecoCompativel) then
              p_idlocalretornarestoque := c_endPulmao.idlocal;
              return;
            end if;
          end loop;
        
        end if;
      end if;
    end if;
  end retornoEstoqueParaPicking;

  -- Refactored procedure retornarEstoqueParaRegiaoRetorno 
  procedure retornarEstoqueParaRegiao
  (
    p_iddepositante          in number,
    p_idarmazem              in number,
    p_idproduto              in number,
    p_idlote                 in number,
    p_qtde                   in number,
    p_idlocal                in local.idlocal%type,
    p_idlocalretornarestoque in out local.idlocal%type,
    p_configuracaoonda       in configuracaoonda%rowtype
  ) is
    v_idregiaoatual      number;
    v_cabeprodutonolocal boolean;
    v_temlocalparaprod   boolean;
    v_barra              embalagem.barra%type;
    v_qtdeNoFator        number;
    v_regiaoarmazenagem  regiaoarmazenagem%rowtype;
    v_tipoerro           number;
    r_loteUnico          pk_lote.t_loteunico;
    v_msgErro            varchar2(1000);
    v_msg                t_message;
    v_idLocal            local.id%type;
  
  begin
    v_cabeprodutonolocal := false;
    v_temlocalparaprod   := false;
  
    begin
      select *
        into v_regiaoarmazenagem
        from regiaoarmazenagem r
       where r.idregiao = p_configuracaoonda.idregiaoretornoestoque;
    exception
      when no_data_found then
        v_msg := t_message('Não foi possivel encontrar a região de armazenagem definida na configuração da onda (idconfiguracaoonda: {0})');
        v_msg.addParam(p_configuracaoonda.idconfiguracaoonda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    select l.idregiao
      into v_idregiaoatual
      from local l
     where l.idarmazem = p_idarmazem
       and l.idlocal = p_idlocal;
  
    if (v_idregiaoatual = p_configuracaoonda.idregiaoretornoestoque) then
      p_idlocalretornarestoque := p_idlocal;
      return;
    end if;
  
    begin
      select e.barra, (p_qtde / e.fatorconversao), lt.descr, lt.dtvenc,
             lt.estado, pd.loteuniconoendereco, lt.idproduto,
             lt.iddepositante
        into v_barra, v_qtdeNoFator, r_loteUnico.loteindustria,
             r_loteUnico.dtvencimento, r_loteUnico.estado,
             r_loteUnico.loteuniconoendereco, r_loteUnico.idProduto,
             r_loteUnico.iddepositante
        from lote lt, embalagem e, produtodepositante pd
       where lt.idlote = p_idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and pd.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante;
    exception
      when no_data_found then
        select lt.idproduto, lt.iddepositante
          into r_loteUnico.idProduto, r_loteUnico.iddepositante
          from lote lt
         where lt.idlote = p_idlote;
      
        v_msg := t_message('O produto não está vinculado ao depositante' ||
                           'IDDEPOSITANTE: {0}' || chr(13) ||
                           'IDPRODUTO: {1}');
        v_msg.addParam(r_loteUnico.iddepositante);
        v_msg.addParam(r_loteUnico.idProduto);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    -- seleciona os locais que o produto pode ser retornado
    if (p_configuracaoonda.validarvinculoprodsetorretestq = 1) then
      for c_local in (select l.idarmazem, l.idlocal
                        from regiaoarmazenagem r, local l, setor s,
                             setorproduto sp, setordepositante sd
                       where r.idregiao =
                             p_configuracaoonda.idregiaoretornoestoque
                         and l.idregiao = r.idregiao
                         and l.ativo = 'S'
                         and l.idarmazem = p_idarmazem
                         and s.idsetor = l.idsetor
                         and s.ativo = 'S'
                         and s.expedicao = 'S'
                         and sp.idsetor = s.idsetor
                         and sp.idproduto = p_idproduto
                         and sd.idsetor = s.idsetor
                         and sd.iddepositante = p_iddepositante)
      loop
        -- se tem local para o produto é avaliado se tem capacidade para comportar o lote
        v_temlocalparaprod   := true;
        v_cabeprodutonolocal := pk_remanejamento.CtrlValidarRestriFisicas(p_idproduto,
                                                                          v_qtdeNoFator,
                                                                          c_local.idarmazem,
                                                                          c_local.idlocal,
                                                                          v_barra,
                                                                          v_tipoerro);
        if (v_cabeprodutonolocal) then
          v_cabeprodutonolocal := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                      c_local.idarmazem,
                                                                      c_local.idlocal,
                                                                      v_msgErro);
        
          if (v_cabeprodutonolocal) then
            p_idlocalretornarestoque := c_local.idlocal;
          end if;
        end if;
      
        exit when v_cabeprodutonolocal;
      end loop;
    
    else
      -- NÃO SERÁ CONSIDERADO SE O PRODUTO ESTÁ VINCULADO NO SETOR
      -- NÃO SERÁ CONSIDERADO SE O LOCAL POSSUI RESTRIÇÕES FISICAS
      -- NÃO SERÁ CONSIDERADO SE O LOCAL PODE RECEBER LOTE ÚNICO
      for c_local in (select l.idarmazem, l.idlocal, l.id
                        from regiaoarmazenagem r, local l, setor s,
                             setordepositante sd
                       where r.idregiao =
                             p_configuracaoonda.idregiaoretornoestoque
                         and l.idregiao = r.idregiao
                         and l.ativo = 'S'
                         and l.idarmazem = p_idarmazem
                         and s.idsetor = l.idsetor
                         and s.ativo = 'S'
                         and s.expedicao = 'S'
                         and sd.idsetor = s.idsetor
                         and sd.iddepositante = p_iddepositante)
      loop
        v_temlocalparaprod       := true;
        v_cabeprodutonolocal     := true;
        p_idlocalretornarestoque := c_local.idlocal;
        v_idLocal                := c_local.id;
      
        exit when v_idLocal > 0;
      end loop;
    
    end if;
  
    if (not v_temlocalparaprod) then
      v_msg := t_message('Não foram encontrados locais para retorno do produto id: ' ||
                         '{0} na região de retorno {1} (idregiao: {2}).');
      v_msg.addParam(p_idproduto);
      v_msg.addParam(v_regiaoarmazenagem.descr);
      v_msg.addParam(v_regiaoarmazenagem.idregiao);
      raise_application_error(-20000, v_msg.formatMessage);
    
    end if;
  
    if (not v_cabeprodutonolocal) then
      v_msg := t_message('Não foram encontrados locais com capacidade física total disponível para retornar o estoque para região de retorno ' ||
                         '{0} (idregiao: {1}). Lote: {2}.' ||
                         ' Idproduto: {3}. IdArmazem: {4}. IdDepositante: {5}');
      v_msg.addParam(v_regiaoarmazenagem.descr);
      v_msg.addParam(v_regiaoarmazenagem.idregiao);
      v_msg.addParam(p_idlote);
      v_msg.addParam(p_idproduto);
      v_msg.addParam(p_idarmazem);
      v_msg.addParam(p_iddepositante);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end retornarEstoqueParaRegiao;

  -- Refactored procedure getLocalRetornoEstoque 
  procedure getLocalRetornoEstoque
  (
    p_configuracaoonda       in configuracaoonda%rowtype,
    p_idonda                 in number,
    p_idnotafiscal           in number,
    p_iddepositante          in number,
    p_idarmazem              in number,
    p_idproduto              in number,
    p_idlote                 in number,
    p_qtde                   in number,
    p_idlocal                in local.idlocal%type,
    p_idlocalretornarestoque in out local.idlocal%type
  ) is
  
    v_codInternoProd varchar2(1000);
    v_descrProd      varchar2(1000);
    v_msg            t_message;
  
  begin
    -- Caso existe local de retorno informado para cancelamento de produto via OC o mesmo é retornado
    begin
      select gl.idlocal
        into p_idlocalretornarestoque
        from gtt_local gl
       where gl.idarmazem = p_idarmazem;
    exception
      when no_data_found then
        p_idlocalretornarestoque := null;
    end;
  
    if (p_idlocalretornarestoque is not null) then
      return;
    end if;
  
    if (p_configuracaoonda.utilizarregiaoretorno = 1) then
      retornarEstoqueParaRegiao(p_iddepositante, p_idarmazem, p_idproduto,
                                p_idlote, p_qtde, p_idlocal,
                                p_idlocalretornarestoque, p_configuracaoonda);
    else
      retornoEstoqueParaPicking(p_idonda, p_idnotafiscal, p_iddepositante,
                                p_idproduto, p_idlote, p_idarmazem,
                                p_idlocal, p_idlocalretornarestoque);
    end if;
  
    if (p_idlocalretornarestoque is null) then
    
      select p.codigointerno, p.descr
        into v_codInternoProd, v_descrProd
        from produto p
       where p.idproduto = p_idproduto;
    
      v_msg := t_message('Não foi localizado endereço compatível para retornar o produto {0} - {1}.' ||
                         chr(13) || 'Operação cancelada.');
      v_msg.addParam(v_codInternoProd);
      v_msg.addParam(v_descrProd);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end getLocalRetornoEstoque;

  procedure removerIntegracoesEsteira
  (
    p_idonda       number,
    p_idnotafiscal number
  ) is
    -- C_TIPO_REM_CX_MOV     constant number := 0;
    -- C_TIPO_REM_CX_GRA     constant number := 1;
    C_TIPO_VOL_CX_FECHADA constant number := 2;
    C_TIPO_VOL_COLMEIA    constant number := 3;
    C_TIPO_PESAGEM_VOL    constant number := 4;
    C_TIPO_AUD_VOL        constant number := 5;
    -- C_TIPO_LIB_COLETA     constant number := 6;
  
    C_NAO_INTEGRADO          constant number := 0;
    C_TIPO_OPER_CANCELAMENTO constant number := 9;
  
  begin
  
    for c_int_vol_romaneio in (select vr.idvolumeromaneio idoperacao
                                 from volumeromaneio vr
                                where vr.idromaneio = p_idonda
                                  and vr.idnotafiscal = p_idnotafiscal)
    loop
    
      for c_int_aut in (select *
                          from int_automacao_esteira
                         where idoperacao = c_int_vol_romaneio.idoperacao
                           and tipooperacao in
                               (C_TIPO_VOL_CX_FECHADA, C_TIPO_VOL_COLMEIA,
                                C_TIPO_PESAGEM_VOL, C_TIPO_AUD_VOL)
                           and integrado = C_NAO_INTEGRADO)
      loop
      
        delete from int_automacao_esteira i
         where i.idoperacao = c_int_aut.idoperacao
           and i.tipooperacao = c_int_aut.tipooperacao;
      
        insert into historico_automacao_esteira
          (id, data, evento, esteira, codintegracao, identificador,
           integrado, pesagemliberada, idoperacao, tipooperacao,
           usuariologado)
        values
          (seq_hist_automacao_esteira.nextval, sysdate, 1,
           c_int_aut.esteira, c_int_aut.codintegracao,
           c_int_aut.identificador, c_int_aut.integrado,
           c_int_aut.pesagemliberada, c_int_aut.idoperacao,
           C_TIPO_OPER_CANCELAMENTO, SYS_CONTEXT('USERENV', 'OS_USER'));
      
      end loop;
    end loop;
  
  end removerIntegracoesEsteira;

  -- Cancela as movimentaçoes e remove a reserva de estoque para a nota fiscal 
  procedure cancelarMovimentacoes
  (
    p_idonda        in number,
    p_idnotafiscal  in number,
    p_idusuario     in number,
    p_iddepositante in number
  ) is
    CONFESCAN_CANCELADO   constant number := 7;
    CONFMONTVOL_CANCELADO constant number := 6;
    v_idlocalretornarestoque local.idlocal%type;
    v_configuracaoonda       configuracaoonda%rowtype;
    v_rastrearinfoespecifica number;
    v_idLocal                local.idlocal%type;
    v_idLocalAnterior        local.idlocal%type;
  
    function retLocalEstoqueOS return local.idlocal%type is
      C_TIPOOS_FORMACAOKIT        constant ordemservico.tiposervico%type := 'K';
      C_TIPOOS_DESMONTAGEMKIT     constant ordemservico.tiposervico%type := 'D';
      C_TIPOOS_ESTOJAMENTO        constant ordemservico.tiposervico%type := 'E';
      C_TIPOOS_DESMONTESTOJAMENTO constant ordemservico.tiposervico%type := 'J';
      C_TIPOOS_FORMACAOKITRASTR   constant ordemservico.tiposervico%type := 'I';
    
      C_TPLOCAL_FORMACAOKIT        constant local.tipo%type := 14;
      C_TPLOCAL_DESMONTAGEMKIT     constant local.tipo%type := 15;
      C_TPLOCAL_ESTOJAMENTO        constant local.tipo%type := 16;
      C_TPLOCAL_DESMONTESTOJAMENTO constant local.tipo%type := 17;
      C_TPLOCAL_FORMACAOKITRASTR   constant local.tipo%type := 20;
    
      v_idarmazem   local.idarmazem%type;
      v_tipoLocalOS local.tipo%type;
      v_idLocalOS   local.idlocal%type;
    begin
      select rp.idarmazem,
             (case
                when os.tiposervico = C_TIPOOS_FORMACAOKIT then
                 C_TPLOCAL_FORMACAOKIT
                when os.tiposervico = C_TIPOOS_DESMONTAGEMKIT then
                 C_TPLOCAL_DESMONTAGEMKIT
                when os.tiposervico = C_TIPOOS_ESTOJAMENTO then
                 C_TPLOCAL_ESTOJAMENTO
                when os.tiposervico = C_TIPOOS_DESMONTESTOJAMENTO then
                 C_TPLOCAL_DESMONTESTOJAMENTO
                when os.tiposervico = C_TIPOOS_FORMACAOKITRASTR then
                 C_TPLOCAL_FORMACAOKITRASTR
              end) tipoLocalOS
        into v_idarmazem, v_tipoLocalOS
        from romaneiopai rp, ordemservico os
       where os.idromaneio = rp.idromaneio
         and os.idromaneio = p_idonda;
    
      select lo.idlocal
        into v_idLocalOS
        from local lo
       where lo.idarmazem = v_idarmazem
         and lo.tipo = v_tipoLocalOS;
    
      return v_idLocalOS;
    end retLocalEstoqueOS;
  begin
    pk_onda.getConfiguracaoOnda(p_idonda, v_configuracaoonda);
  
    -- Aqui a ideia e encontrar onde esta o estoque e aplicar as regras dependendo da sua posicao no armazem.
    for cm in (select idarmazem, idlocal, idlote, qtde, estoquemovimentado,
                      idproduto, qtderetiraradicionarpicking,
                      idlocal idlocalanterior, idmovimentacoes,
                      0 localEspecialOS, null idvolumeromaneio
                 from -- encontra estoque na origem para movimentação de lote
                       (select lo.idarmazem, lo.idlocal, m.idlote,
                               sum(m.qtdemovimentada) qtde,
                               decode(m.etapa, 1, decode(m.status, 1, 'S', 'N'),
                                       'S') estoquemovimentado, lt.idproduto,
                               case
                                  when (ld.buffer = 'S' and ld.picking = 'S' and
                                       ld.bufferesteira = 1) then
                                   sum(m.qtdemovimentada)
                                  else
                                   sum(m.qtdemovimentada - m.quantidade)
                                end qtderetiraradicionarpicking,
                               stragg(m.id) idmovimentacoes
                          from movimentacao m, local lo, lote lt, local ld
                         where m.idonda = p_idonda
                           and m.idnotafiscal = p_idnotafiscal
                           and ((m.status in (0, 1) and
                               v_configuracaoonda.transferenciatitularidade = 0) or
                               (m.status = 2 and
                               v_configuracaoonda.transferenciatitularidade = 1))
                           and m.idlote is not null
                           and (m.etapa in
                               (select min(etapa)
                                   from grupomovimentacao gm, movimentacao m2
                                  where gm.idgrupo = m.id
                                    and m2.id = gm.idmovimentacao
                                    and ((m2.status in (0, 1) and
                                        v_configuracaoonda.transferenciatitularidade = 0) or
                                        (m2.status = 2 and
                                        v_configuracaoonda.transferenciatitularidade = 1))) or
                               (m.etapa > 1 and exists
                                (select 1
                                    from remanejamento r, local lod
                                   where r.idromaneio = p_idonda
                                     and r.idlocaldestino = lo.idlocal
                                     and r.idarmazemdestino = lo.idarmazem
                                     and lo.picking = 'S'
                                     and lo.buffer = 'N'
                                     and r.idlocalorigem = lod.idlocal
                                     and r.idarmazemorigem = lod.idarmazem
                                     and lod.picking = 'S'
                                     and lod.buffer = 'S')))
                           and lo.id = m.idlocalorigem
                           and lt.idlote = m.idlote
                           and ld.id = m.idlocaldestino
                         group by lo.idarmazem, lo.idlocal, m.idlote,
                                  decode(m.etapa, 1,
                                          decode(m.status, 1, 'S', 'N'), 'S'),
                                  lt.idproduto, ld.buffer, ld.picking,
                                  ld.bufferesteira)
               union all
               -- encontra estoque na origem para movimentacao de volume
               /*Obs: Caso o volume seja de OS, e tenha sido formada OS com Onda,
               o estoque estará em locais especiais de cada serviço*/
                (select lo.idarmazem, lo.idlocal, cv.idlote,
                       sum(cv.quantidade) qtde, 'S' estoquemovimentado,
                       lt.idproduto, 0 qtderetiraradicionarpicking,
                       lo.idlocal idlocalanterior, null idmovimentacoes,
                       (case
                          when (os.tiposervico is not null and rp.tipo = 1) then
                           1
                          else
                           0
                        end) localEspecialOS, null idvolumeromaneio
                  from movimentacao m, local lo, conteudovolume cv, lote lt,
                       romaneiopai rp, ordemservico os
                 where m.idonda = p_idonda
                   and m.idnotafiscal = p_idnotafiscal
                   and m.status in (0, 1)
                   and m.idvolumeromaneio is not null
                   and m.etapa in
                       (select min(etapa)
                          from grupomovimentacao gm, movimentacao m2
                         where gm.idgrupo = m.id
                           and m2.id = gm.idmovimentacao
                           and m2.status in (0, 1)
                           and decode(m2.idvolumeromaneio, null,
                                      nvl(m.idvolumeromaneio, -1),
                                      m2.idvolumeromaneio) =
                               nvl(m.idvolumeromaneio, -1))
                   and lo.id = m.idlocalorigem
                   and cv.idvolumeromaneio = m.idvolumeromaneio
                   and lt.idlote = cv.idlote
                   and rp.idromaneio = m.idonda
                   and os.idromaneio(+) = rp.idromaneio
                 group by lo.idarmazem, lo.idlocal, cv.idlote, 'S',
                          lt.idproduto, 0, os.tiposervico, rp.tipo)
               union all
               -- encontra estoque de lote na rua de expedicao ou doca
                (select mv.idarmazem, mv.idlocal, mv.idlote,
                       (mv.qtdemovimentada - nvl(rq.qtderetornada, 0)) qtde,
                       mv.estoquemovimentado, mv.idproduto,
                       mv.qtderetiraradicionarpicking, mv.idlocalanterior,
                       mv.idmovimentacoes, 0 localEspecialOS,
                       null idvolumeromaneio
                  from (select ld.idarmazem, ld.idlocal, m.idlote,
                                sum(m.qtdemovimentada) qtdemovimentada,
                                'S' estoquemovimentado, lt.idproduto,
                                0 qtderetiraradicionarpicking,
                                la.idlocal idlocalanterior,
                                null idmovimentacoes
                           from movimentacao m, local ld, lote lt, local la
                          where m.idonda = p_idonda
                            and m.idnotafiscal = p_idnotafiscal
                            and m.status = 2
                            and m.idlote is not null
                            and la.id = m.idlocalorigem
                            and ld.id = m.idlocaldestino
                            and ld.tipo in (4, 6)
                            and lt.idlote = m.idlote
                            and la.id = m.idlocalorigem
                          group by ld.idarmazem, ld.idlocal, m.idlote, 'S',
                                   lt.idproduto, 0, la.idlocal) mv,
                       (select re.idarmazemorigem, re.idlocalorigem, lr.idlote,
                                sum(lr.qtde) qtderetornada
                           from loteremanejamento lr, remanejamento re, lote lt,
                                depositante d
                          where re.idromaneio = p_idonda
                            and re.cadmanual = 'N'
                            and re.status = 'F'
                            and re.idremanejamento = lr.idremanejamento
                            and d.separarlotescompletos = 1
                            and d.identidade = lt.iddepositante
                            and lt.idlote = lr.idlote
                          group by re.idarmazemorigem, re.idlocalorigem,
                                   lr.idlote) rq
                 where rq.idarmazemorigem(+) = mv.idarmazem
                   and rq.idlocalorigem(+) = mv.idlocal
                   and rq.idlote(+) = mv.idlote)
               union all
               -- encontra estoque de volume na rua de expedicao ou doca
                (select ld.idarmazem, ld.idlocal, cv.idlote,
                       sum(cv.quantidade) qtde, 'S' estoquemovimentado,
                       lt.idproduto, 0 qtderetiraradicionarpicking,
                       la.idlocal idlocalanterior, null idmovimentacoes,
                       0 localEspecialOS, m.idvolumeromaneio
                  from movimentacao m, local ld, conteudovolume cv, lote lt,
                       local la
                 where m.idonda = p_idonda
                   and m.idnotafiscal = p_idnotafiscal
                   and m.status = 2
                   and m.idvolumeromaneio is not null
                   and ld.id = m.idlocaldestino
                   and ld.tipo in (4, 6)
                   and la.id = m.idlocalorigem
                   and cv.idvolumeromaneio = m.idvolumeromaneio
                   and lt.idlote = cv.idlote
                 group by ld.idarmazem, ld.idlocal, cv.idlote, lt.idproduto,
                          la.idlocal, m.idvolumeromaneio)
               union all
               -- encontra estoque no local onde vira volume (packing, escaninho) que ainda nao virou volume e deve ser removido
               select idarmazem, idlocal, idlote, qtde, estoquemovimentado,
                      idproduto, qtderetiraradicionarpicking, idlocalanterior,
                      null idmovimentacoes, 0 localEspecialOS,
                      null idvolumeromaneio
                 from (select idarmazem, idlocal, idlote,
                               (sum(qtdemovimentada) -
                                sum((select nvl(sum(cv.quantidade), 0)
                                       from movimentacao m2, v_conteudovolume cv
                                      where m2.idonda = m.idonda
                                        and m2.idnotafiscal = m.idnotafiscal
                                        and ((m2.status in (0, 1, 2)) or
                                            (m2.status = 3 and exists
                                             (select 1
                                                 from cortefisicovolume cfv
                                                where cfv.idvolumeromaneio =
                                                      m2.idvolumeromaneio
                                                  and cfv.status = 1)))
                                        and m2.idlocalorigem = m.idlocaldestino
                                        and cv.idvolumeromaneio =
                                            m2.idvolumeromaneio
                                        and cv.idlote = m.idlote))) qtde,
                               'S' estoquemovimentado, idproduto,
                               0 qtderetiraradicionarpicking, idlocalanterior
                          from (select ld.idarmazem, ld.idlocal, m.idlote,
                                        m.idlocaldestino, m.idnotafiscal,
                                        m.idonda,
                                        sum(m.qtdemovimentada) qtdemovimentada,
                                        lt.idproduto, la.idlocal idlocalanterior
                                   from movimentacao m, local ld, lote lt,
                                        local la
                                  where m.idonda = p_idonda
                                    and m.idnotafiscal = p_idnotafiscal
                                    and m.status = 2
                                    and m.idlote is not null
                                    and ld.id = m.idlocaldestino
                                    and ld.tipo in (3, 8) --colmeia, packing
                                    and ld.buffer = 'N'
                                    and la.id = m.idlocalorigem
                                    and lt.idlote = m.idlote
                                  group by ld.idarmazem, ld.idlocal, m.idlote,
                                           m.idlocaldestino, m.idnotafiscal,
                                           m.idonda, lt.idproduto, la.idlocal) m
                         group by idarmazem, idlocal, idlote, 'S', idproduto,
                                  idlocalanterior)
                where qtde > 0
                order by idarmazem, idlocal, idlote)
    loop
      /*Obs: Caso o volume seja de OS, e tenha sido formada OS com Onda,
      o estoque estará em locais especiais de cada serviço*/
      if cm.localEspecialOS = 0 then
        v_idLocal         := cm.idlocal;
        v_idLocalAnterior := cm.idlocalanterior;
      else
        v_idLocal         := retLocalEstoqueOS;
        v_idLocalAnterior := v_idLocal;
      end if;
    
      -- todos os casos devem retirar pendencia
      pk_estoque.retirar_pendencia(cm.idarmazem, v_idLocal, cm.idlote,
                                   cm.qtde, p_idusuario,
                                   'NOTA FISCAL CANCELADA, REMOVIDO PENDENCIA PARA NOTAFISCAL ID:' ||
                                    p_idnotafiscal || ', ONDA:' || p_idonda);
    
      -- verifica se o estoque já foi movimentado e determina o local de retorno 
      if (cm.estoquemovimentado = 'S') then
        getLocalRetornoEstoque(v_configuracaoonda, p_idonda, p_idnotafiscal,
                               p_iddepositante, cm.idarmazem, cm.idproduto,
                               cm.idlote, cm.qtde, v_idLocal,
                               v_idlocalretornarestoque);
      
        -- se o local que o estoque esta é o mesmo local de retorno do produto nao faz nada.
        -- caso contrario o estoque e movido para o local de retorno 
        if (v_idlocalretornarestoque <> v_idLocal) then
          pk_estoque.retirar_estoque(cm.idarmazem, v_idLocal, cm.idlote,
                                     cm.qtde, p_idusuario,
                                     'NOTA FISCAL CANCELADA, REMOVIDO ESTOQUE PARA NOTAFISCAL ID:' ||
                                      p_idnotafiscal || ', ONDA:' ||
                                      p_idonda, 'N', null);
        
          pk_estoque.incluir_estoque(cm.idarmazem, v_idlocalretornarestoque,
                                     cm.idlote, cm.qtde, p_idusuario,
                                     'NOTA FISCAL CANCELADA, ADICIONADO ESTOQUE PARA NOTAFISCAL ID:' ||
                                      p_idnotafiscal || ', ONDA:' ||
                                      p_idonda, 'N', null);
        
          --verifica se existe separacao especifica para o lote e se existir efetua as mudancas        
          if (cm.idvolumeromaneio is not null) then
            for c_locais in (select distinct lo.idlocal
                               from movimentacao m, local lo
                              where m.idlocalorigem = lo.id
                                and m.idlote = cm.idlote
                                and m.idnotafiscal = p_idnotafiscal
                                and m.idonda = p_idonda
                                and m.status <> 3
                                and exists
                              (select 1
                                       from separacaoespecifica se
                                      where se.idnotafiscal = m.idnotafiscal
                                        and se.idlote = m.idlote
                                        and se.idlocal = lo.idlocal))
            loop
              pk_lote.AlterarSeparacaoEspecifica(cm.idlote, cm.idarmazem,
                                                 c_locais.idlocal,
                                                 v_idlocalretornarestoque,
                                                 -1);
            end loop;
          else
            pk_lote.AlterarSeparacaoEspecifica(cm.idlote, cm.idarmazem,
                                               cm.idlocalanterior,
                                               v_idlocalretornarestoque);
          end if;
        
          insert into cancelamentoonda
            (id, idarmazem, idendorigem, idenddestino, idlote, qtde,
             idnotafiscal, idonda)
          values
            (seq_cancelamentoonda.nextval, cm.idarmazem, v_idLocal,
             v_idlocalretornarestoque, cm.idlote, cm.qtde, p_idnotafiscal,
             p_idonda);
        end if;
      end if;
    
      -- verifica se o estoque estava indo para o picking para retirar o adicionar.
      -- na gtt_retirar_adicionar_onda ficam armazenados todos os lotes que devem
      -- retirar adicionar, mas somente e executado no final para nao criar remanejamentos
      -- por motivo de movimentacoes da propria onda que ainda nao foram canceladas.
      if (cm.qtderetiraradicionarpicking > 0) then
        select distinct ld.idlocal
          into v_idlocalretornarestoque
          from grupomovimentacao gm, movimentacao m, local ld
         where gm.idgrupo in (select m.id
                                from movimentacao m, local lo
                               where m.idonda = p_idonda
                                 and m.idnotafiscal = p_idnotafiscal
                                 and m.status in (0, 1)
                                 and m.idlote = cm.idlote
                                 and m.qtdemovimentada >= m.quantidade
                                 and lo.id = m.idlocalorigem
                                 and lo.idarmazem = cm.idarmazem
                                 and lo.idlocal = v_idLocal)
           and m.id = gm.idmovimentacao
           and m.status in (0, 1)
           and ld.id = m.idlocaldestino
           and ld.tipo = 0
           and (ld.buffer = 'N' or
               (ld.bufferesteira = 1 and ld.buffer = 'S'));
      
        insert into gtt_retirar_adicionar_onda
          (idarmazem, idlocalpicking, idlote, qtde, complementar,
           idlocalestoque, qtdereabastecer, idonda, idmovimentacoes)
        values
          (cm.idarmazem, v_idlocalretornarestoque, cm.idlote,
           cm.qtderetiraradicionarpicking,
           'RETIRADO ADICIONAR DEVIDO O CANCELAMENTO DA NOTAFISCAL ID: ' ||
            p_idnotafiscal || ', ONDA: ' || p_idonda, v_idLocal, cm.qtde,
           p_idonda, cm.idmovimentacoes);
      
      end if;
    
      v_rastrearinfoespecifica := pk_lote.getRastrearInfoEspecifica(cm.idlote);
      if (v_rastrearinfoespecifica = 0) then
        update estoqueinformacaoespecifica es
           set es.conferido        = 0,
               es.idconfpacking    = null,
               es.idnotafiscal     = null,
               es.idescaninho      = null,
               es.idvolumeromaneio = null,
               es.confmontvol      = 0,
               es.nrooperacao      = p_idnotafiscal,
               es.operacao         = 'RETIRADA NOTA FISCAL DA ONDA'
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      elsif (v_rastrearinfoespecifica = 1) then
        update estoqueinformacaoespecifica es
           set es.conferido        = 0,
               es.idconfpacking    = null,
               es.idlote           = null,
               es.idnotafiscal     = null,
               es.idescaninho      = null,
               es.idvolumeromaneio = null,
               es.confmontvol      = 0,
               es.nrooperacao      = p_idnotafiscal,
               es.operacao         = 'RETIRADA NOTA FISCAL DA ONDA'
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      elsif (v_rastrearinfoespecifica = 2) then
      
        insert into historicoestoqueinfespec
          (id, idarmazem, idproduto, identidade, idinfomaterial,
           identificadorinfo, numerooperacao, operacao, dataoperacao,
           valorantes, valordepois, idloteantes, idlotedepois,
           conferidoantes, conferidodepois, expedidoantes, expedidodepois)
          select seq_historicoestoqueinfespec.nextval, e.idarmazem,
                 e.idproduto, e.identidade, e.idinfomaterial,
                 e.identificadorinfo, p_idnotafiscal,
                 'RETIRADA NOTA FISCAL DA ONDA', sysdate, e.valor, e.valor,
                 e.idlote, e.idlote, e.conferido, e.conferido, e.expedida,
                 e.expedida
            from estoqueinformacaoespecifica e
           where e.idlote = cm.idlote
             and e.idnotafiscal = p_idnotafiscal;
      
        delete estoqueinformacaoespecifica es
         where es.idlote = cm.idlote
           and es.idnotafiscal = p_idnotafiscal;
      end if;
    end loop;
  
    update confescaninho ce
       set ce.status = CONFESCAN_CANCELADO
     where ce.idnotafiscal = p_idnotafiscal;
  
    update confmontvolcolmeia cmv
       set cmv.status = CONFMONTVOL_CANCELADO
     where cmv.idnotafiscal = p_idnotafiscal;
  
    update movimentacao m
       set m.status = 3
     where m.idonda = p_idonda
       and m.idnotafiscal = p_idnotafiscal;
  
    update tipocaixavolume t
       set t.disponivel = 1,
           t.idonda     = null
     where t.idtipocaixavolume in
           (select vr.idtipocaixavolume
              from volumeromaneio vr, tipocaixavolume tx
             where vr.statusvolume = 0
               and vr.idromaneio = p_idonda
               and vr.idnotafiscal = p_idnotafiscal
               and tx.idtipocaixavolume = vr.idtipocaixavolume
               and tx.retornavel = 1);
  
    delete from historicocaixaretornavel
     where dataretorno is null
       and idtipocaixavolume in
           (select vr.idtipocaixavolume
              from volumeromaneio vr, tipocaixavolume tx
             where vr.statusvolume = 0
               and vr.idromaneio = p_idonda
               and vr.idnotafiscal = p_idnotafiscal
               and tx.idtipocaixavolume = vr.idtipocaixavolume
               and tx.retornavel = 1);
  
    delete from conteudocarrinho cc
     where 1 = 1
       and cc.idmovimentacao in
           (select m.id
              from movimentacao m
             where m.idonda = p_idonda
               and m.idnotafiscal = p_idnotafiscal);
  
    update caixaseparacao cx
       set cx.liberado     = 1,
           cx.codigotarefa = null
     where cx.idcaixaseparacao in
           (select seb.idcaixaseparacao
              from sepbuffercolmeia seb
             where seb.idonda = p_idonda
               and seb.idnotafiscal = p_idnotafiscal
            union all
            select cp.idcaixaseparacao
              from movimentacao m, caixaseparacao cp, romaneiopai rp
             where 1 = 1
               and rp.idromaneio = m.idonda
               and m.idonda = p_idonda
               and m.idnotafiscal = p_idnotafiscal
               and (cp.codigotarefa =
                   lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0') or
                   cp.codigotarefa = rp.codigointerno))
       and cx.liberado = 0
       and not exists
     (select 1
              from conteudocarrinho cr
             where 1 = 1
               and cr.idcaixaseparacao = cx.idcaixaseparacao);
  
    delete from sepbuffercolmeia seb
     where seb.idonda = p_idonda
       and seb.idnotafiscal = p_idnotafiscal;
  
    for c_volume in (select vr.idvolumeromaneio, m.idlocalorigem,
                            vr.idtipocaixavolume
                       from volumeromaneio vr, movimentacao m
                      where vr.idromaneio = p_idonda
                        and vr.idnotafiscal = p_idnotafiscal
                        and m.idvolumeromaneio = vr.idvolumeromaneio)
    loop
      if (c_volume.idtipocaixavolume is not null) then
        pk_onda.utilizarCaixaVolume(c_volume.idlocalorigem,
                                    c_volume.idvolumeromaneio,
                                    c_volume.idtipocaixavolume, p_idusuario,
                                    'E');
      end if;
    end loop;
  
    removerIntegracoesEsteira(p_idonda, p_idnotafiscal);
  
    pk_expedicao.desassociarCodRastreioVolumeNF(p_idnotafiscal);
  
    update volumeromaneio vr
       set vr.statusvolume = 1
     where vr.idnotafiscal = p_idnotafiscal;
  
    pk_romaneio.AtualizaStatusAuditoria(p_idonda);
  
  end cancelarMovimentacoes;

  -- Remove a nota fiscal do escaninho 
  procedure retirarNfDoEscaninho
  (
    p_idonda       in number,
    p_idnotafiscal in number
  ) is
  begin
    for c in (select e.idendereco
                from escaninho e
               where e.idnotafiscal = p_idnotafiscal
                 and e.idromaneio = p_idonda)
    loop
      if (c.idendereco is not null) then
        delete from conteudoescaninho ce
         where ce.idescaninho = c.idendereco;
      
        update escaninho e
           set e.status            = 0,
               e.idnotafiscal      = null,
               e.idromaneio        = null,
               e.idusuariomontagem = null
         where e.idendereco = c.idendereco;
      end if;
    end loop;
  end retirarNfDoEscaninho;

  -- Refactored procedure retirarBaixaEfetiva 
  procedure retirarBaixaEfetiva
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
  begin
    for c_baixa in (select b.idarmazem, b.idlocal, b.idlote, b.qtde
                      from baixaestoqueefetiva b
                     where b.idonda = p_idonda
                       and b.idnotafiscal = p_idnotafiscal
                       and b.qtde > 0)
    loop
      pk_estoque.retirar_pendencia(c_baixa.idarmazem, c_baixa.idlocal,
                                   c_baixa.idlote, c_baixa.qtde, p_idusuario,
                                   'NOTA FISCAL CANCELADA, REMOVIDO PENDENCIA PARA NOTAFISCAL ID:' ||
                                    p_idnotafiscal || ', ONDA:' || p_idonda ||
                                    ' PARA REALIZACAO DA BAIXA EFETIVA PRODUTO PESAVEL');
    end loop;
  end retirarBaixaEfetiva;

  procedure cancNotaFiscalRemessaTerceiro
  (
    p_notafiscal notafiscal.idnotafiscal%type,
    p_idusuario  number
  ) is
    v_notaFiscalRemessa notafiscal.idnotafiscal%type;
    v_nfRemessaAuto     integer;
    v_nfCodigoInterno   notafiscal.codigointerno%type;
    v_msg               t_message;
    v_mensagem          varchar2(1000);
    v_idprenf           number;
  begin
    if (pk_notaremessa.possuiNotaRemessa(p_idNotaFiscal => p_notafiscal,
                                         p_idRemessa => v_notaFiscalRemessa)) then
    
      begin
        select 1
          into v_nfRemessaAuto
          from nfe n, notafiscal nf
         where nf.idnotafiscal = n.idnotafiscal
           and nf.idnotafiscal = v_notaFiscalRemessa
           and n.situacao = 3
           and n.id = (select max(n2.id)
                         from nfe n2
                        where n2.idnotafiscal = n.idnotafiscal);
      exception
        when no_data_found then
          v_nfRemessaAuto := 0;
      end;
    
      if (v_nfRemessaAuto < 1) then
      
        update nfcot cot
           set cot.ativo = 0
         where cot.idnotaremessa = v_notaFiscalRemessa;
      
        select nf.idprenf
          into v_idprenf
          from notafiscal nf
         where nf.idnotafiscal = v_notaFiscalRemessa;
      
        pk_notafiscal.CancelaNF(v_idprenf, p_idusuario,
                                'CANCELAMENTO DA NF DE REMESSA POR CONTA E ORDEM DE TERCEIROS COM IDNOTAFISCAL: ' ||
                                 v_notaFiscalRemessa ||
                                 ', VINCULADA À NF DE VENDA ' ||
                                 p_notafiscal, 'N', 'S', v_mensagem);
      
        if (v_mensagem is not null) then
          raise_application_error(-20000, v_mensagem);
        end if;
      else
        begin
          select codigoInterno
            into v_nfCodigoInterno
            from notafiscal
           where idNotafiscal = p_notafiscal;
        end;
        v_msg := t_message('Não é permitido retirar a nota fiscal {0},' ||
                           ' pois ela possui uma N.F.C.O.T autorizada na sefaz. id: {1}.' ||
                           ' É necessário cancelar esta nota na SEFAZ primeiro');
        v_msg.addParam(v_nfCodigoInterno);
        v_msg.addParam(v_notaFiscalRemessa);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  end cancNotaFiscalRemessaTerceiro;

  procedure cancelarTrocaLote
  (
    p_idonda       in number,
    p_idnotafiscal in number
  ) is
  
    cursor c_idTrocaLote is
      select c.id idTrocaLote
        from trocarloteseponda c
       where c.idonda = p_idonda
         and c.idnotafiscal = p_idnotafiscal;
  
    r c_idTrocaLote%rowtype;
  
    C_STATUS_TROCALOTE_CANC    CONSTANT NUMBER := 2;
    C_STATUS_TROCALOTEDET_CANC CONSTANT NUMBER := 0;
  
  begin
    for r in c_idTrocaLote
    loop
    
      update trocarloteseponda tlc
         set tlc.datacancelamento = sysdate,
             tlc.status           = C_STATUS_TROCALOTE_CANC
       where tlc.idonda = p_idonda
         and tlc.idnotafiscal = p_idnotafiscal
         and tlc.id = r.idtrocalote;
    
      update trocarlotesepondadet tld
         set tld.datacancelamento = sysdate,
             tld.status           = C_STATUS_TROCALOTEDET_CANC
       where tld.idtrocalote = r.idtrocalote;
    
    end loop;
  
  end;

  procedure voltarImpressaoNF(p_idNotaFiscal in number) is
    v_existePDF number;
    v_imprimenf char(1);
    v_idprenf   number;
  begin
    select nf.idprenf, e.imprimenf
      into v_idprenf, v_imprimenf
      from notafiscal nf, entidade e
     where nf.idnotafiscal = p_idnotafiscal
       and nf.remetente = e.identidade;
  
    select count(*)
      into v_existePDF
      from dual
     where exists (select 1
              from danfe_notafiscal d
             where d.idnotafiscal = p_idnotafiscal);
  
    if (v_existePDF = 1 and v_imprimenf = 'S') then
      update nfimpressao n
         set n.situacaoimpressao = 'A',
             n.dataimpressao     = null
       where idprenf = v_idprenf;
    
      update notafiscal
         set impresso      = 'N',
             dataimpressao = null,
             idusuarioimp  = null
       where idprenf = v_idprenf;
    end if;
  end;

  procedure cancelarNotaFiscal
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    r_notafiscal       notafiscal%rowtype;
    v_idpontoalerta    number;
    v_statusonda       number;
    v_possuifalta      number;
    v_NFRetArmazenagem number;
    v_msg              t_message;
  
    c_true constant number := 1;
  
    procedure alterarSepEspCadAutPk is
      v_idSep number;
    begin
      for c_sep in (select l.iddepositante, l.idlote, l.idproduto,
                           pd.utilizaestoquepulmao,
                           ll.idlocal idlocaldisponivel, ll.idarmazem,
                           (ll.estoque + ll.adicionar - ll.pendencia) qtde,
                           lo.idlocal localorigem, ld.idlocal localdestino,
                           s.idlocal idlocalseparacao, s.qtde qtdeseparacao,
                           s.id idsepespec
                      from movimentacao m, lote l, produtodepositante pd,
                           lotelocal ll, local lo, local ld,
                           separacaoespecifica s
                     where m.idonda = p_idonda
                       and m.idnotafiscal = p_idnotafiscal
                       and m.idlote = l.idlote
                       and pd.idproduto = l.idproduto
                       and pd.identidade = l.iddepositante
                       and ll.idlote = l.idlote
                       and (ll.estoque + ll.adicionar - ll.pendencia) > 0
                       and lo.id = m.idlocalorigem
                       and ld.id = m.idlocaldestino
                       and pd.utilizaestoquepulmao = 5
                       and s.idnotafiscal = m.idnotafiscal
                       and s.idlote = m.idlote
                       and s.idarmazem = l.idarmazem)
      loop
        if (c_sep.qtdeseparacao <= c_sep.qtde) then
          begin
            --atualiza a separação específica com o endereço com quantidade disponível do produto
            update separacaoespecifica s
               set s.idlocal = c_sep.idlocaldisponivel
             where s.id = c_sep.idsepespec;
          exception
            when dup_val_on_index then
              --caso ja tenha uma seaparação especifica pra aquele lote, endereço, nota e armazem, atualiza a quantidade
              update separacaoespecifica s
                 set s.qtde = s.qtde + c_sep.qtdeseparacao
               where s.idlocal = c_sep.idlocaldisponivel
                 and s.idlote = c_sep.idlote
                 and s.idnotafiscal = p_idnotafiscal
                 and s.idarmazem = c_sep.idarmazem
              returning s.id into v_idSep;
            
              update seploteindsepespecif s
                 set s.qtde = s.qtde + c_sep.qtdeseparacao
               where s.idsepespecifica = v_idSep;
            
              delete seploteindsepespecif s
               where s.idsepespecifica = c_sep.idsepespec;
            
              delete from separacaoespecifica s
               where s.id = c_sep.idsepespec;
          end;
        end if;
      end loop;
    end alterarSepEspCadAutPk;
  
    procedure removerCadAutomaticoPicking is
    begin
      for c_result in (select distinct l.idproduto, ld.idlocal
                         from movimentacao m, notafiscal nf, lote l,
                              produtodepositante pd, local ld
                        where m.idnotafiscal = p_idnotafiscal
                          and m.idnotafiscal = nf.idnotafiscal
                          and l.idlote = m.idlote
                          and pd.idproduto = l.idproduto
                          and pd.identidade = nf.iddepositante
                          and m.idlocalorigem = ld.id
                          and pd.utilizaestoquepulmao = 5
                          and pk_onda.usaPickingDinamico(pd.idproduto,
                                                         pd.identidade,
                                                         l.idarmazem) = 1)
      loop
        delete from produtolocal pd
         where pd.idproduto = c_result.idproduto
           and pd.idlocal = c_result.idlocal
           and (exists (select 1
                          from lotelocal ll, lote l
                         where ll.idlocal = pd.idlocal
                           and l.idproduto = pd.idproduto
                           and l.idlote = ll.idlote
                           and ll.estoque = 0
                           and ll.pendencia = 0
                           and ll.adicionar = 0) or not exists
                (select 1
                   from lotelocal ll, lote l
                  where ll.idlocal = pd.idlocal
                    and l.idproduto = pd.idproduto
                    and l.idlote = ll.idlote));
      end loop;
    end removerCadAutomaticoPicking;
  
    procedure validarConferenciaPesagem
    (
      p_idnotafiscal in number,
      p_idonda       in number
    ) is
      v_carga              number;
      v_conferenciaPesagem number;
    
      C_NAO              constant number := 0;
      C_CARGA_PROCESSADA constant char := 'S';
    
      function isPedidoPai return boolean is
        v_retorno number;
      begin
        select count(*)
          into v_retorno
          from (select nf.idnotafiscal
                   from notafiscal nf
                  where nf.idnotafiscal = p_idnotafiscal
                    and nvl(nf.idpedidopai, 0) = 0) p, notafiscal n,
               notafiscalcarga nfc, carga c
         where n.idpedidopai = p.idnotafiscal
           and c.finalizado = 'S'
           and nfc.idnotafiscal = n.idnotafiscal
           and c.idcarga = nfc.idcarga;
        return v_retorno > 0;
      end isPedidoPai;
    
      procedure cancelarCargaComConfPesagem is
        v_idcarga number;
      begin
        begin
          select nfc.idcarga
            into v_idcarga
            from notafiscalcarga nfc
           where nfc.idnotafiscal = p_idnotafiscal;
        exception
          when no_data_found then
            v_idcarga := 0;
        end;
      
        pk_carga.desfazerConferenciaPesagem(v_idcarga, p_idusuario);
      end cancelarCargaComConfPesagem;
    
      function isPedidoProcessado return boolean is
        v_retorno number;
      begin
        select count(*)
          into v_retorno
          from notafiscal nf, notafiscalcarga nfc, carga c
         where c.finalizado = C_CARGA_PROCESSADA
           and nf.idnotafiscal = p_idnotafiscal
           and nfc.idnotafiscal = nf.idnotafiscal
           and c.idcarga = nfc.idcarga;
        return v_retorno = 1;
      end isPedidoProcessado;
    
    begin
      begin
        select conf.conferenciapesagem
          into v_conferenciaPesagem
          from romaneiopai rp, configuracaoonda conf
         where rp.idromaneio = p_idonda
           and conf.conferenciapesagem > 0
           and conf.idconfiguracaoonda = rp.idconfiguracaoonda;
      exception
        when no_data_found then
          v_conferenciaPesagem := 0;
      end;
    
      if (v_conferenciaPesagem = C_NAO) then
        return;
      end if;
    
      if (isPedidoProcessado) then
        v_msg := t_message('O documento {0} ja encontra-se com a coleta processada.Operação cancelada.');
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (isPedidoPai) then
        v_msg := t_message('O documento {0} possui pedidos filhos em coleta procssado. Operação cancelada.');
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      cancelarCargaComConfPesagem;
    end validarConferenciaPesagem;
  
    procedure cancelarRemLotesCompletos is
      v_separarLotesCompletos number;
    begin
      select d.separarlotescompletos
        into v_separarLotesCompletos
        from notafiscal nf, depositante d
       where nf.idnotafiscal = p_idnotafiscal
         and d.identidade = nf.iddepositante;
    
      if (v_separarLotesCompletos = 1) then
        for c_rem in (select distinct r.idremanejamento, r.idarmazemorigem,
                                      r.idlocalorigem
                        from movimentacao m, loteremanejamento lr,
                             remanejamento r, local ld
                       where m.idonda = p_idonda
                         and m.etapa = 1
                         and m.status = 2
                         and m.idnotafiscal = p_idnotafiscal
                         and lr.idlote = m.idlote
                         and r.idremanejamento = lr.idremanejamento
                         and r.cadmanual = 'N'
                         and r.status <> 'F'
                         and ld.id = m.idlocaldestino
                         and ld.tipo in (4, 6)
                         and ld.idarmazem = r.idarmazemorigem
                         and ld.idlocal = r.idlocalorigem)
        loop
          update loteremanejamento
             set idromaneio = null
           where idromaneio = p_idonda
             and idremanejamento = c_rem.idremanejamento;
        
          update remanejamento
             set idromaneio = null
           where idromaneio = p_idonda
             and idremanejamento = c_rem.idremanejamento;
        
          update remanejamento r
             set r.planejado = 'N'
           where r.idremanejamento = c_rem.idremanejamento;
        
          for c_loterem in (select idlote, qtde
                              from loteremanejamento
                             where idremanejamento = c_rem.idremanejamento)
          loop
            delete from loteremanejamento
             where idremanejamento = c_rem.idremanejamento
               and idlote = c_loterem.idlote;
          
            -- todos os casos devem adicionar pendencia
            pk_estoque.incluir_pendencia(c_rem.idarmazemorigem,
                                         c_rem.idlocalorigem,
                                         c_loterem.idlote, c_loterem.qtde,
                                         p_idusuario,
                                         'CANCELAMENTO DE REMANEJAMENTO DE RETORNO DE SEPARAÇÃO DE LOTES COMPLETOS, ADICIONADA PENDENCIA PARA NOTAFISCAL ID:' ||
                                          p_idnotafiscal || ', ONDA:' ||
                                          p_idonda);
          
          end loop;
        
          delete remanejamentoromaneio
           where idremanejamento = c_rem.idremanejamento;
        
          delete from remanejamento
           where idremanejamento = c_rem.idremanejamento;
        
          pk_utilities.GeraLog(p_idusuario,
                               substr('O REMANEJAMENTO ' ||
                                       c_rem.idremanejamento ||
                                       ' FOI EXCLUIDO POIS A ONDA DE ID: ' ||
                                       p_idonda || ' FOI DESFEITA.', 1, 1000),
                               c_rem.idremanejamento, 'DR');
        end loop;
      end if;
    end cancelarRemLotesCompletos;
  
    procedure efetivaCanceladosERP is
      v_idprenf      notafiscal.idprenf%type;
      v_canceladoERP number;
      v_erro         varchar2(1000);
    begin
      select max(nf.idprenf), max(nf.canceladoerp)
        into v_idprenf, v_canceladoERP
        from notafiscal nf
       where nf.idnotafiscal = p_idnotafiscal;
    
      if (v_canceladoERP = c_true) then
        pk_notafiscal.CancelaNF(v_idprenf, p_idusuario,
                                'CANCELADO PELO ERP', 'N', 'S', v_erro);
      
        if v_erro is not null then
          raise_application_error(-20000, v_erro);
        end if;
      end if;
    end efetivaCanceladosERP;
  
  begin
    select count(*)
      into v_possuifalta
      from cortefisico c, cortefisiconf cnf
     where c.idonda = p_idonda
       and cnf.idcortefisico = c.id
       and cnf.idnotafiscal = p_idnotafiscal
       and c.status = 0;
  
    if (v_possuifalta > 0) then
      v_msg := t_message('Não é permitido cancelar a nota fiscal com id {0}.' ||
                         ' Ela possui registro de corte fisico pendente de resolução. Resolva o corte primeiro.');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_possuifalta
      from volumeromaneio vr, cortefisicovolume cfv
     where vr.idromaneio = p_idonda
       and vr.idnotafiscal = p_idnotafiscal
       and cfv.idvolumeromaneio = vr.idvolumeromaneio
       and cfv.status = 0;
  
    if (v_possuifalta > 0) then
      v_msg := t_message('Não é permitido cancelar a nota fiscal com id {0}.' ||
                         ' Ela possui registro de corte fisico de volume pendente de resolução. Resolva o corte primeiro.');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarConferenciaPesagem(p_idnotafiscal, p_idonda);
    validarStatusNF(r_notafiscal, p_idnotafiscal, v_idpontoalerta);
  
    -- Verificar se a nota fiscal de venda possui nota fiscal de remessa por conta de terceiro
    cancNotaFiscalRemessaTerceiro(r_notafiscal.idnotafiscal, p_idusuario);
  
    removerPontoAlerta(v_idpontoalerta);
    validarNfColetaAutomatica(p_idonda, p_idnotafiscal);
    retirarNfDaCaleta(p_idnotafiscal);
    cancelarTrocaLote(p_idonda, p_idnotafiscal);
    cancelarRemLotesCompletos;
    cancelarMovimentacoes(p_idonda, p_idnotafiscal, p_idusuario,
                          r_notafiscal.iddepositante);
    pk_triggers_control.disableTrigger('T_BEFORE_REMANEJAMENTO');
    pk_remanejamento.desfazerRemanejamento(p_idonda, p_idusuario, 1,
                                           p_idnotafiscal);
    pk_triggers_control.enableTrigger('T_BEFORE_REMANEJAMENTO');
    alterarSepEspCadAutPk;
    retirarNfDoEscaninho(p_idonda, p_idnotafiscal);
    retirarBaixaEfetiva(p_idonda, p_idnotafiscal, p_idusuario);
    retirarPaletSeparacaoNf(p_idnotafiscal);
    voltarImpressaoNF(p_idNotaFiscal);
    removerCadAutomaticoPicking;
  
    update notafiscal nf
       set nf.imprimeetiquetatransportador = 0,
           nf.qtdevolumescontrolado        = null
     where nf.idnotafiscal = p_idnotafiscal;
  
    for e in (select e.id
                from etiquetatransportador e
               where 1 = 1
                 and e.idnotafiscal = p_idnotafiscal)
    loop
      delete from historicoetiqtransportador h
       where 1 = 1
         and h.idetiquetatransp = e.id;
    
      delete from etiquetatransportador et
       where 1 = 1
         and et.id = e.id;
    end loop;
  
    select r.statusonda
      into v_statusOnda
      from romaneiopai r
     where r.idromaneio = p_idonda;
  
    pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    update nfdet
       set qtdeatendida = 0
     where nf = p_idnotafiscal;
    pk_triggers_control.enableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    update nfdetimpressao
       set qtdeatendida = 0
     where idprenf = r_notafiscal.idprenf;
  
    -- se o status da onda for EM_FORMACAO(0)  significa que o cancelamento esta sendo
    -- chamado pela formacao da onda e ela possui corte. Neste caso as notas fiscais não devem
    -- ser retiradas da onda, somente o estoque deve ser retirado a reserva.
    if (v_statusOnda not in (0, 6)) then
      select count(*)
        into v_NFRetArmazenagem
        from dual
       where exists (select 1
                from retornosimbolico rs, notafiscal nf, operacao op,
                     depositante d, regime r
               where rs.idnotafiscalretorno = p_idnotafiscal
                 and nf.idnotafiscal = rs.idnotafiscalvenda
                 and op.idoperacao = nf.idoperacao
                 and d.identidade = nf.iddepositante
                 and r.idregime = d.idregime
                 and r.classificacao = 'A'
                 and op.tipooper in ('TA', 'G'));
    
      if v_NFRetArmazenagem = 1 then
        pk_notafiscal.desfazerNFRetArmazenagemOnda(p_idonda, p_idnotafiscal,
                                                   p_idusuario);
      end if;
    
      -- Verificando se existem notas de retorno simbólico geradas para a nota de venda (Séculus)
      for c_NFRetSimb in (select rs.idnotafiscalretorno
                            from retornosimbolico rs, notafiscal nf,
                                 operacao op, depositante d, regime r
                           where rs.idnotafiscalvenda = p_idnotafiscal
                             and nf.idnotafiscal = rs.idnotafiscalretorno
                             and op.idoperacao = nf.idoperacao
                             and d.identidade = nf.iddepositante
                             and r.idregime = d.idregime
                             and r.classificacao = 'A'
                             and r.contribuinteicms = 'S'
                             and op.tipooper = 'TS')
      loop
        pk_notafiscal.cancelarNfe(c_NFRetSimb.idnotafiscalretorno,
                                  p_idusuario);
      end loop;
    
      update produtoconfpacking pc
         set pc.status = 0
       where exists (select 1
                from confpacking c
               where c.idnotafiscal = p_idnotafiscal
                 and c.idonda = p_idonda
                 and c.id = pc.idconfpacking);
    
      --alterar status da confpacking para cancelado da notafiscal quando a onda for diferente da obtida acima
      update confpacking c
         set c.status = 2
       where c.idnotafiscal = p_idnotafiscal
         and c.idonda = p_idonda;
    
      efetivaCanceladosERP;
    end if;
  end;

  -- Verifica se existe alguma nota fiscal processada e impede o cancelamento da onda. 
  procedure validarNotasParaCancelarOnda(p_idonda in number) is
    v_qtdenfsprocessadas number;
    v_msg                t_message;
  begin
    select nvl(count(*), 0)
      into v_qtdenfsprocessadas
      from nfromaneio nfr, notafiscal n
     where nfr.idromaneio = p_idonda
       and n.idnotafiscal = nfr.idnotafiscal
       and n.statusnf = 'P';
  
    if (v_qtdenfsprocessadas > 0) then
      v_msg := t_message('Esta onda possui notas fiscais já processadas e não pode ser cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end validarNotasParaCancelarOnda;

  -- Valida status da onda para cancelamento 
  procedure validarOndaParaCancelamento
  (
    p_idonda in number,
    p_origem in number
  ) is
    v_statusonda                 number;
    v_NFRetArmazenagem           number;
    v_impedirCancOndaSepIniciada number;
    v_transfTitularidade         number;
    v_msg                        t_message;
  
    procedure validarOndaOS is
      v_total number;
    begin
      if p_origem = C_ORIGEM_CANCELAMENTO_OS then
        return;
      end if;
    
      select count(*)
        into v_total
        from dual
       where exists (select 1
                from ordemservico os
               where os.idromaneio = p_idonda);
    
      if v_total > 0 then
        v_msg := t_message('Não é permitido cancelamento de onda ou retirada de ' ||
                           'pedido / nota fiscal de onda de ordem de serviço.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarOndaOS;
  begin
    begin
      select r.statusonda, co.transferenciatitularidade
        into v_statusonda, v_transfTitularidade
        from romaneiopai r, configuracaoonda co
       where r.idromaneio = p_idonda
         and r.tipo = 1
         and co.idconfiguracaoonda = r.idconfiguracaoonda;
    exception
      when no_data_found then
        v_msg := t_message('Onda não encontrada para o id {0}');
        v_msg.addParam(p_idonda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    validarOndaOS;
  
    if (v_statusonda = 3) then
      v_msg := t_message('O cancelamento não pode ser executado pois a onda id {0} esta processada.');
      v_msg.addParam(p_idonda);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (v_statusonda = 5) then
      v_msg := t_message('O cancelamento não pode ser executado pois a onda id {0} já está cancelada.');
      v_msg.addParam(p_idonda);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (v_transfTitularidade = 1 and
       p_origem <> C_ORIGEM_TRANSF_TITULARIDADE) then
      v_msg := t_message('O cancelamento não pode ser executado pois a onda id {0} é do tipo "Transferência de Titularidade".');
      v_msg.addParam(p_idonda);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    --Verifica a origem da chamada da procedure, se a origem for 
    --atraves da procedure cancelarOnda realizar a valição abaixo.
    if p_origem = C_ORIGEM_CANCELAR_ONDA then
      select count(*)
        into v_impedirCancOndaSepIniciada
        from dual
       where exists
       (select 1
                from romaneiopai rp, movimentacao m, configuracaoonda c
               where c.impedirCancOndaSepIniciada = 1
                 and m.status in (1, 2)
                 and rp.idromaneio = p_idonda
                 and rp.idromaneio = m.idonda
                 and rp.idconfiguracaoonda = c.idconfiguracaoonda);
    
      if v_impedirCancOndaSepIniciada > 0 then
        v_msg := t_message('A Onda id: {0} já está em processo de separação, portanto, não é possível Cancelar a Onda, por favor, utilize a funcionalidade de Retirar Nota da Onda');
        v_msg.addParam(p_idonda);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    end if;
  
    if (p_origem <> C_ORIGEM_RETIRAR_NOTA) then
      select count(*)
        into v_NFRetArmazenagem
        from retornosimbolico rs, notafiscal nf, nfimpressao nfi,
             operacao op, depositante d, regime re
       where nf.idnotafiscal = rs.idnotafiscalretorno
         and nfi.idprenf = nf.idprenf
         and (nfi.situacaonfe not in (6, 10) and
             not (exists (select 1
                             from nfe nfe
                            where nfe.idnotafiscal = rs.idnotafiscalretorno
                              and nfe.situacao = 4) and not exists
               (select 1
                      from nfe nfe
                     where nfe.idnotafiscal = rs.idnotafiscalretorno
                       and nfe.situacao not in (4, 5))))
         and op.idoperacao = nf.idoperacao
         and d.identidade = nf.iddepositante
         and re.idregime = d.idregime
         and re.classificacao = 'A'
         and re.contribuinteicms = 'S'
         and op.tipooper = 'TA'
         and rs.idnotafiscalretorno in
             (select idnotafiscal
                from nfromaneio
               where idromaneio = p_idonda);
    
      if (v_NFRetArmazenagem > 0) then
        v_msg := t_message('Esta onda possui notas fiscais de retorno já faturadas e deve ser cancelada pela tela de controle de NF-e.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
  end validarOndaParaCancelamento;

  /*
   *  Rotina responsavel por retirar o adicionar do picking quando uma onda e cancelada ou uma nota fiscal e retirada.
  */
  procedure retirarAdicionarDoPicking
  (
    p_idonda    in number,
    p_idusuario in number
  ) is
    v_idremanejamento number;
    v_regiaoorigem    varchar2(1000);
    v_ruaorigem       local.rua%type;
    v_regiaodestino   varchar2(1000);
    v_ruadestino      local.rua%type;
    v_idonda          number;
  begin
    for c in (select idarmazem, idlocalpicking, idlote, qtde, complementar,
                     idlocalestoque, qtdereabastecer, idonda, idmovimentacoes
                from gtt_retirar_adicionar_onda)
    loop
      v_idonda := null;
      if p_idonda <> c.idonda then
        v_idonda := c.idonda;
      end if;
    
      begin
        --TENTA DESFAZER O GRUPO DE REMANEJAMENTOS DE PULMÃO PARA BUFFER DE PK, DOS "IDMOVIMENTACAO" ENVOLVIDOS
        --CASO NÃO CONSIGA DESFAZER OS REMANEJAMENTOS, OCORRERÁ ERRO DE CHECK CONTRAINT NO COMANDO SEGUINTE
        --CRIANDO UM REMANEJAMENTO DO PULMÃO PARA O BUFFER DE PK PARA SUBSTITUIR A MOVIMENTAÇÃO DA ONDA QUE FOI CANCELADA
        pk_triggers_control.disableTrigger('T_BEFORE_REMANEJAMENTO');
      
        pk_remanejamento.desfazRemanejBuffPickParaPick(p_idonda,
                                                       p_idusuario,
                                                       c.idmovimentacoes);
      
        pk_triggers_control.enableTrigger('T_BEFORE_REMANEJAMENTO');
      
        pk_estoque.retirar_adicionar(c.idarmazem, c.idlocalpicking,
                                     c.idlote, c.qtde, p_idusuario,
                                     c.complementar);
      exception
        when others then
          -- se nao foi possivel retirar o adicionar significa que existe alguma outra operaçao utilizando o adicionar.
          -- neste caso e criado remanejamento para as outras operaçoes continuarem normalmente.
        
          v_idremanejamento := pk_remanejamento.cadastrar_remanejamento(c.idarmazem,
                                                                        c.idarmazem,
                                                                        c.idlocalestoque,
                                                                        c.idlocalpicking,
                                                                        p_idusuario,
                                                                        nvl(v_idonda,
                                                                             p_idonda),
                                                                        'REABASTECIMENTO PARA ONDA: ' ||
                                                                         nvl(v_idonda,
                                                                             p_idonda),
                                                                        'N',
                                                                        'S');
        
          --ALTERA OS REMANEJAMENTOS CRIADOS PELAS MOVIMENTACÕES QUE GERARAM ESSE ADICIONAR
          --INSERINDO COMO REMANEJAMENTO PAI A VARIAVEL v_idremanejamento
          if c.idmovimentacoes is not null then
            pk_triggers_control.disableTrigger('T_BEFORE_REMANEJAMENTO');
          
            execute immediate 'update remanejamento r ' ||
                              '   set r.idremanejamentopai = ' ||
                              v_idremanejamento ||
                              ' where r.idmovimentacao in (' ||
                              c.idmovimentacoes || ')';
          
            pk_triggers_control.enableTrigger('T_BEFORE_REMANEJAMENTO');
          end if;
        
          select r.descr, lo.rua
            into v_regiaoorigem, v_ruaorigem
            from regiaoarmazenagem r, local lo
           where lo.idregiao = r.idregiao
             and lo.idlocal = c.idlocalestoque
             and lo.idarmazem = c.idarmazem;
        
          select r.descr, ld.rua
            into v_regiaodestino, v_ruadestino
            from regiaoarmazenagem r, local ld
           where ld.idregiao = r.idregiao
             and ld.idlocal = c.idlocalpicking
             and ld.idarmazem = c.idarmazem;
        
          pk_convocacao.insereRemanejamento(p_idusuario, v_idremanejamento,
                                            'Remanejar id ' ||
                                             v_idremanejamento || ' - ' ||
                                             v_regiaoorigem || ' - RUA ' ||
                                             v_ruaorigem || ' PARA ' ||
                                             v_regiaodestino || ' RUA ' ||
                                             v_ruadestino, c.idlocalestoque,
                                            c.idarmazem);
          begin
            insert into loteremanejamento
              (idremanejamento, idlote, qtde, conferido, idromaneio)
            values
              (v_idremanejamento, c.idlote, c.qtdereabastecer, 'N',
               nvl(v_idonda, p_idonda));
          exception
            when dup_val_on_index then
              update loteremanejamento
                 set qtde = qtde + c.qtde
               where idremanejamento = v_idremanejamento
                 and idlote = c.idlote;
          end;
        
          pk_estoque.retirar_adicionar(c.idarmazem, c.idlocalpicking,
                                       c.idlote, c.qtde, p_idusuario,
                                       c.complementar);
      end;
    end loop;
  
  end;

  --Apaga Convocação Ativa Packing.
  procedure apagarConvocacaoPacking
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    v_identificador  varchar2(200);
    v_qtde_atividade number;
  begin
  
    for c_nf_tarefa in (select m.idnotafiscal identificador,
                               lpad(m.idonda, 10, '0') ||
                                lpad(m.identificador, 4, '0') codbarratarefa
                          from nfromaneio nfr, movimentacao m
                         where nfr.idromaneio = m.idonda
                           and nfr.idnotafiscal = m.idnotafiscal
                           and nfr.idromaneio = p_idonda
                           and nfr.idnotafiscal =
                               nvl(p_idnotafiscal, nfr.idnotafiscal)
                         group by m.idnotafiscal,
                                  lpad(m.idonda, 10, '0') ||
                                   lpad(m.identificador, 4, '0'))
    loop
      v_identificador := c_nf_tarefa.identificador;
    
      if pk_packing.isConferenciaPorTarefa(c_nf_tarefa.identificador) then
        v_identificador := c_nf_tarefa.codbarratarefa;
      end if;
    
      select count(1)
        into v_qtde_atividade
        from atividade a
       where a.idoperacao = v_identificador;
    
      if v_qtde_atividade = 0 then
        select count(1)
          into v_qtde_atividade
          from atividade a
         where a.idoperacao = to_number(v_identificador);
      
        v_identificador := to_number(v_identificador);
      end if;
    
      if v_qtde_atividade > 0 then
        pk_convocacao.apagaPackingColetor(p_idusuario, v_identificador);
      end if;
    end loop;
  
  end;

  /*
  *  Rotina responsavel pelo cancelamento da onda
  */
  procedure cancelarOnda
  (
    p_idonda    in number,
    p_idusuario in number,
    p_origem    in number
  ) is
    type t_lista is table of number;
  
    v_statusOnda             number;
    v_movNaoCancelada        number;
    v_listanf                t_lista;
    v_msg                    t_message;
    v_idpedidopaiConfPesagem number;
  
    procedure liberarCaixaEmUsoTerceiro is
    begin
      pk_triggers_control.disableTrigger('T_BEFORE_TIPOCAIXAVOLUME');
      update tipocaixavolume tv
         set tv.emusosistematerceiro = 0,
             tv.idonda               = null,
             tv.disponivel           = 1
       where nvl(tv.idonda, 0) = p_idonda;
      pk_triggers_control.enableTrigger('T_BEFORE_TIPOCAIXAVOLUME');
    end liberarCaixaEmUsoTerceiro;
  
  begin
    -- Realizando lock da onda em cancelamento para não ocorrer concorrência
    select o.statusonda
      into v_statusOnda
      from romaneiopai o
     where o.idromaneio = p_idonda
       for update;
  
    pk_utilities.GeraLog(p_idusuario,
                         'INICIOU O CANCELAMENTO DA ONDA ID: ' || p_idonda,
                         p_idonda, 'CO');
  
    validarOndaParaCancelamento(p_idonda, p_origem);
    validarNotasParaCancelarOnda(p_idonda);
  
    -- Armazena dados para exibição nos dados das ondas canceladas
    insert into histromaneiopai
      (idromaneio, pedido, notafiscal, depositante, transportadora,
       destinatario, coleta)
      select rp.idromaneio, nf.numpedidofornecedor pedido,
             nf.codigointerno notafiscal, dep.razaosocial depositante,
             transp.razaosocial transportadora,
             dest.razaosocial destinatario, stragg(cr.carga) coleta
        from romaneiopai rp, nfromaneio nfr, notafiscal nf, entidade dep,
             entidade dest, entidade transp, cargaromaneio cr
       where rp.idromaneio = p_idonda
         and nfr.idromaneio = rp.idromaneio
         and nf.idnotafiscal = nfr.idnotafiscal
         and dep.identidade = nf.iddepositante
         and dest.identidade = nf.destinatario
         and transp.identidade = nf.transportadoranotafiscal
         and cr.idromaneio(+) = nfr.idromaneio
         and cr.idnotafiscal(+) = nfr.idnotafiscal
       group by rp.idromaneio, nf.numpedidofornecedor, nf.codigointerno,
                dep.razaosocial, transp.razaosocial, dest.razaosocial;
  
    -- Limpando Gtt para iniciar seu preenchimento na rotina de cancelar nota fiscal
    -- Não colocado o delete dentro da rotina devido a chamar várias vezes alimentando
    -- Obs: chamada também no retirarNotaFiscal
    delete from gtt_retirar_adicionar_onda;
    v_idpedidopaiConfPesagem := 0;
    for c in (select nfr.idnotafiscal, nvl(nf.idpedidopai, 0) idpedidopai,
                     nvl(conf.conferenciapesagem, 0) conferenciapesagem
                from nfromaneio nfr, notafiscal nf, romaneiopai rp,
                     configuracaoonda conf
               where nfr.idromaneio = p_idonda
                 and nf.idnotafiscal = nfr.idnotafiscal
                 and rp.idromaneio = nfr.idromaneio
                 and conf.idconfiguracaoonda = rp.idconfiguracaoonda)
    loop
      --Apaga Convocação Ativa Packing
      apagarConvocacaoPacking(p_idonda, c.idnotafiscal, p_idusuario);
    
      cancelarNotaFiscal(p_idonda, c.idnotafiscal, p_idusuario);
    
      if (v_idpedidopaiConfPesagem = 0 and c.idpedidopai > 0 and
         c.conferenciapesagem = 1) then
        v_idpedidopaiConfPesagem := c.idpedidopai;
      end if;
    
    end loop;
  
    if (v_idpedidopaiConfPesagem > 0) then
      pk_carga.excluirCargaConfPesagemPai(v_idpedidopaiConfPesagem);
    end if;
  
    retirarAdicionarDoPicking(p_idonda, p_idusuario);
  
    select r.statusonda
      into v_statusOnda
      from romaneiopai r
     where r.idromaneio = p_idonda;
  
    -- se o status da onda for EM_FORMACAO(0)  significa que o cancelamento esta sendo
    -- chamado pela formacao da onda e ela possui corte. Neste caso as notas fiscais não devem
    -- ser retiradas da onda, somente o estoque deve ser retirado a reserva.
    if (v_statusOnda = 0) then
      update romaneiopai r
         set r.statusonda = 6
       where r.idromaneio = p_idonda;
    else
      insert into nfretirada
        (idromaneio, idnotafiscal)
        select idromaneio, idnotafiscal
          from nfromaneio
         where idromaneio = p_idonda;
    
      for c_nfonda in (select nf.idprenf
                         from nfromaneio nfr, notafiscal nf
                        where nf.idnotafiscal = nfr.idnotafiscal
                          and nfr.idromaneio = p_idonda)
      loop
        update nfimpressao nfi
           set nfi.statusdoc = 12
         where nfi.idprenf = c_nfonda.idprenf;
      end loop;
    
      select nfr.idnotafiscal
        BULK COLLECT
        INTO v_listanf
        from nfromaneio nfr
       where nfr.idromaneio = p_idonda;
    
      delete from nfromaneio nfr
       where nfr.idromaneio = p_idonda;
    
      for i in 1 .. v_listanf.count
      loop
        update notafiscal n
           set n.statusnf           = decode(n.digitada, 'S', 'N', 'I'),
               n.statusroteirizacao = 0,
               n.lido               = 0
         where n.idnotafiscal = v_listanf(i);
      
      end loop;
    
      delete from saidapornf s
       where s.idonda = p_idonda;
    
      if (pk_onda.isOndaCheckoutExpress(p_idonda)) then
        pk_packing.gravarHistCaixaSeparacaoCancel(null, p_idonda,
                                                  C_ORIGEM_CANCELAR_ONDA);
      end if;
    
      update romaneiopai r
         set r.statusonda            = 5,
             r.pesoteorico           = 0,
             r.qtdematerial          = 0,
             r.qtdetotalmaterial     = 0,
             r.datacancelamento      = sysdate,
             r.idusuariocancelamento = p_idusuario
       where r.idromaneio = p_idonda;
    
      pk_convocacao.apagarConvocacaoOnda(p_idusuario, p_idonda);
    
      for c in (select distinct o.idnotafiscal
                  from movimentacao o
                 where o.idonda = p_idonda)
      loop
        regraSubPedido(p_idonda, c.idnotafiscal, p_idusuario);
      end loop;
    end if;
  
    select count(*)
      into v_movNaoCancelada
      from movimentacao m
     where m.idonda = p_idonda
       and m.status <> 3;
  
    if (v_movNaoCancelada > 0) then
      v_msg := t_message('Ocorreu uma falha no cancelamento da onda. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    liberarCaixaEmUsoTerceiro;
  
    pk_utilities.GeraLog(p_idusuario,
                         'FINALIZOU O CANCELAMENTO DA ONDA ID: ' ||
                          p_idonda, p_idonda, 'CO');
  end;

  procedure redefinirIdentificadores(p_idonda in number) is
    v_identificador number;
  begin
    -- cria um novos identificadores para as novas movimentacoes
    select nvl(max(m.identificador), 0)
      into v_identificador
      from movimentacao m
     where m.idonda = p_idonda;
  
    if (v_identificador > 0) then
      for c in (select distinct ro.idregiao origem, ro.tipo tipoorigem,
                                lo.buffer bufferorigem, rd.idregiao destino,
                                rd.tipo tipodestino, ld.buffer bufferdestino
                  from movimentacao m, local lo, local ld,
                       regiaoarmazenagem ro, regiaoarmazenagem rd
                 where m.idonda = p_idonda
                   and m.status = 0
                   and m.identificador = 0
                   and lo.id = m.idlocalorigem
                   and ld.id = m.idlocaldestino
                   and ro.idregiao = lo.idregiao
                   and ro.tipo <> 2
                   and rd.idregiao = ld.idregiao
                   and rd.tipo in (0, 2))
      loop
        -- movimentacoes com destino buffer de picking o identificador e por produto.
        if (c.tipodestino = 0 and c.bufferdestino = 'S') then
          for x in (select distinct lt.idproduto
                      from movimentacao m, local lo, local ld, lote lt
                     where m.idonda = p_idonda
                       and m.status = 0
                       and m.identificador = 0
                       and lo.id = m.idlocalorigem
                       and lo.buffer = c.bufferorigem
                       and lo.idregiao = c.origem
                       and ld.id = m.idlocaldestino
                       and ld.buffer = c.bufferdestino
                       and ld.idregiao = c.destino
                       and lt.idlote = m.idlote)
          loop
            v_identificador := v_identificador + 1;
          
            update movimentacao
               set identificador = v_identificador
             where id in (select m1.id
                            from movimentacao m1, local lo, local ld, lote lt
                           where m1.idonda = p_idonda
                             and m1.status = 0
                             and m1.identificador = 0
                             and lo.id = m1.idlocalorigem
                             and lo.buffer = c.bufferorigem
                             and lo.idregiao = c.origem
                             and ld.id = m1.idlocaldestino
                             and ld.buffer = c.bufferdestino
                             and ld.idregiao = c.destino
                             and lt.idlote = m1.idlote
                             and lt.idproduto = x.idproduto);
          end loop;
          -- para os demais casos o dientificador e por regiao
        else
          v_identificador := v_identificador + 1;
        
          update movimentacao
             set identificador = v_identificador
           where id in (select m1.id
                          from movimentacao m1, local lo, local ld
                         where m1.idonda = p_idonda
                           and m1.status = 0
                           and m1.identificador = 0
                           and lo.id = m1.idlocalorigem
                           and lo.buffer = c.bufferorigem
                           and lo.idregiao = c.origem
                           and ld.id = m1.idlocaldestino
                           and ld.buffer = c.bufferdestino
                           and ld.idregiao = c.destino);
        end if;
      
      end loop;
    end if;
  end;

  procedure verificarSeDeveCancelarOnda(p_idonda in number) is
    v_qtdenfs number;
  begin
    select count(*)
      into v_qtdenfs
      from nfromaneio nfr
     where nfr.idromaneio = p_idonda;
  
    if (v_qtdenfs = 0) then
      update romaneiopai r
         set r.statusonda        = 5,
             r.pesoteorico       = 0,
             r.qtdematerial      = 0,
             r.qtdetotalmaterial = 0
       where r.idromaneio = p_idonda;
    
      pk_convocacao.apagarConvocacaoOnda(0, p_idonda);
    
    end if;
  end;

  /*
  *  Verifica se todas as notas restantes da onda estao processada e processa a onda caso afirmativo.
  */
  procedure verificarSeDeveProcessarOnda(p_idonda in number) is
    v_qtdenfsemprocessar number;
    v_qtdenfs            number;
  begin
    select nvl(count(n.statusnf), 0)
      into v_qtdenfsemprocessar
      from nfromaneio nfr, notafiscal n
     where nfr.idromaneio = p_idonda
       and n.idnotafiscal = nfr.idnotafiscal
       and n.statusnf <> 'P';
  
    select count(*)
      into v_qtdenfs
      from nfromaneio nfr
     where nfr.idromaneio = p_idonda;
  
    if (v_qtdenfsemprocessar = 0 and v_qtdenfs > 0) then
      update romaneiopai r
         set r.statusonda = 3
       where r.idromaneio = p_idonda;
    end if;
  end verificarSeDeveProcessarOnda;

  /*
  *  verifica se as notas restantes na onda estao separadas, conferidas e pesadas 
  *  entao atualiza os respectivos status da onda
  */
  procedure atualizaSepConfPesDaOnda
  (
    p_idonda    in number,
    p_idusuario in number
  ) is
    v_separado  number;
    v_conferido number;
    v_pesado    number;
  begin
    begin
      select sum(decode(s.separado, 1, 0, 1)) separado,
             sum(decode(s.conferido, 1, 0, 1)) conferido,
             sum(decode(s.pesado, 1, 0, 1)) pesado
        into v_separado, v_conferido, v_pesado
        from saidapornf s
       where s.idonda = p_idonda;
    exception
      when no_data_found then
        v_separado  := 1;
        v_conferido := 1;
        v_pesado    := 1;
    end;
  
    if (v_separado = 0) then
      update romaneiopai r
         set r.separado           = 'S',
             r.datafinalseparacao = sysdate,
             r.idusuarioseparacao = p_idusuario
       where r.idromaneio = p_idonda;
    end if;
  
    if (v_conferido = 0) then
      update romaneiopai r
         set r.liberado             = 'S',
             r.dataliberacao        = sysdate,
             r.idusuarioconferencia = p_idusuario
       where r.idromaneio = p_idonda;
    end if;
  
    if (v_pesado = 0) then
      update romaneiopai r
         set r.pesagemliberada     = 'S',
             r.dtpesagemliberada   = sysdate,
             r.idusuariolibpesagem = p_idusuario
       where r.idromaneio = p_idonda;
    end if;
  end atualizaSepConfPesDaOnda;

  /*
  *  Calcula informacoes das notas para atualizar a tabela romaneiopai (onda)
  */
  procedure calcularTitulosPesoNF
  (
    p_idonda       in number,
    p_idnotafiscal in number
  ) is
    v_totalExemplares number;
    v_totalTitulos    number;
    v_pesoExemplares  number;
  begin
    select sum((nvl(e.pesobruto, 0) * n.qtdeatendida / 1000)) pesoexemplares,
           sum((n.qtdeatendida * e.fatorconversao)) totalexemplares,
           count(distinct n.idproduto) totaltitulos
      into v_pesoExemplares, v_totalExemplares, v_totalTitulos
      from nfromaneio nfr, nfdet n, embalagem e
     where nfr.idromaneio = p_idonda
       and nfr.idnotafiscal = n.nf
       and n.nf <> p_idnotafiscal
       and e.barra = n.barra
       and e.idproduto = n.idproduto;
  
    update romaneiopai r
       set r.pesoteorico       = v_pesoExemplares,
           r.qtdetotalmaterial = v_totalExemplares,
           r.qtdematerial      = v_totalTitulos
     where r.idromaneio = p_idonda;
  end;

  procedure retirarNotaFiscal
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    v_idconfiguracaoonda     number;
    v_nfvenda                number;
    v_isNfReinseridaRomaneio number;
    v_notafiscal             notafiscal%rowtype;
    v_msg                    t_message;
    v_NFRetArmazenagem       number;
  begin
    validarOndaParaCancelamento(p_idonda, C_ORIGEM_RETIRAR_NOTA);
  
    select count(*)
      into v_NFRetArmazenagem
      from retornosimbolico rs, notafiscal nf, nfimpressao nfi, operacao op,
           depositante d, regime re
     where nf.idnotafiscal = rs.idnotafiscalretorno
       and nfi.idprenf = nf.idprenf
       and (nfi.situacaonfe not in (6, 10) and
           not (exists (select 1
                           from nfe nfe
                          where nfe.idnotafiscal = rs.idnotafiscalretorno
                            and nfe.situacao = 4) and not exists
             (select 1
                    from nfe nfe
                   where nfe.idnotafiscal = rs.idnotafiscalretorno
                     and nfe.situacao not in (4, 5))))
       and op.idoperacao = nf.idoperacao
       and d.identidade = nf.iddepositante
       and re.idregime = d.idregime
       and re.classificacao = 'A'
       and re.contribuinteicms = 'S'
       and op.tipooper = 'TA'
       and rs.idnotafiscalretorno = p_idnotafiscal;
  
    if (v_NFRetArmazenagem > 0) then
      v_msg := t_message('Esta nota fiscal de retorno já está faturada e deve ser cancelada pela tela de controle de NF-e. idnotafiscal: {0}.');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select *
      into v_notafiscal
      from notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal
       for update;
  
    -- primeiro e avaliado as mosvimentacoes de composicao de nota fiscal, alimentando a GTT_MOVIMENTACAO_COMPOSICAO
    insert into gtt_movimentacao_composicao
      (idmovimentacao, idcomposicao)
      select m.id, m.idcomposicao
        from movimentacao m
       where m.idonda = p_idonda
         and m.idnotafiscal = p_idnotafiscal
         and m.status in (0, 1)
         and m.idcomposicao is not null
         and m.etapa = 1;
  
    -- Limpando Gtt para iniciar seu preenchimento na rotina de cancelar nota fiscal
    -- Não colocado o delete dentro da rotina devido a chamar várias vezes alimentando
    -- Obs: chamada também na rotina cancelarOnda
    delete from gtt_retirar_adicionar_onda;
  
    begin
      select rs.idnotafiscalvenda
        into v_nfvenda
        from retornosimbolico rs
       where rs.idnotafiscalretorno = p_idnotafiscal;
    exception
      when no_data_found then
        v_nfvenda := 0;
    end;
  
    cancelarNotaFiscal(p_idonda, p_idnotafiscal, p_idusuario);
  
    if (v_nfvenda > 0) then
      select count(1)
        into v_isNfReinseridaRomaneio
        from nfromaneio nfr
       where nfr.idromaneio = p_idonda
         and nfr.idnotafiscal = v_nfvenda;
    
      if (v_isNfReinseridaRomaneio > 0) then
        pk_onda_cancelar.removerNotaFiscalOnda(p_idonda, v_nfvenda,
                                               p_idusuario);
      end if;
    end if;
  
    retirarAdicionarDoPicking(p_idonda, p_idusuario);
  
    -- percorre as movimentacoes que possuem composicao e estoque no pulmao.
    -- a movimentacao e o estoque das demais notas fiscais que pertencem a composicao sao cancelados 
    -- e depois regerados passando pelo picking
    for c in (select idmovimentacao, idcomposicao
                from gtt_movimentacao_composicao)
    loop
      for x in (select lo.idarmazem, lo.idlocal, m.idlote, m.qtdemovimentada,
                       m.idnotafiscal
                  from movimentacao m, local lo
                 where m.idcomposicao = c.idcomposicao
                   and m.etapa = 1
                   and m.status in (0, 1)
                   and lo.id = m.idlocalorigem)
      loop
        -- recalculando os status de totalseparar, totalconferir e totalpesar 
        -- para as notas fiscais que permanecem na onda
        if x.idnotafiscal <> p_idnotafiscal then
          update saidapornf s
             set s.totalseparar           = s.totalseparar -
                                            x.qtdemovimentada,
                 s.totalconferir          = s.totalconferir -
                                            x.qtdemovimentada,
                 s.totalpesar             = s.totalpesar - x.qtdemovimentada,
                 s.atualizacaopesocancvol = 1
           where s.idnotafiscal = x.idnotafiscal
             and s.idonda = p_idonda;
        end if;
      
        Pk_Estoque.retirar_pendencia(x.idarmazem, x.idlocal, x.idlote,
                                     x.qtdemovimentada, p_idusuario,
                                     'NOTA FISCAL CANCELADA, REMOVIDO PENDENCIA PARA NOTAFISCAL ID:' ||
                                      p_idnotafiscal || ', ONDA:' ||
                                      p_idonda);
      
      end loop;
    
      pk_onda.gerarListaProdutoOndaPorMov(c.idmovimentacao);
      pk_onda.geradorMovPulBufPickingColmeia(p_idonda, p_idusuario);
    
      update movimentacao m
         set m.status = 3
       where m.idcomposicao = c.idcomposicao
         and m.status <> 3;
    end loop;
  
    redefinirIdentificadores(p_idonda);
  
    insert into nfretirada
      (idromaneio, idnotafiscal)
    values
      (p_idonda, p_idnotafiscal);
  
    update nfimpressao nfi
       set nfi.statusdoc = 12
     where nfi.idprenf in
           (select nf.idprenf
              from notafiscal nf
             where nf.idnotafiscal = p_idnotafiscal);
  
    delete from nfromaneio nfr
     where nfr.idromaneio = p_idonda
       and nfr.idnotafiscal = p_idnotafiscal;
  
    delete from saidapornf s
     where s.idonda = p_idonda
       and s.idnotafiscal = p_idnotafiscal;
  
    if (pk_onda.isOndaCheckoutExpress(p_idonda)) then
      pk_packing.gravarHistCaixaSeparacaoCancel(p_idnotafiscal, p_idonda,
                                                C_ORIGEM_RETIRAR_NOTA);
    end if;
  
    calcularTitulosPesoNF(p_idonda, p_idnotafiscal);
    atualizaSepConfPesDaOnda(p_idonda, p_idusuario);
    verificarSeDeveCancelarOnda(p_idonda);
    verificarSeDeveProcessarOnda(p_idonda);
  
    begin
      select r.idconfiguracaoonda
        into v_idconfiguracaoonda
        from romaneiopai r
       where r.idromaneio = p_idonda
         and r.tipo = 1;
    exception
      when no_data_found then
        v_msg := t_message('Onda não encontrada para o id {0}');
        v_msg.addParam(p_idonda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    pk_romaneio.preencherInfSeparacao(p_idonda, v_idconfiguracaoonda);
    pk_convocacao.finalizaSeparacaoOnda(p_idusuario, p_idonda);
  end;

  /*
  *  Rotina responsavel por remover uma nota fiscal da onda
  */
  procedure removerNotaFiscalOnda
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    v_movNaoCancelada number;
    v_identificador   varchar2(200);
    v_qtde_atividade  number;
    v_msg             t_message;
  begin
    --Apaga Convocação Ativa Packing    
    apagarConvocacaoPacking(p_idonda, p_idnotafiscal, p_idusuario);
  
    -- Realizando lock da onda com retirada de nf para não ocorrer concorrência
    -- foi utilizado parametro já existente somente para o lock
    select o.statusonda
      into v_movNaoCancelada
      from romaneiopai o
     where o.idromaneio = p_idonda
       for update;
  
    retirarNotaFiscal(p_idonda, p_idnotafiscal, p_idusuario);
    regraSubPedido(p_idonda, p_idnotafiscal, p_idusuario);
  
    select count(*)
      into v_movNaoCancelada
      from movimentacao m
     where m.idonda = p_idonda
       and m.idnotafiscal = p_idnotafiscal
       and m.status <> 3;
  
    if (v_movNaoCancelada > 0) then
      v_msg := t_message('Ocorreu uma falha no cancelamento da onda. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  procedure cancelarMultiplasOndas(p_idusuario in number) is
    v_configuracaoOnda configuracaoonda%Rowtype;
    v_msg              t_message;
    v_msgDescr         t_message;
  begin
    for c_onda in (select g.idselecionado
                     from gtt_selecao g)
    loop
      savepoint onda;
      begin
        --Apaga Convocação Ativa Packing
        apagarConvocacaoPacking(c_onda.idselecionado, null, p_idusuario);
      
        select co.*
          into v_configuracaoOnda
          from configuracaoonda co, romaneiopai rp
         where co.idconfiguracaoonda = rp.idconfiguracaoonda
           and rp.idromaneio = c_onda.idselecionado;
      
        if (v_configuracaoOnda.Tipoonda = C_TIPOONDA_CARGA) then
          pk_ondacarga_cancelar.cancelarOnda(c_onda.idselecionado,
                                             p_idusuario,
                                             C_ORIGEM_CANCELAR_ONDA);
        else
          cancelarOnda(c_onda.idselecionado, p_idusuario,
                       C_ORIGEM_CANCELAR_ONDA);
        end if;
      
        v_msg      := t_message('Cancelamento de onda');
        v_msgDescr := t_message('Onda id: {0} cancelada com sucesso');
        v_msgDescr.addParam(c_onda.idselecionado);
        pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                       v_msgDescr.formatMessage,
                                       pk_gttresumoexecucao.TIPO_SUCESSO);
      
      exception
        when others then
          rollback to onda;
        
          v_msg      := t_message('Cancelamento de onda');
          v_msgDescr := t_message('Onda id: {0} não foi cancelada.  {1}');
          v_msgDescr.addParam(c_onda.idselecionado);
          v_msgDescr.addParam(SQLERRM);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ERRO);
        
      end;
    end loop;
  end;

  -- Retira a nota fiscal caso ela esteja vinculada a um palet de Separação.
  procedure retirarPaletSeparacaoNf(p_idnotafiscal in number) is
    v_countPaletSeparacaoNf number;
  begin
    select count(1)
      into v_countPaletSeparacaoNf
      from paletseparacaonf psnf
     where psnf.idnotafiscal = p_idnotafiscal;
  
    if (v_countPaletSeparacaoNf > 0) then
      delete from paletseparacaonf psnfd
       where psnfd.idnotafiscal = p_idnotafiscal;
    end if;
  end;
  procedure validarStatusNF
  (
    r_notafiscal    out notafiscal%rowtype,
    p_idNotafiscal  in number,
    v_idpontoalerta out number
  ) is
    v_msg t_message;
  begin
    select n.idnotafiscal, n.statusroteirizacao, n.statusnf, n.iddepositante,
           p.idpontoalerta, n.idprenf
      into r_notafiscal.idnotafiscal, r_notafiscal.statusroteirizacao,
           r_notafiscal.statusnf, r_notafiscal.iddepositante,
           v_idpontoalerta, r_notafiscal.idprenf
      from notafiscal n, depositante d, pontoalerta p
     where n.idnotafiscal = p_idnotafiscal
       and d.identidade = n.iddepositante
       and p.idnotafiscal(+) = n.idnotafiscal;
  
    if (r_notafiscal.statusroteirizacao <> 2) then
      v_msg := t_message('Status roteirizacao da nota fiscal inválido. O status deve ser EM_ROMANEIO para realizar o cancelamento. Operação não realizada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (r_notafiscal.statusnf = 'P') then
      v_msg := t_message('A nota fiscal com id {0} esta processada. Operação não realizada');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end validarStatusNF;

  procedure validarNfColetaAutomatica
  (
    p_idonda       in number,
    p_idnotafiscal in number
  ) is
    v_idcarga number;
    v_msg     t_message;
    v_nfs     varchar2(1000);
  
    C_COLETA_AUTOMATICA constant char := 'A';
  
    function getCargaVolumeColetado return number is
      v_idcarga number;
    begin
      begin
        select c.idcarga, stragg(c.idnotafiscal)
          into v_idcarga, v_nfs
          from (select distinct v.idcarga, (v.idnotafiscal)
                   from volumeromaneio v, carga c
                  where v.idromaneio = p_idonda
                    and v.idnotafiscal = p_idnotafiscal
                    and v.conferido = 'S'
                    and c.cadastro = C_COLETA_AUTOMATICA
                    and c.idcarga = v.idcarga) c
         group by c.idcarga;
      exception
        when no_data_found then
          v_idcarga := 0;
          v_nfs     := null;
      end;
    
      return v_idcarga;
    end getCargaVolumeColetado;
  
  begin
    v_idcarga := getCargaVolumeColetado;
    if (v_idcarga > 0) then
      v_msg := t_message('A(s) nota(s) fiscal(s) {0} possui(em) volume(s) ja coletado(s) na coleta {1}. ' ||
                         ' Retire o(s) volume(s) da coleta, para retirar a nf da onda.');
      v_msg.addParam(v_nfs);
      v_msg.addParam(v_idcarga);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarNfColetaAutomatica;
end;
/

