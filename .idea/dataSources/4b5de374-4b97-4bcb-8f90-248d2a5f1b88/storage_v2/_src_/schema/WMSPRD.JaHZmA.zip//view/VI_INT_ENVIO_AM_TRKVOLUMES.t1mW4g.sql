create view VI_INT_ENVIO_AM_TRKVOLUMES as
select agrupador id, numero, codigobarras, pesobruto, cubagemtotal,
       idnotafiscal, codrastreio, barravolume, altura, largura, comprimento,
       decode(pesobrutoum, 0, 'GR', 1, 'KG', 'TON') pesobrutoum, decode(cubagemtotalum, 0, 'CM3', 'M3') cubagemtotalum, 
       decode(umlineares, 0, 'CM', 1, 'M') umlineares
  from int_envio_am_trkvolumes
/

