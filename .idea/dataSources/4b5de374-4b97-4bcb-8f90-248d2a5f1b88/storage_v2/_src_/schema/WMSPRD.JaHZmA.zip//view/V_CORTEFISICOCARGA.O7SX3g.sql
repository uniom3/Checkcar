create view V_CORTEFISICOCARGA as
select c.idonda, o.codigointerno codonda, spc.palete,
       nvl(nf.numpedidofornecedor, ' ') pedido, nf.codigointerno numnf,
       nvl(nf.sequencia, ' ') serie, c.identificador idtarefa,
       c.codbarratarefa, c.idenderecofalta, lo.idlocal idlocal, c.idproduto,
       p.codigointerno codprod, initcap(p.descr) produto, c.barra,
       spc.qtde || ' ' || e.descrreduzido qtde,
       sum((spc.qtde * e.fatorconversao)) || ' UN' qtdeunit, c.idusuario,
       initcap(u.nomeusuario) nomeusuario, max(c.data) datahora,
       nvl((select l.idlocal
              from local l, regiaoarmazenagem ra, produtolocal p
             where l.buffer = 'N'
               and l.ativo = 'S'
               and l.tipo = 0
               and l.idarmazem = nf.idarmazem
               and ra.idregiao = l.idregiao
               and ra.tipo = 0
               and p.idendereco = l.id
               and p.identidade = nf.iddepositante
               and p.idproduto = c.idproduto
               and rownum = 1), 'Sem Picking') picking,
       nvl((select stragg(distinct lo.idlocal) idlocal
              from local lo, lotelocal ll, lote l
             where ll.idlote = l.idlote
               and lo.idlocal = ll.idlocal
               and ll.idarmazem = lo.idarmazem
               and lo.picking = 'N'
               and lo.tipo in (1, 2)
               and lo.idarmazem = nf.idarmazem
               and l.iddepositante = nf.iddepositante
               and l.idproduto = c.idproduto
               and ll.estoque - ll.pendencia + ll.adicionar > 0
               and rownum < 3), 'Sem Pulmão') pulmoes
  from cortefisico c, separacaoporcarga spc, local lo, regiaoarmazenagem r,
       embalagem e, produto p, romaneiopai o, nfromaneio nfr, notafiscal nf,
       usuario u
 where spc.idcortefisico = c.id
   and spc.status = 4
   and lo.id = c.idenderecofalta
   and r.idregiao = lo.idregiao
   and e.idproduto = c.idproduto
   and e.barra = c.barra
   and p.idproduto = c.idproduto
   and o.idromaneio = c.idonda
   and nfr.idromaneio = o.idromaneio
   and nf.idnotafiscal = nfr.idnotafiscal
   and u.idusuario = c.idusuario
 group by c.idonda, o.codigointerno, spc.palete, nf.numpedidofornecedor,
          nf.codigointerno, nf.sequencia, c.identificador, c.codbarratarefa,
          c.idenderecofalta, lo.idlocal, c.idproduto, p.codigointerno,
          p.descr, c.barra, spc.qtde, e.descrreduzido, c.idusuario,
          u.nomeusuario, nf.idarmazem, nf.iddepositante
/

