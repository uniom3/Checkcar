create view VI_INT_ENVIO_EFD_C190 as
select a."REG",a."CST_ICMS",a."CFOP",a."ALIQ_ICMS",a."VL_OPR",a."VL_BC_ICMS",a."VL_ICMS",a."VL_BC_ICMS_ST",a."VL_ICMS_ST",a."VL_RED_BC",a."VL_IPI",a."COD_OBS",a."IDARMAZEM",a."DATAPROCESSAMENTO",a."CODIGOINTERNO",a."IDNOTAFISCAL"
  from (select 'C190' reg, '041' cst_icms,
                pk_utilities.getCFOP(o.idcfop, nf.tipo) cfop,
                sum(nvl(nd.aliqicms, 0)) aliq_icms,
                pk_utilities.getNumeroFormatadoEFD(nf.totalgeral) vl_opr,
                sum(nvl(nd.baseicms, 0)) vl_bc_icms,
                sum(nvl(nd.valoricms, 0)) vl_icms,
                sum(nvl(nd.baseicmssubst, 0)) vl_bc_icms_st,
                sum(nvl(nd.icmsst, 0)) vl_icms_st, sum(0) vl_red_bc,
                sum(nvl(nd.ipi, 0)) vl_ipi, ' ' cod_obs, nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento,
                nf.codigointerno, nf.idnotafiscal
           from notafiscal nf, nfdet nd, depositante dp, regime re, operacao o,
                nfremarmazenagem nr
          where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
                nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
            and nd.nf = nf.idnotafiscal
            and decode(nf.statusnf, 'P', 1, 0) = 1
            and decode(nf.retornoreentrega, 'N', 1, 0) = 1
            and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
            and dp.identidade = nf.iddepositante
            and re.idregime = dp.idregime
            and decode(re.classificacao, 'A', 1, 0) = 1
            and o.idoperacao = nf.idoperacao
            and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
            and nvl(nd.total, 0) > 0
            and nr.idnfremessa(+) = nf.idnotafiscal
          group by 'C190', '041', pk_utilities.getCFOP(o.idcfop, nf.tipo), ' ',
                   pk_utilities.getNumeroFormatadoEFD(nf.totalgeral),
                   nf.idarmazem, trunc(nvl(nr.datacobertura, nf.datacadastro)),
                   nf.codigointerno, nf.idnotafiscal) a
 order by a.codigointerno asc
/

