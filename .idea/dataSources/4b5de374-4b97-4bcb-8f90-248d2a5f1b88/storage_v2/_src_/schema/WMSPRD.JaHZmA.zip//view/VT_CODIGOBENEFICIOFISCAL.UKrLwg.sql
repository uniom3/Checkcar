create view VT_CODIGOBENEFICIOFISCAL as
select cb.idcodigobeneficio, op.idcfop cfop, op.descr operacao, p.pais,
       es.uf, cb.codigodobeneficio, cb.basereduzida, cb.cst
  from codigobeneficiofiscal cb, estado es, operacao op, pais p
 where cb.idpais = es.idpais
   and cb.uf = es.uf
   and cb.idoperacao = op.idoperacao
   and es.idpais = p.idpais
   order by p.pais, es.uf, cb.codigodobeneficio
/

