create package pk_utilities is

  TYPE t_array IS TABLE OF CLOB INDEX BY BINARY_INTEGER;
  -- Author  : LEANDRO
  -- Created : 29/03/2004 11:59:35
  -- Purpose :

  /*Constantes para convers?o de unidades de medida*/
  c_unMedida_mm3 constant number := 0;
  c_unMedida_cm3 constant number := 3;
  c_unMedida_m3  constant number := 9;
  c_unMedida_mm  constant number := 0;
  c_unMedida_cm  constant number := 1;
  c_unMedida_m   constant number := 3;
  c_unMedida_g   constant number := 0;
  c_unMedida_kg  constant number := 3;
  c_unMedida_t   constant number := 6;

  type t_logintegracao is record(
    idlogintegracao number,
    idprenf         number,
    idusuario       number,
    data            date default sysdate,
    arquivo         varchar2(200),
    texto           varchar2(1000),
    tipo            char(1),
    descr           varchar2(4000),
    extencaoarq     varchar2(20),
    sqltext         varchar2(4000),
    numpedido       varchar2(20),
    numnf           varchar2(20),
    codprod         varchar2(60),
    barra           varchar2(100),
    chaveintegracao number,
    agrupador       number);

  type t_barraGs1 is record(
    barraEmbalagem embalagem.barra%type,
    loteIndustria  lote.descr%type,
    dtFabricacao   date,
    dtVencimento   date,
    quantidade     number,
    peso           number);

  procedure GeraLog
  (
    p_usuario in number,
    p_log     in varchar2,
    p_id      in number,
    p_tipolog in varchar2
  );

  procedure GeraLogAutonomous
  (
    p_usuario in number,
    p_log     in varchar2,
    p_id      in number,
    p_tipolog in varchar2
  );

  procedure GeraLogInt
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2
  );
  
  procedure getLogErrorByPedido(pLogIntegracao in out logintegracao%rowtype);

  FUNCTION F_RET_EMBALAGEM_EQUIVALENTE
  (
    P_BARRA  IN EMBALAGEM.BARRA%TYPE,
    P_BARRA2 IN EMBALAGEM.BARRA%TYPE
  ) RETURN VARCHAR2;

  function f_ret_EmbEquivPai(p_barra in embalagem.barra%type) return varchar2;

  function VOL_TOT_VEICULO(P_PLACA IN VARCHAR2) return number;

  /*
  * Rotina que retiria caracteres nao numericos de uma string
  * Esta rotina e utilizada a importacao de nota fiscal
  */
  function retNumNFCodInterno
  (
    p_codinterno in varchar2,
    p_tiporet    in string
  ) return varchar2;

  /*
   * Rotina que retorna o proprietario do sistema
  */
  /*  function pegarproprietario return number;*/

  function verifica_gerasepcriarromaneio return varchar2;

  function retornar_dif_data_extenso
  (
    P_HORAINICIO IN DATE,
    P_HORAFIM    IN DATE
  ) RETURN VARCHAR2;

  /*
   * Rotina que retorna o nro de dias que faltam para expirar a senha 
  */
  function num_dias_prox_senha return date;

  /*
   * Carrega as informacoes de configura??o do sistema
  */
  function CarregarConfiguracao return configuracao%rowtype;

  /*
   * Essa fun??o retorna o menor de dois valores
   * ? utilizada na libera??o de notas fiscais para 
   * checar as quantidades cobertas fiscalmente
  */
  function retorna_valormenor
  (
    p_valor1 in number,
    p_valor2 in number
  ) return number;

  /*
   * Esta rotina tem como objetivo remanejar um lote para o endere?o espec?ficado
  */
  procedure RemanejarLote
  (
    p_lote           in number,
    p_armazemdestino in number,
    p_localdestino   in local.idlocal%type,
    p_usuario        number
  );

  function SoNumero(P_Texto in varchar2) return varchar2;

  function retornaCidadeProprietario return varchar2;

  function split
  (
    p_string      varchar2,
    p_index       number,
    p_delimitador varchar2 := ','
  ) return varchar2;

  function formatarTempo(p_tempoEmSegundos in number) return varchar2;

  function gravarLogIntegracao(p_log in t_logintegracao) return number;

  function GerarLogIntegracao
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2,
    p_agrupador   in number := null
  ) return number;

  function GerarLogIntegracaoAut
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2,
    p_agrupador   in number := null
  ) return number;

  function F_TEMPO_ENTRE
  (
    P_DATA_FIM    IN DATE,
    P_DATA_INICIO IN DATE
  ) return varchar;

  function distanciaLocal
  (
    p_prioridade      in number,
    p_bloco           in local.bloco%type,
    p_rua             in local.rua%type,
    p_predio          in number,
    p_andar           in number,
    p_apartamento     in number,
    p_prioridadeAlvo  in number,
    p_blocoAlvo       in local.bloco%type,
    p_ruaAlvo         in local.rua%type,
    p_predioAlvo      in number,
    p_andarAlvo       in number,
    p_apartamentoAlvo in number
  ) return number;

  function retornarTempo(p_tempoEmSegundos in number) return varchar2;

  -- retorna da data ap?s a qtde de dias uteis informado.
  function retornarDataUtil
  (
    p_data      date,
    p_diasuteis number
  ) return date;

  function formatarEndereco
  (
    p_completo    in varchar2,
    p_logradouro  in varchar2,
    p_numero      in varchar2,
    p_complemento in varchar2
  ) return varchar2;

  function formatarEndrecoComplemento
  (
    p_bairrodescr  in varchar2,
    p_cidadedescr  in varchar2,
    p_estadocidade in varchar2
  ) return varchar2;

  function f_RetEmbalagensMov
  (
    p_idproduto in number,
    p_qtdeunit  in number,
    p_tipo      in number
  ) return number;

  function isPrimeiroAndar
  (
    p_idarmazem in local.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return number;

  procedure gerarLogTransfere
  (
    p_idusuario  in number,
    p_tela       in varchar2,
    p_tabela     in varchar2,
    p_primarykey in varchar2,
    p_campo      in varchar2,
    p_tipo       in number
  );

  function isNumber(p_texto in varchar2) return boolean;

  function masc_minuto_hora(p_minutos number) return varchar2;

  function minuto_hora(p_minutos Pls_Integer) return number;

  function getCodigoFederecaoEstado(p_uf in varchar2) return number;

  function split_array(p_valor in CLOB) return t_array;

  function removeAcentosCaractereEspecial(p_valor in varchar2)
    return varchar2;

  function isPossuiCaratereMinusculo(p_texto in varchar2) return boolean;

  function isPossuiCaratereMaiusculo(p_texto in varchar2) return boolean;

  function isPossuiNumero(p_texto in varchar2) return boolean;

  function isPossuiCaratereEspecial(p_texto in varchar2) return boolean;

  function getCFOP
  (
    p_cfop   in varchar2,
    p_tiponf in varchar2
  ) return varchar2;

  function getNumeroFormatadoEFD(p_valor in number) return varchar2;

  function extrairBarraGS1128(p_codBarra in varchar2)
    return pk_utilities.t_barraGs1;

  procedure GeraLogClob
  (
    p_usuario in number,
    p_id      in number,
    p_tipolog in varchar2,
    p_clob    clob,
    p_tamanho number
  );

  function getXMLDecode(p_texto in varchar2) return varchar2;

  function getXMLEncode(p_texto in varchar2) return varchar2;

  procedure gerarLogTempoExecucao
  (
    p_descricao      varchar2,
    p_dataInicioExec date,
    p_dataFimExec    date,
    p_identificacao  number default null
  );

  function getConversao
  (
    p_valor           in number,
    p_unMedidaOrigem  in number,
    p_unMedidaDestino in number
  ) return number;

  function replaceEspacos(p_texto varchar) return varchar2;

  function removerAcentuacao(p_texto in varchar2) return varchar2;

  procedure validarLeituraPadraoCode128
  (
    p_idProcesso    in number,
    p_idDepositante in number,
    p_tipoProcesso  in number
  );

  function extrairCODE128_entBarraColetor
  (
    p_barra         in varchar2,
    p_idDepositante in depositante.identidade%type,
    p_field         in number := null,
    p_codigoProduto in out number,
    p_barraProduto  in out varchar2,
    p_barraCaixa    in out varchar2,
    p_Quantidade    in out number,
    p_LoteIndustria in out varchar2,
    p_LoteAdicional in out varchar2,
    p_Vencimento    in out date,
    p_Fabricacao    in out date,
    p_Peso          in out number,
    p_PesoLiquido   in out number,
    p_tipo          in number
  ) return number;

  function extrairCODE128
  (
    p_barra         in varchar2,
    p_idDepositante in depositante.identidade%type,
    p_field         in number := null,
    p_codigoProduto in out number,
    p_barraProduto  in out varchar2,
    p_barraCaixa    in out varchar2,
    p_Quantidade    in out number,
    p_LoteIndustria in out varchar2,
    p_LoteAdicional in out varchar2,
    p_Vencimento    in out date,
    p_Fabricacao    in out date,
    p_Peso          in out number,
    p_PesoLiquido   in out number
  ) return number;

  function composicaoidentificacaoEnd
  (
    p_armazem          in number,
    p_idlocal          in varchar2,
    p_configuracaoonda in number
  ) return varchar2;

  procedure validarEscalaPesagem
  (
    p_idescala    in number,
    p_pesoinicial in number,
    p_pesofinal   in number,
    p_tipo        in char
  );

  function calcularQtdeCaixas
  (
    p_quantidade    in number,
    p_caixas        in number,
    p_qtdePorCaixas in number
  ) return varchar2;

end pk_utilities;
/

