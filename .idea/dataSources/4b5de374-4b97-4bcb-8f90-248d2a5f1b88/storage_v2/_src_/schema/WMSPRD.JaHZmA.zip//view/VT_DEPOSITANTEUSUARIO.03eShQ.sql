create view VT_DEPOSITANTEUSUARIO as
select u.idusuario, u.nomeusuario, u.nomeusuariocompleto
  from usuario u
 where u.ativo = 'S'
/

