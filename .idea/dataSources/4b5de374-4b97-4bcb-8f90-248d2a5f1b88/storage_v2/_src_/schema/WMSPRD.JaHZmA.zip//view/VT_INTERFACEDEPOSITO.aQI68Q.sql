create view VT_INTERFACEDEPOSITO as
select i.idinterface, i.chamada tela
  from interface i
 where i.modulo = 'A'
/

