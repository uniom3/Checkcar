create view V_LIVROFISCALSAIDA as
select d.razaosocial depositante,
       decode(d.pessoa, 'J', d.cgc, d.cic) cnpjdepositante, l.idlivrofiscal,
       l.dtsaida datasaida, l.especie, l.serie, l.numero, l.dtdocumento,
       l.uf, to_char(l.valorcontabil, '999g999g999g990d00') valorcontabil,
       l.contabil, l.fiscal cfop,
       to_char(l.basecalculoicms, '999g999g999g990d00') bcicms,
       to_char(l.basecalculoipi, '999g999g999g990d00') bcipi,
       l.aliquotaicms aliqicms, l.aliquotaipi aliqipi,
       to_char(l.impostoicms, '999g999g999g990d00') icms,
       to_char(l.impostoipi, '999g999g999g990d00') ipi,
       to_char(l.isentoicms, '999g999g999g990d00') isentoicms,
       to_char(l.isentoipi, '999g999g999g990d00') isentoipi,
       to_char(l.outrasicms, '999g999g999g990d00') outrasicms,
       to_char(l.outrasipi, '999g999g999g990d00') outrasipi,
       l.observacoes obs, l.cnpjemitente, l.codigoemitente codemitente,
       l.razaosocial, l.inscrestadual, l.cnpjdestinatario,
       l.codigodestinatario coddestinatario, l.razaosocialdestinatario,
       l.inscrestadualdestinatario iedestinatario, l.idnotafiscal,
       l.iditemlivrofiscalsaida id
  from itemlivrofiscalsaida l, notafiscal nf, entidade d
 where l.idnotafiscal = nf.idnotafiscal
   and nf.iddepositante = d.identidade
/

