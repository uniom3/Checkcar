create view VI_INT_ENVIO_EFD_C113 as
select 'C113' reg, decode(nf.tipo, 'E', 0, 1) ind_oper, 1 ind_emit,
       emit.codigointerno cod_part, '55' cod_mod,
       v.ide_NFref_refNF_serie ser, ' ' sub, v.ide_NFref_refNF_nNF num_doc,
       to_char(nf.dataemissao, 'ddmmyyyy') dt_doc, nf.idarmazem,
       max(trunc(nf.dataprocessamento)) dataprocessamento
  from vr_xmlnfenfref v, notafiscal nf, entidade emit, depositante dp,
       regime re, operacao o
 where nf.idprenf(+) = v.h$idprenf
   and emit.identidade = nf.remetente
   and o.idoperacao = nf.idoperacao
   and nf.dataemissao is not null
   and nf.statusnf = 'P'
   and nf.retornoreentrega = 'N'
   and nvl(re.contribuinteicms, 'S') = 'S'
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and re.classificacao = 'A'
   and o.idoperacao = nf.idoperacao
 group by 'C113', decode(nf.tipo, 'E', 0, 1), 1, emit.codigointerno, '55',
          v.ide_NFref_refNF_serie, '', v.ide_NFref_refNF_nNF,
          to_char(nf.dataemissao, 'ddmmyyyy'), nf.idarmazem
 order by v.ide_NFref_refNF_nNF
/

