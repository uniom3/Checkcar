create package body pk_utilities is

  procedure GeraLog
  (
    p_usuario in number,
    p_log     in varchar2,
    p_id      in number,
    p_tipolog in varchar2
  ) is
  begin
    -- inserindo log
    insert into loguser
      (idusuario, idlog, log, datahora, id, tipolog)
    VALUES
      (p_usuario, SEQ_LOGUSER.NEXTVAL, substr(p_log, 1, 4000), sysdate,
       p_id, p_tipolog);
  end;

  procedure GeraLogAutonomous
  (
    p_usuario in number,
    p_log     in varchar2,
    p_id      in number,
    p_tipolog in varchar2
  ) is
    pragma autonomous_transaction;
  begin
    -- inserindo log
    insert into loguser
      (idusuario, idlog, log, datahora, id, tipolog)
    values
      (p_usuario, seq_loguser.nextval, substr(p_log, 1, 4000), sysdate,
       p_id, p_tipolog);
    commit;
  end;

  procedure GeraLogInt
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2
  ) is
  begin
  
    -- inserindo log
    insert into logintegracao
      (idlogintegracao, idprenf, data, arquivo, texto, tipo, idusuario,
       descr, extencaoarq, sql, numpedido, numnf, codprod, barra)
    values
      (seq_logintegracao.nextval, nvl(p_idprenf, 0), sysdate,
       nvl(p_arquivo, 'INSERÇÃO VIA BANCO DE DADOS'),
       nvl(p_texto, 'INSERÇÃO VIA BANCO DE DADOS'), p_tipo, p_usuario,
       p_descr, nvl(p_extencaoarq, 'INT_BD'), p_sql, nvl(p_numpedido, 0),
       nvl(p_numnf, 0), nvl(p_codprod, 0), nvl(p_barra, 0));
  end;

  procedure getLogErrorByPedido(pLogIntegracao in out logintegracao%rowtype) is
  begin
    begin
      select *
        into pLogIntegracao
        from logintegracao l
       where l.idlogintegracao =
             (select max(lg.idlogintegracao)
                from logintegracao lg
               where lg.numpedido = pLogIntegracao.Numpedido
                 and lg.tipo = 'E');
    exception
      when others then
        pLogIntegracao.Descr := null;
    end; 
  end;

  function f_ret_embalagem_equivalente
  (
    p_barra  in embalagem.barra%type,
    p_barra2 in embalagem.barra%type
  ) return varchar2 is
    v_barra embalagem.barra%type;
  begin
    select e.barraprincipal
      into v_barra
      from embalagemequivalente e, embalagem ep, embalagem ee
     where e.barraprincipal = p_barra
       and e.barraequivalente = p_barra2
       and ep.idproduto = e.idprodutoprincipal
       and ep.barra = e.barraprincipal
       and ep.ativo = 'S'
       and ee.idproduto = e.idprodutoequivalente
       and ee.barra = e.barraequivalente
       and ee.ativo = 'S';
    return p_barra2;
  exception
    when no_data_found then
      return p_barra;
  end;

  function f_ret_EmbEquivPai(p_barra in embalagem.barra%type) return varchar2 is
    v_barra embalagem.barra%type;
  begin
    select e.barra
      into v_barra
      from (select b.barra
               from (select eq.barraprincipal barra
                        from embalagemequivalente eq, embalagem eeq,
                             embalagem eep
                       where eq.barraequivalente = eep.barra
                         and eq.idprodutoequivalente = eep.idproduto
                         and eep.barra = p_barra
                         and eq.barraprincipal = eeq.barra
                         and eq.idprodutoprincipal = eeq.idproduto
                         and eeq.ativo = 'S'
                      union
                      select p_barra barra
                        from dual) b
              order by b.barra) e
     where rownum = 1;
  
    return v_barra;
  exception
    when no_data_found then
      return p_barra;
  end;

  function VOL_TOT_VEICULO(P_PLACA IN VARCHAR2) return number is
    V_VOL NUMBER;
  begin
    BEGIN
      SELECT ROUND((SUM((ALTURA * LARGURA * COMPRIMENTO) -
                         ((ALTURA * LARGURA * COMPRIMENTO) *
                         (TOLERANCIAMED / 100)))) / 1000000000, 2)
        INTO V_VOL
        FROM VEICULOPALET
       WHERE PLACA = P_PLACA;
    EXCEPTION
      WHEN OTHERS THEN
        V_VOL := 1;
    END;
    RETURN V_VOL;
  end;

  function retNumNFCodInterno
  (
    p_codinterno in varchar2,
    p_tiporet    in string
  ) return varchar2 is
    v_retnum varchar2(20);
    v_retstr varchar2(100);
    v_i      number;
  begin
    for v_i in 1 .. length(p_codinterno)
    loop
      if substr(p_codinterno, v_i, 1) in
         ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') then
        v_retnum := v_retnum || substr(p_codinterno, v_i, 1);
      else
        v_retstr := v_retstr || substr(p_codinterno, v_i, 1);
      end if;
    end loop;
    if p_tiporet = 'S' then
      return v_retstr;
    else
      return v_retnum;
    end if;
  end;

  /*  function pegarproprietario return number is
    cursor c_prop is
      select c.idproprietario
        from configuracao c
       where c.ativo = 'S';
    r_prop c_prop%rowtype;
  begin
    if c_prop%isopen then
      close c_prop;
    end if;
    open c_prop;
    fetch c_prop
      into r_prop;
  
    return r_prop.idproprietario;
  end;*/

  function verifica_gerasepcriarromaneio return varchar2 is
    cursor c_config is
      select nvl(c.gerasepcriarromaneio, 'N') gerasepcriarromaneio
        from configuracao c
       where c.ativo = 'S';
  
    r_config c_config%rowtype;
    v_gersep varchar2(1);
  begin
    if c_config%isopen then
      close c_config;
    end if;
    open c_config;
    fetch c_config
      into r_config;
    if c_config%found then
      v_gersep := r_config.gerasepcriarromaneio;
    else
      v_gersep := 'N';
    end if;
    return v_gersep;
  end;

  function retornar_dif_data_extenso
  (
    P_HORAINICIO IN DATE,
    P_HORAFIM    IN DATE
  ) RETURN VARCHAR2 IS
    V_DIA    NUMBER;
    V_HORA   NUMBER;
    V_MINUTO NUMBER;
  BEGIN
    SELECT trunc((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) /
                  (24 * 60)) DIAS,
           TRUNC(((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) -
                  (trunc((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) /
                          (24 * 60)) * (24 * 60))) / 60) HORAS,
           TRUNC((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) -
                  (((trunc((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) /
                           (24 * 60))) * 24 * 60) +
                  ((TRUNC(((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) -
                           (trunc((to_number(P_HORAFIM - P_HORAINICIO) * 24 * 60) /
                                   (24 * 60)) * (24 * 60))) / 60)) * 60))) MINUTOS
      INTO V_DIA, V_HORA, V_MINUTO
      FROM dual;
    RETURN NVL(V_DIA, 0) || ' DIA(S) ' || NVL(V_HORA, 0) || ' HORA(S) ' || NVL(V_MINUTO,
                                                                               0) || ' MINUTO(S)';
  END;

  /*
   * Rotina que retorna o nro de dias que faltam para expirar a senha 
  */
  function num_dias_prox_senha return date is
    cursor c_dias is
      select mudarsenhaemdias
        from configuracao
       where ativo = 'S';
    r_dias c_dias%rowtype;
  begin
    if c_dias%isopen then
      close c_dias;
    end if;
    open c_dias;
    fetch c_dias
      into r_dias;
  
    if c_dias%found then
      return sysdate + r_dias.mudarsenhaemdias;
    else
      return sysdate + 15;
    end if;
    close c_dias;
  end;

  /*
   * Carrega as informacoes de configuração do sistema
  */
  function CarregarConfiguracao return configuracao%rowtype is
    cursor c_config is
      select *
        from configuracao
       where ativo = 'S';
  
    r_config c_config%rowtype;
  begin
    if c_config%isopen then
      close c_config;
    end if;
    open c_config;
    fetch c_config
      into r_config;
    if c_config%found then
      close c_config;
      return r_config;
    else
      close c_config;
      return null;
    end if;
  
  end;

  /*
   * Essa função retorna o menor de dois valores
   * é utilizada na liberação de notas fiscais para 
   * checar as quantidades cobertas fiscalmente
  */
  function retorna_valormenor
  (
    p_valor1 in number,
    p_valor2 in number
  ) return number is
    Result number;
  begin
    if p_valor2 > p_valor1 then
      Result := p_valor1;
    else
      Result := p_valor2;
    end if;
  
    return(Result);
  end;

  /*
   * Esta rotina tem como objetivo remanejar um lote para o endereço específicado
  */
  procedure RemanejarLote
  (
    p_lote           in number,
    p_armazemdestino in number,
    p_localdestino   in local.idlocal%type,
    p_usuario        number
  ) is
    cursor c_estlote(p_lote in number) is
      select idarmazem, idlocal, estoque
        from lotelocal
       where idlote = p_lote
         and estoque > 0;
  
    r_estlote         c_estlote%rowtype;
    v_idremanejamento number;
    v_texto           varchar2(200);
  begin
    -- para que essa rotina seja executada o lote não pode ter pendencia nem adicionar
    if c_estlote%isopen then
      close c_estlote;
    end if;
    open c_estlote(p_lote);
    fetch c_estlote
      into r_estlote;
    while c_estlote%found
    loop
      -- insere o remanejamento
      v_texto           := 'REMANEJAMENTO REF. A MUDANÇA DE LOCAL DO LOTE ' ||
                           P_LOTE;
      v_idremanejamento := pk_remanejamento.cadastrar_remanejamento(r_estlote.idarmazem,
                                                                    p_armazemdestino,
                                                                    r_estlote.idlocal,
                                                                    p_localdestino,
                                                                    p_usuario,
                                                                    null,
                                                                    v_texto,
                                                                    'N');
      -- insere o lote no remanejamento
      insert into loteremanejamento
        (idremanejamento, idlote, qtde)
      values
        (v_idremanejamento, p_lote, r_estlote.estoque);
      -- finaliza o remanejamento
      pk_remanejamento.finalizarRemanejamento(v_idremanejamento, p_usuario);
      -- pega o proximo local q o lote esta
      fetch c_estlote
        into r_estlote;
    end loop;
    close c_estlote;
  end;

  function SoNumero(P_Texto in varchar2) return varchar2 is
    v_return varchar2(100);
  begin
    for i in 1 .. length(nvl(p_texto, ' '))
    loop
      if nvl(substr(p_texto, i, 1), ' ') in
         ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0') then
        v_return := v_return || substr(p_texto, i, 1);
      end if;
    end loop;
    return v_return;
  end;

  function retornaCidadeProprietario return varchar2 is
    v_idproprietario number;
    v_cidade         cidade.descr%type;
  begin
    select idproprietario
      into v_idproprietario
      from configuracao
     where ativo = 'S';
  
    select c.descr cidade
      into v_cidade
      from endereco e, cidade c
     where c.idcidade = e.idcidade
       and e.identidade = v_idproprietario
       and e.idendereco = pk_entidade.f_ret_idendereco(v_idproprietario);
  
    return v_cidade;
  exception
    when others then
      return null;
    
  end;

  function split
  (
    p_string      varchar2,
    p_index       number,
    p_delimitador varchar2 := ','
  ) return varchar2 is
    v_posicaoinicial number;
    v_posicaofinal   number;
  begin
    if p_index = 1 then
      v_posicaoinicial := 1;
    else
      v_posicaoinicial := instr(p_string, p_delimitador, 1, p_index - 1);
      if v_posicaoinicial = 0 then
        return null;
      else
        v_posicaoinicial := v_posicaoinicial + length(p_delimitador);
      end if;
    end if;
  
    v_posicaofinal := instr(p_string, p_delimitador, v_posicaoinicial, 1);
  
    if v_posicaofinal = 0 then
      return substr(p_string, v_posicaoinicial);
    else
      return substr(p_string, v_posicaoinicial,
                    v_posicaofinal - v_posicaoinicial);
    end if;
  end;

  function formatarTempo(p_tempoEmSegundos in number) return varchar2 is
    v_resultado varchar2(100);
    v_dia       number;
    v_hora      number;
    v_minuto    number;
    v_segundo   number;
  begin
    if (p_tempoEmSegundos is null) then
      return null;
    end if;
  
    v_dia := floor(p_tempoEmSegundos / 60 / 60 / 24);
  
    v_hora := (v_dia * 24 * 60 * 60);
    v_hora := floor((p_tempoEmSegundos - v_hora) / 60 / 60);
  
    v_minuto := (v_dia * 24 * 60 * 60) + (v_hora * 60 * 60);
    v_minuto := floor((p_tempoEmSegundos - v_minuto) / 60);
  
    v_segundo := (v_dia * 24 * 60 * 60) + (v_hora * 60 * 60) +
                 (v_minuto * 60);
    v_segundo := floor((p_tempoEmSegundos - v_segundo));
  
    select decode(v_dia, 0, '', v_dia || decode(v_dia, 1, ' dia ', ' dias ')) ||
            decode(v_hora, 0, '',
                   v_hora || decode(v_hora, 1, ' hora ', ' horas ')) ||
            decode(v_minuto, 0, '',
                   v_minuto || decode(v_minuto, 1, ' minuto ', ' minutos ')) ||
            decode(v_segundo, 0, '',
                   v_segundo ||
                    decode(v_segundo, 1, ' segundo ', ' segundos '))
      into v_resultado
      from dual;
  
    if (v_resultado is null) then
      v_resultado := '-';
    end if;
  
    return v_resultado;
  end;

  function inserirLogIntegracao
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2,
    p_agrupador   in number
  ) return number is
    v_id        number;
    v_sql       varchar2(4000);
    v_agrupador number;
  begin
    begin
      if (p_agrupador is null) then
        select agrupador, insertsql
          into v_agrupador, v_sql
          from int_dados;
      else
        v_agrupador := p_agrupador;
        v_sql       := p_sql;
      end if;
    
      if (p_tipo = 'E') then
        update int_dados
           set resultado = 0
         where agrupador = v_agrupador;
      end if;
    exception
      when no_data_found then
        v_sql := p_sql;
    end;
  
    insert into logintegracao
      (idlogintegracao, idprenf, data, arquivo, texto, tipo, idusuario,
       descr, extencaoarq, sql, numpedido, numnf, codprod, barra, agrupador)
    values
      (seq_logintegracao.nextval, nvl(p_idprenf, 0), sysdate,
       nvl(p_arquivo, 'INSERÇÃO VIA BANCO DE DADOS'),
       nvl(p_texto, 'INSERÇÃO VIA BANCO DE DADOS'), p_tipo, p_usuario,
       upper(p_descr), nvl(p_extencaoarq, 'INT_BD'), v_sql,
       nvl(p_numpedido, 0), nvl(p_numnf, 0), nvl(p_codprod, 0),
       nvl(p_barra, 0), v_agrupador)
    returning idlogintegracao into v_id;
  
    return v_id;
  end inserirLogIntegracao;

  function gravarLogIntegracao(p_log in t_logintegracao) return number is
  begin
    return inserirLogIntegracao(p_log.idprenf, p_log.arquivo, p_log.texto,
                                p_log.tipo, p_log.idusuario, p_log.descr,
                                p_log.extencaoarq, p_log.sqltext,
                                p_log.numpedido, p_log.numnf, p_log.codprod,
                                p_log.barra, p_log.agrupador);
  end;

  function GerarLogIntegracao
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2,
    p_agrupador   in number := null
  ) return number is
  begin
    return inserirLogIntegracao(p_idprenf, p_arquivo, p_texto, p_tipo,
                                p_usuario, p_descr, p_extencaoarq, p_sql,
                                p_numpedido, p_numnf, p_codprod, p_barra,
                                p_agrupador);
  end;

  function GerarLogIntegracaoAut
  (
    p_idprenf     in number,
    p_arquivo     in varchar2,
    p_texto       in varchar2,
    p_tipo        in char,
    p_usuario     in number,
    p_descr       in varchar2,
    p_extencaoarq in varchar2,
    p_sql         in varchar2,
    p_numpedido   in varchar2,
    p_numnf       in varchar2,
    p_codprod     in varchar2,
    p_barra       in varchar2,
    p_agrupador   in number := null
  ) return number is
    pragma autonomous_transaction;
  begin
    return inserirLogIntegracao(p_idprenf, p_arquivo, p_texto, p_tipo,
                                p_usuario, p_descr, p_extencaoarq, p_sql,
                                p_numpedido, p_numnf, p_codprod, p_barra,
                                p_agrupador);
    commit;
  end;

  function F_TEMPO_ENTRE
  (
    P_DATA_FIM    IN DATE,
    P_DATA_INICIO IN DATE
  ) return varchar is
    v_dias   number;
    v_hrs    number;
    v_min    number;
    v_sec    number;
    v_return varchar(100);
  begin
    v_return := '';
    if P_DATA_INICIO > P_DATA_FIM then
      v_return := 'DATA INICIO MAIOR QUE DATA FIM';
    end if;
    IF P_DATA_FIM is not null THEN
    
      v_dias := trunc((((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60) / 60) / 24);
      v_hrs  := trunc(((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60) / 60) -
                24 *
                (trunc((((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60) / 60) / 24));
      v_min  := trunc((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60) -
                60 *
                (trunc(((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60) / 60));
      v_sec  := trunc(86400 * (P_DATA_FIM - P_DATA_INICIO)) -
                60 * (trunc((86400 * (P_DATA_FIM - P_DATA_INICIO)) / 60));
    
      if v_dias > 0 then
        v_return := to_char(v_dias) || ' dia';
      end if;
      if v_dias > 1 then
        v_return := v_return || 's';
      end if;
      if v_dias > 0 then
        v_return := v_return || ' ';
      end if;
    
      if v_hrs > 0 then
        v_return := v_return || to_char(v_hrs) || ' h';
      end if;
      if v_hrs > 1 then
        v_return := v_return || 's';
      end if;
      if v_hrs > 0 then
        v_return := v_return || ' ';
      end if;
    
      if v_min > 0 then
        v_return := v_return || to_char(v_min) || ' min';
      end if;
      if v_min > 1 then
        v_return := v_return || 's';
      end if;
      if v_min > 0 then
        v_return := v_return || ' ';
      end if;
    
      if v_sec > 0 then
        v_return := v_return || to_char(v_sec) || ' seg';
      end if;
    
    END IF;
  
    if P_DATA_INICIO = P_DATA_FIM then
      v_return := '0';
    end if;
  
    return v_return;
  end;

  function distanciaLocal
  (
    p_prioridade      in number,
    p_bloco           in local.bloco%type,
    p_rua             in local.rua%type,
    p_predio          in number,
    p_andar           in number,
    p_apartamento     in number,
    p_prioridadeAlvo  in number,
    p_blocoAlvo       in local.bloco%type,
    p_ruaAlvo         in local.rua%type,
    p_predioAlvo      in number,
    p_andarAlvo       in number,
    p_apartamentoAlvo in number
  ) return number is
    v_distancia         varchar2(90);
    v_prioridade        number;
    v_blocoNumerico     number;
    v_ruaNumerico       number;
    v_blocoAlvoNumerico number;
    v_ruaAlvoNumerico   number;
  
    v_blocoTmp     local.bloco%type;
    v_blocoAlvoTmp local.bloco%type;
    v_bloco        number;
    v_rua          number;
    v_predio       number;
    v_andar        number;
    v_apartamento  number;
  
    function getAsciSomaLog(p_valor in varchar2) return number is
      v_retorno varchar2(25);
    begin
      for i in 1 .. 5
      loop
        v_retorno := v_retorno ||
                     lpad(ASCII(SUBSTR(lpad(p_valor, 5, ' '), i, 1)), 3, '0');
      end loop;
      return v_retorno;
    end getAsciSomaLog;
  
  begin
  
    v_blocoTmp     := nvl(p_bloco, ' ');
    v_blocoAlvoTmp := nvl(p_blocoAlvo, ' ');
  
    v_blocoNumerico     := getAsciSomaLog(v_blocoTmp);
    v_blocoAlvoNumerico := getAsciSomaLog(v_blocoAlvoTmp);
    v_bloco             := v_blocoAlvoNumerico - v_blocoNumerico;
  
    v_ruaNumerico     := getAsciSomaLog(p_rua);
    v_ruaAlvoNumerico := getAsciSomaLog(p_ruaAlvo);
  
    v_prioridade := p_prioridadeAlvo - p_prioridade;
  
    v_rua         := v_ruaAlvoNumerico - v_ruaNumerico;
    v_predio      := p_predioAlvo - p_predio;
    v_andar       := p_andarAlvo - p_andar;
    v_apartamento := p_apartamentoAlvo - p_apartamento;
  
    if (v_prioridade < 0) then
      v_prioridade := v_prioridade * -1;
    end if;
  
    if (v_bloco < 0) then
      v_bloco := v_bloco * -1;
    end if;
  
    if (v_rua < 0) then
      v_rua := v_rua * -1;
    end if;
  
    if (v_predio < 0) then
      v_predio := v_predio * -1;
    end if;
  
    if (v_andar < 0) then
      v_andar := v_andar * -1;
    end if;
  
    if (v_apartamento < 0) then
      v_apartamento := v_apartamento * -1;
    end if;
  
    v_distancia := lpad(v_prioridade, 5, '0');
    v_distancia := v_distancia || lpad(v_bloco, 5, '0');
    v_distancia := v_distancia || lpad(v_rua, 5, '0');
    v_distancia := v_distancia || lpad(v_predio, 5, '0');
    v_distancia := v_distancia || lpad(v_andar, 5, '0');
    v_distancia := v_distancia || lpad(v_apartamento, 5, '0');
  
    return v_distancia;
  end;

  function retornarTempo(p_tempoEmSegundos in number) return varchar2 is
    v_resultado varchar2(100);
    v_dia       number;
    v_hora      number;
    v_minuto    number;
    v_segundo   number;
  begin
    /*if nvl(p_tempoEmSegundos, 0) = 0 then
      return null;
    end if;*/
  
    v_dia := floor(nvl(p_tempoEmSegundos, 0) / 60 / 60 / 24);
  
    v_hora := (v_dia * 24 * 60 * 60);
    v_hora := floor((nvl(p_tempoEmSegundos, 0) - v_hora) / 60 / 60);
  
    v_minuto := (v_dia * 24 * 60 * 60) + (v_hora * 60 * 60);
    v_minuto := floor((nvl(p_tempoEmSegundos, 0) - v_minuto) / 60);
  
    v_segundo := (v_dia * 24 * 60 * 60) + (v_hora * 60 * 60) +
                 (v_minuto * 60);
    v_segundo := floor((nvl(p_tempoEmSegundos, 0) - v_segundo));
  
    select lpad((v_dia * 24) + v_hora, 2, 0) || ':' || lpad(v_minuto, 2, 0) || ':' ||
            lpad(v_segundo, 2, 0)
      into v_resultado
      from dual;
  
    if (v_resultado is null) then
      v_resultado := '-';
    end if;
  
    return v_resultado;
  end;

  -- retorna da data após a qtde de dias uteis informado.
  function retornarDataUtil
  (
    p_data      date,
    p_diasuteis number
  ) return date is
    v_data      date;
    v_diasuteis number := 0;
  begin
    v_data := trunc(p_data);
  
    if p_diasuteis > 0 then
      while v_diasuteis < p_diasuteis
      loop
        v_data := v_data + 1;
        if to_number(to_char(v_data, 'd')) not in (1, 7) then
          v_diasuteis := v_diasuteis + 1;
        end if;
      end loop;
    end if;
  
    return v_data;
  end;

  function formatarEndereco
  (
    p_completo    in varchar2,
    p_logradouro  in varchar2,
    p_numero      in varchar2,
    p_complemento in varchar2
  ) return varchar2 is
    v_endereco varchar2(5000);
  begin
    v_endereco := '';
    /*
    trim(t.completo) || ' ' || trim(e.logradouro) || ', ' || trim(e.numero) ||
        decode(trim(e.complemento), null, '', ', ' || trim(e.complemento)) endereco,
    */
  
    if (length(p_completo) > 0) then
      v_endereco := trim(p_completo);
    end if;
  
    if (length(p_logradouro) > 0) then
      v_endereco := v_endereco || ' ' || trim(p_logradouro);
    end if;
  
    if (length(p_numero) > 0) then
      v_endereco := v_endereco || ', ' || trim(p_numero);
    end if;
  
    if (length(p_complemento) > 0) then
      v_endereco := v_endereco || ', ' || trim(p_complemento);
    end if;
  
    return trim(v_endereco);
  end;

  function formatarEndrecoComplemento
  (
    p_bairrodescr  in varchar2,
    p_cidadedescr  in varchar2,
    p_estadocidade in varchar2
  ) return varchar2 is
    v_endereco varchar2(5000);
  begin
    v_endereco := '';
    /*
    (trim(b.descr) || ' - ' || trim(c.descr) || ' - ' ||
        trim(c.estadocidade)) complendereco
    */
  
    if (length(p_bairrodescr) > 0) then
      v_endereco := trim(p_bairrodescr);
    end if;
  
    if (length(p_cidadedescr) > 0) then
      v_endereco := v_endereco || ' - ' || trim(p_cidadedescr);
    end if;
  
    if (length(p_estadocidade) > 0) then
      v_endereco := v_endereco || ', ' || trim(p_estadocidade);
    end if;
  
    return trim(v_endereco);
  end;

  function f_RetEmbalagensMov
  (
    p_idproduto in number,
    p_qtdeunit  in number,
    p_tipo      in number
  ) return number is
    v_qtdeMaiorFator         number;
    v_qtdeFatorIntermediario number;
    v_qtdeMenorFator         number;
    v_MaiorFator             number;
    v_qtdeRestante           number;
  begin
    /*P_TIPO: 0 = TODAS EMBALAGENS, 1 = EMBALAGENS MENOR FATOR / 2 = EMBALAGENS FATOR MEDIO / 3 = EMBALAGENS MAIOR FATOR*/
    v_qtdeMenorFator         := 0;
    v_qtdeFatorIntermediario := 0;
    v_qtdeMaiorFator         := 0;
    v_qtdeRestante           := p_qtdeunit;
  
    begin
      select MaiorFator
        into v_MaiorFator
        from (select distinct fatorconversao MaiorFator
                 from embalagem
                where idproduto = p_idproduto
                  and ativo = 'S'
                  and fatorconversao > 1
                order by fatorconversao desc)
       where rownum = 1;
    
      v_qtdeMaiorFator := trunc(v_qtdeRestante / v_MaiorFator);
      v_qtdeRestante   := v_qtdeRestante -
                          (trunc(v_qtdeRestante / v_MaiorFator) *
                          v_MaiorFator);
    exception
      when others then
        v_qtdeMaiorFator := 0;
        v_MaiorFator     := 2;
    end;
  
    for c_embalagens in (select distinct fatorconversao fator
                           from embalagem
                          where idproduto = p_idproduto
                            and ativo = 'S'
                            and fatorconversao < v_MaiorFator
                          order by fatorconversao desc)
    loop
      if c_embalagens.fator > 1 then
        v_qtdeFatorIntermediario := v_qtdeFatorIntermediario +
                                    trunc(v_qtdeRestante /
                                          c_embalagens.fator);
        v_qtdeRestante           := v_qtdeRestante - (trunc(v_qtdeRestante /
                                                            c_embalagens.fator) *
                                    c_embalagens.fator);
      else
        v_qtdeMenorFator := v_qtdeRestante;
      end if;
    end loop;
  
    /*P_TIPO: 0 = TODAS EMBALAGENS, 1 = EMBALAGENS MENOR FATOR / 2 = EMBALAGENS FATOR MEDIO / 3 = EMBALAGENS MAIOR FATOR*/
    if p_tipo = 0 then
      return v_qtdeMenorFator + v_qtdeFatorIntermediario + v_qtdeMaiorFator;
    elsif p_tipo = 1 then
      return v_qtdeMenorFator;
    elsif p_tipo = 2 then
      return v_qtdeFatorIntermediario;
    elsif p_tipo = 3 then
      return v_qtdeMaiorFator;
    end if;
  end;

  function isPrimeiroAndar
  (
    p_idarmazem in local.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return number is
    v_primeiroandar number;
  begin
    select min(andar)
      into v_primeiroandar
      from local
     where (idarmazem, rua) in
           (select idarmazem, rua
              from local
             where idarmazem = p_idarmazem
               and idlocal = p_idlocal);
  
    if v_primeiroandar = to_number(substr(p_idlocal, 6, 1)) then
      return 1;
    else
      return 0;
    end if;
  end;

  procedure gerarLogTransfere
  (
    p_idusuario  in number,
    p_tela       in varchar2,
    p_tabela     in varchar2,
    p_primarykey in varchar2,
    p_campo      in varchar2,
    p_tipo       in number
  ) is
    v_log loguser.log%type;
  begin
    -- p_tipo = 0: Vinculou registro
    -- p_tipo = 1: Desvinculou registro
  
    if p_tipo = 0 then
      v_log := substr('Tela: ' || initcap(p_tela) ||
                      ' - Vinculou Registro:', 1, 4000);
    
    else
      v_log := substr('Tela: ' || initcap(p_tela) ||
                      ' - Desvinculou Registro:', 1, 4000);
    end if;
  
    v_log := substr(v_log || ' - Primary Key: ' || upper(p_primarykey) ||
                    ' da tabela ' || upper(p_tabela), 1, 4000);
  
    if (p_campo is not null) then
      v_log := substr(v_log || ' - Campos: ' || upper(p_campo), 1, 4000);
    end if;
  
    insert into loguser
      (idlog, idusuario, log, datahora, tipolog)
    values
      (seq_loguser.nextval, p_idusuario, v_log, sysdate, 'CA');
  end;

  function isNumber(p_texto in varchar2) return boolean is
    v_numero number;
  begin
    if (p_texto is null) then
      return false;
    end if;
  
    if (upper(p_texto) like ('%E%')) then
      return false;
    end if;
  
    begin
      v_numero := to_number(p_texto);
      return true;
    exception
      when invalid_number then
        return false;
    end;
  exception
    when others then
      return false;
  end;

  function masc_minuto_hora(p_minutos NUMBER) RETURN VARCHAR2 IS
    v_masc  varchar2(1024);
    en_hora number(14, 2);
    v_msg   t_message;
  BEGIN
    IF p_minutos IS NOT NULL THEN
      en_hora := NVL(minuto_hora(ABS(p_minutos)), 0);
      v_masc  := REPLACE(TRIM(TO_CHAR(TRUNC(ABS(en_hora)), '999g999g999')) || ':' ||
                         TRIM(TO_CHAR(MOD(ABS(en_hora), 1) * 100, '09')), ',',
                         '.');
    
      IF p_minutos < 0 THEN
        v_masc := '-' || v_masc;
      END IF;
    ELSE
      v_masc := NULL;
    END IF;
  
    RETURN(v_masc);
  
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE <> -20001 THEN
        v_msg := t_message('Erro em MASC_MINUTO_HORA : {0}');
        v_msg.addParam(SUBSTR(SQLERRM, 1, 350));
        raise_application_error(-20000, v_msg.formatMessage);
      END IF;
    
      RAISE;
    
  END masc_minuto_hora;

  function minuto_hora(p_minutos Pls_Integer) Return number Is
    v_horas Pls_Integer;
    v_minut Pls_Integer;
    v_ret   Number;
    v_msg   t_message;
  Begin
    v_ret := 0;
    If p_minutos Is Not Null Then
      If p_minutos >= 60 Then
        v_horas := trunc(p_minutos / 60);
        v_minut := p_minutos - (v_horas * 60);
      Else
        v_horas := 0;
        v_minut := p_minutos;
      End If;
      v_ret := v_horas + (v_minut / 100);
    Else
      v_ret := Null;
    End If;
    Return(round(v_ret, 2));
  Exception
    When Others Then
      If Sqlcode <> -20001 Then
        v_msg := t_message('Erro em MINUTO_HORA : {0}');
        v_msg.addParam(substr(Sqlerrm, 1, 350));
        raise_application_error(-20000, v_msg.formatMessage);
      End If;
      Raise;
  End minuto_hora;

  function getCodigoFederecaoEstado(p_uf in varchar2) return number is
    r_ibgeConstante number;
  begin
    case p_uf
      when ('AC') then
        r_ibgeConstante := 12;
      when ('AL') then
        r_ibgeConstante := 27;
      when ('AM') then
        r_ibgeConstante := 13;
      when ('BA') then
        r_ibgeConstante := 29;
      when ('CE') then
        r_ibgeConstante := 23;
      when ('DF') then
        r_ibgeConstante := 53;
      when ('ES') then
        r_ibgeConstante := 32;
      when ('GO') then
        r_ibgeConstante := 52;
      when ('MA') then
        r_ibgeConstante := 21;
      when ('MG') then
        r_ibgeConstante := 31;
      when ('MT') then
        r_ibgeConstante := 51;
      when ('MS') then
        r_ibgeConstante := 50;
      when ('PA') then
        r_ibgeConstante := 15;
      when ('PB') then
        r_ibgeConstante := 25;
      when ('PE') then
        r_ibgeConstante := 26;
      when ('PI') then
        r_ibgeConstante := 22;
      when ('PR') then
        r_ibgeConstante := 41;
      when ('RJ') then
        r_ibgeConstante := 33;
      when ('RN') then
        r_ibgeConstante := 24;
      when ('RO') then
        r_ibgeConstante := 11;
      when ('RR') then
        r_ibgeConstante := 14;
      when ('RS') then
        r_ibgeConstante := 43;
      when ('SC') then
        r_ibgeConstante := 42;
      when ('SE') then
        r_ibgeConstante := 28;
      when ('SP') then
        r_ibgeConstante := 35;
      when ('TO') then
        r_ibgeConstante := 17;
      else
        r_ibgeConstante := 99;
    end case;
  
    return r_ibgeConstante;
  end;

  function split_array(p_valor in CLOB) return t_array is
    v_indice       number := 0;
    v_posicaoatual number := 1;
    v_valor        varchar2(4000);
    v_count        number := 1;
    v_array        t_array;
  begin
    if p_valor is null then
      return v_array;
    end if;
    loop
      select instr(p_valor, ';', v_indice + 1)
        into v_indice
        from dual;
    
      if v_indice = 0 then
        v_indice := length(p_valor) + 1;
      end if;
    
      v_valor := substr(p_valor, v_posicaoatual, v_indice - v_posicaoatual);
      v_posicaoatual := v_indice + 1;
      v_array(v_count) := v_valor;
      v_count := v_count + 1;
    
      exit when(v_indice = 0 or v_indice = length(p_valor) + 1);
    end loop;
    return v_array;
  end;

  function removeAcentosCaractereEspecial(p_valor in varchar2)
    return varchar2 is
    C_ACENTOS    constant varchar2(200) := 'À,Â,Ê,Ô,Î,Û,Ã,Õ,Á,É,Í,Ó,Ú,Ç,Ü,Ë,à,â,ê,ô,î,û,ã,õ,á,é,í,ó,ú,ç,ü,ë';
    C_SEMACENTOS constant varchar2(200) := 'A,A,E,O,I,U,A,O,A,E,I,O,U,C,U,E,a,a,e,o,i,u,a,o,a,e,i,o,u,c,u,e';
  begin
    if ((p_valor is null) OR (length(p_valor) = 0)) then
      return '';
    end if;
  
    return replace(translate(p_valor, C_ACENTOS, C_SEMACENTOS), '¿', '');
  
  end removeAcentosCaractereEspecial;

  function isPossuiCaratereMinusculo(p_texto in varchar2) return boolean is
  begin
    if (p_texto is null) then
      return false;
    end if;
  
    if p_texto = upper(p_texto) then
      return false;
    end if;
  
    return true;
  end;

  function isPossuiCaratereMaiusculo(p_texto in varchar2) return boolean is
  begin
  
    if (p_texto is null) then
      return false;
    end if;
    if p_texto = lower(p_texto) then
      return false;
    end if;
  
    return true;
  end;

  function isPossuiNumero(p_texto in varchar2) return boolean is
    v_temNumero varchar2(100);
  begin
    if (p_texto is null) then
      return false;
    end if;
  
    v_temNumero := SoNumero(p_texto);
    if v_temNumero is null then
      return false;
    end if;
  
    return true;
  end;

  function isPossuiCaratereEspecial(p_texto in varchar2) return boolean is
    v_temEspecial varchar(1);
  begin
    if (p_texto is null) then
      return false;
    end if;
    begin
      SELECT *
        into v_temEspecial
        FROM dual
       WHERE regexp_like(p_texto, '^.*[^A-Z,0-9].*$');
    exception
      when no_data_found then
        v_temEspecial := null;
    end;
  
    if v_temEspecial is null then
      return false;
    end if;
  
    return true;
  end;

  function getCFOP
  (
    p_cfop   in varchar2,
    p_tiponf in varchar2
  ) return varchar2 is
    v_retorno varchar2(4000);
    v_cfop    varchar2(4000);
  begin
    if (p_cfop is null or p_tiponf is null) then
      return '0000';
    end if;
  
    v_cfop := pk_utilities.SoNumero(p_cfop);
  
    if (p_tiponf = 'E') then
      select decode(substr(v_cfop, 0, 1), 5, '1' || substr(v_cfop, 2, 4), 6,
                     '2' || substr(v_cfop, 2, 4), 7,
                     '3' || substr(v_cfop, 2, 4), v_cfop)
        into v_retorno
        from dual;
    else
      v_retorno := v_cfop;
    end if;
  
    return v_retorno;
  
  end getCFOP;

  function getNumeroFormatadoEFD(p_valor in number) return varchar2 is
    v_retorno varchar2(4000);
    v_valor   number;
  begin
    if (p_valor is null) then
      v_valor := 0;
    else
      v_valor := p_valor;
    end if;
  
    v_retorno := to_char(to_number(to_char(v_valor, 'FM999999999990D00')),
                         'FM999999999990D00');
  
    return v_retorno;
  
  end getNumeroFormatadoEFD;

  function extrairBarraGS1128(p_codBarra in varchar2)
    return pk_utilities.t_barraGs1 is
  
    IDENTIFICADOR_PRODUTO  constant varchar2(3) := '01';
    IDENTIFICADOR_LOTE     constant varchar2(3) := '10';
    IDENTIFICADOR_QTDE     constant varchar2(2) := '30';
    IDENTIFICADOR_PESO     constant varchar2(4) := '310Y';
    IDENTIFICADOR_VENC     constant varchar2(2) := '17';
    IDENTIFICADOR_FAB      constant varchar2(2) := '11';
    IDENTIFICADOR2_PRODUTO constant varchar2(3) := '240';
  
    v_isBarraGS1128 boolean;
    r_barraGs1      pk_utilities.t_barraGs1;
    v_dtVencimento  varchar2(6);
    v_dtFabricacao  varchar2(6);
  
  begin
    v_isBarraGS1128 := nvl(replace(regexp_substr(p_codBarra,
                                                 '(\(' ||
                                                  IDENTIFICADOR_PRODUTO ||
                                                  '\))([_0-9a-zA-Z\.\,]+)'),
                                   '(' || IDENTIFICADOR_PRODUTO || ')'),
                           replace(regexp_substr(p_codBarra,
                                                  '(\(' ||
                                                   IDENTIFICADOR2_PRODUTO ||
                                                   '\))([_0-9a-zA-Z\.\,]+)'),
                                    '(' || IDENTIFICADOR2_PRODUTO || ')')) is
                       not null;
  
    if (not v_isBarraGS1128) then
      return null;
    end if;
  
    select nvl(replace(regexp_substr(p_codBarra,
                                      '(\(' || IDENTIFICADOR_PRODUTO ||
                                       '\))([_0-9a-zA-Z\.\,\-]+)'),
                        '(' || IDENTIFICADOR_PRODUTO || ')'),
                replace(regexp_substr(p_codBarra,
                                       '(\(' || IDENTIFICADOR2_PRODUTO ||
                                        '\))([_0-9a-zA-Z\.\,\-]+)'),
                         '(' || IDENTIFICADOR2_PRODUTO || ')')),
           replace(regexp_substr(p_codBarra,
                                  '(\(' || IDENTIFICADOR_LOTE ||
                                   '\))([_0-9a-zA-Z*\.\,\* \*/\-]+)'),
                    '(' || IDENTIFICADOR_LOTE || ')'),
           replace(regexp_substr(p_codBarra,
                                  '(\(' || IDENTIFICADOR_QTDE ||
                                   '\))([_0-9a-zA-Z\.\,]+)'),
                    '(' || IDENTIFICADOR_QTDE || ')'),
           replace(regexp_substr(p_codBarra,
                                  '(\(' || IDENTIFICADOR_FAB ||
                                   '\))([_0-9a-zA-Z\.\,]+)'),
                    '(' || IDENTIFICADOR_FAB || ')'),
           replace(regexp_substr(p_codBarra,
                                  '(\(' || IDENTIFICADOR_VENC ||
                                   '\))([_0-9a-zA-Z\.\,]+)'),
                    '(' || IDENTIFICADOR_VENC || ')'),
           replace(regexp_substr(p_codBarra,
                                  '(\(' || IDENTIFICADOR_PESO ||
                                   '\))([_0-9a-zA-Z\.\,]+)'),
                    '(' || IDENTIFICADOR_PESO || ')')
      into r_barraGs1.barraEmbalagem, r_barraGs1.loteIndustria,
           r_barraGs1.quantidade, v_dtFabricacao, v_dtVencimento,
           r_barraGs1.peso
      from dual;
  
    select to_date(decode(substr(v_dtFabricacao, length(v_dtFabricacao) - 1,
                                  length(v_dtFabricacao)), '00',
                           substr(v_dtFabricacao, 0,
                                   length(v_dtFabricacao) - 2) ||
                            to_char(extract(day from
                                            last_day(to_date(substr(v_dtFabricacao,
                                                                    0,
                                                                    length(v_dtFabricacao) - 2) || '01',
                                                             'YYMMDD')))),
                           v_dtFabricacao), 'YYMMDD')
      into r_barraGs1.dtFabricacao
      from dual;
  
    select to_date(decode(substr(v_dtVencimento, length(v_dtVencimento) - 1,
                                  length(v_dtVencimento)), '00',
                           substr(v_dtVencimento, 0,
                                   length(v_dtVencimento) - 2) ||
                            to_char(extract(day from
                                            last_day(to_date(substr(v_dtVencimento,
                                                                    0,
                                                                    length(v_dtVencimento) - 2) || '01',
                                                             'YYMMDD')))),
                           v_dtVencimento), 'YYMMDD')
      into r_barraGs1.dtVencimento
      from dual;
  
    return r_barraGs1;
  end extrairBarraGS1128;

  procedure GeraLogClob
  (
    p_usuario in number,
    p_id      in number,
    p_tipolog in varchar2,
    p_clob    clob,
    p_tamanho number
  ) is
    v_numeroLinha  number;
    v_copiarDe     number;
    v_conteudo     varchar2(4000);
    v_posicaoEnter number;
  begin
    v_numeroLinha := 0;
    v_copiarDe    := 1;
  
    while v_copiarDe <= length(p_clob)
    loop
      v_numeroLinha  := v_numeroLinha + 1;
      v_conteudo     := dbms_lob.substr(p_clob, p_tamanho, v_copiarDe);
      v_posicaoEnter := INSTR(v_conteudo, chr(13));
    
      if v_posicaoEnter > 0 then
        v_conteudo := substr(v_conteudo, 1, v_posicaoEnter - 1);
        v_copiarDe := v_copiarDe + v_posicaoEnter + 1;
      else
        v_copiarDe := v_copiarDe + p_tamanho;
      end if;
    
      pk_utilities.GeraLog(p_usuario, v_conteudo, p_id, p_tipolog);
    end loop;
  
  end GeraLogClob;

  function getXMLDecode(p_texto in varchar2) return varchar2 is
  begin
    if (p_texto is null) then
      return null;
    end if;
    return DBMS_XMLGEN.CONVERT(p_texto, DBMS_XMLGEN.ENTITY_DECODE);
  end;

  function getXMLEncode(p_texto in varchar2) return varchar2 is
  begin
    if (p_texto is null) then
      return null;
    end if;
    return DBMS_XMLGEN.CONVERT(p_texto, DBMS_XMLGEN.ENTITY_ENCODE);
  end;

  procedure gerarLogTempoExecucao
  (
    p_descricao      varchar2,
    p_dataInicioExec date,
    p_dataFimExec    date,
    p_identificacao  number default null
  ) is
  
    procedure validaDadosExecucao is
      v_msg t_message;
    begin
      if nvl(p_descricao, '0') = '0' then
        v_msg := t_message('Descrição da rotina não preenchida');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if p_dataInicioExec is null then
        v_msg := t_message('Data de inicio da execução não preenchida');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if p_dataFimExec is null then
        v_msg := t_message('Data fim da execução não preenchida');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if p_dataInicioExec > p_dataFimExec then
        v_msg := t_message('Data de inicio da execução está maior que a data fim da execução');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validaDadosExecucao;
  
    procedure insertLog is
      v_tempoExecucao number;
    begin
    
      v_tempoExecucao := round((to_number(p_dataFimExec - p_dataInicioExec) * 1440) * 60);
      insert into logexecucao
      values
        (seq_logexecucao.nextval, p_descricao, p_dataInicioExec,
         p_dataFimExec, v_tempoExecucao, p_identificacao);
    
    end insertLog;
  
  begin
  
    validaDadosExecucao;
    insertLog;
  
  end gerarLogTempoExecucao;

  function getConversao
  (
    p_valor           in number,
    p_unMedidaOrigem  in number,
    p_unMedidaDestino in number
  ) return number is
    v_fatorConversao number;
    v_resultado      number;
  
    /*IMPORTANTE*/
    -- Utilizar como parâmetros de entrada p_unMedidaOrigem e p_unMedidaDestino
    -- as constantes designadas por "Constantes para conversão de unidades de medida"
    -- disponíveis na assinatura da pk_utilities
  
  begin
    if (p_unMedidaOrigem = p_unMedidaDestino) then
      return p_valor;
    end if;
  
    v_fatorConversao := power(10, (p_unMedidaOrigem - p_unMedidaDestino));
    v_resultado      := p_valor * v_fatorConversao;
    return v_resultado;
  end;

  function removerAcentuacao(p_texto in varchar2) return varchar2 is
  begin
    return TRIM(upper(translate(p_texto,
                                'ÁÇÉÍÓÚÀÈÌÒÙÂÊÎÔÛÃÕËÜáçéíóúàèìòùâêîôûãõëü',
                                'ACEIOUAEIOUAEIOUAOEUaceiouaeiouaeiouaoeu')));
  end;

  function replaceEspacos(p_texto varchar) return varchar2 is
  
    v_retorno varchar2(4000);
  
    function replaceEspacoFunction(v_texto varchar2) return varchar2 is
      v_qtde     number;
      v_textoAux varchar2(4000);
    begin
      v_textoAux := replace(v_texto, '  ', ' ');
    
      select count(1)
        into v_qtde
        from dual
       where v_textoAux like '%  %';
    
      if (v_qtde > 0) then
        v_textoAux := replaceEspacoFunction(v_textoAux);
      end if;
    
      return v_textoAux;
    
    end replaceEspacoFunction;
  begin
    v_retorno := replaceEspacoFunction(p_texto);
    return trim(v_retorno);
  end replaceEspacos;

  function extrairCODE128
  (
    p_barra         in varchar2,
    p_idDepositante in depositante.identidade%type,
    p_field         in number := null,
    p_codigoProduto in out number,
    p_barraProduto  in out varchar2,
    p_barraCaixa    in out varchar2,
    p_Quantidade    in out number,
    p_LoteIndustria in out varchar2,
    p_LoteAdicional in out varchar2,
    p_Vencimento    in out date,
    p_Fabricacao    in out date,
    p_Peso          in out number,
    p_PesoLiquido   in out number
  ) return number is
  begin
    return extrairCODE128_entBarraColetor(p_barra, p_idDepositante, p_field,
                                          p_codigoProduto, p_barraProduto,
                                          p_barraCaixa, p_Quantidade,
                                          p_LoteIndustria, p_LoteAdicional,
                                          p_Vencimento, p_Fabricacao, p_Peso,
                                          p_PesoLiquido, 0);
  
  end extrairCODE128;

  function extrairCODE128_entBarraColetor
  (
    p_barra         in varchar2,
    p_idDepositante in depositante.identidade%type,
    p_field         in number := null,
    p_codigoProduto in out number,
    p_barraProduto  in out varchar2,
    p_barraCaixa    in out varchar2,
    p_Quantidade    in out number,
    p_LoteIndustria in out varchar2,
    p_LoteAdicional in out varchar2,
    p_Vencimento    in out date,
    p_Fabricacao    in out date,
    p_Peso          in out number,
    p_PesoLiquido   in out number,
    p_tipo          in number
  ) return number is
  
    /*
     p_tipo
     0 - entrar barra padrão
     1 - entrar código de barra do produto no coletor de dados
    */
  
    /********************************************************************************************************
    * Goals: Implementar rotina para leitura e vaidação de código de barrras utlizndo padrão CODE128, permi-*
    *        tindo uma parametrização dinâmica de letirua. Permitir uma leitura única, tanto para coletor co*
    *        mo para WMS Enterprise, fazendo uso de diverso padrões de leituras por equipamentos diversos   *
    *                                                                                                       *
    * Development Details:                                                                                  *
    *                                                                                                       *
    *    Step 1 :                                                                                           *
    *      - Validar parametrização ( grupoSeparador )                                                      *
    *      - Validar e remover prefixo                                                                      *
    *      - Quebrar grupos                                                                                 *
    *      - Validar existencia e consistências de limitador de Tags                                        *
    *                                                                                                       *
    *    Step 2 :                                                                                           *
    *      - Aplicar extração utilizando limitador de TAG                                                   *
    *      - Aplicar extração utilizando posicionamento de string                                           *
    *      - Gerar resto                                                                                    *
    *                                                                                                       *
    *                                                                                                       *
    *    Step 3 :                                                                                           *
    *      - Aplicar Step 2 no restolho                                                                     *
    *      - Popular variaveis de retorno                                                                   *
    *      - Validar restrições e gerar erros                                                               *
    *                                                                                                       *
    *                                                                                                       *
    * Plan Test :                                                                                           *
    *   -> Bipar utilizando coletor ( AIM CODE, ID CODE )                                                   *
    *   -> Bipar utilizando leitor comum de barras                                                          *
    *   -> Bipar barras simples (informação única)                                                          *
    *   -> Bipar barras complexas (multiplas informaçõees e formatos                                        *
    ********************************************************************************************************/
  
    --->>> Types Declarations
    type tTag is record(
      conteudoTag varchar2(400),
      tag         varchar2(100),
      valorTag    varchar2(100),
      confTag     conftagbarra%rowtype);
  
    type tMtzTag is table of tTag;
  
    type tQuebra is record(
      quebra      varchar2(400),
      quebraresto varchar2(400),
      restoValido boolean := true,
      tags        tMtzTag);
  
    type tMtzQuebra is table of tQuebra;
  
    --->>> Variables Declarations
    v_barra             varchar2(4000) := trim(p_barra);
    v_prefixo           confprefixobarra.prefixo%type;
    v_idDepositante     depositante.identidade%type := p_idDepositante;
    v_mtz               tMtzQuebra := tMtzQuebra();
    v_grupoSeparador    depositante.gruposeparadorbarra%type;
    v_return            number := 0;
    v_msg               t_message;
    v_tagPrioritaria    conftagbarra%rowtype := null;
    v_qtdLimitadorGeral number := 0;
    v_possuiLiitador    boolean;
  
    --->>> Constants Declarations
    /* Indificador de Tipo de TAGs */
    IDF_NAO_UTILIZADO      constant number := 0;
    IDF_CODIGO_PRODUTO     constant number := 1;
    IDF_BARRA_PRODUTO      constant number := 2;
    IDF_BARRA_CAIXA        constant number := 3;
    IDF_QUANTIDADE_PRODUTO constant number := 4;
    IDF_LOTE_INDUSTRIA     constant number := 5;
    IDF_VENCIMENTO         constant number := 6;
    IDF_FABRICACAO         constant number := 7;
    IDF_PESO               constant number := 8;
    IDF_PESO_LIQUIDO       constant number := 9;
    IDF_LOTE_ADICIONAL     constant number := 10;
    /* Controle de Limitado de TAGs */
    CARACTER_LIMTAG_INI constant varchar2(1) := '(';
    CARACTER_LIMTAG_FIM constant varchar2(1) := ')';
    /* Intificador de Tipos de Field */
    IDF_TPFIELD_NUMERICO constant number := 0;
    IDF_TPFIELD_TEXTO    constant number := 1;
    IDF_TPFIELD_DATA     constant number := 2;
  
    --->>> Cursors Declarations
    cursor c_tag(p_idDepositante in depositante.identidade%type) is
      select *
        from conftagbarra ctb
       where ctb.iddepositante = p_iddepositante -- idConfiguração
       order by ctb.field, ctb.tag;
    --->>> Methods Implementation
  
    function isUtilizaCode128(p_idDepositante in number) return boolean is
      v_contpref number := 0;
      v_contTag  number := 0;
    begin
    
      select count(1)
        into v_contpref
        from confprefixobarra cp
       where cp.iddepositante = p_idDepositante;
    
      select count(1)
        into v_contTag
        from conftagbarra ct
       where ct.iddepositante = p_idDepositante;
    
      return(v_contPref + v_contTag) > 0;
    
    end isUtilizaCode128;
  
    /*********************************************************************************
    * Função para carregar os dados de configuração da TAG                           *
    *********************************************************************************/
    procedure setConfTagBarra
    (
      p_confTag       in out conftagbarra%rowtype,
      p_idDepositante in depositante.identidade%type,
      p_tag           in conftagbarra.tag%type
    ) is
    begin
      begin
        select ctb.*
          into p_confTag
          from conftagbarra ctb
         where ctb.iddepositante = p_idDepositante
           and ctb.tag = p_tag;
      exception
        when no_data_found then
          p_confTag := null;
      end;
    end setConfTagBarra;
  
    /*********************************************************************************
    * Função para verificar se o Depositante possui Grupo Separador configurado ou o *
    *   Armazém                                                                      *
    *********************************************************************************/
  
    function getGrupoSeparador(p_idDepositante in depositante.identidade%type)
      return varchar2 is
      v_return depositante.gruposeparadorbarra%type := null;
    begin
      begin
        select d.gruposeparadorbarra
          into v_return
          from depositante d
         where d.identidade = p_idDepositante;
      exception
        when no_data_found then
          v_return := null;
      end;
    
      return v_return;
    
    end getGrupoSeparador;
  
    /*********************************************************************************
    * Função para verificar se a barra possui grupo separador                        *
    *********************************************************************************/
    function possuiGrupoSeparadorBarra
    (
      p_barra          in varchar2,
      p_grupoSeparador in varchar2
    ) return boolean is
      v_pos number;
    begin
      select inStr(p_barra, p_grupoSeparador)
        into v_pos
        from dual;
      return(v_pos > 0);
    end possuiGrupoSeparadorBarra;
  
    /*********************************************************************************
    * Função para validar se o início da barra possui caracter válido                *
    *********************************************************************************/
    function isInicioTagValido(p_barra in varchar2) return boolean is
    begin
      return(regexp_substr(trim(p_barra), '([^.0-9a-zA-Z\-\)\(\/\-])+') is null);
    end isInicioTagValido;
  
    /*********************************************************************************
    * Função para remover prefixo da barra de entrada de acordo com a configuração de*
    *   prefixos parametrizados para o Depositante                                   *
    *********************************************************************************/
    function removerPrefixoBarra
    (
      p_barra         in out varchar2,
      p_prefixo       in out confprefixobarra.prefixo%type,
      p_idDepositante in depositante.identidade%type
    ) return boolean is
      v_encontrou           boolean := false;
      v_prefixo_depositante confprefixobarra.prefixo%type := null;
    
    begin
    
      for crs_prefixo in (select cpb.prefixo
                            from confprefixobarra cpb
                           where cpb.iddepositante = p_idDepositante) -- idConfiguração
      loop
        v_prefixo_depositante := crs_prefixo.prefixo;
      
        if instr(p_barra, v_prefixo_depositante) = 1 then
          v_encontrou := true;
        end if;
      
        if (v_encontrou) then
          p_barra   := substr(p_barra, length(v_prefixo_depositante) + 1);
          p_prefixo := v_prefixo_depositante;
          exit;
        end if;
      
      end loop;
    
      if (v_prefixo_depositante is null) then
        v_encontrou := true;
      end if;
    
      return v_encontrou;
    end removerPrefixoBarra;
  
    /*********************************************************************************
    * Regra 1:                                                                       *
    *   Quando houver grupo separador configurado efetuar a quebra de strings por    *
    *   grupo separador e montar uma matriz com as strings resultantes               *
    *                                                                                *
    * Rotina para aplicar a regra1 quando encontrado grupo separador na barra de     *
    *   entrada                                                                      *
    *********************************************************************************/
    procedure aplicarRegra1
    (
      p_barra          in varchar2,
      p_mtz            in out tMtzQuebra,
      p_grupoSeparador in depositante.gruposeparadorbarra%type
    ) is
      v_posicao        number := 0;
      v_contador       number := 0;
      v_barraResultado varchar2(400);
    begin
      v_barraResultado := p_barra;
    
      loop
        v_contador := v_contador + 1;
      
        select inStr(v_barraResultado, p_grupoSeparador)
          into v_posicao
          from dual;
      
        p_mtz.extend();
        p_mtz(v_contador).tags := tMtzTag();
      
        if (v_posicao = 0) then
          p_mtz(v_contador).quebra := v_barraResultado;
        else
          select subStr(v_barraResultado, 1, v_posicao - 1)
            into p_mtz(v_contador).quebra
            from dual;
        
          select subStr(v_barraResultado,
                         v_posicao + length(p_grupoSeparador))
            into v_barraResultado
            from dual;
        end if;
      
        exit when(v_posicao = 0 or v_barraResultado is null or
                  length(v_barraResultado) = 0);
      end loop;
    
    end aplicarRegra1;
  
    /*********************************************************************************
    * Função para verificar se há limitador de Tag na barra                          *
    *********************************************************************************/
    function possuiLimitadorTAG(p_barra in varchar2) return boolean is
      v_ini    number := 0;
      v_fim    number := 0;
      v_return boolean := false;
    begin
      select inStr(p_barra, CARACTER_LIMTAG_INI)
        into v_ini
        from dual;
    
      select inStr(p_barra, CARACTER_LIMTAG_FIM)
        into v_fim
        from dual;
    
      if (v_ini > 0 or v_fim > 0) then
        v_return := true;
      end if;
    
      return v_return;
    
    end possuiLimitadorTAG;
  
    /*********************************************************************************
    * Função para verificar a quantidade de limitadores de tag são válidas           *
    *********************************************************************************/
    function isQtdLimTagValida
    (
      p_barra in varchar2,
      v_qtd   in out number
    ) return boolean is
      v_linha        varchar2(100);
      v_qtdLimTagIni number := 0;
      v_qtdLimTagFim number := 0;
      v_contador     number := 0;
    begin
      v_linha := p_barra;
    
      loop
        v_contador := v_contador + 1;
      
        if (substr(v_linha, v_contador, 1) = CARACTER_LIMTAG_INI) then
          v_qtdLimTagIni := v_qtdLimTagIni + 1;
        end if;
      
        exit when(v_contador = Length(v_linha));
      end loop;
    
      v_contador := 0;
    
      loop
        v_contador := v_contador + 1;
      
        if (substr(v_linha, v_contador, 1) = CARACTER_LIMTAG_FIM) then
          v_qtdLimTagFim := v_qtdLimTagFim + 1;
        end if;
      
        exit when(v_contador = Length(v_linha));
      end loop;
    
      v_qtd := (v_qtdLimTagFim + v_qtdLimTagIni);
    
      return(v_qtdLimTagFim = v_qtdLimTagIni);
    end isQtdLimTagValida;
  
    /*********************************************************************************
    * Função para validar se a barra possui a TAG                                    *
    *********************************************************************************/
    function possuiTAG
    (
      p_barra            in varchar2,
      p_tag              conftagbarra.tag%type,
      p_tamanho          in number,
      p_retornoTAG       in out varchar2,
      p_retorno          in out varchar2,
      p_utilizaLimitador in boolean,
      p_fieldCursor      in number,
      p_fixo             in number
    ) return boolean is
      v_controle number := length(p_tag) + p_tamanho;
      v_pos      number := -1;
    begin
    
      p_retorno := null;
    
      if (p_utilizaLimitador) then
        select regexp_substr(p_barra,
                              '(\(' || p_tag || '\))([-_0-9a-zA-Z\.\,/\]+)'),
               '(' || p_tag || ')'
          into p_retorno, p_retornoTAG
          from dual;
      else
        -- a busca é feita por posição
        select inStr(p_barra, p_tag)
          into v_pos
          from dual;
      
        if (v_pos = 1) then
          select (case
                    when (length(p_barra) > v_controle) then
                     subStr(p_barra, 1, v_controle)
                    else
                     p_barra
                  end), p_tag
            into p_retorno, p_retornoTAG
            from dual;
        else
          p_retorno := null;
        end if;
      end if;
    
      if (p_retorno is null) then
        p_retornoTAG := null;
      end if;
    
      --data
      if (p_fieldCursor = 6 and p_fixo = 1 and p_field = 5) then
        p_retornoTAG := null;
        p_retorno    := null;
      end if;
    
      if (p_fieldCursor = 5 and p_field = 5 and not p_utilizaLimitador and
         p_barra like (p_tag || '%')) then
        p_retornoTAG := null;
        p_retorno    := null;
      end if;
    
      return(p_retorno is not null);
    
    end possuiTAG;
  
    procedure extrairConteudoTAG
    (
      p_quebra        in out tQuebra,
      p_retornoTag    in varchar2,
      p_retorno       in varchar2,
      p_utilizaResto  in boolean,
      p_idDepositante in depositante.identidade%type
    ) is
    
    begin
      p_quebra.tags.extend();
      p_quebra.tags(p_quebra.tags.count).conteudoTag := p_retorno;
      p_quebra.tags(p_quebra.tags.count).tag := replace(replace(p_retornoTag,
                                                                CARACTER_LIMTAG_INI,
                                                                ''),
                                                        CARACTER_LIMTAG_FIM,
                                                        '');
    
      select substr(p_retorno, length(p_retornoTag) + 1,
                     length(p_retorno) - length(p_retornoTag))
        into p_quebra.tags(p_quebra.tags.count).valorTag
        from dual;
    
      setConfTagBarra(p_quebra.tags(p_quebra.tags.count).confTag,
                      p_idDepositante,
                      p_quebra.tags(p_quebra.tags.count).tag);
    
      p_quebra.quebraResto := replace(case
                                        when p_utilizaResto then
                                         p_quebra.quebraResto
                                        else
                                         p_quebra.quebra
                                      end, p_retorno, '');
    end extrairConteudoTAG;
  
    /*********************************************************************************
    * Rotina para buscar se encontra TAGs na barra                                   *
    *********************************************************************************/
    procedure buscarTag
    (
      p_quebra              in out tQuebra,
      p_idDepositante       depositante.identidade%type,
      p_utilizandoLimitador in boolean,
      p_utilizaResto        in boolean
    ) is
      v_retornoTAG varchar2(100);
      v_retorno    varchar2(100);
    begin
      p_quebra.restoValido := false;
      for crs in c_tag(p_idDepositante)
      loop
        if (possuiTAG(case
                        when p_utilizaResto then
                         p_quebra.quebraResto
                        else
                         p_quebra.quebra
                      end, crs.tag, crs.tamanho, v_retornoTAG, v_retorno,
                      p_utilizandoLimitador, crs.field, crs.fixo)) then
          extrairConteudoTAG(p_quebra, v_retornoTAG, v_retorno,
                             p_utilizaResto, p_idDepositante);
          p_quebra.restoValido := true;
        
          exit;
        end if;
      end loop;
    end buscarTag;
  
    /*********************************************************************************
    * Regra 2:                                                                       *
    *   1 - valida se possui limitador de TAG                                        *
    *   2 - quando encontrado limitidador valida se a quantidade de limitador é cons *
    *       istente                                                                  *
    *   3 - efetua a busca de TAGs utilizando rotina de limitador                    *
    *   4 - efetua a busca de TAGs                                                   *
    *********************************************************************************/
    procedure aplicarRegra2
    (
      p_mtz           in out tMtzQuebra,
      p_idDepositante depositante.identidade%type
    ) is
      v_qtdLimitador number := 0;
    begin
      for i in 1 .. p_mtz.count
      loop
      
        if (not isInicioTagValido(p_mtz(i).quebra)) then
          v_msg := t_message('Barra inválida - Caracteres Especiais - {0}');
          v_msg.addParam(p_mtz(i).quebra);
          raise_application_error(-20000, v_msg.formatMessage);
          exit;
        end if;
      
        if (possuiLimitadorTAG(p_mtz(i).quebra)) then
          if (isQtdLimTagValida(p_mtz(i).quebra, v_qtdLimitador)) then
            buscarTag(p_mtz(i), p_idDepositante, true, false);
          else
            v_msg := t_message('Os limitadores de TAGs não estão corretos - {0}');
            v_msg.addParam(p_mtz(i).quebra);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          buscarTag(p_mtz(i), p_idDepositante, false, false);
        end if;
      
        -- aplicar validação no resto até que seja invalidado
        loop
          if (possuiLimitadorTAG(p_mtz(i).quebraResto)) then
            if (isQtdLimTagValida(p_mtz(i).quebraResto, v_qtdLimitador)) then
              buscarTag(p_mtz(i), p_idDepositante, true, true);
            else
              v_msg := t_message('Os limitadores de TAGs não estão corretos - {0}');
              v_msg.addParam(p_mtz(i).quebraResto);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          else
            buscarTag(p_mtz(i), p_idDepositante, false, true);
          end if;
        
          exit when(not p_mtz(i).restoValido or
                    length(p_mtz(i).quebraResto) = 0);
        end loop;
      
      end loop;
    end aplicarRegra2;
  
    /*********************************************************************************
    * Função para retornar descrição do field                                        *
    *********************************************************************************/
    function getDescCampo(p_idfCampo in number) return varchar2 is
    begin
      return(case p_idfCampo when IDF_CODIGO_PRODUTO then
             'Código do Produto' when IDF_BARRA_PRODUTO then
             'Barra do Produto' when IDF_BARRA_CAIXA then 'Barra da Caixa' when
             IDF_QUANTIDADE_PRODUTO then 'Quantidade' when
             IDF_LOTE_INDUSTRIA then 'Lote Indústria' when IDF_VENCIMENTO then
             'Data de Vencimento' when IDF_FABRICACAO then
             'Data de Fabricação' when IDF_PESO then 'Peso Bruto' when
             IDF_PESO_LIQUIDO then 'Peso Líquido' when IDF_LOTE_ADICIONAL then
             'Lote Adicional'
             
             else 'Não mapeado' end);
    end getDescCampo;
  
    /*********************************************************************************
    * Função para retornar uma tag configurada para tipo de campo                    *
    *********************************************************************************/
    function getTagTipo
    (
      p_field         conftagbarra.field%type,
      p_idDepositante depositante.identidade%type
    ) return varchar2 is
      v_return varchar2(100) := null;
    begin
      begin
        select cb.tag
          into v_return
          from conftagbarra cb
         where cb.iddepositante = p_idDepositante
           and cb.field = nvl(p_field, -1)
           and rownum = 1;
      exception
        when no_data_found then
          null;
      end;
    
      return v_return;
    end getTagTipo;
  
    procedure gerarGrupoUnico
    (
      p_barra in varchar2,
      p_mtz   in out tMtzQuebra
    ) is
    begin
      p_mtz.extend();
      p_mtz(p_mtz.count).tags := tMtzTag();
      p_mtz(p_mtz.count).quebra := p_barra;
    end gerarGrupoUnico;
  
    procedure aplicarRegra3(p_mtz in tMtzQuebra) is
    
      procedure setCampos(p_tag in tTag) is
      
        -- Rotina para tratar número
        procedure setValorNumerico
        (
          p_identificacao in number,
          p_campo         in out number,
          p_valor         string,
          p_casasDecimais in number
        ) is
        begin
          if (p_identificacao = IDF_QUANTIDADE_PRODUTO) then
            p_campo := to_number(p_valor) /
                       to_number(rpad('1', p_casasDecimais + 1, '0'));
          else
            p_campo := to_number(p_valor);
          end if;
        exception
          when others then
            v_msg := t_message('Não foi possivel efetuar conversão de dado - [Campo : {0}] [Valor : {1}]');
            v_msg.addParam(getDescCampo(p_identificacao));
            v_msg.addParam(p_valor);
            raise_application_error(-20000, v_msg.formatMessage);
        end setValorNumerico;
      
        --Rotina para tratar string
        procedure setValorTexto
        (
          p_identificacao in number,
          p_campo         in out varchar,
          p_valor         string,
          p_confBarra     in conftagbarra%rowtype
        ) is
        
          procedure removezeros(p_valor in out varchar2) is
            v_encontrei boolean := true;
          begin
            loop
              if (substr(p_valor, 1, 1) = '0') then
                p_valor := substr(p_valor, 2);
              else
                v_encontrei := false;
              end if;
              exit when not v_encontrei;
            end loop;
          end removezeros;
        
        begin
        
          if (p_confBarra.Fixo = 1 and
             length(p_valor) <> p_confBarra.Tamanho) then
            v_msg := t_message('Conteúdo/Tamanho da barra não compatível com parametrização - [Campo : {0}] [Tamanho : {1}]');
            v_msg.addParam(getDescCampo(p_identificacao));
            v_msg.addParam(p_valor);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          p_campo := (case
                       when p_confBarra.Elimitaespacos = 1 then
                        trim(p_valor)
                       else
                        p_valor
                     end);
          if (p_confBarra.Elimitazeros = 1) then
            removezeros(p_campo);
          end if;
        exception
          when others then
            v_msg := t_message('Não foi possivel efetuar conversão de dado - [Campo : {0}] [Valor : {1}]');
            v_msg.addParam(getDescCampo(p_identificacao));
            v_msg.addParam(p_valor);
            raise_application_error(-20000, v_msg.formatMessage);
        end setValorTexto;
      
        --Rotina para tratar string
        procedure setValorData
        (
          p_identificacao in number,
          p_campo         in out date,
          p_valor         string,
          p_confBarra     in conftagbarra%rowtype
        ) is
        
          v_data date;
        
          IDF_FORMATOMASCARADATA_NU  constant number := 0;
          IDF_FORMATOMASCARADATA_INT constant number := 1; -- YYMMDD
          IDF_FORMATOMASCARADATA_BRZ constant number := 2; -- DDMMAA
          IDF_FORMATOMASCARADATA_CLC constant number := 3; -- NDAA
        
        begin
          if (p_confBarra.Fixo = 1 and
             length(p_valor) <> p_confBarra.Tamanho) then
            v_msg := t_message('Conteúdo/Tamanho da barra não compatível com parametrização - [Campo : {0}] [Tamanho : {1}]');
            v_msg.addParam(getDescCampo(p_identificacao));
            v_msg.addParam(p_valor);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          if (p_confBarra.Mascara = IDF_FORMATOMASCARADATA_INT) then
            select to_date(p_valor, 'yymmdd')
              into v_data
              from dual;
          elsif (p_confBarra.Mascara = IDF_FORMATOMASCARADATA_BRZ) then
            select to_date(p_valor, 'ddmmyy')
              into v_data
              from dual;
          elsif (p_confBarra.Mascara = IDF_FORMATOMASCARADATA_CLC) then
            select to_date('01/01/' ||
                            substr(p_valor, (length(p_valor) - 2) + 1),
                            'dd/mm/yyyy') +
                    (to_number(substr(p_valor, 1, length(p_valor) - 2)) - 1)
              into v_data
              from dual;
          end if;
        
          p_campo := v_data;
        exception
          when others then
            v_msg := t_message('Não foi possivel efetuar conversão de dado - [Campo : {0}] [Valor : {1}]');
            v_msg.addParam(getDescCampo(p_identificacao));
            v_msg.addParam(p_valor);
            raise_application_error(-20000, v_msg.formatMessage);
        end setValorData;
      
      begin
        if (p_tag.confTag.field = IDF_CODIGO_PRODUTO) then
          setValorNumerico(IDF_CODIGO_PRODUTO, p_codigoProduto,
                           p_tag.valorTag, p_tag.confTag.casasdecimais);
        elsif (p_tag.confTag.field = IDF_BARRA_PRODUTO) then
          setValorTexto(IDF_BARRA_PRODUTO, p_barraProduto, p_tag.valorTag,
                        p_tag.confTag);
        elsif (p_tag.confTag.field = IDF_BARRA_CAIXA) then
          setValorTexto(IDF_BARRA_CAIXA, p_barraCaixa, p_tag.valorTag,
                        p_tag.confTag);
        elsif (p_tag.confTag.field = IDF_QUANTIDADE_PRODUTO) then
          setValorNumerico(IDF_QUANTIDADE_PRODUTO, p_Quantidade,
                           p_tag.valorTag, p_tag.confTag.casasdecimais);
        elsif (p_tag.confTag.field = IDF_LOTE_INDUSTRIA) then
          setValorTexto(IDF_LOTE_INDUSTRIA, p_LoteIndustria, p_tag.valorTag,
                        p_tag.confTag);
        elsif (p_tag.confTag.field = IDF_VENCIMENTO) then
          setValorData(IDF_VENCIMENTO, p_Vencimento, p_tag.valorTag,
                       p_tag.confTag);
        elsif (p_tag.confTag.field = IDF_FABRICACAO) then
          setValorData(IDF_FABRICACAO, p_Fabricacao, p_tag.valorTag,
                       p_tag.confTag);
        elsif (p_tag.confTag.field = IDF_PESO) then
          setValorNumerico(IDF_PESO, p_Peso, p_tag.valorTag,
                           p_tag.confTag.casasdecimais);
        elsif (p_tag.confTag.field = IDF_PESO_LIQUIDO) then
          setValorNumerico(IDF_PESO_LIQUIDO, p_PesoLiquido, p_tag.valorTag,
                           p_tag.confTag.casasdecimais);
        elsif (p_tag.confTag.field = IDF_LOTE_ADICIONAL) then
          setValorTexto(IDF_LOTE_ADICIONAL, p_LoteAdicional, p_tag.valorTag,
                        p_tag.confTag);
        end if;
      end setCampos;
    
    begin
      for i in 1 .. p_mtz.count
      loop
        for y in 1 .. p_mtz(i).tags.count
        loop
          if (p_mtz(i).tags(y).valortag is not null) then
            v_return := 1;
          end if;
        
          setCampos(p_mtz(i).tags(y));
        end loop;
      end loop;
    end aplicarRegra3;
  
    procedure removerTagBarra
    (
      p_barra          in out varchar2,
      p_Tag            in varchar2,
      p_possuiLiitador in boolean
    ) is
      v_achou      number := 0;
      v_tagRemover varchar2(100);
    begin
      if p_possuiLiitador then
        v_tagRemover := CARACTER_LIMTAG_INI || p_tag || CARACTER_LIMTAG_FIM;
      else
        v_tagRemover := p_tag;
      end if;
    
      select inStr(p_barra, v_tagRemover)
        into v_achou
        from dual;
    
      if v_achou = 1 then
        p_barra := subStr(p_barra, length(v_tagRemover) + 1,
                          length(p_barra) - length(v_tagRemover));
      end if;
    
    end removerTagBarra;
  
    procedure removerCaracteresInvalidos(p_barra in out varchar2) is
      v_aux    varchar2(4000);
      v_char   varchar2(1);
      v_length number := length(p_barra);
    
      function isCaracterPermitido(p_char in varchar2) return boolean is
      begin
        return(regexp_substr(trim(p_char), '([^.,_0-9a-zA-Z\-\)\(\/\-])+') is null);
      end isCaracterPermitido;
    
    begin
    
      for x in 1 .. v_length
      loop
        v_char := substr(v_barra, x, 1);
      
        if (v_char <> nvl(v_grupoSeparador, '-1') and
           isCaracterPermitido(v_char) and trim(v_char) is not null) then
          v_aux := v_aux || v_char;
        else
          v_aux := v_aux || v_char;
        end if;
      end loop;
    
      p_barra := v_aux;
    end removerCaracteresInvalidos;
  
    --->>> Main Code
  begin
    --->>> Set Variables
    p_codigoProduto := null;
    p_barraProduto  := null;
    p_barraCaixa    := null;
    p_Quantidade    := null;
    p_LoteIndustria := null;
    p_LoteAdicional := null;
    p_Vencimento    := null;
    p_Fabricacao    := null;
    p_Peso          := null;
    p_PesoLiquido   := null;
  
    v_grupoSeparador := getGrupoSeparador(v_idDepositante);
  
    if (isUtilizaCode128(p_idDepositante) and v_barra is not null and
       (v_barra like ('%' || v_grupoSeparador || '%') or p_tipo = 0)) then
      if (nvl(p_field, 0) > 0) then
        begin
          select c.*
            into v_tagPrioritaria
            from conftagbarra c
           where c.iddepositante = p_idDepositante
             and c.field = p_field
             and rownum = 1;
        exception
          when others then
            return v_return;
        end;
      end if;
    
      v_barra := upper(v_barra);
    
      if (not removerPrefixoBarra(v_barra, v_prefixo, v_idDepositante) and
         p_field is null) then
        return v_return;
      end if;
    
      removerCaracteresInvalidos(v_barra);
    
      if (v_grupoSeparador is not null) then
        if (possuiGrupoSeparadorBarra(v_barra, v_grupoSeparador)) then
          aplicarRegra1(v_barra, v_mtz, v_grupoSeparador);
        else
          gerarGrupoUnico(v_barra, v_mtz);
        end if;
      else
        gerarGrupoUnico(v_barra, v_mtz);
      end if;
    
      v_possuiLiitador := isQtdLimTagValida(v_barra, v_qtdLimitadorGeral);
    
      if (v_tagPrioritaria.Idconfiguracaotagbarra is not null and
         v_mtz.count = 1 and
         (v_possuiLiitador and v_qtdLimitadorGeral <= 2)) then
        -- validar se conteúdo é compatível
        if ((v_tagPrioritaria.Fixo = 1 and
           length(v_mtz(1).quebra) = v_tagPrioritaria.Tamanho) or
           v_tagPrioritaria.Fixo = 0 and
           length(v_mtz(1).quebra) <= v_tagPrioritaria.Tamanho) then
        
          if (isInicioTagValido(v_mtz(1).quebra)) then
          
            removerTagBarra(v_barra, v_tagPrioritaria.Tag,
                            possuiLimitadorTAG(v_barra));
          
            extrairConteudoTAG(v_mtz(1), v_tagPrioritaria.Tag,
                               v_tagPrioritaria.Tag || v_barra, false,
                               p_idDepositante);
          
          else
            v_msg := t_message('Barra inválida - Caracteres Especiais - {0}');
            v_msg.addParam(v_mtz(1).quebra);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          aplicarRegra2(v_mtz, v_idDepositante);
        end if;
      else
        aplicarRegra2(v_mtz, v_idDepositante);
      end if;
    
      aplicarRegra3(v_mtz);
    end if;
  
    return v_return;
  
  end extrairCODE128_entBarraColetor;

  procedure validarLeituraPadraoCode128
  (
    p_idProcesso    in number,
    p_idDepositante in number,
    p_tipoProcesso  in number
  ) is
  
    type tCursor is ref cursor;
    v_cursor            tCursor;
    v_idDepositanteComp number;
    v_controle          boolean := false;
  
    v_msg t_message;
  
    IDF_INVENTARIO    constant number := 0;
    IDF_CONF_CHECKOUT constant number := 1;
    IDF_FORM_ONDA     constant number := 2;
  
    function getSQLDep(p_tipoProcesso in number) return clob is
      v_sql clob := null;
    begin
      if (p_tipoProcesso = IDF_INVENTARIO) then
      
        v_sql := 'select d.identidade idDepositante
             from depositanteinventario d
            where d.idinventario = :idProcesso
              and d.identidade <> :idDepositante';
      
      end if;
    
      if (p_tipoProcesso = IDF_CONF_CHECKOUT) then
      
        v_sql := 'select dp.identidade idDepositante
             from nfromaneio nfr, notafiscal nf, depositante dp, configuracaoonda co,
                  romaneiopai rp, confcheckout cot
            where nf.idnotafiscal = nfr.idnotafiscal
              and nf.iddepositante = dp.identidade
              and nfr.idromaneio = rp.idromaneio
              and rp.idromaneio = cot.idonda
              and cot.id = :idProcesso
              and nf.iddepositante <> :idDepositante
              and co.idconfiguracaoonda = rp.idconfiguracaoonda
              and (co.conferenciaporcheckoutexpress = 1 or
                  co.tipoconferenciacolmeia = 1)';
      end if;
    
      if (p_tipoProcesso = IDF_FORM_ONDA) then
      
        v_sql := 'select distinct dp.identidade idDepositante
             from romaneiopai rp, nfromaneio nfr, notafiscal nf, depositante dp,
                  configuracaoonda co
            where rp.idromaneio = :idProcesso
              and nfr.idromaneio = rp.idromaneio
              and nf.idnotafiscal = nfr.idnotafiscal
              and dp.identidade = nf.iddepositante
              and nf.iddepositante <> :idDepositante
              and co.idconfiguracaoonda = rp.idconfiguracaoonda
              and (co.conferenciaporcheckoutexpress = 1 or
                  co.tipoconferenciacolmeia = 1)';
      end if;
    
      return v_sql;
    end getSQLDep;
  
    procedure openCursor
    (
      p_cursor        in out tCursor,
      p_tipoProcesso  in number,
      p_idProcesso    in number,
      p_idDepositante in number
    ) is
    
    begin
      open p_cursor for getSQLDep(p_tipoProcesso)
        using p_idProcesso, p_idDepositante;
    end;
  
    function isQtdConfValida
    (
      p_idDepositante     number,
      p_idDepositanteComp number
    ) return boolean is
      v_controlePrefixo   boolean := false;
      v_controleTag       boolean := false;
      v_controleSeparador boolean := false;
      v_qtdO              number := 0;
      v_qtdD              number := 0;
    begin
      -- Validando se a quantidade de tags configuradas
      -- são iguais entre os depositantes comparados
      select (select count(*) qtd
                 from conftagbarra
                where iddepositante = p_idDepositante),
             (select count(*) qtd
                 from conftagbarra
                where iddepositante = p_idDepositanteComp)
        into v_qtdO, v_qtdD
        from dual;
    
      v_controleTag := ((v_qtdO = v_qtdD));
    
      if (not v_controleTag) then
        v_msg := t_message('Quantidade de configurações de Tags da regra CODE128 para o Depositante: id[{0}]' ||
                           chr(13) ||
                           'diferente da quantidade do Depositante: id[{1}].' ||
                           chr(13) || 'Verifique!');
        v_msg.addParam(p_idDepositante);
        v_msg.addParam(p_idDepositanteComp);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Validando se a quantidade de prefixos configurados
      -- são iguais entre os depositantes comparados
      select (select count(*) qtd
                 from confprefixobarra
                where iddepositante = p_idDepositante),
             (select count(*) qtd
                 from confprefixobarra
                where iddepositante = p_idDepositanteComp)
        into v_qtdO, v_qtdD
        from dual;
    
      v_controlePrefixo := ((v_qtdO = v_qtdD));
    
      if (not v_controlePrefixo) then
        v_msg := t_message('Quantidade de configurações de Prefixos da regra CODE128 para o Depositante: id[{0}]' ||
                           chr(13) ||
                           'diferente da quantidade do Depositante: id[{1}].' ||
                           chr(13) || 'Verifique!');
        v_msg.addParam(p_idDepositante);
        v_msg.addParam(p_idDepositanteComp);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Validando se o separador de barras é igual entre
      -- os depositantes comparados
      select count(1)
        into v_qtdO
        from (select nvl(dp.gruposeparadorbarra, 'NI') gruposepardorbarra
                 from depositante dp
                where dp.identidade = p_idDepositante) o,
             ((select nvl(dp.gruposeparadorbarra, 'NI') gruposepardorbarra
                  from depositante dp
                 where dp.identidade = p_idDepositanteComp)) d
       where o.gruposepardorbarra = d.gruposepardorbarra;
    
      v_controleSeparador := (v_qtdO = 1);
    
      if (not v_controleSeparador) then
        v_msg := t_message('Caractere Separador de Grupo da regra CODE128 para o Depositante: id[{0}]' ||
                           chr(13) ||
                           'diferente do Caractere Separador de Grupo da regra CODE128 do Depositante: id[{1}].' ||
                           chr(13) || 'Verifique!');
        v_msg.addParam(p_idDepositante);
        v_msg.addParam(p_idDepositanteComp);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      return(v_controlePrefixo and v_controleTag and v_controleSeparador);
    
    end isQtdConfValida;
  
    function isConf
    (
      p_idDepositante     number,
      p_idDepositanteComp number,
      p_tipoConf          number
    ) return boolean is
    
      IDF_TIPOCONF_TAG constant number := 0;
      IDF_IIPOCONF_PRF constant number := 1;
    
      v_sql cLob := null;
    
      l_crsOrigem         integer default dbms_sql.open_cursor; -- referencia de cursor Origem
      l_descOrigem        dbms_sql.desc_tab; -- describe Origem
      l_colOrigem         number;
      l_columnValueOrigem varchar2(4000);
      l_statusOrigem      integer;
    
      l_crsDestino         integer default dbms_sql.open_cursor; -- referencia de cursor destino
      l_descDestino        dbms_sql.desc_tab; -- describe Destino
      l_colDestino         number;
      l_columnValueDestino varchar2(4000);
      l_statusDestino      integer;
      v_valueO             varchar2(4000);
      v_valueD             varchar2(4000);
      v_return             boolean := true;
    
    begin
    
      if (p_tipoConf = IDF_TIPOCONF_TAG) then
        v_sql := 'SELECT * FROM CONFTAGBARRA WHERE IDDEPOSITANTE = :IDDEPOSITANTE ORDER BY FIELD, TAG';
      elsif p_tipoConf = IDF_IIPOCONF_PRF then
        v_sql := 'SELECT PREFIXO FROM CONFPREFIXOBARRA WHERE IDDEPOSITANTE = :IDDEPOSITANTE';
      end if;
    
      dbms_sql.parse(l_crsOrigem, v_sql, dbms_sql.native);
      dbms_sql.parse(l_crsDestino, v_sql, dbms_sql.native);
    
      dbms_sql.describe_columns(l_crsOrigem, l_colOrigem, l_descOrigem);
      for i in 1 .. l_colOrigem
      loop
        dbms_sql.define_column(l_crsOrigem, i, l_columnValueOrigem, 4000);
      end loop;
    
      dbms_sql.describe_columns(l_crsDestino, l_colDestino, l_descDestino);
      for i in 1 .. l_colDestino
      loop
        dbms_sql.define_column(l_crsDestino, i, l_columnValueDestino, 4000);
      end loop;
    
      -- Parametrizando consulta de Origem e Destino com IDDEPOSITANTE
      dbms_sql.bind_variable(l_crsOrigem, ':IDDEPOSITANTE', p_idDepositante);
      dbms_sql.bind_variable(l_crsDestino, ':IDDEPOSITANTE',
                             p_idDepositanteComp);
    
      -- Carregando dados da Origem e Destino
      l_statusOrigem  := dbms_sql.execute(l_crsOrigem);
      l_statusDestino := dbms_sql.execute(l_crsDestino);
    
      while (dbms_sql.fetch_rows(l_crsOrigem) > 0 and
            dbms_sql.fetch_rows(l_crsDestino) > 0)
      loop
        for i in 1 .. l_colOrigem
        loop
          -- Removendo da validação colunas da tabela CONFTAGBARRA que começam com "ID"
          -- pois os campos a serem validados não possuem essas iniciais
          if (substr(upper(l_descOrigem(i).col_name), 1, 2) <> 'ID') then
            dbms_sql.column_value(l_crsOrigem, i, v_valueO);
            dbms_sql.column_value(l_crsDestino, i, v_valueD);
          
            if (nvl(v_valueO, 'NI') <> nvl(v_valueD, 'NI')) then
            
              v_msg := t_message('Definições de regra CODE-128 divergente!' ||
                                 chr(13) ||
                                 'O campo "{0}" com valor "{1}" do Depositante [idDepositante:{2}] é diferente' ||
                                 chr(13) ||
                                 'do campo "{3}" com valor "{4}" do Depositante [idDepositante:{5}]');
            
              v_msg.addParam(l_descOrigem(i).col_name);
              v_msg.addParam(nvl(v_valueO, 'Não definido'));
              v_msg.addParam(p_idDepositante);
              v_msg.addParam(l_descDestino(i).col_name);
              v_msg.addParam(nvl(v_valueD, 'Não definido'));
              v_msg.addParam(p_idDepositanteComp);
            
              raise_application_error(-20000, v_msg.formatMessage);
            
              v_return := false;
              exit;
            end if;
          end if;
        end loop;
      end loop;
    
      return v_return;
    end isConf;
  
  begin
  
    openCursor(v_cursor, p_tipoProcesso, p_idProcesso, p_idDepositante);
  
    loop
    
      fetch v_cursor
        into v_idDepositanteComp;
      exit when v_cursor%notfound;
    
      v_controle := isQtdConfValida(p_idDepositante, v_idDepositanteComp);
      exit when not v_controle;
      v_controle := isConf(p_idDepositante, v_idDepositanteComp, 1);
      exit when not v_controle;
      v_controle := isConf(p_idDepositante, v_idDepositanteComp, 0);
      exit when not v_controle;
    
    end loop;
  
    if ((not v_controle) and (v_idDepositanteComp is not null)) then
      raise_application_error(-20000, 'Configurações Inválidas');
    end if;
  
  end validarLeituraPadraoCode128;

  function composicaoidentificacaoEnd
  (
    p_armazem          in number,
    p_idlocal          in varchar2,
    p_configuracaoonda in number
  ) return varchar2 is
  
    v_qtdbloco      number := 0;
    v_qtdrua        number := 0;
    v_qtdpredio     number := 0;
    v_qtdandar      number := 0;
    v_qtapartamento number := 0;
  
    v_soma number := 0;
  
    v_composicao varchar2(25);
  
  begin
  
    begin
      select o.blocoqtdcaracter, o.ruaqtdcaracter, o.predioqtdcaracter,
             o.andarqtdcaracter, o.apartamentoqtdcaracter
        into v_qtdbloco, v_qtdrua, v_qtdpredio, v_qtdandar, v_qtapartamento
        from configuracaoonda o
       where o.idconfiguracaoonda = p_configuracaoonda;
    exception
      when no_data_found then
        v_qtdbloco      := 0;
        v_qtdrua        := 0;
        v_qtdpredio     := 0;
        v_qtdandar      := 0;
        v_qtapartamento := 0;
    end;
  
    v_soma := v_qtdbloco + v_qtdrua + v_qtdpredio + v_qtdandar +
              v_qtapartamento;
  
    select decode(l.bloco, null, '',
                   decode(v_qtdbloco, 0, '',
                           substr(lpad(l.bloco, length(l.mascarabloco), '0'),
                                   -v_qtdbloco))) ||
            decode(l.rua, null, '',
                   decode(v_qtdrua, 0, '',
                           substr(lpad(l.rua, length(l.mascararua), '0'),
                                   -v_qtdrua))) ||
            decode(l.predio, null, '',
                   decode(v_qtdpredio, 0, '',
                           substr(lpad(l.predio, length(l.mascarapredio), '0'),
                                   -v_qtdpredio))) ||
            decode(l.andar, null, '',
                   decode(v_qtdandar, 0, '',
                           substr(lpad(l.andar, length(l.mascaraandar), '0'),
                                   -v_qtdandar))) ||
            decode(l.apartamento, null, '',
                   decode(v_qtapartamento, 0, '',
                           substr(lpad(l.apartamento,
                                        length(l.mascaraapartamento), '0'),
                                   -v_qtapartamento))) as composicao
      into v_composicao
      from local l
     where l.idarmazem = p_armazem
       and l.idlocal = p_idlocal;
  
    if (v_composicao is null) then
      return p_idlocal;
    else
      return lpad(replace(v_composicao, ' ', 0), v_soma, '0');
    end if;
  end;

  procedure validarEscalaPesagem
  (
    p_idescala    in number,
    p_pesoinicial in number,
    p_pesofinal   in number,
    p_tipo        in char
  ) is
    v_resultado number;
    v_msg       t_message;
  
  begin
  
    if (p_pesoinicial > p_pesofinal) then
      v_msg := t_message('O peso inicial não pode ser maior do que o peso final.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_resultado
      from escalapesagem ep
     where ((p_pesoinicial between ep.pesoinicial and ep.pesofinal or
           p_pesofinal between ep.pesoinicial and ep.pesofinal) and
           ep.tipo = p_tipo and ep.idescala <> p_idescala)
        or ((ep.pesoinicial between p_pesoinicial and p_pesofinal or
           ep.pesofinal between p_pesoinicial and p_pesofinal) and
           ep.tipo = p_tipo and ep.idescala <> p_idescala);
  
    if (v_resultado > 0) then
      v_msg := t_message('O intervalo de tolerância informado já está contemplado por outro cadastro.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarEscalaPesagem;

  function calcularQtdeCaixas
  (
    p_quantidade    in number,
    p_caixas        in number,
    p_qtdePorCaixas in number
  ) return varchar2 is
    v_retorno varchar2(4000);
    v_qtde    number;
    v_resto   number;
  begin
    if (p_qtdePorCaixas > p_quantidade) then
      return p_quantidade || ' POR CAIXA';
    end if;
  
    v_qtde := trunc(p_quantidade / p_qtdePorCaixas);
  
    v_resto := mod(p_quantidade, p_qtdePorCaixas);
  
    v_retorno := p_qtdePorCaixas || ' POR CAIXA';
  
    if (v_resto = 0) then
      return v_retorno;
    end if;
    v_resto := p_quantidade - (p_qtdePorCaixas * (p_caixas - 1));
  
    v_retorno := v_retorno || ' E ' || v_resto || ' NA CAIXA RESTANTE';
    return v_retorno;
  end calcularQtdeCaixas;
end pk_utilities;
/

