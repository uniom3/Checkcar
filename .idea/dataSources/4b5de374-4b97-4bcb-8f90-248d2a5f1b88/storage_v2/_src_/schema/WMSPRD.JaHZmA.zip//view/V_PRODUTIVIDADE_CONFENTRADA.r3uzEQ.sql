create view V_PRODUTIVIDADE_CONFENTRADA as
select data, anomes, idusuario, usuario, nomeusuario, atividade, depositante,
       setor, regiao, pk_utilities.retornarTempo(tempogasto) tempogasto,
       qtdeitens, qtdeunidades, round(qtdevolumes, 6) qtdevolumes,
       round(pesokg, 4) pesokg, qtdeatividade
  from (select c.data, c.anomes, c.idusuario, c.usuario, c.nomeusuario,
                c.atividade, c.depositante, c.setor, c.regiao,
                sum(c.tempogasto) tempogasto, sum(c.qtdeitens) qtdeitens,
                sum(c.qtdeunidades) qtdeunidades,
                sum(c.qtdevolumes) qtdevolumes, sum(c.pesokg) pesokg,
                sum(c.qtdeatividade) qtdeatividade
           from (select cd.idlotenf, trunc(cd.datahora) data,
                         to_char(cd.datahora, 'yyyy/mm') anomes, cd.idusuario,
                         u.nomeusuario usuario,
                         u.nomeusuariocompleto nomeusuario,
                         'CONFERÊNCIA DE ENTRADA' atividade,
                         edep.razaosocial depositante, null setor, null regiao,
                         min(cd.datahora) horainicio, max(cd.datahora) horafim,
                         (max(cd.datahora) - min(cd.datahora)) * 86400 tempogasto,
                         count(distinct cd.idproduto) qtdeitens,
                         sum(cd.qtde * e.fatorconversao) qtdeunidades,
                         sum((cd.qtde * e.fatorconversao) /
                              pk_produto.getFatorEmbCompra(cd.idproduto)) qtdevolumes,
                         sum(cd.qtde * e.pesobruto) / 1000 pesokg,
                         count(distinct cd.idconferenciaentrada) qtdeatividade
                    from (select cd.idlotenf, cd.idproduto, cd.estado,
                                  max(cd.idconferenciaentrada) idconferenciaentrada
                             from conferenciaentradadet cd
                            where cd.status = 'S'
                              and nvl(cd.ignorada, 'N') = 'N'
                            group by cd.idlotenf, cd.idproduto, cd.estado) ml,
                         conferenciaentradadet cd, usuario u, embalagem e,
                         lote l, entidade edep
                   where cd.idlotenf = ml.idlotenf
                     and cd.idconferenciaentrada = ml.idconferenciaentrada
                     and cd.idproduto = ml.idproduto
                     and cd.estado = ml.estado
                     and cd.ignorada = 'N'
                     and cd.status = 'S'
                     and u.idusuario = cd.idusuario
                     and e.idproduto = cd.idproduto
                     and e.barra = cd.barra
                     and l.idlote(+) = cd.idlote
                     and edep.identidade(+) = l.iddepositante
                   group by cd.idlotenf, trunc(cd.datahora),
                            to_char(cd.datahora, 'yyyy/mm'), cd.idusuario,
                            u.nomeusuario, u.nomeusuariocompleto,
                            edep.razaosocial) c
          group by c.data, c.anomes, c.idusuario, c.usuario, c.nomeusuario,
                   c.atividade, c.setor, c.regiao, c.depositante)
 order by data, nomeusuario
/

