create package body pk_transporte is
  /***********************************************************
   CURSOR GLOBAL QUE RECUPERA QUAIS AS ROTAS QUE COMP?E
   DETERMINADA CARGA.
  ***********************************************************/
  cursor c_tiporota(p_idcarga in carga.idcarga%type) is
    select tr.idtiporota, max(ro.valoradiantamento) va,
           max(rt.mediatempo) mt, max(nvl(rt.qtdeminentrega, 0)) qtdeminent
      from carga c, notafiscalcarga nfc, romaneiopai rp, palet p,
           produtopalet pp, rotacliente rc, rotas ro, tiporota tr,
           veiculo ve, rotaclassificacao rt,
           (select idnotafiscal, max(idromaneio) idromaneio
               from nfromaneio
              group by idnotafiscal) nfr
     where nfr.idromaneio = rp.idromaneio
       and nfr.idnotafiscal = nfc.idnotafiscal
       and nfc.idcarga = c.idcarga
       and c.idcarga = p_idcarga
       and p.idromaneio = rp.idromaneio
       and pp.idpalet = p.idpalet
       and pp.idromaneio = p.idromaneio
       and rc.identidade(+) = pp.identidade
       and ro.idrota = rc.idrota
       and tr.idtiporota = ro.idtiporota
       and ve.placa(+) = c.placa
       and rt.idclassificacao = ve.idclassificacao
       and rt.idrota = ro.idrota
     group by tr.idtiporota;

  r_tiporota c_tiporota%rowtype;

  /**************************************************************
  PROCEDIMENTO PARA INSERIR TODAS AS DESPESAS PADROES PARA AS
  ROTAS USADAS NESTA CARGA.
  CHAMADA: GERENCIADOR DE CARGA, CONTROLE DE DESPESAS;
  **************************************************************/
  procedure gera_despesas_padrao
  (
    p_carga in carga.idcarga%type,
    p_movto in string
  ) is
    cursor c_df(p_carga in carga.idcarga%type) is
      select dc.idcarga
        from despesacarga dc, despesaviagem dv
       where dv.tipopagto <> 'A'
         and dc.pago = 'S'
         and dc.idcarga = p_carga
         and dv.iddespesaviagem = dc.iddespesaviagem;
    v_carga carga.idcarga%type;
  begin
    if c_tiporota%isopen then
      close c_tiporota;
    end if;
    --pega rotas que compoe a carga
    open c_tiporota(p_carga);
    fetch c_tiporota
      into r_tiporota;
    while c_tiporota%found
    loop
      if trim(p_movto) = 'F' then
        for c_desp in (select d.iddespesaviagem, d.valorpadrao, d.tipopagto
                         from despesaviagem d
                        where d.tipopagto = 'A'
                          and d.iddespesaviagem not in
                              (select d.iddespesaviagem
                                 from despesacarga d
                                where idcarga = p_carga)
                          and d.idtiporota = r_tiporota.idtiporota)
        loop
          -- INSERE AS DESPEDAS PADROES PARA A ROTA.
          begin
            savepoint r_666;
            insert into despesacarga
              (idcarga, iddespesaviagem, valor, datadespesa, pago)
            values
              (p_carga, c_desp.iddespesaviagem, r_tiporota.va,
               trunc(sysdate), 'N');
          exception
            when dup_val_on_index then
              rollback to r_666;
          end;
        end loop;
      elsif trim(p_movto) = 'E' then
        if c_df%isopen then
          close c_df;
        end if;
        open c_df(p_carga);
        fetch c_df
          into v_carga;
        if c_df%notfound then
          for c_desp in (select d.iddespesaviagem, d.valorpadrao, d.tipopagto
                           from despesaviagem d
                          where d.tipopagto <> 'A'
                            and d.iddespesaviagem not in
                                (select d.iddespesaviagem
                                   from despesacarga d
                                  where idcarga = p_carga)
                            and d.idtiporota = r_tiporota.idtiporota)
          loop
            -- insere as despedas padroes para a rota.
            begin
              savepoint r_666;
              insert into despesacarga
                (idcarga, iddespesaviagem, valor, datadespesa, pago)
              values
                (p_carga, c_desp.iddespesaviagem, c_desp.valorpadrao,
                 trunc(sysdate), 'N');
            exception
              when dup_val_on_index then
                rollback to r_666;
            end;
          end loop;
        end if;
      
      end if;
      fetch c_tiporota
        into r_tiporota;
    end loop;
    close c_tiporota;
    if c_df%isopen then
      close c_df;
    end if;
  end;

  /****************************************************************
  PROCEDIMENTO USADO PARA FAZER O FECHAMENTO DA CARGA NO RETORNO
  DO MOTORISTA.
  CHAMADA: GERENCIADOR DE CARGA, CONTROLE DE DESPESAS;
  ****************************************************************/
  procedure fechamento_motorista(p_carga in carga.idcarga%type) is
    v_msg t_message;
  
    cursor c_desp(p_idcarga in carga.idcarga%type) is
      select c.idcarga, c.iddespesaviagem, c.valor, c.pago, v.operacao,
             v.tipopagto
        from despesacarga c, despesaviagem v
       where c.pago = 'S'
         and v.tipopagto = 'D'
         and c.idcarga = p_idcarga
         and v.iddespesaviagem = c.iddespesaviagem;
  
    cursor c_carga(p_idcarga in carga.idcarga%type) is
      select c.idcarga, rp.idromaneio, c.codigointerno, c.liberado, c.data,
             c.horasaida, c.horaretorno, c.valeemitido, c.identidade,
             nvl(c.diasparado, 0) diasparado, v.idclassificacao,
             count(distinct pp.identidade) numentregas
        from carga c, romaneiopai rp, veiculo v, palet p, produtopalet pp,
             notafiscalcarga nfc,
             (select idnotafiscal, max(idromaneio) idromaneio
                 from nfromaneio
                group by idnotafiscal) nfr
       where c.idcarga = p_idcarga
         and rp.idromaneio = nfr.idromaneio
         and nfr.idnotafiscal = nfc.idnotafiscal
         and nfc.idcarga = c.idcarga
         and p.idromaneio = rp.idromaneio
         and pp.idromaneio = p.idromaneio
         and pp.idpalet = p.idpalet
         and v.placa(+) = c.placa
         and c.idcarga not in (select idcarga
                                 from despesacarga
                                where idcarga = c.idcarga
                                  and pago = 'N')
       group by c.idcarga, rp.idromaneio, c.codigointerno, c.liberado,
                c.data, c.horasaida, c.horaretorno, c.valeemitido,
                c.identidade, c.diasparado, v.idclassificacao;
  
    cursor c_premiacao
    (
      p_dias in number,
      p_desp in number
    ) is
      select iddespesaviagem, numdias, valor
        from premiacaodiaria
       where numdias = p_dias
         and iddespesaviagem = p_desp;
  
    cursor c_premiacaomin
    (
      p_desp  in number,
      p_carga in number
    ) is
      select max(pn.valor) valor
        from premiacaodiariamin pn
       where pn.iddespesaviagem = p_desp
         and (pn.idclassificacao, pn.idrota) in
             (select rt.idclassificacao, rt.idrota
                from carga c, romaneiopai rp, palet p, produtopalet pp,
                     rotacliente rc, rotas ro, tiporota tr, veiculo v,
                     rotaclassificacao rt, notafiscalcarga nfc,
                     (select idnotafiscal, max(idromaneio) idromaneio
                         from nfromaneio
                        group by idnotafiscal) nfr
               where nfr.idromaneio = rp.idromaneio
                 and nfr.idnotafiscal = nfc.idnotafiscal
                 and nfc.idcarga = c.idcarga
                 and c.idcarga = p_carga
                 and p.idromaneio = rp.idromaneio
                 and pp.idromaneio = p.idromaneio
                 and pp.idpalet = p.idpalet
                 and rc.identidade = pp.identidade
                 and ro.idrota = rc.idrota
                 and tr.idtiporota = ro.idtiporota
                 and v.placa(+) = c.placa
                 and rt.idclassificacao = v.idclassificacao
                 and rt.idrota = ro.idrota);
    r_carga        c_carga%rowtype;
    r_premiacao    c_premiacao%rowtype;
    r_premiacaomin c_premiacaomin%rowtype;
    r_desp         c_desp%rowtype;
    v_maxdia       number := 0;
    v_mindia       number := 0;
    v_numdia       number := 0;
    v_tempo        number := 0;
  begin
    if c_carga%isopen then
      close c_carga;
    end if;
    open c_carga(p_carga);
    fetch c_carga
      into r_carga;
    if c_carga%found then
      if c_tiporota%isopen then
        close c_tiporota;
      end if;
      open c_tiporota(r_carga.idcarga);
      fetch c_tiporota
        into r_tiporota;
      if c_desp%isopen then
        close c_desp;
      end if;
      /*  VERIFICA SE A QUANTIDADE MINIMA DE ENTREGA E MAIOR QUE A QUANTIDADE
      DE ENTRAGA PARA A CARGA  */
      if r_carga.numentregas >= r_tiporota.qtdeminent then
        --VERIFICA SE NO FECHAMENTO ESTA SENDO PAGA A DIARIA DO MOTORISTA
        open c_desp(p_carga);
        fetch c_desp
          into r_desp;
        while c_desp%found
        loop
          -- RETORNA QUAL A PREMIACAO ADEQUADA PARA O FECHAMENTO
          if c_premiacao%isopen then
            close c_premiacao;
          end if;
          v_tempo  := Retornar_NumDiarias(r_carga.horasaida,
                                          r_carga.horaretorno) -
                      r_carga.diasparado;
          v_numdia := (r_tiporota.mt - v_tempo) * -1;
          open c_premiacao(v_numdia, r_desp.iddespesaviagem);
          fetch c_premiacao
            into r_premiacao;
          if c_premiacao%notfound then
            --SE N?O ENCONTROU UMA PREMIACAO ADEQUADA, DESCOBRE O PREMIO MAX E MIN
            begin
              select min(p.numdias), max(p.numdias)
                into v_mindia, v_maxdia
                from premiacaodiaria p
               where p.iddespesaviagem = r_desp.iddespesaviagem;
            exception
              when no_data_found then
                v_mindia := 0;
                v_maxdia := 0;
            end;
            if v_numdia < v_mindia then
              v_numdia := v_mindia;
            end if;
            if v_numdia > v_maxdia then
              v_numdia := v_maxdia;
            end if;
            close c_premiacao;
            open c_premiacao(v_numdia, r_desp.iddespesaviagem);
            fetch c_premiacao
              into r_premiacao;
          end if;
          begin
            savepoint r_55;
            update despesacarga
               set valor = r_premiacao.valor * r_tiporota.mt
             where idcarga = p_carga
               and iddespesaviagem = r_desp.iddespesaviagem;
          exception
            when others then
              rollback to r_55;
              v_msg := t_message('ERRO AO REALIZAR FECHAMENTO. CONTACTE O ADMINISTRADOR DO SISTEMA');
              raise_application_error(-20000, v_msg.formatMessage);
          end;
          fetch c_desp
            into r_desp;
        end loop;
      else
        -- se a carga n?o atingiu a quantidade minima de entrega.
        open c_desp(p_carga);
        fetch c_desp
          into r_desp;
        while c_desp%found
        loop
          if c_premiacaomin%isopen then
            close c_premiacaomin;
          end if;
          open c_premiacaomin(r_desp.iddespesaviagem, p_carga);
          fetch c_premiacaomin
            into r_premiacaomin;
          if c_premiacaomin%found then
            begin
              savepoint r_55;
              update despesacarga
                 set valor = nvl(r_premiacaomin.valor, 0)
               where idcarga = p_carga
                 and iddespesaviagem = r_desp.iddespesaviagem;
            exception
              when others then
                rollback to r_55;
                v_msg := t_message('ERRO AO REALIZAR FECHAMENTO. CONTACTE O ADMINISTRADOR DO SISTEMA');
                raise_application_error(-20000, v_msg.formatMessage);
            end;
          end if;
          fetch c_desp
            into r_desp;
        end loop;
      end if;
      update funcionario
         set liberado = 'S'
       where identidade = r_carga.identidade;
    else
      v_msg := t_message('ERRO AO FECHAR CARGA. VERIFIQUE SE TODAS AS DESPESAS FORAM FINALIZADAS.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
    if c_carga%isopen then
      close c_carga;
    end if;
    if c_desp%isopen then
      close c_desp;
    end if;
    if c_premiacao%isopen then
      close c_premiacao;
    end if;
    if c_tiporota%isopen then
      close c_tiporota;
    end if;
    commit;
  end;

  /****************************************************************
  PROCEDIMENTO QUE ATUALIZA A KILOMETRAGEM DO VEICULO
  CHAMADA: TMSCARGA
  ****************************************************************/
  procedure atualiza_km
  (
    p_placa   in veiculo.placa%type,
    p_kmfinal in carga.kmfinal%type
  ) is
  begin
    update veiculo
       set kmatual = p_kmfinal
     where placa = trim(p_placa);
  exception
    when others then
      rollback;
  end;

  /****************************************************************
  PROCEDIMENTO QUE REALIZA O ACERTO FINANCEIRO
  CHAMADA: TMSCARGA
  ****************************************************************/
  procedure acerto_financeiro
  (
    p_notafiscal in number,
    p_operacao   in string,
    p_idusuario  in usuario.idusuario%type
  ) is
    v_msg t_message;
  
    cursor c_acerto(p_rom in romaneiopai.idromaneio%type) is
      select r.idromaneio
        from nfromaneio r, nfdet n
       where n.acertofinanceiro = 'N'
         and r.idromaneio = p_rom
         and n.nf = r.idnotafiscal;
  
    cursor c_nf(p_nfform in number) is
      select distinct nr.idromaneio
        from nfromaneio nr
       where nr.idnotafiscal = p_nfform;
  
    v_rom    romaneiopai.idromaneio%type;
    v_acerto romaneiopai.idromaneio%type;
    v_status char(1);
  begin
    update nfdet
       set acertofinanceiro = upper(trim(p_operacao)),
           dataacerto       = sysdate
     where nf = p_notafiscal;
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_notafiscal);
    fetch c_nf
      into v_rom;
    while c_nf%found
    loop
      if c_acerto%isopen then
        close c_acerto;
      end if;
      open c_acerto(v_rom);
      fetch c_acerto
        into v_acerto;
      if p_operacao = 'S' then
        if (c_acerto%found) then
          v_status := 'P';
        else
          v_status := 'F';
        end if;
      else
        if (c_acerto%found) then
          v_status := 'P';
        else
          v_status := 'N';
        end if;
      end if;
      update carga
         set acertofinanceiro     = v_status,
             dataacertofinanceiro = sysdate,
             idusuarioacerto      = p_idusuario
       where idcarga in (select distinct nfc.idcarga
                           from nfromaneio nfr, notafiscalcarga nfc
                          where nfc.idnotafiscal = nfr.idnotafiscal
                            and nfr.idromaneio = v_rom);
      fetch c_nf
        into v_rom;
    end loop;
    commit;
    if c_nf%isopen then
      close c_nf;
    end if;
    if c_acerto%isopen then
      close c_acerto;
    end if;
  exception
    when others then
      v_msg := t_message('ERRO AO REALIZAR A BAIXA DA CARGA. CONTATE O ADMINISTRADOR DO SISTEMA.');
      raise_application_error(-20000, v_msg.formatMessage);
      rollback;
  end;

  function Retornar_NumDiarias
  (
    p_horainicio in date,
    p_horafim    in date
  ) return number is
    v_dia number;
  begin
    select trunc(p_horafim - p_horainicio)
      into v_dia
      from dual;
    if to_number(to_char(p_horafim, 'hh24')) >= 13 then
      v_dia := v_dia + 1;
    end if;
    return nvl(v_dia, 0);
  end;

  procedure validarEtiquetaTransportador(p_idnotafiscal in number) is
    v_imprimeetiquetatransportador notafiscal.imprimeetiquetatransportador%type;
    v_statusnf                     notafiscal.statusnf%type;
    v_conferido                    number;
    v_idcarga                      number;
    v_embarqueliberado             carga.embarqueliberado%type;
  
    v_msg t_message;
  begin
    select nf.imprimeetiquetatransportador, nf.statusnf
      into v_imprimeetiquetatransportador, v_statusnf
      from notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal;
  
    if v_imprimeetiquetatransportador = 0 then
      v_msg := t_message('A nota fiscal id: {0} não está definida para impressão de etiqueta do transportador.');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      select s.conferido
        into v_conferido
        from saidapornf s
       where s.idnotafiscal = p_idnotafiscal;
    exception
      when no_data_found then
        select s.conferido
          into v_conferido
          from retornosimbolico r, saidapornf s
         where r.idnotafiscalvenda = p_idnotafiscal
           and s.idnotafiscal = r.idnotafiscalretorno;
    end;
  
    if (v_conferido = 0) then
      v_msg := t_message('A nota fiscal não foi conferida. Operação cancelada.' ||
                         chr(13) || 'IDNOTAFISCAL: {0}');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      select max(nfc.idcarga)
        into v_idcarga
        from notafiscalcarga nfc
       where nfc.idnotafiscal = p_idnotafiscal;
    
      select ca.embarqueliberado
        into v_embarqueliberado
        from carga ca
       where ca.idcarga = v_idcarga;
    
      if (v_embarqueliberado = 'S') then
        v_msg := t_message('A nota fiscal está em carga com embarque liberado. Operação cancelada.' ||
                           chr(13) || 'IDNOTAFISCAL: {0}' || chr(13) ||
                           'IDCARGA: {1}');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(v_idcarga);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    exception
      when no_data_found then
        null;
    end;
  
    if (v_statusnf = 'P') then
      v_msg := t_message('A nota fiscal já está processada. Operação cancelada.' ||
                         chr(13) || 'IDNOTAFISCAL: {0}');
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarEtiquetaTransportador;

  function retornarQtdeEtiqTransportador(p_idnotafiscal in number)
    return number is
    v_qtdeetiquetas number;
  begin
  
    validarEtiquetaTransportador(p_idnotafiscal);
  
    select sum(decode(a.qtdeetiquetas, 0, 1, a.qtdeetiquetas)) qtdeetiquetas
      into v_qtdeetiquetas
      from (select vr.idvolumeromaneio,
                    sum(decode(e.caixafechada, 'S',
                                trunc(cv.quantidade / e.fatorconversao), 0)) qtdeetiquetas
               from volumeromaneio vr, conteudovolume cv, lote lt, embalagem e,
                    romaneiopai rp
              where vr.idnotafiscal = p_idnotafiscal
                and rp.idromaneio = vr.idromaneio
                and rp.statusonda in (1, 2, 4)
                and cv.idvolumeromaneio = vr.idvolumeromaneio
                and lt.idlote = cv.idlote
                and e.barra = lt.barra
                and e.idproduto = lt.idproduto
              group by vr.idvolumeromaneio) a;
  
    return v_qtdeetiquetas;
  end;

  procedure gravarEtiquetaTransportador
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_qtdesugerida in number,
    p_qtdeimpressa in number,
    p_idusuario    in number,
    p_origemimp    in number,
    p_idsupervisor in number := 0,
    p_retorno      out number,
    p_idetiqueta   out number
  ) is
    v_impressaoconfirmada number;
    v_idetiquetatransp    number;
  
    SOLICITAR_SUPERVISOR constant number := 0;
    HISTORICO_GRAVADO    constant number := 1;
  begin
  
    validarEtiquetaTransportador(p_idnotafiscal);
  
    select count(*)
      into v_impressaoconfirmada
      from etiquetatransportador et
     where et.idonda = p_idonda
       and et.idnotafiscal = p_idnotafiscal;
  
    if (v_impressaoconfirmada > 0 and p_idsupervisor = 0) then
      p_retorno := SOLICITAR_SUPERVISOR;
      return;
    end if;
  
    if (v_impressaoconfirmada > 0) then
      select id
        into v_idetiquetatransp
        from etiquetatransportador
       where idonda = p_idonda
         and idnotafiscal = p_idnotafiscal;
    
      update etiquetatransportador
         set idusuariologado   = p_idusuario,
             idsupervisor      = decode(p_idsupervisor, 0, null,
                                        p_idsupervisor),
             qtdesugerida      = p_qtdesugerida,
             qtdeimpressa      = p_qtdeimpressa,
             dataconfirmacao   = sysdate,
             origemconfirmacao = p_origemimp
       where id = v_idetiquetatransp;
    else
      select seq_etiquetatransportador.nextval
        into v_idetiquetatransp
        from dual;
    
      insert into etiquetatransportador
        (id, idonda, idnotafiscal, idusuariologado, idsupervisor,
         qtdesugerida, qtdeimpressa, dataconfirmacao, origemconfirmacao)
      values
        (v_idetiquetatransp, p_idonda, p_idnotafiscal, p_idusuario,
         decode(p_idsupervisor, 0, null, p_idsupervisor), p_qtdesugerida,
         p_qtdeimpressa, sysdate, p_origemimp);
    end if;
  
    insert into historicoetiqtransportador
      (id, idetiquetatransp, idusuariologado, idsupervisor, qtdesugerida,
       qtdeimpressa, dataconfirmacao, origemconfirmacao)
    values
      (seq_historicoetiqtransportador.nextval, v_idetiquetatransp,
       p_idusuario, decode(p_idsupervisor, 0, null, p_idsupervisor),
       p_qtdesugerida, p_qtdeimpressa, sysdate, p_origemimp);
  
    begin
      select co.idetiquetatransportador
        into p_idetiqueta
        from romaneiopai rp, configuracaoonda co
       where rp.idromaneio = p_idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda;
    exception
      when no_data_found then
        select g.idrelatorio
          into p_idetiqueta
          from gerenciadorrelatorio g
         where g.tiporelatorio = 18
           and g.personalizada = 0
           and rownum = 1;
    end;
  
    p_retorno := HISTORICO_GRAVADO;
  end;

  procedure adicionarTranspRedespacho
  (
    p_idservicotransportadora in number,
    p_idtransportadora        in number,
    p_idusuario               in number
  ) is
    v_msg t_message;
  
    function validarEntidadeTransportadora return boolean is
      v_retorno number;
    begin
      begin
        select 1
          into v_retorno
          from entidade e, tipo t
         where e.identidade = p_idtransportadora
           and e.ativo = 'S'
           and t.descr = 'TRANSPORTADORA'
           and e.tipoentidade = t.idtipo;
      exception
        when no_data_found then
          v_retorno := 0;
      end;
    
      return v_retorno > 0;
    end validarEntidadeTransportadora;
  
  begin
    if (validarEntidadeTransportadora) then
      insert into servicoTranspRedespacho
        (idservicotranspredespacho, idservicotransportadora,
         idtransportadora, idusuario)
      values
        (seq_servicoTranspRedespacho.nextval, p_idservicotransportadora,
         p_idtransportadora, p_idusuario);
    else
      v_msg := t_message('A entidade não é uma transportadora ou não encontra-se ativa');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end adicionarTranspRedespacho;

  procedure removerTranspRedespacho
  (
    p_idservicotransportadora in number,
    p_idtransportadora        in number
  ) is
  begin
    delete from servicotranspredespacho s
     where s.idtransportadora = p_idtransportadora
       and s.idservicotransportadora = p_idservicotransportadora;
  end removerTranspRedespacho;

end;
/

