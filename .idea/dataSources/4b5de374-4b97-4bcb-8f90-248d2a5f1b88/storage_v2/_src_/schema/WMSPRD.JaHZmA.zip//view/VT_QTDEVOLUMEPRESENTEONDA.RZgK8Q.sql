create view VT_QTDEVOLUMEPRESENTEONDA as
select nvl(tp.descr, 'SEM CAIXA DEFINIDA') descr, count(vr.idvolume) qtde, vr.idromaneio h$idonda, vr.idromaneio h$tableid
  from volumeromaneio vr, tipocaixavolume tp
WHERE tp.idtipocaixavolume (+) = vr.idtipocaixavolume
  and vr.statusvolume = 0
 group by nvl(tp.descr, 'SEM CAIXA DEFINIDA'), vr.idromaneio

/

