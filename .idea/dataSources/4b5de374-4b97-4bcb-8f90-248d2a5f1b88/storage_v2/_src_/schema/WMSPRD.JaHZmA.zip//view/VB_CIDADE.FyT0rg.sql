create view VB_CIDADE as
select c.descr cidade, c.estadocidade uf, p.pais, c.idcidade h$idcidade
  from cidade c, pais p
 where c.pais = p.idpais
/

