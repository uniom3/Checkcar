create view VB_EMBALARVOLUMEPARAPRESENTE as
select sum(decode(c.qtdVolumeEmMontagem, 0, -1,
                   c.qtdItemNF - c.qtdVolumesMontado)) qtd, c.idnotafiscal,
       c.idescaninho
  from (select nvl(itemOS.qtd, 0) qtdItemNF,
                nvl(emVolume.qtd, 0) qtdVolumesMontado,
                nvl(emMontagem.qtd, 0) qtdVolumeEmMontagem, du.l,
                itemOS.idnotafiscal, emMontagem.idescaninho
           from (select 1 l
                    from dual) du,
                (select sum(osi.qtdeitem) qtd, osi.idproduto, os.idnotafiscal,
                         1 l
                    from ordemseparacao os, ordemseparacaoitem osi
                   where os.status in (0, 1)
                     and osi.idordemsep = os.idordemseparacao
                     and osi.giftwrapid is not null
                   group by osi.idproduto, os.idnotafiscal) itemOS,
                (select sum(ct.quantidade) qtd, lt.idproduto, ct.idescaninho,
                         e.idnotafiscal, 1 l
                    from escaninho e, conteudoescaninho ct, movimentacao m,
                         lote lt
                   where ct.idescaninho = e.idendereco
                     and m.id = ct.idmovimentacao
                     and lt.idlote = m.idlote
                   group by lt.idproduto, ct.idescaninho, e.idnotafiscal) emMontagem,
                (select sum(cv.quantidade) qtd, lt.idproduto, vr.idnotafiscal,
                         1 l
                    from volumeromaneio vr, conteudovolume cv, lote lt
                   where cv.idvolumeromaneio = vr.idvolumeromaneio
                     and lt.idlote = cv.idlote
                   group by lt.idproduto, vr.idnotafiscal) emVolume
          where emMontagem.idnotafiscal = itemOS.idnotafiscal
            and emVolume.idnotafiscal(+) = itemOS.idnotafiscal
            and itemOS.l(+) = du.l
            and emMontagem.l(+) = itemOS.l
            and emMontagem.idproduto(+) = itemOS.idproduto
            and emVolume.idproduto(+) = itemOS.idproduto) c
 group by c.idnotafiscal, c.idescaninho
/

