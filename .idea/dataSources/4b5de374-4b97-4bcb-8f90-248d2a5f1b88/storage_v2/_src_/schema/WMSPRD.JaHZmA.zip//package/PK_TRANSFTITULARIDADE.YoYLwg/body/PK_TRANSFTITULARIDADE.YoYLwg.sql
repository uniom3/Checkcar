create package body pk_transftitularidade is

  C_AGUARDANDO_EFETIVACAO constant number := 4;

  v_msg t_message;

  procedure inserirTransferenciaLiberacao(p_idUsuarioReserva in number) is
  begin
    for c_nf in (select nf.idnotafiscal, c.transferenciatitularidade,
                        nf.estoqueverificado
                   from notafiscal nf, gtt_selecaoliberacao g,
                        classificacaotipopedido c
                  where nf.idnotafiscal = g.idselecionado
                    and exists (select 1
                           from gtt_selecaoliberacao
                          where idselecionado = nf.idnotafiscal)
                    and c.idtipopedido = nf.idtipopedido)
    loop
      if c_nf.transferenciatitularidade = 1
         and c_nf.estoqueverificado = 'S' then
        insert into transferenciatitularidade
          (idtransferencia, datacadastro, idnotafiscalsaida,
           idusuarioreserva, datareserva, status)
        values
          (seq_transferenciatitularidade.nextval, sysdate,
           c_nf.idnotafiscal, p_idUsuarioReserva, sysdate,
           C_STATUS_AG_RESERVA_ESTOQUE);
      end if;
    end loop;
  end;

  procedure cancelarTransferenciaPendente(p_idUsuario in number) is
    v_nfcount number;
    v_nfdesc  varchar2(500);
    v_msg     t_message;
  begin
    select count(*), stragg(t.idnotafiscalsaida)
      into v_nfcount, v_nfdesc
      from transferenciatitularidade t
     where exists (select 1
              from gtt_selecao
             where idselecionado = t.idnotafiscalsaida)
       and t.status not in
           (C_STATUS_AG_RESERVA_ESTOQUE, C_STATUS_CANCELADO);
  
    if v_nfcount > 0 then
      v_msg := t_message('Dentre as notas selecionadas, existem notas' ||
                         ' de Transferência de Titularidade com status' ||
                         ' diferente de "Aguardando Reserva de Estoque(1)".' ||
                         ' Impossível continuar operação. NF: {0}');
      v_msg.addParam(v_nfdesc);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update transferenciatitularidade t
       set t.idusuariocancelamento = p_idUsuario,
           t.datacancelamento      = sysdate,
           t.status                = C_STATUS_CANCELADO,
           t.idnotafiscalentrada   = null
     where exists (select 1
              from gtt_selecao
             where idselecionado = t.idnotafiscalsaida)
       and t.status = C_STATUS_AG_RESERVA_ESTOQUE;
  end;

  procedure vinculaNotaEntrada
  (
    p_idTransfTitularidade in number,
    p_idNotaFiscal         in number,
    p_idUsuario            in number
  ) is
    v_idNotaSaida      number;
    v_idNotaEntrada    number;
    v_validaDiferencas number;
    v_possuiBacklist   number;
    v_nomeUsuario      usuario.nomeusuario%type;
    v_msg              t_message;
  begin
  
    begin
      select t.idnotafiscalentrada
        into v_idNotaEntrada
        from transferenciatitularidade t
       where t.idtransferencia = p_idTransfTitularidade;
    exception
      when no_data_found then
        v_idNotaEntrada := null;
    end;
  
    if (v_idNotaEntrada is not null) then
      v_msg := t_message('Não foi possível realizar o vínculo pois esta Transferência de Titularidade já possui Nota Fiscal de Entrada associada');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select t.idnotafiscalsaida
      into v_idNotaSaida
      from transferenciatitularidade t
     where t.idtransferencia = p_idTransfTitularidade;
  
    select count(*)
      into v_validaDiferencas
      from transferenciatitularidade tt, notafiscal nfe, notafiscal nfs,
           entidade ee, entidade es
     where tt.idtransferencia = p_idTransfTitularidade
       and nfe.idnotafiscal = p_idNotaFiscal
       and nfs.idnotafiscal = tt.idnotafiscalsaida
       and ee.identidade = nfe.iddepositante
       and es.identidade = nfs.destinatario
       and (pk_entidade.formatcnpjcpf(ee.cgc) =
           pk_entidade.formatcnpjcpf(es.cgc) or
           pk_entidade.formatcnpjcpf(ee.cic) =
           pk_entidade.formatcnpjcpf(es.cic));
  
    if (v_validaDiferencas = 0) then
      v_msg := t_message('O destinatário da nota de saída deve ser igual ao depositante da nota de entrada. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_possuiBacklist
      from notafiscal nf, nfdet nd, depositante d, backlist b
     where nf.idnotafiscal = p_idnotafiscal
       and d.identidade = nf.iddepositante
       and d.utzbacklist in (1, 2, 3)
       and nd.nf = nf.idnotafiscal
       and b.idnfdet = nd.idnfdet;
  
    if (v_possuiBacklist > 0) then
      select count(*)
        into v_validaDiferencas
        from (select lt.idproduto, sum(m.quantidade), lt.descr ltindustria,
                      case
                         when (pd.coletadtavenclote in (1, 3)) then
                          lt.dtvenc
                         else
                          null
                       end dtvencimento,
                      case
                         when (pd.coletadtavenclote in (2, 3)) then
                          lt.dtfabricacao
                         else
                          null
                       end dtfabricacao
                 from movimentacao m, lote lt, notafiscal nfentrada,
                      produtodepositante pd
                where m.idnotafiscal = v_idNotaSaida
                  and lt.idlote = m.idlote
                  and m.status in (0, 1, 2, 4)
                  and m.etapa = 1
                  and nfentrada.idnotafiscal = p_idNotaFiscal
                  and pd.identidade = nfentrada.iddepositante
                  and pd.idproduto = lt.idproduto
                group by lt.idproduto, lt.descr,
                         case
                           when (pd.coletadtavenclote in (1, 3)) then
                            lt.dtvenc
                           else
                            null
                         end,
                         case
                           when (pd.coletadtavenclote in (2, 3)) then
                            lt.dtfabricacao
                           else
                            null
                         end, pd.coletadtavenclote
               minus
               select nd.idproduto, sum(nd.qtde), b.loteindustria ltindustria,
                      case
                         when (pd.coletadtavenclote in (1, 3)) then
                          b.vencimento
                         else
                          null
                       end dtvencimento,
                      case
                         when (pd.coletadtavenclote in (2, 3)) then
                          b.dtfabricacao
                         else
                          null
                       end dtfabricacao
                 from notafiscal nf, nfdet nd, backlist b,
                      produtodepositante pd
                where nf.idnotafiscal = p_idNotaFiscal
                  and nd.nf = nf.idnotafiscal
                  and b.idnfdet = nd.idnfdet
                  and pd.identidade = nf.iddepositante
                  and pd.idproduto = nd.idproduto
                group by nd.idproduto, b.loteindustria,
                         case
                           when (pd.coletadtavenclote in (1, 3)) then
                            b.vencimento
                           else
                            null
                         end, pd.coletadtavenclote,
                         case
                           when (pd.coletadtavenclote in (2, 3)) then
                            b.dtfabricacao
                           else
                            null
                         end);
    
      if (v_validaDiferencas > 0) then
        v_msg := t_message('Não foi possível realizar o vínculo pois nem todos' ||
                           ' os produtos, quantidades, lotes indústria, vencimento' ||
                           ' e fabricação dos backlists cadastrados são iguais.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      select count(*)
        into v_validaDiferencas
        from (select nd.idproduto, sum(nd.qtde)
                 from nfdet nd
                where nd.nf = v_idNotaSaida
                group by nd.idproduto
               minus
               select nd.idproduto, sum(nd.qtde)
                 from nfdet nd
                where nd.nf = p_idNotaFiscal
                group by nd.idproduto);
    
      if (v_validaDiferencas > 0) then
        v_msg := t_message('Não foi possível realizar o vínculo pois nem todos' ||
                           ' os produtos e quantidades das notas de entrada e saída são iguais');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    update transferenciatitularidade t
       set t.idnotafiscalentrada = p_idNotaFiscal,
           t.idusuarionfentrada  = p_idUsuario,
           t.datanfentrada       = sysdate,
           t.status              = C_STATUS_AG_EFETIVACAO
     where t.idtransferencia = p_idTransfTitularidade;
  
    select u.nomeusuario
      into v_nomeUsuario
      from usuario u
     where u.idusuario = p_idUsuario;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Usuário ' || v_nomeUsuario || ' (' || p_idUsuario ||
                          ') vinculou a nota fiscal ' || p_idNotaFiscal ||
                          ' do controle de transferência de titularidade ' ||
                          p_idTransfTitularidade, null, 'TT');
  end;

  procedure desvinculaNotaEntrada
  (
    p_idTransfTitularidade in number,
    p_idNotaFiscal         in number,
    p_idUsuario            in number
  ) is
    v_nomeUsuario usuario.nomeusuario%type;
  begin
    update transferenciatitularidade t
       set t.idnotafiscalentrada = null,
           t.idusuarionfentrada  = null,
           t.datanfentrada       = null,
           t.status              = C_STATUS_AG_DOC_ENTRADA
     where t.idtransferencia = p_idTransfTitularidade;
  
    select u.nomeusuario
      into v_nomeUsuario
      from usuario u
     where u.idusuario = p_idUsuario;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Usuário ' || v_nomeUsuario || ' (' || p_idUsuario ||
                          ') desvinculou a nota fiscal ' || p_idNotaFiscal ||
                          ' do controle de transferência de titularidade ' ||
                          p_idTransfTitularidade, null, 'TT');
  end;

  procedure validarNfEmTransferencia(p_idprenf in number) is
    v_idNotaFiscal number;
    v_status       number;
    v_idTrans      number;
    v_msg          t_message;
  begin
  
    begin
      select nf.idnotafiscal
        into v_idNotaFiscal
        from notafiscal nf
       where nf.idprenf = p_idPreNf;
    exception
      when no_data_found then
        return;
    end;
  
    begin
      select tt.idtransferencia, tt.status
        into v_idTrans, v_status
        from transferenciatitularidade tt
       where tt.idtransferencia =
             (select max(t.idtransferencia)
                from transferenciatitularidade t
               where (t.idnotafiscalsaida = v_idNotaFiscal or
                     t.idnotafiscalentrada = v_idNotaFiscal))
         and ((tt.idnotafiscalsaida = v_idNotaFiscal) or
             (tt.idnotafiscalentrada = v_idNotaFiscal));
    
      if (v_status = C_STATUS_CONCLUIDO) then
        v_msg := t_message('Não é permitido cancelar/excluir a nota/pedido [idNotaFiscal : {0}],' ||
                           ' pois a Transferência de Titularidade [idTransferencia: {1}] está concluída.');
        v_msg.addParam(v_idNotaFiscal);
        v_msg.addParam(v_idTrans);
        raise_application_error(-20000, v_msg.formatMessage);
      elsif (v_status > C_STATUS_CANCELADO) then
        v_msg := t_message('Não é permitido cancelar/excluir a nota/pedido [idNotaFiscal : {0}].' ||
                           ' É necessário primeiro cancelar a Transferência de Titularidade [idTransferencia: {1}].');
        v_msg.addParam(v_idNotaFiscal);
        v_msg.addParam(v_idTrans);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    exception
      when no_data_found then
        null;
    end;
  end validarNfEmTransferencia;

  procedure reservarEstoque
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  ) is
    C_ORIGEM_FORMACAO_TRANSF constant number := 2;
  
    C_STATUS_ONDA_FORMADA  constant number := 1;
    C_STATUS_ONDA_LIBERADA constant number := 2;
    C_STATUS_ONDA_CORTE    constant number := 6;
  
    RESULTADO_ONDA_FORMADA constant number := 1;
  
    v_transfstatus       number;
    v_idconfiguracaoonda number;
    v_idnotasaida        number;
    v_iddepositantesaida number;
    v_idonda             number;
    v_resultadoFormacao  number;
    v_idusuariointegr    number;
    v_msg                t_message;
  
    r_onda          romaneiopai%rowtype;
    r_nfFaturamento notafiscal%rowtype;
    r_inforomaneio  pk_integracao.t_inforomaneio;
  
    procedure coletarDadosIniciais is
    begin
      begin
        select t.idnotafiscalsaida, t.status, nf.iddepositante
          into v_idnotasaida, v_transfstatus, v_iddepositantesaida
          from transferenciatitularidade t, notafiscal nf
         where t.idtransferencia = p_idTransferencia
           and nf.idnotafiscal = t.idnotafiscalsaida;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada nenhuma Transferência de Titularidade com ID: {0}');
          v_msg.addParam(p_idTransferencia);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_transfstatus <> C_STATUS_AG_RESERVA_ESTOQUE) then
        v_msg := t_message('Esta Transferência de Titularidade possui ' ||
                           'status inadequado para este tipo de operação ({0}). ' ||
                           'Para continuar, selecione uma transferência com ' ||
                           'status Aguardando Reserva de Estoque(1).');
        v_msg.addParam(v_transfstatus);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Buscando configuração de onda de Transferência de Titularidade
      -- Essa configuração de onda deverá ser única para o depositante
      begin
        select c.idconfiguracaoonda, do.identidade
          into v_idconfiguracaoonda, v_iddepositantesaida
          from configuracaoonda c, depositanteonda do, notafiscal nf
         where c.transferenciatitularidade = 1
           and do.idconfiguracaoonda = c.idconfiguracaoonda
           and nf.idnotafiscal = v_idnotasaida
           and do.identidade = nf.iddepositante;
      exception
        when too_many_rows then
          v_msg := t_message('Foram encontradas mais de uma configuração de onda de Transferência de Titularidade o depositante ID: {0}' ||
                             ' da Nota Fiscal de saída ID: {1}. Este comportamento não é permitido. Operação cancelada.');
          v_msg.addParam(v_iddepositantesaida);
          v_msg.addParam(v_idnotasaida);
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          v_msg := t_message('Não foi encontrada nenhuma configuração de onda de Transferência de Titularidade para o depositante ID: {0}. Operação cancelada.');
          v_msg.addParam(v_iddepositantesaida);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end coletarDadosIniciais;
  
    procedure inserirNotaFiscalGtt is
    begin
      -- Este fluxo trabalha apenas com uma nota por vez
      insert into gtt_propriedade
        (propriedade, valor1)
      values
        ('NOTA_FISCAL', v_idnotasaida);
    end inserirNotaFiscalGtt;
  
  begin
    coletarDadosIniciais;
  
    -- Inserindo nota de saída na gtt_propriedade, utilizada pela formação da onda
    inserirNotaFiscalGtt;
  
    -- Executando formação da onda
    v_resultadoFormacao := pk_onda.formarOnda(v_idonda, p_idArmazem,
                                              v_idconfiguracaoonda,
                                              'ONDA DE TRANSFERENCIA DE TITUALARIDADE - ID TRANSF: ' ||
                                               p_idTransferencia, p_idUsuario,
                                              C_ORIGEM_FORMACAO_TRANSF);
    --Validando formação da onda
    if (v_resultadoFormacao <> RESULTADO_ONDA_FORMADA) then
      v_msg := t_message('Erro na formação da onda. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select *
      into r_onda
      from romaneiopai rp
     where rp.idromaneio = v_idonda;
  
    if (r_onda.statusonda = C_STATUS_ONDA_CORTE) then
      v_msg := t_message('Não foi possível executar essa ação pois ' ||
                         'existe corte de estoque na nota fiscal de saída ID: {0}.' ||
                         ' Verifique os locais onde os produtos ' ||
                         'estão alocados e se a configuração de onda contempla o uso desses locais.' ||
                         ' Operação cancelada.');
      v_msg.addParam(v_idnotasaida);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (r_onda.statusonda <> C_STATUS_ONDA_FORMADA) then
      v_msg := t_message('Não é possivel liberar a onda da transferência de titularidade ID: {0}' ||
                         ' pois seu status esta diferente de GERADA. ' ||
                         'Provavelmente ocorreu algum erro na formação. ' ||
                         ' Operação cancelada.');
      v_msg.addParam(r_onda.idromaneio);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Liberando a onda para expedicao
    r_onda.statusonda    := C_STATUS_ONDA_LIBERADA;
    r_onda.dataliberacao := sysdate;
  
    update romaneiopai rp
       set row = r_onda
     where rp.idromaneio = r_onda.idromaneio;
  
    -- Realizando Separação da Onda gerada
    update movimentacao m1
       set m1.status         = 2, -- Movimentacao Concluida
           m1.idusuario      = p_idUsuario,
           m1.qtdeconferida  = round(m1.qtdemovimentada, 6),
           m1.datainicio     = sysdate,
           m1.datatermino    = sysdate,
           m1.fluxousavolume = 0,
           m1.tiposeparacao  = 1 -- Separação Manual
     where exists (select 1
              from movimentacao m, local lo, local ld
             where m.idonda = r_onda.idromaneio
               and m.status in (0, 1)
               and m.idlocalorigem = m.idlocaldestino
               and m.idlocalorigem = lo.id
               and m.idlocaldestino = ld.id
               and m.id = m1.id);
  
    update saidapornf s
       set s.separacaoiniciada   = s.qtdeseparada,
           s.conferenciainiciada = s.qtdeconferida
     where s.idonda = r_onda.idromaneio;
  
    pk_triggers_control.disableTrigger('T_INSERIR_NFROMANEIO');
  
    -- Realizando Conferencia
    update nfromaneio nr
       set nr.baixado              = 'S',
           nr.conferido            = 'S',
           nr.idusuarioconferencia = p_idUsuario,
           nr.dataconferencia      = sysdate
     where nr.idromaneio = r_onda.idromaneio
       and nr.idnotafiscal = v_idnotasaida;
  
    pk_triggers_control.enableTrigger('T_INSERIR_NFROMANEIO');
  
    -- Onda em execução
    -- Recuperando dados da onda novamente por conta
    -- das alteracoes realizadas pelas triggers
    select *
      into r_onda
      from romaneiopai rp
     where rp.idromaneio = r_onda.idromaneio;
  
    r_onda.statusonda             := 4;
    r_onda.datainicioseparacao    := sysdate;
    r_onda.motivoliberacaopesagem := 'Transferencia de Titularidade';
    r_onda.dataliberacaoonda      := sysdate;
  
    update romaneiopai r
       set row = r_onda
     where r.idromaneio = r_onda.idromaneio;
  
    begin
      select nf.*
        into r_nffaturamento
        from notafiscal nf, transferenciatitularidade t
       where t.idtransferencia = p_idTransferencia
         and nf.idnotafiscal = t.idnotafiscalsaida;
    exception
      when no_data_found then
        r_nffaturamento.idnotafiscal := null;
    end;
  
    -- Realizando Integração com o Faturamento
    if (r_nffaturamento.idnotafiscal is not null and
       r_nfFaturamento.tiponf = 'P') then
    
      v_idusuariointegr := pk_usuario.getIdUsusarioIntegracao;
    
      r_inforomaneio.idarmazem            := r_onda.idarmazem;
      r_inforomaneio.idromaneio           := r_onda.idromaneio;
      r_inforomaneio.codigointerno        := r_onda.codigointerno;
      r_inforomaneio.tituloromaneio       := r_onda.tituloromaneio;
      r_inforomaneio.tipo                 := r_onda.tipo;
      r_inforomaneio.separado             := r_onda.separado;
      r_inforomaneio.pesagemliberada      := r_onda.pesagemliberada;
      r_inforomaneio.idusuarioconferencia := r_onda.idusuarioconferencia;
      r_inforomaneio.statusonda           := r_onda.statusonda;
    
      pk_integracao.envioFaturamento(r_nffaturamento, v_idusuariointegr,
                                     r_inforomaneio);
    
      select nf.*
        into r_nffaturamento
        from notafiscal nf, transferenciatitularidade t
       where t.idtransferencia = p_idTransferencia
         and nf.idnotafiscal = t.idnotafiscalsaida;
    
      if (r_nffaturamento.Enviadofaturamento <> 'S') then
        v_msg := t_message('Ocorreu um erro ao enviar o pedido ID: {0}' ||
                           ' para o faturamento. Operação cancelada.');
        v_msg.addParam(r_nffaturamento.idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Atualizando status após enviar pedido para faturamento
      update transferenciatitularidade t
         set t.status           = C_STATUS_AG_FATURAMENTO,
             t.idusuarioreserva = p_idUsuario,
             t.datareserva      = sysdate
       where t.idtransferencia = p_idTransferencia;
    else
      -- Marcando nota fiscal como impressa
      update notafiscal nf
         set nf.impresso      = 'S',
             nf.dataimpressao = sysdate,
             nf.idusuarioimp  = p_idUsuario
       where nf.idnotafiscal = v_idnotasaida;
    
      -- Atualizando status da transferência com nota já faturada
      update transferenciatitularidade t
         set t.status           = C_STATUS_AG_DOC_ENTRADA,
             t.idusuarioreserva = p_idUsuario,
             t.datareserva      = sysdate
       where t.idtransferencia = p_idTransferencia;
    
      gerarNfEntrada(p_idArmazem, p_idUsuario, p_idTransferencia);
    
    end if;
  
    -- Finaliza atividade de separação gerada
    pk_convocacao.finalizaSeparacaoOnda(p_idUsuario, r_onda.idromaneio);
  
  end reservarEstoque;

  function isTransfTitularidade(p_idonda in number) return boolean is
    v_transftitularidade number;
  begin
    begin
      select co.transferenciatitularidade
        into v_transftitularidade
        from romaneiopai r, configuracaoonda co
       where r.idromaneio = p_idonda
         and co.idconfiguracaoonda = r.idconfiguracaoonda;
    exception
      when no_data_found then
        v_transftitularidade := 0;
    end;
  
    if (v_transftitularidade = 1) then
      return true;
    else
      return false;
    end if;
  end isTransfTitularidade;

  function getTransfTitularidadeStatus(p_idonda in number) return number is
    v_transftitularidadestatus number;
  begin
    begin
      select tt.status
        into v_transftitularidadestatus
        from nfromaneio nr, transferenciatitularidade tt
       where nr.idromaneio = p_idonda
         and tt.idnotafiscalsaida = nr.idnotafiscal
         and tt.status = C_AGUARDANDO_EFETIVACAO;
    exception
      when no_data_found then
        v_transftitularidadestatus := null;
    end;
  
    return v_transftitularidadestatus;
  end getTransfTitularidadeStatus;

  procedure transTitularidadeFaturamento(p_idNotaFiscal in number) is
    TRANSFERENCIA_TITULARIDADE constant number := 1;
  
    v_idtransferencia           number;
    v_statustitularidade        number;
    v_transferenciatitularidade number := 1;
    v_msg                       t_message;
    v_idUsuario                 usuario.idusuario%type;
    v_idArmazem                 armazem.idarmazem%type;
  begin
  
    begin
      select tt.idtransferencia, tt.status, nf.idarmazem
        into v_idtransferencia, v_statustitularidade, v_idArmazem
        from transferenciatitularidade tt, notafiscal nf
       where tt.idnotafiscalsaida = p_idNotaFiscal
         and tt.idnotafiscalsaida = nf.idnotafiscal
         and tt.status <> C_STATUS_CANCELADO;
    exception
      when no_data_found then
        v_transferenciatitularidade := 0;
    end;
  
    if (v_transferenciatitularidade = TRANSFERENCIA_TITULARIDADE) then
    
      if (v_statustitularidade <> C_STATUS_AG_FATURAMENTO) then
        v_msg := t_message('A Nota Fiscal [idNOtafistal: {0} ] está com status diferente de Aguardando Faturamento.' ||
                           ' Faturamento não permitido.');
        v_msg.addParam(p_idNotaFiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      update transferenciatitularidade t
         set t.status = C_STATUS_AG_DOC_ENTRADA
       where t.idtransferencia = v_idtransferencia;
    
      v_idUsuario := pk_usuario.getIdUsusarioIntegracao;
    
      gerarNfEntrada(v_idArmazem, v_idUsuario, v_idTransferencia);
    
    end if;
  
  end transTitularidadeFaturamento;

  procedure efetivarTransferencia
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  ) is
    v_idonda       number;
    v_identidadeOr number;
    v_idLoteNf     number;
    v_conf         number;
    v_msg          t_message;
    v_idnotasaida  number;
  
    procedure validarTransferencia is
      v_statustransferencia number;
    begin
      begin
        select t.idnotafiscalsaida, t.status
          into v_idnotasaida, v_statustransferencia
          from transferenciatitularidade t
         where t.idtransferencia = p_idTransferencia;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada nenhum Transferência de Titularidade com o ID: {0}');
          v_msg.addParam(p_idTransferencia);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_statustransferencia <> C_STATUS_AG_EFETIVACAO) then
        v_msg := t_message('A Transferência de Titularidade com o ID: {0}' ||
                           ' não pôde ser efetivada pois possui status diferente' ||
                           ' de "Aguardando Efetivação".');
        v_msg.addParam(p_idTransferencia);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      begin
        select distinct nr.idromaneio
          into v_idonda
          from nfromaneio nr
         where nr.idnotafiscal = v_idnotasaida;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada onda criada com a Nota Fiscal de saída ID: {0}' ||
                             'vinculada à Transferência de Titularidade selecionada ID: {1}.' ||
                             ' Operação cancelada.');
          v_msg.addParam(v_idnotasaida);
          v_msg.addParam(p_idTransferencia);
          raise_application_error(-20000, v_msg.formatMessage);
        when too_many_rows then
          v_msg := t_message('A Nota Fiscal de saída ID: {0} está vinculada a movimentações referentes a 2 ou mais ondas diferentes. Operação cancelada.');
          v_msg.addParam(v_idnotasaida);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end validarTransferencia;
  
    procedure cadastrarOr is
      v_idtiporecebimento number;
    begin
      select d.identidade, d.idtiporecebimentotransf
        into v_identidadeOr, v_idtiporecebimento
        from transferenciatitularidade tt, notafiscal nf, depositante d
       where tt.idtransferencia = p_idtransferencia
         and nf.idnotafiscal = tt.idnotafiscalentrada
         and d.identidade = nf.iddepositante;
    
      if (v_idtiporecebimento is null) then
        v_msg := t_message('Não foi encontrado nenhum Tipo de Recebimento de Transferência de Titularidade vinculado ao depositante ID: {0}');
        v_msg.addParam(v_identidadeOr);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Inserindo Ordem de Recebimento
      insert into lotenf
        (idlotenf, data, idusuario, idarmazem, idtiporecebimento,
         identidade, status, escaneado, digitado, recontagem, formado,
         regeitado, mapaaloc, cadloteliberado, flaglibnf, erp, cadloteaut,
         faltamalocar)
      values
        (seq_lotenfiscal.nextval, sysdate, p_idusuario, p_idarmazem,
         v_idtiporecebimento, v_identidadeOr, 'N', 'N', 'N', 'S', 'S', 'N',
         'N', 'N', 0, 'N', 'N', -1)
      returning idlotenf into v_idLoteNf;
    
      -- Vinculando Nota Fiscal de Entrada
      update notafiscal
         set idlotenf = v_idLoteNf
       where idnotafiscal =
             (select tt.idnotafiscalentrada
                from transferenciatitularidade tt
               where tt.idtransferencia = p_idtransferencia);
    
    end cadastrarOr;
  
    procedure cadastrarBacklist is
      v_countbacklist number;
      v_qtdeatendida  number;
      v_qtderestante  number;
    begin
    
      select count(*)
        into v_countbacklist
        from transferenciatitularidade tt, nfdet nd, backlist b
       where tt.idtransferencia = p_idtransferencia
         and nd.nf = tt.idnotafiscalentrada
         and b.idnfdet = nd.idnfdet;
    
      if (v_countbacklist > 0) then
        return;
      end if;
    
      v_qtdeatendida := 0;
    
      -- Busca todos os lotes utilizados na expedição da nota de saída da
      -- transferência de titularidade que está sendo efetivada.
      for c_estoque in (select m.id, lt.idproduto, lt.descr loteindustria,
                               lt.dtvenc dtvencimento, lt.dtfabricacao,
                               m.quantidade
                          from transferenciatitularidade tt, movimentacao m,
                               lote lt
                         where tt.idtransferencia = p_idtransferencia
                           and m.idnotafiscal = tt.idnotafiscalsaida
                           and lt.idlote = m.idlote
                           and lt.descr is not null)
      loop
        -- Busca NFDETs não atendidas completamente pelo Backlist
        -- qtderestante: quantidade ainda não atendida pelo backlist nesta NFDET.
        for c_nfdet in (select nd.idnfdet,
                               (nd.qtde - nvl(sum(bl.qtde), 0)) qtderestante
                          from transferenciatitularidade tt, nfdet nd,
                               backlist bl
                         where tt.idtransferencia = p_idtransferencia
                           and nd.nf = tt.idnotafiscalentrada
                           and nd.idproduto = c_estoque.idproduto
                           and nd.idnfdet not in
                               (select n.idnfdet
                                  from nfdet n, backlist b
                                 where n.nf = tt.idnotafiscalentrada
                                   and b.idnfdet = n.idnfdet having
                                 sum(b.qtde) = n.qtde
                                 group by n.idnfdet, n.qtde)
                           and bl.idnfdet(+) = nd.idnfdet
                         group by nd.idnfdet, nd.qtde)
        loop
          if v_qtdeatendida < c_estoque.quantidade then
            if c_nfdet.qtderestante < c_estoque.quantidade then
              v_qtderestante := c_nfdet.qtderestante;
            else
              v_qtderestante := c_estoque.quantidade;
            end if;
          
            insert into backlist
              (id, idnfdet, idusuario, loteindustria, qtde, dtfabricacao,
               vencimento)
            values
              (seq_backlist.nextval, c_nfdet.idnfdet, p_idusuario,
               c_estoque.loteindustria, v_qtderestante,
               c_estoque.dtfabricacao, c_estoque.dtvencimento);
          
            v_qtdeatendida := v_qtdeatendida + v_qtderestante;
          end if;
        end loop;
      
        if (v_qtdeatendida <> c_estoque.quantidade) then
          v_msg := t_message('Erro na criação dos Backlists. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        v_qtdeatendida := 0;
      
      end loop;
    end cadastrarBacklist;
  
    procedure gerarLoteAlocacao
    (
      p_idcontagem      number,
      p_idlocalalocacao local.idlocal%type
    ) is
      r_lote           lote%rowtype;
      v_idmapaalocacao number;
    
      C_SIM                 constant char(1) := 'S';
      C_NAO                 constant char(1) := 'N';
      C_AGUARDANDO          constant char(1) := 'A';
      C_TIPOLOTE            constant char(1) := 'L';
      C_SITUACAO_RECEBIDO   constant char(1) := 'R';
      C_TIPOPALLET_COMPLETO constant char(1) := 'C';
    begin
    
      select ced.idproduto, ced.barra, nf.iddepositante, ced.estado,
             p_idUsuario, C_TIPOLOTE, C_SITUACAO_RECEBIDO, ced.qtde,
             C_TIPOPALLET_COMPLETO, ced.descrlote, ced.datavencto,
             ced.datafabricacao, sysdate
        into r_lote.idproduto, r_lote.barra, r_lote.iddepositante,
             r_lote.estado, r_lote.idusuario, r_lote.tipolote,
             r_lote.situacao, r_lote.qtdeentrada, r_lote.tipopalet,
             r_lote.descr, r_lote.dtvenc, r_lote.dtfabricacao,
             r_lote.dtentrada
        from conferenciaentradadet ced, notafiscal nf
       where ced.idcontagem = p_idcontagem
         and nf.idlotenf = ced.idlotenf;
    
      if (pk_lote.isLoteIndustriaComMaisDeUmVenc(r_lote.iddepositante,
                                                 r_lote.idproduto,
                                                 r_lote.descr, r_lote.dtvenc)) then
        raise_application_error(-20000,
                                'Não é possível cadastrar lote do mesmo produto/depositante com o mesmo lote indústria e data de vencimento diferentes. Depositante:' ||
                                 r_lote.iddepositante || '. Produto: ' ||
                                 r_lote.idproduto || ' Lote Indústria: ' ||
                                 r_lote.descr || ' Data Venc: ' ||
                                 r_lote.dtvenc);
      
      end if;
    
      r_lote.idlote := pk_lote.cadastrar_lote(r_lote, v_idlotenf, C_SIM);
    
      select seq_mapaalocacao.nextval
        into v_idmapaalocacao
        from dual;
    
      insert into mapaalocacao
        (idalocacao, idusuario, idlote, idarmazem, idlocal, qtde, data,
         status, descr)
      values
        (v_idmapaalocacao, p_idusuario, r_lote.idlote, p_idArmazem,
         p_idlocalalocacao, r_lote.qtdeentrada, sysdate, C_AGUARDANDO,
         'TRANSFERENCIA TITULARIDADE: ' || p_idTransferencia);
    
      pk_alocacao.alocar_mapaalocacao(v_idmapaalocacao, p_idusuario, C_NAO);
    
    end gerarLoteAlocacao;
  
    procedure gerarCoberturaFiscal is
      v_classificacao char(1);
    begin
      select tr.classificacao
        into v_classificacao
        from lotenf lnf, tiporecebimento tr
       where lnf.idlotenf = v_idlotenf
         and tr.idtiporecebimento = lnf.idtiporecebimento;
    
      if (v_classificacao <> 'A') then
        pk_coberturafiscal.GerarCoberturaLote(v_idlotenf);
      end if;
    
    end gerarCoberturaFiscal;
  
    procedure gerarConferenciaLotesAlocacao is
      v_idcontagem  number;
      v_faltaalocar number;
    
      procedure validarParametrizacao
      (
        p_idproduto         lote.idproduto%type,
        p_idlocaldestino    local.id%type,
        p_iddepositantedest local.iddepositante%type,
        p_idArmazem         local.idarmazem%type
      ) is
      
        v_parametrizarTransf number;
        v_produtoDepositante produtodepositante%rowtype;
      
        C_NAO_PARAMETRIZAR constant number := 0;
      
        cursor crs_setorDep is
          select lc.idsetor, std.iddepositante, st.descr
            from local lc, setor st, setordepositante std
           where lc.id = p_idlocaldestino
             and lc.idsetor = st.idsetor
             and lc.idsetor = std.idsetor(+)
             and p_iddepositantedest = std.iddepositante(+)
             and std.iddepositante is null;
      
        cursor crs_setorProd is
          select lc.idsetor, stp.idproduto, st.descr
            from local lc, setor st, setorproduto stp
           where lc.id = p_idlocaldestino
             and lc.idsetor = st.idsetor
             and lc.idsetor = stp.idsetor(+)
             and p_idproduto = stp.idproduto(+)
             and stp.idproduto is null;
      
        cursor crs_prodDepositante is
          select a.idproduto, a.descr, a.idDepositante, a.razaosocial,
                 pd.idproduto idprodutoDepositante
            from (select p.idproduto, p.descr, e.identidade idDepositante,
                          e.razaosocial
                     from produto p, entidade e
                    where p.idproduto = p_idproduto
                      and e.identidade = p_iddepositantedest) a,
                 produtodepositante pd
           where a.idproduto = pd.idproduto(+)
             and a.idDepositante = pd.identidade(+)
             and pd.idproduto is null;
      
      begin
      
        select dp.parametrizartransftitularidade
          into v_parametrizarTransf
          from depositante dp
         where dp.identidade = p_iddepositantedest;
      
        for c_std in crs_setorDep
        loop
          if (v_parametrizarTransf = C_NAO_PARAMETRIZAR) then
            v_msg := t_message('Depositante [idDepositante: {0}] não vinculado ao setor: {1}');
            v_msg.addParam(p_iddepositantedest);
            v_msg.addParam(c_std.idsetor || ' - ' || c_std.descr);
            raise_application_error(-20000, v_msg.formatMessage);
          else
            insert into setordepositante
              (idsetor, iddepositante)
            values
              (c_std.idsetor, p_iddepositantedest);
          end if;
        end loop;
      
        for c_stp in crs_setorProd
        loop
          if (v_parametrizarTransf = C_NAO_PARAMETRIZAR) then
            v_msg := t_message('Produto [idProduto: {0}] não vinculado ao setor: {1}');
            v_msg.addParam(p_idProduto);
            v_msg.addParam(c_stp.idsetor || ' - ' || c_stP.descr);
            raise_application_error(-20000, v_msg.formatMessage);
          else
            insert into setorproduto
              (idproduto, idsetor, prioridade)
            values
              (p_idProduto, c_stp.idsetor, 1);
          end if;
        end loop;
      
        for c_pd in crs_prodDepositante
        loop
          if (v_parametrizarTransf = C_NAO_PARAMETRIZAR) then
            v_msg := t_message('Produto [idProduto: {0}] não vinculado ao Depositante: {1}');
            v_msg.addParam(p_idProduto || ' - ' || c_pd.descr);
            v_msg.addParam(c_pd.idDepositante || ' - ' || c_pd.razaosocial);
            raise_application_error(-20000, v_msg.formatMessage);
          else
          
            select pd.*
              into v_produtoDepositante
              from notafiscal nf, produtodepositante pd
             where nf.idnotafiscal = v_idnotasaida
               and nf.iddepositante = pd.identidade
               and pd.idproduto = p_idproduto;
          
            v_produtoDepositante.Identidade := p_iddepositantedest;
          
            pk_entidade.CadastrarProdutoDepositante(v_produtoDepositante);
          
          end if;
        end loop;
      
      end validarParametrizacao;
    
    begin
      pk_recebimento.validarOrdemServico(v_idLoteNf);
      pk_recebimento.validarGeracaoContagem(v_idlotenf);
    
      insert into conferenciaentrada
        (idconferenciaentrada, idlotenf, data, idusuario)
      values
        (1, v_idlotenf, sysdate, p_idusuario)
      returning idconferenciaentrada into v_conf;
    
      select count(*)
        into v_faltaalocar
        from transferenciatitularidade tt, notafiscal nf, movimentacao m,
             lote lt, local l
       where tt.idtransferencia = p_idtransferencia
         and nf.idnotafiscal = tt.idnotafiscalsaida
         and m.idnotafiscal = nf.idnotafiscal
         and m.idonda = v_idonda
         and lt.idlote = m.idlote
         and l.id = m.idlocaldestino;
    
      update lotenf l
         set l.faltamalocar = v_faltaalocar
       where l.idlotenf = v_idlotenf;
    
      for c_estoque in (select lt.idproduto, lt.barra,
                               pk_produto.RetornarCodBarraMenorFator(lt.idproduto) barraunitaria,
                               lt.estado,
                               trunc(m.quantidade / lt.fatorconversao) quantidade,
                               mod(m.quantidade, lt.fatorconversao) resto,
                               lt.descr loteindustria,
                               decode(pd.coletadtavenclote, 1, lt.dtvenc, 3,
                                       lt.dtvenc, null) vencimento,
                               decode(pd.coletadtavenclote, 2,
                                       lt.dtfabricacao, 3, lt.dtfabricacao,
                                       null) fabricacao, lt.numerovolume,
                               lt.itemadicional, lt.loteadicional,
                               m.id idmovimentacao, l.idlocal idlocaldestino,
                               e.fatorconversao,
                               p.fracionado produtoFracionado,
                               nfe.iddepositante idDepositanteDest,
                               l.id localDestino
                          from transferenciatitularidade tt, notafiscal nf,
                               movimentacao m, lote lt, local l,
                               produtodepositante pd, embalagem e, produto p,
                               notafiscal nfe
                         where tt.idtransferencia = p_idtransferencia
                           and nf.idnotafiscal = tt.idnotafiscalsaida
                           and m.idnotafiscal = nf.idnotafiscal
                           and m.idonda = v_idonda
                           and lt.idlote = m.idlote
                           and l.id = m.idlocaldestino
                           and pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante
                           and e.idproduto = lt.idproduto
                           and e.barra = lt.barra
                           and lt.idproduto = p.idproduto
                           and tt.idnotafiscalentrada = nfe.idnotafiscal)
      loop
      
        validarParametrizacao(c_estoque.idproduto, c_estoque.localDestino,
                              c_estoque.iddepositantedest, p_idArmazem);
      
        if (c_estoque.quantidade > 0) then
          pk_confentrada.p_gravar_conferencia(p_idusuario, v_idlotenf,
                                              v_conf, c_estoque.idproduto,
                                              c_estoque.barra,
                                              c_estoque.estado,
                                              c_estoque.quantidade,
                                              c_estoque.vencimento,
                                              c_estoque.loteindustria, 'N',
                                              0, v_idcontagem,
                                              c_estoque.numerovolume,
                                              c_estoque.itemadicional, null,
                                              null, c_estoque.fabricacao,
                                              c_estoque.loteadicional);
        
          gerarLoteAlocacao(v_idcontagem, c_estoque.idlocaldestino);
        end if;
      
        if (c_estoque.resto > 0) then
          pk_confentrada.p_gravar_conferencia(p_idusuario, v_idlotenf,
                                              v_conf, c_estoque.idproduto,
                                              c_estoque.barraunitaria,
                                              c_estoque.estado,
                                              c_estoque.resto,
                                              c_estoque.vencimento,
                                              c_estoque.loteindustria, 'N',
                                              0, v_idcontagem,
                                              c_estoque.numerovolume,
                                              c_estoque.itemadicional, null,
                                              null, c_estoque.fabricacao,
                                              c_estoque.loteadicional);
        
          gerarLoteAlocacao(v_idcontagem, c_estoque.idlocaldestino);
        end if;
      
      end loop;
    
      update conferenciaentradadet
         set automatico = 'S',
             status     = 'S'
       where idconferenciaentrada = v_conf
         and idlotenf = v_idlotenf;
    
      update conferenciaentrada
         set finalizada = 'S',
             idusuario  = p_idusuario,
             data       = sysdate
       where idlotenf = v_idlotenf
         and idconferenciaentrada = v_conf;
    
      update lotenf ln
         set ln.flaglibnf            = 2,
             ln.cadloteliberado      = 'S',
             ln.cadloteaut           = 'S',
             ln.datageracaolote      = sysdate,
             ln.idusuariogeracaolote = p_idusuario
       where ln.idlotenf = v_idlotenf;
    
      gerarCoberturaFiscal;
    
    end gerarConferenciaLotesAlocacao;
  
    procedure finalizarTransfTitularidade is
      v_qtderestante number;
    begin
      select sum(lt.qtdeentrada) - sum(lt.qtdealocada) restante
        into v_qtderestante
        from lote lt, orlote ol
       where lt.idlote = ol.idlote
         and ol.idlotenf = v_idLoteNf;
    
      if (v_qtderestante > 0) then
        v_msg := t_message('Não é permitido finalizar a Transferência' ||
                           ' de Titularidade a quantidade alocada referentes' ||
                           ' aos novos lotes gerados não é igual à quantidade' ||
                           ' de entrada desses lotes. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Finalizando OR e Nota de Entrada
      update lotenf
         set status        = 'P',
             dtfimalocacao = sysdate,
             faltamalocar  = 0
       where idlotenf = v_idLoteNf;
    
      update notafiscal
         set statusnf = 'P'
       where idlotenf = v_idLoteNf;
    
      pk_integracao.exportarORAposAlocacao(v_idLoteNf);
      pk_integracao.expRetornoRecebimentoCE(v_idLoteNf);
    
      -- Atualizando a Transferência de Titularidade
      update transferenciatitularidade tt
         set tt.idusuariotransferencia = p_idusuario,
             tt.datatransferencia      = sysdate,
             tt.status                 = C_STATUS_CONCLUIDO
       where tt.idtransferencia = p_idtransferencia;
    
    end finalizarTransfTitularidade;
  begin
  
    validarTransferencia;
  
    --Processar a onda
    pk_onda.processarOnda(v_idonda, p_idUsuario);
  
    --Cadastrar a ordem de recebimento
    --Vincular a nota de entrada
    cadastrarOr;
  
    --Gerar Conferencia
    gerarConferenciaLotesAlocacao;
  
    --Concluir controle de transferência de titularidade
    finalizarTransfTitularidade;
  end;

  procedure cancelarTransferencia
  (
    p_idTransfTitularidade number,
    p_idUsuario            number
  ) is
    r_transfTitularidade transferenciatitularidade%rowtype;
    v_idPrenfEntrada     number;
    v_geraNfEntrada      number;
    v_msg                t_message;
  
    procedure carregarTransfTitularidade is
    begin
      begin
        select *
          into r_transfTitularidade
          from transferenciatitularidade t
         where t.idtransferencia = p_idTransfTitularidade;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada nenhuma Transferência de Titularidade com ID: {0}. Operação cancelada.');
          v_msg.addParam(p_idTransfTitularidade);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end;
  
    procedure voltarNFLiberada(p_idonda in number) is
      v_nomeUsuario usuario.nomeusuario%type;
    begin
      insert into gtt_selecao
        (idselecionado)
      values
        (r_transfTitularidade.Idnotafiscalsaida);
    
      pk_notafiscal.voltarNFLiberada(p_idUsuario);
    
      select u.nomeusuario
        into v_nomeUsuario
        from usuario u
       where u.idusuario = p_idUsuario;
    
      if (p_idonda is null) then
        pk_utilities.GeraLog(p_idUsuario,
                             'Usuário ' || v_nomeUsuario || ' (' ||
                              p_idUsuario ||
                              ') cancelou a Transferência de Titularidade ID: ' ||
                              p_idTransfTitularidade ||
                              ' com a Nota Fiscal ID: ' ||
                              r_transfTitularidade.Idnotafiscalsaida,
                             r_transfTitularidade.Idtransferencia, 'TT');
      else
        pk_utilities.GeraLog(p_idUsuario,
                             'Usuário ' || v_nomeUsuario || ' (' ||
                              p_idUsuario ||
                              ') cancelou a Transferência de Titularidade ID: ' ||
                              p_idTransfTitularidade ||
                              ' com a Nota Fiscal ID: ' ||
                              r_transfTitularidade.Idnotafiscalsaida ||
                              ' e Onda ID: ' || p_idonda,
                             r_transfTitularidade.Idtransferencia, 'TT');
      end if;
    end;
  
    procedure cancelarOnda is
      v_idonda number;
    begin
      begin
        select nfr.idromaneio
          into v_idonda
          from nfromaneio nfr
         where nfr.idnotafiscal = r_transfTitularidade.Idnotafiscalsaida;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada onda para a Nota Fiscal ID: {0}' ||
                             ' da Transferência de Titularidade ID: {1}' ||
                             '. Operação cancelada.');
          v_msg.addParam(r_transfTitularidade.Idnotafiscalsaida);
          v_msg.addParam(p_idTransfTitularidade);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      pk_onda_cancelar.cancelarOnda(v_idonda, p_idusuario, 3);
    
      --atualiza para aguardando reserva de estoque para conseuigr voltar a nota para aguardando liberação
      update transferenciatitularidade t
         set t.status = C_STATUS_AG_RESERVA_ESTOQUE
       where t.idtransferencia = p_idTransfTitularidade;
    
      --chama a rotina para voltar a nota para aguardando liberação e cancela a transferência de titularidade
      voltarNFLiberada(v_idonda);
    end;
  
  begin
    carregarTransfTitularidade;
  
    if (r_transfTitularidade.Status in
       (C_STATUS_CANCELADO, C_STATUS_CONCLUIDO)) then
      v_msg := t_message('Esta Transferência de Titularidade possui status inadequado para este tipo de operação ({0}).' ||
                         ' Para continuar, selecione uma transferência com status diferente de "Cancelado(0)" e "Concluído(5)".');
      v_msg.addParam(r_transfTitularidade.Status);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (r_transfTitularidade.Idnotafiscalentrada is not null) then
    
      select nf.idprenf, d.gerarnfenttransftitularidade
        into v_idPrenfEntrada, v_geraNfEntrada
        from notafiscal nf, depositante d
       where nf.iddepositante = d.identidade
         and nf.idnotafiscal = r_transfTitularidade.Idnotafiscalentrada;
    
      desvinculaNotaEntrada(p_idTransfTitularidade,
                            r_transfTitularidade.Idnotafiscalentrada,
                            p_idUsuario);
    
      if (v_geraNfEntrada > 0) then
        pk_notafiscal.excluirNotaFiscal(v_idPrenfEntrada, p_idUsuario);
      end if;
    
    end if;
  
    if (r_transfTitularidade.Status = C_STATUS_AG_RESERVA_ESTOQUE) then
      voltarNFLiberada(null);
    else
      cancelarOnda;
    end if;
  
  end;

  procedure gerarNfEntrada
  (
    p_idArmazem       in number,
    p_idUsuario       in number,
    p_idTransferencia in number
  ) is
  
    v_idDesposintateDest entidade.identidade%type;
    v_gerarNF            depositante.gerarnfenttransftitularidade%type;
    v_idNFSaida          notafiscal.idnotafiscal%type;
    v_idNFEntrada        notafiscal.idnotafiscal%type;
    v_msg                t_message;
  
  begin
    -- validar se destinatário é depositante
    select nf.idnotafiscal, d.identidade,
           nvl(d.gerarnfenttransftitularidade, 0), tt.idnotafiscalentrada
      into v_idNFSaida, v_idDesposintateDest, v_gerarNF, v_idNFEntrada
      from transferenciatitularidade tt, notafiscal nf, depositante d
     where tt.idnotafiscalsaida = nf.idnotafiscal
       and tt.status <> 0
       and tt.idtransferencia = p_idTransferencia
       and nf.destinatario = d.identidade(+);
  
    if (v_idDesposintateDest is null) then
      v_msg := t_message('Não é possivel gerar Nota Fiscal de Entrada para o Destinatário [idEntidade: {0}], pois não é um Depositante.');
      v_msg.addParam(v_idDesposintateDest);
      raise_application_error(-20000, v_msg.formatMessage);
    else
      if (v_idNFEntrada is not null) then
        v_msg := t_message('Não é possivel gerar Nota Fiscal de Entrada, pois não a Transferência de Titularidade já possui Nota Fiscal de Entrada Vinculada.');
        raise_application_error(-20000, v_msg.formatMessage);
      else
        if (v_gerarNF = C_GERARNF_ENTRADA_SIM) then
          pk_notafiscal.p_gerarNFEntrada(v_idNFSaida, 'N', p_idUsuario);
        end if;
      end if;
    
    end if;
  
  end gerarNfEntrada;
end pk_transftitularidade;
/

