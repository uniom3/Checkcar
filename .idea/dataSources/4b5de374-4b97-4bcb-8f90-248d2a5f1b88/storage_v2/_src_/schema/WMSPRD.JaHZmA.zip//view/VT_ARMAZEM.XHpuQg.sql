create view VT_ARMAZEM as
select a.idarmazem IDARMAZEM, a.codigointerno, a.descr ARMAZEM,
       e.razaosocial ENTARMAZENAGEM, a.ativo,
       (select count(1)
           from dual
          where exists (select 1
                   from local l
                  where l.idarmazem = a.idarmazem
                    and l.tipo IN (0, 1, 2))) H$EXISTELOCAL
  from armazem a, entidade e
 where e.identidade(+) = a.identidade
/

