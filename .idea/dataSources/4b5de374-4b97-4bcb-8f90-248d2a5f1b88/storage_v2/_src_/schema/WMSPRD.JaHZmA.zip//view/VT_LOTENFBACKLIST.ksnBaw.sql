create view VT_LOTENFBACKLIST as
select x.h$tableid, x.h$idlotenf, x.h$idnfdeti, x.h$idBackList, x.idnfdet,
       x.idnotafiscal, x.notafiscal, x.serie, x.item, x.idproduto, x.codprod,
       x.DESCRICAO, x. loteindustria, x.dtfabricacao, x.dtvencimento, x.qtde,
       x.h$qtdNf
  from (select rownum h$tableid, nf.idlotenf h$idlotenf,
                ndi.idnfdeti h$idnfdeti, b.id h$idBackList, nd.idnfdet,
                nf.idnotafiscal,
                nvl(nf.codigointerno, nf.numpedidofornecedor) notafiscal,
                nf.sequencia serie, ndi.idseq item, p.idproduto,
                p.codigointerno codprod, p.descr DESCRICAO, b.loteindustria,
                to_char(b.dtfabricacao, 'dd/mm/yyyy') dtfabricacao,
                to_char(b.vencimento, 'dd/mm/yyyy') dtvencimento,
                (b.qtde * en.fatorconversao) qtde,
                (nd.qtde * en.fatorconversao) h$qtdNf
           from backlist b, nfdet nd, notafiscal nf, produto p,
                nfdetimpressao ndi, embalagem en, produtodepositante pd
          where b.idnfdet = nd.idnfdet
            and nd.nf = nf.idnotafiscal
            and nd.idproduto = p.idproduto
            and nd.idnfdet = ndi.idnfdet
            and nd.idproduto = en.idproduto
            and nd.barra = en.barra
            and nf.iddepositante = pd.identidade
            and nd.idproduto = pd.idproduto
            and pd.naocriticabacklist = 0
          order by b.loteindustria, b.idnfdet) x
/

