create view VT_LOCAL_CADASTRO_PICKING as
select l.idlocal, l.bloco, l.rua, l.predio, l.andar, l.apartamento,
       l.id h$idendereco, l.idarmazem h$idarmazem, l.ordem h$ordem,
       l.idlocalformatado f$idlocal
  from local l
 where l.ativo = 'S'
   and l.tipo = 0
   and l.buffer = 'N'
 order by l.idlocal
/

