create package pk_romaneio is

  -- Author  : LEANDRO
  -- Created : 24/11/2004 15:30:19
  -- Purpose : pakage contendo as rotinas ref. ao romaneio

  -- constaints publicas
  c_normal                    constant char(1) := 'N';
  c_liberado                  constant char(1) := 'L';
  c_sim                       constant char(1) := 'S';
  c_aguardando                constant char(1) := 'A';
  c_erro                      constant char(1) := 'E';
  c_importado                 constant char(1) := 'I';
  c_carga                     constant char(1) := 'C';
  c_processado                constant char(1) := 'P';
  c_par                       constant char(1) := 'P';
  c_impar                     constant char(1) := 'I';
  c_direita                   constant char(1) := 'D';
  c_esquerda                  constant char(1) := 'E';
  c_perc_tolerancia           constant number := 0.05;
  c_bom                       constant char(1) := 'N';
  c_nao                       constant char(1) := 'N';
  c_cancelado                 constant char(1) := 'X';
  c_recebido                  constant char(1) := 'R';
  c_finalizado                constant char(1) := 'F';
  c_selecionado               constant char(1) := 'S';
  c_retorno_armazenagem       constant char(2) := 'TA';
  c_reentrega                 constant char(1) := 'R';
  c_danificado                constant char(1) := 'D';
  c_truncado                  constant char(1) := 'T';
  c_desmontagem_kit           constant char(1) := 'D';
  c_montagem_kit              constant char(1) := 'K';
  C_NAO_NUMBER                constant number := 0;
  C_SIM_NUMBER                constant number := 1;
  C_ORDEM_DEVOLUCAO_CANCELADA constant number := 1;
  -- variaveis publicas
  v_idusuario number;
  v_estado    char(1);
  /*
  * Retorna as notas fiscais do romaneio
  */
  function Dados_NF_Romaneio
  (
    p_romaneio in number,
    p_campo    in number
  ) return clob;

  /*
  * rotina responsavel por retirar as notas fiscais do romaneio ao desfazer o romaneio
  */
  procedure retirarNFRomaneio
  (
    p_romaneio   in number,
    p_usuario    in number,
    p_voltanotas in char
  );

  /*
   * rotina responsavel por desfazer o romaneio.
  */
  procedure desfazer_romaneio
  (
    p_romaneio   in number,
    p_usuario    in number,
    p_commit     in romaneiopai.faturado%type,
    p_voltanotas in char := 'N'
  );

  /*
   * Atualiza os Dados da Carga
  */
  procedure atualizar_carga(p_carga in number);

  /*
   * Rotina responsavel por inserir as nfs dos depositantes no romaneio
  */
  procedure inserir_depositante_romaneio
  (
    p_romaneio    in out number,
    p_rota        in number,
    p_tipocarga   in varchar2,
    p_depositante in number,
    p_usuario     in number,
    p_ordem       in number
  );

  /*
   * Insere as Notas Fiscais ao Romaneio passando o tipo da carga
  */
  procedure inserir_nfromaneio_tipocarga
  (
    p_romaneio    in out number,
    p_entidade    in number,
    p_depositante in number,
    p_usuario     in number,
    p_tipocarga   in varchar2
  );

  /*
   * Insere as Notas Fiscais ao Romaneio
  */
  procedure inserir_nfromaneio
  (
    p_romaneio in out number,
    p_entidade in number,
    p_nf       in number,
    p_usuario  in number,
    p_seq      in number,
    p_commit   in varchar2 := 'S'
  );

  /*
   * Rotina que cadastra o romaneiopai
  */
  function inserir_romaneiopai(p_romaneio in romaneiopai%rowtype)
    return number;

  /*
   * Retorna o volume das notas fiscais pendentes para gerac?o
  */
  function vol_total_rota(p_rota in number) return number;

  /*
   * Exclui uma NF ou Todas as NFs do Cliente do Romaneio
  */
  procedure excluir_nfromaneio
  (
    p_romaneio in out number,
    p_entidade in number,
    p_nf       in number,
    p_usuario  in number
  );

  /*
   * Rotina Responsavel por alterar a ordem de entrega dos clientes
   * na formac?o de carga.
  */
  procedure alterar_ordem_entrega
  (
    p_romaneio in number,
    p_ent      in number,
    p_seq      in number,
    p_ordem    in number
  );

  /*
   * Sumariza o Romaneio baseando-se nas nfs vinculadas ao romaneio
  */
  procedure Atualizar_Produtos_Romaneio
  (
    p_romaneio in romaneiopai%rowtype,
    p_commit   in varchar2 := c_sim
  );

  /*
  * Rotina usada para ordenar as notas fiscais de acordo com a ordem de entrega
  * das rotas
  */
  procedure ordenar_notas_romaneio(p_romaneio in number);

  /*
   * Retorna o Volume total do romaneio, esta rotina simula a formac?o de carga.
   * Pegando as embalagens disponiveis e os volumes respectivos.
   * Ex. se pedir 5 display ao inves de calcular o volume dessas embalagens
   * o sistema calcula o volume de uma caixa (5 display = 1 caixa)
  */
  function vol_total_romaneio
  (
    p_romaneio  in number,
    p_segregado in varchar2
  ) return number;

  /*
   * Rotina responsavel por formar o romaneio, dependendo da configuracao
   * setada no sistema (tab. configuracao) o romaneio de separacao ja
   * sera criado.
  */
  procedure Formar_Romaneio
  (
    p_Romaneio       in number,
    p_Usuario        in number,
    p_GerarCarga     in varchar2,
    p_commit         in varchar2 := 'S',
    p_checarqtde     in char := 'S',
    p_estado         in char := 'X',
    p_atualizarprod  in char := 'S',
    p_veiculodoca    in char := 'S',
    p_gerarseparacao in varchar2 := 'S'
  );

  /*
   * Atualiza o Codigo do Romaneio
  */
  procedure Atualizar_Num_Romaneio(p_romaneio in out romaneiopai%rowtype);

  /*
   * Libera ou ocupa a doca e veiculo do romaneio
  */
  procedure alterar_veiculo_doca_romaneio(r_romaneio in romaneiopai%rowtype);

  /*
   * Gera as inf. de separacao do romaneio, como palet, mapa de separacao, produto por cliente, etc.
  */
  procedure criar_pallet_romaneio
  (
    p_romaneio       in out romaneiopai%rowtype,
    p_usuario        in number,
    p_estado         in lote.estado%type,
    p_commit         in varchar2 := c_sim,
    p_gerarseparacao in varchar2 := 'S'
  );

  procedure criarRemanejamento
  (
    p_idromaneio     in number,
    p_idarmazem      in number,
    p_idlocalorigem  in local.idlocal%type,
    p_idlocaldestino in local.idlocal%type,
    p_idusuario      in number,
    p_idlote         in number,
    p_qtdeabastecer  in number,
    p_commit         in char
  );

  /*
   * reabastece o picking para a formacao do romaneio
  */
  procedure reabastecer_picking
  (
    p_romaneio in number,
    p_usuario  in number,
    p_estado   in lote.estado%type,
    p_commit   in varchar2 := 'S'
  );

  /*
   * Apaga as informacoes do palet
  */
  procedure apagar_pallet_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * verifica a restricao de picking para os produtos do romaneio
   * verifica se os produtos possuem qtde de picking maior do que a permitida por depositante
  */
  procedure verificar_restricao_picking(p_romaneio in number);

  /*
   * Forma o palet, respeitando a ordem de entrega.
  */
  procedure formar_pallet_ordem_entrega
  (
    p_romaneio       in number,
    p_num_palet      in out number,
    p_nummaxpalet    in number,
    p_calc_num_palet in varchar2
  );

  /*
   * Distribui o peso entre os palets
  */
  procedure distribuir_peso_veiculo
  (
    p_romaneio  in number,
    p_recursivo in boolean,
    p_commit    in varchar2 := c_sim
  );

  procedure recalcularQtdePaletSeparacao(p_romaneio in number);

  /*
   * Rotina responsavel por localizar os enderecos disponiveis
   * no estoque e inserir na tabela paletseparacao ou separacaoespecifica
  */
  function preencher_pallet_separacao
  (
    p_romaneio       in number,
    p_pallet         in number,
    p_armazem        in number,
    p_depositante    in number,
    p_produto        in number,
    p_estado         in varchar2,
    p_qtde           in number,
    p_barra          in embalagem.barra%type,
    p_fatorconversao in number,
    p_usuario        in number,
    p_idlote         in number,
    p_identidade     in number,
    p_reentrega      in char,
    p_idlocal        in local.idlocal%type := ''
  ) return number;

  /*
   * Rotina responsavel por inserir a ordem de separacao por cliente (Separacao por Cliente)
  */
  procedure inserir_pallet_separacao_cli
  (
    p_romaneio in number,
    p_idpalet  in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_produto  in number,
    p_barra    in embalagem.barra%type,
    p_cliente  in number,
    p_qtde     in number,
    p_ordem    in number := null
  );

  /*
   * Rotina responsavel por inserir na tabela de palet separacao
  */
  procedure inserir_pallet_separacao
  (
    p_romaneio in number,
    p_idpalet  in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_lote     in number,
    p_produto  in number,
    p_barra    in embalagem.barra%type,
    p_qtde     in number,
    p_qtdeunit in number
  );

  /*
   * Insere os cortes do romaneio
  */
  procedure inserir_corte_romaneio
  (
    p_romaneio   in number,
    p_pallet     in number,
    p_armazem    in number,
    p_entidade   in number,
    p_produto    in number,
    p_barra      in embalagem.barra%type,
    p_qtdepedido in number,
    p_estado     in lote.estado%type,
    p_motivo     in varchar2
  );

  /*
   * Retorna o Estado de Lote que vai ser usado para a Geracao do Romaneio
  */
  function estado_notafiscal_romaneio(p_romaneio in number)
    return lote.estado%type;

  /*
   * Cria os palets para separacao
  */
  procedure criar_pallet_separacao
  (
    p_romaneio in out romaneiopai%rowtype,
    p_usuario  in number,
    p_estado   in lote.estado%type,
    p_commit   in varchar2 := c_sim
  );

  /*
   * Apaga os produtos que tiveram cortes no romaneio
  */
  procedure excluir_prod_cortado_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Insere os Produtos na tabela de informacoes de produtos no palet
  */
  procedure inserir_produto_palet
  (
    p_romaneio    in number,
    p_pallet      in number,
    p_depositante in number,
    p_cliente     in number,
    p_produto     in number,
    p_barra       in embalagem.barra%type,
    p_qtde        in number
  );

  /*
  * Retorna as Rotas em que o cliente esta inserido
  */
  function ret_rotacliente(p_idcliente in number) return string;

  function ret_codrotacliente(p_idcliente in number) return string;

  function ret_TelefRepres
  (
    p_idcliente  in number,
    p_idromaneio in number
  ) return string;

  function ret_NomeRepres
  (
    p_idcliente  in number,
    p_idromaneio in number
  ) return string;

  /*
   * Re-Ordena os Clientes na Rota
  */
  procedure ReOrdenarClienteRota(p_rota in number);

  /*
   * Processa romaneio
  */
  procedure processar_romaneio
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Carrega todos as informac?es da romaneiopai
  */
  function carregar_romaneio(p_romaneio in number) return romaneiopai%rowtype;

  /*
   * Processa romaneio a partir da carga
  */
  procedure processar_romaneio_carga
  (
    p_carga   in number,
    p_usuario in number,
    p_origem  in number,
    p_motivo  in number default -1
  );

  procedure finalizaVolumeColeta(p_carga in number);

  /*
   * Redistribui as qtdes do Pallet separacao nao deixando que fique qtde
   * quebradas
  */
  procedure redistribuir_qtde_separacao
  (
    p_romaneio in number,
    p_pallet   in number,
    p_lote     in number,
    p_armazem  in number,
    p_local    in local.idlocal%type,
    p_produto  in number,
    p_barra    in string,
    p_qtde     in number
  );

  /*
   * Verifica se e necessario a distribuicao das qtde de produto
   * no pallet de separacao Ex. 1,5cx = 1 caixa e 2 dp
  */
  procedure verificar_qtde_separacao(p_romaneio in number);

  /*
  * Func?o que retorna que paleto o cliente esta
  */
  function cliente_palet
  (
    p_romaneio in number,
    p_entidade in number
  ) return varchar2;

  /*
   * Responsavel por ordenar a separacao dos palets
  */
  procedure ordenar_palet_separacao(p_romaneio in number);
  /*
   * Insere Uma Nova Carga
  */
  function Inserir_Carga
  (
    p_romaneio   in romaneiopai%rowtype,
    p_usuario    in number,
    p_gerarcarga in varchar2
  ) return number;

  function pegar_romaneios(p_coleta in number) return varchar2;

  /*
   * Retorna o id das NFs para o Destinatario no romaneio
  */
  function Retornar_idNF_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Retorna o codigo das NFs para o Destinatario no romaneio
  */
  function Retornar_NF_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Retorna o nome das transportadoras para o Destinatario no romaneio
  */
  function Retornar_Transp_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Verifica se existe algum item das nfs com qtde atendida nula
  */
  procedure checar_nf_qtdeatendida(p_romaneio in number);

  /*
   * Func?o que retornas as Rotas vinculadas a NF
  */
  function Retornar_Rota(p_idententrega in number) return varchar2;

  /*
   * Func?o que retornas as Pre-cargas vinculadas a NF
  */
  function Retornar_PreCarga(p_idententrega in number) return varchar2;

  /*
   * Func?o que retorna a data maxima da separac?o do romaneio
  */
  function Retornar_DtMaxSep(p_idromaneio in number) return date;

  /*
   * Func?o que retorna a data maxima da conferencia liberada
  */
  function Retornar_DtMaxConf(p_idromaneio in number) return date;

  /*
   * Atualiza na nf a qtde atendida em funcao do corte de algum
   * produto na formacao de carga
  */
  procedure ZerarQtdeAtendidaNF
  (
    p_romaneio in number,
    p_produto  in number,
    p_estado   lote.estado%type
  );

  /*
   * Rotina que exclui os palets
  */
  procedure excluir_pallet_separacao
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Rotina para desfazer o romaneio e mudar o statusnf para processado
  */
  procedure desfazerreentrega
  (
    p_idocorrenciaentrega in number,
    p_usuario             in number
  );

  /*
   * Rotina que cancela a NF caso a somatoria da Qtde atendida for 0 (Zero)
  */
  procedure CancelarNFCorteTotal
  (
    p_idromaneio in number,
    p_idusuario  in number
  );

  /*
   * Func?o que Retorna sequencia maxima da nfromaneio
  */
  function RetornarOrdemEntregaMaxima(p_romaneio in number) return number;

  /*
   * Func?o que Retorna sequencia da nfromaneio
  */
  function RetornarOrdemEntrega
  (
    p_romaneio in number,
    p_entidade in number
  ) return number;

  /*
   * Rotina que retira NF da Carga
  */
  procedure retirarNFCarga
  (
    p_idromaneio   in number,
    p_idnotafiscal in number,
    p_idusuario    in number,
    p_idlotenf     out number
  );

  /*
  * Cria os Romaneio baseado no Retorno dos Pacotes do Sistema Roterizador
  */
  procedure FormarRomaneioPacote
  (
    p_idpacote    in number,
    p_numromaneio in number,
    p_idusuario   in number,
    p_armazem     in number,
    p_doca        in number,
    p_idlocal     in number
  );

  /*  
  *Rotina que verifica se o pacote ja foi todo formado e finaliza o mesmo
  */
  procedure FinalizaPacote(p_idpacote in number);

  /*
   * Rotina que verifica as diferencas nas qtdes da nf com a que est?o na Separac?o especifica
  */
  procedure VerificaDiferencaQtde(p_romaneio in number);

  /*
   * Rotina que cria o manifesto de carga
  */
  procedure CriarManifestoCarga
  (
    p_idcarga      in number,
    p_idnotafiscal in number
  );

  /*
   * Cria pallet e ProdutoPalet para reentrega
  */
  procedure criar_pallet_reentrega(p_romaneio in number);

  /*
   * Inclui nf em uma nova carga
  */
  procedure IncluirNF_NovaCarga
  (
    p_entidade    in number,
    p_depositante in number,
    p_nf          in number,
    p_usuario     in number,
    p_carga       in number,
    p_tipoocorr   in string,
    p_tipocarga   in string
  );

  /*
   * Retorna se o romaneio ja foi separado ou n?o
  */
  function ret_romenio_separado(p_romaneio in number) return varchar2;

  procedure apaga_palet_separacao
  (
    p_romaneio  in number,
    p_idpalet   in number,
    p_idarmazem in number,
    p_idlocal   in local.idlocal%type,
    p_idproduto in number
  );

  function retornar_volume_nf_romaneio
  (
    p_romaneio in number,
    p_nf       in number
  ) return number;

  function retornar_depositante(p_romaneio in number) return varchar2;

  /*
   * Insere as Notas Fiscais ao Romaneio
  */
  procedure inserir_nfromaneio_notafiscal
  (
    p_romaneio   in out number,
    p_notafiscal in number,
    p_usuario    in number,
    p_commit     in varchar2 := c_sim
  );

  /*
   * Retorna a sigla de expedição baseado no cep informado
  */
  function SiglaExpedicao(p_cep in varchar2) return varchar2;

  /*
   * Retorna a rota de expedição baseado no cep informado
  */
  function RotaExpedicao(p_cep in varchar2) return varchar2;

  /*
   * Retorna STRING com as notas fiscais do romaneio
  */
  function RetornaNFRomaneio(p_romaneio in varchar2) return varchar2;

  function RetornaIDNFRomaneio(p_romaneio in varchar2) return varchar2;

  function RetornaQtdeNFRomaneio(p_romaneio in number) return number;

  /*
   * Rorina responsável por vincular os volumes cuja os pais (lotes) foram vinculados ao romaneio
  */
  procedure VincularVolumeNoRomaneio
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Retorna STRING com os Pedidos do Romaneio
  */
  function RetornaPedidoRomaneio(p_romaneio in varchar2) return varchar2;

  /*
   * Volta o estoque de um romaneio processado
  */
  procedure retornarRomaneioProcessado
  (
    p_idromaneio in romaneiopai.idromaneio%type,
    p_idusuario  in number
  );

  /*
   * Preenche o Palet Separacao Cliente apos Recalculo do PaletSeparacao
  */
  procedure RecalculaPaletSepCliente(p_idromaneio in number);

  /*
   * Retorna o Num pedido das NFs para o Destinatario no romaneio
  */
  function Retornar_NumPedido_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Retorna Data de Importacao do pedido das NFs para o Destinatario no romaneio
  */
  function RETORNAR_DTIMPPEDIDO
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Retorna o PagGeomapa das NFs para o Destinatario no romaneio
  */
  function Retornar_LocGeo_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  /*
   * Retorna os tipos de documentos das NFs para o Destinatario no romaneio
  */
  function Retornar_TipoDocumento_Cliente
  (
    p_romaneio     in number,
    p_destinatario in number
  ) return varchar2;

  -- Parametro p_tipo identifica se a p_id esta armazenando o IDROMANEIO ou o IDUSUARIO.
  procedure finalizarseparacao
  (
    p_id       in number,
    p_tipo     in varchar2,
    p_idregiao in number := null
  );

  /*
  * Rotina usada para ordenar as notas fiscais de acordo com a ordem de entrega
  * da nfromaneio
  */
  procedure ordenar_sequencia_romaneio(p_romaneio in number);

  /*
   * Identifica os lotes por nota fiscal do romaneio
  */
  procedure identificarlotes(p_idromaneio in romaneiopai.idromaneio%type);

  /*
   * Rotina que verifica as notas do romaneio ja foram faturadas, processa as mesmas e fatura o romaneio
  */
  procedure VerificaNFRomaneio(p_romaneio in out romaneiopai%rowtype);

  /*
   * Atualiza o romaneiopai
  */
  procedure AtualizarRomaneio(p_romaneio in romaneiopai%rowtype);

  /*
   * Gera a convocacao ativa para o romaneio
  */
  procedure GeraConvocacaoAtiva
  (
    p_idromaneio     in number,
    p_usuario        in number,
    p_gerarseparacao in varchar2
  );

  /*
   * Retorna iddepositante para romaneio.
  */
  function RetornarIdDepositante(p_romaneio in number) return number;

  /*
   * Retorna depositante para romaneio.
  */
  function RetornarDepositante(p_romaneio in number) return varchar2;

  /*
   * Retorna destinatario para romaneio.
  */
  function RetornarIdDestinatario(p_romaneio in number) return number;

  /*
   * Retorna destinatario para romaneio.
  */
  function RetornarDestinatario(p_romaneio in number) return varchar2;

  /*
   * Retorna transportadora para romaneio.
  */
  function RetornarTransportadora(p_romaneio in number) return varchar2;

  /*
   * Funcao que retorna os usuarios do paletseparacao
  */
  function RetornarUsuarioSepararao
  (
    p_romaneio in number,
    p_palet    in number
  ) return varchar2;

  /*
   * Rotina que vincula o usuario se vai separar ao palet
  */
  procedure AgendarUsuario
  (
    p_romaneio in number,
    p_usuario  in number
  );

  -- Inicia a Separacao Manual
  procedure IniSeparacaoManual
  (
    p_idromaneio    in number,
    p_idusuario     in number,
    p_idusuariovinc in number
  );

  -- Finaliza a Separacao Manual
  procedure FinSeparacaoManual
  (
    p_idromaneio in number,
    p_idusuario  in number
  );

  /*
   * Rotina que troca o usuario da separacao
  */
  procedure TrocarUsuarioSeparacao
  (
    p_romaneio     in number,
    p_usuario      in number,
    p_usuariotroca in number
  );

  /*
   * Rotina que cancela a separacao do romaneio
  */
  procedure CancelarSeparacao
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
  * Retorna a uma coleta automatica
  */
  function RetornaColetaAutomatica(p_romaneio in number) return number;

  function RetornarIdNF(p_romaneio in varchar2) return number;

  /*
  *  Funcao que retorno transportadora da nota fiscal
  */
  function RetornaTransportadora(p_romaneio in number) return number;

  procedure auditarromaneio
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Rotina que exclui a  tabela lotepallet
  */
  procedure excluir_lotepallet
  (
    p_romaneio in number,
    p_usuario  in number
  );

  /*
   * Rotina responsavel em alimentar as tabelas de separação a partir de romaneio formados pela nova rotina (Java)
  */
  procedure preencherInfSeparacao
  (
    p_romaneio       in number,
    p_idconfiguracao in number
  );

  /*
   * Retorna a sigla de expedicao baseado no cep informado
  */
  function RetornarSiglaExpedicaoTransp
  (
    p_identidade in number,
    p_cep        in varchar2
  ) return varchar2;

  /*
   * Rotina responsavel em inserir notas fiscais na carga
  */
  procedure inserirNFCarga
  (
    p_romaneio in number,
    p_carga    in number
  );

  /*
  * Verifica Remanejamentos Pendentes do Romaneio
  */
  procedure VerificaRemanejRomaneio
  (
    p_idromaneio   in number,
    p_complementar in varchar2
  );

  /*
  * Insere na tabela LogRomaneioCorte e LogDetRomaneioCorte
  */
  procedure InsereLogRomaneioCorte(p_idRomaneio in number);

  /*
   * Retornar consulta de reabastecimentos 
  */
  function ConsultaLoteReab(p_idremanejamento in number) return varchar2;

  /*
   * Retorna Entidade Entrega para romaneio.
  */
  function RetornarEntEntrega(p_romaneio in number) return varchar2;

  function retornarFaturado(p_idromaneio in number) return char;

  /*
   * Retorna STRING com os Pedidos do Romaneio
  */
  function RetornaPedFornecRomaneio(p_romaneio in varchar2) return varchar2;

  /*
  * Retorna a Doca da Onda
  */
  function RetornaDocaOnda
  (
    p_idonda            in number,
    id_transportadoranf in number,
    v_codvolume         in varchar2
  ) return varchar2;

  /*
  * Retorna Melhor Instrumento para Separacao do Material
  */
  function RetornaInstrumento
  (
    p_idarmazem in number,
    p_peso      in number,
    p_andar     in varchar2
  ) return varchar2;

  procedure atualizaDocumentoRomaneio
  (
    p_idromaneio   in number,
    p_idnotafiscal in number,
    p_tipo         in number
  );

  procedure atualizaCargaRomaneio
  (
    p_idcarga      in number,
    p_idnotafiscal in number,
    p_tipo         in number
  );

  /*
  * Inserir na IdEntRomaneio
  */
  procedure InsereClienteRomaneio
  (
    p_idRomaneio in number,
    p_idNF       in number
  );

  /*
   * Retorna Pessoa Destinatario para romaneio.
  */
  function RetornarPessoaDestinatario(p_romaneio in number) return varchar2;

  function retornarPontoAlerta(p_idromaneio in number) return varchar2;

  procedure vincularCaixaSeparacaoRomaneio
  (
    p_idromaneio          in number,
    p_barracaixaseparacao in caixaseparacao.barra%type,
    p_mensagem            out varchar2
  );

  procedure liberarCaixaSeparacacao
  (
    p_idromaneio       in number,
    p_idcaixaseparacao in number := null
  );

  procedure calculaValoresRomaneio(p_idromaneio in number);

  procedure AtualizaStatusAuditoria(p_idRomaneio in number);

  procedure AlterarQtdeSeparacao
  (
    p_idromaneio   in number,
    p_idpalet      in number,
    p_idlocal      in local.idlocal%type,
    p_idproduto    in number,
    p_barra        in varchar2,
    p_qtdeseparada in number,
    p_idusuario    in number
  );

  procedure alterarTitulo
  (
    p_idromaneio in number,
    p_titulo     in varchar2,
    p_idusuario  in number
  );

  procedure registrarControleSeparacao
  (
    p_idRomaneio       in number,
    p_idPalet          in number,
    p_idPlanoSeparacao in number,
    p_idUsuario        in number,
    p_idRegiao         in number,
    p_idUsuarioLogado  in number
  );

  procedure preencherPaletSepNFOnda(p_idromaneio in romaneiopai.idromaneio%type);

  function resumoTipoEmbalagem(p_idromaneio in romaneiopai.idromaneio%type)
    return varchar2;

  function valorPesoCubado(p_barra in volumeromaneio.codbarra%type)
    return number;

  function coletaPossuiVendorReturn(p_carga in number) return boolean;

end pk_romaneio;
/

