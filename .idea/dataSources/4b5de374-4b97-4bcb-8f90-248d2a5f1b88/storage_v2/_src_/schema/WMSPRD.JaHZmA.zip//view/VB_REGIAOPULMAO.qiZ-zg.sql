create view VB_REGIAOPULMAO as
select descr regiaoretornoestoque, idregiao
  from regiaoarmazenagem
 where tipo = 1
/

