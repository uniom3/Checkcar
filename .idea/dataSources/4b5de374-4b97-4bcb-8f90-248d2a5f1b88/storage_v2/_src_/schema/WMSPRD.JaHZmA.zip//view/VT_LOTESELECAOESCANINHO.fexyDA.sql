create view VT_LOTESELECAOESCANINHO as
select (s.loteindustria || s.datavencimento || s.h$barra) h$tableid,
       s.loteindustria,
       to_char(s.datavencimento, 'dd/mm/yyyy') datavencimento,
       s.h$barra h$barra
  from (select distinct lt.descr loteindustria, lt.dtvenc datavencimento,
                         e.barra h$barra
           from movimentacao m, escaninho es, lote lt, produto p, embalagem e
          where es.idendereco = m.idlocaldestino
            and es.idnotafiscal = m.idnotafiscal
            and es.idromaneio = m.idonda
            and m.status in (0, 1, 2)
            and m.qtdeconferida - m.qtdeemvolume > 0
            and lt.idlote = m.idlote
            and p.idproduto = lt.idproduto
            and p.idproduto = e.idproduto) s
/

