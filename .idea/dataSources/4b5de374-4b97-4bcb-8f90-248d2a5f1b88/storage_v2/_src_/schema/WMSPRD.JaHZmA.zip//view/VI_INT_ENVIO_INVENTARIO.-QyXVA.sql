create view VI_INT_ENVIO_INVENTARIO as
select 8 I, i.CNPJ_DEPOSITANTE CNPJDEPOSITANTE, i.CODIGOINTERNO,
       lpad(i.estoque, 12, 0) ESTOQUE,
       lpad(i.inventariado, 12, 0) INVENTARIADO, i.BARRA, i.DESCR,
       lpad(i.idinventario, 12, 0) IDINVENTARIO, i.ESTADO,
       i.CODIGOINTERNO CODINTERNO, i.DESCR DESCRPROD, '*' F,
       to_char(i.DATA, 'dd/MM/yyyy HH24:mi') DATAEMISSAO, i.AGRUPADOR ID,
       i.idreplicacao
  from int_envio_inventario i
/

