create view VI_INT_ENVIO_AM_RTI_PACKITENS as
select agrupador id, packageid, itemvalue, itemtype, quantityshipped
  from int_envio_am_rti_packitens
/

