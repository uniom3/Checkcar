create view VT_BACKLISTPRODUTO as
select b.id, p.descr produto, b.qtde, b.loteindustria, b.idnfdet,
       to_char(b.vencimento, 'dd/mm/yyyy') vencimento,
       to_char(b.dtfabricacao, 'dd/mm/yyyy') dtfabricacao,
       decode(l.idlotenf, null, 'Inexistente',
               decode(tr.conferenciaalocada, 0,
                       'Não utiliza Conferência Alocada',
                       decode((select count(1)
                                 from conferenciaentradadet cdet, lote lt
                                where cdet.idlotenf = l.idlotenf
                                  and cdet.idlote = lt.idlote
                                  and cdet.idproduto = nd.idproduto
                                  and cdet.barra = nd.barra
                                  and cdet.descrlote = b.loteindustria
                                  and lt.dtalocacao is not null), 1, 'Finalizado',
                               decode((select count(1) qtdeconferida
                                         from conferenciaentradadet c
                                        where c.idlotenf = l.idlotenf
                                          and c.idproduto = nd.idproduto
                                          and c.barra = nd.barra
                                          and c.descrlote = b.loteindustria), 0,
                                       'Pendente', 'Em conferência')))) statusrecebimento,
       decode(l.idlotenf, null, 0,
                -- 0 inexistente
               decode(tr.conferenciaalocada, 0, 1,
                        -- 1 nao utiliza
                       decode((select count(1)
                                 from conferenciaentradadet cdet, lote lt
                                where cdet.idlotenf = l.idlotenf
                                  and cdet.idlote = lt.idlote
                                  and cdet.idproduto = nd.idproduto
                                  and cdet.barra = nd.barra
                                  and cdet.descrlote = b.loteindustria
                                  and lt.dtalocacao is not null), 1, 2,
                                -- 2 Finalizado
                               decode((select count(1) qtdeconferida
                                         from conferenciaentradadet c
                                        where c.idlotenf = l.idlotenf
                                          and c.idproduto = nd.idproduto
                                          and c.barra = nd.barra
                                          and c.descrlote = b.loteindustria), 0, 3,
                                       4)))) h$status,
        -- 3 Pendente, 4 Em Conferência
       nvl(tr.conferenciaalocada, 0) h$conferenciaAlocada
  from backlist b, nfdet nd, produto p, notafiscal nf, lotenf l,
       tiporecebimento tr
 where nd.idnfdet = b.idnfdet
   and p.idproduto = nd.idproduto
   and nf.idnotafiscal = nd.nf
   and l.idlotenf(+) = nf.idlotenf
   and tr.idtiporecebimento(+) = l.idtiporecebimento
/

