create view VT_SELECIONARCONFPACKLOTEUNICO as
select descrlote, to_char(vencproduto, 'dd/mm/rrrr') vencproduto,
       z.idproduto h$idproduto, idnotafiscal h$idnotafiscal, idonda h$idonda,
       idenderecopacking h$idpacking, z.codbarratarefa h$codbarratarefa
  from (select m.idonda, pa.idendereco idenderecopacking, m.idnotafiscal,
                lt.idproduto, lt.descr descrlote, lt.dtvenc vencproduto,
                sum(m.quantidade) qtdetotal, 0 qtdecontada, 0 qtdeemvolume,
                lpad(m.idonda, 10, 0) || lpad(m.identificador, 4, 0) codbarratarefa
           from movimentacao m, lote lt, packing pa
          where m.idlocaldestino = pa.idendereco
            and m.status in (0, 1, 2)
            and lt.idlote = m.idlote
          group by m.idonda, pa.idendereco, m.idnotafiscal, lt.idproduto,
                   lt.descr, lt.dtvenc,
                   lpad(m.idonda, 10, 0) || lpad(m.identificador, 4, 0)
         having sum(m.quantidade) > 0
         union all
         select c.idonda, c.idpacking idenderecopacking, c.idnotafiscal,
                pc.idproduto, pc.loteindustria descrlote,
                pc.vencimento vencproduto, 0 qtdetotal,
                nvl(sum(pc.qtde * e.fatorconversao), 0) qtdecontada,
                0 qtdeemvolume, c.codbarratarefa
           from confpacking c, produtoconfpacking pc, embalagem e,
                notafiscal n
          where pc.idconfpacking = c.id
            and pc.status = 1
            and c.status = 0
            and c.idnotafiscal = n.idnotafiscal
            and e.idproduto = pc.idproduto
            and e.barra = pc.barra
          group by c.idonda, c.idpacking, c.idnotafiscal, pc.idproduto,
                   pc.loteindustria, pc.vencimento, c.codbarratarefa, pc.data
         union all
         select m.idonda, pa.idendereco idenderecopacking, m.idnotafiscal,
                lt.idproduto, lt.descr descrlote, lt.dtvenc vencproduto,
                0 qtdetotal, 0 qtdecontada,
                nvl(sum(cv.quantidade), 0) qtdeemvolume,
                lpad(m.idonda, 10, 0) || lpad(m.identificador, 4, 0) codbarratarefa
           from movimentacao m, conteudovolume cv, lote lt, packing pa
          where m.status in (0, 1, 2)
            and pa.idendereco = m.idlocalorigem
            and cv.idvolumeromaneio = m.idvolumeromaneio
            and lt.idlote = cv.idlote
          group by m.idonda, pa.idendereco, m.idnotafiscal, lt.idproduto,
                   lt.descr, lt.dtvenc,
                   lpad(m.idonda, 10, 0) || lpad(m.identificador, 4, 0)) z
having(sum(qtdetotal) - sum(qtdecontada) - sum(qtdeemvolume)) > 0
 group by idonda, idenderecopacking, idnotafiscal, z.idproduto, descrlote,
          to_char(vencproduto, 'dd/mm/rrrr'), codbarratarefa
/

