create view VI_INT_ENVIO_AM_TD_ITEM as
select agrupador id, agrupador, tranferrequestid, lineitemid, itemid,
       itemtype, quantity, itemlocation
  from int_envio_am_td_item
/

