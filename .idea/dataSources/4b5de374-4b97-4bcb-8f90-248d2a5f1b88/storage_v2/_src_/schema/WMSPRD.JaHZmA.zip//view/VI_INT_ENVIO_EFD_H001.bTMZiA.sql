create view VI_INT_ENVIO_EFD_H001 as
select idarmazem, data dataprocessamento, count(*) total
  from historicoestoquediario
 where valor > 0
 group by idarmazem, data

/

