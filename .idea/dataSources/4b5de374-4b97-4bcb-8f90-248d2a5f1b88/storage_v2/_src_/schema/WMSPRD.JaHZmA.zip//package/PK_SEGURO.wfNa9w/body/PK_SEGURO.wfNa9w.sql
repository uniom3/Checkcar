create package body PK_SEGURO is

  t_msg t_message;

  procedure addContratoSeguro
  (
    p_idSeguro   in number,
    p_idContrato in number
  ) is
    v_existe number;
  begin
    select count(1)
      into v_existe
      from segurocontrato
     where idseguro <> p_idSeguro
       and idcontrato = p_idContrato;
  
    if (v_existe > 0) then
      t_msg := t_message('Contrato {0} já está vinculado a outro seguro');
      t_msg.addParam(p_idContrato);
    
      raise_application_error(-20000, t_msg.formatMessage);
    end if;
  
    insert into segurocontrato
      (idsegurocontrato, idseguro, idcontrato)
    values
      (seq_segurocontrato.nextval, p_idSeguro, p_idContrato);
  end;

  procedure removeContratoSeguro
  (
    p_idSeguro   in number,
    p_idContrato in number
  ) is
  begin
    delete from segurocontrato
     where idseguro = p_idSeguro
       and idcontrato = p_idContrato;
  end;

end PK_SEGURO;
/

