create view V_SEPARACOES_PENDENTES as
select idregiaoorigem, regiaoorigem, bufferorigem, idregiaodestino,
       regiaodestino, bufferdestino, tipoorigem, tipodestino,
       tipolocalorigem, pickingorigem, tipolocaldestino, pickingdestino,
       ordemregiao, ordemmov, origemconcluida, idromaneio, idarmazem
  from (select ro.idregiao idregiaoorigem, ro.descr regiaoorigem,
                lo.buffer bufferorigem, rd.idregiao idregiaodestino,
                rd.descr regiaodestino, ld.buffer bufferdestino,
                ro.tipo tipoorigem, rd.tipo tipodestino,
                lo.tipo tipolocalorigem, lo.picking pickingorigem,
                ld.tipo tipolocaldestino, ld.picking pickingdestino,
                decode(ro.tipo, 6, 99, 1, 0, 0, 1, ro.tipo) ordemregiao,
                min(m.id) ordemmov,
                decode(sum(m.qtdemovimentada - m.qtdeconferida), 0, 1, 0) origemconcluida,
                rp.idromaneio, rp.idarmazem
           from romaneiopai rp, atividadepickingvoice a, v_tarefas_onda m,
                local lo, regiaoarmazenagem ro, local ld, regiaoarmazenagem rd
          where a.idatividade = rp.idromaneio
            and m.idonda = rp.idromaneio
            and lo.id = m.idlocalorigem
            and ro.idregiao = lo.idregiao
            and ld.id = m.idlocaldestino
            and rd.idregiao = ld.idregiao
            and m.status in (0, 1)
            and not (round(m.qtdemovimentada - m.qtdeconferida, 6) = 0 and
                 m.status = 2)
            and (ld.idregiao not in
                (select idregiao
                    from regiaoarmazenagem
                   where tipo = decode(ro.tipo, 7, null, 3)) or
                (lo.buffer = 'N' and ld.buffer = 'N' and ro.tipo in (0, 1) and
                rd.tipo = 3))
            and not (lo.buffer = 'N' and m.status = 1 and
                 lo.idregiao in (select idregiao
                                       from regiaoarmazenagem
                                      where tipo = 0) and ld.buffer = 'N' and
                 ld.idregiao in (select idregiao
                                       from regiaoarmazenagem
                                      where tipo = 2))
            and not exists
          (select 1
                   from pickingpicktolightonda ptl, produtolocal pl
                  where pl.idprodutolocal = ptl.idprodutolocal
                    and pl.idarmazem = lo.idarmazem
                    and pl.idlocal = lo.idlocal)
            and not (ld.tipo = 0 and ld.buffer = 'N' and
                 ld.idsetor in
                 (select idsetor
                        from setor
                       where codintegracaoesteira is not null))
          group by ro.idregiao, ro.descr, lo.buffer, rd.idregiao, rd.descr,
                   ld.buffer, ro.tipo, rd.tipo, lo.tipo, lo.picking, ld.tipo,
                   ld.picking, decode(ro.tipo, 6, 99, 1, 0, 0, 1, ro.tipo),
                   rp.idromaneio, rp.idarmazem)
 order by ordemregiao, ordemmov
/

