create view VT_CONFIRMACAOPIN as
select nf.codigointerno notafiscal, nf.sequencia serie,
       nf.numpedidofornecedor pedido,
       decode(dep.pessoa, 'J', dep.cgc, dep.cic) cnpjdepositante,
       dep.razaosocial depositante,
       decode(rem.pessoa, 'J', rem.cgc, rem.cic) cnpjemitente,
       rem.razaosocial emitente,
       decode(dest.pessoa, 'J', dest.cgc, dest.cic) cnpjdestinatario,
       dest.razaosocial destinatario, nf.dataemissao dtemissao,
       nf.chaveacessonfe chaveacessonfe,
       decode(nvl(nf.impresso, 'N'), 'S', 'FATURADO', 'N',
               decode(nvl(nf.enviadofaturamento, 'N'), 'S', 'AGUARDANDO', 'N',
                       decode(nvl(rp.faturado, 'N'), 'N', 'PENDENTE', 'A',
                               'AGUARDANDO', 'S', 'FATURADO'))) faturado,
       nf.datafaturamento dtFaturamento, nf.impresso NFImpressa,
       rp.codigointerno OndaSeparacao, nf.dataconfirmacaopin,
       us.nomeusuario usuarioconfirmacaopin, nf.idnotafiscal h$idnotafiscal,
       nf.controlepin h$controlepin
  from notafiscal nf, nfimpressao n, entidade dep, entidade rem,
       entidade dest, nfromaneio nfr, romaneiopai rp, usuario us
 where n.idprenf(+) = nf.idprenf
   and dep.identidade = nf.iddepositante
   and rem.identidade = nf.remetente
   and dest.identidade = nf.destinatario
   and nf.controlepin in (1, 2)
   and nfr.idnotafiscal(+) = nf.idnotafiscal
   and nfr.idromaneio = rp.idromaneio(+)
   and us.idusuario(+) = nf.usuarioconfirmacaopin
/

