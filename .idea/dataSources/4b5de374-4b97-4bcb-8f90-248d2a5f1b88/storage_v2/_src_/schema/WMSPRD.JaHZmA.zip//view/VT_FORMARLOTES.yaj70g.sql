create view VT_FORMARLOTES as
with sql_lotes as
 (select r.idremanejamento h$idremanejamento, ll.idarmazem h$idarmazem,
         ll.idlocal h$idlocal, p.idproduto, p.codigointerno,
         pd.codigointerno codprodutodep, p.descr produto,
         l.descr loteindustria, l.dtfabricacao, l.dtvenc,
         decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'T',
                 'VENCIDO/TRUNCADO') estado,
         pk_lote.retinformacoesespecifica(l.idlote) informacaoespecifica,
         l.loteadicional, l.itemadicional, e.razaosocial depositante,
         p.fracionado, l.estado h$estadolote, ll.estoque, ll.pendencia,
         ll.adicionar, ll.reservado, p.descr, l.iddepositante, l.idlote,
         case
            when exists (select 1
                    from informacaomatdep imd, produtodepositante pd
                   where imd.identidade = l.iddepositante
                     and imd.idproduto = l.idproduto
                     and pd.idproduto = imd.idproduto
                     and pd.identidade = imd.identidade
                     and pd.rastrearinfoespecifica in (0, 1)) then
             l.idlote
            else
             null
          end h$idloteinfoespec, l.liberado, l.idusuariobloqueio,
         l.idmotivobloqueio, l.motivobloqueio, l.databloqueio,
         l.hashcomplotekit
    from lotelocal ll, lote l, produto p, entidade e, remanejamento r,
         produtodepositante pd
   where r.status = 'A'
     and e.identidade = l.iddepositante
     and p.idproduto = l.idproduto
     and pd.identidade = l.iddepositante
     and pd.idproduto = l.idproduto
     and l.tipolote = 'L'
     and l.idlote = ll.idlote
     and (ll.estoque - ll.pendencia + ll.adicionar) > 0
     and ll.idlocal = r.idlocalorigem
     and ll.idarmazem = r.idarmazemorigem
     and ll.idlote not in
         (select idlote
            from loteremanejamento
           where idlote = ll.idlote
             and idremanejamento = r.idremanejamento))
select s.h$idremanejamento, s.h$idarmazem, s.h$idlocal, s.idproduto,
       s.codigointerno, s.codprodutodep, s.produto, s.loteindustria,
       s.dtfabricacao, s.dtvenc, sum(s.estoque) estoque,
       sum(s.pendencia) pendencia, sum(s.adicionar) adicionar,
       sum(s.estoque - s.pendencia - s.reservado + s.adicionar) disponivel,
       s.estado,
       pk_lote.retinformacoesespecifica(s.idlote) informacaoespecifica,
       s.loteadicional, s.itemadicional, s.iddepositante, s.depositante,
       s.fracionado, s.h$estadolote, s.h$idloteinfoespec, s.liberado,
       s.idusuariobloqueio, s.idmotivobloqueio, s.motivobloqueio,
       s.databloqueio, s.hashcomplotekit
  from sql_lotes s
 group by s.h$idremanejamento, s.h$idarmazem, s.h$idlocal, s.idproduto,
          s.codigointerno, s.codprodutodep, s.produto, s.loteindustria,
          s.loteadicional, s.dtvenc, s.dtfabricacao, s.estado,
          s.itemadicional, s.iddepositante, s.depositante, s.fracionado,
          pk_lote.retinformacoesespecifica(s.idlote), s.h$idloteinfoespec,
          s.h$estadolote, s.liberado, s.idusuariobloqueio,
          s.idmotivobloqueio, s.motivobloqueio, s.databloqueio,
          s.hashcomplotekit
 order by s.produto
/

