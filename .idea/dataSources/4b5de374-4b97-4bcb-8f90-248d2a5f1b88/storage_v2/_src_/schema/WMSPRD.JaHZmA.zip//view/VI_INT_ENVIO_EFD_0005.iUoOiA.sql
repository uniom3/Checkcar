create view VI_INT_ENVIO_EFD_0005 as
select '0005' reg, nvl(nvl(e.fantasia, e.razaosocial),' ') fantasia, nvl(en.cep, ' ') cep,
       nvl(en.logradouro, ' ') end, nvl(en.numero, ' ') num,
       nvl(en.complendereco, ' ') compl, nvl(en.bairro, ' ') bairro,
       nvl(t.idtelefone, ' ') fone, nvl(t.ramal, ' ') fax, ' ' email,
       a.idarmazem
  from armazem a, entidade e, v_endereco en, telefone t
 where e.identidade = a.identidade
   and en.identidade(+) = e.identidade
   and t.identidade(+) = e.identidade
/

