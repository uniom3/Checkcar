create view VT_SUBTIPOENTIDADE as
select idsubtipo, descr
  from subtipo
/

