create view V_RELEMBARQUE as
select c.idcarga, c.codigointerno, nf.idnotafiscal, nf.sequencia,
       nf.codigointerno codnf, trunc(nf.dataemissao) dataemissao,
       ve.razaosocial cliente, ve.cidade || ' - ' || ve.uf cidade, ve.bairro,
       case
          when vr.volume = 0
               and vr.volumeautomatico > 0 then
           1
          else
           vr.volume
        end volume, nvl(vr.cubagem, 0) cubagem,
       round(nvl(vr.pesovolume, 0), 3) pesobruto, nfi.vlrtotal valor,
       vt.razaosocial transp, initcap(c.motorista) motorista,
       upper(c.placa) placa, c.rgmotorista,
       initcap(vu.razaosocial) conferidor,
       'Eu ' || initcap(trim(c.motorista)) ||
        ', declaro para os devidos fins que recebi a carga ' || 'nro. ' ||
        to_char(c.codigointerno) || ' descrita acima, em perfeita ordem.' as termo,
       c.totalpeso, c.totalvolume,
       nvl(nf.numpedidofornecedor, 'NAO ENV.') numpedidofornecedor,
       et.qtdeimpressa volumesdetransporte
  from carga c, notafiscalcarga nfc, notafiscal nf, nfimpressao nfi,
       v_entidade ve, entidade vt, usuario us, entidade vu,
       (select v.idcarga, v.idnotafiscal,
                sum(decode(geradoautomaticamente, 0, 1, 0)) volume,
                sum(decode(geradoautomaticamente, 1, 1, 0)) volumeautomatico,
                sum(v.peso / 1000) pesovolume,
                (sum(round(((nvl(tv.altura, 0) * nvl(tv.largura, 0) *
                            nvl(tv.comprimento, 0)) / 1000000000), 3)) *
                 count(v.idvolume)) cubagem
           from volumeromaneio v, tipocaixavolume tv
          where tv.idtipocaixavolume(+) = v.idtipocaixavolume
          group by v.idcarga, v.idnotafiscal) vr, etiquetatransportador et
 where vr.idcarga = nfc.idcarga
   and vr.idnotafiscal = nfc.idnotafiscal
   and vu.identidade(+) = us.entidadeusuario
   and us.idusuario(+) = c.idusuariocoleta
   and vt.identidade(+) = c.idtransportadora
   and ve.identidade = nf.ident_entrega
   and nfi.idprenf = nf.idprenf
   and nf.idnotafiscal = nfc.idnotafiscal
   and nfc.embarqueliberado = 'S'
   and nfc.idcarga = c.idcarga
   and et.idnotafiscal(+) = nfc.idnotafiscal
/

