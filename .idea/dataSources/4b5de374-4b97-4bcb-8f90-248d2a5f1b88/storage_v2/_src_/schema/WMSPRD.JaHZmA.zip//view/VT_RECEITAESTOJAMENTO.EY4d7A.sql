create view VT_RECEITAESTOJAMENTO as
select rc.idos idordemservico, rc.idproduto, p.descr produto,
       rc.qtdeunit QTDEUNITARIA, rc.id h$id, rc.estojo permitirestojo
  from receitaestojamento rc, produto p
 where rc.idproduto = p.idproduto
 order by rc.id
/

