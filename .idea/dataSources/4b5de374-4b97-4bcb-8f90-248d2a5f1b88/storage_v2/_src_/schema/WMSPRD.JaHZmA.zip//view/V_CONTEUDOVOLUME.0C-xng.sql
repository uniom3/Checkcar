create view V_CONTEUDOVOLUME as
select cv.id,
       cv.quantidade + nvl((select sum(cva.quantidaderemovida)
                              from cortevolumeauditoria cva, cortefisico cf
                             where cva.idconteudovolume = cv.id
                               and cf.id = cva.idcortefisico
                               and cf.status in (0, 1)), 0) quantidade,
       cv.idlote, cv.idvolumeromaneio, cv.idvolumeromaneioold,
       cv.quantidadefracionada
  from conteudovolume cv
/

