create view VT_LOGINTEGRACAOCAIXA (BARRA, SERVICO, DATAHORA, LOG, IDLOG) as
select lc.barracaixa barra, lc.servico, lr.datahora,
       upper(lr.resultmessage) log, lc.id idlog
  from logintegracaocaixa lc, logintegracaorest lr
 where lr.id = lc.idlogintegracaorest
/

