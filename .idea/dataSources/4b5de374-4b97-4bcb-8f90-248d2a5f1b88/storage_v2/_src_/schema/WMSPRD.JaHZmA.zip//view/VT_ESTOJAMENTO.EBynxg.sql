create view VT_ESTOJAMENTO as
select os.rowid h$tableid, os.idordemservico, os.datacadastro dtcadastro,
       e.razaosocial depositante,
       decode(os.tiposervico, 'E', 'Estojamento', '') tiposervico,
       decode(os.situacao, 'A', 'Aguardando', 'P', 'Processada', 'X',
               'Cancelada') situacao, os.idlotenf, rp.codigointerno onda,
       p.descr produto, os.dataprocessamento dtprocessamento,
       os.datacancelamento, u.nomeusuario usuariocancelamento,
       os.identidade iddepositante, os.idproduto, os.idconfiguracaoonda,
       os.idromaneio h$idromaneio, os.situacao h$situacao,
       os.tiposervico h$tiposervico, os.idarmazem h$idarmazem,
       0 h$lotevinculado,
       d.permitiralterarqtdeseparacao h$permitiralterarqtdeseparacao,
       os.combo, os.idinventario, os.qtde,
       os.etiquetaimpressa h$etiquetaimpressa, os.observacao
  from ordemservico os, entidade e, romaneiopai rp, produto p, depositante d,
       usuario u
 where e.identidade = os.identidade
   and rp.idromaneio(+) = os.idromaneio
   and upper(os.tiposervico) = 'E'
   and p.idproduto(+) = os.idproduto
   and d.identidade = e.identidade
   and u.idusuario(+) = os.idusuariocancel
 order by os.idordemservico
/

