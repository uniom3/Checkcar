create view VT_HISTORICOOCUPACAO as
select ha.idarmazem h$idarmazem, ha.data, sum(ha.qtde) qtdelocaisocup,
       nvl(s.descr, 'SEM SETOR') setor, e.razaosocial depositante
  from historicoalocacao ha, setor s, entidade e
 where s.idsetor(+) = ha.idsetor
   and e.identidade = ha.identidade
 group by ha.idarmazem, ha.data, nvl(s.descr, 'SEM SETOR'), e.razaosocial
/

