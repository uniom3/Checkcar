create view V_PRODUTIVIDADE_REMANEJDESTINO as
select data, anomes, idusuario, usuario, nomeusuario, atividade, depositante,
       setor, regiao, pk_utilities.retornarTempo(tempogasto) tempogasto,
       qtdeitens, qtdeunidades, round(qtdevolumes, 6) qtdevolumes,
       round(pesokg, 4) pesokg, qtdeatividade
  from (select r.data, r.anomes, r.idusuario, r.usuario, r.nomeusuario,
                r.atividade, r.depositante, r.setor, r.regiao,
                sum(r.tempogasto) tempogasto, sum(r.qtdeitens) qtdeitens,
                sum(r.qtdeunidades) qtdeunidades,
                sum(r.qtdevolumes) qtdevolumes, sum(r.pesokg) pesokg,
                sum(r.qtdeatividade) qtdeatividade
           from (select r.idremanejamento, trunc(r.horainicio) data,
                         to_char(r.horainicio, 'yyyy/mm') anomes,
                         r.idusuariofim idusuario, u.nomeusuario usuario,
                         u.nomeusuariocompleto nomeusuario,
                         'REMANEJAMENTO DE DESTINO' atividade,
                         edep.razaosocial depositante, s.descr setor,
                         ra.descr regiao, r.horainicio, r.horafim,
                         (r.horafim - r.horainicio) * 86400 tempogasto,
                         count(distinct l.idproduto) qtdeitens,
                         sum(lr.qtde) qtdeunidades,
                         sum(lr.qtde /
                              pk_produto.getFatorEmbCompra(l.idproduto)) qtdevolumes,
                         sum((lr.qtde / e.fatorconversao) * e.pesobruto) / 1000 pesokg,
                         1 qtdeatividade
                    from remanejamento r, usuario u, local lo, setor s,
                         regiaoarmazenagem ra, loteremanejamento lr, lote l,
                         embalagem e, entidade edep
                   where r.status = 'F'
                     and u.idusuario = r.idusuariofim
                     and lo.idarmazem = r.idarmazemdestino
                     and lo.idlocal = r.idlocaldestino
                     and s.idsetor(+) = lo.idsetor
                     and ra.idregiao(+) = lo.idregiao
                     and lr.idremanejamento = r.idremanejamento
                     and l.idlote = lr.idlote
                     and e.idproduto = l.idproduto
                     and e.barra = l.barra
                     and edep.identidade(+) = l.iddepositante
                   group by r.idremanejamento, trunc(r.horainicio),
                            edep.razaosocial, to_char(r.horainicio, 'yyyy/mm'),
                            r.idusuariofim, u.nomeusuario, u.nomeusuariocompleto,
                            s.descr, ra.descr, r.horainicio, r.horafim,
                            (r.horafim - r.horainicio) * 86400) r
          group by r.data, r.anomes, r.idusuario, r.usuario, r.nomeusuario,
                   r.atividade, r.setor, r.regiao, r.depositante)
 order by data, nomeusuario
/

