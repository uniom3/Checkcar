create view V_CONFBACKLISTRESUMO as
select ln.idlotenf, cd.idproduto, cd.descrlote loteindustria,
       1 qtdeConferencia
  from lotenf ln, conferenciaentradadet cd, embalagem e, armazem a,
       depositante d
 where cd.idlotenf = ln.idlotenf
   and cd.descrlote is not null
   and cd.ignorada = 'N'
   and e.barra = cd.barra
   and e.idproduto = cd.idproduto
   and a.idarmazem = ln.idarmazem
   and exists
 (select cda.idlotenf
          from conferenciaentradadet cda
         where cda.idlotenf = cd.idlotenf
           and cda.idconferenciaentrada = cd.idconferenciaentrada
           and cda.idproduto = cd.idproduto
           and cda.estado = cd.estado
           and cd.status = 'S'
           and cd.ignorada = 'N')
   and not exists
 (select idlotenf, idconferenciaentrada, idcontagem
          from montagem m
         where m.idlotenf = cd.idlotenf
           and m.idconferenciaentrada = cd.idconferenciaentrada
           and m.idcontagem = cd.idcontagem)
   and not exists
 (select idlotenf, idconferenciaentrada, idcontagem
          from compmontagem m
         where m.idlotenf = cd.idlotenf
           and m.idconferenciaentrada = cd.idconferenciaentrada
           and m.idcontagem = cd.idcontagem)
   and d.identidade = ln.identidade
   and d.utzbacklist = 1
union
select ln.idlotenf, cd.idproduto, cd.descrlote loteindustria,
       sum(cd.qtde * e.fatorconversao) qtdeConferencia
  from lotenf ln, conferenciaentradadet cd, embalagem e, armazem a,
       depositante d
 where cd.idlotenf = ln.idlotenf
   and cd.descrlote is not null
   and cd.ignorada = 'N'
   and e.barra = cd.barra
   and e.idproduto = cd.idproduto
   and a.idarmazem = ln.idarmazem
   and exists
 (select cda.idlotenf
          from conferenciaentradadet cda
         where cd.status = 'S'
           and cd.ignorada = 'N'
           and cda.idlotenf = cd.idlotenf
           and cda.idconferenciaentrada = cd.idconferenciaentrada
           and cda.idproduto = cd.idproduto
           and cda.estado = cd.estado)
   and not exists
 (select idlotenf, idconferenciaentrada, idcontagem
          from montagem m
         where m.idlotenf = cd.idlotenf
           and m.idconferenciaentrada = cd.idconferenciaentrada
           and m.idcontagem = cd.idcontagem)
   and not exists
 (select idlotenf, idconferenciaentrada, idcontagem
          from compmontagem m
         where m.idlotenf = cd.idlotenf
           and m.idconferenciaentrada = cd.idconferenciaentrada
           and m.idcontagem = cd.idcontagem)
   and d.identidade = ln.identidade
   and d.utzbacklist in (2, 3)
 group by ln.idlotenf, ln.identidade, cd.idproduto, cd.descrlote
/

