create view VT_HISTORICOCAIXASEPARACAOPROD as
select h.idcaixaseparacao, cx.barra, cx.descricao, rp.codigointerno onda,
       m.idnotafiscal, ro.descr || ' para ' || rd.descr separacao,
       lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0') codbarratarefa,
       rd.descr, dp.razaosocial depositante, pd.codigointerno codigoproduto,
       pd.descr produto, m.quantidade, us.nomeusuario separador,
       uc.nomeusuario conferente,
       decode(hcc.tipohistorico, 0, 'Cancelamento da Onda', 1,
               'Retirada Nota Fiscal da Onda', 2, 'Conferência Checkout') tipohistorico,
       hcc.datahistorico,
       h.idhistoricocaixaseparacao h$idhistoricocaixaseparacao
  from historicocaixaseparacao h, caixaseparacao cx, local lo,
       regiaoarmazenagem ro, local ld, regiaoarmazenagem rd,
       historicoconteudocaixa hcc, romaneiopai rp, movimentacao m, lote lt,
       produto pd, entidade dp, usuario us, usuario uc
 where hcc.idhistoricocaixaseparacao = h.idhistoricocaixaseparacao
   and cx.idcaixaseparacao = h.idcaixaseparacao
   and m.id = hcc.idmovimentacao
   and lo.id = m.idlocalorigem
   and ld.id = m.idlocaldestino
   and ro.idregiao = lo.idregiao
   and rd.idregiao = ld.idregiao
   and rp.idromaneio = m.idonda
   and dp.identidade = lt.iddepositante
   and lt.idlote = m.idlote
   and pd.idproduto = lt.idproduto
   and us.idusuario = m.idusuario
   and uc.idusuario(+) = h.idusuariopacking
/

