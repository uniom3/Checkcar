create view VT_LIVROREGISTROINVENTARIO as
select d.razaosocial depositante,
       decode(d.pessoa, 'J', d.cgc, d.cic) cnpjdepositante, lf.idlivrofiscal,
       lf.dtestoque dataestoque, lf.idnotafiscal, lf.especie, lf.serie, lf.numero,
       lf.fiscal cfop, lf.tipo, lf.idproduto, lf.classfiscalproduto,
       lf.quantidade, to_char(lf.valor, '999g999g999g990d00') valor,
       to_char(lf.ipi, '999g999g999g990d00') ipi, lf.observacao,
       lf.iditemlivro id, l.status h$status
  from itemlivroregistroinventario lf, notafiscal nf, entidade d, livrofiscal l
 where l.idlivrofiscal = lf.idlivrofiscal
   and lf.idnotafiscal = nf.idnotafiscal
   and nf.iddepositante = d.identidade
/

