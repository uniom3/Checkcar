create view VT_ESTACAOSEPARACAOUSUARIO as
select decode(eu.idusuario, null, 0, 1) marcado, e.usuario, e.nivel,
       e.departamento, e.idusuario, e.idestacao h$idestacao, e.ativo h$ativo
  from (select e.id idestacao, u.nomeusuario usuario, u.nivel, u.departamento,
                u.idusuario, u.ativo
           from estacao e, usuario u) e, estacaousuario eu
 where eu.idestacao(+) = e.idestacao
   and eu.idusuario(+) = e.idusuario
   and e.idusuario > 0
/

