create view VT_SERVICOETIQUETAEXTERNA as
select s.id, s.descr, s.tiposervico, s.urlservico urlservicoetqext,
       s.codigointegracao, s.ativo, s.iddepositante h$iddepositante
  from servicoetiquetaexterna s
/

