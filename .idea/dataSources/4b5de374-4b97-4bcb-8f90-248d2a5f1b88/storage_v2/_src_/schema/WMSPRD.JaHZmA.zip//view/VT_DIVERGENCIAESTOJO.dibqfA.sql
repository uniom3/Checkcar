create view VT_DIVERGENCIAESTOJO as
select decode((select count(1)
                 from kitproduto kp
                where kp.idprodutokit = idl.idproduto), 0, 'ESTOJO', 'KIT') tipo,
       p.descr produto, idl.loteindustria ltind2, e.razaosocial depositante,
       idl.barra, idl.vencimento dtvenc2, idl.idlocal local2,
       sum(ie.estoque) estoque, idl.qtd contagem,
       (idl.qtd - sum(ie.estoque)) diferenca, idl.idinventario,
       idl.identidade iddepositante, idl.idproduto, ie.idlocal
  from invdetliberado idl, invest ie, depositante d, entidade e, produto p
 where ie.idinventario = idl.idinventario
   and ie.idproduto = idl.idproduto
   and ie.identidade = idl.identidade
   and ie.loteindustria = idl.loteindustria
   and idl.identidade = d.identidade
   and ie.identidade = d.identidade
   and ie.idlocal = idl.idlocal
   and d.controlefiscalkitcomponente = 0
   and d.identidade = e.identidade
   and p.idproduto = ie.idproduto
   and p.idproduto = idl.idproduto
   and (exists (select 1
                  from ordemservico os
                 where os.idproduto = idl.idproduto
                   and os.tiposervico = 'E') or exists
        (select 1
           from kitproduto kp, ordemkit ok, ordemservico os
          where kp.idprodutokit = idl.idproduto
            and os.tiposervico = 'I'
            and os.idordemservico = ok.idordemservico
            and ok.idprodutokit = kp.idprodutokit))
 group by p.descr, idl.loteindustria, e.razaosocial, idl.barra,
          idl.vencimento, idl.idlocal, idl.qtd, idl.idinventario,
          idl.identidade, idl.idproduto, ie.idlocal
union all
select decode((select count(1)
                 from kitproduto kp
                where kp.idprodutokit = idl.idproduto), 0, 'ESTOJO', 'KIT') tipo,
       p.descr produto, idl.loteindustria ltind2, e.razaosocial depositante,
       idl.barra, idl.vencimento dtvenc2, idl.idlocal local2, 0 estoque,
       idl.qtd contagem, (idl.qtd) diferenca, idl.idinventario,
       idl.identidade iddepositante, idl.idproduto, ie.idlocal
  from invdetliberado idl, invest ie, depositante d, entidade e, produto p
 where ie.idinventario = idl.idinventario
   and ie.idproduto = idl.idproduto
   and ie.identidade = idl.identidade
   and ie.loteindustria = idl.loteindustria
   and idl.identidade = d.identidade
   and ie.identidade = d.identidade
   and ie.idlocal <> idl.idlocal
   and d.controlefiscalkitcomponente = 0
   and d.identidade = e.identidade
   and p.idproduto = ie.idproduto
   and p.idproduto = idl.idproduto
   and (exists (select 1
                  from ordemservico os
                 where os.idproduto = idl.idproduto
                   and os.tiposervico = 'E') or exists
        (select 1
           from kitproduto kp, ordemkit ok, ordemservico os
          where kp.idprodutokit = idl.idproduto
            and os.tiposervico = 'I'
            and os.idordemservico = ok.idordemservico
            and ok.idprodutokit = kp.idprodutokit))
 group by p.descr, idl.loteindustria, e.razaosocial, idl.barra,
          idl.vencimento, idl.idlocal, idl.qtd, idl.idinventario,
          idl.identidade, idl.idproduto, ie.idlocal
/

