create view VT_PEDIDOSCOMCORTE as
select nfd.idnfdeti h$tableid, nf.nome_dest cliente, nf.numpedido pedido,
       nf.codigointerno documento, nfd.dataimportacao DTIMPORTACAO,
       nfd.codigoindustria CODPRODUTO, nfd.barra barra,
       nfd.descr_prod produto, nfd.qtde QTDESOLICITADA,
       nvl(nfd.qtdefaturada, nfd.qtdeatendida) QTDEATENDIDA,
       nfd.vlrunit VALORUNITARIO, nfd.vlrtotal VALORTOTAL,
       (nfd.vlrtotal /
        (decode(nvl(nfd.qtdefaturada, nfd.qtdeatendida), 0, nfd.qtde,
                 nvl(nfd.qtdefaturada, nfd.qtdeatendida)))) *
        (nfd.qtde - nvl(nfd.qtdefaturada, nfd.qtdeatendida)) VALORCORTE,
       (nfd.qtde - (nvl(nfd.qtdefaturada, nfd.qtdeatendida))) qtdeCorte,
       decode(n.statusnf, 'N', 'NORMAL', 'X', 'CANCELADA', 'B', 'BLOQUEADA',
               'P', 'PROCESSADA') STATUSNF,
       decode(n.estoqueverificado, 'N', 'PENDENTE', 'S', 'LIBERADO', 'X',
               'NÃO LIBERADO') STATUSLIBERACAO, n.idarmazem h$idarmazem
  from nfdetimpressao nfd, nfimpressao nf, notafiscal n
 WHERE n.idprenf = nf.idprenf
   and nf.idprenf = nfd.idprenf
   and nfd.qtdeatendida <> nfd.qtde
/

