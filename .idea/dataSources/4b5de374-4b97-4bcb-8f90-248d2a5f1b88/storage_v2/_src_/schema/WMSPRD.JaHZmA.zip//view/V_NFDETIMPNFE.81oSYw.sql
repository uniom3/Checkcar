create view V_NFDETIMPNFE as
select nd.idprenf, nd.codigoindustria codigointerno, nd.descr_prod produto, nd.ncm, nd.cest,
       nd.st, nd.cfop, nd.descrreduzido, nd.qtde,
       nd.vlrunit valorunitliquido, nd.totalliquido valortotalliquido,
       nd.baseicms baseicmsprod, nd.valoricms valoricmsprod, nd.ipi ipiprod,
       nd.aliqicms, nd.aliqipi, nd.origemproduto,
       nd.descr_prod || nd.infadicionalprod prodcompleto
  from nfdetimpressao nd
/

