create view VB_FAMILIA as
select e.codigointerno codigo, e.razaosocial familia,
       decode(e.pessoa, 'J', e.cgc, e.cic) CNPJ, t.descr tipo,
       st.descr SubTipo, e.identidade idFamilia
  from entidade e, tipo t, subtipo st
 where e.ativo = 'S'
   and t.idtipo = e.tipoentidade
   and st.idsubtipo(+) = e.subtipoentidade
   and ((t.descr like '%DEPOSITANTE%') or (t.descr like '%FORNECEDOR%') or
        (t.descr like '%PROPRIETARIO%') or (st.descr like '%EDITORA%'))


/

