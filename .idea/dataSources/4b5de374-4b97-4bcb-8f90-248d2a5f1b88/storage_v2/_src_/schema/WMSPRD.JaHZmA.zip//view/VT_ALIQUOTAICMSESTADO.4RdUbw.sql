create view VT_ALIQUOTAICMSESTADO as
select rownum h$tableid ,v."ESTADO",v."AC",v."AL",v."AM",v."AP",v."BA",v."CE",v."DF",v."ES",v."GO",v."MA",v."MG",v."MS",v."MT",v."PA",v."PB",v."PE",v."PI",v."PR",v."RJ",v."RN",v."RO",v."RR",v."RS",v."SC",v."SE",v."SP",v."TO" from (
select c.ufo Estado, max( decode(c.ufd, 'AC',  pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0) ) "AC",
      max( decode(c.ufd, 'AL', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)  )  "AL",
      max(decode(c.ufd, 'AM', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "AM",
       max(decode(c.ufd, 'AP', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "AP",
       max(decode(c.ufd, 'BA', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "BA",
       max(decode(c.ufd, 'CE', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "CE",
       max(decode(c.ufd, 'DF', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "DF",
       max(decode(c.ufd, 'ES', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "ES",
       max(decode(c.ufd, 'GO', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "GO",
       max(decode(c.ufd, 'MA', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "MA",
       max(decode(c.ufd, 'MG', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "MG",
       max(decode(c.ufd, 'MS', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "MS",
       max(decode(c.ufd, 'MT', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "MT",
       max(decode(c.ufd, 'PA', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "PA",
       max(decode(c.ufd, 'PB', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "PB",
       max(decode(c.ufd, 'PE', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "PE",
       max(decode(c.ufd, 'PI', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "PI",
       max(decode(c.ufd, 'PR', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "PR",
       max(decode(c.ufd, 'RJ', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "RJ",
       max(decode(c.ufd, 'RN', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "RN",
       max(decode(c.ufd, 'RO', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "RO",
       max(decode(c.ufd, 'RR', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "RR",
       max(decode(c.ufd, 'RS', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "RS",
       max(decode(c.ufd, 'SC', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "SC",
       max(decode(c.ufd, 'SE', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "SE",
       max(decode(c.ufd, 'SP', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "SP",
       max(decode(c.ufd, 'TO', pk_notaremessa.getAliquotaICMSEstado(c.ufo, c.ufd), 0)) "TO"
  from AliquotaICMSEstado c
 group by c.ufo
 order by c.ufo) v
/

