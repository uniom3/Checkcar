create package body pk_onda_liberar_01 is
  function isRemanejamentoPendente
  (
    p_idOnda   in number,
    p_tipoOnda in number
  ) return number is
  
    v_temrempendente number;
  
  begin
  
    if (p_tipoOnda = TIPO_ONDA_NORMAL) then
      select count(distinct r.idremanejamento)
        into v_temrempendente
        from movimentacao m, loteremanejamento lr, remanejamento r, local l
       where m.idonda = p_idOnda
         and m.etapa = 1
         and lr.idlote = m.idlote
         and r.idremanejamento = lr.idremanejamento
         and r.status <> 'F'
         and exists (select 1
                from remanejamentoromaneio rr
               where rr.idremanejamento = r.idremanejamento
                 and rr.idlote = lr.idlote
                 and rr.idromaneio <= m.idonda)
         and l.idlocal = r.idlocaldestino
         and l.tipo = 0
         and l.buffer = 'N';
    else
      select count(distinct lr.idremanejamento)
        into v_temrempendente
        from paleteondanf p, loteremanejamento lr, remanejamento r
       where p.idonda = p_idOnda
         and p.idlote = lr.idlote
         and r.idremanejamento = lr.idremanejamento
         and r.status <> 'F';
    end if;
  
    return v_temrempendente;
  
  end isRemanejamentoPendente;

  procedure liberarOnda
  (
    p_idOnda    number,
    p_idUsuario number
  ) is
  
    v_onda                     romaneiopai%rowtype;
    v_tipoonda                 configuracaoonda.tipoonda%type;
    v_ordem                    number;
    v_mascarabloco             armazem.mascarabloco%type;
    v_agruparvolruaexped       number;
    v_modaltransporte          number;
    v_permiteseparacaomultipla number;
    v_formarondalibexec        number;
    v_configuracaoOnda         configuracaoonda%rowtype;
    v_inicioLiberacaoOnda      date;
    v_fimLiberacaoOnda         date;
  
    v_msg t_message;
  
    vsMsgLogLiberacao varchar2(800);
  
    procedure carregarOnda is
    begin
      select *
        into v_onda
        from romaneiopai rp
       where rp.idromaneio = p_idOnda
         for update;
    exception
      when no_data_found then
        v_msg := t_message('Onda id: {0} não encontrada. Operação Cancelada.');
        v_msg.addParam(p_idOnda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    procedure validarLiberacao is
      v_qtdeondasliberadas     number;
      v_qtdeondaparalela       number;
      v_obrigarremanteslibonda number;
      v_temrempendente         number;
      v_controlepinconfirmado  number;
      v_tiponf                 varchar2(1);
    
      C_TIPO_NOTAFISCAL constant char := 'N';
    begin
      if (v_onda.Statusonda <> C_STATUS_ONDA_FORMADA) then
        v_msg := t_message('Não é possivel liberar a onda id: {0} pois seu status esta diferente de GERADA.');
        v_msg.addParam(v_onda.Idromaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      begin
        select nf.tiponf
          into v_tiponf
          from nfromaneio nfr, notafiscal nf, romaneiopai rp,
               configuracaoonda co
         where nfr.idromaneio = p_idOnda
           and co.conferenciapesagem = 1
           and nf.idnotafiscal = nfr.idnotafiscal
           and rp.idromaneio = nfr.idromaneio
           and co.idconfiguracaoonda = rp.idconfiguracaoonda;
      exception
        when too_many_rows then
          v_msg := t_message('A onda está parametrizada para o fluxo de conferência por pesagem, e este aceita apenas um pedido na onda.');
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          v_tiponf := '0';
      end;
    
      if (v_tiponf = C_TIPO_NOTAFISCAL) then
        v_msg := t_message('Para fluxo de conferência por pesagem, pode existir apenas pedido na onda.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (pk_triggers_control.isTriggerDisable('KIT/ESTOJAMENTO')) then
        v_qtdeondasliberadas := 0;
      else
        select count(*)
          into v_qtdeondasliberadas
          from romaneiopai o
         where o.tipo = 1
           and o.statusonda = C_STATUS_ONDA_LIBERADA
           and o.idarmazem = v_onda.Idarmazem;
      end if;
    
      select a.qtdeondaparalela, a.mascarabloco,
             a.agruparvolumesruaexpedicao, a.modaltransporte
        into v_qtdeondaparalela, v_mascarabloco, v_agruparvolruaexped,
             v_modaltransporte
        from armazem a
       where a.idarmazem = v_onda.Idarmazem;
    
      if (v_qtdeondasliberadas >= v_qtdeondaparalela) then
        v_msg := t_message('A onda não pode ser liberada porque a quantidade de ondas liberadas ({0})' ||
                           ' é maior ou igual a quantidade de ondas em paralelo ({1}) definida na configuração do armazém.');
        v_msg.addParam(v_qtdeondasliberadas);
        v_msg.addParam(v_qtdeondaparalela);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select co.obrigarremanteslibonda, co.tipoonda,
             co.permiteseparacaomultipla
        into v_obrigarremanteslibonda, v_tipoonda,
             v_permiteseparacaomultipla
        from configuracaoonda co
       where co.idconfiguracaoonda = v_onda.Idconfiguracaoonda;
    
      v_temrempendente := isRemanejamentoPendente(v_onda.idromaneio,
                                                  v_tipoonda);
    
      if (v_obrigarremanteslibonda = 1 and v_temrempendente > 0) then
        v_msg := t_message('Não foi possível liberar a onda número: {0}' ||
                           ' para separação, pois existe(m) remanejamento(s) pendente(s) para a mesma.');
        v_msg.addParam(v_onda.Codigointerno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*) total
        into v_controlepinconfirmado
        from dual
       where exists (select 1
                from nfromaneio nfr, notafiscal nf
               where nfr.idromaneio = v_onda.Idromaneio
                 and nf.idnotafiscal = nfr.idnotafiscal
                 and nvl(nf.controlepin, 0) = 1);
    
      if (v_controlepinconfirmado > 0) then
        v_msg := t_message('Não foi possível liberar a onda número: {0}' ||
                           ' para separação, pois existe(m) Notas Fiscais Pendente de Confirmação do PIN.');
        v_msg.addParam(v_onda.Codigointerno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (pk_transftitularidade.isTransfTitularidade(v_onda.Idromaneio)) then
        v_msg := t_message('Onda é do tipo "Transferência de Titularidade". Operação Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      for c_nf in (select nf.idnotafiscal
                     from nfromaneio nfr, notafiscal nf
                    where 1 = 1
                      and nf.idnotafiscal = nfr.idnotafiscal
                      and nfr.idromaneio = v_onda.Idromaneio)
      loop
        pk_ordemseparacao.validaPedFatOrdemSep(c_nf.idnotafiscal,
                                               pk_ordemseparacao.C_OF_BLOQUEIA_LIBERACAOONDA);
      end loop;
    
    end validarLiberacao;
  
    procedure ordenarMovSepOnda is
    
      procedure definirOrdemDasMovRuas
      (
        p_idonda          in number,
        p_idregiaoorigem  in number,
        p_bufferorigem    in char,
        p_idregiaodestino in number,
        p_bufferdestino   in char,
        p_ordem           in out number,
        p_bloco           in varchar := null
      ) is
      
        C_MODO_CORREDOR_LARGO_E_VNA constant number := 1;
        C_SEP_DECRESCENTE           constant number := 0;
        C_SEP_CRESCENTE             constant number := 1;
        C_NAO                       constant number := 0;
        C_SIM                       constant number := 1;
      
        v_ordemCrescente     boolean := false;
        v_idlocalorigem      local.idlocal%type;
        v_idproduto          number;
        v_separacaoCrescente number;
        v_alternaParImpar    number;
      
        procedure definirSepCrescenteImparPar(p_rua in varchar2) is
        begin
          for c_movrua in (select m.id, lo.idlocal, lt.idproduto
                             from movimentacao m, local lo, local ld, lote lt
                            where m.idonda = p_idonda
                              and m.status in (0, 1, 2)
                              and lo.id = m.idlocalorigem
                              and lo.idregiao = p_idregiaoorigem
                              and lo.buffer = p_bufferorigem
                              and lo.rua = p_rua
                              and ld.id = m.idlocaldestino
                              and ld.idregiao = p_idregiaodestino
                              and ld.buffer = p_bufferdestino
                              and lt.idlote = m.idlote
                            order by lo.bloco asc, lo.rua asc, lo.predio asc,
                                     lo.andar asc, lo.apartamento asc,
                                     lo.idlocal asc)
          loop
            if ((v_idlocalorigem <> c_movrua.idlocal or
               v_idproduto <> c_movrua.idproduto) and p_bufferorigem = 'N') then
              p_ordem := p_ordem + 1;
            
              v_idlocalorigem := c_movrua.idlocal;
              v_idproduto     := c_movrua.idproduto;
            end if;
          
            update movimentacao
               set ordem = p_ordem
             where id = c_movrua.id;
          
          end loop;
        end definirSepCrescenteImparPar;
      
        procedure definirSepCrescenteLinear(p_rua in varchar2) is
        begin
        
          for c_movRua in (select *
                             from (select impar.*
                                      from (select m.id, lt.idproduto, 0 ordem,
                                                    lo.bloco, lo.rua, lo.predio,
                                                    lo.andar, lo.apartamento,
                                                    lo.idlocal
                                               from movimentacao m, local lo,
                                                    local ld, lote lt
                                              where m.idonda = p_idonda
                                                and m.status in (0, 1, 2)
                                                and lo.id = m.idlocalorigem
                                                and lo.idregiao =
                                                    p_idregiaoorigem
                                                and lo.buffer = p_bufferorigem
                                                and lo.rua = p_rua
                                                and ld.id = m.idlocaldestino
                                                and ld.idregiao =
                                                    p_idregiaodestino
                                                and ld.buffer = p_bufferdestino
                                                and lt.idlote = m.idlote
                                                and mod(lo.predio, 2) <> 0) impar
                                    union all
                                    select par.*
                                      from (select m.id, lt.idproduto, 1 ordem,
                                                    lo.bloco, lo.rua, lo.predio,
                                                    lo.andar, lo.apartamento,
                                                    lo.idlocal
                                               from movimentacao m, local lo,
                                                    local ld, lote lt
                                              where m.idonda = p_idonda
                                                and m.status in (0, 1, 2)
                                                and lo.id = m.idlocalorigem
                                                and lo.idregiao =
                                                    p_idregiaoorigem
                                                and lo.buffer = p_bufferorigem
                                                and lo.rua = p_rua
                                                and ld.id = m.idlocaldestino
                                                and ld.idregiao =
                                                    p_idregiaodestino
                                                and ld.buffer = p_bufferdestino
                                                and lt.idlote = m.idlote
                                                and mod(lo.predio, 2) = 0) par) locais
                            order by locais.ordem asc, locais.bloco asc,
                                     locais.rua asc, locais.predio asc,
                                     locais.andar asc, locais.apartamento asc,
                                     locais.idlocal asc)
          loop
          
            if ((v_idlocalorigem <> c_movrua.idlocal or
               v_idproduto <> c_movrua.idproduto) and p_bufferorigem = 'N') then
              p_ordem := p_ordem + 1;
            
              v_idlocalorigem := c_movrua.idlocal;
              v_idproduto     := c_movrua.idproduto;
            end if;
          
            update movimentacao
               set ordem = p_ordem
             where id = c_movrua.id;
          
          end loop;
        end definirSepCrescenteLinear;
      
        procedure definirSepDecrescenteParImpar(p_rua in varchar2) is
        begin
          for c_movrua in (select m.id, lo.idlocal, lt.idproduto
                             from movimentacao m, local lo, local ld, lote lt
                            where m.idonda = p_idonda
                              and m.status in (0, 1, 2)
                              and lo.id = m.idlocalorigem
                              and lo.idregiao = p_idregiaoorigem
                              and lo.buffer = p_bufferorigem
                              and lo.rua = p_rua
                              and ld.id = m.idlocaldestino
                              and ld.idregiao = p_idregiaodestino
                              and ld.buffer = p_bufferdestino
                              and lt.idlote = m.idlote
                            order by lo.bloco desc, lo.rua desc,
                                     lo.predio desc, lo.andar desc,
                                     lo.apartamento desc, lo.idlocal desc)
          loop
            if ((v_idlocalorigem <> c_movrua.idlocal or
               v_idproduto <> c_movrua.idproduto) and p_bufferorigem = 'N') then
              p_ordem := p_ordem + 1;
            
              v_idlocalorigem := c_movrua.idlocal;
              v_idproduto     := c_movrua.idproduto;
            end if;
          
            update movimentacao
               set ordem = p_ordem
             where id = c_movrua.id;
          end loop;
        end definirSepDecrescenteParImpar;
      
        procedure definirSepDecrescenteLinear(p_rua in varchar2) is
        begin
          for c_movRua in (select *
                             from (
                                    
                                    select impar.*
                                      from (select m.id, lt.idproduto, 1 ordem,
                                                     lo.bloco, lo.rua, lo.predio,
                                                     lo.andar, lo.apartamento,
                                                     lo.idlocal
                                                from movimentacao m, local lo,
                                                     local ld, lote lt
                                               where m.idonda = p_idonda
                                                 and m.status in (0, 1, 2)
                                                 and lo.id = m.idlocalorigem
                                                 and lo.idregiao =
                                                     p_idregiaoorigem
                                                 and lo.buffer = p_bufferorigem
                                                 and lo.rua = p_rua
                                                 and ld.id = m.idlocaldestino
                                                 and ld.idregiao =
                                                     p_idregiaodestino
                                                 and ld.buffer = p_bufferdestino
                                                 and lt.idlote = m.idlote
                                                 and mod(lo.predio, 2) <> 0) impar
                                    
                                    union all
                                    
                                    select par.*
                                      from (select m.id, lt.idproduto, 0 ordem,
                                                     lo.bloco, lo.rua, lo.predio,
                                                     lo.andar, lo.apartamento,
                                                     lo.idlocal
                                                from movimentacao m, local lo,
                                                     local ld, lote lt
                                               where m.idonda = p_idonda
                                                 and m.status in (0, 1, 2)
                                                 and lo.id = m.idlocalorigem
                                                 and lo.idregiao =
                                                     p_idregiaoorigem
                                                 and lo.buffer = p_bufferorigem
                                                 and lo.rua = p_rua
                                                 and ld.id = m.idlocaldestino
                                                 and ld.idregiao =
                                                     p_idregiaodestino
                                                 and ld.buffer = p_bufferdestino
                                                 and lt.idlote = m.idlote
                                                 and mod(lo.predio, 2) = 0) par
                                    
                                    ) locais
                            order by locais.ordem desc, locais.bloco desc,
                                     locais.rua desc, locais.predio desc,
                                     locais.andar desc,
                                     locais.apartamento desc,
                                     locais.idlocal desc)
          
          loop
          
            if ((v_idlocalorigem <> c_movrua.idlocal or
               v_idproduto <> c_movrua.idproduto) and p_bufferorigem = 'N') then
              p_ordem := p_ordem + 1;
            
              v_idlocalorigem := c_movrua.idlocal;
              v_idproduto     := c_movrua.idproduto;
            end if;
          
            update movimentacao
               set ordem = p_ordem
             where id = c_movrua.id;
          
          end loop;
        end definirSepDecrescenteLinear;
      
      begin
      
        v_ordemCrescente := true;
      
        for c_ruareg in (select distinct lo.rua
                           from movimentacao m, local lo, local ld
                          where m.idonda = p_idonda
                            and m.status in (0, 1, 2)
                            and lo.id = m.idlocalorigem
                            and lo.idregiao = p_idregiaoorigem
                            and lo.buffer = p_bufferorigem
                            and nvl(lo.bloco, '-1') = nvl(p_bloco, '-1')
                            and ld.id = m.idlocaldestino
                            and ld.idregiao = p_idregiaodestino
                            and ld.buffer = p_bufferdestino
                          order by lo.rua)
        loop
        
          if (v_configuracaoOnda.Modoseparacaoonda =
             C_MODO_CORREDOR_LARGO_E_VNA) then
          
            begin
              select cmso.crescente, cmso.alternapareimpar
                into v_separacaoCrescente, v_alternaParImpar
                from configuracaomodoseparacaoonda cmso
               where cmso.bloco = p_bloco
                 and cmso.rua = c_ruareg.rua;
            exception
              when no_data_found then
                v_msg := t_message('Configuração não encontrada na tabela de separação customizada para o Bloco:"{0}" e Rua:"{1}"');
                v_msg.addParam(p_bloco);
                v_msg.addParam(c_ruareg.rua);
                raise_application_error(-20000, v_msg.formatMessage);
            end;
          
            v_idlocalorigem := ' ';
            v_idproduto     := 0;
          
            if (v_separacaoCrescente = C_SEP_CRESCENTE and
               v_alternaParImpar = C_SIM) then
            
              definirSepCrescenteImparPar(c_ruareg.rua);
            
            elsif (v_separacaoCrescente = C_SEP_CRESCENTE and
                  v_alternaParImpar = C_NAO) then
            
              definirSepCrescenteLinear(c_ruareg.rua);
            
            elsif (v_separacaoCrescente = C_SEP_DECRESCENTE and
                  v_alternaParImpar = C_SIM) then
            
              definirSepDecrescenteParImpar(c_ruareg.rua);
            
            elsif (v_separacaoCrescente = C_SEP_DECRESCENTE and
                  v_alternaParImpar = C_NAO) then
            
              definirSepDecrescenteLinear(c_ruareg.rua);
            
            else
              v_msg := t_message('Configuração não inserida na tabela de separação customizada para o Bloco:"{0}" e Rua:"{1}"');
              v_msg.addParam(p_bloco);
              v_msg.addParam(c_ruareg.rua);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
          else
          
            if (v_ordemCrescente) then
            
              v_idlocalorigem := ' ';
              v_idproduto     := 0;
            
              for c_movrua in (select m.id, lo.idlocal, lt.idproduto
                                 from movimentacao m, local lo, local ld,
                                      lote lt
                                where m.idonda = p_idonda
                                  and m.status in (0, 1, 2)
                                  and lo.id = m.idlocalorigem
                                  and lo.idregiao = p_idregiaoorigem
                                  and lo.buffer = p_bufferorigem
                                  and lo.rua = c_ruareg.rua
                                  and ld.id = m.idlocaldestino
                                  and ld.idregiao = p_idregiaodestino
                                  and ld.buffer = p_bufferdestino
                                  and lt.idlote = m.idlote
                                order by lo.bloco asc, lo.rua asc,
                                         lo.predio asc, lo.andar asc,
                                         lo.apartamento asc, lo.idlocal asc)
              loop
                if ((v_idlocalorigem <> c_movrua.idlocal or
                   v_idproduto <> c_movrua.idproduto) and
                   p_bufferorigem = 'N') then
                  p_ordem := p_ordem + 1;
                
                  v_idlocalorigem := c_movrua.idlocal;
                  v_idproduto     := c_movrua.idproduto;
                end if;
              
                update movimentacao
                   set ordem = p_ordem
                 where id = c_movrua.id;
              
              end loop;
            
              v_ordemCrescente := false;
            
            else
            
              v_idlocalorigem := ' ';
              v_idproduto     := 0;
            
              for c_movrua in (select m.id, lo.idlocal, lt.idproduto
                                 from movimentacao m, local lo, local ld,
                                      lote lt
                                where m.idonda = p_idonda
                                  and m.status in (0, 1, 2)
                                  and lo.id = m.idlocalorigem
                                  and lo.idregiao = p_idregiaoorigem
                                  and lo.buffer = p_bufferorigem
                                  and lo.rua = c_ruareg.rua
                                  and ld.id = m.idlocaldestino
                                  and ld.idregiao = p_idregiaodestino
                                  and ld.buffer = p_bufferdestino
                                  and lt.idlote = m.idlote
                                order by lo.bloco desc, lo.rua desc,
                                         lo.predio desc, lo.andar desc,
                                         lo.apartamento desc, lo.idlocal desc)
              loop
                if ((v_idlocalorigem <> c_movrua.idlocal or
                   v_idproduto <> c_movrua.idproduto) and
                   p_bufferorigem = 'N') then
                  p_ordem := p_ordem + 1;
                
                  v_idlocalorigem := c_movrua.idlocal;
                  v_idproduto     := c_movrua.idproduto;
                end if;
              
                update movimentacao
                   set ordem = p_ordem
                 where id = c_movrua.id;
              end loop;
            
              v_ordemCrescente := true;
            
            end if;
          
          end if;
        
        end loop;
      end definirOrdemDasMovRuas;
    
      procedure definirOrdemDasMovBlocos
      (
        p_idonda          in number,
        p_idregiaoorigem  in number,
        p_bufferorigem    in char,
        p_idregiaodestino in number,
        p_bufferdestino   in char,
        p_ordem           in out number
      ) is
      begin
        for c_blocoreg in (select distinct lo.bloco
                             from movimentacao m, local lo, local ld
                            where m.idonda = p_idonda
                              and m.status in (0, 1, 2)
                              and lo.id = m.idlocalorigem
                              and lo.idregiao = p_idregiaoorigem
                              and lo.buffer = p_bufferorigem
                              and ld.id = m.idlocaldestino
                              and ld.idregiao = p_idregiaodestino
                              and ld.buffer = p_bufferdestino
                            order by lo.bloco)
        loop
          definirOrdemDasMovRuas(p_idonda, p_idregiaoorigem, p_bufferorigem,
                                 p_idregiaodestino, p_bufferdestino, p_ordem,
                                 c_blocoreg.bloco);
        end loop;
      end definirOrdemDasMovBlocos;
    
    begin
      v_ordem := 0;
    
      for c_regsep in (select distinct m.idonda, ro.idregiao idregiaoorigem,
                                       lo.buffer bufferorigem,
                                       rd.idregiao idregiaodestino,
                                       ld.buffer bufferdestino
                         from movimentacao m, local lo, local ld,
                              regiaoarmazenagem ro, regiaoarmazenagem rd
                        where m.idonda = v_onda.Idromaneio
                          and m.status in (0, 1, 2)
                          and ld.id = m.idlocaldestino
                          and lo.id = m.idlocalorigem
                          and rd.idregiao = ld.idregiao
                          and ro.idregiao = lo.idregiao
                          and ro.tipo in (0, 1))
      loop
        if (v_mascarabloco is null) then
          definirOrdemDasMovRuas(c_regsep.idonda, c_regsep.idregiaoorigem,
                                 c_regsep.bufferorigem,
                                 c_regsep.idregiaodestino,
                                 c_regsep.bufferdestino, v_ordem);
        else
          definirOrdemDasMovBlocos(c_regsep.idonda, c_regsep.idregiaoorigem,
                                   c_regsep.bufferorigem,
                                   c_regsep.idregiaodestino,
                                   c_regsep.bufferdestino, v_ordem);
        end if;
      end loop;
    
    end ordenarMovSepOnda;
  
    procedure ordenarSepPorCarga is
      procedure definirOrdemDasSepRuas
      (
        p_idonda         in number,
        p_idregiaoorigem in number,
        p_bufferorigem   in char,
        p_ordem          in out number,
        p_bloco          in local.bloco%type := null
      ) is
        v_ordemCrescente boolean := false;
        v_idlocalorigem  local.idlocal%type;
        v_idproduto      number;
      begin
        v_ordemCrescente := true;
      
        for c_ruareg in (select distinct lo.rua
                           from separacaoporcarga m, local lo
                          where m.idonda = p_idonda
                            and m.status in (0, 1, 2)
                            and lo.idarmazem = m.idarmazem
                            and lo.idlocal = m.idlocal
                            and lo.idregiao = p_idregiaoorigem
                            and lo.buffer = p_bufferorigem
                            and nvl(lo.bloco, '-1') = nvl(p_bloco, '-1')
                          order by lo.rua)
        loop
          if (v_ordemCrescente) then
          
            v_idlocalorigem := ' ';
            v_idproduto     := 0;
          
            for c_movrua in (select m.idseparacaoporcarga, lo.idlocal,
                                    m.idproduto
                               from separacaoporcarga m, local lo
                              where m.idonda = p_idonda
                                and m.status in (0, 1, 2)
                                and lo.idarmazem = m.idarmazem
                                and lo.idlocal = m.idlocal
                                and lo.idregiao = p_idregiaoorigem
                                and lo.buffer = p_bufferorigem
                                and lo.rua = c_ruareg.rua
                              order by lo.bloco asc, lo.rua asc,
                                       lo.predio asc, lo.andar asc,
                                       lo.apartamento asc, lo.idlocal asc)
            loop
              if ((v_idlocalorigem <> c_movrua.idlocal or
                 v_idproduto <> c_movrua.idproduto) and
                 p_bufferorigem = 'N') then
                p_ordem := p_ordem + 1;
              
                v_idlocalorigem := c_movrua.idlocal;
                v_idproduto     := c_movrua.idproduto;
              end if;
            
              update separacaoporcarga
                 set ordem = p_ordem
               where idseparacaoporcarga = c_movrua.idseparacaoporcarga;
            
            end loop;
          
            v_ordemCrescente := false;
          
          else
          
            v_idlocalorigem := ' ';
            v_idproduto     := 0;
          
            for c_movrua in (select m.idseparacaoporcarga, lo.idlocal,
                                    m.idproduto
                               from separacaoporcarga m, local lo
                              where m.idonda = p_idonda
                                and m.status in (0, 1, 2)
                                and lo.idarmazem = m.idarmazem
                                and lo.idlocal = m.idlocal
                                and lo.idregiao = p_idregiaoorigem
                                and lo.buffer = p_bufferorigem
                                and lo.rua = c_ruareg.rua
                              order by lo.bloco desc, lo.rua desc,
                                       lo.predio desc, lo.andar desc,
                                       lo.apartamento desc, lo.idlocal desc)
            loop
              if ((v_idlocalorigem <> c_movrua.idlocal or
                 v_idproduto <> c_movrua.idproduto) and
                 p_bufferorigem = 'N') then
                p_ordem := p_ordem + 1;
              
                v_idlocalorigem := c_movrua.idlocal;
                v_idproduto     := c_movrua.idproduto;
              end if;
            
              update separacaoporcarga
                 set ordem = p_ordem
               where idseparacaoporcarga = c_movrua.idseparacaoporcarga;
            end loop;
          
            v_ordemCrescente := true;
          
          end if;
        end loop;
      end definirOrdemDasSepRuas;
    
      procedure definirOrdemDasSepBlocos
      (
        p_idonda         in number,
        p_idregiaoorigem in number,
        p_bufferorigem   in char,
        p_ordem          in out number
      ) is
      begin
        for c_blocoreg in (select distinct lo.bloco
                             from separacaoporcarga m, local lo
                            where m.idonda = p_idonda
                              and m.status in (0, 1, 2)
                              and lo.idarmazem = m.idarmazem
                              and lo.idlocal = m.idlocal
                              and lo.idregiao = p_idregiaoorigem
                              and lo.buffer = p_bufferorigem
                            order by lo.bloco)
        loop
          definirOrdemDasSepRuas(p_idonda, p_idregiaoorigem, p_bufferorigem,
                                 p_ordem, c_blocoreg.bloco);
        end loop;
      end definirOrdemDasSepBlocos;
    begin
      v_ordem := 0;
      for c_regsepcarga in (select distinct m.idonda,
                                            ro.idregiao idregiaoorigem,
                                            lo.buffer bufferorigem
                              from separacaoporcarga m, local lo,
                                   regiaoarmazenagem ro
                             where m.idonda = v_onda.Idromaneio
                               and m.status in (0, 1, 2)
                               and lo.idarmazem = m.idarmazem
                               and lo.idlocal = m.idlocal
                               and ro.idregiao = lo.idregiao
                               and ro.tipo in (0, 1))
      loop
        if (v_mascarabloco is null) then
          definirOrdemDasSepRuas(c_regsepcarga.idonda,
                                 c_regsepcarga.idregiaoorigem,
                                 c_regsepcarga.bufferorigem, v_ordem);
        else
          definirOrdemDasSepBlocos(c_regsepcarga.idonda,
                                   c_regsepcarga.idregiaoorigem,
                                   c_regsepcarga.bufferorigem, v_ordem);
        end if;
      end loop;
    end ordenarSepPorCarga;
  
    procedure gerarColetaAutomatica is
      v_listaNotafiscal pk_carga.tIdNotaFiscal;
      index_i           number;
    begin
      index_i := 1;
    
      if (pk_carga.isColetaAutomatica(null, v_onda.idromaneio, null)) then
        for c_notaonda in (select nfr.idnotafiscal
                             from nfromaneio nfr, notafiscal nf,
                                  depositante d
                            where nfr.idromaneio = v_onda.idromaneio
                              and nf.idnotafiscal = nfr.idnotafiscal
                              and d.identidade = nf.iddepositante
                              and d.tipocoleta = 1)
        loop
          v_listaNotafiscal(index_i) := c_notaonda.idnotafiscal;
          index_i := index_i + 1;
        end loop;
      
        pk_carga.gerarColetaAutomatica(v_listaNotafiscal, p_idusuario);
      end if;
    end gerarColetaAutomatica;
  
    procedure definirIdentificadoresSep is
      v_separacaomultipla number;
      v_identificador     number;
      TIPO_REGIAO_PICKING constant number := 0;
      LOCAL_BUFFER        constant number := 1;
    
      procedure setIdentificadorPorProduto
      (
        p_idonda          number,
        p_idregiaoorigem  number,
        p_bufferdestino   number,
        p_idregiaodestino number,
        v_identificador   in out number
      ) is
        v_idproduto number;
      begin
        v_idproduto := 0;
        for c_movporprod in (select m.id, m.identificador, lt.idproduto
                               from movimentacao m, local lo,
                                    regiaoarmazenagem ro, local ld,
                                    regiaoarmazenagem rd, lote lt
                              where m.idonda = p_idonda
                                and m.status in (0, 1)
                                and rd.idregiao = p_idregiaodestino
                                and rd.idregiao = ld.idregiao
                                and ld.id = m.idlocaldestino
                                and decode(ld.buffer, 'N', 0, 1) =
                                    p_bufferdestino
                                and ro.tipo = TIPO_REGIAO_PICKING
                                and ro.idregiao = p_idregiaoorigem
                                and ro.idregiao = lo.idregiao
                                and lo.id = m.idlocalorigem
                                and decode(lo.buffer, 'N', 0, 1) =
                                    LOCAL_BUFFER
                                and lt.idlote = m.idlote
                              order by lt.idproduto)
        loop
          if (c_movporprod.identificador = 0) then
            if (v_idproduto <> c_movporprod.idproduto) then
              v_identificador := v_identificador + 1;
            
              v_idproduto := c_movporprod.idproduto;
            end if;
          
            update movimentacao m
               set m.identificador = v_identificador
             where id = c_movporprod.id;
          end if;
        end loop;
      end setIdentificadorPorProduto;
    
      procedure setIdentificadorPorPessoas
      (
        p_idonda          number,
        p_idregiaoorigem  number,
        p_bufferdestino   number,
        p_idregiaodestino number,
        p_qtdepessoas     number,
        v_identificador   in out number
      ) is
        v_totallocaisorigem  number;
        v_qtdelocalporpessoa number;
        v_qtdedistribuir     number;
        v_contador           number;
        v_valoratual         number;
        v_idlocalorigem      local.idlocal%type;
      begin
        select count(distinct lo.idlocal)
          into v_totallocaisorigem
          from movimentacao m, local lo, regiaoarmazenagem ro, local ld,
               regiaoarmazenagem rd
         where m.idonda = p_idonda
           and m.status in (0, 1)
           and rd.idregiao = p_idregiaodestino
           and rd.idregiao = ld.idregiao
           and ld.id = m.idlocaldestino
           and decode(ld.buffer, 'N', 0, 1) = p_bufferdestino
           and ro.idregiao = p_idregiaoorigem
           and ro.idregiao = lo.idregiao
           and lo.id = m.idlocalorigem
           and decode(lo.buffer, 'N', 0, 1) <> LOCAL_BUFFER;
      
        if (v_totallocaisorigem > 0) then
          v_qtdelocalporpessoa := trunc(v_totallocaisorigem / p_qtdepessoas);
        
          delete from gtt_aux;
        
          for i in 1 .. p_qtdepessoas
          loop
            insert into gtt_aux
              (valor1, valor2)
            values
              (i, v_qtdelocalporpessoa);
          end loop;
        
          v_qtdedistribuir := mod(v_totallocaisorigem, p_qtdepessoas);
          if (v_qtdedistribuir > 0) then
            for c_aux in (select valor1
                            from gtt_aux
                           order by valor1)
            loop
              update gtt_aux
                 set valor2 = valor2 + 1
               where valor1 = c_aux.valor1;
            
              v_qtdedistribuir := v_qtdedistribuir - 1;
            
              exit when v_qtdedistribuir = 0;
            end loop;
          end if;
        
          v_identificador := v_identificador + 1;
          v_contador      := 0;
          v_valoratual    := 1;
          v_idlocalorigem := null;
        
          for c_movporlocal in (select m.id, lo.idlocal idlocalorigem
                                  from movimentacao m, local lo,
                                       regiaoarmazenagem ro, local ld,
                                       regiaoarmazenagem rd
                                 where m.idonda = p_idonda
                                   and m.status in (0, 1)
                                   and rd.idregiao = p_idregiaodestino
                                   and rd.idregiao = ld.idregiao
                                   and ld.id = m.idlocaldestino
                                   and decode(ld.buffer, 'N', 0, 1) =
                                       p_bufferdestino
                                   and ro.idregiao = p_idregiaoorigem
                                   and ro.idregiao = lo.idregiao
                                   and lo.id = m.idlocalorigem
                                   and decode(lo.buffer, 'N', 0, 1) <>
                                       LOCAL_BUFFER
                                   and m.identificador = 0
                                 order by lo.idlocal)
          loop
            if (nvl(v_idlocalorigem, ' ') <> c_movporlocal.idlocalorigem) then
            
              select valor2
                into v_qtdelocalporpessoa
                from gtt_aux
               where valor1 = v_valoratual;
            
              if (v_contador = v_qtdelocalporpessoa) then
                v_contador      := 0;
                v_valoratual    := v_valoratual + 1;
                v_identificador := v_identificador + 1;
              end if;
            
              v_idlocalorigem := c_movporlocal.idlocalorigem;
              v_contador      := v_contador + 1;
            end if;
          
            update movimentacao m
               set m.identificador = v_identificador
             where id = c_movporlocal.id;
          end loop;
        end if;
      end setIdentificadorPorPessoas;
    begin
      select count(*)
        into v_separacaomultipla
        from gtt_localseparacaoonda g
       where g.idonda = v_onda.Idromaneio;
    
      if (v_separacaomultipla > 0) then
        if (v_permiteseparacaomultipla = 0) then
          v_msg := t_message('Não é possivel definir grupos de identificadores da onda pois a configuração do armazem não permite multiplos separadores.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select nvl(max(identificador), 0) identificador
          into v_identificador
          from movimentacao
         where idonda = v_onda.Idromaneio;
      
        for c_regiao in (select idonda, bufferorigem, idregiaoorigem,
                                tiporegiaoorigem, bufferdestino,
                                idregiaodestino, tiporegiaodestino,
                                qtdepessoas
                           from gtt_localseparacaoonda g
                          where g.idonda = v_onda.Idromaneio)
        loop
          if (c_regiao.tiporegiaoorigem = TIPO_REGIAO_PICKING and
             c_regiao.bufferorigem = LOCAL_BUFFER) then
            setIdentificadorPorProduto(c_regiao.idonda,
                                       c_regiao.idregiaoorigem,
                                       c_regiao.bufferdestino,
                                       c_regiao.idregiaodestino,
                                       v_identificador);
          else
            setIdentificadorPorPessoas(c_regiao.idonda,
                                       c_regiao.idregiaoorigem,
                                       c_regiao.bufferdestino,
                                       c_regiao.idregiaodestino,
                                       c_regiao.qtdepessoas, v_identificador);
          end if;
        end loop;
      end if;
    end definirIdentificadoresSep;
  
    procedure exportarDocumentos is
      C_SEPARACAO_INICIADA constant number := 2;
      C_FAT_LIB_ONDA       constant number := 1;
      C_FAT_DESABILITADO   constant number := 5;
    begin
      for c in (select nfr.idnotafiscal, d.momentofaturamentopedido,
                       co.momentofaturamentopedido expfatonda,
                       d.utilizaautorizacaoexpedicao utilizaAutorizacaoExpedicao
                  from nfromaneio nfr, notafiscal nf, depositante d,
                       configuracaoonda co, romaneiopai rp
                 where nfr.idromaneio = p_idOnda
                   and nfr.idnotafiscal = nf.idnotafiscal
                   and nf.iddepositante = d.identidade
                   and co.idconfiguracaoonda = rp.idconfiguracaoonda
                   and rp.idromaneio = nfr.idromaneio)
      loop
        if (c.expfatonda = C_FAT_LIB_ONDA OR
           (c.expfatonda = C_FAT_DESABILITADO AND
           c.momentofaturamentopedido = C_FAT_LIB_ONDA)) then
          pk_integracao.expFaturamentoPedido(c.idnotafiscal, p_idOnda, null,
                                             null, null, v_onda);
        end if;
      
        if (c.utilizaAutorizacaoExpedicao = 0) then
          pk_integracao.executarExpOutBound(c.idnotafiscal,
                                            C_SEPARACAO_INICIADA);
        end if;
      
      end loop;
    end exportarDocumentos;
  
  begin
    v_inicioLiberacaoOnda := sysdate;
    carregarOnda;
    pk_onda.getConfiguracaoOnda(p_idOnda, v_configuracaoOnda);
    validarLiberacao;
  
    pk_onda_inf.posFormarOnda(p_idonda,
                              v_configuracaoOnda.Idconfiguracaoonda,
                              p_idUsuario, v_configuracaoOnda.tipoOnda);
  
    if (v_tipoonda = TIPO_ONDA_NORMAL) then
      ordenarMovSepOnda;
    
      select count(1)
        into v_formarondalibexec
        from armazem a
       where a.idarmazem = v_onda.idarmazem
         and a.formaondaliberadaexec = 0;
    
      if (v_formarondalibexec >= 1) then
        if (not pk_triggers_control.isTriggerDisable('KIT/ESTOJAMENTO')) then
          pk_romaneio.preencherInfSeparacao(p_idOnda,
                                            v_onda.Idconfiguracaoonda);
        end if;
      end if;
    end if;
  
    if (v_tipoonda = TIPO_ONDA_CARGA) then
      ordenarSepPorCarga;
    end if;
  
    gerarColetaAutomatica;
    definirIdentificadoresSep;
    exportarDocumentos;
    pk_onda.enviarIntegracaoSeparacaoPTL(v_onda, v_configuracaoOnda,
                                         C_ENVIO_PTL_LIBERACAOONDA);
  
    select 'LIBERAÇÃO DA ONDA DE ID: ' || p_idOnda || ' PARA EXECUÇÃO' ||
            decode(a.statusonda, C_STATUS_ONDA_GERADA_CORTE,
                   ', LIBERAÇÃO COM CORTE', '')
      into vsMsgLogLiberacao
      from romaneiopai a
     where a.idromaneio = v_onda.idromaneio;
  
    update romaneiopai
       set statusonda        = C_STATUS_ONDA_LIBERADA,
           dataliberacaoonda = sysdate
     where idromaneio = v_onda.Idromaneio;
  
    v_fimLiberacaoOnda := sysdate;
    pk_utilities.gerarLogTempoExecucao(vsMsgLogLiberacao,
                                       v_inicioLiberacaoOnda,
                                       v_fimLiberacaoOnda);
  end;

end pk_onda_liberar_01;
/

