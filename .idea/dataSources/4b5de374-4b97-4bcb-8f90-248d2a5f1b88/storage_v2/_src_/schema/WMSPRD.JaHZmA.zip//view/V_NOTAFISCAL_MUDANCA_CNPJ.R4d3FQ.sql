create view V_NOTAFISCAL_MUDANCA_CNPJ as
select nf.idprenf, nf.idarmazem, nfi.cnpj_dest, nfi.cnpj_transp, nfi.cnpj_entrega,
       nfi.cnpj_depositante, nfi.cnpj_emitente, nfi.cnpj_unidade,
       nfi.cnpj_transpredespacho, nfi.cnpj_consig
  from notafiscal nf, nfimpressao nfi
 where 1 = 1
   and nfi.idprenf = nf.idprenf
   and nf.statusnf not in ('P', 'X')
/

