create view VT_TRANSFERENCIATITULO as
select t.idtransferencia, saida.datacadastro,
       decode(saida.status, 0, 'Cancelado', 1,
               'Aguardando Reserva de Estoque', 2, 'Aguardando Faturamento', 3,
               'Aguardando Documento de Entrada', 4, 'Aguardando Efetivação',
               5, 'Concluído') status, saida.coddepositantesaida,
       saida.razaoDepSaida, saida.cnpjDepSaida, saida.pedido,
       saida.numeronfvenda, saida.serienfvenda, saida.datareserva,
       saida.usuarioreserva, entrada.coddepositanteentrada,
       entrada.razaoDepEntrada, entrada.cnpjDepEntrada,
       entrada.numeronfentrada, entrada.serienfentrada,
       entrada.datanfentrada, entrada.usuarioentrada,
       t.datatransferencia dataEfetivacao,
       userTransf.Nomeusuario usuarioEfetivacao, t.Datacancelamento,
       userCanc.Nomeusuario usuarioCancelamento, t.idusuarioreserva,
       t.idusuarionfentrada, t.idusuariotransferencia idUsuarioEfetivacao,
       t.idusuariocancelamento, t.status h$status,
       saida.idarmazem h$idarmazem, nvl(saida.gerarnfenttransftitularidade,0) h$gerarNFEnt
  from (select t.idtransferencia, t.datacadastro, t.status,
                e.razaosocial razaoDepSaida, nf.numpedidofornecedor pedido,
                e.codigointerno codDepositanteSaida, e.cgc cnpjDepSaida,
                nf.codigointerno numeroNfVenda, nf.sequencia serieNfVenda,
                t.Datareserva, userReserva.Nomeusuario usuarioReserva,
                nf.idarmazem, dpd.gerarnfenttransftitularidade
           from transferenciatitularidade t, notafiscal nf, entidade e,
                usuario userReserva, depositante dpd
          where t.idnotafiscalsaida = nf.idnotafiscal
            and nf.iddepositante = e.identidade
            and t.idusuarioreserva = userReserva.Idusuario
            and nf.destinatario = dpd.identidade(+)) saida,
       (select t.idtransferencia, e.codigointerno codDepositanteEntrada,
                e.razaosocial razaoDepEntrada, e.cgc cnpjDepEntrada,
                nf.codigointerno numeroNfEntrada, nf.sequencia serieNfEntrada,
                t.datanfentrada, userEntrada.Nomeusuario usuarioEntrada,
                nf.idarmazem
           from transferenciatitularidade t, notafiscal nf, entidade e,
                usuario userEntrada
          where t.idnotafiscalentrada = nf.idnotafiscal
            and nf.iddepositante = e.identidade
            and t.idusuarioreserva = userEntrada.Idusuario) entrada,
       transferenciatitularidade t, usuario userTransf, usuario userCanc
 where saida.idtransferencia = t.idtransferencia
   and saida.idtransferencia = entrada.idtransferencia(+)
   and t.idusuariotransferencia = userTransf.Idusuario(+)
   and t.idusuariocancelamento = userCanc.Idusuario(+)
   and saida.idarmazem = entrada.idarmazem(+)

-- Indica o status da transferencia :Cancelado(0), Aguardando Reserva de Estoque(1), Aguardando
-- Faturamento(2), Aguardando Documento de Entrada(3),
-- Aguardando Efetivação(4), Concluido(5)
/

