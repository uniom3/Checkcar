create package pk_sepondacarga is

  function separacaoManual
  (
    p_idOnda        in number,
    p_tarefa        separacaoporcarga.tarefa%type,
    p_idusuario     in number,
    p_mensagem      in out varchar2,
    p_tipoSeparacao in number := 1
    
  ) return number;

  procedure pausarSeparacao
  (
    p_idOnda    in number,
    p_tarefa    separacaoporcarga.tarefa%type,
    p_idusuario in number
  );

  function getProximaSeparacao
  (
    p_idonda          in number,
    p_tarefa          in varchar2
  ) return number;

  function finalizarSeparacaoCarga
  (
    p_idSeparacaoCarga in number,
    p_idUsuario        in number
  ) return number;

end pk_sepondacarga;
/

