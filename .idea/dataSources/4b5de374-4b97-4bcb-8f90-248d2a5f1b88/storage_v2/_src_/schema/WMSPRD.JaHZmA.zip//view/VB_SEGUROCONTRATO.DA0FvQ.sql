create view VB_SEGUROCONTRATO as
select c.id idcontrato, c.descricao, to_char(c.numero) numero_contrato,
       c.datainicio, c.datatermino, c.identidadepagadora, ep.codigointerno,
       ep.razaosocial entidadepagadora, ep.cgc cnpjpagadora,
       ep.inscrestadual iepagadora, ed.razaosocial depositante, ed.cgc,
       ed.inscrestadual
  from contrato c, entidade ep, contratodepositante cd, entidade ed
 where c.situacao not in (2, 3)
   and ep.identidade = c.identidadepagadora
   and cd.idcontrato(+) = c.id
   and ed.identidade(+) = cd.iddepositante
/

