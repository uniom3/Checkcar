create view VT_CORTEONDA as
select cr.idromaneio, rp.codigointerno codromaneio,
       nf.codigointerno notafiscal, nf.pedido, nf.sequencia nroserie,
       pnfdet.idproduto, pnfdet.codigointerno codproduto,
       pnfdet.descr produto, pnfdet.kitexpexplodida,
       decode(pnfdet.kitexpexplodida, 'S', pcomp.idproduto, null) idprodutocomp,
       decode(pnfdet.kitexpexplodida, 'S', pcomp.codigointerno, null) codprodutocomp,
       decode(pnfdet.kitexpexplodida, 'S', pcomp.descr, null) produtocomp, cr.motivocorte, cr.qtdepedido qtdesolicitada,
       cr.qtdedisponivelpk qtdedisponivel
   from corteromaneio cr, romaneiopai rp, nfromaneio nfr, notafiscal nf,
       nfdet nfdet, produto pnfdet, produto pcomp
 where rp.idromaneio = cr.idromaneio
   and nfr.idromaneio = rp.idromaneio
   and nf.idnotafiscal = nfr.idnotafiscal
   and nfdet.nf = nf.idnotafiscal
   and nfdet.idnfdet = cr.iditemnotafiscal
   and pnfdet.idproduto = nfdet.idproduto
   and pcomp.idproduto = cr.idproduto
/

