create view VT_EMBALAGEM as
select p.codigointerno codproduto, p.descr produto, e.barra,
       e.descr embalagem, e.apresentacao, e.descrreduzido descrreduzido,
       e.fatorconversao, e.altura, e.largura, e.comprimento, e.lastro,
       e.qtdecamada camada, e.empilhamentomax, e.pesobruto, e.pesoliquido,
       e.ativo, e.precadastro, e.datacadastro dtcadastro, e.dataalteracao,
       t.descr tipoembalagem, e.idtipoembalagem, p.idproduto,
       e.idproduto h$idproduto, p.codigointerno h$codproduto,
       p.descr h$produto, e.rowid h$tableid,
       (select count(*)
           from embalagem e
          where e.idproduto = p.idproduto
            and e.fatorconversao = 1) h$countfatorconversao
  from embalagem e, tipoembalagem t, produto p
 where e.idproduto = p.idproduto
   and t.idtipoembalagem(+) = e.idtipoembalagem
/

