create package body pk_ordemseparacao is

  function isAguardandoFaturamentoColmeia(p_idNotafiscal number)
    return number is
  begin
    pk_ordemseparacao.validaPedFatOrdemSep(p_idnotafiscal,
                                           pk_ordemseparacao.C_OF_BLOQUEIA_GERACAOVOLUME);
    return C_OF_FATURADA;
  exception
    when others then
      return C_OF_AGUARDANDO_FATURAMENTO;
  end isAguardandoFaturamentoColmeia;

  function isPermiteExpedirPedFatOrdemSep
  (
    p_idnotafiscal number,
    p_momento      number
  ) return number is
  begin
    pk_ordemseparacao.validaPedFatOrdemSep(p_idnotafiscal, p_momento);
    return C_OF_PERMITE_EXPEDIR_NOTA;
  exception
    when others then
      return C_OF_NAO_PERMITE_EXPEDIR_NOTA;
  end isPermiteExpedirPedFatOrdemSep;

  procedure validaPedFatOrdemSep
  (
    p_idnotafiscal number,
    p_momento      number
  ) is
  
    v_msg                 t_message;
    v_numpedidofornecedor notafiscal.numpedidofornecedor%type;
  
    function isOrdemSeparacaoPedido(p_idnf number) return boolean is
      v_qtde           number;
      r_ordemseparacao ordemseparacao%rowtype;
    begin
    
      select count(1)
        into v_qtde
        from notafiscal nf, depositante d
       where 1 = 1
         and d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and nvl(nf.devolucaofornecedor, 0) = 0
         and nf.idnotafiscal = p_idnf;
    
      if (v_qtde = 0) then
        return false;
      end if;
    
      begin
        select os.*
          into r_ordemseparacao
          from ordemseparacao os
         where 1 = 1
           and os.idnotafiscal = p_idNf;
      exception
        when others then
          v_msg := t_message('O depositante da Nota Fiscal id {0} e pedido {1} esta configurado cadastrar pedido de ordem de separação. Ordem de separação não encontrada.');
          v_msg.addParam(p_idnotafiscal);
          v_msg.addParam(v_numpedidofornecedor);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      select count(1)
        into v_qtde
        from ordemseparacao os, notafiscal nf, depositante d
       where nf.idnotafiscal = os.idnotafiscal
         and d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and os.status in (0, 1)
         and nvl(nf.tiponf, 'P') = 'P'
         and nf.idnotafiscal = p_idnf;
    
      return v_qtde > 0;
    
    end isOrdemSeparacaoPedido;
  
    function isImpedirLiberarPedNaoFat(p_idnf number) return boolean is
      v_qtde number;
    begin
      select count(1)
        into v_qtde
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and d.impedirlibpednaofatexp = 1
         and nf.idnotafiscal = p_idnf;
    
      return v_qtde > 0;
    
    end isImpedirLiberarPedNaoFat;
  
    function isImpedirFormarOndaPedNaoFat(p_idnf number) return boolean is
      v_qtde number;
    begin
      select count(1)
        into v_qtde
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and d.impedirformondapednaofat = 1
         and nf.idnotafiscal = p_idnf;
    
      return v_qtde > 0;
    
    end isImpedirFormarOndaPedNaoFat;
  
    function isImpedirLiberarOndaPedNaoFat(p_idnf number) return boolean is
      v_qtde number;
    begin
      select count(1)
        into v_qtde
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and d.impedirlibondapednaofat = 1
         and nf.idnotafiscal = p_idnf;
    
      return v_qtde > 0;
    
    end isImpedirLiberarOndaPedNaoFat;
  
    function isImpedirGerarVolumePedNaoFat(p_idnf number) return boolean is
      v_qtde number;
    begin
      select count(1)
        into v_qtde
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and d.gerarpedidoof = 1
         and d.impedirgervolpednaofat = 1
         and nf.idnotafiscal = p_idnf;
    
      return v_qtde > 0;
    
    end isImpedirGerarVolumePedNaoFat;
  
  begin
    if (isOrdemSeparacaoPedido(p_idnotafiscal)) then
    
      select nvl(nf.numpedidofornecedor, nf.codigointerno)
        into v_numpedidofornecedor
        from notafiscal nf
       where nf.idnotafiscal = p_idnotafiscal;
    
      if (p_momento = C_OF_BLOQUEIA_LIB_EXPED and
         isImpedirLiberarPedNaoFat(p_idnotafiscal)) then
        v_msg := t_message('O depositante da Nota Fiscal id {0} e pedido {1} esta configurado para impedir liberação de Nota Fiscal não faturada.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(v_numpedidofornecedor);
        raise_application_error(-20000, v_msg.formatMessage);
      
      elsif (p_momento = C_OF_BLOQUEIA_FORMACAOONDA and
            isImpedirFormarOndaPedNaoFat(p_idnotafiscal)) then
        v_msg := t_message('O depositante da Nota Fiscal id {0} e pedido {1} esta configurado para impedir formação de onda de Nota Fiscal não faturada.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(v_numpedidofornecedor);
        raise_application_error(-20000, v_msg.formatMessage);
      
      elsif (p_momento = C_OF_BLOQUEIA_LIBERACAOONDA and
            isImpedirLiberarOndaPedNaoFat(p_idnotafiscal)) then
        v_msg := t_message('O depositante da Nota Fiscal id {0} e pedido {1} esta configurado para impedir liberação de onda de Nota Fiscal não faturada.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(v_numpedidofornecedor);
        raise_application_error(-20000, v_msg.formatMessage);
      
      elsif (p_momento = C_OF_BLOQUEIA_GERACAOVOLUME and
            isImpedirGerarVolumePedNaoFat(p_idnotafiscal)) then
        v_msg := t_message('O depositante da Nota Fiscal id {0} e pedido {1} esta configurado para impedir geração de volume de Nota Fiscal não faturada.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(v_numpedidofornecedor);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
    end if;
  end validaPedFatOrdemSep;

  function isCaixaRecomendadaSIOC
  (
    p_idNotafiscal in notafiscal.idnotafiscal%type,
    p_idEscaninho  in escaninho.idendereco%type
  ) return number is
  
    v_qtdUtiliza           number := 0;
    v_qtdNUtiliza          number := 0;
    v_caixaRecomendadaSIOC number := 0;
  begin
  
    select nvl(sum(decode(x.utilizacaixarecomendada, 0, 1, 0)), 0) nUtiliza,
           nvl(sum(decode(x.utilizacaixarecomendada, 1, 1, 0)), 0) utiliza
      into v_qtdNUtiliza, v_qtdUtiliza
      from (select distinct pd.idproduto, pd.utilizacaixarecomendada
               from escaninho e, conteudoescaninho ce, movimentacao mv,
                    lote lt, produtodepositante pd
              where e.idendereco = ce.idescaninho
                and e.idnotafiscal = p_idNotafiscal
                and e.idendereco = p_idEscaninho
                and ce.idmovimentacao = mv.id
                and mv.idlote = lt.idlote
                and lt.idproduto = pd.idproduto
                and lt.iddepositante = pd.identidade) x;
  
    if (v_qtdUtiliza > 0 and v_qtdNUtiliza = 0) then
      v_caixaRecomendadaSIOC := 1;
    else
      v_caixaRecomendadaSIOC := 0;
    end if;
  
    return v_caixaRecomendadaSIOC;
  
  end isCaixaRecomendadaSIOC;

  /*
   * Pesquisa ordem de separacao por id
  */
  function getOrdemSeparacao(p_idOrdemSeparacao in ordemseparacao.idordemseparacao%type)
    return ordemseparacao%rowtype is
  
    cursor c_ordemseparacao(p_idOrdemSeparacao in number) is
      select *
        from ordemseparacao
       where idordemseparacao = p_idOrdemSeparacao;
  
    r_ordemseparacao c_ordemseparacao%rowtype;
  
  begin
    if c_ordemseparacao%isopen then
      close c_ordemseparacao;
    end if;
    open c_ordemseparacao(p_idOrdemSeparacao);
    fetch c_ordemseparacao
      into r_ordemseparacao;
    if c_ordemseparacao%found then
      close c_ordemseparacao;
      return r_ordemseparacao;
    else
      close c_ordemseparacao;
      return null;
    end if;
  end;

  /**
  * Pesquisa ordem de separacao por codigo interno
  */
  function pesquisaPorCodigoInterno(p_codigoInterno in ordemseparacao.codigointerno%type)
    return ordemseparacao%rowtype is
  
    cursor c_ordemseparacao(p_codigoInterno in varchar2) is
      select *
        from ordemseparacao
       where trim(codigointerno) = trim(p_codigoInterno);
  
    r_ordemseparacao c_ordemseparacao%rowtype;
  begin
    if c_ordemseparacao%isopen then
      close c_ordemseparacao;
    end if;
  
    open c_ordemseparacao(p_codigoInterno);
  
    fetch c_ordemseparacao
      into r_ordemseparacao;
  
    if c_ordemseparacao%found then
      close c_ordemseparacao;
      return r_ordemseparacao;
    else
      close c_ordemseparacao;
      return null;
    end if;
  
  end pesquisaPorCodigoInterno;

  /*
   * Pesquisa cancelamento por id da ordem de separacao
  */

  function pesquisaCancelamentoPorOrdSep
  (
    p_idOrdemSeparacao     in ordemseparacaocancelamento.idordemseparacao%type,
    p_messageControlNumber in number
  ) return ordemseparacaocancelamento%rowtype is
  
    cursor c_ordemseparacaocancelamento(p_idOrdemSeparacao in number) is
      select osc.*
        from ordemseparacaocancelamento osc
       where osc.idordemseparacao = p_idOrdemSeparacao
         and osc.poderecebercancelamentoitem = 1
         and osc.messagecontrolnumber = p_messageControlNumber;
  
    r_ordemseparacaocancelamento c_ordemseparacaocancelamento%rowtype;
  begin
    if c_ordemseparacaocancelamento%isopen then
      close c_ordemseparacaocancelamento;
    end if;
  
    open c_ordemseparacaocancelamento(p_idOrdemSeparacao);
  
    fetch c_ordemseparacaocancelamento
      into r_ordemseparacaocancelamento;
  
    if c_ordemseparacaocancelamento%found then
      close c_ordemseparacaocancelamento;
      return r_ordemseparacaocancelamento;
    else
      close c_ordemseparacaocancelamento;
      return null;
    end if;
  
  end pesquisaCancelamentoPorOrdSep;

  /**
  * Insere cancelamento da ordem de separacao
  */
  function inserirOrdemSepCancelamento
  (
    p_idOrdemSeparacao     in number,
    p_purchaseordernumber  in ordemseparacao.codigointerno%type,
    p_messagecontrolnumber in number
  ) return ordemseparacaocancelamento%rowtype is
  
    v_idordemseparacaocancelamento number;
  
    r_ordemSeparacaoCancelamento ordemseparacaocancelamento%rowtype;
  
  begin
  
    insert into ordemseparacaocancelamento
      (id, idordemseparacao, purchaseordernumber,
       poderecebercancelamentoitem, messagecontrolnumber)
    values
      (seq_ordemseparacaocancelamento.nextval, p_idOrdemSeparacao,
       p_purchaseordernumber, 1, p_messagecontrolnumber)
    returning id into v_idordemseparacaocancelamento;
  
    select osc.*
      into r_ordemSeparacaoCancelamento
      from ordemseparacaocancelamento osc
     where osc.id = v_idordemseparacaocancelamento;
  
    return r_ordemSeparacaoCancelamento;
  end inserirOrdemSepCancelamento;

  /**
  * Insere o item a ser cancelado da ordem de separacao
  */
  function inserirOrdemSepCancItem
  (
    p_idOrdemSeparacaoCancelamento number,
    p_lineitemsequencenumber       in ordemseparacaocancelamentoitem.lineitemsequencenumber%type,
    p_idProduto                    number,
    p_descricaoProduto             in produto.descr%type,
    p_qtde                         number,
    p_status                       number,
    p_etapa                        varchar2,
    p_motivo                       varchar2,
    p_dataSolicitacao              date
  ) return number is
    v_idordemseparacaocancitem number;
  begin
  
    insert into ordemseparacaocancelamentoitem
      (id, idordemseparacaocancelamento, lineitemsequencenumber, idproduto,
       descricao, qtde, status, etapa, motivo, datasolicitacao)
    values
      (seq_ordemsepcancelamentoitem.nextval, p_idOrdemSeparacaoCancelamento,
       p_lineitemsequencenumber, p_idProduto, p_descricaoProduto, p_qtde,
       p_status, p_etapa, p_motivo, p_dataSolicitacao)
    returning id into v_idordemseparacaocancitem;
  
    return v_idordemseparacaocancitem;
  
  end inserirOrdemSepCancItem;

  function atualizarOrdemSepCancItem
  (
    p_idOrdemSepCancItem number,
    p_status             number,
    p_etapa              varchar2,
    p_motivo             number,
    p_isEfetivou         boolean
  ) return number is
    v_idordemseparacaocancitem number;
    v_dataEfetivacao           date;
  begin
  
    v_dataEfetivacao := null;
  
    if p_isEfetivou = true then
      v_dataEfetivacao := sysdate;
    end if;
  
    update ordemseparacaocancelamentoitem osci
       set osci.status         = p_status,
           osci.etapa          = p_etapa,
           osci.motivo         = p_motivo,
           osci.dataefetivacao = v_dataEfetivacao
     where osci.id = p_idOrdemSepCancItem;
  
    return v_idordemseparacaocancitem;
  
  end atualizarOrdemSepCancItem;

  /*
  Verifica se o pedido já iniciou a separação
  */
  function isSeparacaoIniciada
  (
    v_idOnda       number,
    v_idNotaFiscal number
  ) return boolean is
    v_movimentacaoIniciada number;
  begin
    v_movimentacaoIniciada := 0;
  
    select count(mov.id)
      into v_movimentacaoIniciada
      from movimentacao mov
     where mov.idonda = v_idOnda
       and mov.idnotafiscal = v_idNotaFiscal
       and mov.status <> C_STATUS_MOV_CANCELADA
       and mov.qtdeconferida > 0;
  
    return v_movimentacaoIniciada > 0;
  end isSeparacaoIniciada;

  /*
  Verifica se o a quantidade a cancelar é igual ao total de quantidade da nf
  */
  function isQtdeCancelarIgualQtdeNota
  (
    v_idNotaFiscal            notafiscal.idnotafiscal%type,
    v_idSeparacaoCancelamento ordemseparacaocancelamento.id%type
  ) return boolean is
    v_qtdeTotalNota    number;
    v_qtdeParaCancelar number;
  begin
    select sum(nfit.qtde)
      into v_qtdeTotalNota
      from nfdet nfit
     where nfit.nf = v_idNotaFiscal;
  
    select sum(osci.qtde)
      into v_qtdeParaCancelar
      from ordemseparacaocancelamento osc,
           ordemseparacaocancelamentoitem osci
     where osc.id = v_idSeparacaoCancelamento
       and osc.poderecebercancelamentoitem = 1
       and osc.id = osci.idordemseparacaocancelamento
       and osci.status = 0;
  
    return v_qtdeTotalNota = v_qtdeParaCancelar;
  end isQtdeCancelarIgualQtdeNota;

  procedure cancelaOrdemSeparacao
  (
    p_idOrdemSeparacao             in number,
    p_motivo_cancelamento          in varchar2,
    p_idUsuario                    in number,
    p_origemTelaControleNotaFiscal in number := 0
  ) is
    C_XML_MODELO_ASN constant number := 5;
  
    r_ordem_sep              ordemseparacao%rowtype;
    r_notafiscal             notafiscal%rowtype;
    v_erro_can               varchar2(1000);
    v_msg                    t_message;
    v_tipoExpCancelamentoDep number;
  begin
    begin
      select *
        into r_ordem_sep
        from ordemseparacao
       where idordemseparacao = p_idOrdemSeparacao;
    exception
      when no_data_found then
        v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: {0}.' ||
                           chr(13) ||
                           ' Ordem de separação informada não encontrada.');
        v_msg.addParam(p_idOrdemSeparacao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (r_ordem_sep.status = 1) then
      v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: {0}.' ||
                         chr(13) || ' Ordem de separação está processada.');
      v_msg.addParam(p_idOrdemSeparacao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (r_ordem_sep.status = 2) then
      v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: {0}.' ||
                         chr(13) || ' Ordem de separação está cancelada.');
      v_msg.addParam(p_idOrdemSeparacao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (r_ordem_sep.idnotafiscal is not null) then
      begin
        select *
          into r_notafiscal
          from notafiscal
         where idnotafiscal = r_ordem_sep.idnotafiscal;
      exception
        when no_data_found then
          v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: {0}.' ||
                             chr(13) ||
                             ' Nota Fiscal associada Id: {1} não encontrada.');
          v_msg.addParam(p_idOrdemSeparacao);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_tipoExpCancelamentoDep = C_XML_MODELO_ASN and
         p_origemTelaControleNotaFiscal = 0) then
        v_msg := t_message('Depositante id:{0} trabalha com exportação de cancelamento ASN. Cancele a Ordem de separação por meio da Nota/Pedido id:{1} na tela Controle Nota Fiscal.');
        v_msg.addParam(r_notafiscal.iddepositante);
        v_msg.addParam(r_notafiscal.idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_notafiscal.statusnf <> 'X') then
        if (r_notafiscal.estoqueverificado = 'S') then
          v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: ' ||
                             '{0}.' || chr(13) ||
                             ' Nota Fiscal associada Id:' ||
                             '{1} possui liberação para roteização.');
          v_msg.addParam(p_idOrdemSeparacao);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_notafiscal.statusnf = 'P') then
          v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: ' ||
                             '{0}.' || chr(13) ||
                             ' Nota Fiscal associada Id:' ||
                             '{1} está processada.');
          v_msg.addParam(p_idOrdemSeparacao);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (v_tipoExpCancelamentoDep = C_XML_MODELO_ASN and
           p_origemTelaControleNotaFiscal = 0) then
          pk_notafiscal.CancelaNF(r_notafiscal.idprenf, p_idusuario,
                                  p_motivo_cancelamento, 'N', 'N',
                                  v_erro_can);
        end if;
      
        if (v_erro_can is not null) then
          v_msg := t_message('Não é possóvel cancelar a Ordem de separação Id: ' ||
                             '{0}.' || chr(13) ||
                             ' Nota Fiscal associada Id:{1}' ||
                             ' ocorreu um erro ao realizar o cancelamento da nota fiscal.' ||
                             chr(13) || 'Erro: {2}');
          v_msg.addParam(p_idOrdemSeparacao);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          v_msg.addParam(v_erro_can);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end if;
  
    update ordemseparacao
       set status = 2
     where idordemseparacao = p_idOrdemSeparacao;
  
  end cancelaOrdemSeparacao;

  procedure executarOrdemSepCancelamento
  (
    p_idOrdemSeparacao     in ordemseparacao.idordemseparacao%type,
    p_messageControlNumber in ordemseparacaocancelamento.messagecontrolnumber%type,
    p_idUsuarioIntegracao  in number
  ) is
  
    C_ONDA_FORMADA     constant number := 1;
    C_ONDA_LIBERADA    constant number := 2;
    C_ONDA_EM_EXECUCAO constant number := 4;
    C_NAO              constant number := 0;
  
    v_idNotaFiscal             number;
    v_estoqueverificado        number;
    v_etiquetaZplAwsSolicitada number;
    v_statusOnda               number;
    v_fluxoCheckout            number;
    v_idOnda                   number;
    v_pedidoEmOnda             boolean;
    v_removeuNfOnda            boolean;
    v_idConfiguracaoOnda       number;
  
    r_ordemSeparacaoCancelamento ordemseparacaocancelamento%rowtype;
  
    v_msg t_message;
  
  begin
  
    select *
      into r_ordemSeparacaoCancelamento
      from ordemseparacaocancelamento osc
     where osc.idordemseparacao = p_idOrdemSeparacao
       and osc.poderecebercancelamentoitem = 1
       and osc.messagecontrolnumber = p_messageControlNumber;
  
    begin
      select os.idnotafiscal
        into v_idNotaFiscal
        from ordemseparacao os
       where os.idordemseparacao =
             r_ordemSeparacaoCancelamento.Idordemseparacao
         and os.status = 0
         and os.idnotafiscal is not null;
    exception
      when no_data_found then
        v_msg := t_message('Nota Fiscal não encontrada para a Ordem de separação id: {0}');
        v_msg.addParam(r_ordemSeparacaoCancelamento.Idordemseparacao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (not existeQtdeDispParaCancelamento(r_ordemSeparacaoCancelamento)) then
    
      atualizarOrdemSepCancelamento(r_ordemSeparacaoCancelamento.Idordemseparacao,
                                    r_ordemSeparacaoCancelamento.Id, C_NAO,
                                    C_NAO_CANCELADO, C_SIM,
                                    'Não existe quantidade disponível para cancelar.',
                                    r_ordemSeparacaoCancelamento.Messagecontrolnumber);
    
      pk_integracao.exportarOCR(r_ordemSeparacaoCancelamento.Idordemseparacao,
                                r_ordemSeparacaoCancelamento.Messagecontrolnumber);
    
      return;
    end if;
  
    select count(1)
      into v_etiquetaZplAwsSolicitada
      from volumeromaneio vr
     where vr.idnotafiscal = v_idNotaFiscal
       and vr.statusvolume = 0
       and vr.idarquivozpl is not null;
  
    if (v_etiquetaZplAwsSolicitada > 0) then
    
      atualizarOrdemSepCancelamento(r_ordemSeparacaoCancelamento.idordemseparacao,
                                    r_ordemSeparacaoCancelamento.Id, C_NAO,
                                    C_STATUS_NAO_CANCELADO, C_SIM,
                                    'solicitação de etiqueta AWS realizada',
                                    p_messageControlNumber);
    
      pk_integracao.exportarOCR(r_ordemSeparacaoCancelamento.idordemseparacao,
                                r_ordemSeparacaoCancelamento.Messagecontrolnumber);
    else
    
      select decode(nf.estoqueverificado, 'S', 1, 'N', 0)
        into v_estoqueverificado -- Liberado para expedição
        from notafiscal nf
       where nf.idnotafiscal = v_idNotaFiscal;
    
      if (v_estoqueverificado = C_NAO) then
        atualizarOrdemSepENotafiscal(p_idUsuarioIntegracao,
                                     r_ordemSeparacaoCancelamento.idordemseparacao,
                                     r_ordemSeparacaoCancelamento.Id, false,
                                     v_idNotaFiscal, p_messageControlNumber,
                                     null, false, false);
      else
      
        v_pedidoEmOnda := true;
      
        begin
          select rp.idromaneio, rp.statusonda,
                 co.conferenciaporcheckoutexpress, co.idconfiguracaoonda
            into v_idOnda, v_statusOnda, v_fluxoCheckout,
                 v_idConfiguracaoOnda
            from nfromaneio nfr, romaneiopai rp, configuracaoonda co
           where nfr.idnotafiscal = v_idNotaFiscal
             and nfr.idromaneio = rp.idromaneio
             and rp.statusonda <> 5
             and rp.idconfiguracaoonda = co.idconfiguracaoonda; -- != Cancelada
        exception
          when no_data_found then
            v_idOnda       := null;
            v_pedidoEmOnda := false;
        end;
      
        if (not v_pedidoEmOnda) then
          atualizarOrdemSepENotafiscal(p_idUsuarioIntegracao,
                                       r_ordemSeparacaoCancelamento.idordemseparacao,
                                       r_ordemSeparacaoCancelamento.Id, true,
                                       v_idNotaFiscal,
                                       p_messageControlNumber, v_idOnda,
                                       false, false);
          -- O tratamento de cancelamento deve acontecer para onda em: formada, liberada ou execução que não tenha iniciado a separação                                       
        elsif ((v_statusOnda IN
              (C_ONDA_FORMADA, C_ONDA_LIBERADA, C_ONDA_EM_EXECUCAO)) and
              not isSeparacaoIniciada(v_idOnda, v_idNotaFiscal)) then
          v_removeuNfOnda := false;
        
          atualizarMovimentacoes(p_idUsuarioIntegracao,
                                 r_ordemSeparacaoCancelamento,
                                 v_idNotaFiscal, v_idOnda, v_fluxoCheckout,
                                 v_removeuNfOnda);
        
          pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
        
          atualizarOrdemSepENotafiscal(p_idUsuarioIntegracao,
                                       r_ordemSeparacaoCancelamento.idordemseparacao,
                                       r_ordemSeparacaoCancelamento.Id, true,
                                       v_idNotaFiscal,
                                       p_messageControlNumber, v_idOnda,
                                       not v_removeuNfOnda, false);
        
          pk_triggers_control.enableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
        
          pk_onda.criarMapaSeparacaoOnda(v_idOnda, v_idConfiguracaoOnda);
        
        end if;
      
      end if;
    
    end if;
  
  end executarOrdemSepCancelamento;

  procedure atualizarOrdemSepCancelamento
  (
    p_idOrdemSeparacao             in number,
    p_idOrdemSeparacaoCancelamento in number,
    p_podeReceberCancelamentoItem  in number,
    p_resultado                    in number,
    p_liberadaParaExportarOCR      in number,
    p_motivo                       in varchar2,
    p_messageControlNumber         in number
  ) is
  begin
  
    update ordemseparacaocancelamento osc
       set osc.poderecebercancelamentoitem = p_podeReceberCancelamentoItem,
           osc.liberadaParaExportarOCR     = p_liberadaParaExportarOCR
     where osc.idordemseparacao = p_idOrdemSeparacao
       and osc.messagecontrolnumber = p_messageControlNumber;
  
    update ordemseparacaocancelamentoitem osci
       set osci.status = p_resultado,
           osci.motivo = p_motivo
     where osci.idordemseparacaocancelamento =
           p_idOrdemSeparacaoCancelamento;
  
  end atualizarOrdemSepCancelamento;

  procedure atualizarOrdemSepENotafiscal
  (
    p_idUsuarioIntegracao          in number,
    p_idOrdemSeparacao             in number,
    p_idOrdemSeparacaoCancelamento in number,
    p_pedidoLiberadoParaExpedicao  in boolean,
    p_idNotaFiscal                 in number,
    p_messageControlNumber         in number,
    p_idOnda                       in number,
    p_NfEmOnda                     in boolean,
    p_exportarOfr                  in boolean
  ) is
    v_idConfiguracaoOnda         number;
    v_quantidadeRestanteCancelar number;
    v_quantidadeCancelarAgora    number;
  
    procedure baixarNotaFiscal
    (
      p_IdOrdemSeparacao        ordemseparacao.idordemseparacao%type,
      p_IdProduto               produto.idproduto%type,
      p_quantidadeLinhaOriginal number
    ) is
    begin
      for c_Nota in (select nota.idnotafiscal, det.idproduto,
                            (det.qtde * e.fatorconversao) quantidadeNota,
                            det.idnfdet
                       from notafiscal nota, nfdet det, ordemseparacao os,
                            embalagem e
                      where os.idordemseparacao = p_idOrdemSeparacao
                        and nota.idnotafiscal = os.idnotafiscal
                        and e.idproduto = det.idproduto
                        and e.barra = det.barra
                        and det.nf = nota.idnotafiscal
                        and det.qtde = p_quantidadeLinhaOriginal -- filtra a mesma quantidade
                        and det.idproduto = p_IdProduto
                        and rownum = 1) -- para o mesmo produto
      --Lembrando que pode haver duas linhas com a mesma quantidade para o mesmo produto, por isso a utilização desses filtros
      loop
        if (p_pedidoLiberadoParaExpedicao) then
          update nfdet nf
             set nf.qtdeatendida = nf.qtdeatendida -
                                   v_quantidadeCancelarAgora
           where nf.idnfdet = c_Nota.Idnfdet;
        end if;
      
        update nfdet nf
           set nf.qtde = nf.qtde - v_quantidadeCancelarAgora
         where nf.idnfdet = c_Nota.Idnfdet;
      end loop;
    end baixarNotaFiscal;
  
    procedure baixarOrdemSeparacao
    (
      p_IdOrdemSeparacao ordemseparacao.idordemseparacao%type,
      p_IdProduto        produto.idproduto%type
    ) is
    begin
      -- Loop da ordemseparação
      for c_separacao in (select ordemItem.Idproduto,
                                 ordemItem.Qtdeitem quantidade,
                                 ordemItem.Idordemsepitem
                            from ordemseparacaoitem ordemItem
                           where ordemItem.Idordemsep = p_idOrdemSeparacao
                             and ordemItem.Idproduto = p_IdProduto)
      loop
        if (c_separacao.quantidade <= v_quantidadeRestanteCancelar) then
          v_quantidadeRestanteCancelar := v_quantidadeRestanteCancelar -
                                          c_separacao.quantidade;
          v_quantidadeCancelarAgora    := c_separacao.quantidade;
        else
          v_quantidadeCancelarAgora    := v_quantidadeRestanteCancelar;
          v_quantidadeRestanteCancelar := 0;
        end if;
      
        update ordemseparacaoitem osi
           set osi.qtdeitem = osi.qtdeitem - v_quantidadeCancelarAgora
         where osi.idordemsep = p_idOrdemSeparacao
           and osi.idproduto = c_separacao.idproduto
           and osi.idordemsepitem = c_separacao.Idordemsepitem;
      
        baixarNotaFiscal(p_IdOrdemSeparacao, p_IdProduto,
                         c_separacao.quantidade);
      
        exit when v_quantidadeRestanteCancelar <= 0;
      end loop;
    end baixarOrdemSeparacao;
  
  begin
    -- A nota pode não estar em onda (Aguardando aprovação, por exemplo).
    if (p_idOnda is not null) then
      select co.idconfiguracaoonda
        into v_idConfiguracaoOnda
        from romaneiopai rp, configuracaoonda co
       where rp.idromaneio = p_idOnda
         and rp.idconfiguracaoonda = co.idconfiguracaoonda;
    end if;
  
    --Foi necessário fazer os loops abaixo por conta do multilineitem, pois pode ocorrer de
    --para o mesmo produto, ter quantidades iguais ou Não, porém com multilineitem diferentes
  
    -- Loop da ordemSeparacaoCancelamentoItem
    for c_cancelamento in (select cancelItem.Idproduto,
                                  cancelItem.Idordemseparacaocancelamento,
                                  sum(cancelItem.Qtde) quantidade
                             from ordemseparacaocancelamentoitem cancelItem,
                                  ordemseparacaocancelamento cancel
                            where cancelItem.Status = 0
                              and cancelItem.Idordemseparacaocancelamento =
                                  cancel.id
                              and cancel.poderecebercancelamentoitem = 1
                              and cancel.idordemseparacao =
                                  p_idOrdemSeparacao
                            group by cancelitem.idproduto,
                                     cancelItem.Idordemseparacaocancelamento)
    loop
      v_quantidadeRestanteCancelar := c_cancelamento.quantidade;
      v_quantidadeCancelarAgora    := 0;
    
      baixarOrdemSeparacao(p_idOrdemSeparacao, c_cancelamento.idproduto);
    
      if (p_NfEmOnda) then
        pk_onda.criarMapaSeparacaoOndaPedido(p_idOnda, v_idConfiguracaoOnda,
                                             c_cancelamento.idproduto);
      end if;
    end loop;
  
    atualizarOrdemSepCancelamento(p_idOrdemSeparacao,
                                  p_idOrdemSeparacaoCancelamento, C_NAO,
                                  C_STATUS_CANCELADO_COM_SUCESSO, C_SIM,
                                  null, p_messageControlNumber);
  
    pk_integracao.exportarOCR(p_idOrdemSeparacao, p_messageControlNumber);
  
    controleNotaFiscalEItens(p_idOrdemSeparacao, p_idNotaFiscal, p_idOnda,
                             p_NfEmOnda, p_idUsuarioIntegracao,
                             p_exportarOfr);
  
  end atualizarOrdemSepENotafiscal;

  procedure atualizarMovimentacoes
  (
    p_idUsuarioIntegracao        in number,
    r_ordemSeparacaoCancelamento ordemseparacaocancelamento%rowtype,
    p_idNotaFiscal               in number,
    p_idOnda                     in number,
    p_fluxoCheckout              in number,
    p_removerNfDaOndaCheckout    in out boolean
  ) is
  
    v_qtdeParaCancelar           number;
    v_qtdeDisponivelParaCancelar number;
    v_idMovimentacao             number;
    v_fatorConversao             number;
    v_idLote                     number;
    v_idArmazem                  number;
    v_barra                      varchar2(32);
    v_idLocal                    local.idlocal%type;
    v_qtdeEmMov                  number;
    v_aux                        number;
  
    procedure baixarQtdes(p_qtdeCancelar in number) is
    
      procedure baixarTabelas
      (
        p_idNotaFiscal   in number,
        p_idonda         in number,
        p_qtdeSubtrair   in number,
        p_barra          in varchar2,
        p_idLote         in number,
        p_fatorConversao in number
      ) is
      
      begin
      
        update paletseparacaonf psnf
           set psnf.qtde        = psnf.qtde - p_qtdeSubtrair,
               psnf.qtdeunidade =
               (psnf.qtde * p_fatorConversao) - p_qtdeSubtrair
         where 1 = 1
           and psnf.idromaneio = p_idonda
           and psnf.idnotafiscal = p_idNotaFiscal
           and psnf.idlote = p_idLote
           and psnf.barra = p_barra;
      
        delete paletseparacaonf psnf
         where psnf.idromaneio = p_idonda
           and psnf.idnotafiscal = p_idNotaFiscal
           and psnf.idlote = p_idLote
           and psnf.barra = p_barra
           and psnf.qtde = 0;
      
        update saidapornf snf
           set snf.totalseparar      = snf.totalseparar - p_qtdeSubtrair,
               snf.totalconferir     = snf.totalconferir - p_qtdeSubtrair,
               snf.totalpesar        = snf.totalpesar - p_qtdeSubtrair,
               snf.separacaoiniciada = snf.separacaoiniciada -
                                       p_qtdeSubtrair
         where snf.idonda = p_idonda
           and snf.idnotafiscal = p_idNotaFiscal;
      
      end baixarTabelas;
    
    begin
    
      v_qtdeParaCancelar := p_qtdeCancelar;
    
      while v_qtdeParaCancelar > 0
      loop
      
        v_aux := 0;
      
        select lt.idarmazem, m.id, m.idlote, m.quantidade, emb.barra,
               lo.idlocal, emb.fatorconversao
          into v_idArmazem, v_idMovimentacao, v_idLote, v_qtdeEmMov, v_barra,
               v_idlocal, v_fatorConversao
          from movimentacao m, lote lt, produto p, local lo, embalagem emb,
               nfdet det
         where m.idnotafiscal = p_idNotaFiscal
           and m.idonda = p_idOnda
           and m.idlote = lt.idlote
           and m.status = 0
           and m.quantidade <= v_qtdeDisponivelParaCancelar
           and m.quantidade > 0
           and m.idlocalorigem = lo.id
           and lt.idproduto = emb.idproduto
           and det.nf = m.idnotafiscal
           and det.barra = emb.barra
           and det.idproduto = lt.idproduto
           and rownum = 1;
      
        if (v_qtdeEmMov = v_qtdeParaCancelar) then
        
          update movimentacao m
             set m.status = 3
           where m.id = v_idMovimentacao;
        
          v_aux := v_qtdeParaCancelar;
        
        else
        
          if (v_qtdeEmMov > v_qtdeParaCancelar) then
          
            v_aux := v_qtdeParaCancelar;
          
          elsif (v_qtdeEmMov < v_qtdeParaCancelar) then
          
            v_aux := v_qtdeEmMov;
          
          end if;
        
          pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
        
          update movimentacao m
             set m.status = 1
           where m.id = v_idMovimentacao;
        
          pk_estoque.retirar_pendencia(v_idArmazem, v_idLocal, v_idLote,
                                       v_aux, p_idUsuarioIntegracao,
                                       'pendêNCIA DE ' || v_aux ||
                                        ' QUANTIDADE(S) RETIRADA(S) EM função DE ORDEM DE CANCELAMENTO ' ||
                                        r_ordemSeparacaoCancelamento.id ||
                                        ' CONTROL NUMBER ' ||
                                        r_ordemSeparacaoCancelamento.messagecontrolnumber,
                                       v_idMovimentacao);
        
          update movimentacao m
             set m.quantidade      = m.quantidade - v_aux,
                 m.qtdemovimentada = m.qtdemovimentada - v_aux,
                 m.status          = 0
           where m.id = v_idMovimentacao;
        
          pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
        
        end if;
      
        baixarTabelas(p_idNotaFiscal, p_idonda, v_aux, v_barra, v_idLote,
                      v_fatorConversao);
        v_qtdeParaCancelar := v_qtdeParaCancelar - v_qtdeEmMov;
      end loop;
    
    end baixarQtdes;
  
  begin
    --Atencao: Nao retirar esta atribuicao    
    p_removerNfDaOndaCheckout := isQtdeCancelarIgualQtdeNota(p_idNotaFiscal,
                                                             r_ordemSeparacaoCancelamento.Id);
    if (p_removerNfDaOndaCheckout) then
      pk_onda_cancelar.removerNotaFiscalOnda(p_idOnda, p_idNotaFiscal,
                                             p_idUsuarioIntegracao);
    else
      for c_itensCancelar in (select osci.idproduto,
                                     sum(osci.qtde) Qtdecancelar
                                from ordemseparacaocancelamento osc,
                                     ordemseparacaocancelamentoitem osci
                               where osc.id =
                                     r_ordemSeparacaoCancelamento.Id
                                 and osc.poderecebercancelamentoitem = 1
                                 and osc.id =
                                     osci.idordemseparacaocancelamento
                                 and osci.status = 0
                               group by osci.idproduto)
      loop
      
        select sum(nd.qtdeatendida)
          into v_qtdeDisponivelParaCancelar
          from nfdet nd
         where nd.nf = p_idNotaFiscal
           and nd.idproduto = c_itensCancelar.Idproduto;
      
        if (v_qtdeDisponivelParaCancelar > c_itensCancelar.Qtdecancelar) then
        
          baixarQtdes(c_itensCancelar.Qtdecancelar);
        
        elsif (v_qtdeDisponivelParaCancelar = c_itensCancelar.Qtdecancelar) then
        
          if (p_fluxoCheckout > 0) then
          
            p_removerNfDaOndaCheckout := true;
            return;
          
          else
          
            baixarQtdes(c_itensCancelar.Qtdecancelar);
          end if;
        
        end if;
      
      end loop;
    
      for c_movZerada in (select m.id, m.idonda, m.idnotafiscal, m.idlote
                            from movimentacao m
                           where m.idonda = p_idonda
                             and m.idnotafiscal = p_idNotaFiscal
                             and m.quantidade = 0)
      
      loop
      
        update lotelocal ll
           set ll.idmovimentacao = null
         where ll.idmovimentacao = c_movZerada.Id;
      
        delete from grupomovimentacao gm
         where gm.idmovimentacao = c_movZerada.Id;
      
        delete from paletseparacaonf psnf
         where psnf.idromaneio = c_movZerada.Idonda
           and psnf.idnotafiscal = c_movZerada.Idnotafiscal
           and psnf.idlote = c_movZerada.Idlote
           and psnf.qtde = 0;
      
      end loop;
    
      delete from movimentacao m
       where m.idonda = p_idonda
         and m.idnotafiscal = p_idNotaFiscal
         and m.quantidade = 0;
    
    end if;
  
  end atualizarMovimentacoes;

  function existeQtdeDispParaCancelamento(r_ordemSeparacaoCancelamento ordemseparacaocancelamento%rowtype)
    return boolean
  
   is
    v_idOrdemSeparacao     number;
    v_qtdeDispParaCancelar number;
    v_qtdeOrdemSeparacao   number;
    v_qtdeOutrasOC         number;
    v_qtdeConferidaColmeia number;
    v_qtdeCheckout         number;
  
  begin
  
    v_idOrdemSeparacao := r_ordemSeparacaoCancelamento.Idordemseparacao;
  
    for c_itemCancelar in (select osci.idproduto, sum(osci.qtde) qtde
                             from ordemseparacaocancelamentoitem osci
                            where osci.idordemseparacaocancelamento =
                                  r_ordemSeparacaoCancelamento.Id
                            group by osci.idproduto)
    loop
    
      select nvl(sum(osi.qtdeitem), 0) qtdeOrdemSeparacao
        into v_qtdeOrdemSeparacao
        from ordemseparacao os, ordemseparacaoitem osi
       where os.idordemseparacao = v_idOrdemSeparacao
         and os.idordemseparacao = osi.idordemsep
         and os.status = 0 -- Pendente
         and osi.idproduto = c_itemCancelar.Idproduto;
    
      select nvl(sum(osci.qtde), 0) qtdeOutrasOC
        into v_qtdeOutrasOC
        from ordemseparacaocancelamento osc,
             ordemseparacaocancelamentoitem osci
       where osc.idordemseparacao = v_idOrdemSeparacao
         and osc.messagecontrolnumber <>
             r_ordemSeparacaoCancelamento.Messagecontrolnumber
         and osc.poderecebercancelamentoitem = 1
         and osc.id = osci.idordemseparacaocancelamento
         and osci.status = C_AGUARDANDO
         and osci.idproduto = c_itemCancelar.Idproduto;
    
      -- QTDE CONFERIDA NA MONTAGEM DE VOLUME DA COLMEIA
      select nvl(sum(cme.quantidade), 0) qtdeEmVolume
        into v_qtdeConferidaColmeia
        from notafiscal nf, ordemseparacao os, movimentacao m,
             conteudomontagemescaninho cme, confmontvolcolmeia cfv, lote lt,
             produto p
       where os.idordemseparacao = v_idOrdemSeparacao
         and os.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = m.idnotafiscal
         and m.id = cme.idmovimentacao
         and m.status <> 3
         and cme.idconfmontvolcolmeia = cfv.id
         and cfv.status = 3
         and m.idlote = lt.idlote
         and lt.idproduto = c_itemCancelar.Idproduto
         and lt.idproduto = p.idproduto;
    
      -- QTDE EM VOLUME NO CHECKOUT EXPRESS     
      select nvl(sum(m.quantidade), 0)
        into v_qtdeCheckout
        from ordemseparacao os, notafiscal nf, nfromaneio nfr,
             romaneiopai rp, configuracaoonda co, movimentacao m, lote lt
       where os.idordemseparacao = v_idOrdemSeparacao
         and os.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = nfr.idnotafiscal
         and nfr.idromaneio = rp.idromaneio
         and rp.idconfiguracaoonda = co.idconfiguracaoonda
         and rp.statusonda in (1, 2, 4) -- onda formada
         and co.conferenciaporcheckoutexpress = 1
         and rp.idromaneio = m.idonda
         and nf.idnotafiscal = m.idnotafiscal
         and m.status = 2
         and m.idlote = lt.idlote
         and lt.idproduto = c_itemCancelar.Idproduto;
    
      v_qtdeDispParaCancelar := v_qtdeOrdemSeparacao -
                                (v_qtdeOutrasOC + v_qtdeConferidaColmeia +
                                v_qtdeCheckout);
    
      if (c_itemCancelar.Qtde > v_qtdeDispParaCancelar) then
        return false;
      end if;
    
    end loop;
  
    return true;
  
  end existeQtdeDispParaCancelamento;

  function isVolumeGeradoOF(p_idOrdemSeparacao number) return boolean is
    C_STATUVOLUME_ATIVO_OF constant number := 0;
    v_existeVolumeGeradoOF number := 0;
  begin
  
    select count(1)
      into v_existeVolumeGeradoOF
      from ordemseparacao os, volumeromaneio vr
     where os.idnotafiscal = vr.idnotafiscal
       and os.idordemseparacao = p_idOrdemSeparacao
       and vr.statusvolume = C_STATUVOLUME_ATIVO_OF;
  
    return v_existeVolumeGeradoOF > 0;
  
  end isVolumeGeradoOF;

  procedure atualizaNaoItensNaoCancelados(p_idOrdemSeparacaoCancelamento in number) is
  
  begin
    update ordemseparacaocancelamento osc
       set osc.poderecebercancelamentoitem = 0
     where osc.id = p_idOrdemSeparacaoCancelamento;
  
    update ordemseparacaocancelamentoitem osci
       set osci.status = C_NAO_CANCELADO
     where osci.id in (select idselecionado
                         from gtt_selecao);
  
  end atualizaNaoItensNaoCancelados;

  /*
   * Pesquisa ordem de separacao por idNotaFiscal
  */
  function getOrdemSepPoridNotaFiscal(p_idNotaFiscal in ordemseparacao.idnotafiscal%type)
    return ordemseparacao%rowtype is
  
    cursor c_ordemseparacao(p_idNotaFiscal in number) is
      select *
        from ordemseparacao
       where idnotafiscal = p_idNotaFiscal;
  
    r_ordemseparacao c_ordemseparacao%rowtype;
  
  begin
    if c_ordemseparacao%isopen then
      close c_ordemseparacao;
    end if;
  
    open c_ordemseparacao(p_idNotaFiscal);
    fetch c_ordemseparacao
      into r_ordemseparacao;
  
    if c_ordemseparacao%found then
      close c_ordemseparacao;
      return r_ordemseparacao;
    else
      close c_ordemseparacao;
      return null;
    end if;
  end getOrdemSepPoridNotaFiscal;

  /*
   * Pesquisa items da ordem de separacao
  */
  function getItensOrdemSeparacao(p_idOrdemSeparacao in ordemseparacao.idordemseparacao%type)
    return ordemseparacao%rowtype is
  
    cursor c_ordemseparacao(p_idOrdemSeparacao in number) is
      select *
        from ordemseparacao
       where idnotafiscal = p_idOrdemSeparacao;
  
    r_ordemseparacao c_ordemseparacao%rowtype;
  
  begin
    if c_ordemseparacao%isopen then
      close c_ordemseparacao;
    end if;
  
    open c_ordemseparacao(p_idOrdemSeparacao);
    fetch c_ordemseparacao
      into r_ordemseparacao;
  
    if c_ordemseparacao%found then
      close c_ordemseparacao;
      return r_ordemseparacao;
    else
      close c_ordemseparacao;
      return null;
    end if;
  end getItensOrdemSeparacao;

  function confirmarBarraProdCanceladoOC
  (
    p_idNotaFiscal in number,
    p_barra        in varchar2
  ) return number is
  
    r_ordemseparacao ordemseparacao%rowtype;
  
    v_idProduto     number;
    v_qtdeCancelado number;
  
  begin
    begin
      r_ordemseparacao := getOrdemSepPoridNotaFiscal(p_idNotaFiscal);
    exception
      when others then
        return 0;
    end;
  
    if (r_ordemseparacao.idordemseparacao is null) then
      return 0;
    end if;
  
    --VERIRICAR SE O PRODUTO 'BIPADO' CONSTA NA TABELA DE ITENS é SER CANCELADOS
    begin
      begin
        select osci.idproduto, sum(osci.qtde)
          into v_idProduto, v_qtdeCancelado
          from ordemseparacaocancelamento osc,
               ordemseparacaocancelamentoitem osci, embalagem e
         where osci.status = 0 -- AGUARDANDO
           and osc.id = osci.idordemseparacaocancelamento
           and osc.idordemseparacao = r_ordemseparacao.idordemseparacao
           and e.barra = p_barra
           and osci.idproduto = e.idproduto
         group by osci.idproduto;
      
      exception
        when others then
          v_idProduto     := 0;
          v_qtdeCancelado := 0;
      end;
    
      if (v_idProduto > 0) then
        return v_qtdeCancelado;
      else
        return 0;
      end if;
    
    end;
  
  end confirmarBarraProdCanceladoOC;

  procedure atualizarTabelasColmeia
  (
    p_idNotaFiscal    number,
    p_idProduto       number,
    p_idConfEscaninho number,
    p_idUsuario       number,
    p_idLocal         varchar2
  ) is
    v_qtdeCancelar                 number;
    v_qtdeAuxCancelar              number;
    v_qtdeAuxCancelarAgora         number;
    v_qtdeJaColocouNoEscaninho     number;
    v_idOrdemSeparacao             number;
    v_idOnda                       number;
    v_qtdeItensNotaFiscal          number;
    v_qtdeAtendidaNF               number;
    v_messageControlNumber         number;
    v_barra                        lote.barra%type;
    v_fatorConversao               embalagem.fatorconversao%type;
    v_jaExportadoOfr               number;
    v_utilizaAutorizacaoExpedicao  number;
    v_idArmazem                    number;
    v_qtdeSeparada                 number;
    v_qtdeConferida                number;
    v_qtdePesada                   number;
    v_qtdeTotalSeparar             number;
    v_qtdeTotalConferir            number;
    v_qtdeTotalPesar               number;
    v_separacaoiniciada            number;
    v_idLocalOrigem                lotelocal.idlocal%type;
    v_idLocalDestino               lotelocal.idlocal%type;
    v_idColmeia                    confescaninho.idcolmeia%type;
    v_idEscaninho                  confescaninho.idescaninho%type;
    v_escaninhoAtualizado          boolean := false;
    v_confEscanihnoAtualizada      boolean := false;
    v_msgErro                      varchar2(1000);
    v_idPrenf                      notafiscal.idprenf%type;
    v_idOrdemSeparacaoCancelamento number;
    v_ordemSepCancelEmAndamento    number;
    v_existeConfEscaninhoProd      number;
  
    C_PRESENTE_INDEFINIDO constant number := -1;
    C_SEPARACAO_INICIADA  constant number := 2;
  
    procedure baixarItensNotaFiscal
    (
      p_idNotaFiscal notafiscal.idnotafiscal%type,
      p_idproduto    produto.idproduto%type
    ) is
    begin
      -- BAIXA NOS ITENS DA NOTA FISCAL
      v_qtdeAuxCancelarAgora := 0;
      v_qtdeCancelar         := v_qtdeAuxCancelar;
      for notaDet in (select det.idnfdet, det.nf, det.qtde, det.qtdeatendida,
                             det.qtdefaturada
                        from nfdet det
                       where det.nf = p_idNotaFiscal
                         and det.idproduto = p_idProduto)
      loop
      
        if (notadet.qtde <= v_qtdeCancelar) then
          v_qtdeAuxCancelarAgora := notadet.qtde;
          v_qtdeCancelar         := v_qtdeCancelar - notadet.qtde;
        else
          v_qtdeAuxCancelarAgora := v_qtdeCancelar;
          v_qtdeCancelar         := 0;
        end if;
      
        -- Utilizado vários and para garantir
        update nfdet nd
           set nd.qtde         = nd.qtde - v_qtdeAuxCancelarAgora,
               nd.qtdeatendida = nd.qtdeatendida - v_qtdeAuxCancelarAgora
         where nd.idnfdet = notadet.idnfdet
           and nd.nf = p_idNotaFiscal
           and nd.idproduto = p_idProduto;
      
        exit when v_qtdeCancelar <= 0;
      end loop;
    end;
  
    procedure baixarItensOrdemSeparacao
    (
      p_idOrdemSeparacao ordemseparacao.idordemseparacao%type,
      p_idproduto        produto.idproduto%type
    ) is
    begin
      -- BAIXA NOS ITENS DA ORDEM separação ITEM
      v_qtdeAuxCancelarAgora := 0;
      v_qtdeCancelar         := v_qtdeAuxCancelar;
      for sepDet in (select osi.idordemsepitem, osi.qtdeitem
                       from ordemseparacaoitem osi
                      where osi.idordemsep = p_idOrdemSeparacao
                        and osi.idproduto = p_idProduto)
      loop
      
        if (sepDet.qtdeitem <= v_qtdeCancelar) then
          v_qtdeAuxCancelarAgora := sepDet.qtdeitem;
          v_qtdeCancelar         := v_qtdeCancelar - sepDet.qtdeitem;
        else
          v_qtdeAuxCancelarAgora := v_qtdeCancelar;
          v_qtdeCancelar         := 0;
        end if;
      
        -- Utilizado vários and para garantir
        update ordemseparacaoitem osi
           set osi.qtdeitem = osi.qtdeitem - v_qtdeAuxCancelarAgora
         where osi.idordemsep = p_idOrdemSeparacao
           and osi.idproduto = p_idProduto
           and osi.idordemsepitem = sepDet.Idordemsepitem;
      
        exit when v_qtdeCancelar <= 0;
      end loop;
    end;
  
    procedure finalizarOC is
    begin
      update escaninho e
         set e.status = C_ESCANINHO_NAO_UTILIZADO
       where e.idnotafiscal = p_idNotaFiscal;
    
      v_escaninhoAtualizado := true;
      PK_ONDA_CANCELAR.removerNotaFiscalOnda(v_idOnda, p_idNotaFiscal,
                                             p_idUsuario);
      v_confEscanihnoAtualizada := true;
      cancelaOrdemSeparacao(v_idOrdemSeparacao,
                            'Cancelamento realizado via OC (Order Cancel Request)',
                            p_idUsuario, 0);
      select idprenf
        into v_idPrenf
        from notafiscal
       where idnotafiscal = p_idNotaFiscal;
    
      pk_notafiscal.CancelaNF(v_idPrenf, p_idUsuario,
                              'CANCELADO POR MOTIVO DE OC', 'N', 'N',
                              v_msgErro);
    
    end finalizarOC;
  
    procedure finalizarOcExportarOFR
    (
      p_idNotaFiscal           notafiscal.idnotafiscal%type,
      p_quantidadeCancelar     number,
      p_indicadorExportacaoOFR number
    ) is
    begin
      select count(nfd.idnfdet)
        into v_qtdeItensNotaFiscal
        from nfdet nfd
       where nfd.nf = p_idNotaFiscal
         and nfd.qtdeatendida > 0;
    
      -- NOTA FISCAL COM APENAS 1 PRODUTO OU SEM PRODUTOS
      if (v_qtdeItensNotaFiscal <= 1) then
        begin
          -- SE A QUANTIDADE A CANCELAR é IGUAL A QUANTIDADE TOTAL DA NOTA FISCAL, RETIRAR NOTA FISCAL DA ONDA
          -- E CANCELAR ORDEM DE separação         
          select sum(nfd.qtdeatendida)
            into v_qtdeAtendidaNF
            from nfdet nfd
           where nfd.nf = p_idNotaFiscal;
        
          if ((p_quantidadeCancelar = v_qtdeAtendidaNF) and
             (v_qtdeItensNotaFiscal = 0)) then
          
            finalizarOC;
          
          elsif (v_qtdeItensNotaFiscal = 0) then
          
            finalizarOC;
          
          else
            begin
              -- SE FOR 1, é PQ FOI DEFINIDO NA CONFERENCIA, ONDE já é FEITO A exportação
              -- SE FOR 0, SIGNIFICA QUE é O PRIMEIRO BIP NA COLMEIA, então DEVE-SE EXPORTAR O OFR
              if (p_indicadorExportacaoOFR = 0) then
                select d.utilizaautorizacaoexpedicao
                  into v_utilizaAutorizacaoExpedicao
                  from depositante d, notafiscal nf
                 where nf.idnotafiscal = p_idNotaFiscal
                   and nf.iddepositante = d.identidade;
              
                if (v_utilizaAutorizacaoExpedicao = 0) then
                  pk_integracao.executarExpOutBound(p_idNotaFiscal,
                                                    C_PRESENTE_INDEFINIDO);
                else
                  pk_integracao.executarExpOutBound(p_idNotaFiscal,
                                                    C_SEPARACAO_INICIADA);
                end if;
              end if;
            end;
          end if;
        end;
      end if;
    end;
  
    procedure baixarSaidaPorNf
    (
      p_idOnda       romaneiopai.idromaneio%type,
      p_idNotaFiscal notafiscal.idnotafiscal%type,
      p_idproduto    produto.idproduto%type
    ) is
    begin
      begin
        select case
                  when (snf.qtdeseparada - v_qtdeAuxCancelar) < 0 then
                   snf.qtdeseparada
                  else
                   snf.qtdeseparada - v_qtdeAuxCancelar
                end qtdeSeparada,
               case
                  when (snf.qtdeconferida - v_qtdeAuxCancelar) < 0 then
                   snf.qtdeconferida
                  else
                   snf.qtdeconferida - v_qtdeAuxCancelar
                end qtdeConferida,
               case
                  when (snf.qtdepesada - v_qtdeAuxCancelar) < 0 then
                   snf.qtdepesada
                  else
                   snf.qtdepesada - v_qtdeAuxCancelar
                end qtdePesada,
               case
                  when (snf.totalseparar - v_qtdeAuxCancelar) < 0 then
                   snf.totalseparar
                  else
                   snf.totalseparar - v_qtdeAuxCancelar
                end qtdeTotalSeparada,
               case
                  when (snf.totalconferir - v_qtdeAuxCancelar) < 0 then
                   snf.totalconferir
                  else
                   snf.totalconferir - v_qtdeAuxCancelar
                end qtdeTotalConferida,
               case
                  when (snf.totalpesar - v_qtdeAuxCancelar) < 0 then
                   snf.totalpesar
                  else
                   snf.totalpesar - v_qtdeAuxCancelar
                end qtdeTotalPesada,
               case
                  when (snf.separacaoiniciada - v_qtdeAuxCancelar) < 0 then
                   snf.separacaoiniciada
                  else
                   snf.separacaoiniciada - v_qtdeAuxCancelar
                end separacaoiniciada
        
          into v_qtdeSeparada, v_qtdeConferida, v_qtdePesada,
               v_qtdeTotalSeparar, v_qtdeTotalConferir, v_qtdeTotalPesar,
               v_separacaoiniciada
          from saidapornf snf
         where snf.idonda = p_idOnda
           and snf.idnotafiscal = p_idNotaFiscal;
      
      end;
    
      select count(1)
        into v_existeConfEscaninhoProd
        from confescaninho c
       where c.idnotafiscal = p_idNotaFiscal
         and c.idproduto = p_idProduto
         and c.status = C_CONFESCAN_CONCLUIDO;
    
      if (v_existeConfEscaninhoProd > 0) then
      
        update saidapornf snf
           set snf.totalseparar      = v_qtdeTotalSeparar,
               snf.totalconferir     = v_qtdeTotalConferir,
               snf.totalpesar        = v_qtdeTotalPesar,
               snf.qtdeseparada      = v_qtdeSeparada,
               snf.qtdeconferida     = v_qtdeConferida,
               snf.qtdepesada        = v_qtdePesada,
               snf.separacaoiniciada = v_separacaoiniciada
         where snf.idonda = p_idOnda
           and snf.idnotafiscal = p_idNotaFiscal;
      
      else
      
        update saidapornf snf
           set snf.totalseparar      = v_qtdeTotalSeparar,
               snf.totalconferir     = v_qtdeTotalConferir,
               snf.totalpesar        = v_qtdeTotalPesar,
               snf.separacaoiniciada = v_separacaoiniciada
         where snf.idonda = p_idOnda
           and snf.idnotafiscal = p_idNotaFiscal;
      end if;
    
      update saidapornf snf
         set snf.idusuarioseparacao = p_idUsuario,
             snf.dataseparacao      = sysdate
       where snf.idonda = v_idOnda
         and snf.idnotafiscal = p_idNotaFiscal
         and snf.totalseparar = snf.qtdeseparada
         and (snf.idusuarioconferencia is null or snf.dataseparacao is null);
    end;
  
    procedure baixarMovimentacoes
    (
      p_idNotaFiscal notafiscal.idnotafiscal%type,
      p_idproduto    produto.idproduto%type
    ) is
    begin
      -- QUANDO AINDA não FOI COLOCADO NENHUM PRODUTO NO ESCANINHO
      begin
        select sum(m.qtdeemvolume) qtdeJaColocouNoEscaninho
          into v_qtdeJaColocouNoEscaninho
          from movimentacao m
         where m.Idnotafiscal = p_idNotaFiscal
           and m.status <> 3
           and m.idlote = (select l.idlote
                             from lote l
                            where l.idproduto = p_idProduto
                              and l.idlote = m.idlote);
      exception
        when others then
          v_qtdeJaColocouNoEscaninho := 0;
      end;
    
      -- atualização NAS movimentações
      if (v_qtdeJaColocouNoEscaninho = 0) then
        v_qtdeAuxCancelarAgora := 0;
        for c_movimentacao in (select *
                                 from movimentacao m
                                where m.Idnotafiscal = p_idNotaFiscal
                                  and m.status <> 3
                                  and m.idlote =
                                      (select l.idlote
                                         from lote l
                                        where l.idproduto = p_idProduto
                                          and l.idlote = m.idlote))
        loop
          -- SE não TENHO MAIS NADA PRA CANCELAR
          if (v_qtdeCancelar <= 0) then
            exit; -- SAI DO LOOP
          end if;
        
          pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
        
          -- ALTERAR REGISTRO DE MOVIMENTACAO PARA REMOVER O ESTOQUE DO LOCAL
          update movimentacao m
             set m.status = C_STATUS_MOV_EM_ANDAMENTO
           where m.id = c_movimentacao.id;
        
          select loc.idlocal
            into v_idLocalOrigem
            from local loc
           where loc.id = c_movimentacao.idlocalorigem;
        
          v_qtdeAuxCancelarAgora := v_qtdeCancelar;
          if (v_qtdeAuxCancelarAgora > c_movimentacao.qtdemovimentada) then
            v_qtdeAuxCancelarAgora := c_movimentacao.qtdemovimentada;
            --Não necessita subtratir a v_qtdeAuxCancelarAgora, pois é atribuida a ela a v_qtdeCancelar que é tradada no fim do loop
          end if;
        
          -- RETIRAR PENDENCIA DO LOCAL (Não tirar daqui pois ele olha o status da movimentação).
          pk_estoque.retirar_pendencia(v_idArmazem, v_idLocalOrigem,
                                       c_movimentacao.idlote,
                                       v_qtdeAuxCancelarAgora, p_idUsuario,
                                       'pendêNCIA RETIRADA EM função DE CANCELAMENTO DE ITEM VIA OC',
                                       c_movimentacao.id);
        
          -- CANCELAR REGISTRO DE MOVIMENTACAO
          update movimentacao m
             set m.status = C_STATUS_MOV_CANCELADA
           where m.id = c_movimentacao.id;
        
          if (v_qtdeAuxCancelarAgora < c_movimentacao.qtdemovimentada) then
          
            -- ADICIONAR REGISTRO DE movimentação COM QTDE RESTANTE      
            insert into movimentacao
              (id, idlocalorigem, idlocaldestino, quantidade, etapa, idlote,
               status, idonda, qtdemovimentada, idvolumeromaneio,
               idnotafiscal, datainicio, datatermino, idusuario,
               qtdeconferida, idcomposicao, qtdeemvolume, ordem,
               identificador, motivocancelamento, tiposeparacao,
               fluxousavolume, datapausa, tempopausa, idordemestoque,
               idnfdet, disponivelestoqueorigem)
            values
              (seq_movimentacao.nextval, c_movimentacao.idlocalorigem,
               c_movimentacao.idlocaldestino,
               
               /*SUBTRAI qtdeAoFormarONDA*/
               c_movimentacao.quantidade - v_qtdeAuxCancelarAgora,
               
               c_movimentacao.etapa, c_movimentacao.idlote,
               c_movimentacao.status, c_movimentacao.idonda,
               
               /*SUBTRAI qtdeASerMovimentada*/
               c_movimentacao.qtdemovimentada - v_qtdeAuxCancelarAgora,
               
               c_movimentacao.idvolumeromaneio, c_movimentacao.idnotafiscal,
               c_movimentacao.datainicio, c_movimentacao.datatermino,
               c_movimentacao.idusuario,
               
               /*SUBTRAI qtdeSeparadaQdoEscaninho*/
               c_movimentacao.qtdeconferida - v_qtdeAuxCancelarAgora,
               
               c_movimentacao.idcomposicao, c_movimentacao.qtdeemvolume,
               c_movimentacao.ordem, c_movimentacao.identificador,
               c_movimentacao.motivocancelamento,
               c_movimentacao.tiposeparacao, c_movimentacao.fluxousavolume,
               c_movimentacao.datapausa, c_movimentacao.tempopausa,
               c_movimentacao.idordemestoque, c_movimentacao.idnfdet,
               c_movimentacao.disponivelestoqueorigem);
          
          end if;
        
          pk_estoque.retirar_estoque(v_idArmazem, v_idLocalOrigem,
                                     c_movimentacao.idlote,
                                     v_qtdeAuxCancelarAgora, p_idUsuario,
                                     'ESTOQUE RETIRADO DE CANCELAMENTO DE OC',
                                     'N');
        
          -- INCLUIR ESTOQUE DO PRODUTO NO LOCAL ESCOLHIDO NO MOMENTO DO CANCELAMENTO
          pk_estoque.incluir_estoque(v_idArmazem, p_idLocal,
                                     c_movimentacao.idlote,
                                     v_qtdeAuxCancelarAgora, p_idUsuario,
                                     'ESTOQUE incluído EM função DE CANCELAMENTO DE OC',
                                     'N');
        
          pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
        
          --ATUALIZA A QUANTIDADE A CANCELAR
          v_qtdeCancelar := v_qtdeCancelar - v_qtdeAuxCancelarAgora;
        
        end loop;
      
      else
        -- QUANDO já COLOCOU AO MENOS UM PRODUTO NO ESCANINHO
        for c_movimentacao in (select *
                                 from movimentacao m
                                where m.Idnotafiscal = p_idNotaFiscal
                                  and m.status <> C_STATUS_MOV_CANCELADA
                                  and m.idlote =
                                      (select l.idlote
                                         from lote l
                                        where l.idproduto = p_idProduto
                                          and l.idlote = m.idlote))
        loop
          -- SE não TENHO MAIS NADA PRA CANCELAR
          if (v_qtdeCancelar <= 0) then
            exit; -- SAI DO LOOP
          end if;
        
          pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
        
          -- CANCELAR REGISTRO DE MOVIMENTACAO
          update movimentacao m
             set m.status = C_STATUS_MOV_CANCELADA
           where m.id = c_movimentacao.id;
        
          select loc.idlocal
            into v_idLocalDestino
            from local loc
           where loc.id = c_movimentacao.idlocaldestino;
        
          if (v_qtdeCancelar < c_movimentacao.qtdemovimentada) then
          
            -- ADICIONAR REGISTRO DE movimentação COM QTDE RESTANTE      
            insert into movimentacao
              (id, idlocalorigem, idlocaldestino, quantidade, etapa, idlote,
               status, idonda, qtdemovimentada, idvolumeromaneio,
               idnotafiscal, datainicio, datatermino, idusuario,
               qtdeconferida, idcomposicao, qtdeemvolume, ordem,
               identificador, motivocancelamento, tiposeparacao,
               fluxousavolume, datapausa, tempopausa, idordemestoque,
               idnfdet, disponivelestoqueorigem)
            values
              (seq_movimentacao.nextval, c_movimentacao.idlocalorigem,
               c_movimentacao.idlocaldestino,
               
               c_movimentacao.quantidade - v_qtdeCancelar,
               
               c_movimentacao.etapa, c_movimentacao.idlote,
               c_movimentacao.status, c_movimentacao.idonda,
               
               c_movimentacao.qtdemovimentada - v_qtdeCancelar,
               
               c_movimentacao.idvolumeromaneio, c_movimentacao.idnotafiscal,
               c_movimentacao.datainicio, c_movimentacao.datatermino,
               c_movimentacao.idusuario,
               
               c_movimentacao.qtdeconferida - v_qtdeCancelar,
               
               c_movimentacao.idcomposicao,
               
               c_movimentacao.qtdeemvolume,
               
               c_movimentacao.ordem, c_movimentacao.identificador,
               c_movimentacao.motivocancelamento,
               c_movimentacao.tiposeparacao, c_movimentacao.fluxousavolume,
               c_movimentacao.datapausa, c_movimentacao.tempopausa,
               c_movimentacao.idordemestoque, c_movimentacao.idnfdet,
               c_movimentacao.disponivelestoqueorigem);
          
            -- INCLUIR ESTOQUE DO PRODUTO NO LOCAL ESCOLHIDO NO MOMENTO DO CANCELAMENTO
            pk_estoque.incluir_estoque(v_idArmazem, p_idLocal,
                                       c_movimentacao.idlote, v_qtdeCancelar,
                                       p_idUsuario,
                                       'ESTOQUE incluído EM função DE CANCELAMENTO DE OC',
                                       'N');
          
            -- RETIRAR PENDENCIA DO LOCAL ATUAL
            pk_estoque.retirar_pendencia(v_idArmazem, v_idLocalDestino,
                                         c_movimentacao.idlote,
                                         v_qtdeCancelar, p_idUsuario,
                                         'pendêNCIA RETIRADA EM função DE CANCELAMENTO DE OC');
          
            -- RETIRAR ESTOQUE DO LOCAL ATUAL
            pk_estoque.retirar_estoque(v_idArmazem, v_idLocalDestino,
                                       c_movimentacao.idlote, v_qtdeCancelar,
                                       p_idUsuario,
                                       'ESTOQUE RETIRADO EM função DE CANCELAMENTO DE OC');
          
          end if;
        
          pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
        
          --ATUALIZAR paletseparacaonf
          begin
            select lt.barra, e.fatorconversao
              into v_barra, v_fatorConversao
              from lote lt, embalagem e
             where lt.idlote = c_movimentacao.idlote
               and lt.barra = e.barra;
          end;
        
          update paletseparacaonf psnf
             set psnf.qtde        = psnf.qtde - v_qtdeCancelar,
                 psnf.qtdeunidade =
                 (psnf.qtde * v_fatorConversao) - v_qtdeCancelar
           where 1 = 1
             and psnf.idromaneio = v_idOnda
             and psnf.idnotafiscal = p_idNotaFiscal
             and psnf.idlote = c_movimentacao.idlote
             and psnf.barra = v_barra;
        
          --ATUALIZA A QUANTIDADE A CANCELAR
          v_qtdeCancelar := v_qtdeCancelar - c_movimentacao.qtdemovimentada;
        
        end loop;
      end if;
    end;
  
    procedure apagarLuzEscaninho(p_idcolmeia in number) is
      COM_PRODUTO         constant number := 2;
      COLOCANDO_PRODUTO   constant number := 3;
      SEPARACAO_CONCLUIDA constant number := 4;
      MONTANDO_VOLUME     constant number := 5;
    begin
      -- caso o produto informado seja invalido é necessário
      -- apagar o escaninho que esta piscando para evitar
      -- que o conferente coloque o produto no escaninho errado
      update escaninho e
         set e.status = MONTANDO_VOLUME
       where e.idcolmeia = p_idcolmeia
         and e.status = SEPARACAO_CONCLUIDA;
    
      update escaninho e
         set e.status = COM_PRODUTO
       where e.idcolmeia = p_idcolmeia
         and e.status = COLOCANDO_PRODUTO;
    
    end apagarLuzEscaninho;
  
    procedure controlarStatusEscaninhos
    (
      p_idColmeia    in number,
      p_idEscaninho  in number,
      p_idNotaFiscal in number
    ) is
      AGUARDANDO_CONF_PEDIDO constant number := 8;
      ENVIANDO_MONT_VOL      constant number := 5;
    
      v_MovPendentes number;
    begin
      apagarLuzEscaninho(p_idColmeia);
    
      select count(*)
        into v_MovPendentes
        from Movimentacao m
       where m.status in (0, 1, 2)
         and m.quantidade - m.qtdeEmVolume > 0
         and m.idLocalDestino = p_idEscaninho;
    
      if (v_MovPendentes = 0) then
        update escaninho
           set status = ENVIANDO_MONT_VOL
         where idendereco = p_idEscaninho;
      
        update escaninho
           set status = ENVIANDO_MONT_VOL
         where idnotafiscal = p_idNotaFiscal
           and status = AGUARDANDO_CONF_PEDIDO;
      end if;
    
    end controlarStatusEscaninhos;
  
  begin
  
    begin
      select osci.qtde, osci.qtde, osc.messagecontrolnumber,
             os.idordemseparacao, nfr.idromaneio, nf.idarmazem, osc.id
        into v_qtdeCancelar, v_qtdeAuxCancelar, v_messageControlNumber,
             v_idOrdemSeparacao, v_idOnda, v_idArmazem,
             v_idOrdemSeparacaoCancelamento
        from ordemseparacaocancelamentoitem osci,
             ordemseparacaocancelamento osc, ordemseparacao os,
             nfromaneio nfr, notafiscal nf
       where osci.idordemseparacaocancelamento = osc.id
         and osc.idordemseparacao = os.idordemseparacao
         and os.idnotafiscal = p_idNotaFiscal
         and osci.idproduto = p_idProduto
         and osci.status = 0
         and os.idnotafiscal = nfr.idnotafiscal
         and nfr.idnotafiscal = nf.idnotafiscal
         and rownum = 1;
    exception
      when others then
        v_qtdeCancelar         := 0;
        v_qtdeAuxCancelar      := 0;
        v_messageControlNumber := 0;
        v_idOrdemSeparacao     := 0;
        v_idOnda               := 0;
    end;
  
    baixarMovimentacoes(p_idNotaFiscal, p_idProduto);
  
    pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
    pk_triggers_control.disableTrigger('T_ALTERASAIDAPORNF');
    pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
  
    baixarItensNotaFiscal(p_idNotaFiscal, p_idProduto);
    baixarItensOrdemSeparacao(v_idOrdemSeparacao, p_idProduto);
  
    -- ARMAZENA VARIAVEL PARA EXPORTAR POSTERIORMENTE
    select count(1)
      into v_jaExportadoOfr
      from saidapornf snf
     where snf.idonda = v_idOnda
       and snf.idnotafiscal = p_idNotaFiscal
       and snf.separado = 1;
  
    baixarSaidaPorNf(v_idOnda, p_idNotaFiscal, p_idProduto);
  
    pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
    pk_triggers_control.enableTrigger('T_ALTERASAIDAPORNF');
    pk_triggers_control.enableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
  
    -- CONCLUIR CANCELAMENTO DO ITEM
    begin
      update ordemseparacaocancelamentoitem osci
         set osci.status = 1 -- SUCESSO
       where osci.status = 0 -- AGUARDANDO
         and osci.idproduto = p_idProduto
         and osci.idordemseparacaocancelamento =
             (select osc.id
                from ordemseparacaocancelamento osc, ordemseparacao os
               where osc.idordemseparacao = os.idordemseparacao
                 and osc.messagecontrolnumber = v_messageControlNumber
                 and os.idnotafiscal = p_idNotaFiscal);
    end;
  
    finalizarOcExportarOFR(p_idNotaFiscal, v_qtdeAuxCancelar,
                           v_jaExportadoOfr);
  
    if not (v_escaninhoAtualizado) then
    
      select c.idcolmeia, c.idescaninho
        into v_idColmeia, v_idEscaninho
        from confescaninho c
       where c.idconfescaninho = p_idConfEscaninho;
    
      controlarStatusEscaninhos(v_idColmeia, v_idEscaninho, p_idNotaFiscal);
    
    end if;
  
    --ATUALIZAR STATUS DA CONFERENCIA
    if not (v_confEscanihnoAtualizada) then
      update confescaninho ce
         set ce.status = 12
       where ce.idconfescaninho = p_idConfEscaninho;
    end if;
  
    -- CONTROLAR SE A OC FOI TOTALMENTE CONCLUIDA PARA EXPORTAR O OCR
    select count(1)
      into v_ordemSepCancelEmAndamento
      from ordemseparacaocancelamentoitem osci
     where osci.idordemseparacaocancelamento =
           v_idOrdemSeparacaoCancelamento
       and osci.status = 0;
  
    if (v_ordemSepCancelEmAndamento = 0) then
      atualizarOrdemSepCancelamento(v_idOrdemSeparacao,
                                    v_idOrdemSeparacaoCancelamento, C_NAO,
                                    C_STATUS_CANCELADO_COM_SUCESSO, C_SIM,
                                    null, v_messageControlNumber);
    
      pk_integracao.exportarOCR(v_idOrdemSeparacao, v_messageControlNumber);
    
    end if;
  
  end atualizarTabelasColmeia;

  function confirmarLocalProdCanceladoOC
  (
    p_idConfEscaninho in number,
    p_idNotaFiscal    in number,
    p_idProduto       in number,
    p_idLocal         in varchar2,
    p_idUsuario       in number
  ) return number is
  
    v_produtoVinculado number;
  
    v_msg t_message;
  
  begin
  
    --VERIRICAR VINCULO DO PRODUTO NO LOCAL
    begin
    
      begin
        select count(1)
          into v_produtoVinculado
          from local
         where idlocal = p_idLocal;
      exception
        when others then
          v_produtoVinculado := 0;
      end;
    
      if (v_produtoVinculado = 0) then
        v_msg := t_message('O local indicado id {0} não existe.');
        v_msg.addParam(p_idLocal);
        v_msg.addParam(p_idProduto);
        raise_application_error(-20002, v_msg.formatMessage);
      end if;
    
      --EFETUAR alterações NAS TABELAS RELACIONADAS A colméia
      atualizarTabelasColmeia(p_idNotaFiscal, p_idProduto,
                              p_idConfEscaninho, p_idUsuario, p_idLocal);
    
      return 1;
    
    end;
  
  end confirmarLocalProdCanceladoOC;

  procedure baixarQtdItemMontVolColmeia
  (
    p_idConfMontVolComeia in number,
    p_idNotaFiscal        in number,
    p_idProduto           in number,
    p_idOnda              in number,
    p_qtdeRemover         in number
  ) is
    v_idEscaninho     number;
    v_codBarraProduto varchar2(60);
    v_qtdeEmVolume    number;
    v_qtdeRemover     number;
    v_qtdeRemovida    number;
  
  begin
    v_qtdeRemovida := 0;
    v_qtdeRemover  := p_qtdeRemover;
  
    select cmvc.idescaninho, cmvc.barra
      into v_idEscaninho, v_codBarraProduto
      from confmontvolcolmeia cmvc
     where cmvc.id = p_idConfMontVolComeia
       and cmvc.idnotafiscal = p_idNotaFiscal
       and cmvc.idproduto = p_idProduto
       and cmvc.idromaneio = p_idOnda;
  
    while v_qtdeRemover > 0
    
    loop
    
      select ce.qtdeemvolume
        into v_qtdeEmVolume
        from confescaninho ce
       where ce.idescaninho = v_idEscaninho
         and ce.status = C_CONFESCAN_CONCLUIDO
         and ce.codbarra = v_codBarraProduto
         and ce.qtdeemvolume <= v_qtdeRemover
         and rownum = 1
       order by ce.qtdeemvolume asc;
    
      v_qtdeRemover  := v_qtdeRemover - v_qtdeEmVolume;
      v_qtdeRemovida := v_qtdeRemovida + v_qtdeEmVolume;
    
      dbms_output.put_line('Removido ' || v_qtdeRemovida || ' de ' ||
                           p_qtdeRemover);
    
    end loop;
  
  end baixarQtdItemMontVolColmeia;

  procedure confirmarCancelamentoProduto
  (
    p_idConfMontVolColmeia  in number,
    p_idEscaninho           in number,
    p_idNotaFiscal          in number,
    p_idProduto             in number,
    p_qtdeTotalCancelarProd in number,
    p_idLocalRetorno        in local.idlocal%type,
    p_idUsuario             in number
  ) is
  
    v_qtdCancelarConfEscaninho     number;
    v_qtdeCancelLinhaMovAtual      number;
    v_diferenca                    number;
    v_idArmazem                    number;
    v_idOrdemSeparacao             number;
    v_messageControlNumber         number;
    v_idOrdemSeparacaoCancelamento number;
    v_qtdeFaltaCancelar            number;
    v_qtdeJaCancelada              number;
    v_ordemSepCancelEmAndamento    number;
    v_qtdeConferidaAux             number;
    v_idProduto                    number;
    v_idOnda                       number;
    v_msg                          t_message;
  
    procedure validarLocalRetorno is
      r_localretorno local%rowtype;
    begin
      begin
        select nf.idarmazem, cmvc.idproduto
          into v_idArmazem, v_idProduto
          from confmontvolcolmeia cmvc, notafiscal nf
         where cmvc.id = p_idConfMontVolColmeia
           and cmvc.idnotafiscal = nf.idnotafiscal;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, conferência não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      begin
        select lr.*
          into r_localretorno
          from local lr
         where lr.idarmazem = v_idArmazem
           and lr.idlocal = p_idLocalRetorno;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, local de retorno {0} não encontrado.');
          v_msg.addParam(p_idLocalRetorno);
          raise_application_error(-20002, v_msg.formatMessage);
      end;
    
    end validarLocalRetorno;
  
    procedure baixarConteudoEscaninho
    (
      p_idMovimentacao in number,
      p_qtdeLinhaMov   in number
    ) is
    
      v_qtdCancelarConteudoEscaninho number;
    
    begin
    
      if (p_qtdeLinhaMov > p_qtdeTotalCancelarProd) then
        v_qtdCancelarConteudoEscaninho := p_qtdeTotalCancelarProd;
      elsif (p_qtdeLinhaMov <= p_qtdeTotalCancelarProd) then
        v_qtdCancelarConteudoEscaninho := p_qtdeLinhaMov;
      end if;
    
      for c_contEscaninho in (select *
                                from CONTEUDOESCANINHO c
                               where c.idescaninho = p_idEscaninho
                                 and c.idmovimentacao = p_idMovimentacao
                                 and c.quantidade <=
                                     v_qtdCancelarConteudoEscaninho)
      loop
      
        if (c_contEscaninho.Quantidade <= v_qtdCancelarConteudoEscaninho) then
          delete from CONTEUDOESCANINHO c
           where c.id = c_contEscaninho.Id;
        
          v_qtdCancelarConteudoEscaninho := v_qtdCancelarConteudoEscaninho -
                                            c_contEscaninho.Quantidade;
        elsif (c_contEscaninho.Quantidade > v_qtdCancelarConteudoEscaninho) then
          update CONTEUDOESCANINHO c
             set c.quantidade = c.quantidade -
                                v_qtdCancelarConteudoEscaninho
           where c.id = c_contEscaninho.Id;
        
          v_qtdCancelarConteudoEscaninho := 0;
        end if;
      
        exit when v_qtdCancelarConteudoEscaninho = 0;
      end loop;
    
    end baixarConteudoEscaninho;
  
    procedure baixarConfEscaninho(p_qtdeLinhaMov in number) is
    
    begin
    
      if (p_qtdeLinhaMov > p_qtdeTotalCancelarProd) then
        v_qtdCancelarConfEscaninho := p_qtdeTotalCancelarProd;
      elsif (p_qtdeLinhaMov <= p_qtdeTotalCancelarProd) then
        v_qtdCancelarConfEscaninho := p_qtdeLinhaMov;
      end if;
    
      for c_confEscaninho in (select *
                                from CONFESCANINHO cf
                               where cf.idescaninho = p_idEscaninho
                                 and cf.idnotafiscal = p_idNotaFiscal
                                 and cf.idproduto = p_idProduto
                                 and cf.status in (0, 2)
                                 and cf.qtdeemvolume <=
                                     v_qtdCancelarConfEscaninho)
      loop
      
        if (c_confEscaninho.Qtdeemvolume <= v_qtdCancelarConfEscaninho) then
          delete from CONFESCANINHO cf
           where cf.idconfescaninho = c_confEscaninho.Idconfescaninho;
        
          v_qtdCancelarConfEscaninho := v_qtdCancelarConfEscaninho -
                                        c_confEscaninho.Qtdeemvolume;
        elsif (c_confEscaninho.Qtdeemvolume > v_qtdCancelarConfEscaninho) then
          update CONFESCANINHO cf
             set cf.qtdeemvolume = cf.qtdeemvolume -
                                   v_qtdCancelarConfEscaninho
           where cf.idconfescaninho = c_confEscaninho.Idconfescaninho;
        
          v_qtdCancelarConfEscaninho := 0;
        end if;
      
        exit when v_qtdCancelarConfEscaninho = 0;
      end loop;
    
    end baixarConfEscaninho;
  
    procedure baixarMovimentacao
    (
      p_movimentacao      in movimentacao%rowtype,
      p_qtdeFaltaCancelar in out number,
      p_qtdeJaCancelada   in out number
    ) is
      v_idLocal local.idlocal%type;
    begin
      p_qtdeFaltaCancelar := p_qtdeTotalCancelarProd;
      p_qtdeJaCancelada   := 0;
      v_diferenca         := 0;
    
      select loc.idlocal
        into v_idLocal
        from local loc
       where loc.id = p_movimentacao.idlocaldestino;
    
      if (p_movimentacao.qtdeconferida > p_qtdeFaltaCancelar) then
      
        v_qtdeCancelLinhaMovAtual := p_qtdeTotalCancelarProd;
        p_qtdeJaCancelada         := p_qtdeTotalCancelarProd;
        p_qtdeFaltaCancelar       := 0;
      
        pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
        update movimentacao m
           set m.status = C_STATUS_MOV_EM_ANDAMENTO
         where m.id = p_movimentacao.id;
        pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
      
        begin
          pk_estoque.retirar_pendencia(v_idArmazem, v_idLocal,
                                       p_movimentacao.idlote,
                                       v_qtdeCancelLinhaMovAtual,
                                       p_idUsuario,
                                       'pendêNCIA RETIRADA EM função DE CANCELAMENTO DE ITEM VIA OC',
                                       p_movimentacao.id);
        exception
          when others then
            --IGNORAR CASO não HAJA NADA PARA RETIRAR pendêNCIA
            C_STATUS_MOV_CANCELADA := C_STATUS_MOV_CANCELADA;
        end;
      
        update movimentacao m
           set m.status = C_STATUS_MOV_CANCELADA
         where m.id = p_movimentacao.id;
      
        v_diferenca := p_movimentacao.qtdeconferida -
                       v_qtdeCancelLinhaMovAtual;
      
        insert into movimentacao
          (id, idlocalorigem, idlocaldestino, quantidade, etapa, idlote,
           status, idonda, qtdemovimentada, idvolumeromaneio, idnotafiscal,
           datainicio, datatermino, idusuario, qtdeconferida, idcomposicao,
           qtdeemvolume, ordem, identificador, motivocancelamento,
           tiposeparacao, fluxousavolume, datapausa, tempopausa,
           idordemestoque, idnfdet, disponivelestoqueorigem)
        values
          (seq_movimentacao.nextval, p_movimentacao.idlocalorigem,
           p_movimentacao.idlocaldestino, v_diferenca, p_movimentacao.etapa,
           p_movimentacao.idlote, C_STATUS_MOV_CONCLUIDA,
           p_movimentacao.idonda, v_diferenca,
           p_movimentacao.idvolumeromaneio, p_movimentacao.idnotafiscal,
           p_movimentacao.datainicio, p_movimentacao.datatermino,
           p_movimentacao.idusuario, v_diferenca,
           p_movimentacao.idcomposicao,
           p_movimentacao.qtdeemvolume - v_qtdeCancelLinhaMovAtual,
           p_movimentacao.ordem, p_movimentacao.identificador,
           p_movimentacao.motivocancelamento, p_movimentacao.tiposeparacao,
           p_movimentacao.fluxousavolume, p_movimentacao.datapausa,
           p_movimentacao.tempopausa, p_movimentacao.idordemestoque,
           p_movimentacao.idnfdet, p_movimentacao.disponivelestoqueorigem);
      
        pk_estoque.incluir_estoque(v_idArmazem, p_idLocalRetorno,
                                   p_movimentacao.idlote,
                                   v_qtdeCancelLinhaMovAtual, p_idUsuario,
                                   'ESTOQUE incluído EM função DE CANCELAMENTO DE OC',
                                   'N');
      elsif (p_movimentacao.qtdeconferida <= p_qtdeFaltaCancelar) then
      
        v_qtdeCancelLinhaMovAtual := p_movimentacao.qtdeconferida;
        p_qtdeFaltaCancelar       := p_qtdeFaltaCancelar -
                                     v_qtdeCancelLinhaMovAtual;
        p_qtdeJaCancelada         := v_qtdeCancelLinhaMovAtual;
      
        pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
        update movimentacao m
           set m.status = C_STATUS_MOV_EM_ANDAMENTO
         where m.id = p_movimentacao.id;
        pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
      
        pk_estoque.retirar_pendencia(v_idArmazem, v_idLocal,
                                     p_movimentacao.idlote,
                                     v_qtdeCancelLinhaMovAtual, p_idUsuario,
                                     'pendêNCIA RETIRADA EM função DE CANCELAMENTO DE ITEM VIA OC',
                                     p_movimentacao.id);
      
        update movimentacao m
           set m.status = C_STATUS_MOV_CANCELADA
         where m.id = p_movimentacao.id;
      
        pk_estoque.incluir_estoque(v_idArmazem, p_idLocalRetorno,
                                   p_movimentacao.idlote,
                                   v_qtdeCancelLinhaMovAtual, p_idUsuario,
                                   'ESTOQUE incluído EM função DE CANCELAMENTO DE OC',
                                   'N');
      end if;
    
    end baixarMovimentacao;
  
    procedure baixarItensNotaFiscal
    (
      p_idNotaFiscal   in number,
      p_idProduto      in number,
      p_qtdeCancelarNf in number
    ) is
    
      v_qtdeCancelarAgora    number;
      v_qtdeRestanteCancelar number;
    begin
    
      --BAIXA NAS TABELAS DE NOTA FISCAL
      pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
      pk_triggers_control.disableTrigger('T_ALTERASAIDAPORNF');
      pk_triggers_control.disableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    
      v_qtdeRestanteCancelar := p_qtdeCancelarNf;
      for c_itemNf in (select *
                         from nfdet nd
                        where nd.nf = p_idNotaFiscal
                          and nd.idproduto = p_idProduto)
      
      loop
      
        if (c_itemNf.Qtde > v_qtdeRestanteCancelar) then
          v_qtdeCancelarAgora    := v_qtdeRestanteCancelar;
          v_qtdeRestanteCancelar := 0;
        elsif (c_itemNf.Qtde <= v_qtdeRestanteCancelar) then
          v_qtdeCancelarAgora    := c_itemNf.Qtde;
          v_qtdeRestanteCancelar := v_qtdeRestanteCancelar - c_itemNf.Qtde;
        end if;
      
        update nfdet nd
           set nd.qtde         = nd.qtde - v_qtdeCancelarAgora,
               nd.qtdeatendida = nd.qtdeatendida - v_qtdeCancelarAgora
         where nd.idnfdet = c_itemNf.Idnfdet;
      
        exit when v_qtdeRestanteCancelar <= 0;
      
      end loop;
    
      pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
      pk_triggers_control.enableTrigger('T_ALTERASAIDAPORNF');
      pk_triggers_control.enableTrigger('T_QTDEATENDIDA_NFDET_STATUSNF');
    
    end baixarItensNotaFiscal;
  
    procedure baixarItensOrdemSeparacao
    (
      p_idOrdemSeparacao     in number,
      p_idProduto            in number,
      p_qtdeCancelarOrdemSep in number
    ) is
    
      v_qtdeCancelarOrdemSep number;
      v_qtdeCancelarAgora    number;
    
    begin
    
      v_qtdeCancelarOrdemSep := p_qtdeCancelarOrdemSep;
    
      for c_itemOrdemSep in (select *
                               from ordemseparacaoitem osi
                              where osi.idordemsep = p_idOrdemSeparacao
                                and osi.idproduto = p_idProduto)
      
      loop
      
        if (c_itemOrdemSep.Qtdeitem > v_qtdeCancelarOrdemSep) then
          v_qtdeCancelarAgora    := v_qtdeCancelarOrdemSep;
          v_qtdeCancelarOrdemSep := 0;
        
        elsif (c_itemOrdemSep.Qtdeitem <= v_qtdeCancelarOrdemSep) then
        
          v_qtdeCancelarAgora    := c_itemOrdemSep.Qtdeitem;
          v_qtdeCancelarOrdemSep := v_qtdeCancelarOrdemSep -
                                    c_itemOrdemSep.Qtdeitem;
        
        end if;
      
        update ordemseparacaoitem osi
           set osi.qtdeitem = osi.qtdeitem - v_qtdeCancelarAgora
         where osi.idordemsepitem = c_itemOrdemSep.Idordemsepitem;
      
        exit when v_qtdeCancelarOrdemSep = 0;
      
      end loop;
    
    end baixarItensOrdemSeparacao;
  
  begin
  
    validarLocalRetorno;
  
    select nf.idarmazem, os.idordemseparacao, osc.id,
           osc.messagecontrolnumber
      into v_idArmazem, v_idOrdemSeparacao, v_idOrdemSeparacaoCancelamento,
           v_messageControlNumber
      from notafiscal nf, ordemseparacao os, ordemseparacaocancelamento osc
     where nf.idnotafiscal = p_idNotaFiscal
       and nf.idnotafiscal = os.idnotafiscal
       and os.idordemseparacao = osc.idordemseparacao
       and osc.poderecebercancelamentoitem = 1;
  
    delete from conteudomontagemescaninho cme
     where cme.idconfmontvolcolmeia = p_idConfMontVolColmeia;
  
    delete from confmontvolcolmeia c
     where c.idescaninho = p_idEscaninho
       and c.idnotafiscal = p_idNotaFiscal
       and c.idproduto = p_idProduto
       and c.status = pk_montagemvolume.C_SOLIC_LOCAL_RET_PROD_CANCEL;
  
    for c_mov in (select m.*
                    from movimentacao m, lote lt, produto p
                   where m.idnotafiscal = p_idNotaFiscal
                     and m.status = 2
                     and m.idlote = lt.idlote
                     and lt.idproduto = p.idproduto
                     and p.idproduto = p_idProduto)
    loop
    
      baixarConteudoEscaninho(c_mov.id, c_mov.qtdeconferida);
    
      baixarConfEscaninho(c_mov.qtdeconferida);
    
      baixarMovimentacao(c_mov, v_qtdeFaltaCancelar, v_qtdeJaCancelada);
    
      baixarItensNotaFiscal(p_idNotaFiscal, p_idProduto, v_qtdeJaCancelada);
    
      baixarItensOrdemSeparacao(v_idOrdemSeparacao, p_idProduto,
                                v_qtdeJaCancelada);
    
      select case
                when (snf.qtdeconferida - v_qtdeJaCancelada) < 0 then
                 snf.qtdeconferida
                else
                 snf.qtdeconferida - v_qtdeJaCancelada
              end qtdeConferida
        into v_qtdeConferidaAux
        from saidapornf snf
       where snf.idnotafiscal = p_idNotaFiscal;
    
      update saidapornf snf
         set snf.qtdeseparada      = snf.qtdeseparada - v_qtdeJaCancelada,
             snf.qtdeconferida     = v_qtdeConferidaAux,
             snf.totalseparar      = snf.totalseparar - v_qtdeJaCancelada,
             snf.totalconferir     = snf.totalconferir - v_qtdeJaCancelada,
             snf.totalpesar        = snf.totalpesar - v_qtdeJaCancelada,
             snf.separacaoiniciada = snf.separacaoiniciada -
                                     v_qtdeJaCancelada
       where snf.idnotafiscal = p_idNotaFiscal;
    
      exit when v_qtdeFaltaCancelar <= 0;
    
    end loop;
  
    update ordemseparacaocancelamentoitem osci
       set osci.status = 1
     where osci.idordemseparacaocancelamento =
           v_idOrdemSeparacaoCancelamento
       and osci.idproduto = p_idProduto;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Produto ID:' || p_idProduto ||
                          ' da Ordem de separação Cancelamento ID:' ||
                          v_idOrdemSeparacaoCancelamento ||
                          '. Sucesso no cancelamento do item.',
                         v_idOrdemSeparacaoCancelamento, 'IM');
  
    /* ***** validar se tudo que foi solicitado, foi cancelado ***** */
    /* ***** só assim podemos atualizar a OC e exportar a OCR ***** */
    select count(1)
      into v_ordemSepCancelEmAndamento
      from ordemseparacaocancelamentoitem osci
     where osci.idordemseparacaocancelamento =
           v_idOrdemSeparacaoCancelamento
       and osci.status = 0;
  
    if (v_ordemSepCancelEmAndamento = 0) then
    
      atualizarOrdemSepCancelamento(v_idOrdemSeparacao,
                                    v_idOrdemSeparacaoCancelamento, C_NAO,
                                    C_STATUS_CANCELADO_COM_SUCESSO, C_SIM,
                                    null, v_messageControlNumber);
    
      pk_integracao.exportarOCR(v_idOrdemSeparacao, v_messageControlNumber);
    
      select nfr.idromaneio
        into v_idOnda
        from nfromaneio nfr
       where nfr.idnotafiscal = p_idNotaFiscal;
    
      controleNotaFiscalEItens(v_idOrdemSeparacao, p_idNotaFiscal, v_idOnda,
                               true, p_idUsuario, false);
    end if;
  
  end confirmarCancelamentoProduto;

  procedure associaCustOrderItemInfContVol
  (
    p_idNotaFiscal     in number,
    p_idProduto        in number,
    p_idConteudoVolume in number
  ) is
  
    v_qtdeEmVolume number := 0;
  
    procedure addCustomOrderItemInfo
    (
      p_iditemordemsep in number,
      p_idconteudo     in number,
      p_qtdecartao     in number,
      p_qtderestante   in out number
    ) is
      v_id            number;
      v_qtdeassociada number;
    begin
      -- calcula a qtde correta para a geração do embrulho presente 
      if (p_qtdecartao > p_qtderestante) then
        v_qtdeassociada := p_qtderestante;
      else
        v_qtdeassociada := p_qtdecartao;
      end if;
    
      p_qtderestante := p_qtderestante - v_qtdeassociada;
    
      -- grava conteudo do embrulho presente
      begin
        select coif.id
          into v_id
          from customorderiteminfo coif
         where coif.idconteudovolume = p_idconteudo
           and coif.idordemsepitem = p_iditemordemsep;
      exception
        when no_data_found then
          v_id := 0;
      end;
    
      if (v_id = 0) then
        select seq_customorderiteminfo.nextval
          into v_id
          from dual;
      
        insert into customorderiteminfo
          (id, idordemsepitem, idconteudovolume, quantidade)
        values
          (v_id, p_iditemordemsep, p_idconteudo, v_qtdeassociada);
      else
        update customorderiteminfo coif
           set coif.quantidade = coif.quantidade + v_qtdeassociada
         where coif.id = v_id;
      end if;
    end addCustomOrderItemInfo;
  
  begin
  
    select sum(cv.quantidadefracionada)
      into v_qtdeEmVolume
      from conteudovolume cv, lote l
     where cv.idlote = l.idlote
       and l.idproduto = p_idproduto
       and cv.id = p_idConteudoVolume;
  
    for c_custOrdItemInfo in (select idordemsepitem,
                                     qtdecustomorderiteminfrestante
                                from (select idordemsepitem,
                                              (qtdeitem -
                                               qtdecustomorderiteminfo) qtdecustomorderiteminfrestante
                                         from (select osi.idordemsepitem,
                                                       osi.qtdeitem,
                                                       (select nvl(sum(coif.quantidade),
                                                                     0)
                                                           from customorderiteminfo coif,
                                                                conteudovolume cv,
                                                                volumeromaneio vr
                                                          where coif.idordemsepitem =
                                                                osi.idordemsepitem
                                                            and vr.statusvolume = 0
                                                            and vr.idvolumeromaneio =
                                                                cv.idvolumeromaneio
                                                            and cv.id =
                                                                coif.idconteudovolume) qtdecustomorderiteminfo
                                                  from ordemseparacao os,
                                                       ordemseparacaoitem osi
                                                 where os.idordemseparacao =
                                                       osi.idordemsep
                                                   and os.idnotafiscal =
                                                       p_idnotafiscal
                                                   and osi.idproduto =
                                                       p_idproduto
                                                 order by osi.idordemsepitem)) p
                               where p.qtdecustomorderiteminfrestante > 0)
    loop
      addCustomOrderItemInfo(c_custOrdItemInfo.idordemsepitem,
                             p_idConteudoVolume,
                             c_custOrdItemInfo.qtdecustomorderiteminfrestante,
                             v_qtdeEmVolume);
      exit when v_qtdeEmVolume = 0;
    
    end loop;
  
  end associaCustOrderItemInfContVol;

  procedure controleNotaFiscalEItens
  (
    p_idOrdemSeparacao    in number,
    p_idNotaFiscal        in number,
    p_idOnda              in number,
    p_NfEmOnda            in boolean,
    p_idUsuarioIntegracao in number,
    p_exportarOfr         in boolean
  ) is
  
    v_qtdeItensRestantes number;
    v_idPrenf            number;
    v_origem             number;
    v_statusOF           ordemseparacao.status%type;
    v_erro_cancelamento  varchar2(4000);
  
  begin
  
    select count(1)
      into v_qtdeItensRestantes
      from ordemseparacao os, notafiscal nf, nfdet nd
     where os.idordemseparacao = p_idOrdemSeparacao
       and os.idnotafiscal = nf.idnotafiscal
       and nf.idnotafiscal = nd.nf
       and nf.statusnf <> 'X'
       and nd.qtde > 0;
  
    if (v_qtdeItensRestantes > 0) then
      delete from ordemseparacaoitem osi
       where osi.idordemsep = p_idOrdemSeparacao
         and osi.qtdeitem = 0;
    
      pk_notafiscal.p_totalliza_nfdet(p_idNotaFiscal);
      pk_notafiscal.p_totaliza_nf(p_idNotaFiscal, 'N');
    
    else
    
      select distinct nf.idprenf
        into v_idPrenf
        from ordemseparacao os, notafiscal nf, nfdet nd
       where os.idordemseparacao = p_idOrdemSeparacao
         and os.idnotafiscal = nf.idnotafiscal
         and nf.idnotafiscal = nd.nf;
    
      if (p_idOnda is not null and p_NfEmOnda) then
      
        update escaninho e
           set e.status = C_ESCANINHO_NAO_UTILIZADO
         where e.idnotafiscal = p_idNotaFiscal;
      
        pk_onda_cancelar.removerNotaFiscalOnda(p_idOnda, p_idNotaFiscal,
                                               p_idUsuarioIntegracao);
      end if;
    
      if (p_exportarOfr) then
        v_origem := 0;
      else
        v_origem := 2;
      end if;
    
      pk_notafiscal.CancelaNF(v_idPrenf, p_idUsuarioIntegracao,
                              'Cancelamento realizado via OC (Order Cancel Request)',
                              'N', 'N', v_erro_cancelamento, 0, v_origem);
    
      select os.status
        into v_statusOF
        from ordemseparacao os
       where os.idordemseparacao = p_idOrdemSeparacao;
    
      if (v_statusOF = 0) then
        cancelaOrdemSeparacao(p_idOrdemSeparacao,
                              'Cancelamento realizado via OC (Order Cancel Request)',
                              p_idUsuarioIntegracao);
      end if;
    
    end if;
  end controleNotaFiscalEItens;

  procedure excluirOrdemSepENotaFiscal
  (
    p_idUsuario        in number,
    p_idOrdemSeparacao in number
  ) is
  
    C_PENDENTE constant number := 0;
  
    v_idNfVinculado number;
    v_idPrenf       number;
    v_statusOF      number;
    v_erro          varchar2(4000);
    v_msg           t_message;
  
  begin
  
    select os.idnotafiscal, os.status
      into v_idNfVinculado, v_statusOF
      from ordemseparacao os
     where os.idordemseparacao = p_idOrdemSeparacao;
  
    if (v_statusOF <> C_PENDENTE) then
      v_msg := t_message('Ordem de Separação com status diferende de "Pendente" não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (nvl(v_idNfVinculado, 0) > 0) then
    
      select nf.idprenf
        into v_idPrenf
        from notafiscal nf
       where nf.idnotafiscal = v_idNfVinculado;
    
      begin
        pk_notafiscal.CancelaNF(v_idPrenf, p_idUsuario,
                                'NF cancelada pela exclusão da Ordem de separação id: ' ||
                                 p_idOrdemSeparacao, 'N', 'N', v_erro, 0, 1);
      exception
        when others then
          v_msg := t_message('Erro ao cancelar notafiscal id: {0} - {1}');
          v_msg.addParam(v_idNfVinculado);
          v_msg.addParam(v_erro);
          raise_application_error(-20000, v_msg.formatmessage);
      end;
    
      begin
        pk_notafiscal.excluirNotaFiscal(v_idPrenf, p_idUsuario);
      end;
    end if;
  
    -- tabelas auxiliares
    delete from ordemseparacaoitem_aux osia
     where osia.idordemsep = p_idOrdemSeparacao;
  
    delete from ordemseparacao_aux osa
     where osa.idordemseparacao = p_idOrdemSeparacao;
  
    -- tabelas principais
    delete from ordemseparacaoitem osi
     where osi.idordemsep = p_idOrdemSeparacao;
  
    delete from ordemseparacao os
     where os.idordemseparacao = p_idOrdemSeparacao;
  
  end excluirOrdemSepENotaFiscal;

end pk_ordemseparacao;
/

