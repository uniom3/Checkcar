create view VB_PRODUTOOSKITRASTREABILIDADE as
select p.codigointerno, p.descr descricao, p.idproduto,
       pd.identidade h$iddepositante
  from produto p , produtodepositante pd
 where pd.idproduto = p.idproduto
   and exists
 (select 1 -- Garanti que é Kit
          from kitproduto k
         where k.idprodutokit = pd.idproduto
           and not exists
         (select 1
                  from kitproduto kb
                 where kb.idprodutokit = k.idproduto
                   and (kb.estojo = 1 or exists -- Trava KKE / KKK
                        (select 1
                           from kitproduto kc
                          where kc.idprodutokit = kb.idproduto))))
/

