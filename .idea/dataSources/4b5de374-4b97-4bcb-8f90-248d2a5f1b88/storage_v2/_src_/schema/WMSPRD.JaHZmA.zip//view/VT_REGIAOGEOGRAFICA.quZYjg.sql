create view VT_REGIAOGEOGRAFICA as
select p.pais pais, r.idregiao sigla, r.descr descricao, r.id h$id
  from regiao r, pais p
 where r.idpais = p.idpais
   and nvl(p.codpais,0) not in (9999)
/

