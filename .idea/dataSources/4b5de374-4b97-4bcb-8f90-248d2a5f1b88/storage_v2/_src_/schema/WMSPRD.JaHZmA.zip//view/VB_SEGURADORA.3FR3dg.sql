create view VB_SEGURADORA as
select e.razaosocial seguradora,
       decode(e.pessoa, 'J', e.cgc, e.cic) cnpjcpf, e.identidade,
       e.iddepositante h$iddepositante
  from entidade e
 where e.ativo = 'S'
   and e.tipoentidade in (select idtipo
                            from tipo
                           where descr like '%SEGURA%')
 order by e.codigointerno
/

