create view VR_ETIQUETAEMBALAGEM as
select e.barra,
       'Cod. ' || (case
          when (nvl(g.iddepositante, 0) = 0) then
           p.codigointerno
          else
           (select nvl(pd.codigointerno, p.codigointerno)
              from produtodepositante pd
             where pd.idproduto = p.idproduto
               and pd.identidade = g.iddepositante)
        end) codproduto, p.descr produto, e.descr embalagem, e.apresentacao,
       e.descrreduzido, e.fatorconversao
  from gtt_embalagem g, embalagem e, produto p
 where e.idproduto = g.idproduto
   and e.barra = g.barra
   and p.idproduto = e.idproduto
/

