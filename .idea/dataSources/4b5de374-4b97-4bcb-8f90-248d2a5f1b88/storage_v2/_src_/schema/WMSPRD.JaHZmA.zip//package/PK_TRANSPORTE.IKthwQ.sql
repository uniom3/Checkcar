create package pk_transporte is
  procedure gera_despesas_padrao
  (
    p_carga in carga.idcarga%type,
    p_movto in string
  );
  procedure fechamento_motorista(p_carga in carga.idcarga%type);

  procedure atualiza_km
  (
    p_placa   in veiculo.placa%type,
    p_kmfinal in carga.kmfinal%type
  );
  procedure acerto_financeiro
  (
    p_notafiscal in number,
    p_operacao   in string,
    p_idusuario  in usuario.idusuario%type
  );

  function Retornar_NumDiarias
  (
    p_horainicio in date,
    p_horafim    in date
  ) return number;

  function retornarQtdeEtiqTransportador(p_idnotafiscal in number)
    return number;

  procedure gravarEtiquetaTransportador
  (
    p_idonda       in number,
    p_idnotafiscal in number,
    p_qtdesugerida in number,
    p_qtdeimpressa in number,
    p_idusuario    in number,
    p_origemimp    in number,
    p_idsupervisor in number := 0,
    p_retorno      out number,
    p_idetiqueta   out number
  );

  procedure adicionarTranspRedespacho
  (
    p_idservicotransportadora in number,
    p_idtransportadora        in number,
    p_idusuario               in number
  );

  procedure removerTranspRedespacho
  (
    p_idservicotransportadora in number,
    p_idtransportadora        in number
  );

end pk_transporte;
/

