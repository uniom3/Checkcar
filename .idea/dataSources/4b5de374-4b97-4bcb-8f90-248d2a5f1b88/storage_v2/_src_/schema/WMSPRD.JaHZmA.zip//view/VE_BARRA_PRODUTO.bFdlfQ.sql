create view VE_BARRA_PRODUTO as
select ed.cgc cnpj_depositante, pd.codigointerno codigoproduto, eb.barra barraunitaria
  from produto pr, produtodepositante pd, depositante dp, entidade ed, embalagem eb
  where pr.idproduto = pd.idproduto
  and pd.identidade = dp.identidade
  and dp.identidade = ed.identidade
  and pd.idproduto = eb.idproduto
  and eb.fatorconversao = 1
  and eb.ativo = 'S'
/

