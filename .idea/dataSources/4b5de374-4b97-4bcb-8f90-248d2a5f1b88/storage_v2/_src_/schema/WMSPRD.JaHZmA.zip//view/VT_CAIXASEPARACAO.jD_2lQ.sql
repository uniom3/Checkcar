create view VT_CAIXASEPARACAO as
select cx.idcaixaseparacao,
       decode(cx.tipo, 0, 'COLMÉIA', 1, 'AUDITORIA', 2, 'CHECKOUT EXPRESS', 3, 'ETIQUETAGEM') tipo,
       c.cor colmeia, nvl(cx.cor, c.cor) cor, l.idlocal, cx.descricao,
       cx.barra, cx.liberado, nvl(a.idarmazem, ar.idarmazem) h$idarmazem,
       l.idlocalformatado f$idlocal, l.ordem h$ordem
  from caixaseparacao cx, colmeia c, local l, armazem a, armazem ar
 where ar.idarmazem(+) = c.idarmazem
   and c.idcolmeia(+) = cx.idcolmeia
   and l.id(+) = cx.idendereco
   and a.idarmazem(+) = l.idarmazem
/

