create view VT_LINHASEPEXTREGIAO as
select distinct decode((select count(1)
                          from linhasepextregiao lse
                         where lse.idregiaoarmazenagem = ra.idregiao
                           and lse.idlinhasepext = ls.id), 0, 0, 1) marcado,
                ra.descr regiao, ra.tipo, ra.idregiao,
                ls.id h$idlinhasepexterna, ra.rowid || ls.rowid h$tableid
  from regiaoarmazenagem ra, linhasepexterna ls
 where not exists (select 1
          from linhasepextregiao lse
         where lse.idregiaoarmazenagem = ra.idregiao
           and lse.idlinhasepext <> ls.id)
/

