create view VB_DEPOSITANTEFILIAL as
select e.identidade, e.razaosocial depositante,
       cgc, cic, e.inscrestadual, e.pessoa
  from entidade e, depositante d, regime r
 where e.ativo = 'S'
   and d.identidade = e.identidade
   and r.idregime = d.idregime
   and r.classificacao = 'F'
 order by e.razaosocial
/

