create TYPE BODY T_MESSAGE AS
    constructor function T_MESSAGE(p_param in varchar2) return self as result is
    begin
      v_message   := p_param;
      parametros := T_LIST_MESSAGE_PARAM;
      return;
    end T_MESSAGE;
  
    MEMBER procedure addParam(p_value in varchar2) is
    begin
      parametros.addParam(p_value);
    end addParam;
  
    MEMBER procedure addParam(p_value in number) is
    begin
      parametros.addParam(p_value);
    end addParam;
  
    MEMBER procedure addParam(p_value in date) is
    begin
      parametros.addParam(p_value);
    end addParam;
  
    MEMBER function formatMessage return varchar2 is
    begin
      return pk_message.getMessage(self);
    end formatMessage;
  
    MEMBER function formatXML return Xmltype is
    begin
      return pk_message.convertMessageParamToXMLType(self);
    end formatXML;
  END;

/

