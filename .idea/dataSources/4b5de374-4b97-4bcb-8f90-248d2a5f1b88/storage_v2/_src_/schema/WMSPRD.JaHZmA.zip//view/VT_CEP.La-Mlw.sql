create view VT_CEP as
select cep.idcep, cep.cep, cep.recuperavel, p.idpais, p.pais, cep.idcidade,
       c.descr cidade, c.estadocidade, cep.idbairro, b.descr bairro,
       te.descr endereco, cep.logradouro, cep.paginageomapa
  from cep cep, bairro b, cidade c, tipoendereco te, pais p
 where b.idbairro(+) = cep.idbairro
   and b.idcidade(+) = cep.idcidade
   and c.idcidade(+) = cep.idcidade
   and p.idpais(+) = c.pais
   and te.idtipoendereco(+) = cep.idtipoendereco
/

