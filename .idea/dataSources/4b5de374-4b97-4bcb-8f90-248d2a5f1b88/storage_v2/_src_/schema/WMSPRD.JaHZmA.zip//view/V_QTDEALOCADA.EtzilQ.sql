create view V_QTDEALOCADA as
select lt.idlotenf, lt.idproduto, lt.estado,
       sum(e.fatorconversao * ma.qtde) qtdeun
  from mapaalocacao ma, embalagem e,
       (select distinct nf.idlotenf, o.idlote, l.idproduto, l.barra, l.estado
           from origemlote o, notafiscal nf, lote l
          where o.idnotafiscal = nf.idnotafiscal
            and o.idlote = l.idlote) lt
 where e.idproduto = lt.idproduto
   and ma.idlote = lt.idlote
   and ma.status <> 'X'
   and e.barra in (select max(barra)
                     from embalagem
                    where idproduto = lt.idproduto
                      and fatorconversao in
                          (select max(fatorconversao)
                             from embalagem
                            where idproduto = lt.idproduto))
 group by lt.idlotenf, lt.idproduto, lt.estado
/

