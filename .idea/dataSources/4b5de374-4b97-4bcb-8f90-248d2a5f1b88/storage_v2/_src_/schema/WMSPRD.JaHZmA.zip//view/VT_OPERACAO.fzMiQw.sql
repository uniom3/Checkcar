create view VT_OPERACAO as
select idoperacao, descr descricao, idcfop cfop, tipo, tipooper,
       decode(tipooper, 'RA', 'Remessa Armazenagem', 'RS',
               'Remessa Simbólica para Armazenagem', 'RG',
               'Remessa Armazenagem GMB', 'TA', 'Retorno de Armazenagem', 'TS',
               'Retorno Simbólico de Armazenagem', 'TG',
               'Retorno Armazenagem GMB', 'TD', 'Retorno Devolução', 'G',
               'Guia de Movimentação Bancária (GMB)', 'RG',
               'Remessa Armazenagem GMB', 'TG', 'Retorno Armazenagem GMB',
               'RD', 'Retorno Devolução', 'OU', 'Outros') tipooperacao,
       classificacaofiscal, classificacaocfop, tipofinalidadenfe, menslinha1,
       menslinha2
  from operacao o
/

