create view VT_CODIGORASTREIO as
select c.rowid h$tableid, c.idconftranspdep, et.razaosocial transportadora,
       ed.razaosocial depositante, edest.razaosocial destinatario,
       entrega.razaosocial entrega, st.utilizacodrastr,
       decode(cr.status, 0, 'DISPONÍVEL', 1, 'UTILIZADO', 2, 'CANCELADO') status,
       cr.codigorastreio, vr.idvolumeromaneio, nf.codigointerno notafiscal,
       et.identidade idTransportadora, ed.identidade idDepositante,
       cr.idcodrasttransdep, cr.status h$status
  from confTranspDepositante c, codrasttransdep cr, entidade ed, entidade et,
       volumeromaneio vr, nfromaneio nfr, notafiscal nf, entidade edest,
       entidade entrega, servicotransportadora st, transpdepositante td
 where c.idconftranspdep = cr.idconftranspdep
   and ed.identidade = td.iddepositante
   and et.identidade = td.idtransportadora
   and vr.idcodrasttransdep(+) = cr.idcodrasttransdep
   and nfr.idromaneio(+) = vr.idromaneio
   and nfr.idnotafiscal(+) = vr.idnotafiscal
   and nf.idnotafiscal(+) = nfr.idnotafiscal
   and edest.identidade(+) = nf.destinatario
   and entrega.identidade(+) = nf.ident_entrega
   and td.idtranspdepositante = st.idtranspdepositante
   and st.idservicotransportadora = c.idservicotransportadora
/

