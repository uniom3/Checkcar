create view VT_PRODUTOONDA as
select p.idproduto, p.codigointerno codprod, nd.barra,
       sum(nd.qtdeatendida) qtde, p.descr produto, 
       rp.datageracao, f.razaosocial familia, sf.descr subfamilia,
       e.fatorconversao, e.pesobruto, rp.idromaneio h$idonda
  from romaneiopai rp, nfromaneio nfr, nfdet nd, produto p, embalagem e,
       entidade f, subfamilia sf
where sf.idsubfamilia(+) = p.idsubfamilia
   and f.identidade(+) = p.idfamilia
   and e.barra = nd.barra
   and e.idproduto = nd.idproduto
   and p.idproduto = nd.idproduto
   and nd.nf = nfr.idnotafiscal
   and nfr.idromaneio = rp.idromaneio
 group by p.idproduto, p.codigointerno, nd.barra, p.descr,
          rp.datageracao, f.razaosocial, sf.descr,
          e.fatorconversao, e.pesobruto,  rp.idromaneio

/

