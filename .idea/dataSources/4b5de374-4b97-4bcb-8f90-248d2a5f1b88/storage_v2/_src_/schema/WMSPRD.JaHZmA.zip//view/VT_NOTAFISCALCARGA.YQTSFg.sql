create view VT_NOTAFISCALCARGA as
select dep.fantasia depositante, nf.numpedidofornecedor pedido,
       nf.codigointerno notaFiscal, nf.sequencia serie, nf.estado,
       dest.razaosocial destinatario, trans.fantasia transportadora, e.uf,
       d.ondaexclusiva depOndaExclusiva, nf.dataentrega,
       trans.razaoSocial razaoSocialTransportadora,
       dest.codigoInterno as codigoCliente, dest.cgc as cnpjDestinatario,
       e.bairro, e.cidade, d.identidade as idDepositante,
       dep.razaoSocial as razaoSocialDepositante, dep.cgc as cnpjDepositante,
       nf.dataProcessamento as dataCadastro, nf.dataEmissao as DataEmissao,
       nfi.ciffob as tipoFrete, nf.totalGeral as totalGeral,
       d.diasRestricao as diasRestricao, nf.pesoBruto as pesoBruto,
       nf.idnotafiscal, trans.identidade idTransportadora, nf.statusnf,
       dest.identidade, nvl(nf.idpedidopai, 0) h$idpedidopai,
       nc.idcarga coleta
  from nfromaneio nfr, notafiscal nf, nfimpressao nfi, entidade dep,
       depositante d, entidade trans, entidade dest, notafiscalcarga nc,
       (select eDest.identidade, eDest.Idendereco, cDest.Estadocidade uf,
                bDest.Descr as bairro, cdest.descr as cidade
           from endereco eDest, bairro bDest, cidade cDest
          where cDest.Idcidade = eDest.Idcidade
            and bDest.Idbairro = edest.idbairro) e
 where 1 = 1
   and nf.idnotafiscal = nfr.idnotafiscal
   and nfi.idprenf = nf.idprenf
   and nc.idnotafiscal = nf.idnotafiscal
   and dep.identidade = nf.iddepositante
   and d.identidade = dep.identidade
   and trans.identidade(+) = nf.transportadoranotafiscal
   and dest.identidade = nf.destinatario
   and e.identidade(+) = dest.identidade
   and e.idendereco(+) = pk_entidade.f_ret_idendereco(dest.identidade)
/

