create view VB_ENTIDADE_PROD_EMIT as
select e.razaosocial, e.fantasia,
       decode(e.pessoa, 'J', e.cgc, e.cic) cnpjcpf,
       e.identidade,
       nvl(e.iddepositante, e.identidade) h$iddepositante,
       t.idtipo h$idtipoentidade, t.descr h$tipoentidade
  from entidade e, tipo t
 where e.ativo = 'S'
   and e.tipoentidade = t.idtipo
/

