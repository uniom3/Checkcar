create package body pk_separacaoespecifica is

  C_ESTOQUE_RESERVADO_LOTE constant number := -20111;

  function isPermiteAltLoteIndustria(p_idnfdet in number) return boolean is
    v_isPedWeb char(1) := 'N';
  begin
    begin
      select nfi.pedidoweb
        into v_isPedWeb
        from nfdet nd, notafiscal nf, nfimpressao nfi
       where nd.idnfdet = p_idnfdet
         and nf.idnotafiscal = nd.nf
         and nfi.idprenf = nf.idprenf;
    exception
      when no_data_found then
        v_isPedWeb := 'N';
    end;
  
    return v_isPedWeb = 'N';
  end isPermiteAltLoteIndustria;


  function getQtdeJaLiberada
  (
    p_idnotafiscal number,
    p_idProduto    number
  ) return number is
    r_notafiscal     notafiscal%rowtype;
    v_qtdeJaLiberada number;
  begin
    begin
      select nf.*
        into r_notafiscal
        from notafiscal nf
       where 1 = 1
         and nf.idnotafiscal = p_idnotafiscal;
    exception
      when no_data_found then
        return 0;
    end;
  
    select nvl(sum(nd.qtdeatendida * e.fatorconversao), 0) qtdeJaLiberada
      into v_qtdeJaLiberada
      from notafiscal nf, nfdet nd, embalagem e
     where 1 = 1
       and nd.nf = nf.idnotafiscal
       and e.barra = nd.barra
       and e.idproduto = nd.idproduto
       and nf.estoqueverificado = 'S'
       and nf.tipo = 'S'
       and nf.statusnf not in ('X', 'P')
       and nf.movestoque = 'S'
       and nf.idarmazem = r_notafiscal.idarmazem
       and nf.iddepositante = r_notafiscal.iddepositante
       and nd.idproduto = p_idProduto
       and not exists
     (select 1
              from nfromaneio nfr
             where 1 = 1
               and nfr.idnotafiscal = nf.idnotafiscal);
  
    return v_qtdeJaLiberada;
  
  end getQtdeJaLiberada;

  procedure marcarMetodoSepEspecifica
  (
    p_idnotafiscal              in number,
    p_metodoSeparacaoEspecifica in number
  ) is
  begin
    update notafiscal nf
       set nf.metodoSeparacaoEspecifica = p_metodoSeparacaoEspecifica
     where nf.idnotafiscal = p_idnotafiscal;
  end;

  procedure desmarcarMetodoSepEspecifica(p_idnotafiscal in number) is
    v_existeAlgumLoteVinculado number;
  begin
    select count(*)
      into v_existeAlgumLoteVinculado
      from dual
     where exists (select 1
              from separacaoespecifica se
             where se.idnotafiscal = p_idnotafiscal);
  
    if (v_existeAlgumLoteVinculado = 0) then
      update notafiscal nf
         set nf.metodoseparacaoespecifica = null
       where nf.idnotafiscal = p_idnotafiscal;
    end if;
  end desmarcarMetodoSepEspecifica;

  procedure validarLoteVinculadoTipoPedido
  (
    p_idarmazem    in number,
    p_idlocal      in local.idlocal%type,
    p_idlote       in number,
    p_idnotafiscal in number
  ) is
    v_compativelTipoPedido number;
    v_msg                  t_message;
  begin
  
    select count(1)
      into v_compativelTipoPedido
      from vt_separacaoespecifica_tp v
     where v.h$idarmazem = p_idarmazem
       and v.h$idnotafiscal = p_idnotafiscal
       and v.idlote = p_idlote;
  
    if (v_compativelTipoPedido = 0) then
      v_msg := t_message('Este lote não é compatível com a Classificação do tipo de Pedido.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  function isNotaComRastroLoteIndustria(p_idnfdet in number) return number is
  
    C_NAO_NOTA_POSSUI_RASTRO constant number := 0;
    C_NOTA_POSSUI_RASTRO     constant number := 1;
  
    v_comRastro number;
  
  begin
  
    select count(1)
      into v_comRastro
      from notafiscal nf, nfdetrastro nfm
     where nfm.idnfdet = p_idnfdet
       and nf.idprenf = nfm.idprenf;
  
    if v_comRastro = 0 then
      -- Verifica também se foi colocado em separação específica através de importação Banco e TXT
      select count(1)
        into v_comRastro
        from nfdetimpressao ndi, nfdet nd
       where nd.idnfdet = p_idnfdet
         and nd.idnfdet = ndi.idnfdet
         and not exists (select 1
                from nfdetrastro nm
               where nm.idnfdet = ndi.idnfdet)
         and ndi.serie is not null;
    
      if v_comRastro = 0 then
        return C_NAO_NOTA_POSSUI_RASTRO;
      end if;
    end if;
  
    return C_NOTA_POSSUI_RASTRO;
  
  end isNotaComRastroLoteIndustria;

  function isNotaComRastro(p_idnotafiscal in number) return number is
  
    C_NAO_NOTA_POSSUI_RASTRO constant number := 0;
    C_NOTA_POSSUI_RASTRO     constant number := 1;
  
    v_comRastro number;
  begin
    select count(1)
      into v_comRastro
      from nfdetrastro nfm, notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal
       and nfm.idprenf = nf.idprenf;
  
    if v_comRastro = 0 then
      -- Verifica também se foi colocado em separação específica através de importação Banco e TXT
      select count(1)
        into v_comRastro
        from nfdetimpressao ndi, nfdet nd
       where nd.nf = p_idnotafiscal
         and nd.idnfdet = ndi.idnfdet
         and not exists (select 1
                from nfdetrastro nm
               where nm.idnfdet = ndi.idnfdet)
         and trim(ndi.serie) is not null;
    
      if v_comRastro = 0 then
        return C_NAO_NOTA_POSSUI_RASTRO;
      end if;
    end if;
  
    return C_NOTA_POSSUI_RASTRO;
  
  end isNotaComRastro;

  procedure vincularSeparacaoEspecifica
  (
    p_idarmazem      in number,
    p_idlocal        in local.idlocal%type,
    p_idlote         in number,
    p_idnotafiscal   in number,
    p_qtde           in number,
    p_idUsuario      in number,
    p_fonteSeparacao in number := C_SEP_ESPEC_ENTERPRISE,
    p_cadManual      in char := 'S'
  ) is
    type t_sep is record(
      iddepositante                number,
      metodoSepEspecifica          number,
      idprenf                      number,
      statusnf                     char(1),
      statusnftexto                varchar2(50),
      estoqueverificado            char(1),
      aceitaLoteFracionado         number,
      permitiralterarqtdeseparacao number,
      reservalotes                 notafiscal.reservalotes%type);
  
    r_sep t_sep;
  
    type t_lote is record(
      qtdeCoberturaUN        number,
      fatorConversaoEstoque  number,
      qtdeSolicitadaUN       number,
      qtdeEmOutrasSeparacoes number,
      qtdeJaVinculaUN        number,
      qtdeDispEstoqueUN      number,
      produtofracionado      char(1),
      produto                varchar2(120),
      idproduto              number);
  
    r_lote t_lote;
  
    v_msg                         t_message;
    v_permiteVencido              number;
    v_vinculoSepEsp_viaIntegracao number;
  
    procedure validarQtde is
    
      procedure usarToleranciaLoteNaoFrac is
      begin
        if (r_sep.aceitaLoteFracionado = 1) then
          return;
        end if;
      
        if (r_lote.qtdeEmOutrasSeparacoes > 0) then
          v_msg := t_message('Depositante não permite fracionamento de lote. Este lote já esta sendo utilizado em outra separação especifica.');
          raise_application_error(-20000, v_msg.formatMessage);
        
        end if;
      
        if (r_lote.qtdeDispEstoqueUN <> r_lote.qtdeSolicitadaUN) then
          v_msg := t_message('Depositante não permite fracionamento de lote, use a quantidade total disponível do lote.' ||
                             chr(13) || 'Qtde Disp. Estoque (un): {0}' ||
                             chr(13) || 'Qtde Solicitada (un): {1}');
          v_msg.addParam(r_lote.qtdeDispEstoqueUN);
          v_msg.addParam(r_lote.qtdeSolicitadaUN);
          raise_application_error(-20000, v_msg.formatMessage);
        
        end if;
      
      end usarToleranciaLoteNaoFrac;
    
      function getPercentualTolerancia(p_idNotaFiscal in number)
        return number is
        v_tipoNf             char(1);
        v_percTolerancia     number;
        v_permAlterarQtdeSep number;
      begin
      
        select n.tiponf, d.percentualtolerancia,
               d.permitiralterarqtdeseparacao
          into v_tiponf, v_percTolerancia, v_permAlterarQtdeSep
          from notafiscal n, depositante d
         where n.iddepositante = d.identidade
           and n.idnotafiscal = p_idNotaFiscal;
      
        if v_tiponf = 'P' then
          if v_permAlterarQtdeSep = 1 then
            return v_percTolerancia;
          else
            return 0;
          end if;
        else
          return 0;
        end if;
      
      end getPercentualTolerancia;
    
      procedure validarQtdeEmNFvsSolicitada is
        v_margemtoleranciaUN number;
        v_qtdeitemUN         number;
        v_qtdejavinculadaUN  number;
      begin
        select sum(nd.qtde * e.fatorconversao)
          into v_qtdeitemUN
          from nfdet nd, embalagem e
         where nd.nf = p_idnotafiscal
           and nd.idproduto = r_lote.idproduto
           and e.idproduto = nd.idproduto
           and e.barra = nd.barra;
      
        select nvl(sum(s.qtde), 0)
          into v_qtdejavinculadaUN
          from separacaoespecifica s, lote lt
         where s.idnotafiscal = p_idnotafiscal
           and lt.idlote = s.idlote
           and lt.idproduto = r_lote.idproduto;
      
        if (v_qtdejavinculadaUN + r_lote.qtdeSolicitadaUN) > v_qtdeitemUN then
          if (r_sep.permitiralterarqtdeseparacao = 0) then
            v_msg := t_message('A quantidade total do produto que esta sendo vinculado na separação especifica é maior do que o solicitado em Pedido/Nota Fiscal.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          v_margemtoleranciaUN := trunc(((v_qtdeitemUN / 100) *
                                        getPercentualTolerancia(p_idnotafiscal)) +
                                        v_qtdeitemUN);
        
          if (v_qtdejavinculadaUN + r_lote.qtdeSolicitadaUN) >
             v_margemtoleranciaUN then
            v_msg := t_message('A quantidade informada para separação especifica é maior que a quantidade solicitada no documento.' ||
                               chr(13) || 'Idnotafiscal: {0}' || chr(13) ||
                               'Idproduto: {1}' || chr(13) ||
                               'Qtde maxima permitida: {2}' || chr(13) ||
                               'Qtde solicitada: {3}' || chr(13) ||
                               'Qtde já vinculada: {4}');
            v_msg.addParam(p_idnotafiscal);
            v_msg.addParam(r_lote.idproduto);
            v_msg.addParam(trunc(v_margemtoleranciaUN /
                                 r_lote.fatorconversaoestoque, 6));
            v_msg.addParam(p_qtde);
            v_msg.addParam(trunc(v_qtdejavinculadaUN /
                                 r_lote.fatorconversaoestoque, 6));
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end validarQtdeEmNFvsSolicitada;
    
    begin
      select (lt.qtdedisponivel * e.fatorconversao) qtdecobertura,
             nvl(ee.fatorconversao, 1) fatorconversaoestoque, p.fracionado,
             p.descr, p.idproduto
        into r_lote.qtdecoberturaun, r_lote.fatorconversaoestoque,
             r_lote.produtofracionado, r_lote.produto, r_lote.idproduto
        from lote lt, embalagem e, produtodepositante pd, embalagem ee,
             produto p
       where lt.idlote = p_idlote
         and e.barra = lt.barra
         and e.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante
         and pd.idproduto = lt.idproduto
         and ee.barra(+) = pd.embalagemestoque
         and p.idproduto = lt.idproduto
         for update;
    
      r_lote.qtdeSolicitadaUN := p_qtde * r_lote.fatorconversaoestoque;
    
      select nvl(sum(s.qtde), 0)
        into r_lote.qtdeEmOutrasSeparacoes
        from separacaoespecifica s
       where s.idlote = p_idlote
         and s.idarmazem = p_idarmazem
         and s.idlocal = p_idlocal
         and s.idnotafiscal <> p_idnotafiscal
         and not exists
       (select 1
                from nfromaneio nfr
               where nfr.idnotafiscal = s.idnotafiscal);
    
      if (p_fonteseparacao = C_SEP_ESPEC_COLETOR) then
        select nvl(sum(s.qtde), 0)
          into r_lote.qtdeJaVinculaUN
          from separacaoespecifica s
         where s.idlote = p_idlote
           and s.idarmazem = p_idarmazem
           and s.idlocal = p_idlocal
           and s.idnotafiscal = p_idnotafiscal;
      else
        r_lote.qtdeJaVinculaUN := 0;
      end if;
    
      begin
        select (ll.estoque - ll.pendencia + ll.adicionar)
          into r_lote.qtdeDispEstoqueUN
          from lotelocal ll
         where ll.idlote = p_idlote
           and ll.idlocal = p_idlocal
           and ll.idarmazem = p_idarmazem;
      exception
        when no_data_found then
          v_msg := t_message('ESTOQUE NÃO DISPONÍVEL PARA O LOTE {0} NO LOCAL {1}.');
          v_msg.addParam(p_idlote);
          v_msg.addParam(pk_armazem.formatar_local(p_idlocal, p_idarmazem));
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      usarToleranciaLoteNaoFrac;
    
      r_lote.qtdeDispEstoqueUN := r_lote.qtdeDispEstoqueUN -
                                  r_lote.qtdeEmOutrasSeparacoes -
                                  r_lote.qtdeJaVinculaUN;
    
      if (r_lote.qtdeSolicitadaUN > r_lote.qtdeDispEstoqueUN) then
        v_msg := t_message('ESTOQUE NÃO DISPONÍVEL PARA O LOTE {0}' ||
                           ' NO LOCAL {1}.' || chr(13) ||
                           'A QUANTIDADE A ADICIONAR É DE {2} E SOMENTE' ||
                           ' {3} ESTÁ DISPONIVEL PARA UTILIZAÇÃO');
        v_msg.addParam(p_idlote);
        v_msg.addParam(pk_armazem.formatar_local(p_idlocal, p_idarmazem));
        v_msg.addParam(p_qtde);
        v_msg.addParam(trunc(r_lote.qtdeDispEstoqueUN /
                             r_lote.fatorconversaoestoque, 6));
        raise_application_error(C_ESTOQUE_RESERVADO_LOTE,
                                v_msg.formatMessage);
      
      end if;
    
      if ((r_lote.qtdecoberturaun - r_lote.qtdeEmOutrasSeparacoes -
         r_lote.qtdeJaVinculaUN) < r_lote.qtdeSolicitadaUN) then
      
        v_msg := t_message('ESTOQUE COBERTO INSUFICIENTE PARA O LOTE {0} NO LOCAL' ||
                           ' {1}.' || chr(13) ||
                           'A QUANTIDADE A ADICIONAR É DE {2}' ||
                           ' E SOMENTE {3}  ESTÁ DISPONIVEL PARA UTILIZAÇÃO');
        v_msg.addParam(p_idlote);
        v_msg.addParam(pk_armazem.formatar_local(p_idlocal, p_idarmazem));
        v_msg.addParam(p_qtde);
        v_msg.addParam(trunc((r_lote.qtdecoberturaun -
                             r_lote.qtdeEmOutrasSeparacoes) /
                             r_lote.fatorconversaoestoque, 6));
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_lote.produtofracionado = 'N' and
         r_lote.qtdeSolicitadaUN <> trunc(r_lote.qtdeSolicitadaUN)) then
        v_msg := t_message('O PRODUTO {0} (IDPRODUTO: {1}) NÃO PERMITE QUANTIDADE FRACIONADA.');
        v_msg.addParam(r_lote.produto);
        v_msg.addParam(r_lote.idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      validarQtdeEmNFvsSolicitada;
    
    end validarQtde;
  
    procedure quandoOrigemWMSEnterprise is
      v_total number;
    
      procedure verificaNfRastro is
        v_existeRastro number;
      begin
        select count(*)
          into v_existeRastro
          from nfdetrastro n
         where n.idprenf =
               (select idprenf
                  from notafiscal
                 where idnotafiscal = p_idnotafiscal);
      
        -- Desvia fluxo para não excluir lotes da separação específica quando se trata de rastro.
        if (v_existeRastro > 0) then
          v_vinculoSepEsp_viaIntegracao := 1;
        end if;
      
      end verificaNfRastro;
    
    begin
    
      verificaNfRastro;
    
      if not (p_fonteSeparacao = C_SEP_ESPEC_ENTERPRISE) then
        return;
      end if;
    
      if (v_vinculoSepEsp_viaIntegracao = 1) then
        return;
      end if;
    
      select count(*)
        into v_total
        from separacaoespecifica se
       where se.idnotafiscal = p_idnotafiscal
         and se.idlote = p_idlote
         and se.idlocal = p_idlocal
         and se.idarmazem = p_idarmazem;
    
      if (v_total > 0) then
        pk_separacaoespecifica.desvincularSeparacaoEspecifica(p_idarmazem,
                                                              p_idlocal,
                                                              p_idlote,
                                                              p_idnotafiscal,
                                                              p_idusuario, 0);
      end if;
    end quandoOrigemWMSEnterprise;
  
    procedure validarSep is
      C_NOTA_NAO_POSSUI_TAG_RASTRO constant number := 0;
    
    begin
    
      if (isNotaComRastro(p_idnotafiscal) = C_NOTA_NAO_POSSUI_TAG_RASTRO) then
        if (r_sep.metodoSepEspecifica = 1) then
          v_msg := t_message('O metodo de incluir o estoque para separação especifica não esta configurado para utilizar lote por local. Confira o cadastro do depositante.' ||
                             chr(13) || 'IDDEPOSITANTE: {0}');
          v_msg.addParam(r_sep.iddepositante);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end if;
    
      if r_sep.statusnf not in ('I', 'N') then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ {0}.' || chr(13) ||
                           'OPERAÇÃO CANCELADA.' || chr(13) ||
                           'IDPRENF: {1}' || chr(13) || 'IDNOTAFISCAL: {2}');
        v_msg.addParam(r_sep.statusnftexto);
        v_msg.addParam(r_sep.idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_sep.estoqueverificado = 'S' then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ LIBERADO PARA EXPEDIÇÃO.' ||
                           chr(13) ||
                           'PARA VINCULAR OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                           chr(13) || 'IDPRENF: {0}' || chr(13) ||
                           'IDNOTAFISCAL: {1}');
        v_msg.addParam(r_sep.idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_sep.estoqueverificado = 'X' then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL NÃO FOI LIBERADO PARA EXPEDIÇÃO DEVIDO A CORTE NO ESTOQUE.' ||
                           chr(13) ||
                           'PARA VINCULAR OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                           chr(13) || 'IDPRENF: {0}' || chr(13) ||
                           'IDNOTAFISCAL: {1}');
        v_msg.addParam(r_sep.idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    end validarSep;
  
  begin
    if (p_qtde <= 0) then
      v_msg := t_message('A quantidade informada deve ser maior que zero. Lote id: {0}');
      v_msg.addParam(p_idlote);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_permiteVencido
      from notafiscal nf, classificacaotipopedido c, lote lt
     where nf.idnotafiscal = p_idnotafiscal
       and c.idtipopedido = nf.idtipopedido
       and c.estadomat = 'N'
       and lt.idlote = p_idlote
       and lt.dtvenc <= trunc(sysdate);
  
    if v_permiteVencido > 0 then
      v_msg := t_message('O lote id: {0} não pode ser vinculado pois está vencido e o ' ||
                         'estado do material na Classificação Tipo de Pedido da Nota ' ||
                         'Fiscal id {1} é diferente de VENCIDO/TRUNCADO.');
      v_msg.addParam(p_idlote);
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_locks.executeLock(p_idArmazem, 1);
  
    select nf.iddepositante,
           nvl(nf.metodoseparacaoespecifica, d.agruparinclusaolotes),
           nf.idprenf, nf.statusnf,
           decode(nf.statusnf, 'N', 'DIGITADO', 'I', 'IMPORTADO', 'C',
                   'EM CARGA', 'P', 'PROCESSADO', 'B', 'EM QUARENTENA',
                   nf.statusnf) status, nf.estoqueverificado,
           case
              when (nf.tiponf = 'P' and d.fracionarlote = 0) then
               0
              else
               1
            end aceitaLoteFracionado, d.permitiralterarqtdeseparacao,
           nf.reservalotes
      into r_sep.iddepositante, r_sep.metodoSepEspecifica, r_sep.idprenf,
           r_sep.statusnf, r_sep.statusnftexto, r_sep.estoqueverificado,
           r_sep.aceitaLoteFracionado, r_sep.permitiralterarqtdeseparacao,
           r_sep.reservalotes
      from notafiscal nf, depositante d
     where nf.idnotafiscal = p_idnotafiscal
       and d.identidade = nf.iddepositante
       for update;
  
    validarSep;
  
    validarNFparaSepEspecifica(p_idnotafiscal);
  
    quandoOrigemWMSEnterprise;
  
    validarQtde;
  
    pk_notafiscal.validarSetorFormacaoOnda(p_idlote, p_idarmazem, p_idlocal);
  
    validarLoteVinculadoTipoPedido(p_idarmazem, p_idlocal, p_idlote,
                                   p_idnotafiscal);
  
    begin
    
      insert into separacaoespecifica
        (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual,
         fonteseparacao, idusuario, dtvinculo)
      values
        (p_idarmazem, p_idlocal, p_idlote, p_idnotafiscal,
         r_lote.qtdeSolicitadaUN, p_cadManual, p_fonteSeparacao, p_idUsuario,
         sysdate);
    
    exception
      when dup_val_on_index then
        if (p_fonteSeparacao = C_SEP_ESPEC_COLETOR or
           v_vinculoSepEsp_viaIntegracao = 1) then
          update separacaoespecifica
             set qtde = qtde + r_lote.qtdeSolicitadaUN
           where idarmazem = p_idarmazem
             and idlocal = p_idlocal
             and idlote = p_idlote
             and idnotafiscal = p_idnotafiscal;
        else
          v_msg := t_message('Ocorreu um erro ao vincular o lote na separação especifica. Erro: dup_val_on_index');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
    end;
  
    marcarMetodoSepEspecifica(p_idnotafiscal, r_sep.metodoSepEspecifica);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Vinculou o lote ' || p_idlote ||
                          ' na separação especifica para o idNotafiscal ' ||
                          p_idnotafiscal, p_idnotafiscal, 'SL');
  
  end vincularSeparacaoEspecifica;

  procedure desvincularSeparacaoEspecifica
  (
    p_idarmazem            in number,
    p_idlocal              in local.idlocal%type,
    p_idlote               in number,
    p_idnotafiscal         in number,
    p_idUsuario            in number,
    p_validarOriginario    in number := 1,
    p_cancelamentoexclusao in number := 0
  ) is
    v_statusReservaEstoque number;
    v_msg                  t_message;
  
    procedure validar
    (
      p_idnotafiscal in number,
      p_idarmazem    in number,
      p_idlocal      in local.idlocal%type,
      p_idlote       in number
    ) is
      v_idprenf              number;
      v_status               varchar2(20);
      v_statusnf             notafiscal.statusnf%type;
      v_estoqueverificado    notafiscal.estoqueverificado%type;
      v_agruparinclusaolotes number;
      v_iddepositante        number;
      v_cadmanual            char(1);
      v_isPedWeb             char(1);
    
      function isPedWebF(p_idnotafiscal in number) return char is
        v_isPedWebFunc char(1);
        pragma autonomous_transaction;
      begin
        select nfi.pedidoweb
          into v_isPedWebFunc
          from notafiscal nf, nfimpressao nfi
         where nf.idnotafiscal = p_idnotafiscal
           and nfi.idprenf = nf.idprenf;
      
        return v_isPedWebFunc;
      
      end isPedWebF;
    
    begin
      select nf.idprenf, nf.statusnf,
             decode(nf.statusnf, 'N', 'DIGITADO', 'I', 'IMPORTADO', 'C',
                     'EM CARGA', 'P', 'PROCESSADO', 'B', 'EM QUARENTENA',
                     nf.statusnf) status, nf.estoqueverificado,
             nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes),
             nf.iddepositante, nf.reservalotes
        into v_idprenf, v_statusnf, v_status, v_estoqueverificado,
             v_agruparinclusaolotes, v_iddepositante, v_statusReservaEstoque
        from notafiscal nf, depositante d
       where nf.idnotafiscal = p_idnotafiscal
         and d.identidade = nf.iddepositante;
    
      if (v_agruparinclusaolotes in (1, 2)) then
        v_msg := t_message('O metodo de incluir o estoque para separação especifica não esta configurado para utilizar lote por local. Confira o cadastro do depositante.' ||
                           chr(13) || 'IDDEPOSITANTE: {0}');
        v_msg.addParam(v_iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_cancelamentoexclusao = 0) then
        v_isPedWeb := isPedWebF(p_idnotafiscal);
      
        if (v_isPedWeb = 'S') then
          v_msg := t_message('Não é permitida alteração de Lotes quando pedido for realizado pelo Pedido Online (WMS-WEB).');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if v_statusnf not in ('I', 'N') then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ {0}.' || chr(13) ||
                           'OPERAÇÃO CANCELADA.' || chr(13) ||
                           'IDPRENF: {1}' || chr(13) || 'IDNOTAFISCAL: {2}');
        v_msg.addParam(v_status);
        v_msg.addParam(v_idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_estoqueverificado = 'S' then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ LIBERADO PARA EXPEDIÇÃO.' ||
                           chr(13) ||
                           'PARA REMOVER OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                           chr(13) || 'IDPRENF: {0}' || chr(13) ||
                           'IDNOTAFISCAL: {1}');
        v_msg.addParam(v_idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      
      elsif v_estoqueverificado = 'X' then
        v_msg := t_message('O PEDIDO OU NOTA FISCAL NÃO FOI LIBERADO PARA EXPEDIÇÃO DEVIDO A CORTE NO ESTOQUE.' ||
                           chr(13) ||
                           'PARA REMOVER OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                           chr(13) || 'IDPRENF: {0}' || chr(13) ||
                           'IDNOTAFISCAL: {1}');
        v_msg.addParam(v_idprenf);
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      select s.cadmanual
        into v_cadmanual
        from separacaoespecifica s
       where s.idarmazem = p_idarmazem
         and s.idlocal = p_idlocal
         and s.idlote = p_idlote
         and s.idnotafiscal = p_idnotafiscal;
    
      if (v_cadmanual = 'N' and p_validarOriginario = 1) then
        v_msg := t_message('Não é possível desvincular lote associado originário de importação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validar;
  
  begin
    validar(p_idnotafiscal, p_idarmazem, p_idlocal, p_idlote);
  
    delete from separacaoespecifica
     where idarmazem = p_idarmazem
       and idlocal = p_idlocal
       and idlote = p_idlote
       and idnotafiscal = p_idnotafiscal;
  
    desmarcarMetodoSepEspecifica(p_idnotafiscal);
    pk_notafiscal.reabrirReservaLotes(p_idnotafiscal,
                                      v_statusReservaEstoque);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Desvinculou o lote ' || p_idlote ||
                          ' da separação especifica para o idNotafiscal ' ||
                          p_idnotafiscal, p_idnotafiscal, 'SL');
  end desvincularSeparacaoEspecifica;

  /*
   * Rotina responsavel por gerar a separacao especifica dos lotes 
   * na importacao do produto usando Lote indústria e/ou data de vencimento
  */
  procedure GerarSepEspecificaImportacao
  (
    p_idusuario     in number,
    p_barra         in varchar2,
    p_serie         in varchar2,
    p_idprenf       in number,
    p_idnfdet       in number,
    p_dval          in date,
    p_qtde          in number,
    p_idnfdetrastro in number := null
  ) is
    v_qtdedisponivel   number;
    v_fatorconversao   number;
    v_restante         number;
    v_disponivel       number;
    v_idnotafiscal     number;
    v_idUsuario        number;
    v_idProduto        number;
    v_itemPossuiRastro number;
    v_itemRastroDtVal  nfdetrastro.dval%type;
    v_itemRastroLote   nfdetrastro.nlote%type;
    v_qtde             nfdetrastro.qlote%type;
    v_idArmazem        number;
    v_situacaoLote     char(1);
    v_msg              t_message;
    v_idTipoPedido     notafiscal.idtipopedido%type;
  
    procedure calcularQtdDisponivel(p_qtdevalidar number) is
    begin
      select nvl(sum(nvl(v.disp, 0)), 0) disp
        into v_qtdedisponivel
        from v_estoque_local_ctp v,
             (select nf.estado, nf.iddepositante, nf.idnotafiscal,
                      nf.idarmazem
                 from notafiscal nf
                where nf.idprenf = p_idprenf) nf
       where 1 = 1
         and trim(v.descricaolote) =
             trim(nvl(v_itemRastroLote, v.descricaolote))
         and v.iddepositante = nf.iddepositante
         and v.estadolote = nf.estado
         and v.idarmazem = nf.idarmazem
         and v.idproduto = v_idProduto
         and v.tipo in (0, 1, 2)
         and decode(v.localativo, 'S', 1, 0) = 1
         and v.loteliberado = nvl(v_situacaoLote, v.loteliberado)
         and to_char(nvl(v.dtvenc, sysdate), 'MM/yyyy') =
             to_char(nvl(v_itemRastroDtVal, nvl(v.dtvenc, sysdate)),
                     'MM/yyyy');
    
      if (p_qtdevalidar * v_fatorconversao) > v_qtdedisponivel then
        v_restante := 0;
        v_msg      := t_message('NÃO EXISTE QUANTIDADE DISPONIVEL PARA O PRODUTO ID: {0} ' ||
                                'DA NOTA ID: {1}. QUANTIDADE DISPONÍVEL: {2} ' ||
                                'E QUANTIDADE SOLICITADA: {3}. LOTE INDUSTRIA/SERIE: {4}');
        v_msg.addParam(v_idProduto);
        v_msg.addParam(v_idnotafiscal);
        v_msg.addParam(v_qtdedisponivel);
        v_msg.addParam(p_qtde * v_fatorconversao);
        v_msg.addParam(v_itemRastroLote);
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end;
  
    procedure vinculaLotes is
      v_qtdedisp       number;
      v_qtdeJaLiberada number;
    begin
      v_qtdedisp := 0;
      for c_lote in (select v.idarmazem, v.idlote, v.idlocal,
                            nvl(v.disp, 0) disp
                       from v_estoque_sepesp v,
                            (select nf.estado, nf.iddepositante,
                                     nf.idnotafiscal, nf.idarmazem,
                                     ctp.estadomat, ctp.situacaolote
                                from notafiscal nf, classificacaotipopedido ctp
                               where nf.idprenf = p_idprenf
                                 and nf.idtipopedido = ctp.idtipopedido(+)) nf
                      where 1 = 1
                        and trim(v.descricaolote) =
                            trim(nvl(v_itemRastroLote, v.descricaolote))
                        and v.iddepositante = nf.iddepositante
                        and v.estadolote = nvl(nf.estadomat, nf.estado)
                        and v.idarmazem = nf.idarmazem
                        and v.idproduto = v_idProduto
                        and v.tipo in (0, 1, 2)
                        and decode(v.localativo, 'S', 1, 0) = 1
                        and (nvl(nf.situacaolote, 0) = 2 or
                            nvl(nf.situacaolote, 0) =
                            decode(v.loteliberado, 'S', 0, 1))
                        and to_char(nvl(v.dtvenc, sysdate), 'MM/yyyy') =
                            to_char(nvl(v_itemRastroDtVal,
                                        nvl(v.dtvenc, sysdate)), 'MM/yyyy')
                           
                        and ((nvl(v_idTipoPedido, 0) = 0) or exists
                             (select 1
                                from setorclassificacaotipopedido sctp
                               where sctp.idtipopedido = v_idTipoPedido
                                 and sctp.idsetor = v.idsetor))
                      order by v.tipo)
      loop
        begin
          select sum(se.qtde)
            into v_disponivel
            from notafiscal nf, separacaoespecifica se
           where nf.statusnf in ('N', 'I')
             and decode(nf.tipo, 'S', 1, 0) = 1
             and decode(nf.reentrega, 'N', 1, 0) = 1
             and se.idnotafiscal = nf.idnotafiscal
             and se.idarmazem = c_lote.idarmazem
             and se.idlocal = c_lote.idlocal
             and se.idlote = c_lote.idlote;
        exception
          when no_data_found then
            v_disponivel := 0;
        end;
        v_qtdedisp  := v_qtdedisp + c_lote.disp;
        c_lote.disp := c_lote.disp - nvl(v_disponivel, 0);
      
        if (c_lote.disp > 0) then
          if v_restante > 0 then
            if v_restante > c_lote.disp then
              v_restante := v_restante - c_lote.disp;
            
              pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                                 c_lote.idlocal,
                                                                 c_lote.idlote,
                                                                 v_idnotafiscal,
                                                                 c_lote.disp,
                                                                 v_idUsuario,
                                                                 C_SEP_ESPEC_ENTERPRISE);
            else
              pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                                 c_lote.idlocal,
                                                                 c_lote.idlote,
                                                                 v_idnotafiscal,
                                                                 v_restante,
                                                                 v_idUsuario,
                                                                 C_SEP_ESPEC_ENTERPRISE);
              v_restante := 0;
            end if;
          end if;
        end if;
        exit when v_restante = 0;
      end loop;
    
      v_qtdeJaLiberada := getQtdeJaLiberada(v_idnotafiscal, v_idProduto);
    
      if v_restante > 0 then
        v_msg := t_message('NÃO EXISTE QUANTIDADE DISPONIVEL PARA O PRODUTO ID: {0} ' ||
                           'DA NOTA ID: {1}. QUANTIDADE DISPONÍVEL: {2}. ' ||
                           ' QUANTIDADE SOLICITADA: {3}. LOTE INDUSTRIA/SERIE: {4}. ' ||
                           ' QUANTIDADE EM SEPARAÇÃO ESPECÍFICA: {5}.');
        v_msg.addParam(v_idProduto);
        v_msg.addParam(v_idnotafiscal);
        v_msg.addParam(v_qtdedisp - v_qtdeJaLiberada);
        v_msg.addParam(p_qtde * v_fatorconversao);
        v_msg.addParam(v_itemRastroLote);
        v_msg.addParam(v_disponivel);
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    
    end vinculaLotes;
  
    procedure vinculaLoteIndustria is
      v_metodoSepEspecifica number;
    
    begin
    
      select d.agruparinclusaolotes
        into v_metodoSepEspecifica
        from depositante d, notafiscal nf
       where nf.idprenf = p_idprenf
         and d.identidade = nf.iddepositante;
    
      if (v_metodoSepEspecifica in (1, 2)) then
      
        pk_separacaoespecifica.vincLoteIndSepEspecifica(p_idusuario,
                                                        p_idnfdet,
                                                        v_itemRastroLote,
                                                        v_qtde,
                                                        v_itemRastroDtVal);
      
      else
      
        vinculaLotes;
      
      end if;
    
    end vinculaLoteIndustria;
  
  begin
    if (p_idusuario is null) then
      begin
        select c.idusuariointegracao
          into v_idusuario
          from configuracao c
         where c.ativo = 'S'
           and c.idusuariointegracao is not null;
      exception
        when no_data_found then
          v_msg := t_message('Usuário de integração padrão não preenchido nas configurações gerais do sistema.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    else
      v_idUsuario := p_idusuario;
    end if;
  
    begin
      select e.fatorconversao, e.idproduto
        into v_fatorconversao, v_idProduto
        from embalagem e
       where e.barra = p_barra;
    exception
      when no_data_found then
        v_msg := t_message('PRODUTO COM BARRA : {0}' || ' NAO ENCONTRADO.' ||
                           chr(13) || 'OPERAÇÃO CANCELADA.');
        v_msg.addParam(p_barra);
        raise_application_error(-20100, v_msg.formatMessage);
    end;
  
    select nf.idarmazem, nf.idtipopedido
      into v_idArmazem, v_idTipoPedido
      from notafiscal nf, nfdet nd
     where nd.nf = nf.idnotafiscal
       and nd.idnfdet = p_idnfdet;
  
    pk_locks.executeLock(v_idArmazem, 1);
  
    v_situacaoLote := pk_lote.getLoteLiberado(p_idnfdet, null);
  
    v_itemPossuiRastro := 0;
  
    select count(nfm.idnfdet)
      into v_itemPossuiRastro
      from nfdetrastro nfm
     where nfm.idnfdet = p_idnfdet;
  
    begin
      select nf.idnotafiscal
        into v_idnotafiscal
        from notafiscal nf
       where nf.idprenf = p_idprenf;
    exception
      when no_data_found then
        v_idnotafiscal := null;
    end;
  
    if v_itemPossuiRastro > 0 then
      for c_rastroItem in (select nfm.dval, nfm.nlote, nfm.qlote
                             from nfdetrastro nfm
                            where nfm.id = p_idnfdetrastro)
      loop
        v_itemRastroDtVal := c_rastroItem.Dval;
        v_itemRastroLote  := c_rastroItem.Nlote;
        calcularQtdDisponivel(c_rastroItem.qlote);
      end loop;
    
    else
      v_itemRastroDtVal := p_dval;
      v_itemRastroLote  := p_serie;
      calcularQtdDisponivel(p_qtde);
    end if;
  
    v_restante := (p_qtde * v_fatorconversao);
  
    if v_itemPossuiRastro > 0 then
      for c_rastroItem in (select nfm.dval, nfm.nlote, nfm.qlote
                             from nfdetrastro nfm
                            where nfm.id = p_idnfdetrastro)
      loop
        v_itemRastroDtVal := c_rastroItem.Dval;
        v_itemRastroLote  := c_rastroItem.Nlote;
        v_qtde            := c_rastroItem.Qlote;
      
        vinculaLoteIndustria;
      end loop;
    
    else
      v_itemRastroDtVal := p_dval;
      v_itemRastroLote  := p_serie;
      v_qtde            := v_restante;
    
      vinculaLoteIndustria;
    end if;
  
  end GerarSepEspecificaImportacao;

  /*
   * Rotina responsavel por gerar a separacao especifica dos lotes 
   * na importacao do produto . é enviado o id do lote
  */
  procedure GerarSepEspecificaImpIDLote(p_prenfdet in t_prenfdet) is
    v_qtdedisponivel number;
    v_fatorconversao number;
    v_restante       number;
    v_QtdeUtilizada  number;
    v_idnotafiscal   number;
    v_idUsuario      number;
    v_msg            t_message;
  begin
    if (p_prenfdet.idusuario is null) then
      begin
        select c.idusuariointegracao
          into v_idusuario
          from configuracao c
         where c.ativo = 'S'
           and c.idusuariointegracao is not null;
      exception
        when no_data_found then
          v_msg := t_message('Usuário de integração padrão não preenchido nas configurações gerais do sistema.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    else
      v_idUsuario := p_prenfdet.idusuario;
    end if;
  
    begin
      select e.fatorconversao
        into v_fatorconversao
        from embalagem e, lote lt
       where 1 = 1
         and lt.idproduto = e.idproduto
         and lt.barra = e.barra
         and lt.idlote = p_prenfdet.serie
         and e.barra = p_prenfdet.barra;
    exception
      when others then
        v_msg := t_message('LOTE COM BARRA: {0} E ID DE LOTE {1}' ||
                           ' NAO ENCONTRADO.' || chr(13) ||
                           'OPERAÇÃO CANCELADA.');
        v_msg.addParam(p_prenfdet.BARRA);
        v_msg.addParam(p_prenfdet.serie);
        raise_application_error(-20200, v_msg.formatMessage);
    end;
  
    begin
      select nvl(sum(nvl(v.disp, 0)), 0) disp
        into v_qtdedisponivel
        from v_estoque_local v,
             (select nf.estado, nf.iddepositante, nf.idnotafiscal,
                      nf.idarmazem
                 from notafiscal nf
                where nf.idprenf = p_prenfdet.idprenf) nf
       where 1 = 1
         and v.idlote = p_prenfdet.serie
         and v.iddepositante = nf.iddepositante
         and v.estadolote = nf.estado
         and v.idarmazem = nf.idarmazem
         and v.tipo in (0, 1, 2)
         and decode(v.localativo, 'S', 1, 0) = 1
         and decode(v.loteliberado, 'S', 1, 0) = 1;
    exception
      when others then
        v_qtdedisponivel := 0;
    end;
  
    begin
      select nf.idnotafiscal
        into v_idnotafiscal
        from notafiscal nf
       where nf.idprenf = p_prenfdet.idprenf;
    exception
      when no_data_found then
        v_idnotafiscal := null;
    end;
  
    if v_qtdedisponivel is null then
      v_qtdedisponivel := 0;
    end if;
  
    if (p_prenfdet.qtde * v_fatorconversao) > v_qtdedisponivel then
      v_restante := 0;
    else
      v_restante := (p_prenfdet.qtde * v_fatorconversao);
    
      for c_lote in (select v.idarmazem, v.idlote, v.idlocal, v.disp
                       from v_estoque_sepesp v,
                            (select nf.estado, nf.iddepositante,
                                     nf.idnotafiscal, nf.idarmazem,
                                     ctp.estadomat, ctp.situacaolote
                                from notafiscal nf, classificacaotipopedido ctp
                               where nf.idprenf = p_prenfdet.idprenf
                                 and nf.idtipopedido = ctp.idtipopedido(+)) nf
                      where 1 = 1
                        and v.idlote = p_prenfdet.serie
                        and v.iddepositante = nf.iddepositante
                        and v.estadolote = nvl(nf.estadomat, nf.estado)
                        and v.idarmazem = nf.idarmazem
                        and v.tipo in (0, 1, 2)
                        and decode(v.localativo, 'S', 1, 0) = 1
                        and (nvl(nf.situacaolote, 0) = 2 or
                            nvl(nf.situacaolote, 0) =
                            decode(v.loteliberado, 'S', 0, 1)))
      loop
        begin
          select nvl(sum(se.qtde), 0)
            into v_QtdeUtilizada
            from notafiscal nf, separacaoespecifica se
           where nf.statusnf in ('N', 'I')
             and decode(nf.tipo, 'S', 1, 0) = 1
             and decode(nf.reentrega, 'N', 1, 0) = 1
             and se.idnotafiscal = nf.idnotafiscal
             and se.idarmazem = c_lote.idarmazem
             and se.idlocal = c_lote.idlocal
             and se.idlote = c_lote.idlote;
        exception
          when no_data_found then
            v_QtdeUtilizada := 0;
        end;
        c_lote.disp := c_lote.disp - v_QtdeUtilizada;
      
        if (c_lote.disp > 0) then
          if v_restante > 0 then
            if v_restante > c_lote.disp then
              v_restante := v_restante - c_lote.disp;
              pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                                 c_lote.idlocal,
                                                                 c_lote.idlote,
                                                                 v_idnotafiscal,
                                                                 c_lote.disp,
                                                                 v_idUsuario,
                                                                 C_SEP_ESPEC_ENTERPRISE);
            else
              pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                                 c_lote.idlocal,
                                                                 c_lote.idlote,
                                                                 v_idnotafiscal,
                                                                 v_restante,
                                                                 v_idUsuario,
                                                                 C_SEP_ESPEC_ENTERPRISE);
              v_restante := 0;
            end if;
          end if;
        
        else
          v_msg := t_message('QUANTIDADE INDISPONÍVEL PARA ATENDER O PEDIDO.');
          raise_application_error(-20100, v_msg.formatMessage);
        
        end if;
        exit when v_restante = 0;
      end loop;
      if v_restante > 0 then
        v_msg := t_message('ERRO AO VERIFICAR QTDE NOS LOTES.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end if;
  end GerarSepEspecificaImpIDLote;

  procedure vincLoteIndSepEspecifica
  (
    p_idusuario      in number,
    p_idnfdet        in number,
    p_loteindustria  in varchar2,
    p_qtde           in out number,
    p_dataVencimento in date := null,
    p_idnfcobertura  in coberturalotedispnf.idnotafiscalcobertura%type := null,
    p_idLote         in number := null,
    p_fonteSeparacao in number := C_SEP_ESPEC_ENTERPRISE
  ) is
    type t_item is record(
      idnotafiscal         notafiscal.idnotafiscal%type,
      fatorconversao       number,
      idarmazem            number,
      idproduto            number,
      descreduzida         embalagem.descrreduzido%type,
      qtdenfdet            number,
      fracionado           produto.fracionado%type,
      agruparinclusaolotes number,
      iddepositante        number,
      estado               notafiscal.estado%type);
  
    r_item         t_item;
    v_idsep        number;
    v_liberado     char(1);
    v_idTipoPedido number;
    v_isPedWeb     char(1) := 'N';
    v_idArmazem    number;
    v_idLote       number := null;
  
    v_msg t_message;
  
    function getPercentualTolerancia(p_idNotaFiscal in number) return number is
      v_tipoNf             char(1);
      v_percTolerancia     number;
      v_permAlterarQtdeSep number;
    begin
    
      select n.tiponf, d.percentualtolerancia,
             d.permitiralterarqtdeseparacao
        into v_tiponf, v_percTolerancia, v_permAlterarQtdeSep
        from notafiscal n, depositante d
       where n.iddepositante = d.identidade
         and n.idnotafiscal = p_idNotaFiscal;
    
      if v_tiponf = 'P' then
        if v_permAlterarQtdeSep = 1 then
          return v_percTolerancia;
        else
          return 0;
        end if;
      else
        return 0;
      end if;
    
    end;
  
    procedure validarQtdeAssociada is
      v_qtdeJaAssociada number;
      v_qtdenoestoque   number;
      v_qtdeAssocNFdet  number;
      v_qtdedisponivel  number;
      v_qtdecobertura   number;
    begin
      if (p_qtde <= 0) then
        v_msg := t_message('A quantidade informada deve ser maior que zero.' ||
                           chr(13) || 'QTDE: {0}');
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (mod(p_qtde, 1) <> 0 and r_item.fracionado = 'N') then
        v_msg := t_message('A quantidade informada deve ser um numero inteiro.' ||
                           chr(13) || 'QTDE: {0}');
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.fatorconversao > 1 and mod(p_qtde, 1) <> 0) then
        v_msg := t_message('O fator de conversão da embalagem é mairo que 1. Não é permitido informar quantidade fracionada.' ||
                           chr(13) || 'QTDE: {0}' || chr(13) ||
                           'FATORCONVERSAO: {1}');
        v_msg.addParam(p_qtde);
        v_msg.addParam(r_item.fatorconversao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select nvl(sum(s.qtde), 0)
        into v_qtdeJaAssociada
        from separacaoespecifica s, lote lt, notafiscal nf
       where lt.idlote = s.idlote
         and lt.descr = p_loteindustria
         and s.idarmazem = r_item.idarmazem
         and lt.idproduto = r_item.idproduto
         and lt.iddepositante = r_item.iddepositante
         and nf.idnotafiscal = s.idnotafiscal
         and nf.statusnf not in ('X', 'P')
         and lt.estado = r_item.estado
         and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
             to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                     'MM/yyyy')
         and not exists
       (select 1
                from nfromaneio nfr
               where nfr.idnotafiscal = s.idnotafiscal);
    
      select sum(ll.estoque - ll.pendencia + ll.adicionar)
        into v_qtdenoestoque
        from lotelocal ll, lote lt, local lo, setor s, produto p,
             produtodepositante pd
       where lt.idlote = ll.idlote
         and ll.idarmazem = r_item.idarmazem
         and lt.iddepositante = r_item.iddepositante
         and lt.descr = p_loteindustria
         and lt.idproduto = r_item.idproduto
         and lt.tipolote = 'L'
         and lt.liberado = nvl(v_liberado, lt.liberado)
         and lo.ativo = 'S'
         and lt.idlotemont is null
         and lo.id = ll.idendereco
         and lo.idregiao is not null
         and s.idsetor = lo.idsetor
         and s.expedicao = 'S'
         and lt.estado = r_item.estado
         and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
             to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                     'MM/yyyy')
         and p.idproduto = lt.idproduto
         and pd.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante
         and (pd.controlartempodematuracao = 0 or
             (pd.controlartempodematuracao = 1 and
             trunc(sysdate) >=
             trunc(lt.dtfabricacao + p.tempoparamaturacaoemdias)))
         and ((nvl(v_idTipoPedido, 0) = 0) or exists
              (select 1
                 from setorclassificacaotipopedido sctp
                where sctp.idtipopedido = v_idTipoPedido
                  and sctp.idsetor = lo.idsetor));
    
      v_qtdedisponivel := v_qtdenoestoque - v_qtdeJaAssociada;
    
      if ((p_qtde * r_item.fatorconversao) > v_qtdedisponivel) then
        v_msg := t_message('A quantidade disponível de estoque para o lote indústria' ||
                           ' {0}, depositante id: {1}, produto id:' ||
                           ' {2} é de somente {3} {4} e a nota fiscal está solicitanto {5} {6}.' ||
                           ' Informe uma quantidade menor ou igual ao disponível.');
        v_msg.addParam(p_loteindustria);
        v_msg.addParam(r_item.iddepositante);
        v_msg.addParam(r_item.idproduto);
        v_msg.addParam(trunc((v_qtdedisponivel / r_item.fatorconversao), 2));
        v_msg.addParam(r_item.descreduzida);
        v_msg.addParam(trunc((p_qtde * r_item.fatorconversao), 2));
        v_msg.addParam(r_item.descreduzida);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select sum(case
                    when dispEst < dispCob then
                     dispEst
                    else
                     dispCob
                  end)
        into v_qtdecobertura
        from (select lt.idlote,
                      sum(ll.estoque - ll.pendencia + ll.adicionar) dispEst,
                      (lt.qtdedisponivel - sum(ll.pendencia - ll.adicionar)) dispCob
                 from lotelocal ll, lote lt, local lo, setor s, produto p,
                      produtodepositante pd
                where lt.idlote = ll.idlote
                  and ll.idarmazem = r_item.idarmazem
                  and lt.iddepositante = r_item.iddepositante
                  and lt.descr = p_loteindustria
                  and lt.idproduto = r_item.idproduto
                  and lt.tipolote = 'L'
                  and lt.liberado = nvl(v_liberado, lt.liberado)
                  and lo.ativo = 'S'
                  and lt.idlotemont is null
                  and lo.id = ll.idendereco
                  and lo.idregiao is not null
                  and s.idsetor = lo.idsetor
                  and s.expedicao = 'S'
                  and lt.estado = r_item.estado
                  and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                      to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                              'MM/yyyy')
                  and p.idproduto = lt.idproduto
                  and pd.idproduto = lt.idproduto
                  and pd.identidade = lt.iddepositante
                  and (pd.controlartempodematuracao = 0 or
                      (pd.controlartempodematuracao = 1 and
                      trunc(sysdate) >=
                      trunc(lt.dtfabricacao + p.tempoparamaturacaoemdias)))
                  and ((nvl(v_idTipoPedido, 0) = 0) or exists
                       (select 1
                          from setorclassificacaotipopedido sctp
                         where sctp.idtipopedido = v_idTipoPedido
                           and sctp.idsetor = lo.idsetor))
                group by lt.idlote, lt.qtdedisponivel);
    
      v_qtdedisponivel := v_qtdecobertura - v_qtdeJaAssociada;
    
      if ((p_qtde * r_item.fatorconversao) > v_qtdedisponivel) then
        v_msg := t_message('A quantidade de estoque coberto disponível para o lote indústria ' ||
                           '{0}, depositante id: {1}, produto id:' ||
                           ' {2} é de somente {3} {4}.' ||
                           ' Informe uma quantidade menor ou igual ao disponível.');
        v_msg.addParam(p_loteindustria);
        v_msg.addParam(r_item.iddepositante);
        v_msg.addParam(r_item.idproduto);
        v_msg.addParam(trunc((v_qtdedisponivel / r_item.fatorconversao), 2));
        v_msg.addParam(r_item.descreduzida);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select nvl(sum(qtde), 0)
        into v_qtdeAssocNFdet
        from sepespporloteindustria
       where idnfdet = p_idnfdet;
    
      if (p_qtde > r_item.qtdenfdet) then
        v_msg := t_message('A quantidade associada é maior do que a quantidade do item selecionado.' ||
                           chr(13) || 'QTDE EM NOTA FISCAL: {0}' || chr(13) ||
                           'QTDE ASSOCIADA: {1}');
        v_msg.addParam(r_item.qtdenfdet);
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_qtde > r_item.qtdenfdet - v_qtdeAssocNFdet) then
        v_msg := t_message('A quantidade associada é maior do que a quantidade disponível do item selecionado.' ||
                           chr(13) || 'QTDE DISPONÍVEL EM NOTA FISCAL: {0}' ||
                           chr(13) || 'QTDE ASSOCIADA: {1}');
        v_msg.addParam(r_item.qtdenfdet - v_qtdeAssocNFdet);
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarQtdeAssociada;
  
    procedure validarQtdeAssociadaNaoFrac is
      v_qtdeJaAssociada  number;
      v_qtdecobertura    number;
      v_qtdeavincular    number;
      v_qtdenolote       number;
      v_qtdeSolCalc      number;
      v_margemtolerancia number;
    
      procedure validarQuantidadePedidoWeb
      (
        p_idNfDet      number,
        p_qtde         number,
        p_qtdavincular number
      ) is
        isPedidoWeb Nfimpressao.Pedidoweb%type;
      
      begin
        select nvl(ni.pedidoweb, 'N')
          into v_isPedWeb
          from nfimpressao ni, nfdetimpressao ndi
         where ni.idprenf = ndi.idprenf
           and ndi.idnfdet = p_idNfDet;
      
        if (v_isPedWeb = 'S' and p_qtde <> p_qtdavincular) then
          v_msg := t_message('Quando for Pedido Web, a quantidade do item não pode ser maior que o disponível em estoque.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end validarQuantidadePedidoWeb;
    
    begin
      if (p_qtde <= 0) then
        v_msg := t_message('A quantidade informada deve ser maior que zero.' ||
                           chr(13) || 'QTDE: {0}');
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (mod(p_qtde, 1) <> 0 and r_item.fracionado = 'N') then
        v_msg := t_message('A quantidade informada deve ser um numero inteiro.' ||
                           chr(13) || 'QTDE: {0}');
        v_msg.addParam(p_qtde);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.fatorconversao > 1 and mod(p_qtde, 1) <> 0) then
        v_msg := t_message('O fator de conversão da embalagem é mairo que 1. Não é permitido informar quantidade fracionada.' ||
                           chr(13) || 'QTDE: {0}' || chr(13) ||
                           'FATORCONVERSAO: {1}');
        v_msg.addParam(p_qtde);
        v_msg.addParam(r_item.fatorconversao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select nvl(sum(s.qtde), 0)
        into v_qtdeJaAssociada
        from separacaoespecifica s, lote lt
       where lt.idlote = s.idlote
         and s.idarmazem = r_item.idarmazem
         and lt.idproduto = r_item.idproduto
         and lt.iddepositante = r_item.iddepositante
         and s.idnotafiscal = (select nf.idnotafiscal
                                 from notafiscal nf, nfdet nfd
                                where nf.idnotafiscal = nfd.nf
                                  and nfd.idnfdet = p_idnfdet
                                  and rownum = 1)
         and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
             to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                     'MM/yyyy')
         and not exists
       (select 1
                from nfromaneio nfr
               where nfr.idnotafiscal = s.idnotafiscal);
    
      select sum(ll.estoque - ll.pendencia + ll.adicionar) -
              nvl(sum(se.qtdesepespec), 0)
        into v_qtdenolote
        from lotelocal ll, lote lt, local lo, setor s, produto p,
             produtodepositante pd,
             (select x.idlote, x.idarmazem, x.qtde qtdesepespec
                 from separacaoespecifica x) se
       where lt.idlote = ll.idlote
         and ll.idarmazem = r_item.idarmazem
         and lt.iddepositante = r_item.iddepositante
         and lt.descr = p_loteindustria
         and lt.idproduto = r_item.idproduto
         and lt.tipolote = 'L'
         and lt.liberado = 'S'
         and lo.ativo = 'S'
         and lt.idlotemont is null
         and lo.id = ll.idendereco
         and lo.idregiao is not null
         and s.idsetor = lo.idsetor
         and s.expedicao = 'S'
         and lt.idlote = se.idlote(+)
         and lt.idarmazem = se.idarmazem(+)
         and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
             to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                     'MM/yyyy')
         and p.idproduto = lt.idproduto
         and pd.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante
         and (pd.controlartempodematuracao = 0 or
             (pd.controlartempodematuracao = 1 and
             trunc(sysdate) >=
             trunc(lt.dtfabricacao + p.tempoparamaturacaoemdias)));
    
      v_qtdeSolCalc := p_qtde - v_qtdeJaAssociada;
    
      if (v_qtdeSolCalc >= v_qtdenolote)
         and (v_qtdenolote > 0) then
        v_qtdeavincular := v_qtdenolote;
      else
        if v_qtdenolote = 0 then
          v_msg := t_message('Estoque não disponível para o lote indústria {0}.' ||
                             chr(13) || 'Quantidade solicitada: {1}' ||
                             chr(13) ||
                             'Quantidade disponível para utilização: {2}');
          v_msg.addParam(p_loteindustria);
          v_msg.addParam(v_qtdeSolCalc);
          v_msg.addParam(v_qtdenolote);
          raise_application_error(-20000, v_msg.formatMessage);
        elsif v_qtdeSolCalc <= 0 then
          v_msg := t_message('A quantidade a associar é maior do que a quantidade disponível do item selecionado.');
          raise_application_error(-20000, v_msg.formatMessage);
        else
          v_margemtolerancia := trunc((p_qtde / 100) *
                                      getPercentualTolerancia(r_item.idnotafiscal) +
                                      p_qtde);
        
          if v_qtdenolote <=
             (v_qtdeSolCalc + (v_margemtolerancia - p_qtde)) then
            v_qtdeavincular := v_qtdenolote;
          else
            v_msg := t_message('Não é possível fracionar o lote indústria {0}' ||
                               ' devido à configuração do Depositante.' ||
                               chr(13) ||
                               'Quantidade pendente para o item: {1}' ||
                               chr(13) ||
                               'Quantidade limite a associar: {2}' ||
                               chr(13) || 'Quantidade disponível: {3}');
            v_msg.addParam(p_loteindustria);
            v_msg.addParam(v_qtdeSolCalc);
            v_msg.addParam(v_qtdeSolCalc + (v_margemtolerancia - p_qtde));
            v_msg.addParam(v_qtdenolote);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end if;
    
      select sum(case
                    when dispEst < dispCob then
                     dispEst
                    else
                     dispCob
                  end)
        into v_qtdecobertura
        from (select lt.idlote,
                      sum(ll.estoque - ll.pendencia + ll.adicionar) dispEst,
                      (lt.qtdedisponivel - sum(ll.pendencia - ll.adicionar)) dispCob
                 from lotelocal ll, lote lt, local lo, setor s, produto p,
                      produtodepositante pd
                where lt.idlote = ll.idlote
                  and ll.idarmazem = r_item.idarmazem
                  and lt.iddepositante = r_item.iddepositante
                  and lt.descr = p_loteindustria
                  and lt.idproduto = r_item.idproduto
                  and lt.tipolote = 'L'
                  and lt.liberado = 'S'
                  and lo.ativo = 'S'
                  and lt.idlotemont is null
                  and lo.id = ll.idendereco
                  and lo.idregiao is not null
                  and s.idsetor = lo.idsetor
                  and s.expedicao = 'S'
                  and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                      to_char(nvl(p_dataVencimento, nvl(lt.dtvenc, sysdate)),
                              'MM/yyyy')
                  and p.idproduto = lt.idproduto
                  and pd.idproduto = lt.idproduto
                  and pd.identidade = lt.iddepositante
                  and (pd.controlartempodematuracao = 0 or
                      (pd.controlartempodematuracao = 1 and
                      trunc(sysdate) >=
                      trunc(lt.dtfabricacao + p.tempoparamaturacaoemdias)))
                group by lt.idlote, lt.qtdedisponivel);
    
      if ((v_qtdeavincular * r_item.fatorconversao) > v_qtdecobertura) then
        v_msg := t_message('A quantidade de estoque coberto disponível para o lote indústria ' ||
                           '{0}, depositante id: {1}, produto id: ' ||
                           '{2} é de somente {3} {4}.' ||
                           ' Informe uma quantidade menor ou igual ao disponível.');
        v_msg.addParam(p_loteindustria);
        v_msg.addParam(r_item.iddepositante);
        v_msg.addParam(r_item.idproduto);
        v_msg.addParam(trunc((v_qtdecobertura / r_item.fatorconversao), 2));
        v_msg.addParam(r_item.descreduzida);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      validarQuantidadePedidoWeb(p_idNfDet, p_qtde, v_qtdeavincular);
      p_qtde := v_qtdeavincular;
    
    end validarQtdeAssociadaNaoFrac;
  
    procedure inserirSepEspecificaPorLtInd is
    begin
      select seq_sepespporloteindustria.nextval
        into v_idsep
        from dual;
    
      insert into sepespporloteindustria
        (idsepespporloteindustria, idnfdet, loteindustria, qtde, idusuario,
         data, idnfcobertura)
      values
        (v_idsep, p_idnfdet, p_loteindustria, p_qtde, p_idusuario, sysdate,
         p_idnfcobertura);
    end inserirSepEspecificaPorLtInd;
  
    procedure reservarLotes(p_liberado char) is
      cursor c_buscaPorSaldoEmLocal
      (
        p_idArmazem    in number,
        p_idDep        in number,
        p_ltInd        in varchar2,
        p_idPrd        in number,
        p_ltLib        in varchar2,
        p_estadoLt     in varchar2,
        p_dtVenc       in date,
        p_idTipoPedido in number,
        p_idLote       in number := null
      ) is
        select b.idarmazem, b.idlocal, b.disponivel, b.tipoLocal
          from (select a.idarmazem, a.idlocal,
                        ((case
                           when a.estDisp < a.cobDisp then
                            a.estDisp
                           else
                            a.cobDisp
                         end) - a.sepEspAssoc) disponivel, a.ordem,
                        a.tipoLocal
                   from (select ll.idarmazem, ll.idlocal, lo.ordem,
                                 lo.tipo tipoLocal,
                                 sum((ll.estoque - ll.pendencia + ll.adicionar)) estDisp,
                                 sum((select nvl(sum(s.qtde), 0)
                                        from separacaoespecifica s
                                       where s.idarmazem = ll.idarmazem
                                         and s.idlote = ll.idlote
                                         and s.idlocal = ll.idlocal
                                         and not exists
                                       (select 1
                                                from nfromaneio nfr
                                               where nfr.idnotafiscal =
                                                     s.idnotafiscal))) sepEspAssoc,
                                 sum(pk_lote.RetornarQtdeDisponivel(lt.idlote)) cobDisp
                            from lotelocal ll, lote lt, local lo, setor s,
                                 produto p, produtodepositante pd
                           where lt.idlote = ll.idlote
                             and ll.idarmazem = p_idArmazem
                             and lt.iddepositante = p_idDep
                             and lt.descr = p_ltInd
                             and lt.idproduto = p_idPrd
                             and lt.tipolote = 'L'
                             and lt.liberado = nvl(p_ltLib, lt.liberado)
                             and lt.estado = p_estadoLt
                             and lo.ativo = 'S'
                             and lt.idlotemont is null
                             and lo.id = ll.idendereco
                             and lo.idregiao is not null
                             and s.idsetor = lo.idsetor
                             and lt.idlote = nvl(p_idLote, lt.idlote)
                             and s.expedicao = 'S'
                             and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                                 to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                         'MM/yyyy')
                             and p.idproduto = lt.idproduto
                             and pd.idproduto = lt.idproduto
                             and pd.identidade = lt.iddepositante
                             and (pd.controlartempodematuracao = 0 or
                                 (pd.controlartempodematuracao = 1 and
                                 trunc(sysdate) >=
                                 trunc(lt.dtfabricacao +
                                         p.tempoparamaturacaoemdias)))
                             and ll.estoque - ll.pendencia + ll.adicionar > 0
                             and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                  (select 1
                                     from setorclassificacaotipopedido sctp
                                    where sctp.idtipopedido = p_idTipoPedido
                                      and sctp.idsetor = lo.idsetor))
                           group by ll.idarmazem, ll.idlocal, lo.ordem, lo.tipo) a) b
         where b.disponivel > 0
         order by b.tipoLocal, b.disponivel, b.ordem;
    
      cursor c_buscaLotesLocalSelecionado
      (
        p_idLocalSelecionado varchar2,
        p_idArmazem          in number,
        p_idDep              in number,
        p_ltInd              in varchar2,
        p_idPrd              in number,
        p_ltLib              in varchar2,
        p_estadoLt           in varchar2,
        p_dtVenc             in date,
        p_idTipoPedido       in number,
        p_idLote             in number := null
      ) is
        select b.idarmazem, b.idlocal, b.idlote, b.disponivel
          from (select a.idarmazem, a.idlocal, a.idlote,
                        ((case
                           when a.estDisp < a.cobDisp then
                            a.estDisp
                           else
                            a.cobDisp
                         end) - a.sepEspAssoc) disponivel, a.dtvencimento,
                        a.dtentrada
                   from (select ll.idarmazem, ll.idlocal, ll.idlote,
                                 (ll.estoque - ll.pendencia + ll.adicionar) estDisp,
                                 (select nvl(sum(s.qtde), 0)
                                     from separacaoespecifica s
                                    where s.idarmazem = ll.idarmazem
                                      and s.idlote = ll.idlote
                                      and s.idlocal = ll.idlocal
                                      and not exists
                                    (select 1
                                             from nfromaneio nfr
                                            where nfr.idnotafiscal =
                                                  s.idnotafiscal)) sepEspAssoc,
                                 pk_lote.RetornarQtdeDisponivel(lt.idlote) cobDisp,
                                 nvl(lt.dtvenc, sysdate) dtvencimento,
                                 lt.dtentrada, lt.idproduto, lt.descr ltind
                            from lotelocal ll, lote lt, local lo, produto p,
                                 produtodepositante pd
                           where ll.idlocal = p_idLocalSelecionado
                             and lt.idlote = ll.idlote
                             and lo.idlocal = ll.idlocal
                             and lo.idarmazem = ll.idarmazem
                             and ll.idarmazem = p_idArmazem
                             and lt.iddepositante = p_idDep
                             and lt.descr = p_ltInd
                             and lt.idproduto = p_idPrd
                             and lt.idlote = nvl(p_idLote, lt.idlote)
                             and lt.tipolote = 'L'
                             and lt.liberado = nvl(p_ltLib, lt.liberado)
                             and lt.estado = p_estadoLt
                             and lt.idlotemont is null
                             and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                  (select 1
                                     from setorclassificacaotipopedido sctp
                                    where sctp.idtipopedido = p_idTipoPedido
                                      and sctp.idsetor = lo.idsetor))
                             and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                                 to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                         'MM/yyyy')
                             and p.idproduto = lt.idproduto
                             and pd.idproduto = lt.idproduto
                             and pd.identidade = lt.iddepositante
                             and (pd.controlartempodematuracao = 0 or
                                 (pd.controlartempodematuracao = 1 and
                                 trunc(sysdate) >=
                                 trunc(lt.dtfabricacao +
                                         p.tempoparamaturacaoemdias)))
                             and ll.estoque - ll.pendencia + ll.adicionar > 0) a) b
         where b.disponivel > 0
         order by b.dtvencimento, b.dtentrada, b.idlote, b.disponivel;
    
      r_buscaPorSaldoEmLocal       c_buscaPorSaldoEmLocal%rowtype;
      r_buscaLotesLocalSelecionado c_buscaLotesLocalSelecionado%rowtype;
      r_sep                        separacaoespecifica%rowtype;
      v_qtdePriorizar              number;
      v_idsepespecifica            number;
      v_qtde                       number;
      v_Seploteindsepespecif       number;
    begin
      v_qtdePriorizar := p_qtde * r_item.fatorconversao;
    
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
      while (v_qtdePriorizar > 0)
      loop
        if (not c_buscaPorSaldoEmLocal%isopen) then
          open c_buscaPorSaldoEmLocal(r_item.idarmazem,
                                      r_item.iddepositante, p_loteindustria,
                                      r_item.idproduto, p_liberado,
                                      r_item.estado, p_dataVencimento,
                                      v_idTipoPedido, v_idLote);
        end if;
      
        if (c_buscaPorSaldoEmLocal%Notfound) then
          v_msg := t_message('A quantidade associada é maior do que a quantidade disponivel no estoque.' ||
                             chr(13) || 'IDPRODUTO: {0}' || chr(13) ||
                             'LOTEINDUSTRIA: {1}' || chr(13) || 'QTDE: {2}');
          v_msg.addParam(r_item.idproduto);
          v_msg.addParam(p_loteindustria);
          v_msg.addParam(p_qtde);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        fetch c_buscaPorSaldoEmLocal
          into r_buscaPorSaldoEmLocal;
      
        for r_buscaLotesLocalSelecionado in c_buscaLotesLocalSelecionado(r_buscaPorSaldoEmLocal.Idlocal,
                                                                         r_item.idarmazem,
                                                                         r_item.iddepositante,
                                                                         p_loteindustria,
                                                                         r_item.idproduto,
                                                                         p_liberado,
                                                                         r_item.estado,
                                                                         p_dataVencimento,
                                                                         v_idTipoPedido,
                                                                         v_idLote)
        loop
          r_sep.idarmazem := r_buscaLotesLocalSelecionado.Idarmazem;
          r_sep.idlocal   := r_buscaLotesLocalSelecionado.Idlocal;
          r_sep.idlote    := r_buscaLotesLocalSelecionado.Idlote;
          r_sep.qtde      := r_buscaLotesLocalSelecionado.Disponivel;
        
          if (r_sep.qtde > v_qtdePriorizar) then
            r_sep.qtde := v_qtdePriorizar;
          end if;
        
          v_qtdePriorizar := v_qtdePriorizar - r_sep.qtde;
        
          r_sep.idnotafiscal := r_item.idnotafiscal;
        
          if (v_isPedWeb = 'S') then
            r_sep.cadmanual := 'N';
          else
            r_sep.cadmanual := 'S';
          end if;
        
          begin
          
            pk_notafiscal.validarSetorFormacaoOnda(r_sep.idlote,
                                                   r_sep.idarmazem,
                                                   r_sep.idlocal);
          
            insert into separacaoespecifica
              (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual,
               fonteseparacao, idUsuario, dtVinculo)
            values
              (r_sep.idarmazem, r_sep.idlocal, r_sep.idlote,
               r_sep.idnotafiscal, r_sep.qtde, r_sep.cadmanual, 0,
               p_idUsuario, sysdate)
            returning id into v_idsepespecifica;
          
            insert into seploteindsepespecif
              (idsepespecifica, idseploteind, idlote, qtde)
            values
              (v_idsepespecifica, v_idsep, r_sep.idlote, r_sep.qtde);
          exception
            when dup_val_on_index then
              update separacaoespecifica s
                 set s.qtde = s.qtde + r_sep.qtde
               where s.idarmazem = r_sep.idarmazem
                 and s.idlocal = r_sep.idlocal
                 and s.idlote = r_sep.idlote
                 and s.idnotafiscal = r_sep.idnotafiscal
              returning s.id, s.qtde into v_idsepespecifica, v_qtde;
            
              select count(1)
                into v_Seploteindsepespecif
                from seploteindsepespecif s
               where s.idsepespecifica = v_idsepespecifica
                 and s.idlote = r_sep.idlote
                 and s.idseploteind = v_idsep;
            
              if (v_Seploteindsepespecif = 1) then
                update seploteindsepespecif ss
                   set ss.qtde = ss.qtde + r_sep.qtde
                 where ss.idsepespecifica = v_idsepespecifica
                   and ss.idlote = r_sep.idlote
                   and ss.idseploteind = v_idsep;
              else
                select count(1)
                  into v_Seploteindsepespecif
                  from seploteindsepespecif s
                 where s.idsepespecifica = v_idsepespecifica
                   and s.idlote = r_sep.idlote;
              
                if (v_Seploteindsepespecif >= 1) then
                  insert into seploteindsepespecif
                    (idsepespecifica, idseploteind, idlote, qtde)
                  values
                    (v_idsepespecifica, v_idsep, r_sep.idlote, r_sep.qtde);
                else
                  insert into seploteindsepespecif
                    (idsepespecifica, idseploteind, idlote, qtde)
                  values
                    (v_idsepespecifica, v_idsep, r_sep.idlote, v_qtde);
                end if;
              end if;
          end;
        
          exit when v_qtdePriorizar <= 0;
        end loop;
      
      end loop;
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
    exception
      when others then
        if (c_buscaPorSaldoEmLocal%isopen) then
          close c_buscaPorSaldoEmLocal;
        end if;
        raise;
    end reservarLotes;
  
    procedure reservarLotesCob(p_liberado char) is
      cursor c_buscaPorSaldoEmLocal
      (
        p_idArmazem     in number,
        p_idDep         in number,
        p_ltInd         in varchar2,
        p_idPrd         in number,
        p_ltLib         in varchar2,
        p_estadoLt      in varchar2,
        p_dtVenc        in date,
        p_idTipoPedido  in number,
        p_idnfcobertura in number
      ) is
        select b.idarmazem, b.idlocal, b.disponivel, b.tipoLocal
          from (select a.idarmazem, a.idlocal,
                        ((case
                           when a.estDisp < a.cobDisp then
                            a.estDisp
                           else
                            a.cobDisp
                         end) - a.sepEspAssoc) disponivel, a.ordem,
                        a.tipoLocal
                   from (select ll.idarmazem, ll.idlocal, lo.ordem,
                                 lo.tipo tipoLocal,
                                 sum((ll.estoque - ll.pendencia + ll.adicionar)) estDisp,
                                 sum((select nvl(sum(s.qtde), 0)
                                        from separacaoespecifica s
                                       where s.idarmazem = ll.idarmazem
                                         and s.idlote = ll.idlote
                                         and s.idlocal = ll.idlocal
                                         and not exists
                                       (select 1
                                                from nfromaneio nfr
                                               where nfr.idnotafiscal =
                                                     s.idnotafiscal))) sepEspAssoc,
                                 sum(cob.qtdedisponivel) cobDisp
                            from lotelocal ll, lote lt, local lo, setor s,
                                 coberturalotedispnf cob, produto p,
                                 produtodepositante pd
                           where lt.idlote = ll.idlote
                             and ll.idarmazem = p_idArmazem
                             and lt.iddepositante = p_idDep
                             and lt.descr = p_ltInd
                             and lt.idproduto = p_idPrd
                             and lt.tipolote = 'L'
                             and lt.liberado = nvl(p_ltLib, lt.liberado)
                             and lt.estado = p_estadoLt
                             and lo.ativo = 'S'
                             and lt.idlotemont is null
                             and lo.id = ll.idendereco
                             and lo.idregiao is not null
                             and s.idsetor = lo.idsetor
                             and s.expedicao = 'S'
                             and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                                 to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                         'MM/yyyy')
                             and p.idproduto = lt.idproduto
                             and pd.idproduto = lt.idproduto
                             and pd.identidade = lt.iddepositante
                             and (pd.controlartempodematuracao = 0 or
                                 (pd.controlartempodematuracao = 1 and
                                 trunc(sysdate) >=
                                 trunc(lt.dtfabricacao +
                                         p.tempoparamaturacaoemdias)))
                             and ll.estoque - ll.pendencia + ll.adicionar > 0
                             and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                  (select 1
                                     from setorclassificacaotipopedido sctp
                                    where sctp.idtipopedido = p_idTipoPedido
                                      and sctp.idsetor = lo.idsetor))
                             and cob.idlote = ll.idlote
                             and cob.idnotafiscalcobertura = p_idnfcobertura
                           group by ll.idarmazem, ll.idlocal, lo.ordem, lo.tipo) a) b
         where b.disponivel > 0
         order by b.tipoLocal, b.disponivel, b.ordem;
    
      cursor c_buscaLotesLocalSelecionado
      (
        p_idLocalSelecionado varchar2,
        p_idArmazem          in number,
        p_idDep              in number,
        p_ltInd              in varchar2,
        p_idPrd              in number,
        p_ltLib              in varchar2,
        p_estadoLt           in varchar2,
        p_dtVenc             in date,
        p_idTipoPedido       in number,
        p_idnfcobertura      in number
      ) is
        select b.idarmazem, b.idlocal, b.idlote, b.disponivel
          from (select a.idarmazem, a.idlocal, a.idlote,
                        ((case
                           when a.estDisp < a.cobDisp then
                            a.estDisp
                           else
                            a.cobDisp
                         end) - a.sepEspAssoc) disponivel, a.dtvencimento,
                        a.dtentrada
                   from (select ll.idarmazem, ll.idlocal, ll.idlote,
                                 (ll.estoque - ll.pendencia + ll.adicionar) estDisp,
                                 (select nvl(sum(s.qtde), 0)
                                     from separacaoespecifica s
                                    where s.idarmazem = ll.idarmazem
                                      and s.idlote = ll.idlote
                                      and s.idlocal = ll.idlocal
                                      and not exists
                                    (select 1
                                             from nfromaneio nfr
                                            where nfr.idnotafiscal =
                                                  s.idnotafiscal)) sepEspAssoc,
                                 cob.qtdecobertura cobDisp,
                                 nvl(lt.dtvenc, sysdate) dtvencimento,
                                 lt.dtentrada, lt.idproduto, lt.descr ltind
                            from lotelocal ll, lote lt, local lo, produto p,
                                 produtodepositante pd,
                                 (select cob.idlote,
                                          sum(cob.qtdedisponivel) qtdecobertura
                                     from coberturalotedispnf cob
                                    where cob.idnotafiscalcobertura =
                                          p_idnfcobertura
                                    group by cob.idlote) cob
                           where ll.idlocal = p_idLocalSelecionado
                             and lt.idlote = ll.idlote
                             and lo.idlocal = ll.idlocal
                             and lo.idarmazem = ll.idarmazem
                             and ll.idarmazem = p_idArmazem
                             and lt.iddepositante = p_idDep
                             and lt.descr = p_ltInd
                             and lt.idproduto = p_idPrd
                             and lt.tipolote = 'L'
                             and lt.liberado = nvl(p_ltLib, lt.liberado)
                             and lt.estado = p_estadoLt
                             and lt.idlotemont is null
                             and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                  (select 1
                                     from setorclassificacaotipopedido sctp
                                    where sctp.idtipopedido = p_idTipoPedido
                                      and sctp.idsetor = lo.idsetor))
                             and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                                 to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                         'MM/yyyy')
                             and p.idproduto = lt.idproduto
                             and pd.idproduto = lt.idproduto
                             and pd.identidade = lt.iddepositante
                             and (pd.controlartempodematuracao = 0 or
                                 (pd.controlartempodematuracao = 1 and
                                 trunc(sysdate) >=
                                 trunc(lt.dtfabricacao +
                                         p.tempoparamaturacaoemdias)))
                             and ll.estoque - ll.pendencia + ll.adicionar > 0
                             and cob.idlote = ll.idlote
                             and cob.qtdecobertura > 0) a) b
         where b.disponivel > 0
         order by b.dtvencimento, b.dtentrada, b.idlote, b.disponivel;
    
      r_buscaPorSaldoEmLocal       c_buscaPorSaldoEmLocal%rowtype;
      r_buscaLotesLocalSelecionado c_buscaLotesLocalSelecionado%rowtype;
      r_sep                        separacaoespecifica%rowtype;
      v_qtdePriorizar              number;
      v_idsepespecifica            number;
      v_qtde                       number;
      v_Seploteindsepespecif       number;
    begin
      v_qtdePriorizar := p_qtde * r_item.fatorconversao;
    
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
      while (v_qtdePriorizar > 0)
      loop
        if (not c_buscaPorSaldoEmLocal%isopen) then
          open c_buscaPorSaldoEmLocal(r_item.idarmazem,
                                      r_item.iddepositante, p_loteindustria,
                                      r_item.idproduto, p_liberado,
                                      r_item.estado, p_dataVencimento,
                                      v_idTipoPedido, p_idnfcobertura);
        end if;
      
        if (c_buscaPorSaldoEmLocal%Notfound) then
          v_msg := t_message('A quantidade associada é maior do que a quantidade disponivel no estoque.' ||
                             chr(13) || 'IDPRODUTO: {0}' || chr(13) ||
                             'LOTEINDUSTRIA: {1}' || chr(13) || 'QTDE: {2}');
          v_msg.addParam(r_item.idproduto);
          v_msg.addParam(p_loteindustria);
          v_msg.addParam(p_qtde);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        fetch c_buscaPorSaldoEmLocal
          into r_buscaPorSaldoEmLocal;
      
        for r_buscaLotesLocalSelecionado in c_buscaLotesLocalSelecionado(r_buscaPorSaldoEmLocal.Idlocal,
                                                                         r_item.idarmazem,
                                                                         r_item.iddepositante,
                                                                         p_loteindustria,
                                                                         r_item.idproduto,
                                                                         p_liberado,
                                                                         r_item.estado,
                                                                         p_dataVencimento,
                                                                         v_idTipoPedido,
                                                                         p_idnfcobertura)
        loop
          r_sep.idarmazem := r_buscaLotesLocalSelecionado.Idarmazem;
          r_sep.idlocal   := r_buscaLotesLocalSelecionado.Idlocal;
          r_sep.idlote    := r_buscaLotesLocalSelecionado.Idlote;
          r_sep.qtde      := r_buscaLotesLocalSelecionado.Disponivel;
        
          if (r_sep.qtde > v_qtdePriorizar) then
            r_sep.qtde := v_qtdePriorizar;
          end if;
        
          v_qtdePriorizar := v_qtdePriorizar - r_sep.qtde;
        
          r_sep.idnotafiscal := r_item.idnotafiscal;
          r_sep.cadmanual    := 'S';
        
          begin
          
            pk_notafiscal.validarSetorFormacaoOnda(r_sep.idlote,
                                                   r_sep.idarmazem,
                                                   r_sep.idlocal);
          
            insert into separacaoespecifica
              (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual,
               fonteseparacao, idUsuario, dtVinculo)
            values
              (r_sep.idarmazem, r_sep.idlocal, r_sep.idlote,
               r_sep.idnotafiscal, r_sep.qtde, r_sep.cadmanual, 0,
               p_idUsuario, sysdate)
            returning id into v_idsepespecifica;
          
            insert into seploteindsepespecif
              (idsepespecifica, idseploteind, idlote, qtde)
            values
              (v_idsepespecifica, v_idsep, r_sep.idlote, r_sep.qtde);
          exception
            when dup_val_on_index then
              update separacaoespecifica s
                 set s.qtde = s.qtde + r_sep.qtde
               where s.idarmazem = r_sep.idarmazem
                 and s.idlocal = r_sep.idlocal
                 and s.idlote = r_sep.idlote
                 and s.idnotafiscal = r_sep.idnotafiscal
              returning s.id, s.qtde into v_idsepespecifica, v_qtde;
            
              select count(1)
                into v_Seploteindsepespecif
                from seploteindsepespecif s
               where s.idsepespecifica = v_idsepespecifica
                 and s.idlote = r_sep.idlote;
            
              insert into seploteindsepespecif
                (idsepespecifica, idseploteind, idlote, qtde)
              values
                (v_idsepespecifica, v_idsep, r_sep.idlote,
                 decode(v_Seploteindsepespecif, 0, v_qtde, r_sep.qtde));
          end;
        
          pk_lote.inserirQtdeReservadaNFCob(r_sep.idlote, r_sep.qtde,
                                            p_idnfcobertura);
        
          exit when v_qtdePriorizar <= 0;
        end loop;
      
      end loop;
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
    exception
      when others then
        if (c_buscaPorSaldoEmLocal%isopen) then
          close c_buscaPorSaldoEmLocal;
        end if;
        raise;
    end reservarLotesCob;
  
    procedure validarVinculoSepEspecifica is
      v_qtde number;
    begin
      if (r_item.agruparinclusaolotes = 1 or
         (r_item.agruparinclusaolotes = 2 and p_idnfcobertura is null)) then
        select count(s.idsepespporloteindustria)
          into v_qtde
          from sepespporloteindustria s
         where s.idnfdet = p_idnfdet
           and s.loteindustria = p_loteindustria
           and s.idnfcobertura is null;
      
        if (v_qtde > 0) then
          desvincLoteIndSepEspecifica(p_idusuario, p_idnfdet,
                                      p_loteindustria);
        end if;
      elsif (r_item.agruparinclusaolotes = 2) then
        select count(s.idsepespporloteindustria)
          into v_qtde
          from sepespporloteindustria s
         where s.idnfdet = p_idnfdet
           and s.loteindustria = p_loteindustria
           and s.idnfcobertura = p_idnfcobertura;
      
        if (v_qtde > 0) then
          desvincLoteIndSepEspecificaCob(p_idusuario, p_idnfdet,
                                         p_loteindustria, p_idnfcobertura);
        end if;
      end if;
    end validarVinculoSepEspecifica;
  
  begin
    select nf.idarmazem, nf.idtipopedido
      into v_idArmazem, v_idTipoPedido
      from nfdet nd, notafiscal nf
     where nd.idnfdet = p_idnfdet
       and nf.idnotafiscal = nd.nf;
  
    if (not (isPermiteAltLoteIndustria(p_idnfdet)) and
       (p_fonteSeparacao <> C_SEP_ESPEC_WMSWEB)) then
      v_msg := t_message('Não é permitida alteração de Lotes quando pedido for realizado pelo Pedido Online (WMS-WEB).');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_locks.executeLock(v_idArmazem, 1);
  
    select nd.nf, e.fatorconversao, nf.idarmazem, nd.idproduto,
           e.descrreduzido, nd.qtde, p.fracionado,
           nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes),
           d.identidade, nf.estado
      into r_item.idnotafiscal, r_item.fatorconversao, r_item.idarmazem,
           r_item.idproduto, r_item.descreduzida, r_item.qtdenfdet,
           r_item.fracionado, r_item.agruparinclusaolotes,
           r_item.iddepositante, r_item.estado
      from nfdet nd, embalagem e, notafiscal nf, produto p, depositante d
     where nd.idnfdet = p_idnfdet
       and e.idproduto = nd.idproduto
       and e.barra = nd.barra
       and nf.idnotafiscal = nd.nf
       and p.idproduto = nd.idproduto
       and d.identidade = nf.iddepositante;
  
    v_idLote := p_idLote;
  
    if (r_item.agruparinclusaolotes = 0) then
      v_msg := t_message('O metodo de incluir o estoque para separação especifica não esta configurado para utilizar lote industria. Confira o cadastro do depositante.' ||
                         chr(13) || 'IDDEPOSITANTE: {0}');
      v_msg.addParam(r_item.iddepositante);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarNFparaSepEspecifica(r_item.idnotafiscal);
  
    validarVinculoSepEspecifica;
  
    if (pk_notafiscal.aceitaLoteFracionado(r_item.idnotafiscal) > 0) then
      validarQtdeAssociada;
    else
      validarQtdeAssociadaNaoFrac;
    end if;
  
    inserirSepEspecificaPorLtInd;
  
    v_liberado := pk_lote.getLoteLiberado(p_idnfdet);
  
    if (r_item.agruparinclusaolotes = 2 and p_idnfcobertura is not null) then
      reservarLotesCob(v_liberado);
    else
      reservarLotes(v_liberado);
    end if;
  
    marcarMetodoSepEspecifica(r_item.idnotafiscal,
                              r_item.agruparinclusaolotes);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Vinculou o lote industria ' || p_loteindustria ||
                          ' na separação especifica para o idnfdet ' ||
                          p_idnfdet, p_idnfdet, 'SL');
  
  end vincLoteIndSepEspecifica;

  procedure desvincLoteIndSepEspecifica
  (
    p_idusuario            in number,
    p_idnfdet              in number,
    p_loteindustria        in varchar2,
    p_cancelamentoexclusao in number := 0
  ) is
    v_idnotafiscal         number;
    v_agruparinclusaolotes number;
    v_iddepositante        number;
    v_qtderestante         number;
    v_msg                  t_message;
  begin
    select nd.nf, nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes),
           d.identidade
      into v_idnotafiscal, v_agruparinclusaolotes, v_iddepositante
      from nfdet nd, notafiscal nf, depositante d
     where nd.idnfdet = p_idnfdet
       and nf.idnotafiscal = nd.nf
       and d.identidade = nf.iddepositante;
  
    if (v_agruparinclusaolotes = 0) then
      v_msg := t_message('O metodo de incluir o estoque para separação especifica não esta configurado para utilizar lote industria. Confira o cadastro do depositante.' ||
                         chr(13) || 'IDDEPOSITANTE: {0}');
      v_msg.addParam(v_iddepositante);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_cancelamentoexclusao = 0 and
       not (isPermiteAltLoteIndustria(p_idnfdet))) then
      v_msg := t_message('Não é permitida alteração de Lotes quando pedido for realizado pelo Pedido Online (WMS-WEB).');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarNFparaSepEspecifica(v_idnotafiscal);
  
    for c_sepespecifica in (select ss.idsepespecifica, ss.idseploteind,
                                   ss.idlote, ss.qtde
                              from seploteindsepespecif ss
                             where exists
                             (select 1
                                      from sepespporloteindustria sl
                                     where sl.idnfdet = p_idnfdet
                                       and sl.loteindustria = p_loteindustria
                                       and sl.idnfcobertura is null
                                       and sl.idsepespporloteindustria =
                                           ss.idseploteind))
    loop
      delete from seploteindsepespecif ss
       where ss.idsepespecifica = c_sepespecifica.idsepespecifica
         and ss.idseploteind = c_sepespecifica.idseploteind
         and ss.idlote = c_sepespecifica.idlote;
    
      update separacaoespecifica s
         set s.qtde = s.qtde - c_sepespecifica.qtde
       where s.id = c_sepespecifica.idsepespecifica
      returning s.qtde into v_qtderestante;
    
      if v_qtderestante = 0 then
        delete from separacaoespecifica s
         where s.id = c_sepespecifica.idsepespecifica;
      end if;
    end loop;
  
    delete from sepespporloteindustria sl
     where sl.idnfdet = p_idnfdet
       and sl.loteindustria = p_loteindustria
       and sl.idnfcobertura is null;
  
    desmarcarMetodoSepEspecifica(v_idnotafiscal);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Desvinculou o lote industria ' || p_loteindustria ||
                          ' da separação especifica para o idnfdet ' ||
                          p_idnfdet, p_idnfdet, 'SL');
  
  end desvincLoteIndSepEspecifica;

  procedure validarNFparaSepEspecifica(p_idnotafiscal in number) is
    v_idprenf           number;
    v_status            varchar2(20);
    v_statusnf          notafiscal.statusnf%type;
    v_estoqueverificado notafiscal.estoqueverificado%type;
    v_IsPTL             notafiscal.picktolight%type;
    v_msg               t_message;
  begin
    select nf.idprenf, nf.statusnf,
           decode(nf.statusnf, 'N', 'DIGITADO', 'I', 'IMPORTADO', 'C',
                   'EM CARGA', 'P', 'PROCESSADO', 'B', 'EM QUARENTENA',
                   nf.statusnf) status, nf.estoqueverificado, nf.picktolight
      into v_idprenf, v_statusnf, v_status, v_estoqueverificado, v_IsPTL
      from notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal
       for update;
  
    if v_statusnf not in ('I', 'N') then
      v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ {0}.' || chr(13) ||
                         'OPERAÇÃO CANCELADA.' || chr(13) || 'IDPRENF: {1}' ||
                         chr(13) || 'IDNOTAFISCAL: {2}');
      v_msg.addParam(v_status);
      v_msg.addParam(v_idprenf);
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if v_estoqueverificado = 'S' then
      v_msg := t_message('O PEDIDO OU NOTA FISCAL ESTÁ LIBERADO PARA EXPEDIÇÃO.' ||
                         chr(13) ||
                         'PARA VINCULAR OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                         chr(13) || 'IDPRENF: {0}' || chr(13) ||
                         'IDNOTAFISCAL: {1}');
      v_msg.addParam(v_idprenf);
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if v_estoqueverificado = 'X' then
      v_msg := t_message('O PEDIDO OU NOTA FISCAL NÃO FOI LIBERADO PARA EXPEDIÇÃO DEVIDO A CORTE NO ESTOQUE.' ||
                         chr(13) ||
                         'PARA VINCULAR OS LOTES O PEDIDO OU NOTA FISCAL TEM QUE ESTAR PENDENTE DE LIBERAÇÃO PARA EXPEDIÇÃO.' ||
                         chr(13) || 'IDPRENF: {0}' || chr(13) ||
                         'IDNOTAFISCAL: {1}');
      v_msg.addParam(v_idprenf);
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    
    end if;
  
    if (v_IsPTL = 1) then
      v_msg := t_message('Não é permitido vincular lotes de Separação Específica à Documento de Expedição marcado para Separação Externa.' ||
                         chr(13) || 'IDPRENF: {0}' || chr(13) ||
                         'IDNOTAFISCAL: {1}');
      v_msg.addParam(v_idprenf);
      v_msg.addParam(p_idnotafiscal);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarNFparaSepEspecifica;

  procedure GerarSepEspecificaImpTipo
  (
    p_idusuario      in number,
    p_barra          in varchar,
    p_valorInfoEspec in varchar2,
    p_idprenf        in number,
    p_tipomaterial   in number,
    p_qtde           in number,
    p_cadManual      in char := 'S'
  ) is
    v_qtdedisponivel number;
    v_fatorconversao number;
    v_restante       number;
    v_idnotafiscal   number;
    v_disponivel     number;
    v_idUsuario      number;
    v_msg            t_message;
  begin
    if (p_idusuario is null) then
    
      begin
        select c.idusuariointegracao
          into v_idusuario
          from configuracao c
         where c.ativo = 'S'
           and c.idusuariointegracao is not null;
      exception
        when no_data_found then
          v_msg := t_message('Usuário de integração padrão não preenchido nas configurações gerais do sistema.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    else
      v_idUsuario := p_idusuario;
    end if;
  
    begin
      select e.fatorconversao
        into v_fatorconversao
        from embalagem e
       where e.barra = p_barra;
    exception
      when others then
        v_msg := t_message('PRODUTO COM BARRA : {0}' || ' NÃO ENCONTRADO.' ||
                           chr(13) || 'OPERAÇÃO CANCELADA.');
        v_msg.addParam(p_barra);
        raise_application_error(-20100, v_msg.formatMessage);
    end;
  
    begin
      select nvl(sum(nvl(v.disp, 0)), 0) disp
        into v_qtdedisponivel
        from v_estoque_local v, estoqueinformacaoespecifica e,
             produtodepositante pd,
             (select nf.estado, nf.iddepositante, nf.idnotafiscal,
                      nf.idarmazem
                 from notafiscal nf
                where nf.idprenf = p_idprenf) nf
       where 1 = 1
         and e.valor = p_valorInfoEspec
         and e.idinfomaterial = p_tipomaterial
         and v.barra = p_barra
         and v.idarmazem = e.idarmazem
         and v.iddepositante = e.identidade
         and v.idproduto = e.idproduto
         and v.idlote = e.idlote
         and v.iddepositante = nf.iddepositante
         and v.estadolote = nf.estado
         and v.idarmazem = nf.idarmazem
         and pd.identidade = e.identidade
         and pd.idproduto = e.idproduto
         and pd.rastrearinfoespecifica = 0
         and e.idnotafiscal is null
         and e.expedida = 0
         and v.tipo in (0, 1, 2)
         and decode(v.localativo, 'S', 1, 0) = 1
         and decode(v.loteliberado, 'S', 1, 0) = 1;
    end;
  
    if v_qtdedisponivel is null then
      v_qtdedisponivel := 0;
    end if;
  
    if v_qtdedisponivel = 0 then
      v_msg := t_message('PRODUTO COM BARRA : {0}, NRO SERIE {1}' ||
                         ' E TIPO MATERIAL {2} NAO ENCONTRADO.' || chr(13) ||
                         'OPERAÇÃO CANCELADA.');
      v_msg.addParam(p_barra);
      v_msg.addParam(p_valorInfoEspec);
      v_msg.addParam(p_tipomaterial);
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    begin
      select n.idnotafiscal
        into v_idnotafiscal
        from notafiscal n
       where idprenf = p_idprenf;
    exception
      when no_data_found then
        v_idnotafiscal := null;
    end;
  
    if (p_qtde * v_fatorconversao) > v_qtdedisponivel then
      v_restante := 0;
    else
      v_restante := (p_qtde * v_fatorconversao);
    
      for c_lote in (select v.idarmazem, v.idlote, v.idlocal, v.disp
                       from v_estoque_sepesp v, estoqueinformacaoespecifica e,
                            produtodepositante pd,
                            (select nf.estado, nf.iddepositante,
                                     nf.idnotafiscal, nf.idarmazem,
                                     ctp.estadomat, ctp.situacaolote
                                from notafiscal nf, classificacaotipopedido ctp
                               where nf.idprenf = p_idprenf
                                 and nf.idtipopedido = ctp.idtipopedido(+)) nf
                      where 1 = 1
                        and e.valor = p_valorInfoEspec
                        and e.idinfomaterial = p_tipomaterial
                        and v.barra = p_barra
                        and v.idarmazem = e.idarmazem
                        and v.iddepositante = e.identidade
                        and v.idproduto = e.idproduto
                        and v.idlote = e.idlote
                        and v.iddepositante = nf.iddepositante
                        and v.estadolote = nvl(nf.estadomat, nf.estado)
                        and v.idarmazem = nf.idarmazem
                        and pd.identidade = e.identidade
                        and pd.idproduto = e.idproduto
                        and pd.rastrearinfoespecifica = 0
                        and e.idnotafiscal is null
                        and e.expedida = 0
                        and v.tipo in (0, 1, 2)
                        and decode(v.localativo, 'S', 1, 0) = 1
                        and (nvl(nf.situacaolote, 0) = 2 or
                            nvl(nf.situacaolote, 0) =
                            decode(v.loteliberado, 'S', 0, 1)))
      loop
        begin
          select se.qtde
            into v_disponivel
            from notafiscal nf, separacaoespecifica se
           where nf.statusnf in ('N', 'I')
             and decode(nf.tipo, 'S', 1, 0) = 1
             and decode(nf.reentrega, 'N', 1, 0) = 1
             and se.idnotafiscal = nf.idnotafiscal
             and se.idarmazem = c_lote.idarmazem
             and se.idlocal = c_lote.idlocal
             and se.idlote = c_lote.idlote;
        exception
          when no_data_found then
            v_disponivel := 0;
        end;
      
        c_lote.disp := c_lote.disp - v_disponivel;
      
        if v_restante > 0 then
          if v_restante > c_lote.disp then
            v_restante := v_restante - c_lote.disp;
          
            pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                               c_lote.idlocal,
                                                               c_lote.idlote,
                                                               v_idnotafiscal,
                                                               c_lote.disp,
                                                               v_idUsuario,
                                                               C_SEP_ESPEC_ENTERPRISE,
                                                               p_cadManual);
          else
            pk_separacaoespecifica.vincularSeparacaoEspecifica(c_lote.idarmazem,
                                                               c_lote.idlocal,
                                                               c_lote.idlote,
                                                               v_idnotafiscal,
                                                               v_restante,
                                                               v_idUsuario,
                                                               C_SEP_ESPEC_ENTERPRISE,
                                                               p_cadManual);
            v_restante := 0;
          end if;
        end if;
        exit when v_restante = 0;
      end loop;
      if v_restante > 0 then
        v_msg := t_message('ERRO AO VERIFICAR QTDE NOS LOTES.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    end if;
  end GerarSepEspecificaImpTipo;

  procedure ajustaSepEspecifica
  (
    p_idNotaFiscal number,
    p_idlote       number
  ) is
    v_qtdeSep      number;
    v_idarmazemSep armazem.idarmazem%type;
    v_idlocalSep   local.idlocal%type;
    v_idlocalNovo  local.idlocal%type;
  begin
    begin
      select a.idarmazem, a.idlocal, a.qtde
        into v_idarmazemSep, v_idlocalSep, v_qtdeSep
        from (select s.idarmazem, s.qtde, s.idlocal,
                      nvl((select ll.estoque - ll.pendencia + ll.adicionar
                             from lotelocal ll
                            where ll.idlote = s.idlote
                              and ll.idlocal = s.idlocal), 0) disponivel
                 from separacaoespecifica s
                where 1 = 1
                  and s.idnotafiscal = p_idNotafiscal
                  and s.idlote = p_idLote) a
       where a.qtde > a.disponivel;
    
      select a.idlocal
        into v_idlocalNovo
        from (select ll.idlocal,
                      nvl((ll.estoque - ll.pendencia + ll.adicionar), 0) disponivel
                 from lotelocal ll
                where ll.idlote = p_idLote
                  and (ll.estoque - ll.pendencia + ll.adicionar) >= v_qtdeSep
                order by nvl((ll.estoque - ll.pendencia + ll.adicionar), 0) desc) a
       where rownum = 1;
    
      pk_lote.AlterarSeparacaoEspecifica(p_idLote, v_idarmazemSep,
                                         v_idlocalSep, v_idlocalNovo);
    exception
      when others then
        null;
    end;
  end ajustaSepEspecifica;

  procedure desvincLoteIndSepEspecificaCob
  (
    p_idusuario            in number,
    p_idnfdet              in number,
    p_loteindustria        in varchar2,
    p_idnfcobertura        in number,
    p_cancelamentoexclusao in number := 0
  ) is
    v_idnotafiscal         number;
    v_agruparinclusaolotes number;
    v_iddepositante        number;
    v_qtderestante         number;
    v_msg                  t_message;
  
  begin
    select nd.nf, nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes),
           d.identidade
      into v_idnotafiscal, v_agruparinclusaolotes, v_iddepositante
      from nfdet nd, notafiscal nf, depositante d
     where nd.idnfdet = p_idnfdet
       and nf.idnotafiscal = nd.nf
       and d.identidade = nf.iddepositante;
  
    if (v_agruparinclusaolotes in (0, 1)) then
      v_msg := t_message('O método de incluir o estoque para separação especifica não está configurado para utilizar lote indústria listando nota fiscal de cobertura. Confira o cadastro do depositante.' ||
                         chr(13) || 'IDDEPOSITANTE: {0}');
      v_msg.addParam(v_iddepositante);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_cancelamentoexclusao = 0 and
       not (isPermiteAltLoteIndustria(p_idnfdet))) then
      v_msg := t_message('Não é permitida alteração de Lotes quando pedido for realizado pelo Pedido Online (WMS-WEB).');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarNFparaSepEspecifica(v_idnotafiscal);
  
    for c_sepespecifica in (select ss.idsepespecifica, ss.idseploteind,
                                   ss.idlote, ss.qtde
                              from seploteindsepespecif ss
                             where exists
                             (select 1
                                      from sepespporloteindustria sl
                                     where sl.idnfdet = p_idnfdet
                                       and sl.loteindustria = p_loteindustria
                                       and sl.idnfcobertura = p_idnfcobertura
                                       and sl.idsepespporloteindustria =
                                           ss.idseploteind))
    loop
      delete from seploteindsepespecif ss
       where ss.idsepespecifica = c_sepespecifica.idsepespecifica
         and ss.idseploteind = c_sepespecifica.idseploteind
         and ss.idlote = c_sepespecifica.idlote;
    
      update separacaoespecifica s
         set s.qtde = s.qtde - c_sepespecifica.qtde
       where s.id = c_sepespecifica.idsepespecifica
      returning s.qtde into v_qtderestante;
    
      if v_qtderestante = 0 then
        delete from separacaoespecifica s
         where s.id = c_sepespecifica.idsepespecifica;
      end if;
    
      pk_lote.retirarQtdeReservadaNFCob(c_sepespecifica.idlote,
                                        c_sepespecifica.qtde,
                                        p_idnfcobertura);
    end loop;
  
    delete from sepespporloteindustria sl
     where sl.idnfdet = p_idnfdet
       and sl.loteindustria = p_loteindustria
       and sl.idnfcobertura = p_idnfcobertura;
  
    desmarcarMetodoSepEspecifica(v_idnotafiscal);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Desvinculou o lote industria ' || p_loteindustria ||
                          ' da separação especifica para o idnfdet ' ||
                          p_idnfdet, p_idnfdet, 'SL');
  
  end desvincLoteIndSepEspecificaCob;

  procedure vincLoteIndSepPedWeb
  (
    p_idusuario      in number,
    p_idnfdet        in number,
    p_loteindustria  in varchar2,
    p_qtde           in out number,
    p_dataVencimento in date := null,
    p_idLote         in number := null
  ) is
  
    type t_item is record(
      idnotafiscal         notafiscal.idnotafiscal%type,
      fatorconversao       number,
      idarmazem            number,
      idproduto            number,
      descreduzida         embalagem.descrreduzido%type,
      qtdenfdet            number,
      fracionado           produto.fracionado%type,
      agruparinclusaolotes number,
      iddepositante        number,
      estado               notafiscal.estado%type);
    r_item t_item;
    cursor c_buscaPorSaldoEmLocal
    (
      p_idArmazem    in number,
      p_idDep        in number,
      p_ltInd        in varchar2,
      p_idPrd        in number,
      p_ltLib        in varchar2,
      p_estadoLt     in varchar2,
      p_dtVenc       in date,
      p_idTipoPedido in number,
      p_idLote       in number := null
    ) is
      select b.idarmazem, b.idlocal, b.disponivel, b.tipoLocal
        from (select a.idarmazem, a.idlocal,
                      ((case
                         when a.estDisp < a.cobDisp then
                          a.estDisp
                         else
                          a.cobDisp
                       end) - a.sepEspAssoc) disponivel, a.ordem, a.tipoLocal
                 from (select ll.idarmazem, ll.idlocal, lo.ordem,
                               lo.tipo tipoLocal,
                               sum((ll.estoque - ll.pendencia + ll.adicionar)) estDisp,
                               sum((select nvl(sum(s.qtde), 0)
                                      from separacaoespecifica s
                                     where s.idarmazem = ll.idarmazem
                                       and s.idlote = ll.idlote
                                       and s.idlocal = ll.idlocal
                                       and not exists
                                     (select 1
                                              from nfromaneio nfr
                                             where nfr.idnotafiscal =
                                                   s.idnotafiscal))) sepEspAssoc,
                               sum(pk_lote.RetornarQtdeDisponivel(lt.idlote)) cobDisp
                          from lotelocal ll, lote lt, local lo, setor s,
                               produto p, produtodepositante pd
                         where lt.idlote = ll.idlote
                           and ll.idarmazem = p_idArmazem
                           and lt.iddepositante = p_idDep
                           and lt.descr = p_ltInd
                           and lt.idproduto = p_idPrd
                           and lt.tipolote = 'L'
                           and lt.liberado = nvl(p_ltLib, lt.liberado)
                           and lt.estado = p_estadoLt
                           and lo.ativo = 'S'
                           and lt.idlotemont is null
                           and lo.id = ll.idendereco
                           and lo.idregiao is not null
                           and s.idsetor = lo.idsetor
                           and lt.idlote = nvl(p_idLote, lt.idlote)
                           and s.expedicao = 'S'
                           and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                               to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                       'MM/yyyy')
                           and p.idproduto = lt.idproduto
                           and pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante
                           and (pd.controlartempodematuracao = 0 or
                               (pd.controlartempodematuracao = 1 and
                               trunc(sysdate) >=
                               trunc(lt.dtfabricacao +
                                       p.tempoparamaturacaoemdias)))
                           and ll.estoque - ll.pendencia + ll.adicionar > 0
                           and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                (select 1
                                   from setorclassificacaotipopedido sctp
                                  where sctp.idtipopedido = p_idTipoPedido
                                    and sctp.idsetor = lo.idsetor))
                         group by ll.idarmazem, ll.idlocal, lo.ordem, lo.tipo) a) b
       where b.disponivel > 0
       order by b.tipoLocal, b.disponivel, b.ordem;
  
    cursor c_buscaLotesLocalSelecionado
    (
      p_idLocalSelecionado varchar2,
      p_idArmazem          in number,
      p_idDep              in number,
      p_ltInd              in varchar2,
      p_idPrd              in number,
      p_ltLib              in varchar2,
      p_estadoLt           in varchar2,
      p_dtVenc             in date,
      p_idTipoPedido       in number,
      p_idLote             in number := null
    ) is
      select b.idarmazem, b.idlocal, b.idlote, b.disponivel
        from (select a.idarmazem, a.idlocal, a.idlote,
                      ((case
                         when a.estDisp < a.cobDisp then
                          a.estDisp
                         else
                          a.cobDisp
                       end) - a.sepEspAssoc) disponivel, a.dtvencimento,
                      a.dtentrada
                 from (select ll.idarmazem, ll.idlocal, ll.idlote,
                               (ll.estoque - ll.pendencia + ll.adicionar) estDisp,
                               (select nvl(sum(s.qtde), 0)
                                   from separacaoespecifica s
                                  where s.idarmazem = ll.idarmazem
                                    and s.idlote = ll.idlote
                                    and s.idlocal = ll.idlocal
                                    and not exists
                                  (select 1
                                           from nfromaneio nfr
                                          where nfr.idnotafiscal = s.idnotafiscal)) sepEspAssoc,
                               pk_lote.RetornarQtdeDisponivel(lt.idlote) cobDisp,
                               nvl(lt.dtvenc, sysdate) dtvencimento,
                               lt.dtentrada, lt.idproduto, lt.descr ltind
                          from lotelocal ll, lote lt, local lo, produto p,
                               produtodepositante pd
                         where ll.idlocal = p_idLocalSelecionado
                           and lt.idlote = ll.idlote
                           and lo.idlocal = ll.idlocal
                           and lo.idarmazem = ll.idarmazem
                           and ll.idarmazem = p_idArmazem
                           and lt.iddepositante = p_idDep
                           and lt.descr = p_ltInd
                           and lt.idproduto = p_idPrd
                           and lt.idlote = nvl(p_idLote, lt.idlote)
                           and lt.tipolote = 'L'
                           and lt.liberado = nvl(p_ltLib, lt.liberado)
                           and lt.estado = p_estadoLt
                           and lt.idlotemont is null
                           and ((nvl(p_idTipoPedido, 0) = 0) or exists
                                (select 1
                                   from setorclassificacaotipopedido sctp
                                  where sctp.idtipopedido = p_idTipoPedido
                                    and sctp.idsetor = lo.idsetor))
                           and to_char(nvl(lt.dtvenc, sysdate), 'MM/yyyy') =
                               to_char(nvl(p_dtVenc, nvl(lt.dtvenc, sysdate)),
                                       'MM/yyyy')
                           and p.idproduto = lt.idproduto
                           and pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante
                           and (pd.controlartempodematuracao = 0 or
                               (pd.controlartempodematuracao = 1 and
                               trunc(sysdate) >=
                               trunc(lt.dtfabricacao +
                                       p.tempoparamaturacaoemdias)))
                           and ll.estoque - ll.pendencia + ll.adicionar > 0) a) b
       where b.disponivel > 0
       order by b.dtvencimento, b.dtentrada, b.idlote, b.disponivel;
  
    r_buscaPorSaldoEmLocal       c_buscaPorSaldoEmLocal%rowtype;
    r_buscaLotesLocalSelecionado c_buscaLotesLocalSelecionado%rowtype;
    r_sep                        separacaoespecifica%rowtype;
    v_qtdePriorizar              number;
    v_idsepespecifica            number;
    v_qtde                       number;
    v_Seploteindsepespecif       number;
    v_liberado                   char(1);
    v_isPedWeb                   char(1);
    v_agruparinclusaolotes       depositante.agruparinclusaolotes%type;
    v_msg                        t_message;
  begin
  
    select nvl(ni.pedidoweb, 'N')
      into v_isPedWeb
      from nfimpressao ni, nfdetimpressao ndi
     where ni.idprenf = ndi.idprenf
       and ndi.idnfdet = p_idNfDet;
  
    select nd.nf, e.fatorconversao, nf.idarmazem, nd.idproduto,
           e.descrreduzido, nd.qtde, p.fracionado,
           nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes),
           d.identidade, nf.estado
      into r_item.idnotafiscal, r_item.fatorconversao, r_item.idarmazem,
           r_item.idproduto, r_item.descreduzida, r_item.qtdenfdet,
           r_item.fracionado, r_item.agruparinclusaolotes,
           r_item.iddepositante, r_item.estado
      from nfdet nd, embalagem e, notafiscal nf, produto p, depositante d
     where nd.idnfdet = p_idnfdet
       and e.idproduto = nd.idproduto
       and e.barra = nd.barra
       and nf.idnotafiscal = nd.nf
       and p.idproduto = nd.idproduto
       and d.identidade = nf.iddepositante;
  
    v_liberado := pk_lote.getLoteLiberado(p_idnfdet);
    if (r_item.agruparinclusaolotes in (1, 2)) then
      vincLoteIndSepEspecifica(p_idusuario, p_idnfdet, p_loteindustria,
                               p_qtde, p_dataVencimento, null, p_idLote,
                               C_SEP_ESPEC_WMSWEB);
    else
      v_qtdePriorizar := p_qtde * r_item.fatorconversao;
    
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
      while (v_qtdePriorizar > 0)
      loop
        if (not c_buscaPorSaldoEmLocal%isopen) then
          open c_buscaPorSaldoEmLocal(r_item.idarmazem,
                                      r_item.iddepositante, p_loteindustria,
                                      r_item.idproduto, v_liberado,
                                      r_item.estado, p_dataVencimento, null,
                                      p_idLote);
        end if;
      
        if (c_buscaPorSaldoEmLocal%Notfound) then
          v_msg := t_message('A quantidade associada é maior do que a quantidade disponivel no estoque.' ||
                             chr(13) || 'IDPRODUTO: {0}' || chr(13) ||
                             'LOTEINDUSTRIA: {1}' || chr(13) || 'QTDE: {2}');
          v_msg.addParam(r_item.idproduto);
          v_msg.addParam(p_loteindustria);
          v_msg.addParam(p_qtde);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        fetch c_buscaPorSaldoEmLocal
          into r_buscaPorSaldoEmLocal;
      
        for r_buscaLotesLocalSelecionado in c_buscaLotesLocalSelecionado(r_buscaPorSaldoEmLocal.Idlocal,
                                                                         r_item.idarmazem,
                                                                         r_item.iddepositante,
                                                                         p_loteindustria,
                                                                         r_item.idproduto,
                                                                         v_liberado,
                                                                         r_item.estado,
                                                                         p_dataVencimento,
                                                                         null,
                                                                         p_idLote)
        loop
          r_sep.idarmazem := r_buscaLotesLocalSelecionado.Idarmazem;
          r_sep.idlocal   := r_buscaLotesLocalSelecionado.Idlocal;
          r_sep.idlote    := r_buscaLotesLocalSelecionado.Idlote;
          r_sep.qtde      := r_buscaLotesLocalSelecionado.Disponivel;
        
          if (r_sep.qtde > v_qtdePriorizar) then
            r_sep.qtde := v_qtdePriorizar;
          end if;
        
          v_qtdePriorizar := v_qtdePriorizar - r_sep.qtde;
        
          r_sep.idnotafiscal := r_item.idnotafiscal;
        
          if (v_isPedWeb = 'S') then
            r_sep.cadmanual := 'N';
          else
            r_sep.cadmanual := 'S';
          end if;
          vincularSeparacaoEspecifica(r_item.idarmazem,
                                      r_buscaLotesLocalSelecionado.Idlocal,
                                      p_idlote, r_item.idnotafiscal, p_qtde,
                                      p_idusuario, C_SEP_ESPEC_ENTERPRISE,
                                      r_sep.cadmanual);
          exit when v_qtdePriorizar <= 0;
        end loop;
      
      end loop;
      if (c_buscaPorSaldoEmLocal%isopen) then
        close c_buscaPorSaldoEmLocal;
      end if;
    
    end if;
  
  end vincLoteIndSepPedWeb;

  procedure desvincPorNF
  (
    p_idnotafiscal         in number,
    p_idusuario            in number,
    p_cancelamentoexclusao in number := 0
  ) is
    v_existeSeparacaoespecifica number;
    v_agruparlotes              number;
  begin
    select count(1)
      into v_existeSeparacaoespecifica
      from separacaoespecifica s
     where s.idnotafiscal = p_idnotafiscal;
  
    if v_existeSeparacaoespecifica > 0 then
      select nvl(nf.metodoSeparacaoEspecifica, d.agruparinclusaolotes) agruparinclusaolotes
        into v_agruparlotes
        from depositante d, notafiscal nf
       where d.identidade = nf.iddepositante
         and nf.idnotafiscal = p_idnotafiscal;
    
      --Indica o metodo de inclus?o de estoque na liberac?o de nf para expedic?o. 
      --0 - Por Lote Local, 1 - Por Lote Industria, 2 - Por Lote Industria Listando NF Cobertura
    
      if (v_agruparlotes = 0) then
        for sep in (select *
                      from separacaoespecifica s
                     where s.idnotafiscal = p_idnotafiscal)
        loop
          desvincularSeparacaoEspecifica(sep.idarmazem, sep.idlocal,
                                         sep.idlote, sep.idnotafiscal,
                                         p_idusuario, p_cancelamentoexclusao);
        end loop;
      else
        for sep in (select s.*
                      from sepespporloteindustria s, nfdet nd
                     where s.idnfdet = nd.idnfdet
                       and nd.nf = p_idnotafiscal)
        loop
          if (v_agruparlotes = 1 or sep.idnfcobertura is null) then
            desvincLoteIndSepEspecifica(p_idusuario, sep.idnfdet,
                                        sep.loteindustria,
                                        p_cancelamentoexclusao);
          elsif (v_agruparlotes = 2) then
            desvincLoteIndSepEspecificaCob(p_idusuario, sep.idnfdet,
                                           sep.loteindustria,
                                           sep.idnfcobertura,
                                           p_cancelamentoexclusao);
          end if;
        end loop;
      end if;
    end if;
  
    for c in (select s.*
                from sepespporloteindustria s, nfdet nd
               where s.idnfcobertura = p_idnotafiscal
                 and nd.idnfdet = s.idnfdet
                 and nd.nf <> s.idnfcobertura)
    loop
    
      for c2 in (select sss.*
                   from seploteindsepespecif sss
                  where sss.idseploteind = c.idsepespporloteindustria)
      loop
      
        delete from seploteindsepespecif si
         where si.idseploteind = c2.idseploteind;
      
        delete from separacaoespecifica se
         where se.id = c2.idsepespecifica;
      
      end loop;
    
      delete from sepespporloteindustria s
       where s.idsepespporloteindustria = c.idsepespporloteindustria;
    end loop;
  
    if (p_cancelamentoexclusao = 1) then
      delete from separacaoespecifica s
       where s.idnotafiscal = p_idnotafiscal;
    end if;
  
  end desvincPorNF;

  procedure desvincPorLote
  (
    p_idlote               in number,
    p_idusuario            in number,
    p_cancelamentoexclusao in number := 0
  ) is
    v_existeSeparacaoespecifica number;
    v_agruparlotes              number;
  begin
    select count(1)
      into v_existeSeparacaoespecifica
      from separacaoespecifica s, notafiscal nf
     where s.idlote = p_idlote
       and nf.idnotafiscal = s.idnotafiscal
       and nf.statusnf not in ('P');
  
    if v_existeSeparacaoespecifica > 0 then
      select d.agruparinclusaolotes
        into v_agruparlotes
        from depositante d, lote lt
       where d.identidade = lt.iddepositante
         and lt.idlote = p_idlote;
    
      --Indica o metodo de inclus?o de estoque na liberac?o de nf para expedic?o. 
      --0 - Por Lote Local, 1 - Por Lote Industria, 2 - Por Lote Industria Listando NF Cobertura
    
      if (v_agruparlotes = 0) then
        for sep in (select s.*
                      from separacaoespecifica s, notafiscal nf
                     where s.idlote = p_idlote
                       and nf.idnotafiscal = s.idnotafiscal
                       and nf.statusnf not in ('P'))
        loop
          desvincularSeparacaoEspecifica(sep.idarmazem, sep.idlocal,
                                         sep.idlote, sep.idnotafiscal,
                                         p_idusuario, p_cancelamentoexclusao);
        end loop;
      else
        for sep in (select s.*
                      from sepespporloteindustria s, seploteindsepespecif sl
                     where s.idsepespporloteindustria = sl.idseploteind
                       and sl.idlote = p_idlote
                       and not exists (select 1
                              from nfdet nd, notafiscal nf
                             where 1 = 1
                               and nd.idnfdet = s.idnfdet
                               and nf.idnotafiscal = nd.nf
                               and nf.statusnf = 'P'))
        
        loop
          if (v_agruparlotes = 1 or sep.idnfcobertura is null) then
            desvincLoteIndSepEspecifica(p_idusuario, sep.idnfdet,
                                        sep.loteindustria,
                                        p_cancelamentoexclusao);
          elsif (v_agruparlotes = 2) then
            desvincLoteIndSepEspecificaCob(p_idusuario, sep.idnfdet,
                                           sep.loteindustria,
                                           sep.idnfcobertura,
                                           p_cancelamentoexclusao);
          end if;
        end loop;
      end if;
    end if;
  end desvincPorLote;

end pk_separacaoespecifica;
/

