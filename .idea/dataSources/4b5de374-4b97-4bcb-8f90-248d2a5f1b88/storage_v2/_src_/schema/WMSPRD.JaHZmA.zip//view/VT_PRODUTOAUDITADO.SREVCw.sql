create view VT_PRODUTOAUDITADO as
select pa.barra, p.descr produto, pa.quantidadeconferida conferido,
       pa.quantidadedovolume emvolume, pa.quantidadeexcedida excedida,
       pa.quantidadefaltando faltando,
       pa.idauditoriavolume H$idauditoriavolume,
       c.confirmaqtdeauditoria H$confirmaqtdeauditoria,
       pa.quantidadeliberada H$quantidadeliberada,
       nf.iddepositante h$iddepositante,
       nf.idarmazem h$idarmazem, pa.id h$tableid
  from produtoauditado pa, produto p, auditoriavolume a, volumeromaneio v,
       romaneiopai o, configuracaoonda c, notafiscal nf
 where pa.idproduto = p.idproduto
   and a.id = pa.idauditoriavolume
   and v.idvolumeromaneio = a.idvolumeromaneio
   and o.idromaneio = v.idromaneio
   and c.idconfiguracaoonda = o.idconfiguracaoonda
   and nf.idnotafiscal = v.idnotafiscal
/

