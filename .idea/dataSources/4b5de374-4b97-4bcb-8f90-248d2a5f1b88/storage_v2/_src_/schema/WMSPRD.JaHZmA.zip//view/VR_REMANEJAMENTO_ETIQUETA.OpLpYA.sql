create view VR_REMANEJAMENTO_ETIQUETA as
select distinct r.idremanejamento, ao.descr armazemorigem,
                lo.idlocalformatado idlocalorigem,
                ld.idlocalformatado idlocaldestino,
                p.codigointerno || ' - ' || p.descr produto,
                (select trim(stragg(decode(e.fatorconversao, 1,
                                             sum(lr.qtde / e.fatorconversao) || ' ' ||
                                              e.descrreduzido,
                                             '  ' ||
                                              sum(lr.qtde / e.fatorconversao) || ' ' ||
                                              e.descrreduzido || ' [F:' ||
                                              e.fatorconversao || '] '))) etiqueta
                    from loteremanejamento lr, lote l, embalagem e
                   where lr.idremanejamento = r.idremanejamento
                     and l.idlote = lr.idlote
                     and l.idproduto = p.idproduto
                     and e.idproduto = l.idproduto
                     and e.barra = l.barra
                   group by e.fatorconversao, e.descrreduzido) qtdetotal
  from remanejamento r, armazem ao, loteremanejamento lr, lote l, produto p,
       local lo, local ld
 where ao.idarmazem = r.idarmazemorigem
   and lr.idremanejamento = r.idremanejamento
   and l.idlote = lr.idlote
   and p.idproduto = l.idproduto
   and lo.idlocal = r.idlocalorigem
   and lo.idarmazem = r.idarmazemorigem
   and ld.idlocal = r.idlocaldestino
   and ld.idarmazem = r.idarmazemdestino
/

