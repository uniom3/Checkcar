create package body pk_servico is

  function getValorUnitarioKit(p_idordemservico in number) return number is
    v_valorLote   number;
    v_qtdeLote    number;
    v_vlrUnitComp number;
    v_vlrUnitKit  number := 0;
  begin
    for r_LoteOrigem in (select lt.idlote, lt.valorlote, lt.idproduto,
                                (lt.qtdeentrada * elt.fatorconversao) qtdeentrada,
                                (kp.qtde * ek.fatorconversao) qtdeKit
                           from ordemservico os, paletseparacao ps, lote lt,
                                ordemproduto op, kitproduto kp, embalagem ek,
                                embalagem elt
                          where os.idordemservico = p_idordemservico
                            and os.idromaneio = ps.idromaneio
                            and ps.idlote = lt.idlote
                            and os.idordemservico = op.idordemservico
                            and op.idproduto = kp.idprodutokit
                            and lt.idproduto = kp.idproduto
                            and kp.idproduto = ek.idproduto
                            and kp.barra = ek.barra
                            and lt.idproduto = elt.idproduto
                            and lt.barra = elt.barra)
    loop
      if nvl(r_LoteOrigem.Valorlote, 0) > 0 then
        v_valorLote := r_LoteOrigem.Valorlote;
        v_qtdeLote  := v_qtdeLote + r_LoteOrigem.Qtdeentrada;
      else
        v_valorLote := pk_lote.getValorComposicaoLote(r_LoteOrigem.Idlote,
                                                      v_qtdeLote,
                                                      r_LoteOrigem.Idproduto);
      end if;
      if (v_qtdeLote = 0) then
        v_vlrUnitComp := 0;
      else
        v_vlrUnitComp := v_valorLote / v_qtdeLote;
      end if;
    
      v_vlrUnitKit := v_vlrUnitKit + (r_LoteOrigem.Qtdekit * v_vlrUnitComp);
    end loop;
    return round(v_vlrUnitKit, 6);
  end getValorUnitarioKit;

  procedure gerarSeparacaoEspecifica
  (
    p_idNotafiscal   in number,
    p_idOrdemServico in number,
    p_idArmazem      in number,
    p_idUsuario      in number
  ) is
  begin
    for c_lotes in (select g.*
                      from gtt_separacaoespecificainv g
                     where g.idos = p_idOrdemServico
                     order by g.idlote, g.idlocal)
    loop
    
      insert into separacaoespecifica
        (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual,
         fonteseparacao, idusuario, dtvinculo)
      values
        (p_idArmazem, c_lotes.idlocal, c_lotes.idlote, p_idNotafiscal,
         c_lotes.quantidade, 'N', 0, p_idUsuario, sysdate);
    end loop;
  
  end gerarSeparacaoEspecifica;

  function getValorUnitarioComponente
  (
    p_idlote    in number,
    p_idproduto in number
  ) return number is
    v_valorLote number := 0;
    v_qtdeLote  number := 0;
  begin
  
    for r_loteOrigem in (select l.idlote, l.valorlote, l.idproduto,
                                (l.qtdeentrada * e.fatorconversao) qtdeentrada
                           from orlote_origem o, lote l, embalagem e
                          where o.idlote = p_idlote
                            and l.idproduto = p_idproduto
                            and l.idlote = o.idlote_origem
                            and l.idproduto = e.idproduto
                            and l.barra = e.barra)
    loop
      if nvl(r_loteOrigem.Valorlote, 0) > 0 then
        v_valorLote := v_valorLote + r_loteOrigem.Valorlote;
        v_qtdeLote  := v_qtdeLote + r_loteOrigem.Qtdeentrada;
      else
        v_valorLote := v_valorLote +
                       pk_lote.getValorComposicaoLote(r_loteOrigem.Idlote,
                                                      v_qtdeLote,
                                                      r_loteOrigem.Idproduto);
      end if;
    end loop;
  
    if v_qtdeLote = 0 then
      return 0;
    end if;
  
    return round(v_valorLote / v_qtdeLote, 6);
  end getValorUnitarioComponente;

  procedure processar_kitproduto
  (
    p_idordemservico   in ordemservico.idordemservico%type,
    p_usuario          in usuario.idusuario%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  ) is
    posicao              number;
    v_msg                t_message;
    v_msgGrupo           t_message;
    v_gerarLoteIndustria number := 0;
    v_msgErro            tErro;
    listErroCorte        tListaErro := tListaErro();
  
    cursor c_comps(p_os in ordemservico.idordemservico%type) is
      select k.idproduto, sum(op.qtde * k.qtde * e.fatorconversao) qtde
        from ordemproduto op, kitproduto k, embalagem e
       where op.idordemservico = p_os
         and k.idprodutokit = op.idproduto
         and e.barra = k.barra
         and e.idproduto = k.idproduto
       group by k.idproduto
       order by k.idproduto;
  
    cursor c_receita(p_os in ordemservico.idordemservico%type) is
      select os.idordemservico, k.idprodutokit, k.idproduto, k.barra, k.qtde,
             os.idarmazem
        from ordemservico os, ordemproduto op, kitproduto k
       where os.idordemservico = p_os
         and op.idordemservico = os.idordemservico
         and k.idprodutokit = op.idproduto;
  
    cursor c_kits(p_os in ordemservico.idordemservico%type) is
      select op.idproduto, op.qtde, p.descr produto
        from ordemproduto op, produto p
       where op.idordemservico = p_os
         and p.idproduto = op.idproduto;
  
    cursor c_est
    (
      p_os            in number,
      p_idarmazem     in number,
      p_iddepositante in number,
      p_sepesp        in char
    ) is
      select a.idproduto, a.codigointerno, a.descr, nvl(a.qtde, 0) qtde,
             a.iddepositante, a.estado, nvl(a.disp, 0) disp
        from (select p.idproduto, p.codigointerno, p.descr, lib.qtde,
                      lib.iddepositante, lib.estado,
                      (sum(est.disp) -
                       ABS((sum(est.disp) -
                            pk_utilities.retorna_valormenor(sum(est.disp),
                                                             nvl(ll.qtdedisponivel,
                                                                  0))))) +
                       lib.qtde disp
                 from (select os.identidade iddepositante, k.idproduto,
                               'N' estado, os.idarmazem,
                               sum(op.qtde * k.qtde * e.fatorconversao) qtde
                          from ordemservico os, ordemproduto op, kitproduto k,
                               embalagem e
                         where os.idordemservico = p_os
                           and op.idordemservico = os.idordemservico
                           and k.idprodutokit = op.idproduto
                           and e.barra = k.barra
                           and e.idproduto = k.idproduto
                         group by os.identidade, k.idproduto, os.idarmazem,
                                  os.separacaoespec) lib,
                      (select lt.iddepositante, lt.idproduto, lt.estado,
                               sum(nvl(lt.qtdedisponivel, 0)) qtdedisponivel
                          from ordemproduto op, kitproduto kp, lote lt,
                               embalagem em
                         where op.idordemservico = p_os
                           and kp.idprodutokit = op.idproduto
                           and lt.idproduto = kp.idproduto
                           and lt.iddepositante = p_iddepositante
                           and lt.tipolote = 'L'
                           and lt.liberado = 'S'
                           and em.idproduto = lt.idproduto
                           and em.barra = lt.barra
                         group by lt.iddepositante, lt.idproduto, lt.estado) ll,
                      (select est.iddepositante, est.idproduto, est.estadolote,
                               sum(est.disp) disp, sum(est.adicionar) adicionar
                          from ordemproduto op, kitproduto kp,
                               v_estoque_local est, depositante d,
                               ordemservico os
                         where op.idordemservico = p_os
                           and kp.idprodutokit = op.idproduto
                           and est.idproduto = kp.idproduto
                           and est.iddepositante = p_iddepositante
                           and est.loteliberado = 'S'
                           and est.idarmazem = p_idarmazem
                           and nvl(est.estadolote, 'N') = 'N'
                           and nvl(est.localativo, 'N') = 'S'
                           and d.identidade = est.iddepositante
                           and os.idordemservico = op.idordemservico
                           and nvl(est.picking, 'N') like
                               decode(os.idconfiguracaoonda, null,
                                      (decode(nvl(p_sepesp, 'N'), 'S', 'N',
                                               decode(nvl(d.usapicking, 'S'), 'S',
                                                       'S', '%'))), '%')
                           and est.idsetor not in
                               (select idsetor
                                  from setorrecebimento
                                 where idtiporecebimento in
                                       (select idtiporecebimento
                                          from tiporecebimento
                                         where classificacao = 'R'))
                           and est.idlotemont is null
                         group by est.iddepositante, est.idproduto,
                                  est.estadolote) est, produto p
                where est.iddepositante(+) = lib.iddepositante
                  and est.idproduto(+) = lib.idproduto
                  and est.estadolote(+) = lib.estado
                  and ll.iddepositante(+) = lib.iddepositante
                  and ll.idproduto(+) = lib.idproduto
                  and ll.estado(+) = lib.estado
                  and p.idproduto(+) = lib.idproduto
                group by p.idproduto, p.codigointerno, p.descr, lib.qtde,
                         lib.idproduto, lib.iddepositante, lib.estado,
                         nvl(ll.qtdedisponivel, 0)) a
       where 1 = 1
         and nvl(a.disp, 0) <= 0;
  
    cursor c_romaneio(p_romaneio in romaneiopai.idromaneio%type) is
      select r.*
        from romaneiopai r
       where r.idromaneio = p_romaneio;
  
    cursor c_tiporec is
      select min(t.idtiporecebimento) idtiporecebimento
        from tiporecebimento t
       where t.classificacao = C_MOVINTERNO;
  
    cursor c_doca(p_armazem in armazem.idarmazem%type) is
      select min(d.iddoca) iddoca
        from doca d
       where d.idarmazem = p_armazem;
  
    type t_os is record(
      idordemservico              ordemservico.idordemservico%type,
      tiposervico                 ordemservico.tiposervico%type,
      idarmazem                   ordemservico.idarmazem%type,
      situacao                    ordemservico.situacao%type,
      separacaoespec              ordemservico.separacaoespec%type,
      iddoca                      ordemservico.iddoca%type,
      identidade                  ordemservico.identidade%type,
      agruparinclusaolotes        depositante.agruparinclusaolotes%type,
      controlefiscalkitcomponente depositante.controlefiscalkitcomponente%type,
      garantirumvencloteindkit    depositante.garantirumvencloteindkit%type,
      idconfiguracaoonda          ordemservico.idconfiguracaoonda%type,
      idunidade                   armazem.identidade%type,
      utilizakitsestojamentoonda  armazem.utilizakitsestojamentoonda%type);
  
    r_os t_os;
  
    r_comps             c_comps%rowtype;
    r_receita           c_receita%rowtype;
    r_est               c_est%rowtype;
    r_nf                notafiscal%rowtype;
    r_nfdet             nfdet%rowtype;
    r_romaneio          c_romaneio%rowtype;
    r_lotenf            lotenf%rowtype;
    r_tiporec           c_tiporec%rowtype;
    r_doca              c_doca%rowtype;
    r_kits              c_kits%rowtype;
    v_obrigaremetenteor char(1);
    v_separacaoespec    varchar2(20);
  
    procedure qtdeGeradaKitsMesmoLoteInd
    (
      p_idOrdemServico   in number,
      p_idRomaneio       in number,
      p_tipokitsmontados out number,
      p_kitsmontados     out number
    ) is
    
      type t_kit is record(
        idarmazem     paletseparacao.idarmazem%type,
        idromaneio    paletseparacao.idromaneio%type,
        loteindustria lote.descr%type,
        dtvencimento  lote.dtvenc%type,
        idproduto     paletseparacao.idproduto%type,
        qtdeitem      paletseparacao.qtde%type);
    
      type def_kit_aux is table of t_kit;
      tabela_kit def_kit_aux := def_kit_aux();
    
      v_qtkitmontado number := 0;
      v_qtdekit      number := 0;
      v_qtdekittot   number := 0;
      v_existe       number := 1; -- 1 true, 0 false
      v_qtnaomontado number := 0;
    
    begin
    
      insert into gtt_lote_kit
        (idarmazem, idromaneio, loteindustria, dtvencimento, idproduto,
         qtde, qtdeutilizada, disponivel)
        select p.idarmazem, p.idromaneio, l.descr, l.dtvenc, p.idproduto,
               sum(p.qtdeunit) qtde, 0 qtdeutl, sum(p.qtdeunit) disponivel
          from paletseparacao p, lote l
         where p.idlote = l.idlote
           and p.idromaneio = p_idRomaneio
         group by p.idarmazem, p.idromaneio, l.descr, l.dtvenc, p.idproduto;
    
      for reg in (select idproduto, qtde
                    from ordemproduto
                   where idordemservico = p_idOrdemServico)
      loop
        v_qtdekittot := reg.qtde;
        v_qtdekit    := v_qtdekittot;
      
        if v_qtdekittot > 1 then
        
          while v_qtdekit > 0
          loop
          
            v_existe := 1;
            for reg1 in (select idproduto, qtde
                           from kitproduto
                          where idprodutokit = reg.idproduto)
            loop
              tabela_kit.extend(1);
              begin
                select x.idarmazem, x.idromaneio, x.loteindustria,
                       x.dtvencimento, x.idproduto, x.qtde, x.existe
                  into tabela_kit(tabela_kit.last).idarmazem,
                       tabela_kit(tabela_kit.last).idromaneio,
                       tabela_kit(tabela_kit.last).loteindustria,
                       tabela_kit(tabela_kit.last).dtvencimento,
                       tabela_kit(tabela_kit.last).idproduto,
                       tabela_kit(tabela_kit.last).qtdeitem, v_existe
                  from (select gtt.idarmazem, gtt.idromaneio,
                                gtt.loteindustria, gtt.dtvencimento,
                                gtt.idproduto, reg1.qtde,
                                (CASE
                                   WHEN gtt.disponivel < reg1.qtde THEN
                                    0 -- true
                                   ELSE
                                    v_existe
                                 END) as existe
                           from gtt_lote_kit gtt
                          where gtt.idromaneio = p_idRomaneio
                            and gtt.idproduto = reg1.idproduto
                            and gtt.disponivel > 0
                          order by gtt.qtde desc) x
                 where rownum = 1;
              exception
                when no_data_found then
                  v_existe := 0;
              end;
            
            end loop;
          
            if v_existe = 1 then
            
              for i in tabela_kit.first .. tabela_kit.last
              loop
                update gtt_lote_kit
                   set disponivel    = nvl(disponivel, 0) - tabela_kit(i)
                                      .qtdeitem,
                       qtdeutilizada = nvl(qtdeutilizada, 0) + tabela_kit(i)
                                      .qtdeitem
                 where idarmazem = tabela_kit(i).idarmazem
                   and idromaneio = tabela_kit(i).idromaneio
                   and loteindustria = tabela_kit(i).loteindustria
                   and dtvencimento = tabela_kit(i).dtvencimento
                   and idproduto = tabela_kit(i).idproduto;
              end loop;
            
              v_qtkitmontado := v_qtkitmontado + 1;
            
              tabela_kit.trim(tabela_kit.COUNT); --limpa o registro
            
              v_qtdekit := v_qtdekit - 1;
            
            else
              tabela_kit.trim(tabela_kit.COUNT); --limpa o registro
              exit;
            end if;
          
          end loop;
        
          v_qtnaomontado := reg.qtde - v_qtkitmontado;
        
        else
          v_qtkitmontado := 1;
        end if;
      
      end loop;
    
      if v_qtdekittot = v_qtkitmontado then
        p_tipokitsmontados := 2;
        p_kitsmontados     := v_qtdekittot;
      elsif v_qtkitmontado = 0 then
        p_tipokitsmontados := 0;
        p_kitsmontados     := 0;
      else
        p_tipokitsmontados := 1;
        p_kitsmontados     := v_qtkitmontado;
      end if;
    end;
  
    procedure carregarOrdemServico is
    begin
      begin
        select os.idordemservico, os.tiposervico, os.idarmazem, os.situacao,
               nvl(os.separacaoespec, 'N') separacaoespec, os.iddoca,
               os.identidade, d.agruparinclusaolotes,
               d.controlefiscalkitcomponente, d.garantirumvencloteindkit,
               os.idconfiguracaoonda, a.identidade,
               a.utilizakitsestojamentoonda
          into r_os.idordemservico, r_os.tiposervico, r_os.idarmazem,
               r_os.situacao, r_os.separacaoespec, r_os.iddoca,
               r_os.identidade, r_os.agruparinclusaolotes,
               r_os.controlefiscalkitcomponente,
               r_os.garantirumvencloteindkit, r_os.idconfiguracaoonda,
               r_os.idunidade, r_os.utilizakitsestojamentoonda
          from ordemservico os, depositante d, armazem a
         where idordemservico = p_idordemservico
           and d.identidade = os.identidade
           and a.idarmazem = os.idarmazem(+)
           for update;
      exception
        when no_data_found then
          v_msg := t_message('OS: {0}, NAO ENCONTRADA');
          v_msg.addParam(p_idordemservico);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      select decode(r_os.separacaoespec, 'N', 'PICKING', 'PULMÃO')
        into v_separacaoespec
        from dual;
    end carregarOrdemServico;
  
    procedure consultaGerarLoteIndustria is
    begin
      select (case
                when os.tiposervico = C_ESTOJAMENTO then
                 d.criarloteindestojamento
                when os.tiposervico = C_KIT_COM_RASTREABILIDADE then
                 d.criarltindustriaespvenckit
                else
                 0
              end)
        into v_gerarLoteIndustria
        from ordemservico os, depositante d
       where os.identidade = d.identidade
         and os.idordemservico = p_idordemservico;
    end consultaGerarLoteIndustria;
  
    procedure validarOrdemServico is
      C_LOTEINDUST_POR_NFCOBERTURA constant number := 2;
    begin
      if r_os.tiposervico not in (C_KIT, C_KIT_COM_RASTREABILIDADE) then
        v_msg := t_message('OS: {0}, NAO E DO TIPO PARA FORMAR KIT');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.idarmazem is null then
        v_msg := t_message('OS: {0}, NAO POSSUI ARMAZEM SELECIONADO');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.situacao = C_PROCESSADO then
        v_msg := t_message('OS: {0}, JA PROCESSADA');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.agruparinclusaolotes = C_LOTEINDUST_POR_NFCOBERTURA then
        v_msg := t_message('O depositante está com o parâmetro <b>Inclusão de estoque na Separação Específica</b> ' ||
                           'configurado como <b>Por Lote Indústria Listando NF Cobertura</b>. Não é possível gerar Ordem de Serviço. ' ||
                           'Operação cancelada!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarOrdemServico;
  
  begin
  
    carregarOrdemServico;
  
    consultaGerarLoteIndustria;
  
    validarOrdemServico;
  
    if c_comps%isopen then
      close c_comps;
    end if;
    open c_comps(p_idordemservico);
    fetch c_comps
      into r_comps;
  
    -- Verifica se existem kits na OS
    if c_comps%notfound then
      v_msg := t_message('OS: {0}, NAO POSSUI KIT CADASTRADO');
      v_msg.addParam(p_idordemservico);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if c_est%isopen then
      close c_est;
    end if;
    open c_est(p_idordemservico, r_os.idarmazem, r_os.identidade,
               r_os.separacaoespec);
    fetch c_est
      into r_est;
  
    --Verifica estoque dos componentes
    if c_est%notfound then
    
      -- Grava o cadastro de como o kit eh composto
      if c_receita%isopen then
        close c_receita;
      end if;
      open c_receita(p_idordemservico);
      fetch c_receita
        into r_receita;
      while c_receita%found
      loop
        insert into ordemkit
          (idordemservico, idprodutokit, idproduto, barra, qtde)
        values
          (r_receita.idordemservico, r_receita.idprodutokit,
           r_receita.idproduto, r_receita.barra, r_receita.qtde);
        fetch c_receita
          into r_receita;
      end loop;
      -- ** Saida dos componentes **
      -- Insere NF saida
      r_nf.codigointerno := '-1';
      r_nf.sequencia     := 'AJUSTE-KIT';
      r_nf.usuario       := p_usuario;
      r_nf.remetente     := r_os.idunidade;
      r_nf.destinatario  := r_os.idunidade;
      r_nf.dataemissao   := sysdate;
      r_nf.statusnf      := 'N';
      r_nf.digitada      := C_NAO;
      r_nf.impresso      := C_SIM;
      r_nf.ident_entrega := r_os.idunidade;
      r_nf.tipo          := C_SAIDA;
      r_nf.iddepositante := r_os.identidade;
      r_nf.movestoque    := C_SIM;
      r_nf.docinterno    := 1;
      r_nf.idarmazem     := r_os.idarmazem;
    
      if r_os.idconfiguracaoonda is not null then
        r_nf.estoqueverificado        := C_NAO;
        r_nf.statusroteirizacao       := 0;
        r_nf.transportadoranotafiscal := r_os.identidade;
        select o.idoperacao
          into r_nf.idoperacao
          from operacao o
         where o.tipo = 'S'
           and o.tipooper is null
           and rownum = 1;
      else
        r_nf.estoqueverificado  := C_SIM;
        r_nf.statusroteirizacao := 2;
      end if;
    
      r_nf.idnotafiscal := pk_notafiscal.insere_cabecalho_nf(r_nf);
    
      update notafiscal
         set codigointerno = r_nf.idnotafiscal
       where idnotafiscal = r_nf.idnotafiscal;
    
      -- Insere Itens da NF de saida
      while c_comps%found
      loop
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := r_nf.idnotafiscal;
        r_nfdet.barra            := pk_produto.ret_codbarra(r_comps.idproduto,
                                                            1);
        r_nfdet.idproduto        := r_comps.idproduto;
        r_nfdet.precounitliquido := 0;
        r_nfdet.qtde             := r_comps.qtde;
        r_nfdet.qtdeatendida     := r_comps.qtde;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
        fetch c_comps
          into r_comps;
      end loop;
    
      pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
      -- passa para processado pq senao nao pega o estoque na separacao especifica
      update ordemservico
         set situacao           = 'X',
             gerarloteindustria = v_gerarLoteIndustria
       where idordemservico = r_os.idordemservico;
    
      -- Inclui separacao especifica
      if r_os.separacaoespec = 'S'
         and r_os.idconfiguracaoonda is null then
        IncluirSeparacaoEspecifica(r_nf.idnotafiscal);
      end if;
    
      -- Verifica se a expedição de kit é formada por romaneio ou onda
      if r_os.utilizakitsestojamentoonda = 1 then
        --gerar separação específica dos lote gerados por inventário de estojo
        gerarSeparacaoEspecifica(r_nf.idnotafiscal, r_os.idordemservico,
                                 r_os.idarmazem, p_usuario);
      
        update notafiscal nf
           set nf.statusroteirizacao = 1,
               nf.estoqueverificado  = C_SIM
         where nf.idnotafiscal = r_nf.idnotafiscal;
      
        formarOndaOrdemServico(r_romaneio.idromaneio,
                               r_os.idconfiguracaoonda, r_os.idOrdemServico,
                               r_os.tiposervico, r_nf.idnotafiscal,
                               p_usuario);
      
        if ((r_os.controlefiscalkitcomponente =
           C_REALIZA_CONTROLE_FISCAL_KIT) or
           (r_os.garantirumvencloteindkit = C_GARANTIR_UM_VENCLOTEIND_KIT)) then
          /*Esperado que quando utiliza controlefiscalkitcomponente não tenha mais de uma linha em ordemproduto*/
          validarMisturaLoteIndOnda(r_os.idOrdemServico,
                                    r_romaneio.idromaneio, r_os.tiposervico,
                                    p_tipokitsmontados, p_kitsmontados);
        
          if p_tipokitsmontados <> 2 then
            return;
          end if;
        else
          p_tipokitsmontados := 2;
        end if;
      
      else
        -- Inseri Romaneio dos componentes
        r_romaneio.placa       := pk_veiculo.pegaveiculopadrao;
        r_romaneio.idusuario   := p_usuario;
        r_romaneio.idarmazem   := r_os.idarmazem;
        r_romaneio.iddoca      := r_os.iddoca;
        r_romaneio.datageracao := sysdate;
      
        if (r_os.tiposervico = C_KIT) then
          r_romaneio.tituloromaneio := 'SAIDA PARA FORMACAO DE KIT N:' ||
                                       r_os.idordemservico;
        end if;
      
        if (r_os.tiposervico = C_KIT_COM_RASTREABILIDADE) then
          r_romaneio.tituloromaneio := 'SAIDA PARA FORMACAO DE KIT COM RASTREABILIDADE N:' ||
                                       r_os.idordemservico;
        end if;
      
        r_romaneio.faturado   := C_SIM;
        r_romaneio.coletado   := C_SIM;
        r_romaneio.idromaneio := pk_romaneio.inserir_romaneiopai(r_romaneio);
        -- Vincula NF ao romaneio
        insert into nfromaneio
          (idromaneio, idnotafiscal, sequencia)
        values
          (r_romaneio.idromaneio, r_nf.idnotafiscal, 1);
        -- Forma Romaneio dos componentes
        pk_romaneio.formar_romaneio(r_romaneio.idromaneio, p_usuario, C_NAO,
                                    C_NAO);
      
        if ((r_os.controlefiscalkitcomponente =
           C_REALIZA_CONTROLE_FISCAL_KIT) or
           (r_os.garantirumvencloteindkit = C_GARANTIR_UM_VENCLOTEIND_KIT)) then
        
          qtdeGeradaKitsMesmoLoteInd(p_idordemservico,
                                     r_romaneio.idromaneio,
                                     p_tipokitsmontados, p_kitsmontados);
        
          if p_tipokitsmontados <> 2 then
            return;
          end if;
        else
          p_tipokitsmontados := 2;
        end if;
      
      end if;
    
      -- atualiza a ordem de servico para que ao formar romaneio a rotina possa identificar que o romaneio eh de kit
      -- e nco gerar remanejamento
      update ordemservico
         set idromaneio = r_romaneio.idromaneio
       where idordemservico = p_idordemservico;
    
      -- Carrega romaneio
      if c_romaneio%isopen then
        close c_romaneio;
      end if;
      open c_romaneio(r_romaneio.idromaneio);
      fetch c_romaneio
        into r_romaneio;
    
      -- Verifica se tem corte de formacao do romaneio
      if r_romaneio.erro <> C_ERRO then
      
        -- Verifica se a formacao foi concluida com sucesso
        if r_romaneio.gerado <> C_SEPARACAO then
          v_msg := t_message('HOUVE ERRO NA FORMACAO DO ROMANEIO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        -- Fatura o romaneio
        update romaneiopai
           set faturado = C_FATURADO
         where idromaneio = r_romaneio.idromaneio;
      
        -- se a configuração de onda está vazia e o parametro de formar com onda está desabilitado
        if r_os.utilizakitsestojamentoonda = 0 then
          -- Gera a conferencia de saida
          pk_confsaida.gerarcontagem(r_romaneio.idromaneio, p_usuario);
          -- Processa o romaneio
          pk_romaneio.processar_romaneio(r_romaneio.idromaneio, p_usuario);
        end if;
      
        -- ** Entrada dos compostos **
        -- Insere NF entrada
        r_nf.tipo               := C_ENTRADA;
        r_nf.estoqueverificado  := null;
        r_nf.statusroteirizacao := 2;
        r_nf.idnotafiscal       := pk_notafiscal.insere_cabecalho_nf(r_nf);
      
        update notafiscal
           set codigointerno = r_nf.idnotafiscal
         where idnotafiscal = r_nf.idnotafiscal;
      
        if c_kits%isopen then
          close c_kits;
        end if;
        open c_kits(p_idordemservico);
        fetch c_kits
          into r_kits;
      
        -- Insere Itens da NF de entrada
        while c_kits%found
        loop
          r_nfdet.idnfdet          := null;
          r_nfdet.nf               := r_nf.idnotafiscal;
          r_nfdet.barra            := pk_produto.retornar_codbarra(r_kits.idproduto,
                                                                   1);
          r_nfdet.idproduto        := r_kits.idproduto;
          r_nfdet.precounitliquido := getValorUnitarioKit(p_idordemservico);
          r_nfdet.qtde             := r_kits.qtde;
          r_nfdet.qtdeatendida     := r_kits.qtde;
          if r_nfdet.barra is null then
            v_msg := t_message('Material "{0}" nao possui codigo de barras de fator 1 cadastrado ou ativo.' ||
                               chr(13) || 'Operagco Cancelada');
            v_msg.addParam(r_kits.produto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
          pk_notafiscal.insere_detalhe_nf(r_nfdet);
          fetch c_kits
            into r_kits;
        end loop;
      
        pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
        if c_tiporec%isopen then
          close c_tiporec;
        end if;
        open c_tiporec;
        fetch c_tiporec
          into r_tiporec;
      
        if c_tiporec%notfound then
          v_msg := t_message('TIPO DE RECEBIMENTO NAO CADASTRADO PARA FORMACAO DE KIT');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if c_doca%isopen then
          close c_doca;
        end if;
        open c_doca(r_os.idarmazem);
        fetch c_doca
          into r_doca;
      
        if c_doca%notfound then
          v_msg := t_message('NENHUMA DOCA ENCONTRADA PARA O ARMAZEM SELECIONADO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        -- Insere a OR
        if r_tiporec.idtiporecebimento is null then
          v_msg := t_message('TIPO DE RECEBIMENTO DE OPERAÇÕES INTERNAS NÃO CADASTRADO. OPERAÇÃO CANCELADA.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select d.obrigaremetenteor
          into v_obrigaremetenteor
          from depositante d
         where d.identidade = r_os.identidade;
      
        r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
        r_lotenf.descr             := 'FORMACAO DE KIT N: ' ||
                                      r_os.idordemservico;
        r_lotenf.data              := sysdate;
        r_lotenf.idusuario         := p_usuario;
        r_lotenf.idarmazem         := r_os.idarmazem;
        r_lotenf.iddoca            := r_doca.iddoca;
        r_lotenf.identidade        := r_os.identidade;
        r_lotenf.modal             := 0;
      
        if v_obrigaremetenteor = 'S' then
          r_lotenf.idremetente := r_os.idunidade;
        end if;
      
        r_lotenf.idlotenf := pk_recebimento.cadastrar_OR(r_lotenf);
        -- Inserir NF a OR
        update notafiscal
           set idlotenf = r_lotenf.idlotenf
         where idnotafiscal = r_nf.idnotafiscal;
        -- Atualiza as informagues na ordemservico
        update ordemservico
           set idromaneio        = r_romaneio.idromaneio,
               idlotenf          = r_lotenf.idlotenf,
               dataprocessamento = sysdate,
               situacao          = C_PROCESSADO
         where idordemservico = r_os.idordemservico;
      
        pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
      
      else
        v_msgGrupo := t_message('HOUVE CORTE NA FORMACAO DO ROMANEIO.');
      
        for c_corte in (select p.codigointerno, p.descr produto,
                               sum(c.qtdepedido) qtdepedido,
                               nvl(c.qtdedisponivelpk, 0) qtdedisponivelpk,
                               nvl(c.qtdedisponivelpl, 0) qtdedisponivelpl
                          from corteromaneio c, produto p
                         where p.idproduto = c.idproduto
                           and c.idromaneio = r_romaneio.idromaneio
                         group by p.codigointerno, p.descr,
                                  c.qtdedisponivelpk, c.qtdedisponivelpl
                        having sum(c.qtdepedido) > decode(r_os.separacaoespec, 'N', nvl(c.qtdedisponivelpk, 0), nvl(c.qtdedisponivelpl, 0)))
        loop
          v_msg := t_message('PRODUTO: {0} - {1} PEDIDO: {2} Disp.PK: {3} Disp.PL: {4}');
        
          v_msg.addParam(c_corte.codigointerno);
          v_msg.addParam(c_corte.produto);
          v_msg.addParam(c_corte.qtdepedido);
          v_msg.addParam(c_corte.qtdedisponivelpk);
          v_msg.addParam(c_corte.qtdedisponivelpl);
        
          v_msgErro.msgGrupo   := v_msgGrupo.formatMessage;
          v_msgErro.msgDetalhe := v_msg.formatMessage;
        
          listErroCorte.extend();
          posicao := listErroCorte.count;
          listErroCorte(posicao) := v_msgErro;
        end loop;
      
        listaErro := listErroCorte;
        raise_application_error(C_ERROCORTE,
                                'HOUVE CORTE NA FORMACAO DO ROMANEIO.');
      end if;
    else
    
      v_msgGrupo := t_message('PRODUTOS SEM QUANTIDADE DISPONIVEL EM ESTOQUE PARA OS LOCAIS DE {0}.');
      v_msgGrupo.addParam(v_separacaoespec);
    
      while c_est%found
      loop
        v_msg := t_message('PRODUTO: {0} - {1} QTDE: {2} ESTOQUE: {3}');
      
        v_msg.addParam(r_est.codigointerno);
        v_msg.addParam(r_est.descr);
        v_msg.addParam(rpad(substr(r_est.qtde, 1, 5), 5, ' '));
        v_msg.addParam(rpad(substr(r_est.disp, 1, 5), 5, ' '));
      
        v_msgErro.msgGrupo   := v_msgGrupo.formatMessage;
        v_msgErro.msgDetalhe := v_msg.formatMessage;
      
        listErroCorte.extend();
        posicao := listErroCorte.count;
        listErroCorte(posicao) := v_msgErro;
      
        fetch c_est
          into r_est;
      end loop;
      listaErro := listErroCorte;
      raise_application_error(C_ERROCORTE,
                              'PRODUTOS SEM QUANTIDADE DISPONIVEL EM ESTOQUE');
    end if;
  
  end;

  procedure excluir_os
  (
    p_idusuario      in number,
    p_idordemservico in number
  ) is
    cursor c_ordemservico(p_os in number) is
      select o.idordemservico, o.datacadastro, o.identidade, o.idusuario,
             o.idromaneio, o.idlotenf, o.situacao, o.tiposervico
        from ordemservico o
       where o.idordemservico = p_os;
    r_ordemservico c_ordemservico%rowtype;
    v_status       romaneiopai.processado%type;
    v_nfimpressao  number;
    v_orold        number;
    v_totalnf      number;
    v_msg          t_message;
  begin
    if c_ordemservico%isopen then
      close c_ordemservico;
    end if;
    open c_ordemservico(p_idordemservico);
    fetch c_ordemservico
      into r_ordemservico;
  
    if c_ordemservico%found then
      -- verificando situacão do romaneio
      if r_ordemservico.situacao in ('E', 'A') then
        if r_ordemservico.tiposervico in ('K', 'I') then
          if r_ordemservico.idlotenf is not null then
            v_orold := r_ordemservico.idlotenf;
            update ordemservico
               set idlotenf = null
             where idordemservico = p_idordemservico;
            pk_recebimento.desfazer_or(v_orold, r_ordemservico.idusuario);
          end if;
          if r_ordemservico.idromaneio is not null then
            select o.processado
              into v_status
              from romaneiopai o
             where o.idromaneio = r_ordemservico.idromaneio;
            if v_status = 'N' then
              select idprenf
                into v_nfimpressao
                from notafiscal nf, nfromaneio nr
               where nf.idnotafiscal = nr.idnotafiscal
                 and nr.idromaneio = r_ordemservico.idromaneio;
              update ordemservico
                 set idromaneio = null
               where idordemservico = p_idordemservico;
              pk_romaneio.desfazer_romaneio(r_ordemservico.idromaneio,
                                            r_ordemservico.idusuario, 'N');
              delete from nfimpressao
               where idprenf = v_nfimpressao;
            else
              v_msg := t_message('O Romaneio referente a esta OS foi processado.');
              raise_application_error(-20345, v_msg.formatMessage);
            end if;
          end if;
        
          -- verifica se existe alguma nota fiscal em quarentena
          select count(*)
            into v_totalnf
            from ordemprodutonotafiscal n
           where n.idordemservico = p_idordemservico
             and n.idnotafiscal is not null;
        
          if v_totalnf > 0 then
            v_msg := t_message('Exclusao nao permitida. Existe uma ou mais notas fiscais em quarentena. ' ||
                               chr(13) ||
                               'Retire elas da quarentena e tente novamente.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
        delete from ordemproduto
         where idordemservico = r_ordemservico.idordemservico;
      
        for c_lote in (select ol.idlote
                         from ordemlote ol
                        where ol.idordemservico =
                              r_ordemservico.idordemservico)
        loop
          for c_local in (select ll.idlocal, ll.idarmazem
                            from ordemservico os, ordemlote ol,
                                 v_estoque_local ll
                           where os.idordemservico =
                                 r_ordemservico.idordemservico
                             and ol.idordemservico = os.idordemservico
                             and ll.idlote = ol.idlote
                             and ll.iddepositante = os.identidade
                             and ll.idarmazem = os.idarmazem)
          loop
            update lote
               set liberado          = c_sim,
                   databloqueio      = null,
                   motivobloqueio    = null,
                   idusuariobloqueio = null
             where idlote = c_lote.idlote;
          
            delete from loteremanejamento lr
             where lr.idremanejamento in
                   (select r.idremanejamento
                      from remanejamento r
                     where r.idarmazemorigem = c_local.idarmazem
                       and r.idlocalorigem = c_local.idlocal
                       and r.status = c_aguardando);
          
            delete from remanejamento r
             where r.idarmazemorigem = c_local.idarmazem
               and r.idlocalorigem = c_local.idlocal
               and r.status = c_aguardando;
          end loop;
        end loop;
      
        delete from ordemlote
         where idordemservico = r_ordemservico.idordemservico;
      
        delete from ordemservico
         where idordemservico = r_ordemservico.idordemservico;
      else
        v_msg := t_message('Ordem de Serviço não pode ser excluida, pois ela não está em aberto.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
    if c_ordemservico%isopen then
      close c_ordemservico;
    end if;
    commit;
  
    pk_utilities.GeraLog(p_idusuario,
                         'Tela: Excluido Ordem de Serviço idOrdemServico: ' ||
                          p_idordemservico, p_idordemservico, 'CA');
  
  end;

  /*
   * Verifica se existe produtos vinculados a OS
  */
  function totalprodutosvinculados(p_ordemservico in number) return number is
    cursor c_ordprod(p_ordemservico in number) is
      select nvl(count(*), 0) valor
        from ordemproduto
       where idordemservico = p_ordemservico;
    r_ordprod c_ordprod%rowtype;
  
  begin
    if c_ordprod%isopen then
      close c_ordprod;
    end if;
    open c_ordprod(p_ordemservico);
    fetch c_ordprod
      into r_ordprod;
  
    close c_ordprod;
  
    return r_ordprod.valor;
  end;

  /*
   * Desvincuala OR da OS
  */
  procedure desvincularor
  (
    p_ordemservico in number,
    p_orold        in number,
    p_usuario      in number
  ) is
  begin
    update ordemservico
       set idlotenf = null
     where idordemservico = p_ordemservico;
    pk_recebimento.desfazer_or(p_orold, p_usuario);
  end;

  /*
   * Devincula Romaneio da OS
  */
  procedure desvincularromaneio
  (
    p_romaneio     in number,
    p_ordemservico in number,
    p_usuario      in number
  ) is
    cursor c_romapai(p_romaneio in number) is
      select o.processado
        from romaneiopai o
       where o.idromaneio = p_romaneio;
  
    cursor c_nfimp(p_romaneio in number) is
      select idprenf
        from notafiscal nf, nfromaneio nr
       where nf.idnotafiscal = nr.idnotafiscal
         and nr.idromaneio = p_romaneio;
  
    r_romapai c_romapai%rowtype;
    r_nfimp   c_nfimp%rowtype;
  
  begin
    if c_romapai%isopen then
      close c_romapai;
    end if;
    open c_romapai(p_romaneio);
    fetch c_romapai
      into r_romapai;
  
    if r_romapai.processado = C_NAO then
      if c_nfimp%isopen then
        close c_nfimp;
      end if;
      open c_nfimp(p_romaneio);
      fetch c_nfimp
        into r_nfimp;
    
      update ordemservico
         set idromaneio = null
       where idordemservico = p_ordemservico;
    
      pk_romaneio.desfazer_romaneio(p_romaneio, p_usuario, C_NAO);
    
      delete from nfimpressao
       where idprenf = r_nfimp.idprenf;
    
    end if;
  end;

  procedure vincularromaneio
  (
    p_placaveiculo in veiculo.placa%type,
    p_usuario      in number,
    p_armazem      in number,
    p_doca         in number,
    p_dtromaneio   in date,
    p_idos         in number
  ) is
    r_romaneio romaneiopai%rowtype;
  begin
    r_romaneio.placa          := p_placaveiculo;
    r_romaneio.idusuario      := p_usuario;
    r_romaneio.idarmazem      := p_armazem;
    r_romaneio.iddoca         := p_doca;
    r_romaneio.datageracao    := p_dtromaneio;
    r_romaneio.tituloromaneio := 'saida para formacao de kit n:' || p_idos;
    r_romaneio.faturado       := C_SIM;
    r_romaneio.coletado       := C_SIM;
    v_romaneio                := pk_romaneio.inserir_romaneiopai(r_romaneio);
  
    update ordemservico
       set idromaneio = v_romaneio
     where idordemservico = p_idos;
  
  end;

  procedure vincularnf
  (
    p_romaneio  in number,
    p_usuario   in number,
    p_entidade  in number,
    p_data      in date,
    p_os        in number,
    p_idarmazem in number := null
  ) is
    r_insnf notafiscal%rowtype;
    r_nfdet nfdet%rowtype;
  begin
    r_insnf.codigointerno      := p_romaneio;
    r_insnf.sequencia          := 'AJUSTE-KIT';
    r_insnf.usuario            := p_usuario;
    r_insnf.remetente          := p_entidade;
    r_insnf.destinatario       := p_entidade;
    r_insnf.dataemissao        := p_data;
    r_insnf.datacadastro       := sysdate;
    r_insnf.statusnf           := C_NAO;
    r_insnf.digitada           := C_NAO;
    r_insnf.impresso           := C_SIM;
    r_insnf.ident_entrega      := p_entidade;
    r_insnf.tipo               := C_SAIDA;
    r_insnf.iddepositante      := p_entidade;
    r_insnf.movestoque         := C_SIM;
    r_insnf.estoqueverificado  := C_SIM;
    r_insnf.statusroteirizacao := 2;
    r_insnf.idarmazem          := p_idarmazem;
    v_nf                       := pk_notafiscal.insere_cabecalho_nf(r_insnf);
    -- gera os itens da nf
    for c_ordemproduto in (select e.idproduto,
                                  pk_produto.ret_codbarra(e.idproduto, 1) barra,
                                  sum(o.qtde * k.qtde * e.fatorconversao) qtde
                             from ordemproduto o, kitproduto k, embalagem e
                            where o.idordemservico = p_os
                              and k.idprodutokit = o.idproduto
                              and e.idproduto = k.idproduto
                              and e.barra = k.barra
                            group by e.idproduto,
                                     pk_produto.ret_codbarra(e.idproduto, 1))
    loop
      r_nfdet.idnfdet          := null;
      r_nfdet.nf               := v_nf;
      r_nfdet.barra            := c_ordemproduto.barra;
      r_nfdet.idproduto        := c_ordemproduto.idproduto;
      r_nfdet.precounitliquido := 0;
      r_nfdet.qtde             := c_ordemproduto.qtde;
      r_nfdet.qtdeatendida     := c_ordemproduto.qtde;
      pk_notafiscal.insere_detalhe_nf(r_nfdet);
    end loop;
  
    -- gera a nf de impressao
    pk_notafiscal.p_gerar_nfimpressao(v_nf, 'N');
  
    insert into nfromaneio
      (idromaneio, idnotafiscal, sequencia)
    values
      (v_romaneio, v_nf, 1);
  end;

  procedure vincularor
  (
    p_os       in number,
    p_data     in date,
    p_usuario  in number,
    p_armazem  in number,
    p_doca     in number,
    p_entidade in number
  ) is
    cursor c_tiporec is
      select t.idtiporecebimento
        from tiporecebimento t
       where t.classificacao = c_interno
         and upper(Descr) like '%KIT%';
  
    r_tiporec c_tiporec%rowtype;
    r_lotenf  lotenf%rowtype;
    v_insnf   notafiscal%rowtype;
    v_nfent   number;
    v_msg     t_message;
    r_nfdet   nfdet%rowtype;
  begin
    -- tipo de recebimento
    if c_tiporec%isopen then
      close c_tiporec;
    end if;
    open c_tiporec;
    fetch c_tiporec
      into r_tiporec;
    if c_tiporec%notfound then
      v_msg := t_message('NAO FOI LOCALIZADO TIPO DE RECEBIMENTO REF. A AJUSTE DE ESTOOUE.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
    -- cadastra a OR
    --vincularor(p_os in number, p_data in date, p_usuario in number, p_armazem in number, p_doca in number,)
  
    r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
    r_lotenf.descr             := 'FORMACAO DE KIT N:' || p_os;
    r_lotenf.data              := p_data;
    --    r_lotenf.volume            := 1;
    r_lotenf.idusuario  := p_usuario;
    r_lotenf.idarmazem  := p_armazem;
    r_lotenf.iddoca     := p_doca;
    r_lotenf.identidade := p_entidade;
    v_lotenf            := pk_recebimento.cadastrar_OR(r_lotenf);
  
    update ordemservico
       set idlotenf = v_lotenf
     where idordemservico = p_os;
  
    -- insere o cabecalho e o detalhe da nf de entrada.
    v_insnf.idlotenf      := v_lotenf;
    v_insnf.codigointerno := v_lotenf;
    v_insnf.sequencia     := 'AJUSTE-KIT';
    v_insnf.usuario       := p_usuario;
    v_insnf.remetente     := p_entidade;
    v_insnf.destinatario  := p_entidade;
    v_insnf.dataemissao   := p_data;
    v_insnf.datacadastro  := sysdate;
    v_insnf.statusnf      := C_NORMAL;
    v_insnf.digitada      := C_NAO;
    v_insnf.impresso      := C_SIM;
    v_insnf.ident_entrega := p_entidade;
    v_insnf.tipo          := C_ENTRADA;
    v_insnf.iddepositante := p_entidade;
    v_insnf.movestoque    := C_SIM;
    v_nfent               := pk_notafiscal.insere_cabecalho_nf(v_insnf);
  
    -- gera os itens da nf
    for c_ordemproduto in (select op.idproduto,
                                  pk_produto.ret_codbarra(op.idproduto, 1) barra,
                                  op.qtde
                             from ordemproduto op
                            where op.idordemservico = p_os)
    
    loop
      if c_ordemproduto.barra is null then
        v_msg := t_message('PRODUTO SEM EMBALAGEM CADASTRADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      r_nfdet.idnfdet          := null;
      r_nfdet.nf               := v_nfent;
      r_nfdet.barra            := c_ordemproduto.barra;
      r_nfdet.idproduto        := c_ordemproduto.idproduto;
      r_nfdet.precounitliquido := 0;
      r_nfdet.qtde             := c_ordemproduto.qtde;
      r_nfdet.qtdeatendida     := c_ordemproduto.qtde;
      pk_notafiscal.insere_detalhe_nf(r_nfdet);
    end loop;
  
    -- gera a nf de impressao
    pk_notafiscal.p_gerar_nfimpressao(v_nfent, 'N');
    pk_recebimento.Atualizar_Produtos_OR(v_lotenf, 'N');
  
    if c_tiporec%isopen then
      close c_tiporec;
    end if;
  end;

  /*
   * Insere as informacoes na tabela ordemprodutonotafiscal
  */
  procedure InserirOrdemProdutoNotaFiscal(p_OrdemServicoNF in ordemprodutonotafiscal%rowtype) is
  begin
    insert into ordemprodutonotafiscal
      (idordemservico, idproduto, idnotafiscal, qtde)
    values
      (p_OrdemServicoNF.Idordemservico, p_OrdemServicoNF.Idproduto,
       p_OrdemServicoNF.idnotafiscal, p_OrdemServicoNF.qtde);
  exception
    when dup_val_on_index then
      update ordemprodutonotafiscal
         set qtde = qtde + p_OrdemServicoNF.qtde
       where idordemservico = p_OrdemServicoNF.idordemservico
         and idproduto = p_OrdemServicoNF.idproduto
         and idnotafiscal = p_OrdemServicoNF.idnotafiscal;
  end;

  /*
   * Rotina responsavel por gerar a ordem de produgco de kit para um produto
  */
  procedure GerarProducaoKit
  (
    p_idnotafiscal in number,
    p_depositante  in number,
    p_estado       lote.estado%type,
    p_idproduto    in number,
    p_qtde         in number,
    p_usuario      in number
  ) is
    cursor c_infkit
    (
      p_depositante in number,
      p_estado      in char,
      p_idproduto   in number
    ) is
      select p.idproduto, nvl(pd.qtdeminimaproducaokit, 0) qtdeminima,
             nvl(kit.qtdedisponivel, 0) qtdedisponivel
        from produto p, produtodepositante pd,
             (select kp.idprodutokit,
                      min(Trunc(kp.qtde / k.qtde)) qtdedisponivel
                 from (select kp.idprodutokit, kp.idproduto,
                               kp.qtde * e.fatorconversao qtde
                          from kitproduto kp, embalagem e
                         where kp.idprodutokit = p_idproduto
                           and e.idproduto = kp.idproduto
                           and e.barra = kp.barra) k,
                      (select kp.idprodutokit, v.idproduto,
                               nvl(sum(v.disp) -
                                    pk_estoque.RetornarEstoqueReservado(v.iddepositante,
                                                                        v.IDPRODUTO,
                                                                        v.estadolote),
                                    0) qtde
                          from kitproduto kp, v_estoque_local v
                         where kp.idprodutokit = p_idproduto
                           and v.iddepositante = p_depositante
                           and v.estadolote = p_estado
                           and v.idproduto = kp.idproduto
                           and v.loteliberado = c_sim
                           and v.idsetor not in
                               (select idsetor
                                  from setorrecebimento
                                 where idtiporecebimento in
                                       (select idtiporecebimento
                                          from tiporecebimento
                                         where classificacao = c_reentrega))
                         group by kp.idprodutokit, v.iddepositante, v.idproduto,
                                  v.estadolote) kp
                where kp.idprodutokit(+) = k.idprodutokit
                  and kp.idproduto(+) = k.idproduto
                group by kp.idprodutokit) kit
       where p.idproduto = p_idproduto
         and pd.identidade(+) = p_depositante
         and pd.idproduto(+) = p.idproduto
         and kit.idprodutokit = p.idproduto;
  
    cursor c_ordemservico(p_depositante in number) is
      select idordemservico
        from ordemservico os
       where os.identidade = p_depositante
         and os.situacao = c_aberto
         and os.tiposervico = 'K';
  
    r_infkit         c_infkit%rowtype;
    r_ordemservico   ordemservico%rowtype;
    r_ordemproduto   ordemproduto%rowtype;
    r_ordemserviconf ordemprodutonotafiscal%rowtype;
    v_idordemservico number;
    v_qtde           number;
    v_idArmazem      number;
  begin
    -- verifica se existe alguma ordem de servico em aberto para o depositante
    savepoint po_OrdemServico;
  
    if c_ordemservico%isopen then
      close c_ordemservico;
    end if;
    open c_ordemservico(p_depositante);
    fetch c_ordemservico
      into v_idordemservico;
    if c_ordemservico%notfound then
    
      select nf.idarmazem
        into v_idArmazem
        from notafiscal nf
       where nf.idnotafiscal = p_idnotafiscal;
    
      r_ordemservico.idarmazem   := v_idArmazem;
      r_ordemservico.idusuario   := p_usuario;
      r_ordemservico.identidade  := p_depositante;
      r_ordemservico.tiposervico := c_kit;
      r_ordemservico.situacao    := c_aberto;
      v_idordemservico           := InserirOrdemServico(r_ordemservico);
    end if;
    close c_ordemservico;
  
    -- gera a ordem de produgco para o kit
    if c_infkit%isopen then
      close c_infkit;
    end if;
    open c_infkit(p_depositante, p_estado, p_idproduto);
    fetch c_infkit
      into r_infkit;
    if c_infkit%found then
      if (p_qtde >= r_infkit.qtdeminima)
         and (r_infkit.qtdedisponivel >= p_qtde) then
        v_qtde := p_qtde;
      elsif (p_qtde < r_infkit.qtdeminima)
            and (r_infkit.qtdedisponivel >= r_infkit.qtdeminima) then
        v_qtde := r_infkit.qtdeminima;
      else
        v_qtde := r_infkit.qtdedisponivel;
      end if;
    
      r_ordemproduto.idordemservico := v_idordemservico;
      r_ordemproduto.idproduto      := p_idproduto;
      r_ordemproduto.qtde           := v_qtde;
      InserirOrdemServicoProduto(r_ordemproduto);
    
      r_ordemserviconf.idordemservico := v_idordemservico;
      r_ordemserviconf.idproduto      := p_idproduto;
      r_ordemserviconf.idnotafiscal   := p_idnotafiscal;
      if v_qtde >= p_qtde then
        r_ordemserviconf.qtde := p_qtde;
      else
        r_ordemserviconf.qtde := v_qtde;
      end if;
      InserirOrdemProdutoNotaFiscal(r_ordemserviconf);
    
    else
      rollback to po_OrdemServico;
    end if;
    close c_infkit;
  end;

  /*
   * Insere a Ordem de Servigo
  */
  function InserirOrdemServico(p_ordemservico ordemservico%rowtype)
    return number is
    v_idordemservico number;
  begin
    select seq_ordemservico.nextval
      into v_idordemservico
      from dual;
    insert into ordemservico
      (idordemservico, idusuario, idlotenf, idromaneio, identidade,
       datacadastro, dataprocessamento, observacao, tiposervico, situacao)
    values
      (v_idordemservico, p_ordemservico.idusuario, p_ordemservico.idlotenf,
       p_ordemservico.idromaneio, p_ordemservico.identidade,
       nvl(p_ordemservico.datacadastro, sysdate),
       p_ordemservico.dataprocessamento, p_ordemservico.observacao,
       p_ordemservico.tiposervico, p_ordemservico.situacao);
  
    return v_idordemservico;
  end;

  /*
   * Insere o produto na ordem de servico
  */
  procedure InserirOrdemServicoProduto(p_ordemproduto ordemproduto%rowtype) is
  begin
    insert into ordemproduto
      (idordemservico, idproduto, qtde)
    values
      (p_ordemproduto.idordemservico, p_ordemproduto.idproduto,
       p_ordemproduto.qtde);
  exception
    when dup_val_on_index then
      update ordemproduto
         set qtde = qtde + p_ordemproduto.qtde
       where idordemservico = p_ordemproduto.idordemservico
         and idproduto = p_ordemproduto.idproduto;
  end;

  /*
   * Apaga as informacoes na tabela ordemprodutonotafiscal
  */
  procedure ApagarOrdemProdutoNotaFiscal(p_idnotafiscal in number) is
  begin
    delete from ordemprodutonotafiscal
     where idordemservico in (select idordemservico
                                from ordemservico
                               where situacao = 'A')
       and idnotafiscal = p_idnotafiscal;
  end;

  /*
   * Retira a nf da quarentena caso a or seja de kit e a nf esteja bloqueada
  */
  procedure RetirarNFQuarentenaKit(p_idlotenf in number) is
  begin
    update notafiscal
       set statusnf = decode(digitada, c_sim, C_NORMAL, c_importada)
     where idnotafiscal in
           (select distinct opn.idnotafiscal
              from ordemservico os, ordemprodutonotafiscal opn
             where os.idlotenf = p_idlotenf
               and opn.idordemservico = os.idordemservico)
       and statusnf = c_quarentena;
  end;

  /*
   * Inclui produtos na tabela de SEPARACAOESPECIFICA
  */
  procedure IncluirSeparacaoEspecifica(p_idnotafiscal in notafiscal.idnotafiscal%type) is
    cursor c_estoque
    (
      p_idarmazem     in armazem.idarmazem%type,
      p_iddepositante in notafiscal.iddepositante%type,
      p_idproduto     in produto.idproduto%type
    ) is
      select el.idlocal, el.idlote, (el.disp - nvl(sp.qtdeseparada, 0)) disp,
             el.disp disp3,
             (lt.qtdedisponivel - nvl(sp.qtdeseparada, 0)) qtdedisponivel
        from v_estoque_local el,
             (select se.idarmazem, se.idlocal, se.idlote,
                      sum(se.qtde) qtdeseparada
                 from v_notafiscal_pendente np, separacaoespecifica se, lote l
                where np.statusnf in (C_NORMAL, C_IMPORTADA, C_CARGA)
                  and se.idnotafiscal = np.idnotafiscal
                  and l.idlote = se.idlote
                  and np.idproduto = l.idproduto
                group by se.idarmazem, se.idlocal, se.idlote) sp, lote lt
       where el.idarmazem = p_idarmazem
         and el.iddepositante = p_iddepositante
         and el.idproduto = p_idproduto
         and lt.idlote = el.idlote
         and sp.idarmazem(+) = el.idarmazem
         and sp.idlocal(+) = el.idlocal
         and sp.idlote(+) = el.idlote
         and (el.disp - nvl(sp.qtdeseparada, 0)) > 0
         and nvl(el.estadolote, 'N') = 'N'
         and el.loteliberado = 'S'
         and nvl(el.expedicao, 'S') = 'S'
         and el.localativo = 'S'
         and el.tipo in (0, 1, 2)
         and el.buffer = 'N'
         and el.tipolote = 'L'
         and (nvl(el.estoque, 0) + nvl(el.adicionar, 0)) -
             (nvl(el.pendencia, 0) + nvl(el.reservado, 0)) > 0
       order by nvl(el.dtvenc, sysdate), lt.dtentrada, lt.idlote, el.rua,
                el.predio, el.andar, el.apartamento;
  
    r_estoque      c_estoque%rowtype;
    v_qtderestante number;
    v_qtdedisp     number;
    v_qtdesep      number;
    v_msg          t_message;
  begin
    for c_separacao in (select nf.iddepositante, nf.idarmazem,
                               nf.idnotafiscal, nd.idproduto,
                               pr.codigointerno,
                               sum(nd.qtde * em.fatorconversao) qtde,
                               r.classificacao
                          from embalagem em, notafiscal nf, produto pr,
                               nfdet nd, depositante d, regime r
                         where em.idproduto = nd.idproduto
                           and em.barra = nd.barra
                           and nf.idnotafiscal = nd.nf
                           and pr.idproduto = nd.idproduto
                           and nd.nf = p_idnotafiscal
                           and d.identidade = nf.iddepositante
                           and r.idregime = d.idregime
                         group by nf.iddepositante, nf.idarmazem,
                                  nf.idnotafiscal, nd.idproduto,
                                  pr.codigointerno, r.classificacao)
    loop
      v_qtdedisp := pk_estoque.RetornarEstoque(c_separacao.idarmazem,
                                               c_separacao.iddepositante,
                                               c_separacao.idproduto, c_bom,
                                               c_separacao.classificacao);
    
      v_qtderestante := c_separacao.qtde;
      if v_qtdedisp >= c_separacao.qtde then
        if c_estoque%isopen then
          close c_estoque;
        end if;
        open c_estoque(c_separacao.idarmazem, c_separacao.iddepositante,
                       c_separacao.idproduto);
        fetch c_estoque
          into r_estoque;
        while (v_qtderestante > 0)
              and (c_estoque%found)
        loop
          if c_separacao.classificacao = 'F' then
            if r_estoque.disp <= v_qtderestante then
              v_qtdesep := r_estoque.disp;
            else
              v_qtdesep := v_qtderestante;
            end if;
          else
            if r_estoque.qtdedisponivel <= v_qtderestante then
              v_qtdesep := r_estoque.qtdedisponivel;
            else
              v_qtdesep := v_qtderestante;
            end if;
          end if;
        
          if v_qtdesep > 0 then
            insert into separacaoespecifica
              (idarmazem, idlote, idlocal, idnotafiscal, qtde, cadmanual)
            values
              (c_separacao.idarmazem, r_estoque.idlote, r_estoque.idlocal,
               c_separacao.idnotafiscal, v_qtdesep, c_nao);
          
            if c_separacao.classificacao = 'F' then
              if c_separacao.qtde <= r_estoque.disp then
                v_qtderestante := 0;
              else
                v_qtderestante := v_qtderestante - r_estoque.disp;
              end if;
            else
              if c_separacao.qtde <= r_estoque.qtdedisponivel then
                v_qtderestante := 0;
              else
                v_qtderestante := v_qtderestante - r_estoque.qtdedisponivel;
              end if;
            end if;
          end if;
          fetch c_estoque
            into r_estoque;
        end loop;
      end if;
      if v_qtderestante > 0 then
        v_msg := t_message('Nao existe estoque suficiente para atender a demanda. Produto: {0}');
        v_msg.addParam(c_separacao.codigointerno);
        raise_application_error(-20123, v_msg.formatMessage);
      end if;
    end loop;
  
  end;

  /*
   * Gerar/Processar OS
  */
  procedure GerarOS
  (
    p_idordemservico in number,
    p_tipoos         in varchar2,
    p_usuario        in number,
    p_tipokitmontado out number,
    p_kitsmontados   out number,
    p_atualizakit    in number,
    p_commit         in varchar2 := c_sim
  ) is
  
    type t_ordemServico is record(
      idlotenf                 ordemservico.idlotenf%type,
      idromaneio               ordemservico.idromaneio%type,
      idProduto                OrdemServico.idProduto%type,
      qtde                     OrdemServico.qtde%type,
      situacao                 OrdemServico.situacao%type,
      tipoDescOs               varchar2(100),
      existeReceita            number,
      idArmazem                OrdemServico.Idarmazem%type,
      iddepositante            Ordemservico.Identidade%type,
      geraLoteIndEsp           depositante.criarltindustriaespvenckit%type,
      seqloteind               OrdemServico.Seqloteind%type,
      idconfiguracaoonda       Ordemservico.Idconfiguracaoonda%type,
      existeTerceiroNivel      number,
      garantirumvencloteindkit depositante.garantirumvencloteindkit%type);
  
    r_ordemServico t_ordemServico;
  
    v_semerro boolean := true;
    v_msg     t_message;
    v_Seq     number;
  
    procedure carregarDados is
    begin
      select os.idProduto, os.qtde, os.idlotenf, os.idromaneio, os.situacao,
             decode(os.tiposervico, 'K', 'Formação de Kit', 'D',
                     'Desmontagem de Kit', 'E', 'Estojamento', 'J',
                     'Desmontagem Estojamento', 'I', 'Kit com Rastreabilidade',
                     'T', 'Mistura', 'O', 'Classificação', 'R',
                     'Reclassificação') tipoOs,
             (select count(1)
                 from kitproduto pd
                where pd.idprodutokit = os.Idproduto) receita, OS.idArmazem,
             os.identidade,
             (select count(1)
                 from depositante d
                where d.identidade = os.identidade
                  and d.criarltindustriaespvenckit = 1) criarltindustriaespvenckit,
             os.seqloteind, os.idconfiguracaoonda,
             (select 1
                 from kitproduto k
                where k.idprodutokit = os.idproduto
                  and exists
                (select 1
                         from kitproduto kb
                        where kb.idprodutokit = k.idproduto
                          and (kb.estojo = 1 or exists -- Trava KKE / KKK
                               (select 1
                                  from kitproduto kc
                                 where kc.idprodutokit = kb.idproduto)))) existeTerceiroNivel,
             (select count(1)
                 from depositante d
                where d.identidade = os.identidade
                  and d.garantirumvencloteindkit = 1)
        into r_ordemServico.idProduto, r_ordemServico.qtde,
             r_ordemServico.idlotenf, r_ordemServico.idromaneio,
             r_ordemServico.situacao, r_ordemServico.tipoDescOs,
             r_ordemServico.existeReceita, r_ordemServico.idArmazem,
             r_ordemServico.idDepositante, r_ordemServico.geraLoteIndEsp,
             r_ordemServico.seqloteind, r_ordemServico.idconfiguracaoonda,
             r_ordemServico.existeTerceiroNivel,
             r_ordemServico.garantirumvencloteindkit
        from ordemServico os
       where os.idordemservico = p_idordemservico;
    
    end carregarDados;
  
    procedure validacoes is
    begin
    
      if (r_ordemServico.situacao <> C_AGUARDANDO) then
        v_msg := t_message('Ordem de Serviço deve estar com a situação AGUARDANDO.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validacoes;
  
    procedure carregarOSRastreabilidade is
      procedure validacoes is
      begin
      
        if (r_ordemServico.geraLoteIndEsp = 0) then
          v_msg := t_message('Ordem de Servico de KIT com Rastreabilidade deve ser gerada somente com o parâmetro "Criar Lote Indústria Especial e Vencimento em Kit com Rastreabilidade" no Depositante acionado.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if r_ordemServico.idconfiguracaoonda is null then
          v_msg := t_message('Configuração de Onda não informada!');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_ordemServico.existeTerceiroNivel = 1) then
          v_msg := t_message('Ordem de Servico de KIT com Rastreabilidade deve ser gerada somente com componentes sem subComponentes(Kit-Componente ou Kit-Kit-Componente ou Kit-Estojo-Componente).');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_ordemServico.existeReceita = 0) then
          v_msg := t_message('Produto KIT deve ter receita cadastrada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_ordemServico.garantirumvencloteindkit = 0) then
          v_msg := t_message('Produto deve estar com o Parâmetro "Garantir um Vencimento/Lote Indústria por SKU na formação de Kit" acionado na configuração do Depositante.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end validacoes;
    begin
    
      if p_tipoos <> C_KIT_COM_RASTREABILIDADE then
        return;
      end if;
    
      validacoes;
    
      delete from ordemProduto
       where idordemservico = p_idordemservico;
    
      insert into ordemProduto
        (idordemservico, idproduto, qtde)
      values
        (p_idordemservico, r_ordemServico.idProduto, r_ordemServico.qtde);
    
      if r_ordemServico.seqloteind is null then
        pk_locks.executeLock(r_ordemServico.idArmazem, 6);
        v_seq := pk_servico.getSeqLoteIndOS(r_ordemServico.idArmazem,
                                            r_ordemServico.idDepositante,
                                            p_idordemservico, p_usuario);
      
        update ordemservico
           set seqloteind = v_seq
         where idordemservico = p_idordemservico;
      end if;
    
    end carregarOSRastreabilidade;
  
    function existeKitRastreavel(p_ordemServico in number) return boolean is
      v_existe_rastreavel number := 0;
    begin
      begin
      
        select sum(x.contagem)
          into v_existe_rastreavel
          from (select count(*) contagem
                   from ordemservico os, ordemproduto op,
                        produtodepositante pd
                  where os.idordemservico = p_ordemServico
                    and op.idordemservico = os.idordemservico
                    and pd.idproduto = op.idproduto
                    and pd.identidade = os.identidade
                    and pd.bloqueiakitrastreavel = 1
                 union all
                 select count(*) contagem
                   from ordemservico os, ordemproduto op, kitproduto kp,
                        produtodepositante pd
                  where os.idordemservico = p_ordemServico
                    and op.idordemservico = os.idordemservico
                    and kp.idprodutokit = op.idproduto
                    and kp.estojo = 1
                    and pd.identidade = os.identidade
                    and pd.idproduto = op.idproduto
                    and pd.bloqueiakitrastreavel = 1
                 union all
                 select count(*) contagem
                   from ordemservico os, ordemproduto op, kitproduto kp,
                        produtodepositante pd
                  where os.idordemservico = p_ordemServico
                    and op.idordemservico = os.idordemservico
                    and kp.idprodutokit = op.idproduto
                    and pd.identidade = os.identidade
                    and pd.idproduto = op.idproduto
                    and pd.bloqueiakitrastreavel = 1
                    and exists
                  (select 1
                           from kitproduto kit
                          where kit.idprodutokit = kp.idproduto)) x;
      
        if v_existe_rastreavel > 0 then
          return true;
        else
          return false;
        end if;
      end;
    end existeKitRastreavel;
  
  begin
  
    if p_atualizakit > 0 then
      update ordemservico
         set qtde = p_atualizakit
       where idordemservico = p_idordemservico;
      commit;
    end if;
  
    carregarDados;
  
    validacoes;
  
    carregarOSRastreabilidade;
  
    if p_tipoos in (C_KIT, C_KIT_COM_RASTREABILIDADE) then
    
      begin
      
        if p_tipoos = C_KIT
           and existeKitRastreavel(p_idordemservico) then
          p_tipokitmontado := 3;
        else
        
          processar_kitproduto(p_idordemservico, p_usuario,
                               p_tipokitmontado, p_kitsmontados);
        
          if p_tipokitmontado <> 2 then
            rollback;
            v_semerro := false;
          end if;
        end if;
      exception
        when E_ERROCORTE then
          begin
            rollback;
            for x in 1 .. listaErro.count()
            loop
              pk_gttresumoexecucao.addResumo(listaErro(x).msgGrupo,
                                             listaErro(x).msgDetalhe,
                                             pk_gttresumoexecucao.TIPO_ERRO);
            end loop;
          
            v_semerro := false;
          end;
      end;
    
    end if;
  
    if p_tipoos = c_conserto then
      processar_Conserto(p_idordemservico);
    end if;
  
    if p_commit = c_sim then
      commit;
    end if;
  
    if v_semerro then
    
      carregarDados;
    
      pk_utilities.GeraLog(p_usuario,
                           'Tela: Gerada Ordem de Serviço: ' ||
                            r_ordemServico.tipoDescOs || ' idordemservico: ' ||
                            p_idordemservico || ', idlotenf: ' ||
                            r_ordemServico.idlotenf || ', idromaneio: ' ||
                            r_ordemServico.idromaneio, p_idordemservico,
                           'CA');
    
    end if;
  end;

  /*
   * Processar OS tipo Conserto/Manutencgco/Laboratorio
  */
  procedure processar_Conserto(p_idordemservico in number) is
    v_msg t_message;
  
    cursor c_ordemservico(p_os in number) is
      select o.idordemservico, o.datacadastro, o.identidade, o.idusuario,
             o.idromaneio, o.idlotenf, o.situacao, o.idarmazem, o.iddoca,
             o.separacaoespec, o.tiposervico
        from ordemservico o
       where o.idordemservico = p_os;
  
    cursor c_localorig(p_ordemservico in number) is
      select distinct ll.idlocal, ll.idarmazem, ol.idlote, ol.qtde, ll.disp
        from ordemservico os, ordemlote ol, v_estoque_local ll
       where os.idordemservico = p_ordemservico
         and ol.idordemservico = os.idordemservico
         and ll.idlote = ol.idlote;
  
    cursor c_localdest
    (
      p_ordemservico in number,
      p_idarmazem    in number,
      p_identidade   in number
    ) is
      select l.idlocal, l.idarmazem
        from local l, setor s, tiposetor t, setordepositante sd
       where l.idarmazem = p_idarmazem
         and l.ativo = c_sim
         and l.idsetor = s.idsetor
         and s.perda = 0
         and s.insucessoentrega = 0
         and t.idtiposetor = s.idtiposetor
         and t.laboratorio = c_sim
         and sd.idsetor = s.idsetor
         and sd.iddepositante = p_identidade
         and l.idlocalpai is null
         and l.idarmazempai is null
         and (((l.idarmazempai, l.idlocalpai) not in
             (select idarmazempai, idlocalpai
                  from local
                 where idarmazempai is not null
                   and idlocalpai is not null)) or
             (l.idarmazempai || l.idlocalpai is null))
         and (l.idarmazem, l.idlocal) not in
             (select distinct idarmazem, idlocal
                from mapaalocacao
               where status in (pendente, c_aguardando, 'M')
              union
              select idarmazemorigem, idlocalorigem
                from remanejamento
               where status = c_aguardando);
  
    r_ordemservico    c_ordemservico%rowtype;
    r_localorig       c_localorig%rowtype;
    r_localdest       c_localdest%rowtype;
    v_idremanejamento number;
  
  begin
    if c_ordemservico%isopen then
      close c_ordemservico;
    end if;
    open c_ordemservico(p_idordemservico);
    fetch c_ordemservico
      into r_ordemservico;
    if c_ordemservico%found then
      -- verificar se existe produtos vinculados
      if totallotesvinculados(p_idordemservico) = 0 then
        v_msg := t_message('ESTA ORDEM DE SERVICO NAO POSSUI LOTES VINCULADOS.' ||
                           chr(13) || 'OPERACAO CANCELADA');
        raise_application_error(-20345, v_msg.formatMessage);
      elsif r_ordemservico.situacao = C_PROCESSADO then
        -- verificando situacao do romaneio
        v_msg := t_message('ORDEM DE SERVICO JA PROCESSADA');
        raise_application_error(-20345, v_msg.formatMessage);
      else
      
        -- caso a os ja tenha sido gerada com erro
        if r_ordemservico.idlotenf is not null then
          desvincularor(p_idordemservico, r_ordemservico.idlotenf,
                        r_ordemservico.idusuario);
        end if;
      
      end if;
    
      -- cadastrar remanejamento
    
      -- locais de origem dos lotes
      if c_localorig%isopen then
        close c_localorig;
      end if;
      open c_localorig(p_idordemservico);
      fetch c_localorig
        into r_localorig;
      if not c_localorig%found then
        v_msg := t_message('Lote sem local de Origem.');
        raise_application_error(-20345, v_msg.formatMessage);
      elsif r_localorig.qtde > r_localorig.disp then
        v_msg := t_message('Quantidade do Lote vinculado é maior que a quantidade disponível.');
        raise_application_error(-20346, v_msg.formatMessage);
      end if;
    
      -- inicia varredura da origem do lote
      while c_localorig%found
      loop
      
        -- local de destino vago
        if c_localdest%isopen then
          close c_localdest;
        end if;
      
        open c_localdest(p_idordemservico, r_ordemservico.idarmazem,
                         r_ordemservico.identidade);
        fetch c_localdest
          into r_localdest;
        --se nao achou destino
        if not c_localdest%found then
          v_msg := t_message('DEPOSITANTE SEM LOCAL DE LABORATORIO DEFINIDO.');
          raise_application_error(-20345, v_msg.formatMessage);
        end if;
      
        if ((r_localorig.idarmazem = r_localdest.idarmazem) and
           (r_localorig.idlocal = r_localdest.idlocal)) then
          v_msg := t_message('ERRO AO FORMAR REMANEJAMENTO. LOCAL ORIGEM IGUAL AO DESTINO!');
          raise_application_error(-20345, v_msg.formatMessage);
        end if;
      
        -- cadastra remanejamento
        v_idremanejamento := pk_remanejamento.cadastrar_remanejamento(r_localorig.idarmazem,
                                                                      r_localdest.idarmazem,
                                                                      r_localorig.idlocal,
                                                                      r_localdest.idlocal,
                                                                      r_ordemservico.idusuario,
                                                                      null,
                                                                      c_descrconserto,
                                                                      c_nao,
                                                                      c_sim);
        if v_idremanejamento is null then
          v_msg := t_message('ERRO AO FORMAR REMANEJAMENTO');
          raise_application_error(-20345, v_msg.formatMessage);
        end if;
      
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido)
        values
          (v_idremanejamento, r_localorig.idlote, r_localorig.qtde, c_sim);
      
        -- proxima origem
        fetch c_localorig
          into r_localorig;
      end loop;
    
      -- fecha cursor dos lotes de origem
      if c_localorig%isopen then
        close c_localorig;
      end if;
      -- fecha cursor dos lotes de destino
      if c_localdest%isopen then
        close c_localdest;
      end if;
    
      -- processou a ordem de servico
      update ordemservico
         set idlotenf          = null,
             idromaneio        = null,
             dataprocessamento = sysdate,
             situacao          = c_conserto
       where idordemservico = r_ordemservico.idordemservico;
    
      for c_lotes in (select idlote
                        from ordemlote
                       where ordemlote.idordemservico =
                             r_ordemservico.idordemservico)
      loop
        -- bloqueando os lotes
        update lote
           set liberado          = c_nao,
               databloqueio      = sysdate,
               motivobloqueio    = c_descrconserto,
               idusuariobloqueio = r_ordemservico.idusuario
         where idlote = c_lotes.idlote;
      
      end loop;
    
      if c_ordemservico%isopen then
        close c_ordemservico;
      end if;
    
    end if;
  end;

  /*
   * Verifica se existe produtos vinculados a OS
  */
  function totallotesvinculados(p_ordemservico in number) return number is
    cursor c_ordlote(p_ordemservico in number) is
      select nvl(count(*), 0) valor
        from ordemlote
       where idordemservico = p_ordemservico;
    r_ordlote c_ordlote%rowtype;
  
  begin
    if c_ordlote%isopen then
      close c_ordlote;
    end if;
    open c_ordlote(p_ordemservico);
    fetch c_ordlote
      into r_ordlote;
  
    close c_ordlote;
  
    return r_ordlote.valor;
  end;

  /*
   * Finalizar OS Conserto
  */
  procedure FinalizaOS(p_idordemservico in number) is
  begin
    for c_lotes in (select idlote
                      from ordemlote
                     where ordemlote.idordemservico = p_idordemservico)
    loop
      -- desbloqueando os lotes
      update lote
         set liberado          = c_sim,
             databloqueio      = null,
             motivobloqueio    = null,
             idusuariobloqueio = null
       where idlote = c_lotes.idlote;
    end loop;
  
    -- finalizando a OS
    update ordemservico
       set dataprocessamento = sysdate,
           situacao          = c_processado
     where idordemservico = p_idordemservico;
  end;

  /*
   * Importar OS Conserto por nro serie
  */
  procedure ImportaOS_Serie
  (
    p_cnpjdepositante entidade.cgc%type,
    p_serie           lote.descr%type,
    p_produto         produto.codigointerno%type,
    p_usuario         number,
    p_tipomaterial    number := 0,
    p_cnpjunidade     entidade.cgc%type
  ) is
    v_msg t_message;
  
    cursor c_depositante(p_iddepositante in entidade.cgc%type) is
      select d.identidade
        from depositante d, entidade e
       where e.cgc = p_iddepositante
         and e.identidade = d.identidade;
  
    cursor c_lote
    (
      p_serie   in lote.descr%type,
      p_produto in varchar
    ) is
      select l.idlote, l.qtdedisponivel
        from lote l, produto p, v_estoque_local v
       where upper(l.descr) = upper(p_serie)
         and l.idproduto = p.idproduto
         and p.codigointerno = p_produto
         and v.idlote = l.idlote
       group by l.idlote, l.qtdedisponivel;
  
    cursor c_lotetipo
    (
      p_serie        in lote.descr%type,
      p_produto      in varchar,
      p_tipomaterial in number
    ) is
      select l.idlote, l.qtdedisponivel
        from lote l, produto p, conferenciaentradadet d,
             informacaomaterialvalor i, v_estoque_local v
       where l.idproduto = p.idproduto
         and p.codigointerno = p_produto
         and i.idinfomaterial = p_tipomaterial
         and upper(i.valor) = upper(p_serie)
         and d.idlotenf = i.idlotenf
         and d.idconferenciaentrada = i.idconferenciaentrada
         and d.idcontagem = i.idcontagem
         and d.idlote = l.idlote
         and nvl(d.ignorada, 'N') = 'N'
         and l.tipolote = 'L'
         and v.idlote = l.idlote
       group by l.idlote, l.qtdedisponivel;
  
    v_idordemservico ordemservico.idordemservico%type;
    r_depositante    c_depositante%rowtype;
    r_lote           c_lote%rowtype;
    r_ordemservico   ordemservico%rowtype;
    r_doca           doca%rowtype;
    v_erro           varchar2(1000);
    v_idunidade      number;
    v_kitsgerados    number := 0;
    v_tipokitmontado number := 0;
    v_atualizakit    number := 0;
  begin
    if c_depositante%isopen then
      close c_depositante;
    end if;
  
    open c_depositante(p_cnpjdepositante);
  
    fetch c_depositante
      into r_depositante;
  
    if c_depositante%notfound then
      v_msg := t_message('ERRO - CNPJ DO DEPOSITANTE {0} NAO ENCNTRADO.');
      v_msg.addParam(p_cnpjdepositante);
      v_erro := v_msg.formatMessage;
    end if;
  
    if v_erro is null then
      if p_tipomaterial = 0 then
        if c_lote%isopen then
          close c_lote;
        end if;
      
        open c_lote(p_serie, p_produto);
        fetch c_lote
          into r_lote;
      
        if c_lote%notfound then
          v_msg := t_message('ERRO - NRO DE SERIE {0} DO PRODUTO {1} NAO ENCONTRADO.');
          v_msg.addParam(p_serie);
          v_msg.addParam(p_produto);
          v_erro := v_msg.formatMessage;
        end if;
      else
        if c_lotetipo%isopen then
          close c_lotetipo;
        end if;
      
        open c_lotetipo(p_serie, p_produto, p_tipomaterial);
        fetch c_lotetipo
          into r_lote;
      
        if c_lotetipo%notfound then
          v_msg := t_message('ERRO - TIPO PRODUTO {0} NRO DE SERIE {1} DO PRODUTO' ||
                             ' {2} NAO ENCONTRADO.');
          v_msg.addParam(p_tipomaterial);
          v_msg.addParam(p_serie);
          v_msg.addParam(p_produto);
          v_erro := v_msg.formatMessage;
        end if;
      end if;
    end if;
  
    if v_erro is null then
      -- pega armazem e doca
      begin
        select a.idarmazem
          into v_idunidade
          from armazem a, entidade e
         where e.identidade = a.identidade
           and e.cgc = p_cnpjunidade;
      exception
        when no_data_found then
          v_msg := t_message('Nao foi encontrada nenhuma unidade de armazenagem para o cnpj indicado. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        when too_many_rows then
          v_msg := t_message('Foi encontrado mais de uma unidade de armazenagem para o cnpj indicado. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      r_doca := pk_armazem.pegardocapadrao(v_idunidade);
    
      if (r_doca.idarmazem is null)
         or (r_doca.iddoca is null) then
        v_msg  := t_message('NAO FOI LOCALIZADO DOCA PARA A OS.');
        v_erro := v_msg.formatMessage;
      end if;
    
      r_ordemservico.idordemservico := -1;
      r_ordemservico.idusuario      := p_usuario;
      r_ordemservico.identidade     := r_depositante.identidade;
      r_ordemservico.datacadastro   := sysdate;
      r_ordemservico.tiposervico    := c_conserto;
      r_ordemservico.situacao       := c_aguardando;
      r_ordemservico.idarmazem      := r_doca.idarmazem;
      r_ordemservico.iddoca         := r_doca.iddoca;
    
      begin
        v_idordemservico := InserirOrdemServico(r_ordemservico);
        update ordemservico
           set idarmazem = r_ordemservico.idarmazem,
               iddoca    = r_ordemservico.iddoca
         where idordemservico = v_idordemservico;
      
      exception
        when others then
          v_msg  := t_message('ERRO AO INSERIR ORDEM DE SERVICO.');
          v_erro := v_msg.formatMessage;
      end;
    
      if v_erro is null then
        if v_idordemservico is null then
          v_msg  := t_message('ERRO AO INSERIR ORDEM DE SERVICO.');
          v_erro := v_msg.formatMessage;
        end if;
      end if;
    
      if v_erro is null then
        begin
          insert into ordemlote
            (idordemservico, idlote, qtde, serie)
          values
            (v_idordemservico, r_lote.idlote, r_lote.qtdedisponivel,
             p_serie);
        exception
          when others then
            v_msg  := t_message('ERRO AO INSERIR LOTES NA ORDEM DE SERVICO.');
            v_erro := v_msg.formatMessage;
        end;
      end if;
    
      if v_erro is null then
        GerarOS(v_idordemservico, c_conserto, p_usuario, v_tipokitmontado,
                v_kitsgerados, v_atualizakit, c_nao);
      end if;
    end if;
  
    -- fechando cursores
    if c_depositante%isopen then
      close c_depositante;
    end if;
  
    if c_lote%isopen then
      close c_lote;
    end if;
  
    if v_erro is not null then
      raise_application_error(-20000, v_erro);
    end if;
  end;

  /*
   * Importar OS Conserto por produto
  */
  procedure ImportaOS_Produto
  (
    p_cnpjdepositante entidade.cgc%type,
    p_produto         produto.codigointerno%type,
    p_qtde            number,
    p_usuario         number,
    p_cnpjunidade     entidade.cgc%type
  ) is
  
    cursor c_depositante(p_iddepositante in entidade.cgc%type) is
      select d.identidade
        from depositante d, entidade e
       where e.cgc = p_iddepositante
         and e.identidade = d.identidade;
  
    cursor c_lote
    (
      p_produto       in produto.codigointerno%type,
      p_iddepositante in varchar
    ) is
      select v.idlocal, v.idlote, l.idproduto, p.codigointerno, v.disp,
             v.picking
        from v_estoque_local v, lote l, produto p
       where p.codigointerno = p_produto
         and l.idproduto = p.idproduto
         and v.iddepositante = p_iddepositante
         and v.idproduto = p.idproduto
         and v.idlote = l.idlote
       order by v.picking desc, v.rua, v.predio, v.andar, v.apartamento;
  
    v_idordemservico ordemservico.idordemservico%type;
    r_depositante    c_depositante%rowtype;
    r_lote           c_lote%rowtype;
    r_ordemservico   ordemservico%rowtype;
    r_doca           doca%rowtype;
    v_erro           varchar2(1000);
    v_qtdepedida     number;
    v_idunidade      number;
    v_msg            t_message;
    v_kitsgerados    number := 0;
    v_tipokitmontado number := 0;
    v_atualizakit    number := 0;
  begin
    if c_depositante%isopen then
      close c_depositante;
    end if;
  
    open c_depositante(p_cnpjdepositante);
  
    fetch c_depositante
      into r_depositante;
  
    if c_depositante%notfound then
      v_msg := t_message('ERRO - CNPJ DO DEPOSITANTE {0} NAO ENCONTRADO.');
      v_msg.addParam(p_cnpjdepositante);
      v_erro := v_msg.formatMessage;
    end if;
  
    if v_erro is null then
      if c_lote%isopen then
        close c_lote;
      end if;
    
      open c_lote(p_produto, r_depositante.identidade);
      fetch c_lote
        into r_lote;
    
      if c_lote%notfound then
        v_msg := t_message('ERRO - PRODUTO {0} NAO ENCONTRADO.');
        v_msg.addParam(p_produto);
        v_erro := v_msg.formatMessage;
      end if;
    end if;
  
    if v_erro is null then
      -- pega armazem e doca
      begin
        select a.idarmazem
          into v_idunidade
          from armazem a, entidade e
         where e.identidade = a.identidade
           and e.cgc = p_cnpjunidade;
      exception
        when no_data_found then
          v_msg := t_message('Nao foi encontrada nenhuma unidade de armazenagem para o cnpj indicado. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        when too_many_rows then
          v_msg := t_message('Foi encontrado mais de uma unidade de armazenagem para o cnpj indicado. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      r_doca := pk_armazem.pegardocapadrao(v_idunidade);
    
      if (r_doca.idarmazem is null)
         or (r_doca.iddoca is null) then
        v_msg  := t_message('NAO FOI LOCALIZADO DOCA PARA A OS.');
        v_erro := v_msg.formatMessage;
      end if;
    
      r_ordemservico.idordemservico := -1;
      r_ordemservico.idusuario      := p_usuario;
      r_ordemservico.identidade     := r_depositante.identidade;
      r_ordemservico.datacadastro   := sysdate;
      r_ordemservico.tiposervico    := c_conserto;
      r_ordemservico.situacao       := c_aguardando;
      r_ordemservico.idarmazem      := r_doca.idarmazem;
      r_ordemservico.iddoca         := r_doca.iddoca;
    
      begin
        v_idordemservico := InserirOrdemServico(r_ordemservico);
      
        update ordemservico
           set idarmazem = r_ordemservico.idarmazem,
               iddoca    = r_ordemservico.iddoca
         where idordemservico = v_idordemservico;
      exception
        when others then
          v_msg  := t_message('ERRO AO INSERIR ORDEM DE SERVICO.');
          v_erro := v_msg.formatMessage;
      end;
    
      if v_erro is null then
        if v_idordemservico is null then
          v_msg  := t_message('ERRO AO INSERIR ORDEM DE SERVICO.');
          v_erro := v_msg.formatMessage;
        end if;
      end if;
    
      if v_erro is null then
        begin
          -- atribui a qtde pedida a variavel de controle
          v_qtdepedida := p_qtde;
          -- varre os lotes para atender a demanda
          while (v_qtdepedida > 0)
                and c_lote%found
          loop
            if v_qtdepedida > r_lote.disp then
              begin
                insert into ordemlote
                  (idordemservico, idlote, qtde)
                values
                  (v_idordemservico, r_lote.idlote, r_lote.disp);
                v_qtdepedida := v_qtdepedida - r_lote.disp;
              exception
                when dup_val_on_index then
                  update ordemlote
                     set qtde = qtde + r_lote.disp
                   where idordemservico = v_idordemservico
                     and idlote = r_lote.idlote;
              end;
            else
              begin
                insert into ordemlote
                  (idordemservico, idlote, qtde)
                values
                  (v_idordemservico, r_lote.idlote, v_qtdepedida);
                v_qtdepedida := 0;
              exception
                when dup_val_on_index then
                  update ordemlote
                     set qtde = qtde + v_qtdepedida
                   where idordemservico = v_idordemservico
                     and idlote = r_lote.idlote;
              end;
            end if;
            fetch c_lote
              into r_lote;
          end loop;
        exception
          when others then
            v_msg  := t_message('ERRO AO INSERIR LOTES NA ORDEM DE SERVICO.');
            v_erro := v_msg.formatMessage;
        end;
      end if;
    
      -- gera as os de conserto
      if v_erro is null then
        GerarOS(v_idordemservico, c_conserto, p_usuario, v_tipokitmontado,
                v_kitsgerados, v_atualizakit, c_nao);
      end if;
    end if;
  
    -- fechando cursores
    if c_depositante%isopen then
      close c_depositante;
    end if;
  
    if c_lote%isopen then
      close c_lote;
    end if;
  
    if v_erro is not null then
      raise_application_error(-20000, v_erro);
    end if;
  end;

  /*
   * Liberar OS de Desmontagem de Kits
  */
  procedure CLiberarOSDesmKits
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  ) is
  
    cursor getListKitsDaOS(p_idordemservico in ordemservico.idordemservico%type) is
      select ks.qtde, ll.idlote,
             ll.estoque - ll.pendencia + ll.adicionar disp, ll.estoque,
             ll.pendencia, ll.adicionar, p.descr material, l.estado,
             dep.razaosocial depositante, p.idproduto, l.iddepositante,
             ll.idarmazem, ll.idlocal, ed.agruparinclusaolotes
        from kitos ks, lotelocal ll, lote l, produto p, entidade dep,
             depositante ed
       where ks.idordemservico = p_idordemservico
         and ll.idarmazem = ks.idarmazem
         and ll.idlocal = ks.idlocal
         and ll.idlote = ks.idlote
         and l.idlote = ll.idlote
         and p.idproduto = l.idproduto
         and dep.identidade = l.iddepositante
         and ed.identidade = l.iddepositante;
  
    cursor obterEstoqueLocalLote
    (
      p_idarmazem in armazem.idarmazem%type,
      p_idlocal   in local.idlocal%type,
      p_idlote    in lote.idlote%type
    ) is
      select v.idlote, v.disp, v.estoque, v.pendencia, v.adicionar,
             v.produto material, v.estado, v.depositante, v.idproduto,
             v.iddepositante, v.idarmazem, v.idlocal
        from v_estoque_local v
       where v.idarmazem = p_idarmazem
         and v.idlocal = p_idlocal
         and v.idlote = p_idlote;
  
    r_obterEstoqueLocalLote obterEstoqueLocalLote%rowtype;
    r_getListKitsDaOS       getListKitsDaOS%rowtype;
    v_erro                  varchar2(1000);
    v_msg                   t_message;
    v_msgDescr              t_message;
  
    C_LOTEINDUST_POR_NFCOBERTURA constant number := 2;
  begin
    if getListKitsDaOS%isopen then
      close getListKitsDaOS;
    end if;
  
    -- Abre o cursor que seleciona todos os kits vinculados a OS
    open getListKitsDaOS(p_idOS);
  
    fetch getListKitsDaOS
      into r_getListKitsDaOS;
  
    if r_getListKitsDaOS.Agruparinclusaolotes =
       C_LOTEINDUST_POR_NFCOBERTURA then
      v_msg := t_message('O depositante está com o parâmetro <b>Inclusão de estoque na Separação Específica</b> ' ||
                         'configurado como <b>Por Lote Indústria Listando NF Cobertura</b>. Não é possível liberar para execução. ' ||
                         'Operação cancelada!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Caso nao tenha nenhum produto vinculado, gera erro
    if getListKitsDaOS%notfound then
      v_msg := t_message('ERRO - NENHUM PRODUTO VINCULADO A ORDEM DE SERVICO {0}.');
      v_msg.addParam(p_idOS);
      v_erro := v_msg.formatMessage;
    
      v_msg      := t_message('Cadastro');
      v_msgDescr := t_message('Nenhum produto vinculado a ordem de servico.');
      pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                     v_msgDescr.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    -- Loop de todos os produtos vinculados na OS
    while getListKitsDaOS%found
    loop
    
      if v_erro is null then
        if obterEstoqueLocalLote %isopen then
          close obterEstoqueLocalLote;
        end if;
      
        -- Cursor que traz o estoque do lote vinculado a OS
        open obterEstoqueLocalLote(r_getListKitsDaOS.idarmazem,
                                   r_getListKitsDaOS.idlocal,
                                   r_getListKitsDaOS.idlote);
      
        fetch obterEstoqueLocalLote
          into r_obterEstoqueLocalLote;
      
        -- Caso nao tenha estoque do lote neste local, gera erro
        if obterEstoqueLocalLote %notfound then
          v_msg := t_message('KIT CUJO LOTE {0}, NO LOCAL {1}' ||
                             ' NAO EXISTE NO ESTOQUE! ATUALIZE A LISTA DE KITS ASSOCIADOS A ESTA OS.');
          v_msg.addParam(r_getListKitsDaOS.idlote);
          v_msg.addParam(r_getListKitsDaOS.idlocal);
          v_erro := v_msg.formatMessage;
        
          v_msg      := t_message('Sem Estoque');
          v_msgDescr := t_message('Produto id: {0}, Nome: {1}, Lote id: {2}' ||
                                  ', Local: {3} não existe estoque no endereço.');
          v_msgDescr.addParam(r_getListKitsDaOS.idproduto);
          v_msgDescr.addParam(r_getListKitsDaOS.material);
          v_msgDescr.addParam(r_getListKitsDaOS.idlote);
          v_msgDescr.addParam(r_getListKitsDaOS.idlocal);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ERRO);
        end if;
      end if;
    
      if v_erro is null then
        -- Verifica se a quantidade em estoque atende a solicitada
        while obterEstoqueLocalLote %found
        loop
          if r_obterEstoqueLocalLote.disp < r_getListKitsDaOS.qtde then
            v_msg := t_message('KIT CUJO LOTE {0}, NO LOCAL {1}' ||
                               ' NAO EXISTE A QUANTIDADE NECESSARIA!');
            v_msg.addParam(r_getListKitsDaOS.idlote);
            v_msg.addParam(r_getListKitsDaOS.idlocal);
            v_erro := v_msg.formatMessage;
          
            v_msg      := t_message('Estoque Insuficiente');
            v_msgDescr := t_message('Produto id: {0}, Nome: {1},' ||
                                    ' Lote id: {2}, Local: {3}' ||
                                    ' não possui estoque suficiente para atender a OS.');
            v_msgDescr.addParam(r_getListKitsDaOS.idproduto);
            v_msgDescr.addParam(r_getListKitsDaOS.material);
            v_msgDescr.addParam(r_getListKitsDaOS.idlote);
            v_msgDescr.addParam(r_getListKitsDaOS.idlocal);
            pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                           v_msgDescr.formatMessage,
                                           pk_gttresumoexecucao.TIPO_ERRO);
          end if;
        
          fetch obterEstoqueLocalLote
            into r_obterEstoqueLocalLote;
        
        end loop;
      end if;
    
      fetch getListKitsDaOS
        into r_getListKitsDaOS;
    
    end loop;
  
    -- Gera o Romaneio dos Kits
    if v_erro is null then
      gerarExpedicaoDesmKit(p_idOS, p_usuario, v_erro);
    end if;
  
    -- Gera a Ordem de Recebimento dos Produtos desmontados
    if v_erro is null then
      CGerOROSDesmKits(p_idOS, p_usuario, v_erro);
    end if;
  
    if v_erro is null then
      update ordemservico
         set situacao = c_liberado
       where idordemservico = p_idOS;
    end if;
  
    -- Retorna caso de erro
    p_erro := v_erro;
  end;

  /*
   * Cadastrar NF de Saida e Romaneio da Desmontagem dos Kits
  */
  procedure gerarExpedicaoDesmKit
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  ) is
    cursor getListKitsDaOS(p_idordemservico in ordemservico.idordemservico%type) is
      select os.idarmazem, os.identidade iddepositante, os.iddoca,
             os.idconfiguracaoonda
        from ordemservico os
       where idordemservico = p_idordemservico;
  
    cursor c_romaneio(p_romaneio in romaneiopai.idromaneio%type) is
      select r.*
        from romaneiopai r
       where r.idromaneio = p_romaneio;
  
    v_qtdepedida      number;
    v_pesobruto       number;
    r_nf              notafiscal%rowtype;
    r_nfdet           nfdet%rowtype;
    r_romaneio        romaneiopai%rowtype;
    r_getListKitsDaOS getListKitsDaOS%rowtype;
    v_idnf            number;
    v_erro            varchar2(1000);
    v_idunidade       number;
    v_msg             t_message;
    v_msgDescr        t_message;
  begin
    select a.identidade
      into v_idunidade
      from ordemservico os, armazem a
     where os.idordemservico = p_idOS
       and a.idarmazem = os.idarmazem;
    begin
      select count(e.idproduto), sum(e.pesobruto)
        into v_qtdepedida, v_pesobruto
        from kitos ks, lote l, embalagem e
       where ks.idordemservico = p_idOS
         and ks.idlote = l.idlote
         and l.idproduto = e.idproduto
         and e.fatorconversao = 1 -- Um e o Menor fator de conversao
       group by e.idproduto, e.barra, e.fatorconversao, e.pesobruto;
    exception
      when others then
        v_qtdepedida := 0;
        v_pesobruto  := 0;
    end;
  
    if getListKitsDaOS%isopen then
      close getListKitsDaOS;
    end if;
  
    -- Abre o cursor que seleciona todos os kits vinculados a OS
    open getListKitsDaOS(p_idOS);
  
    fetch getListKitsDaOS
      into r_getListKitsDaOS;
  
    -- cadastrar a nf saida
    if v_idnf is null then
      r_nf.movestoque := c_sim;
      r_nf.statusnf   := c_normal;
      -- datacadastro
      r_nf.dataemissao       := sysdate;
      r_nf.digitada          := c_nao;
      r_nf.usuario           := p_usuario;
      r_nf.tipo              := 'S';
      r_nf.crossdocking      := c_nao;
      r_nf.pesobruto         := v_pesobruto;
      r_nf.totalprodutos     := v_qtdepedida;
      r_nf.estado            := c_normal;
      r_nf.iddepositante     := r_getListKitsDaOS.Iddepositante;
      r_nf.observacao        := 'DOC. MOV. INTERNO PARA DESMONTAGEM DE KITS';
      r_nf.sequencia         := 'AJUSTE-DESM.-KIT';
      r_nf.remetente         := v_idunidade;
      r_nf.destinatario      := r_nf.remetente;
      r_nf.impresso          := c_sim;
      r_nf.Ident_Entrega     := r_nf.remetente;
      r_nf.estoqueverificado := c_sim;
    
      if r_getListKitsDaOS.Idconfiguracaoonda is not null then
        r_nf.statusroteirizacao       := 1;
        r_nf.transportadoranotafiscal := r_getListKitsDaOS.Iddepositante;
        select o.idoperacao
          into r_nf.idoperacao
          from operacao o
         where o.tipo = 'S'
           and o.tipooper is null
           and rownum = 1;
      else
        r_nf.statusroteirizacao := 2;
      end if;
    
      r_nf.Idarmazem  := r_getListKitsDaOS.Idarmazem;
      r_nf.docinterno := 1;
      v_idnf          := pk_notafiscal.insere_cabecalho_nf(r_nf);
    end if;
  
    if v_idnf is not null then
    
      for c_det in (select l.idproduto,
                           pk_produto.RetornarCodBarraMenorFator(l.idproduto) barra,
                           ks.qtde, ks.idarmazem, ks.idlocal, ks.idlote
                      from kitos ks, lote l
                     where ks.idordemservico = p_idOS
                       and l.idlote = ks.idlote)
      loop
      
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := v_idnf;
        r_nfdet.barra            := c_det.barra;
        r_nfdet.idproduto        := c_det.idproduto;
        r_nfdet.precounitliquido := 0;
        r_nfdet.qtde             := c_det.qtde;
        r_nfdet.qtdeatendida     := c_det.qtde;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
        -- insere os lotes vinculados da ordem de servico na separacao especifica
        insert into separacaoespecifica
          (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual)
        values
          (c_det.idarmazem, c_det.idlocal, c_det.idlote, v_idnf, c_det.qtde,
           'N');
      end loop;
    
      -- gera a nf de impressao
      pk_notafiscal.p_gerar_nfimpressao(v_idnf, 'N');
    
      if r_getListKitsDaOS.idconfiguracaoonda is not null then
        formarOndaOrdemServico(r_romaneio.idromaneio,
                               r_getListKitsDaOS.idconfiguracaoonda, p_idOS,
                               C_DESMONTAGEMKIT, v_idnf, p_usuario);
      else
        -- Inseri Romaneio dos componentes
        r_romaneio.placa          := pk_veiculo.pegaveiculopadrao;
        r_romaneio.idusuario      := p_usuario;
        r_romaneio.idarmazem      := r_getListKitsDaOS.idarmazem;
        r_romaneio.iddoca         := r_getListKitsDaOS.iddoca;
        r_romaneio.datageracao    := sysdate;
        r_romaneio.tituloromaneio := 'SAIDA PARA DESMONTAGEM DE KITS N:' ||
                                     p_idOS;
        r_romaneio.faturado       := c_sim;
        r_romaneio.coletado       := c_sim;
        r_romaneio.idromaneio     := pk_romaneio.inserir_romaneiopai(r_romaneio);
      
        -- Vincula NF ao romaneio
        insert into nfromaneio
          (idromaneio, idnotafiscal, sequencia)
        values
          (r_romaneio.idromaneio, v_idnf, 1);
      
        -- Forma Romaneio dos componentes
        pk_romaneio.formar_romaneio(r_romaneio.idromaneio, p_usuario, c_nao,
                                    c_nao);
      
      end if;
    
      update ordemservico o
         set o.idromaneio = r_romaneio.idromaneio
       where idordemservico = p_idOS;
    
      -- Carrega romaneio
      if c_romaneio%isopen then
        close c_romaneio;
      end if;
      open c_romaneio(r_romaneio.idromaneio);
      fetch c_romaneio
        into r_romaneio;
      -- Verifica se tem corte de formacao do romaneio
      if r_romaneio.erro <> C_ERRO then
        -- Verifica se a formacao foi concluida com sucesso
        if r_romaneio.gerado <> C_SEPARACAO then
          v_msg  := t_message('HOUVE NOTA FISCAL DE REENTREGA NA FORMACAO DO ROMANEIO');
          v_erro := v_msg.formatMessage;
        
          v_msg      := t_message('Nota Fiscal');
          v_msgDescr := t_message('HOUVE NOTA FISCAL DE REENTREGA NA FORMACAO DO ROMANEIO.');
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ERRO);
        end if;
      else
        v_msg  := t_message('HOUVE CORTE NA FORMACAO DO ROMANEIO' ||
                            chr(13) ||
                            '-----------------------------------' ||
                            chr(13));
        v_erro := v_msg.formatMessage;
        for c_corte in (select 'Produto: ' || p.codigointerno || ' - ' ||
                                p.descr produto, 'Barra: ' || c.barra barra,
                               'Pedido: ' || c.qtdepedido qtdepedido,
                               'Disponivel PK: ' || c.qtdedisponivelpk qtdedisponivelpk,
                               'Disponivel PL: ' || c.qtdedisponivelpl qtdedisponivelpl
                          from corteromaneio c, produto p
                         where p.idproduto = c.idproduto
                           and c.idromaneio = r_romaneio.idromaneio)
        loop
          v_msg      := t_message('Corte na Formação Romaneio');
          v_msgDescr := t_message('{0}{1}' || chr(13) || '{2}' || chr(13) ||
                                  '{3}' || chr(13) || '{4}' || chr(13) ||
                                  '{5}' || chr(13) ||
                                  '================================');
          v_msgDescr.addParam(v_erro);
          v_msgDescr.addParam(c_corte.produto);
          v_msgDescr.addParam(c_corte.barra);
          v_msgDescr.addParam(c_corte.qtdepedido);
          v_msgDescr.addParam(c_corte.qtdedisponivelpk);
          v_msgDescr.addParam(c_corte.qtdedisponivelpl);
          v_erro := v_msgDescr.formatMessage;
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                         pk_gttresumoexecucao.TIPO_ERRO);
        end loop;
      
        dbms_output.put_line(v_erro);
      end if;
    
    end if;
    p_erro := v_erro;
  
  end gerarExpedicaoDesmKit;

  /*
   * Cadastrar NF de Entrada e OR da Desmontagem dos Kits
  */
  procedure CGerOROSDesmKits
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_usuario in number,
    p_erro    out varchar2
  ) is
    cursor c_tiporec is
      select min(t.idtiporecebimento) idtiporecebimento
        from tiporecebimento t
       where classificacao = c_movinterno;
  
    cursor getListKitsDaOS(p_os in ordemservico.idordemservico%type) is
      select ks.qtde, ll.idlote,
             ll.estoque - ll.pendencia + ll.adicionar disp, ll.estoque,
             ll.pendencia, ll.adicionar, p.descr material, l.estado,
             dep.razaosocial depositante, p.idproduto, l.iddepositante,
             ll.idarmazem, ll.idlocal
        from kitos ks, lotelocal ll, lote l, produto p, entidade dep
       where ks.idordemservico = p_os
         and ll.idarmazem = ks.idarmazem
         and ll.idlocal = ks.idlocal
         and ll.idlote = ks.idlote
         and l.idlote = ll.idlote
         and p.idproduto = l.idproduto
         and dep.identidade = l.iddepositante;
  
    cursor getListComponentes(p_idProdutoKit in kitproduto.idprodutokit%type) is
      select idprodutokit, idproduto, barra, qtde
        from kitproduto
       where idprodutokit = p_idProdutoKit;
  
    cursor getParamOS(p_os in ordemservico.idordemservico%type) is
      select o.idlotenf, o.idromaneio, o.identidade, o.tiposervico,
             o.idarmazem, o.iddoca
        from ordemservico o
       where o.idordemservico = p_OS;
  
    r_getListKitsDaOS    getListKitsDaOS%rowtype;
    r_getListComponentes getListComponentes%rowtype;
    r_tiporec            c_tiporec%rowtype;
    r_getParamOS         getParamOS%rowtype;
    r_lotenf             lotenf%rowtype;
    v_insnf              notafiscal%rowtype;
    v_nfsaida            number;
    v_nfent              number;
    v_lotenf             number;
    r_nfdet              nfdet%rowtype;
    v_erro               varchar2(200);
    v_obrigaremetenteor  char(1);
    v_msg                t_message;
    v_msgDescr           t_message;
  
    procedure inserirNFDetReceita
    (
      p_idNFDet      in number,
      p_idLoteOrigem in number,
      p_idProduto    in number,
      p_qtd          in number
    ) is
    
      v_idOS   ordemservico.idordemservico%type;
      v_tipoOS ordemservico.tiposervico%type;
    
    begin
      for c_lote in (select *
                       from (select cpk.idlotecomponente,
                                     (select count(*)
                                         from complotekit c
                                        where c.idlotekit = cpk.idlotecomponente) possuiComponente
                                from complotekit cpk, lote lt
                               where cpk.idlotekit = p_idLoteOrigem
                                 and cpk.idlotecomponente = lt.idlote
                                 and lt.idproduto = p_idProduto
                                 and rownum = 1) p
                      where p.possuiComponente > 0)
      loop
      
        select os.idordemservico, os.tiposervico
          into v_idOS, v_tipoOS
          from origemlote orl, notafiscal nf, ordemservico os
         where orl.idnotafiscal = nf.idnotafiscal
           and nf.idlotenf = os.idlotenf
           and orl.idlote = c_lote.idlotecomponente;
      
        if (v_idOS is not null) then
          if (v_tipoOS in ('E', 'J')) then
            insert into nfdetreceitaestojamento
              (idnfdet, tiposervico, idproduto, qtdeunit, idlotekitreplicar,
               idordemservico, produtoagrupador)
              select p_idNfDet, v_tipoOS, r.idprodutocomp, r.qtdeunit,
                     c_lote.idlotecomponente, p_idOS, 0
                from receitaestojamentolote r
               where r.idlote = c_lote.idlotecomponente;
          
            -- receita do produto agrupador da OS
            if (sql%rowcount > 0) then
              insert into nfdetreceitaestojamento
                (idnfdet, tiposervico, idproduto, qtdeunit,
                 idlotekitreplicar, idordemservico, produtoagrupador)
                select p_idNfDet, v_tipoOS, os.idproduto, 1 qtdeunit,
                       c_lote.idlotecomponente, p_idOS, 1
                  from receitaestojamentolote r, ordemservico os
                 where 1 = 1
                   and os.idordemservico = r.idos
                   and r.idlote = c_lote.idlotecomponente
                 group by os.idproduto;
            end if;
          elsif (v_tipoOS in ('K', 'I')) then
            insert into nfdetreceitaestojamento
              (idnfdet, idproduto, qtdeunit, idlotekitreplicar, tiposervico,
               idordemservico, produtoagrupador, data)
              select p_idNfDet, k.idproduto, (k.qtde * e.fatorconversao),
                     c_lote.idlotecomponente, v_tipoOS, p_idOS, 0, sysdate
                from kitproduto k, lote lt, embalagem e
               where k.idprodutokit = p_idProduto
                 and lt.idlote = c_lote.idlotecomponente
                 and lt.barra = e.barra
                 and lt.idproduto = e.idproduto;
          end if;
        end if;
      
      end loop;
    
    end inserirNFDetReceita;
  
  begin
  
    -- pega dados da ordem de servico
    if getParamOS%isopen then
      close getParamOS;
    end if;
    open getParamOS(p_idOS);
    fetch getParamOS
      into r_getParamOS;
  
    if getParamOS%notfound then
      v_msg      := t_message('Cadastro');
      v_msgDescr := t_message('NAO FOI LOCALIZADO ORDEM DE DESMONTAGEM DE KITS.');
      v_erro     := v_msgDescr.formatMessage;
      pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    if getListKitsDaOS%isopen then
      close getListKitsDaOS;
    end if;
  
    open getListKitsDaOS(p_idOS);
    fetch getListKitsDaOS
      into r_getListKitsDaOS;
    if getListKitsDaOS%notfound then
      v_msg      := t_message('Cadastro');
      v_msgDescr := t_message('NAO FORAM LOCALIZADOS KITS PARA ESTA ORDEM DE SERVICO.');
      v_erro     := v_msgDescr.formatMessage;
      pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    if v_erro is null then
      while getListKitsDaOS%found
            and v_erro is null
      loop
      
        if getListComponentes%isopen then
          close getListComponentes;
        end if;
      
        open getListComponentes(r_getListKitsDaOS.Idproduto);
      
        fetch getListComponentes
          into r_getListComponentes;
      
        if getListComponentes%notfound then
          v_msg      := t_message('Componentes Kit');
          v_msgDescr := t_message('NAO FORAM LOCALIZADOS COMPONENTES DO KIT ' ||
                                  '{0} PARA ESTA ORDEM DE SERVICO.');
          v_msg.addParam(r_getListKitsDaOS.Idproduto);
          v_erro := v_msgDescr.formatMessage;
        
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                         pk_gttresumoexecucao.TIPO_ERRO);
        end if;
      
        -- insere o cabecalho da nf de entrada.
        if v_nfent is null then
          begin
            select nr.idnotafiscal
              into v_nfsaida
              from nfromaneio nr
             where nr.idromaneio = r_getParamOS.idromaneio;
          exception
            when others then
              v_msg      := t_message('Romaneio Desmontagem Kit');
              v_msgDescr := t_message('UM ROMANEIO DE DESMONTAGEM DE KITS DEVE TER EXATAMENTE UM DOCUMENTO DE MOVIMENTACAO!');
              v_erro     := v_msgDescr.formatMessage;
              pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                             pk_gttresumoexecucao.TIPO_ERRO);
          end;
        
          if v_erro is null then
            v_insnf                    := pk_notafiscal.Carregar_NotaFiscal(v_nfsaida);
            v_insnf.tipo               := C_ENTRADA;
            v_insnf.estoqueverificado  := C_NAO;
            v_insnf.statusroteirizacao := 2;
            v_nfent                    := pk_notafiscal.insere_cabecalho_nf(v_insnf);
          end if;
        end if;
      
        --  insere os itens da nf
        if v_erro is null then
          while getListComponentes%found
          loop
            r_nfdet.idnfdet          := null;
            r_nfdet.nf               := v_nfent;
            r_nfdet.barra            := r_getListComponentes.barra;
            r_nfdet.idproduto        := r_getListComponentes.idproduto;
            r_nfdet.precounitliquido := getValorUnitarioComponente(r_getListKitsDaOS.Idlote,
                                                                   r_getListComponentes.idproduto);
            r_nfdet.qtde             := r_getListComponentes.qtde *
                                        r_getListKitsDaOS.Qtde;
            r_nfdet.qtdeatendida     := r_getListComponentes.qtde *
                                        r_getListKitsDaOS.Qtde;
            -- incluir no detalhe da nota de entrada
            pk_notafiscal.insere_detalhe_nf(r_nfdet);
          
            inserirNFDetReceita(r_nfdet.idnfdet, r_getListKitsDaOS.Idlote,
                                r_getListComponentes.idproduto,
                                (r_getListComponentes.qtde *
                                 r_getListKitsDaOS.Qtde));
          
            fetch getListComponentes
              into r_getListComponentes;
          end loop;
        end if;
        fetch getListKitsDaOS
          into r_getListKitsDaOS;
      end loop;
    end if;
  
    if getListComponentes%isopen then
      close getListComponentes;
    end if;
  
    if getListKitsDaOS%isopen then
      close getListKitsDaOS;
    end if;
  
    -- gera a nf de impressao
    if v_erro is null then
      pk_notafiscal.p_gerar_nfimpressao(v_nfent, 'N');
    
      -- tipo de recebimento
      if c_tiporec%isopen then
        close c_tiporec;
      end if;
      open c_tiporec;
      fetch c_tiporec
        into r_tiporec;
    
      if r_tiporec.idtiporecebimento is null then
        v_msg      := t_message('Tipo Recebimento');
        v_msgDescr := t_message('NAO FOI LOCALIZADO TIPO DE RECEBIMENTO REF. A ENTRADA DE DESMONTAGEM DE KIT.');
        v_erro     := v_msgDescr.formatMessage;
        pk_gttresumoexecucao.addResumo(v_msg.formatMessage, v_erro,
                                       pk_gttresumoexecucao.TIPO_ERRO);
      end if;
    
      if v_erro is null then
        -- cadastra a OR
        r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
        r_lotenf.descr             := 'DESMONTAGEM DE KIT N: ' || p_idOS;
        r_lotenf.data              := sysdate;
        r_lotenf.idusuario         := p_usuario;
        r_lotenf.idarmazem         := r_getParamOS.idarmazem;
        r_lotenf.iddoca            := r_getParamOS.iddoca;
        r_lotenf.identidade        := r_getParamOS.identidade;
        r_lotenf.modal             := 0;
      
        select d.obrigaremetenteor
          into v_obrigaremetenteor
          from depositante d
         where d.identidade = r_lotenf.identidade;
      
        if v_obrigaremetenteor = 'S' then
          r_lotenf.idremetente := v_insnf.remetente;
        end if;
      
        v_lotenf := pk_recebimento.cadastrar_OR(r_lotenf);
      
        update ordemservico
           set idlotenf = v_lotenf
         where idordemservico = p_idOS;
      
        update notafiscal
           set idlotenf = v_lotenf
         where idnotafiscal = v_nfent;
      
        update nfimpressao n
           set n.idlotenf = v_lotenf
         where idprenf = (select idprenf
                            from notafiscal
                           where idnotafiscal = v_nfent);
      
        pk_recebimento.Atualizar_Produtos_OR(v_lotenf, c_nao);
      end if;
    
    end if;
  
    if c_tiporec%isopen then
      close c_tiporec;
    end if;
  
    if getParamOS%isopen then
      close getParamOS;
    end if;
  
    p_erro := v_erro;
  end;

  /*
   * Vincular lotes de composicao de montagem a OS
  */
  procedure VinculaLotesCompMontagem
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_idlote  in number,
    p_usuario in number
  ) is
  begin
    -- pega lotes da montagem de material
    insert into ordemlote
      (idordemservico, idlote, qtde)
      select p_idos, l.idlote, l.qtdeentrada
        from lote l
       where idlotemont = p_idlote;
  
    pk_utilities.GeraLog(p_usuario,
                         'INSERIU LOTES COMPONENTES DE MONTAGEM DO AGRUPADOR ' ||
                          p_idlote, p_idOS, 'OS');
  end;

  /*
   * Desvincular lotes de composicao de montagem a OS
  */
  procedure DesvinculaLotesMontagem
  (
    p_idOS    in ordemservico.idordemservico%type,
    p_idlote  in number,
    p_usuario in number
  ) is
    v_lotemontagem number;
    v_msg          t_message;
  begin
    select count(*)
      into v_lotemontagem
      from lote
     where idlote = p_idlote
       and idlotemont is not null;
  
    if v_lotemontagem > 0 then
      v_msg := t_message('LOTE QUE FAZ PARTE DE UMA MONTAGEM NAO PODE SER DESVINVULADO. DESVINCULE O LOTE AGRUPADOR DE MONTAGEM!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_lotemont in (select idlote
                         from lote
                        where idlotemont = p_idlote)
    loop
      delete from ordemlote
       where idordemservico = p_idOS
         and idlote = c_lotemont.idlote;
    end loop;
    pk_utilities.GeraLog(p_usuario,
                         'INSERIU LOTES COMPONENTES DE MONTAGEM DO AGRUPADOR ' ||
                          p_idlote, p_idOS, 'OS');
  end;

  /*
   * Liberar OS de Canibalizacao para execucao
  */
  procedure CtrlLiberarOSCanibExecucao
  (
    p_idOS      in number,
    p_idUsuario in number
  ) is
  begin
    for listaLotes in (select ks.qtde, ll.idlote,
                              ll.estoque - ll.pendencia + ll.adicionar disp,
                              ll.estoque, ll.pendencia, ll.adicionar,
                              p.descr material, l.estado,
                              dep.razaosocial depositante, p.idproduto,
                              l.iddepositante, ll.idarmazem, ll.idlocal
                         from kitos ks, lotelocal ll, lote l, produto p,
                              entidade dep
                        where ks.idordemservico = p_idOS
                          and ll.idarmazem = ks.idarmazem
                          and ll.idlocal = ks.idlocal
                          and ll.idlote = ks.idlote
                          and l.idlote = ll.idlote
                          and p.idproduto = l.idproduto
                          and dep.identidade = l.iddepositante)
    loop
      pk_estoque.incluir_pendencia(listaLotes.idarmazem, listaLotes.Idlocal,
                                   listaLotes.Idlote, listaLotes.Qtde,
                                   p_idUsuario,
                                   'PENDENCIA GERADA EM FUNCAO DA LIBERACAO PARA EXECUCAO DA OS ' ||
                                    'DE CANIBALIZACAO ID: ' || p_idOS);
      update lote
         set liberado          = c_nao,
             databloqueio      = sysdate,
             idusuariobloqueio = p_idusuario,
             motivobloqueio   =
             ('Lote canibalizado pela OS número: ' || to_char(p_idOS))
       where idlote = listaLotes.Idlote;
    end loop;
  
    update ordemservico
       set situacao = c_liberado
     where idordemservico = p_idOS;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'LIBEROU PARA EXECUCAO A OS DE CANIBALIZACAO.',
                         p_idOS, 'OS');
  end;

  /*
   * Suspender OS de Canibalizacao
  */
  procedure CtrlSuspenderExecOSCanib
  (
    p_idOS      in number,
    p_idUsuario in number
  ) is
  begin
    for listaLotes in (select ks.qtde, ll.idlote,
                              ll.estoque - ll.pendencia + ll.adicionar disp,
                              ll.estoque, ll.pendencia, ll.adicionar,
                              p.descr material, l.estado,
                              dep.razaosocial depositante, p.idproduto,
                              l.iddepositante, ll.idarmazem, ll.idlocal
                         from kitos ks, lotelocal ll, lote l, produto p,
                              entidade dep
                        where ks.idordemservico = p_idOS
                          and ll.idarmazem = ks.idarmazem
                          and ll.idlocal = ks.idlocal
                          and ll.idlote = ks.idlote
                          and l.idlote = ll.idlote
                          and p.idproduto = l.idproduto
                          and dep.identidade = l.iddepositante)
    loop
      pk_estoque.retirar_pendencia(listaLotes.idarmazem, listaLotes.Idlocal,
                                   listaLotes.Idlote, listaLotes.Qtde,
                                   p_idUsuario,
                                   'PENDENCIA RETIRADA EM FUNCAO DA SUSPENSAO ' ||
                                    'DA OS DE CANIBALIZACAO ID: ' || p_idOS);
      update lote
         set liberado          = c_sim,
             databloqueio      = null,
             idusuariobloqueio = null,
             motivobloqueio    = null
       where idlote = listaLotes.Idlote;
    end loop;
  
    update ordemservico
       set situacao = c_aberto
     where idordemservico = p_idOS;
  
    pk_utilities.GeraLog(p_idUsuario, 'SUSPENDEU A OS DE CANIBALIZACAO.',
                         p_idOS, 'OS');
  end;

  /*
   * Processar OS de Canibalizacao
  */
  procedure CtrProcessarOSCanib
  (
    p_idOS      in number,
    p_idUsuario in number
  ) is
  begin
    for listaLotes in (select ks.qtde, ll.idlote,
                              ll.estoque - ll.pendencia + ll.adicionar disp,
                              ll.estoque, ll.pendencia, ll.adicionar,
                              p.descr material, l.estado,
                              dep.razaosocial depositante, p.idproduto,
                              l.iddepositante, ll.idarmazem, ll.idlocal
                         from kitos ks, lotelocal ll, lote l, produto p,
                              entidade dep
                        where ks.idordemservico = p_idOS
                          and ll.idarmazem = ks.idarmazem
                          and ll.idlocal = ks.idlocal
                          and ll.idlote = ks.idlote
                          and l.idlote = ll.idlote
                          and p.idproduto = l.idproduto
                          and dep.identidade = l.iddepositante)
    loop
      pk_estoque.retirar_pendencia(listaLotes.idarmazem, listaLotes.Idlocal,
                                   listaLotes.Idlote, listaLotes.Qtde,
                                   p_idUsuario,
                                   'PENDENCIA RETIRADA EM FUNCAO DO PROCESSAMENTO ' ||
                                    'DA OS DE CANIBALIZACAO ID: ' || p_idOS);
    
      update lote
         set canibalizado      = c_sim,
             liberado          = c_sim,
             databloqueio      = null,
             idusuariobloqueio = null,
             motivobloqueio    = null
       where idlote = listaLotes.Idlote;
    
    end loop;
  
    update ordemservico
       set situacao          = c_processado,
           dataprocessamento = sysdate
     where idordemservico = p_idOS;
  
    pk_utilities.GeraLog(p_idUsuario, 'PROCESSOU A OS DE CANIBALIZACAO.',
                         p_idOS, 'OS');
  end;

  /*
   * Desmontar Material
  */
  procedure DesmontarMaterial
  (
    p_idOS      in number,
    p_idUsuario in number,
    p_erro      out varchar2
  ) is
    v_aberta number;
    v_achou  boolean := False;
  begin
    select count(idordemservico)
      into v_aberta
      from ordemservico
     where idordemservico = p_idOS
       and situacao = c_aberto;
  
    if v_aberta > 0 then
      for c_lote in (select l.idlote, l.idlotemont
                       from ordemlote ol, lote l
                      where l.idlotemont is not null
                        and l.idlote = ol.idlote
                        and ol.idordemservico = p_idOS)
      loop
        update lote
           set idpalet    = null,
               idlotemont = null
         where idlote = c_lote.idlote;
      
        insert into historicoagrupamento
          (idhistoricoagrupamento, idlote, idlotemont, dtlancamento,
           tipooperacao, idusuario, idordemservico)
        values
          (seq_historicoagrupamento.nextval, c_lote.idlote,
           c_lote.idlotemont, sysdate, 1, p_idUsuario, p_idOS);
        v_achou := True;
      end loop;
    
      if v_achou then
        update ordemservico
           set situacao = C_PROCESSADO
         where idordemservico = p_idOS;
      else
        p_erro := 'Nao existem componentes para serem desmontados.';
      end if;
    
    else
      p_erro := 'Desmontagem do Material ja esta finalizada.';
    end if;
  end;

  /*
   * Rotina responsável por transferir a cobertura fiscal dos lotes de desmontagem de kit
  */
  procedure transferirCoberturaDesmontagem(p_idordemservico in number) is
    cursor c_origem
    (
      p_idromaneio in number,
      p_idor       in number,
      p_idProduto  in number
    ) is
      select ps.idlotesaida, ps.idlote, sum(ps.qtde - nvl(oo.qtde, 0)) qtde
        from (select ps.idlote idlotesaida, l.idlote,
                      sum(oo.qtde * e.fatorconversao) qtde
                 from (select distinct idlote
                          from paletseparacao
                         where idromaneio = p_idromaneio) ps, orlote_origem oo,
                      lote l, embalagem e
                where oo.idlote = ps.idlote
                  and oo.idlotenf <> p_idor
                  and l.idlote = oo.idlote_origem
                  and l.idproduto = p_idproduto
                  and e.barra = l.barra
                  and e.idproduto = l.idproduto
                group by ps.idlote, l.idlote) ps,
             (select ps.idlote idlotesaida, l.idlote, sum(oo.qtde) qtde
                 from (select distinct idlote
                          from paletseparacao
                         where idromaneio = p_idromaneio) ps, orlote_origem oo,
                      lote l
                where oo.idlote = ps.idlote
                  and oo.idlotenf = p_idor
                  and l.idlote = oo.idlote_origem
                  and l.idproduto = p_idproduto
                group by ps.idlote, l.idlote) oo
       where oo.idlote(+) = ps.idlote
         and oo.idlotesaida(+) = ps.idlote
         and (ps.qtde - nvl(oo.qtde, 0)) > 0
       group by ps.idlotesaida, ps.idlote;
  
    r_origem         c_origem%rowtype;
    r_cobertura      coberturalote%rowtype;
    r_cobertura_ins  coberturalote%rowtype;
    v_idromaneio     number;
    v_idlotenf       number;
    v_restante       number;
    v_qtde           number;
    v_qtdecob        number;
    v_classificacao  regime.classificacao%type;
    r_composicaolote composicaolote%rowtype;
    v_msg            t_message;
  
    c_valorarLote constant boolean := false;
  begin
    -- valida se a os é de desmontagem de kit
    begin
      select os.idromaneio, os.idlotenf, r.classificacao
        into v_idromaneio, v_idlotenf, v_classificacao
        from ordemservico os, depositante dp, regime r
       where os.idordemservico = p_idordemservico
         and os.tiposervico = 'D'
         and dp.identidade = os.identidade
         and r.idregime = dp.idregime;
    exception
      when no_data_found then
        v_idromaneio    := 0;
        v_idlotenf      := 0;
        v_classificacao := 'F';
    end;
  
    if (v_idromaneio > 0)
       and (v_idlotenf > 0) then
      -- lista os lotes de entrada desmontados
      for c in (select l.idlote, l.idproduto,
                       l.qtdeentrada * e.fatorconversao qtde
                  from orlote ol, lote l, embalagem e
                 where ol.idlotenf = v_idlotenf
                   and l.idlote = ol.idlote
                   and e.idproduto = l.idproduto
                   and e.barra = l.barra
                 order by l.idproduto)
      loop
        -- localiza os lotes componentes de kit
        v_restante := c.qtde;
      
        if c_origem%isopen then
          close c_origem;
        end if;
      
        open c_origem(v_idromaneio, v_idlotenf, c.idproduto);
        fetch c_origem
          into r_origem;
      
        while (c_origem%found)
              and (v_restante > 0)
        loop
        
          if v_restante >= r_origem.qtde then
            v_qtde := r_origem.qtde;
          else
            v_qtde := v_restante;
          end if;
        
          begin
            insert into orlote_origem
              (idlotenf, idlote, idlote_origem, qtde)
            values
              (v_idlotenf, c.idlote, r_origem.idlote, v_qtde);
          exception
            when dup_val_on_index then
              update orlote_origem oo
                 set oo.qtde = oo.qtde + v_qtde
               where oo.idlotenf = v_idlotenf
                 and oo.idlote = c.idlote
                 and oo.idlote_origem = r_origem.idlote;
          end;
        
          v_restante := v_restante - v_qtde;
        
          if v_classificacao = 'A' then
            -- lista a cobertura disponivel para o lote de origem
            r_cobertura := pk_lote.RetornarCoberturaLote(r_origem.idlote,
                                                         r_composicaolote);
            while (r_cobertura.idlote is not null)
                  and (v_qtde > 0)
            loop
              if v_qtde >=
                 (r_cobertura.qtdecoberto - r_cobertura.qtderetorno) then
                v_qtdecob := (r_cobertura.qtdecoberto -
                             r_cobertura.qtderetorno);
              else
                v_qtdecob := v_qtde;
              end if;
              -- insere cobertura lote novo
              r_cobertura_ins.idlotenf       := v_idlotenf;
              r_cobertura_ins.idlote         := c.idlote;
              r_cobertura_ins.idnotafiscal   := r_cobertura.idnotafiscal;
              r_cobertura_ins.idnfentrada    := r_cobertura.idnotafiscal;
              r_cobertura_ins.idnfdet        := r_cobertura.idnfdet;
              r_cobertura_ins.idnfdetentrada := r_cobertura.idnfdetentrada;
              r_cobertura_ins.qtdecoberto    := v_qtdecob;
              r_cobertura_ins.qtderetorno    := 0;
              pk_coberturafiscal.InserirCoberturaLote(r_cobertura_ins,
                                                      c_valorarLote);
              pk_lote.valorarLoteDesmontagemKit(c.idlote);
            
              -- indica retorno no lote antigo
              update coberturalote
                 set qtderetorno = qtderetorno + v_qtdecob
               where idlotenf = r_cobertura.idlotenf
                 and idlote = r_cobertura.idlote
                 and idnotafiscal = r_cobertura.idnotafiscal
                 and idnfentrada = r_cobertura.idnfentrada;
            
              if (r_composicaolote.idloteanterior is not null)
                 and (r_composicaolote.idlotenovo is not null) then
                update composicaolote cl
                   set cl.qtderetorno = cl.qtderetorno + v_qtdecob
                 where exists (select 1
                          from gtt_composicaolote gcl
                         where gcl.idloteanterior = cl.idloteanterior
                           and gcl.idlotenovo = cl.idlotenovo);
              end if;
            
              update orlote_origem
                 set qtde = qtde - v_qtdecob
               where idlote = r_origem.idlotesaida
                 and idlote_origem = r_origem.idlote;
            
              v_qtde      := v_qtde - v_qtdecob;
              r_cobertura := pk_lote.RetornarCoberturaLote(r_origem.idlote,
                                                           r_composicaolote);
            end loop;
            if v_qtde > 0 then
              v_msg := t_message('Não foi encontrado cobertura disponivel do lote {0}' ||
                                 ' para finalizar a desmontagem de material, lote desmontado {1}');
              v_msg.addParam(r_origem.idlote);
              v_msg.addParam(c.idlote);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end if;
          fetch c_origem
            into r_origem;
        end loop;
        close c_origem;
        if v_restante > 0 then
          v_msg := t_message('Não foi encontrado lotes cobertos suficientes para finalizar a desmontagem de material.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
      if v_classificacao = 'A' then
        for c in (select idlote, sum(qtdeunit) qtde
                    from paletseparacao
                   where idromaneio = v_idromaneio
                   group by idlote)
        loop
          v_restante := c.qtde;
          -- lista a cobertura disponivel para o lote de origem
          r_cobertura := pk_lote.RetornarCoberturaLote(c.idlote,
                                                       r_composicaolote);
          while (r_cobertura.idlote is not null)
                and (v_restante > 0)
          loop
            if v_restante >=
               (r_cobertura.qtdecoberto - r_cobertura.qtderetorno) then
              v_qtde := (r_cobertura.qtdecoberto - r_cobertura.qtderetorno);
            else
              v_qtde := v_restante;
            end if;
            -- indica retorno no lote de kit desmontado
            update coberturalote
               set qtderetorno = qtderetorno + v_qtde
             where idlotenf = r_cobertura.idlotenf
               and idlote = r_cobertura.idlote
               and idnotafiscal = r_cobertura.idnotafiscal
               and idnfentrada = r_cobertura.idnfentrada;
          
            if (r_composicaolote.idloteanterior is not null)
               and (r_composicaolote.idlotenovo is not null) then
              update composicaolote cl
                 set cl.qtderetorno = cl.qtderetorno + v_qtde
               where exists (select 1
                        from gtt_composicaolote gcl
                       where gcl.idloteanterior = cl.idloteanterior
                         and gcl.idlotenovo = cl.idlotenovo);
            end if;
          
            v_restante  := v_restante - v_qtde;
            r_cobertura := pk_lote.RetornarCoberturaLote(c.idlote,
                                                         r_composicaolote);
          end loop;
        end loop;
      end if;
    end if;
  end;

  procedure suspenderOSDesmontagemKit
  (
    p_idordemservico in number,
    p_idusuario      in number
  ) is
    C_TIPOEXP_ONDA constant number := 1;
    v_situacaoOS ordemservico.situacao%type;
    v_msg        t_message;
  
    v_tipoServico    ordemservico.tiposervico%type;
    v_idlotenf       lotenf.idlotenf%type;
    v_tipoOnda       romaneiopai.tipo%type;
    v_idPreNfEntrada number;
    v_idPreNfSaida   number;
    v_idOnda         number;
  
    procedure carregarDadosIniciais is
    begin
      select os.tiposervico, lnf.idlotenf, rp.tipo, nfent.idprenf,
             rp.idromaneio, nfsai.idprenf, os.situacao
        into v_tipoServico, v_idlotenf, v_tipoOnda, v_idPreNfEntrada,
             v_idOnda, v_idPreNfSaida, v_situacaoOS
        from ordemservico os, lotenf lnf, romaneiopai rp, notafiscal nfent,
             nfromaneio nfr, notafiscal nfsai
       where os.idordemservico = p_idordemservico
         and lnf.idlotenf(+) = os.idlotenf
         and rp.idromaneio(+) = os.idromaneio
         and nfent.idlotenf(+) = lnf.idlotenf
         and nfr.idromaneio(+) = rp.idromaneio
         and nfsai.idnotafiscal(+) = nfr.idnotafiscal;
    end carregarDadosIniciais;
  
    procedure validarOS is
      C_TIPOOS_DESMONTAGEMKIT constant ordemservico.tiposervico%type := 'D';
      C_STATUSOS_AGUARDANDO   constant ordemservico.situacao%type := 'A';
      C_STATUSOS_ALOCACAO     constant ordemservico.situacao%type := 'O';
      C_STATUSOS_PROCESSADA   constant ordemservico.situacao%type := 'P';
    
      v_qtdeConfEnt number;
      v_msg         t_message;
    begin
      if v_situacaoOS = C_STATUSOS_AGUARDANDO then
        v_msg := t_message('Ordem de serviço aberta não pode ser suspensa.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
      if v_situacaoOS = C_STATUSOS_ALOCACAO then
        v_msg := t_message('Ordem de serviço em alocação não pode ser suspensa.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
      if v_situacaoOS = C_STATUSOS_PROCESSADA then
        v_msg := t_message('Ordem de serviço processada não pode ser suspensa.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_tipoServico not in (C_TIPOOS_DESMONTAGEMKIT) then
        v_msg := t_message('Suspensão de OS permitida apenas para ordens de serviço ' ||
                           'dos tipos "Desmontagem de Kit".');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_idlotenf is null then
        v_msg := t_message('Cancelamento de OS permitido apenas para OS com OR criada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_tipoOnda = C_TIPOEXP_ONDA then
      
        select count(*)
          into v_qtdeConfEnt
          from conferenciaentradadet cd
         where cd.idlotenf = v_idlotenf
           and cd.ignorada = 'N';
      
        if v_qtdeConfEnt > 0 then
          v_msg := t_message('Cancelamento de OS permitido apenas antes do início da conferência ' ||
                             'de entrada da OR gerada pela OS.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validarOS;
  
    procedure desfazerOR is
    begin
      update ordemservico os
         set os.idlotenf = null
       where os.idordemservico = p_idordemservico;
    
      --Exclui a OR
      pk_recebimento.desfazer_or(v_idlotenf, p_idusuario, 'N');
    
      pk_function_control.disableFunction('ExportarCancelamento');
    
      --Exclui a nota de entrada
      delete from nfimpressao
       where idprenf = v_idPreNfEntrada;
    
      pk_function_control.enableFunction('ExportarCancelamento');
    end desfazerOR;
  
    procedure desfazerOnda is
      v_estoqueverificado notafiscal.estoqueverificado%type;
    begin
      if v_tipoOnda = C_TIPOEXP_ONDA then
        --Cancela a onda (origem por cancelamento de OS)
        pk_onda_cancelar.cancelarOnda(v_idOnda, p_idusuario, 4);
      else
        pk_romaneio.desfazer_romaneio(v_idOnda, p_idusuario, 'N');
      end if;
    
      select nf.estoqueverificado
        into v_estoqueverificado
        from notafiscal nf
       where 1 = 1
         and nf.idprenf = v_idPreNfSaida;
    
      if (v_estoqueverificado = 'S') then
        delete from gtt_selecao;
      
        insert into gtt_selecao
          (idselecionado)
          select nf.idnotafiscal
            from notafiscal nf
           where nf.idprenf = v_idPreNfSaida;
      
        pk_notafiscal.voltarNFLiberada(p_idusuario);
      
        delete from gtt_selecao;
      end if;
    
      pk_function_control.disableFunction('ExportarCancelamento');
    
      ---Excluir a nota de saida
      delete from nfimpressao
       where idprenf = v_idPreNfSaida;
    
      pk_function_control.enableFunction('ExportarCancelamento');
    end desfazerOnda;
  
    procedure atualizarOS is
      C_STATUSOS_AGUARDANDO constant ordemservico.situacao%type := 'A';
    begin
      update ordemservico os
         set os.situacao         = C_STATUSOS_AGUARDANDO,
             os.idusuariocancel  = p_idusuario,
             os.datacancelamento = sysdate
       where os.idordemservico = p_idordemservico;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Suspendeu a execução da OS de desmontagem de kit id:' ||
                            p_idordemservico, p_idordemservico, 'OS');
    
    end atualizarOS;
  begin
    carregarDadosIniciais;
  
    validarOS;
  
    desfazerOR;
  
    desfazerOnda;
  
    atualizarOS;
  end;

  procedure LiberarOSDesmontagemExecucao
  (
    p_idordemservico in number,
    p_idusuario      in number
  ) is
    v_erro varchar2(5000);
  begin
    delete from gtt_resumoexecucao;
    CLiberarOSDesmKits(p_idordemservico, p_idusuario, v_erro);
  end;

  procedure processarOSDesmontManualmente
  (
    p_idordemservico in number,
    p_idusuario      in number
  ) is
    v_idlotenf   number;
    v_idromaneio number;
    v_msg        t_message;
  
    procedure validarSituacaoOS
    (
      p_idordemservico in number,
      v_idlotenf       in out number,
      v_idromaneio     in out number
    ) is
      v_situacao char(1);
    begin
      select situacao, idlotenf, idromaneio
        into v_situacao, v_idlotenf, v_idromaneio
        from ordemservico
       where idordemservico = p_idordemservico;
    
      if v_situacao <> 'O' then
        v_msg := t_message('Somente pode ser processada manualmente OS em alocação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure validarFormacaoOS
    (
      v_idlotenf   in out number,
      v_idromaneio in out number
    ) is
    begin
      if v_idromaneio is null then
        v_msg := t_message('Somente pode ser processada manualmente OS que possui romaneio.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_idlotenf is null then
        v_msg := t_message('Somente pode ser processada manualmente OS que possui Ordem de Recebimento.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure validarAlocacaoOS(v_idlotenf in out number) is
      v_qtde number;
    begin
      select faltamalocar
        into v_qtde
        from lotenf
       where idlotenf = v_idlotenf;
      v_msg := t_message('Somente pode ser processada manualmente OS que não possui pendências de alocação.');
      raise_application_error(-20000, v_msg.formatMessage);
    end;
  begin
    validarSituacaoOS(p_idordemservico, v_idlotenf, v_idromaneio);
    validarFormacaoOS(v_idlotenf, v_idromaneio);
    validarAlocacaoOS(v_idlotenf);
  
    pk_romaneio.processar_romaneio(v_idromaneio, p_idusuario);
    update ordemservico
       set situacao = 'P'
     where idordemservico = p_idordemservico;
  
    pk_utilities.GeraLog(p_idusuario,
                         'PROCESSOU MANUALMENTE A OS ID: ' ||
                          p_idordemservico, p_idordemservico, 'OS');
  end;

  function isOrdemServicoAguardando(p_idOrdemServico in number) return number is
    v_isOSAberta number;
  begin
    select count(1)
      into v_isOSAberta
      from dual
     where exists (select 1
              from ordemservico os
             where os.idordemservico = p_idOrdemServico
               and os.situacao = 'A');
  
    return v_isOSAberta;
  end isOrdemServicoAguardando;

  procedure excluirOsClassificacao
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  ) is
    C_PROCESSADA       constant char(1) := 'P';
    C_CLASSIFICACAO    constant char(1) := 'O';
    C_RECLASSIFICACAO  constant char(1) := 'R';
    C_MISTURA          constant char(1) := 'T';
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_situacao          ordemservico.situacao%type;
    v_tipoServico       ordemservico.tiposervico%type;
    v_regimeDepositante regime.classificacao%type;
  
    v_msg t_message;
  
    procedure excluirLotesVinculados is
    begin
      for c_lotes in (select cml.idlote, cml.qtde, cml.idendereco,
                             cml.idnotafiscalcobertura, os.idnotafiscal
                        from ordemservico os, classificacaomisturalote cml
                       where os.idordemservico = p_idOrdemServico
                         and cml.idordemservico = os.idordemservico)
      loop
        desvincularLtsOsClassificacao(p_idOrdemServico, c_lotes.idlote,
                                      c_lotes.qtde, c_lotes.idendereco,
                                      c_lotes.idnotafiscal);
      end loop;
    end excluirLotesVinculados;
  
  begin
    begin
      select os.situacao, os.tiposervico, r.classificacao
        into v_situacao, v_tipoServico, v_regimeDepositante
        from ordemservico os, depositante d, regime r
       where os.idordemservico = p_idOrdemServico
         and d.identidade = os.identidade
         and r.idregime = d.idregime;
    exception
      when no_data_found then
        v_msg := t_message('OS de Classificação não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if ((v_situacao = C_PROCESSADA) and (v_tipoServico = C_CLASSIFICACAO)) then
      v_msg := t_message('OS de Classificação já processada não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    excluirLotesVinculados;
  
    delete from ordemservico os
     where os.idordemservico = p_idOrdemServico;
  
  end excluirOsClassificacao;

  procedure excluirOsMistura
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  ) is
    C_PROCESSADA       constant char(1) := 'P';
    C_CLASSIFICACAO    constant char(1) := 'O';
    C_RECLASSIFICACAO  constant char(1) := 'R';
    C_MISTURA          constant char(1) := 'T';
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_situacao          ordemservico.situacao%type;
    v_tipoServico       ordemservico.tiposervico%type;
    v_regimeDepositante regime.classificacao%type;
  
    v_msg t_message;
  
    procedure excluirLotesVinculados is
    begin
      for c_lotes in (select cml.idlote, cml.qtde, cml.idendereco,
                             cml.idnotafiscalcobertura, os.idnotafiscal
                        from ordemservico os, classificacaomisturalote cml
                       where os.idordemservico = p_idOrdemServico
                         and cml.idordemservico = os.idordemservico)
      loop
        desvincularLtsOsMistura(p_idOrdemServico, c_lotes.idlote,
                                c_lotes.qtde, c_lotes.idendereco);
      end loop;
    end excluirLotesVinculados;
  
  begin
    begin
      select os.situacao, os.tiposervico, r.classificacao
        into v_situacao, v_tipoServico, v_regimeDepositante
        from ordemservico os, depositante d, regime r
       where os.idordemservico = p_idOrdemServico
         and d.identidade = os.identidade
         and r.idregime = d.idregime;
    exception
      when no_data_found then
        v_msg := t_message('OS de Mistura não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if ((v_situacao = C_PROCESSADA) and (v_tipoServico = C_MISTURA)) then
      v_msg := t_message('OS de Mistura já processada não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    excluirLotesVinculados;
  
    delete from ordemservico os
     where os.idordemservico = p_idOrdemServico;
  
  end excluirOsMistura;

  procedure excluirOsReclassificacao
  (
    p_idUsuario      in number,
    p_idOrdemServico in number
  ) is
    C_PROCESSADA      constant char(1) := 'P';
    C_CLASSIFICACAO   constant char(1) := 'O';
    C_RECLASSIFICACAO constant char(1) := 'R';
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_situacao          ordemservico.situacao%type;
    v_tipoServico       ordemservico.tiposervico%type;
    v_regimeDepositante regime.classificacao%type;
  
    v_msg t_message;
  
    procedure excluirLotesVinculados is
    begin
      for c_lotes in (select cml.idlote, cml.qtde, cml.idendereco,
                             cml.idnotafiscalcobertura, os.idnotafiscal
                        from ordemservico os, classificacaomisturalote cml
                       where os.idordemservico = p_idOrdemServico
                         and cml.idordemservico = os.idordemservico)
      loop
        desvinculaLtsOsReclassificacao(p_idOrdemServico, c_lotes.idlote,
                                       c_lotes.qtde, c_lotes.idendereco);
      end loop;
    end excluirLotesVinculados;
  
  begin
    begin
      select os.situacao, os.tiposervico, r.classificacao
        into v_situacao, v_tipoServico, v_regimeDepositante
        from ordemservico os, depositante d, regime r
       where os.idordemservico = p_idOrdemServico
         and d.identidade = os.identidade
         and r.idregime = d.idregime;
    exception
      when no_data_found then
        v_msg := t_message('OS de Reclassificação não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if ((v_situacao = C_PROCESSADA) and (v_tipoServico = C_RECLASSIFICACAO)) then
      v_msg := t_message('OS de Reclassificação já processada não pode ser excluída.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    excluirLotesVinculados;
  
    delete from ordemservico os
     where os.idordemservico = p_idOrdemServico;
  
  end excluirOsReclassificacao;

  procedure vincularLotesOsClassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idNotaFiscal   in number
  ) is
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_qtdeDisponivel    number;
    v_qtdeUsar          number;
    v_qtde              number;
    v_total             number;
    v_msg               t_message;
    v_regimeDepositante regime.classificacao%type;
  
  begin
    if (p_qtde <= 0) then
      v_msg := t_message('A quantidade informada deve ser maior que zero. Lote id: {0}');
      v_msg.addParam(p_idlote);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select r.classificacao
      into v_regimeDepositante
      from notafiscal nf, depositante d, regime r
     where nf.idnotafiscal = p_idNotaFiscal
       and d.identidade = nf.iddepositante
       and r.idregime = d.idregime;
  
    select count(*)
      into v_total
      from classificacaomisturalote cml
     where cml.idordemservico = p_idOrdemServico
       and cml.idlote = p_idLote
       and cml.idendereco = p_idEndereco;
  
    if (v_total > 0) then
      pk_servico.desvincularLtsOsClassificacao(p_idOrdemServico, p_idLote,
                                               p_qtde, p_idEndereco,
                                               p_idNotaFiscal);
    end if;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      select nvl(sum(clnf.qtdedisponivel - clnf.qtdereservado), 0)
        into v_qtdeDisponivel
        from coberturalotedispnf clnf
       where clnf.idlote = p_idLote;
    
      if (v_qtde > v_qtdeDisponivel) then
      
        v_msg := t_message('Quantidade de Cobertura insuficiente para atender a OS de Classificação.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idNotaFiscal: {1}' || chr(13) ||
                           ' idLote: {2}' || chr(13) ||
                           ' Quantidade solicitada: {3}' || chr(13) ||
                           ' Quantidade disponível: {4}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idNotaFiscal);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                 clnf.idnfentrada,
                                 sum(clnf.qtdedisponivel -
                                      clnf.qtdereservado) disponivel
                            from coberturalotedispnf clnf
                           where clnf.idlote = p_idLote
                           group by clnf.idlote, clnf.idnotafiscalcobertura,
                                    clnf.idnfentrada)
      
      loop
      
        if (v_qtde > c_lotes_cob.disponivel) then
          v_qtdeUsar := c_lotes_cob.disponivel;
        else
          v_qtdeUsar := v_qtde;
        end if;
      
        insert into classificacaomisturalote
          (idclassificacao, idordemservico, idlote, qtde, idendereco,
           idnotafiscalcobertura)
        values
          (seq_classificacaomisturalote.nextval, p_idOrdemServico,
           c_lotes_cob.idlote, v_qtdeUsar, p_idEndereco,
           c_lotes_cob.idnotafiscalcobertura);
      
        update coberturalotedispnf cnf
           set cnf.qtdereservado = cnf.qtdereservado + v_qtdeUsar
         where cnf.idlote = c_lotes_cob.idlote
           and cnf.idnfentrada = c_lotes_cob.idnfentrada
           and cnf.idnotafiscalcobertura =
               c_lotes_cob.idnotafiscalcobertura;
      
        v_qtde := v_qtde - v_qtdeUsar;
        exit when v_qtde = 0;
      end loop;
    
    else
      begin
        select sum(nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                    nvl(ll.adicionar, 0))
          into v_qtdeDisponivel
          from lote lt, lotelocal ll
         where lt.idlote = p_idLote
           and ll.idlote = lt.idlote;
      
      exception
        when no_data_found then
          v_qtdeDisponivel := 0;
      end;
    
      if (p_qtde > v_qtdeDisponivel) then
        v_msg := t_message('Quantidade insuficiente para atender a OS de Classificação.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idNotaFiscal: {1}' || chr(13) ||
                           ' idLote: {2}' || chr(13) ||
                           ' Quantidade solicitada: {3}' || chr(13) ||
                           ' Quantidade disponível: {4}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idNotaFiscal);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      insert into classificacaomisturalote
        (idclassificacao, idordemservico, idlote, qtde, idendereco)
      values
        (seq_classificacaomisturalote.nextval, p_idOrdemServico, p_idLote,
         p_qtde, p_idEndereco);
    
    end if;
  end vincularLotesOsClassificacao;

  procedure vincularLotesOsMistura
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  ) is
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_qtdeDisponivel    number;
    v_qtdeUsar          number;
    v_qtde              number;
    v_total             number;
    v_msg               t_message;
    v_regimeDepositante regime.classificacao%type;
  
  begin
    if (p_qtde <= 0) then
      v_msg := t_message('A quantidade informada deve ser maior que zero. Lote id: {0}');
      v_msg.addParam(p_idlote);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select r.classificacao
      into v_regimeDepositante
      from lote lt, depositante d, regime r
     where lt.idlote = p_idLote
       and d.identidade = lt.iddepositante
       and r.idregime = d.idregime;
  
    select count(*)
      into v_total
      from classificacaomisturalote cml
     where cml.idordemservico = p_idOrdemServico
       and cml.idlote = p_idLote
       and cml.idendereco = p_idEndereco;
  
    if (v_total > 0) then
      pk_servico.desvincularLtsOsMistura(p_idOrdemServico, p_idLote, p_qtde,
                                         p_idEndereco);
    end if;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      select nvl(sum(clnf.qtdedisponivel - clnf.qtdereservado), 0)
        into v_qtdeDisponivel
        from coberturalotedispnf clnf
       where clnf.idlote = p_idLote;
    
      if (v_qtde > v_qtdeDisponivel) then
      
        v_msg := t_message('Quantidade de Cobertura insuficiente para atender a OS de Mistura.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idLote: {1}' || chr(13) ||
                           ' Quantidade solicitada: {2}' || chr(13) ||
                           ' Quantidade disponível: {3}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                 clnf.idnfentrada,
                                 sum(clnf.qtdedisponivel -
                                      clnf.qtdereservado) disponivel
                            from coberturalotedispnf clnf
                           where clnf.idlote = p_idLote
                           group by clnf.idlote, clnf.idnotafiscalcobertura,
                                    clnf.idnfentrada)
      
      loop
      
        if (v_qtde > c_lotes_cob.disponivel) then
          v_qtdeUsar := c_lotes_cob.disponivel;
        else
          v_qtdeUsar := v_qtde;
        end if;
      
        insert into classificacaomisturalote
          (idclassificacao, idordemservico, idlote, qtde, idendereco,
           idnotafiscalcobertura)
        values
          (seq_classificacaomisturalote.nextval, p_idOrdemServico,
           c_lotes_cob.idlote, v_qtdeUsar, p_idEndereco,
           c_lotes_cob.idnotafiscalcobertura);
      
        update coberturalotedispnf cnf
           set cnf.qtdereservado = cnf.qtdereservado + v_qtdeUsar
         where cnf.idlote = c_lotes_cob.idlote
           and cnf.idnfentrada = c_lotes_cob.idnfentrada
           and cnf.idnotafiscalcobertura =
               c_lotes_cob.idnotafiscalcobertura;
      
        v_qtde := v_qtde - v_qtdeUsar;
        exit when v_qtde = 0;
      end loop;
    
    else
      begin
        select sum(nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                    nvl(ll.adicionar, 0))
          into v_qtdeDisponivel
          from lote lt, lotelocal ll
         where lt.idlote = p_idLote
           and ll.idlote = lt.idlote;
      
      exception
        when no_data_found then
          v_qtdeDisponivel := 0;
      end;
    
      if (p_qtde > v_qtdeDisponivel) then
        v_msg := t_message('Quantidade insuficiente para atender a OS de Mistura.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idLote: {1}' || chr(13) ||
                           ' Quantidade solicitada: {2}' || chr(13) ||
                           ' Quantidade disponível: {3}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      insert into classificacaomisturalote
        (idclassificacao, idordemservico, idlote, qtde, idendereco,
         idnotafiscalcobertura)
      values
        (seq_classificacaomisturalote.nextval, p_idOrdemServico, p_idLote,
         p_qtde, p_idEndereco, null);
    
    end if;
  
  end vincularLotesOsMistura;

  procedure desvincularLtsOsClassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idNotaFiscal   in number
  ) is
  
    C_REGIME_ARM_GERAL  constant char(1) := 'A';
    C_REGIME_ARM_FILIAL constant char(1) := 'F';
  
    v_qtde              number;
    v_qtdeRetirar       number;
    v_regimeDepositante regime.classificacao%type;
  
  begin
  
    begin
      select r.classificacao
        into v_regimeDepositante
        from notafiscal nf, depositante d, regime r
       where nf.idnotafiscal = p_idNotaFiscal
         and d.identidade = nf.iddepositante
         and r.idregime = d.idregime;
    exception
      when no_data_found then
        v_regimeDepositante := C_REGIME_ARM_FILIAL;
    end;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                 clnf.idnfentrada,
                                 sum(clnf.qtdereservado) reservado
                            from coberturalotedispnf clnf
                           where clnf.idlote = p_idLote
                             and clnf.idnfentrada = p_idNotaFiscal
                           group by clnf.idlote, clnf.idnotafiscalcobertura,
                                    clnf.idnfentrada)
      
      loop
      
        if (v_qtde > c_lotes_cob.reservado) then
          v_qtdeRetirar := c_lotes_cob.reservado;
        else
          v_qtdeRetirar := v_qtde;
        end if;
      
        delete from classificacaomisturalote cml
         where cml.idordemservico = p_idOrdemServico
           and cml.idlote = c_lotes_cob.idlote
           and cml.idendereco = p_idEndereco
           and cml.idnotafiscalcobertura =
               c_lotes_cob.idnotafiscalcobertura;
      
        update coberturalotedispnf cnf
           set cnf.qtdereservado = cnf.qtdereservado - v_qtdeRetirar
         where cnf.idlote = c_lotes_cob.idlote
           and cnf.idnfentrada = c_lotes_cob.idnfentrada
           and cnf.idnotafiscalcobertura =
               c_lotes_cob.idnotafiscalcobertura;
      
        v_qtde := v_qtde - v_qtdeRetirar;
      
        exit when v_qtde = 0;
      
      end loop;
    
    else
    
      delete from classificacaomisturalote cml
       where cml.idordemservico = p_idOrdemServico
         and cml.idlote = p_idLote
         and cml.idendereco = p_idEndereco;
    
    end if;
  
  end desvincularLtsOsClassificacao;

  procedure desvincularLtsOsMistura
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  ) is
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_qtde              number;
    v_qtdeRetirar       number;
    v_regimeDepositante regime.classificacao%type;
  
  begin
  
    select r.classificacao
      into v_regimeDepositante
      from lote lt, depositante d, regime r
     where lt.idlote = p_idLote
       and d.identidade = lt.iddepositante
       and r.idregime = d.idregime;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      for c_lotes_vinc in (select cml.idordemservico, cml.idlote, cml.qtde,
                                  cml.idnotafiscalcobertura
                             from classificacaomisturalote cml
                            where cml.idordemservico = p_idOrdemServico
                              and cml.idlote = p_idLote
                              and cml.idendereco = p_idEndereco)
      loop
      
        for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                   clnf.idnfentrada,
                                   sum(clnf.qtdereservado) reservado
                              from coberturalotedispnf clnf
                             where clnf.idlote = c_lotes_vinc.idlote
                               and clnf.idnotafiscalcobertura =
                                   c_lotes_vinc.idnotafiscalcobertura
                             group by clnf.idlote, clnf.idnotafiscalcobertura,
                                      clnf.idnfentrada)
        
        loop
        
          if (v_qtde > c_lotes_cob.reservado) then
            v_qtdeRetirar := c_lotes_cob.reservado;
          else
            v_qtdeRetirar := v_qtde;
          end if;
        
          delete from classificacaomisturalote cml
           where cml.idordemservico = p_idOrdemServico
             and cml.idlote = c_lotes_cob.idlote
             and cml.idendereco = p_idEndereco
             and cml.idnotafiscalcobertura =
                 c_lotes_cob.idnotafiscalcobertura;
        
          update coberturalotedispnf cnf
             set cnf.qtdereservado = cnf.qtdereservado - v_qtdeRetirar
           where cnf.idlote = c_lotes_cob.idlote
             and cnf.idnfentrada = c_lotes_cob.idnfentrada
             and cnf.idnotafiscalcobertura =
                 c_lotes_cob.idnotafiscalcobertura;
        
          v_qtde := v_qtde - v_qtdeRetirar;
        
          exit when v_qtde = 0;
        end loop;
      end loop;
    
    else
    
      delete from classificacaomisturalote cml
       where cml.idordemservico = p_idOrdemServico
         and cml.idlote = p_idLote
         and cml.idendereco = p_idEndereco;
    
    end if;
  
  end desvincularLtsOsMistura;

  procedure executarOrdemServico
  (
    p_idOrdemServico in number,
    p_idUsuario      in number,
    p_commit         in varchar2 := c_sim
  ) is
  
    v_idNfOrigem  notafiscal.idnotafiscal%type;
    v_idNfDestino notafiscal.idnotafiscal%type;
    v_idLoteNf    lotenf.idlotenf%type;
    v_tipoServico ordemservico.tiposervico%type;
    v_idOsMistura ordemservico.idosmistura%type;
  
    cursor c_ordemServico(p_idOS in ordemservico.idordemservico%type) is
      select os.idordemservico, os.tiposervico, os.idarmazem, os.situacao,
             os.iddoca, os.identidade, os.idnotafiscal
        from ordemservico os
       where idordemservico = p_idOS;
  
    cursor c_romaneio(p_idRomaneio in romaneiopai.idromaneio%type) is
      select r.*
        from romaneiopai r
       where r.idromaneio = p_idRomaneio;
  
    r_os        c_ordemServico%rowtype;
    r_nf        notafiscal%rowtype;
    r_nfdet     nfdet%rowtype;
    r_romaneio  c_romaneio%rowtype;
    v_msg       t_message;
    v_idUnidade number;
  
    procedure realizarProcessoSaida is
      procedure criarDocumentoSaida is
        v_idproduto number;
        v_qtde      number;
      
      begin
      
        if c_ordemServico%isopen then
          close c_ordemServico;
        end if;
      
        open c_ordemServico(p_idOrdemServico);
        fetch c_ordemServico
          into r_os;
      
        select a.identidade
          into v_idunidade
          from armazem a
         where a.idarmazem = r_os.idarmazem;
      
        -- Criando cabecalho da nota fiscal de saída
        r_nf.codigointerno      := '-1';
        r_nf.sequencia          := 'OS-INTERNA';
        r_nf.usuario            := p_idUsuario;
        r_nf.remetente          := v_idUnidade;
        r_nf.destinatario       := v_idUnidade;
        r_nf.dataemissao        := sysdate;
        r_nf.statusnf           := 'N';
        r_nf.digitada           := C_NAO;
        r_nf.impresso           := C_SIM;
        r_nf.ident_entrega      := v_idUnidade;
        r_nf.tipo               := C_SAIDA;
        r_nf.iddepositante      := r_os.identidade;
        r_nf.movestoque         := C_SIM;
        r_nf.estoqueverificado  := C_SIM;
        r_nf.statusroteirizacao := 2;
        r_nf.docinterno         := 1;
        r_nf.idarmazem          := r_os.idarmazem;
        r_nf.idnotafiscal       := pk_notafiscal.insere_cabecalho_nf(r_nf);
      
        update notafiscal
           set codigointerno = r_nf.idnotafiscal
         where idnotafiscal = r_nf.idnotafiscal;
      
        select os.idproduto, sum(cml.qtde)
          into v_idproduto, v_qtde
          from ordemservico os, classificacaomisturalote cml
         where cml.idordemservico = os.idordemservico
           and os.idordemservico = p_idOrdemServico
         group by os.idproduto;
      
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := r_nf.idnotafiscal;
        r_nfdet.barra            := pk_produto.ret_codbarra(v_idproduto, 1);
        r_nfdet.idproduto        := v_idproduto;
        r_nfdet.precounitliquido := 0;
        r_nfdet.qtde             := v_qtde;
        r_nfdet.qtdeatendida     := v_qtde;
      
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      
        pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
      
      end criarDocumentoSaida;
    
      procedure vincularSeparacaoEspecifica is
        cursor c_estoque
        (
          p_idLote     number,
          p_idEndereco number
        ) is
          select el.idlocal, el.idlote,
                 (el.disp - nvl(sp.qtdeseparada, 0)) disp, el.disp disp3,
                 (el.disp - nvl(sp.qtdeseparada, 0)) qtdedisponivel
            from v_estoque_local el,
                 (select se.idarmazem, se.idlocal, se.idlote,
                          sum(se.qtde) qtdeseparada
                     from v_notafiscal_pendente np, separacaoespecifica se,
                          lote l
                    where np.statusnf in (C_NORMAL, C_IMPORTADA, C_CARGA)
                      and se.idnotafiscal = np.idnotafiscal
                      and l.idlote = se.idlote
                      and np.idproduto = l.idproduto
                    group by se.idarmazem, se.idlocal, se.idlote) sp,
                 lote lt
           where el.idlote = p_idLote
             and el.h$idendereco = p_idEndereco
             and lt.idlote = el.idlote
             and sp.idarmazem(+) = el.idarmazem
             and sp.idlocal(+) = el.idlocal
             and sp.idlote(+) = el.idlote
             and (el.disp - nvl(sp.qtdeseparada, 0)) > 0
             and nvl(el.estadolote, 'N') = 'N'
             and el.loteliberado = 'S'
             and nvl(el.expedicao, 'S') = 'S'
             and el.localativo = 'S'
             and el.tipo in (0, 1, 2)
             and el.buffer = 'N'
             and el.tipolote = 'L'
             and (nvl(el.estoque, 0) + nvl(el.adicionar, 0)) -
                 (nvl(el.pendencia, 0) + nvl(el.reservado, 0)) > 0
           order by nvl(el.dtvenc, sysdate), lt.dtentrada, lt.idlote, el.rua,
                    el.predio, el.andar, el.apartamento;
      
        procedure incluirSepEspecifica
        (
          p_idNotafiscal   in number,
          p_idOrdemServico in number
        ) is
          r_estoque       c_estoque%rowtype;
          v_qtderestante  number;
          v_qtdesep       number;
          v_msg           t_message;
          v_classificacao char(1);
        begin
        
          select r.classificacao
            into v_classificacao
            from notafiscal n, depositante d, regime r
           where d.identidade = n.iddepositante
             and r.idregime = d.idregime
             and n.idnotafiscal = p_idNotafiscal;
        
          for c_cml in (select cml.idlote, cml.idendereco,
                               sum(nvl(cml.qtde, 0)) qtde, p.codigointerno
                          from classificacaomisturalote cml, lote lt,
                               produto p
                         where cml.idordemservico = p_idOrdemServico
                           and lt.idlote = cml.idlote
                           and p.idproduto = lt.idproduto
                         group by cml.idlote, cml.idendereco, p.codigointerno)
          loop
          
            if c_estoque%isopen then
              close c_estoque;
            end if;
          
            open c_estoque(c_cml.idlote, c_cml.idendereco);
          
            fetch c_estoque
              into r_estoque;
          
            v_qtderestante := c_cml.qtde;
          
            while (v_qtderestante > 0)
                  and (c_estoque%found)
            loop
              if v_classificacao = 'F' then
                if r_estoque.disp <= v_qtderestante then
                  v_qtdesep := r_estoque.disp;
                else
                  v_qtdesep := v_qtderestante;
                end if;
              else
                if r_estoque.qtdedisponivel <= v_qtderestante then
                  v_qtdesep := r_estoque.qtdedisponivel;
                else
                  v_qtdesep := v_qtderestante;
                end if;
              end if;
            
              if v_qtdesep > 0 then
                insert into separacaoespecifica
                  (idarmazem, idlote, idlocal, idnotafiscal, qtde,
                   cadmanual)
                values
                  (r_os.idarmazem, r_estoque.idlote, r_estoque.idlocal,
                   p_idNotafiscal, v_qtdesep, c_nao);
              
                if v_classificacao = 'F' then
                  if c_cml.qtde <= r_estoque.disp then
                    v_qtderestante := 0;
                  else
                    v_qtderestante := v_qtderestante - r_estoque.disp;
                  end if;
                else
                  if c_cml.qtde <= r_estoque.qtdedisponivel then
                    v_qtderestante := 0;
                  else
                    v_qtderestante := v_qtderestante -
                                      r_estoque.qtdedisponivel;
                  end if;
                end if;
              end if;
              fetch c_estoque
                into r_estoque;
            end loop;
            if v_qtderestante > 0 then
              v_msg := t_message('Nao existe estoque suficiente para atender a demanda. Produto: {0}');
              v_msg.addParam(c_cml.codigointerno);
              raise_application_error(-20123, v_msg.formatMessage);
            end if;
          end loop;
        
        end incluirSepEspecifica;
      
      begin
      
        -- Trocando o status para funcionamento de separação específica
        update ordemservico
           set situacao = 'X'
         where idordemservico = r_os.idordemservico;
      
        incluirSepEspecifica(r_nf.idnotafiscal, r_os.idordemservico);
      
      end vincularSeparacaoEspecifica;
    
      procedure realizarExpedicaoRomaneio is
      
        procedure raiseCorteRomaneio is
          v_prod_erro varchar2(4000);
        
        begin
          v_msg       := t_message('HOUVE CORTE NA FORMACAO DO ROMANEIO' ||
                                   chr(13));
          v_prod_erro := v_msg.v_message;
        
          for c_corte in (select p.codigointerno,
                                 substr(p.descr, 1, 20) produto,
                                 sum(c.qtdepedido) qtdepedido,
                                 nvl(c.qtdedisponivelpk, 0) qtdedisponivelpk,
                                 nvl(c.qtdedisponivelpl, 0) qtdedisponivelpl
                            from corteromaneio c, produto p
                           where p.idproduto = c.idproduto
                             and c.idromaneio = r_romaneio.idromaneio
                           group by p.codigointerno, substr(p.descr, 1, 20),
                                    c.qtdedisponivelpk, c.qtdedisponivelpl
                          having sum(c.qtdepedido) > nvl(c.qtdedisponivelpl, 0))
          loop
            v_msg := t_message('{0}' || chr(13) || 'Produto: {1} - {2}' ||
                               chr(13) || 'Pedido: {3}' || chr(13) ||
                               'Disp.PK: {4}' || chr(13) || 'Disp.PL: {5}' ||
                               chr(13));
            v_msg.addParam(v_prod_erro);
            v_msg.addParam(c_corte.codigointerno);
            v_msg.addParam(c_corte.produto);
            v_msg.addParam(c_corte.qtdepedido);
            v_msg.addParam(c_corte.qtdedisponivelpk);
            v_msg.addParam(c_corte.qtdedisponivelpl);
            v_prod_erro := substr(v_msg.formatMessage, 1, 4000);
          
          end loop;
        
          raise_application_error(-20000, v_prod_erro);
        
        end;
      
      begin
      
        r_romaneio.placa          := pk_veiculo.pegaveiculopadrao;
        r_romaneio.idusuario      := p_idUsuario;
        r_romaneio.idarmazem      := r_os.idarmazem;
        r_romaneio.iddoca         := r_os.iddoca;
        r_romaneio.datageracao    := sysdate;
        r_romaneio.tituloromaneio := 'SAÍDA PARA FORMACÃO DE ORDEM DE SERVIÇO INTERNA N:' ||
                                     r_os.idordemservico;
        r_romaneio.faturado       := C_SIM;
        r_romaneio.coletado       := C_SIM;
        r_romaneio.idromaneio     := pk_romaneio.inserir_romaneiopai(r_romaneio);
      
        insert into nfromaneio
          (idromaneio, idnotafiscal, sequencia)
        values
          (r_romaneio.idromaneio, r_nf.idnotafiscal, 1);
      
        update ordemservico
           set idromaneio = r_romaneio.idromaneio
         where idordemservico = p_idordemservico;
      
        pk_romaneio.formar_romaneio(r_romaneio.idromaneio, p_idUsuario,
                                    C_NAO, C_NAO);
      
        if c_romaneio%isopen then
          close c_romaneio;
        end if;
      
        open c_romaneio(r_romaneio.idromaneio);
        fetch c_romaneio
          into r_romaneio;
      
        if r_romaneio.erro = C_ERRO then
          raiseCorteRomaneio;
        end if;
      
        if r_romaneio.gerado <> C_SEPARACAO then
          v_msg := t_message('HOUVE ERRO NA FORMACAO DO ROMANEIO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        -- Fatura o Romaneio
        update romaneiopai
           set faturado = C_FATURADO
         where idromaneio = r_romaneio.idromaneio;
      
        -- Gera a conferencia de saida
        pk_confsaida.gerarcontagem(r_romaneio.idromaneio, p_idUsuario);
      
        -- Processa o romaneio
        pk_romaneio.processar_romaneio(r_romaneio.idromaneio, p_idUsuario);
      
      end realizarExpedicaoRomaneio;
    
    begin
      criarDocumentoSaida;
      vincularSeparacaoEspecifica;
      realizarExpedicaoRomaneio;
    end realizarProcessoSaida;
  
    procedure realizarProcessoEntrada
    (
      p_idNfDestino out notafiscal.idnotafiscal%type,
      p_idLoteNf    out lotenf.idlotenf%type
    ) is
      r_lotenf lotenf%rowtype;
    
      procedure criarDocumentoEntrada is
      begin
      
        r_nf.tipo              := C_ENTRADA;
        r_nf.estoqueverificado := null;
        r_nf.idnotafiscal      := pk_notafiscal.insere_cabecalho_nf(r_nf);
      
        update notafiscal
           set codigointerno = r_nf.idnotafiscal
         where idnotafiscal = r_nf.idnotafiscal;
      
        for c_lotesOS in (select os.idproduto, cml.qtde, lt.valorlote
                            from ordemservico os,
                                 classificacaomisturalote cml, lote lt
                           where cml.idordemservico = os.idordemservico
                             and lt.idlote = cml.idlote
                             and os.idordemservico = p_idOrdemServico)
        loop
          r_nfdet.idnfdet          := null;
          r_nfdet.nf               := r_nf.idnotafiscal;
          r_nfdet.barra            := pk_produto.ret_codbarra(c_lotesOS.idproduto,
                                                              1);
          r_nfdet.idproduto        := c_lotesOS.idproduto;
          r_nfdet.precounitliquido := c_lotesOS.Valorlote;
          r_nfdet.qtde             := c_lotesOS.qtde;
          r_nfdet.qtdeatendida     := c_lotesOS.qtde;
        
          if r_nfdet.barra is null then
            v_msg := t_message('Material "{0}" nao possui código de barras de fator 1 cadastrado ou ativo.' ||
                               chr(13) || 'Operação Cancelada');
            v_msg.addParam(c_lotesOS.Idproduto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          pk_notafiscal.insere_detalhe_nf(r_nfdet);
        end loop;
      
        pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
      
        p_idNfDestino := r_nf.idnotafiscal;
      
      end criarDocumentoEntrada;
    
      procedure criarOrdemRecebimentoOS is
        cursor c_tiporec is
          select min(t.idtiporecebimento) idtiporecebimento
            from tiporecebimento t
           where t.classificacao = C_MOVINTERNO
             and t.gerarloteporpalete = 1
             and t.geraralocacaoporpalete = 1;
      
        cursor c_doca(p_armazem in armazem.idarmazem%type) is
          select min(d.iddoca) iddoca
            from doca d
           where d.idarmazem = p_armazem;
      
        r_tiporec           c_tiporec%rowtype;
        r_doca              c_doca%rowtype;
        v_obrigaremetenteor char(1);
      
      begin
      
        if c_tiporec%isopen then
          close c_tiporec;
        end if;
      
        if c_doca%isopen then
          close c_doca;
        end if;
      
        open c_tiporec;
        fetch c_tiporec
          into r_tiporec;
      
        if c_tiporec%notfound then
          v_msg := t_message('TIPO DE RECEBIMENTO DE OPERAÇÕES INTERNAS NÃO CADASTRADO. OPERAÇÃO CANCELADA.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        open c_doca(r_os.idarmazem);
        fetch c_doca
          into r_doca;
      
        if c_doca%notfound then
          v_msg := t_message('NENHUMA DOCA ENCONTRADA PARA O ARMAZEM SELECIONADO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select d.obrigaremetenteor
          into v_obrigaremetenteor
          from depositante d
         where d.identidade = r_os.identidade;
      
        r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
        r_lotenf.descr             := 'FORMACÃO DE OS INTERNA N: ' ||
                                      r_os.idordemservico;
        r_lotenf.data              := sysdate;
        r_lotenf.idusuario         := p_idUsuario;
        r_lotenf.idarmazem         := r_os.idarmazem;
        r_lotenf.iddoca            := r_doca.iddoca;
        r_lotenf.identidade        := r_os.identidade;
        r_lotenf.modal             := 0;
      
        if v_obrigaremetenteor = 'S' then
          r_lotenf.idremetente := v_idunidade;
        end if;
      
        r_lotenf.idlotenf := pk_recebimento.cadastrar_OR(r_lotenf);
      
        p_idLoteNf := r_lotenf.idlotenf;
      
      end criarOrdemRecebimentoOS;
    
      procedure vincularNFentradaOR is
      begin
        update notafiscal
           set idlotenf = r_lotenf.idlotenf
         where idnotafiscal = r_nf.idnotafiscal;
      
        -- Atualiza as informações na ordemservico
        update ordemservico
           set idromaneio        = r_romaneio.idromaneio,
               idlotenf          = r_lotenf.idlotenf,
               dataprocessamento = sysdate,
               situacao          = C_PROCESSADO
         where idordemservico = r_os.idordemservico;
      
        pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
      
      end vincularNFentradaOR;
    begin
      criarDocumentoEntrada;
      criarOrdemRecebimentoOS;
      vincularNFentradaOR;
    
    end realizarProcessoEntrada;
  
    procedure finalizarProcessoClassificacao is
      v_idlotenf   number;
      v_idromaneio number;
    begin
    
      if p_commit = c_sim then
        commit;
      end if;
    
      select os.idlotenf, os.idromaneio
        into v_idlotenf, v_idromaneio
        from ordemservico os
       where os.idordemservico = p_idOrdemServico;
    
      pk_utilities.GeraLog(p_idUsuario,
                           'Tela: Ordem de Classificação [Classificação/Reclassificação] de Serviço realizada: idOrdemServico: ' ||
                            p_idordemservico || ', idlotenf: ' || v_idlotenf ||
                            ', idromaneio: ' || v_idromaneio,
                           p_idOrdemServico, 'CA');
    end finalizarProcessoClassificacao;
  
    procedure verificarLotesVinculados is
      v_lotesVinc number;
      v_msg       t_message;
    begin
    
      select count(1)
        into v_lotesVinc
        from classificacaomisturalote cml
       where cml.idordemservico = p_idOrdemServico;
    
      if (v_lotesVinc = 0) then
        v_msg := t_message('Não existe lote vinculado para a OS {0}.');
        v_msg.addParam(p_idOrdemServico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end verificarLotesVinculados;
  
    procedure criarVinculoNfOrdemServico
    (
      p_idNfOrigem  in notafiscal.idnotafiscal%type,
      p_idNfDestino in notafiscal.idnotafiscal%type,
      p_idLoteNf    in lotenf.idlotenf%type,
      p_idOsMistura in ordemservico.idosmistura%type
    ) is
    begin
    
      insert into nfordemservico
        (idnfordemservico, idnotafiscalorigem, idnotafiscaldestino,
         idordemservico, idlotenf, idordemservicoorigem,
         idordemservicodestino)
      values
        (seq_nfordemservico.nextval, p_idNfOrigem, p_idNfDestino,
         p_idOrdemServico, p_idLoteNf, p_idOsMistura, p_idOrdemServico);
    end criarVinculoNfOrdemServico;
  
  begin
    verificarLotesVinculados;
    realizarProcessoSaida;
    realizarProcessoEntrada(v_idNfDestino, v_idLoteNf);
    finalizarProcessoClassificacao;
  
    select os.idnotafiscal, os.tiposervico, os.idosmistura
      into v_idNfOrigem, v_tipoServico, v_idOsMistura
      from ordemservico os
     where os.idordemservico = p_idOrdemServico;
  
    if (v_tipoServico in ('O', 'R')) then
    
      criarVinculoNfOrdemServico(v_idNfOrigem, v_idNfDestino, v_idLoteNf,
                                 v_idOsMistura);
    
    end if;
  
  end executarOrdemServico;

  procedure gerarSeparacaoMistura(p_idromaneio in number) is
  
    TYPE def_aux IS RECORD(
      codigo    number,
      descricao varchar2(100),
      codigo2   number);
  
    TYPE DEF_tabela_aux IS TABLE OF DEF_AUX;
    tabela_aux DEF_tabela_aux := DEF_tabela_aux();
  
    TYPE DEF_AUX2 IS RECORD(
      CODIGO    INT,
      DESCRICAO VARCHAR2(100),
      CODIGO2   INT);
  
    TYPE DEF_TABELA_AUX2 IS TABLE OF DEF_AUX2;
    TABELA_AUX2 DEF_TABELA_AUX2 := DEF_TABELA_AUX2();
  
    cursor c_r is
      select k.loteindustria, k.quantidade,
             (select distinct max(m.quantidade) maior
                 from (select vr.loteindustria, count(*) quantidade
                          from v_separacaoclassificacao vr
                         where vr.idromaneio in (p_idromaneio)
                         group by vr.loteindustria) m) maior
        from (select vr.loteindustria, count(*) quantidade
                 from v_separacaoclassificacao vr
                where vr.idromaneio in (p_idromaneio)
                group by vr.loteindustria) k
       group by k.loteindustria, k.quantidade
       order by k.quantidade desc;
  
    qtd_maxima   number;
    divisor      number;
    conta        number;
    conta2       number;
    contador     number := 1;
    contlinha    number := 1;
    v_lote       varchar2(100);
    v_quantidade number;
    v_ordem      number;
    v_sequencia  number;
    v_entrou     boolean := false;
  
    procedure atualizarIdLoteRegiao(v_sequencia in number) is
    begin
      for r_lote in (select v.idlote, v.idregiao, v.loteindustria
                       from v_separacaoclassificacao v
                      where v.idromaneio = p_idromaneio)
      loop
        update separacaomistura g
           set g.idlote   = r_lote.idlote,
               g.idregiao = r_lote.idregiao
         where g.loteindustria = r_lote.loteindustria
           and g.idromaneio = p_idromaneio
           and nvl(g.idlote, 0) = 0
           and idseparacaomistura = v_sequencia
           and rownum = 1;
      end loop;
    end atualizarIdLoteRegiao;
  
  begin
  
    delete separacaomistura
     where idromaneio = p_idromaneio;
  
    for reg in c_r
    
    loop
    
      qtd_maxima := reg.maior;
      divisor    := trunc(qtd_maxima / reg.quantidade);
    
      if (divisor < 1) then
        divisor := 1;
      end if;
    
      if (divisor = qtd_maxima) then
        divisor := trunc(divisor / 2);
      
        if divisor = 0 then
          divisor := 1;
        end if;
      
      end if;
    
      conta     := divisor;
      contlinha := 1;
    
      while conta <= qtd_maxima
      loop
        if (contlinha <= reg.quantidade) then
          tabela_aux.EXTEND(1);
          tabela_aux(tabela_aux.LAST).codigo := conta;
          tabela_aux(tabela_aux.LAST).descricao := reg.loteindustria;
          tabela_aux(tabela_aux.LAST).codigo2 := contador;
          v_entrou := true;
          contlinha := contlinha + 1;
        end if;
        conta := conta + divisor;
      end loop;
      contador := contador + 1;
    end loop;
  
    if v_entrou then
      begin
        select seq_SEPARACAOMISTURA.nextval
          into v_sequencia
          from dual;
      end;
    end if;
  
    for i in tabela_aux.first .. tabela_aux.last
    loop
    
      insert into separacaomistura
        (rodada, loteIndustria, ordem, idromaneio, idseparacaomistura)
      values
        (tabela_aux(i).codigo, tabela_aux(i).descricao,
         tabela_aux(i).codigo2, p_idromaneio, v_sequencia);
    
    end loop;
  
    v_entrou := false;
  
    for reg in (select count(rodada) linhas, rodada
                  from separacaomistura
                 where idseparacaomistura = v_sequencia
                 group by rodada
                 order by rodada desc)
    loop
      if (reg.linhas = 1) then
      
        begin
          select loteIndustria
            into v_lote
            from separacaomistura
           where rodada = reg.rodada
             and idseparacaomistura = v_sequencia;
        exception
          when no_data_found then
            v_lote := '';
        end;
      
        v_quantidade := nvl(v_quantidade, 0) + 1;
      
      else
        qtd_maxima := reg.rodada;
        delete separacaomistura
         where rodada > reg.rodada
           and idseparacaomistura = v_sequencia;
        exit;
      end if;
    end loop;
  
    if nvl(v_quantidade, 0) > 0 then
      divisor := trunc(qtd_maxima / v_quantidade);
    
      if (divisor < 1) then
        divisor := 1;
      end if;
    
      if (divisor = qtd_maxima) then
        divisor := trunc(qtd_maxima / 2);
      
        if divisor = 0 then
          divisor := 1;
        end if;
      
      end if;
    
      conta := divisor;
    
      while conta <= qtd_maxima
      loop
        if v_quantidade > 0 then
          insert into separacaomistura
            (rodada, loteIndustria, ordem, idromaneio, idseparacaomistura)
          values
            (conta, v_lote, 1, p_idromaneio, v_sequencia);
          conta        := conta + divisor;
          v_quantidade := nvl(v_quantidade, 0) - 1;
        else
          exit;
        end if;
      end loop;
    
    end if;
  
    for reg in (select t.rodada as ordem, t.loteIndustria descr,
                       count(t.rodada) as quantidade, i.maior
                  from separacaomistura t,
                       (select max(x.quantidade) maior, x.rodada
                           from (select j.rodada, j.loteIndustria descr,
                                         count(j.rodada) as quantidade
                                    from separacaomistura j
                                   where idseparacaomistura = v_sequencia
                                   group by j.rodada, j.loteIndustria) x
                          group by x.rodada) i
                 where t.rodada = i.rodada
                   and idseparacaomistura = v_sequencia
                 group by t.rodada, t.loteIndustria, i.maior
                 order by t.rodada, count(t.rodada) desc)
    loop
    
      if nvl(v_ordem, 0) = 0 then
        v_ordem    := reg.ordem;
        qtd_maxima := 0;
        divisor    := 0;
        conta      := v_ordem;
        conta2     := 0;
        contlinha  := 0;
      else
        if v_ordem <> reg.ordem then
          v_ordem    := reg.ordem;
          qtd_maxima := 0;
          divisor    := 0;
          conta      := v_ordem;
          conta2     := 0;
          contlinha  := 0;
        end if;
      end if;
    
      qtd_maxima := reg.maior;
      divisor    := trunc(qtd_maxima / reg.quantidade);
    
      if (divisor < 1) then
        divisor := 1;
      end if;
    
      if (divisor = qtd_maxima) then
        divisor := trunc(qtd_maxima / 2);
        if divisor = 0 then
          divisor := 1;
        end if;
      end if;
    
      conta2 := divisor;
    
      contlinha := 1;
    
      while conta2 <= qtd_maxima
      loop
        if (contlinha <= reg.quantidade) then
          TABELA_AUX2.EXTEND(1);
          TABELA_AUX2(TABELA_AUX2.LAST).CODIGO := conta;
          TABELA_AUX2(TABELA_AUX2.LAST).DESCRICAO := reg.descr;
          TABELA_AUX2(TABELA_AUX2.LAST).CODIGO2 := contlinha;
          contlinha := contlinha + 1;
          v_entrou := true;
        end if;
        conta2 := conta2 + divisor;
      end loop;
      contador := contador + 1;
    
    end loop;
  
    if v_entrou then
    
      delete separacaomistura
       where idseparacaomistura = v_sequencia;
    
      for j in TABELA_AUX2.first .. TABELA_AUX2.last
      loop
        insert into separacaomistura
          (rodada, loteIndustria, ordem, idromaneio, idseparacaomistura)
        values
          (tabela_aux2(j).codigo, tabela_aux2(j).descricao,
           tabela_aux2(j).codigo2, p_idromaneio, v_sequencia);
      end loop;
    end if;
  
    atualizarIdLoteRegiao(v_sequencia);
  
  end gerarSeparacaoMistura;

  procedure vincularLotesOsReclassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number,
    p_idOsMistura    in number
  ) is
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_qtdeDisponivel    number;
    v_qtdeUsar          number;
    v_qtde              number;
    v_total             number;
    v_msg               t_message;
    v_regimeDepositante regime.classificacao%type;
  
  begin
    if (p_qtde <= 0) then
      v_msg := t_message('A quantidade informada deve ser maior que zero. Lote id: {0}');
      v_msg.addParam(p_idlote);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select r.classificacao
      into v_regimeDepositante
      from lote lt, depositante d, regime r
     where lt.idlote = p_idLote
       and d.identidade = lt.iddepositante
       and r.idregime = d.idregime;
  
    select count(*)
      into v_total
      from classificacaomisturalote cml
     where cml.idordemservico = p_idOrdemServico
       and cml.idlote = p_idLote
       and cml.idendereco = p_idEndereco;
  
    if (v_total > 0) then
      pk_servico.desvinculaLtsOsReclassificacao(p_idOrdemServico, p_idLote,
                                                p_qtde, p_idEndereco);
    end if;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      select nvl(sum(clnf.qtdedisponivel - clnf.qtdereservado), 0)
        into v_qtdeDisponivel
        from coberturalotedispnf clnf
       where clnf.idlote = p_idLote;
    
      if (v_qtde > v_qtdeDisponivel) then
      
        v_msg := t_message('Quantidade de Cobertura insuficiente para atender a OS de Mistura.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idOsMistura: {1}' || chr(13) || ' idLote: {2}' ||
                           chr(13) || ' Quantidade solicitada: {3}' ||
                           chr(13) || ' Quantidade disponível: {4}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idOsMistura);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                 clnf.idnfentrada,
                                 sum(clnf.qtdedisponivel -
                                      clnf.qtdereservado) disponivel
                            from coberturalotedispnf clnf
                           where clnf.idlote = p_idLote
                           group by clnf.idlote, clnf.idnotafiscalcobertura,
                                    clnf.idnfentrada)
      
      loop
      
        if (v_qtde > c_lotes_cob.disponivel) then
          v_qtdeUsar := c_lotes_cob.disponivel;
        else
          v_qtdeUsar := v_qtde;
        end if;
      
        insert into classificacaomisturalote
          (idclassificacao, idordemservico, idlote, qtde, idendereco,
           idnotafiscalcobertura)
        values
          (seq_classificacaomisturalote.nextval, p_idOrdemServico,
           c_lotes_cob.idlote, v_qtdeUsar, p_idEndereco,
           c_lotes_cob.idnotafiscalcobertura);
      
        update coberturalotedispnf cnf
           set cnf.qtdereservado = cnf.qtdereservado + v_qtdeUsar
         where cnf.idlote = c_lotes_cob.idlote
           and cnf.idnfentrada = c_lotes_cob.idnfentrada
           and cnf.idnotafiscalcobertura =
               c_lotes_cob.idnotafiscalcobertura;
      
        v_qtde := v_qtde - v_qtdeUsar;
        exit when v_qtde = 0;
      end loop;
    
    else
      begin
        select sum(nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                    nvl(ll.adicionar, 0))
          into v_qtdeDisponivel
          from lote lt, lotelocal ll
         where lt.idlote = p_idLote
           and ll.idlote = lt.idlote;
      
      exception
        when no_data_found then
          v_qtdeDisponivel := 0;
      end;
    
      if (p_qtde > v_qtdeDisponivel) then
        v_msg := t_message('Quantidade insuficiente para atender a OS de Reclassificação.' ||
                           chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                           ' idOsMistura: {1}' || chr(13) || ' idLote: {2}' ||
                           chr(13) || ' Quantidade solicitada: {3}' ||
                           chr(13) || ' Quantidade disponível: {4}');
        v_msg.addParam(p_idOrdemServico);
        v_msg.addParam(p_idOsMistura);
        v_msg.addParam(p_idlote);
        v_msg.addParam(p_qtde);
        v_msg.addParam(v_qtdeDisponivel);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      insert into classificacaomisturalote
        (idclassificacao, idordemservico, idlote, qtde, idendereco)
      values
        (seq_classificacaomisturalote.nextval, p_idOrdemServico, p_idLote,
         p_qtde, p_idEndereco);
    
    end if;
  end vincularLotesOsReclassificacao;

  procedure desvinculaLtsOsReclassificacao
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  ) is
  
    C_REGIME_ARM_GERAL constant char(1) := 'A';
  
    v_qtde              number;
    v_qtdeRetirar       number;
    v_regimeDepositante regime.classificacao%type;
  
  begin
  
    select r.classificacao
      into v_regimeDepositante
      from lote lt, depositante d, regime r
     where lt.idlote = p_idLote
       and d.identidade = lt.iddepositante
       and r.idregime = d.idregime;
  
    if (v_regimeDepositante = C_REGIME_ARM_GERAL) then
    
      v_qtde := p_qtde;
    
      for c_lotes_vinc in (select cml.idordemservico, cml.idlote, cml.qtde,
                                  cml.idnotafiscalcobertura
                             from classificacaomisturalote cml
                            where cml.idordemservico = p_idOrdemServico
                              and cml.idlote = p_idLote
                              and cml.idendereco = p_idEndereco)
      loop
      
        for c_lotes_cob in (select clnf.idlote, clnf.idnotafiscalcobertura,
                                   clnf.idnfentrada,
                                   sum(clnf.qtdereservado) reservado
                              from coberturalotedispnf clnf
                             where clnf.idlote = c_lotes_vinc.idlote
                               and clnf.idnotafiscalcobertura =
                                   c_lotes_vinc.idnotafiscalcobertura
                             group by clnf.idlote, clnf.idnotafiscalcobertura,
                                      clnf.idnfentrada)
        
        loop
        
          if (v_qtde > c_lotes_cob.reservado) then
            v_qtdeRetirar := c_lotes_cob.reservado;
          else
            v_qtdeRetirar := v_qtde;
          end if;
        
          delete from classificacaomisturalote cml
           where cml.idordemservico = p_idOrdemServico
             and cml.idlote = c_lotes_cob.idlote
             and cml.idendereco = p_idEndereco
             and cml.idnotafiscalcobertura =
                 c_lotes_cob.idnotafiscalcobertura;
        
          update coberturalotedispnf cnf
             set cnf.qtdereservado = cnf.qtdereservado - v_qtdeRetirar
           where cnf.idlote = c_lotes_cob.idlote
             and cnf.idnfentrada = c_lotes_cob.idnfentrada
             and cnf.idnotafiscalcobertura =
                 c_lotes_cob.idnotafiscalcobertura;
        
          v_qtde := v_qtde - v_qtdeRetirar;
        
          exit when v_qtde = 0;
        end loop;
      end loop;
    
    else
    
      delete from classificacaomisturalote cml
       where cml.idordemservico = p_idOrdemServico
         and cml.idlote = p_idLote
         and cml.idendereco = p_idEndereco;
    
    end if;
  
  end desvinculaLtsOsReclassificacao;

  procedure addProdutosOs
  (
    p_ordemServico  in number,
    p_produto       in number,
    p_quantidade    in number,
    p_idDepositante in number
  ) is
    v_msg                         t_message;
    v_controlefiscalkitcomponente number := 0;
    v_tem                         number := 0;
    v_tipoOS                      ordemservico.tiposervico%type;
  
    function isPossuiKitEstojoReceita(p_idproduto in number) return boolean is
      v_controle number := 0;
    begin
      select count(*)
        into v_controle
        from dual
       where exists (select 1
                from kitproduto k
               where k.idprodutokit = p_idproduto
                 and (k.estojo = 1 or exists
                      (select 1
                         from kitproduto ka
                        where ka.idprodutokit = k.idproduto)));
    
      return v_controle > 0;
    
    end isPossuiKitEstojoReceita;
  
  begin
  
    select o.tiposervico
      into v_tipoOS
      from ordemservico o
     where o.idordemservico = p_ordemServico;
  
    if v_tipoOS = 'K'
       and isPossuiKitEstojoReceita(p_produto) then
      v_msg := t_message('Operação não permitida. Quando o produto [idProduto: {0}] possuir estojo ou Kit em sua receita deve ser montado por OS de Kit Rastreável');
      v_msg.addParam(p_produto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      select controlefiscalkitcomponente
        into v_controlefiscalkitcomponente
        from depositante
       where identidade = p_idDepositante;
    exception
      when no_data_found then
        v_controlefiscalkitcomponente := 0;
    end;
  
    if v_controlefiscalkitcomponente = C_REALIZA_CONTROLE_FISCAL_KIT then
      begin
        select distinct 1
          into v_tem
          from ordemproduto
         where idordemservico = p_ordemServico
           and idproduto <> p_produto;
      exception
        when no_data_found then
          v_tem := 0;
      end;
    
      if v_tem = 1 then
        v_msg := t_message('O depositante está com o parâmetro <b> Controle Fiscal de Kit apenas em componentes</b> ' ||
                           'ativado, permitindo um único produto na ordem de serviço!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end if;
  
    insert into ordemproduto
      (idordemservico, idproduto, qtde)
    values
      (p_ordemServico, p_produto, p_quantidade);
  
  end addProdutosOs;

  function temLtIndCompDiferente(p_idLoteKit in number) return number is
    v_existe number;
  begin
    select count(*)
      into v_existe
      from dual
     where exists (select cc.idproduto
              from (select ltck.idproduto, ltck.descr, ltck.dtvenc
                       from complotekit clk, lote ltk, lote ltck
                      where clk.idlotekit = p_idLoteKit
                        and ltk.idlote = clk.idlotekit
                        and ltck.idlote = clk.idlotecomponente
                      group by ltck.idproduto, ltck.descr, ltck.dtvenc) cc
             group by cc.idproduto
            having count(*) > 1);
  
    return v_existe;
  end;

  procedure formarOndaOrdemServico
  (
    p_idOnda         in out number,
    p_idConfigOnda   in number,
    p_idOrdemServico in number,
    p_tipoServico    in ordemservico.tiposervico%type,
    p_idNotaFiscal   in number,
    p_idUsuario      in number,
    p_osCombo        in number := 0
  ) is
    v_msg          t_message;
    v_erro         varchar2(3000);
    v_idArmazem    number;
    v_destinosaida transportadoradoca%rowtype;
    v_retorno      number;
  
    procedure getArmazemNF is
    begin
      select nf.idarmazem
        into v_idArmazem
        from notafiscal nf
       where nf.idnotafiscal = p_idNotaFiscal;
    end getArmazemNF;
  
    procedure setProdutoEstojo(p_idOs in number) is
    begin
    
      for x in (select rc.idproduto
                  from ordemservico os, receitaestojamento rc
                 where os.idordemservico = rc.idos
                   and os.tiposervico = 'E'
                   and rc.estojo = 1
                   and os.idordemservico = p_idOs
                
                union
                
                select k.idproduto
                  from ordemproduto op, kitproduto k, ordemservico os
                 where op.idordemservico = p_idOrdemServico
                   and op.idproduto = k.idprodutokit
                   and k.estojo = 1
                   and op.idordemservico = os.idordemservico
                   and os.tiposervico in ('K', 'I')
                
                )
      loop
      
        insert into gtt_propriedade
          (propriedade, valor1, valor2)
        values
          ('PRODUTO_ESTOJO', p_idOs, x.idproduto);
      
      end loop;
    
    end setProdutoEstojo;
  
  begin
    if p_idConfigOnda is null then
      v_msg := t_message('Configuração de Onda não informada!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    getArmazemNF;
  
    delete from gtt_propriedade;
  
    insert into gtt_propriedade
      (propriedade, valor1, valor2)
    values
      (p_tipoServico, 1, null);
  
    insert into gtt_propriedade
      (propriedade, valor1, valor2)
    values
      ('NOTA_FISCAL', p_idNotaFiscal, null);
  
    begin
      select td.*
        into v_destinosaida
        from notafiscal nf, transportadoradoca td, local l
       where nf.idnotafiscal = p_idNotaFiscal
         and td.identidade = nf.transportadoranotafiscal
         and l.id = td.idendereco
         and l.idarmazem = nf.idarmazem
         and l.idarmazem = v_idArmazem
         and rownum = 1
         and not exists
       (select 1
                from gtt_propriedade d
               where d.propriedade = 'DESTINO_SAIDA'
                 and to_number(d.valor1) = td.identidade);
    
      insert into gtt_propriedade
        (propriedade, valor1, valor2)
      values
        ('DESTINO_SAIDA', v_destinosaida.identidade,
         v_destinosaida.idendereco);
    exception
      when no_data_found then
        null;
    end;
  
    if (p_tipoServico in ('E', 'I')) then
    
      setProdutoEstojo(p_idOrdemServico);
    
      if (p_tipoServico = 'I') then
        insert into gtt_propriedade
          (propriedade, valor1, valor2)
        values
          ('NUMERO_OS', p_idOrdemServico, null);
      end if;
    
    end if;
  
    v_retorno := pk_onda.formarOnda(p_idOnda, v_idArmazem, p_idConfigOnda,
                                    'SAIDA PARA ' || case
                                       when p_tipoServico = C_ESTOJAMENTO then
                                        'ESTOJAMENTO'
                                       when p_tipoServico = C_DESESTOJAMENTO then
                                        'DESESTOJAMENTO'
                                       when p_tipoServico = c_kit then
                                        'MONTAGEM DE KIT'
                                       when p_tipoServico = C_KIT_COM_RASTREABILIDADE then
                                        'MONTAGEM DE KIT COM RASTREABILIDADE'
                                       when p_tipoServico = C_DESMONTAGEMKIT then
                                        'DESMONTAGEM DE KIT'
                                       else
                                        'ORDEM DE SERVIÇO'
                                     end || ' N:' || p_idOrdemServico,
                                    p_idUsuario, 0);
  
    if v_retorno <> 1 then
      for c_erro in (select e.tipoproblema, e.detalhe
                       from errogeracaoonda e
                      where e.idonda = p_idOnda)
      loop
        v_erro := v_erro || CHR(13) || c_erro.tipoproblema || ': ' ||
                  c_erro.detalhe;
      end loop;
    
      v_msg := t_message('Erro ao formar onda.{0}');
      v_msg.addParam(v_erro);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end formarOndaOrdemServico;

  procedure executarEstojamento
  (
    p_idordemservico   in ordemservico.idordemservico%type,
    p_usuario          in usuario.idusuario%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  ) is
    v_msg t_message;
    v_Seq number;
  
    cursor c_os(p_os in ordemservico.idordemservico%type) is
      select os.idordemservico, os.tiposervico, os.idarmazem, os.situacao,
             nvl(os.separacaoespec, 'N') separacaoespec, os.iddoca,
             os.identidade, d.agruparinclusaolotes,
             d.controlefiscalkitcomponente, os.idconfiguracaoonda,
             os.idproduto, os.qtde, p.descr produto, r.classificacao,
             os.combo, d.permitiralterarqtdeseparacao
        from ordemservico os, depositante d, produto p, regime r
       where idordemservico = p_os
         and d.identidade = os.identidade
         and p.idproduto = os.idproduto
         and r.idregime = d.idregime;
  
    cursor c_romaneio(p_romaneio in romaneiopai.idromaneio%type) is
      select r.*
        from romaneiopai r
       where r.idromaneio = p_romaneio;
  
    r_os        c_os%rowtype;
    r_nf        notafiscal%rowtype;
    r_nfdet     nfdet%rowtype;
    r_romaneio  c_romaneio%rowtype;
    r_lotenf    lotenf%rowtype;
    v_idunidade number;
  
    procedure carregarDadosIniciais is
    
      cursor c_comps(p_os in ordemservico.idordemservico%type) is
        select re.idproduto, re.qtdeunit
          from ordemservico os, receitaestojamento re
         where re.idos = p_os
           and re.idos = os.idordemservico;
    
      v_utilizakitsestojamentoonda number;
      r_comps                      c_comps%rowtype;
    
      C_LOTEINDUST_POR_NFCOBERTURA constant number := 2;
    begin
      if c_os%isopen then
        close c_os;
      end if;
      open c_os(p_idordemservico);
      fetch c_os
        into r_os;
    
      if r_os.agruparinclusaolotes = C_LOTEINDUST_POR_NFCOBERTURA then
        v_msg := t_message('O depositante esta com o parâmetro <b>Inclusão de estoque na Separação Específica</b> ' ||
                           'configurado como <b>Por Lote Indústria Listando NF Cobertura</b>. Não é possível gerar Ordem de Serviço. ' ||
                           'Operação cancelada!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.idconfiguracaoonda is null then
        v_msg := t_message('Configuração de Onda não informada!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica se encontrou a OS
      if c_os%notfound then
        v_msg := t_message('OS: {0}, NÃO ENCONTRADA');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select a.identidade, a.utilizakitsestojamentoonda
        into v_idunidade, v_utilizakitsestojamentoonda
        from armazem a
       where a.idarmazem = r_os.idarmazem;
    
      -- Verifica se a OS é de Estojamento
      if r_os.tiposervico <> C_ESTOJAMENTO then
        v_msg := t_message('OS: {0}, não é do tipo Estojamento');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica se armazem foi especificado
      if r_os.idarmazem is null then
        v_msg := t_message('OS: {0}, NÃO POSSUI ARMAZÉM SELECIONADO');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica a situagco da OS
      if r_os.situacao <> 'A' then
        v_msg := t_message('OS: {0}, JA ESTÁ EM ANDAMENTO.');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if c_comps%isopen then
        close c_comps;
      end if;
      open c_comps(p_idordemservico);
      fetch c_comps
        into r_comps;
      -- Verifica se existem kits na OS
      if c_comps%notfound then
        v_msg := t_message('OS: {0}, não possui receita de estojamento cadastrado.');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.classificacao <> 'F' then
        v_msg := t_message('Não é permitido estojamento para depositante com controle de cobertura fiscal.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if ((nvl(r_os.permitiralterarqtdeseparacao, 0) = 1) and
         (r_os.idconfiguracaoonda is not null)) then
        v_msg := t_message('Não é permitido cadastrar Ordem de Serviço utilizando Onda quando Depositante estiver marcado com opção: ' ||
                           'Permitir Alterar Qtde na Separação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end carregarDadosIniciais;
  
    procedure gravarOrdemKit is
    begin
      insert into ordemkit
        (idordemservico, idprodutokit, idproduto, barra, qtde)
        select p_idordemservico, os.idproduto, os.idproduto,
               pk_produto.ret_codbarra(os.idproduto, 1), 1
          from ordemservico os
         where os.idordemservico = p_idordemservico
           and os.combo = 0
        union
        select p_idordemservico, os.idproduto, re.idproduto,
               pk_produto.ret_codbarra(re.idproduto, 1), re.qtdeunit
          from ordemservico os, receitaestojamento re
         where re.idos = p_idordemservico
           and re.idos = os.idordemservico;
    end gravarOrdemKit;
  
    procedure gerarNfSaida is
    begin
      -- Insere NF saida
      r_nf.codigointerno     := '-1';
      r_nf.sequencia         := 'AJUSTE-KIT';
      r_nf.usuario           := p_usuario;
      r_nf.remetente         := v_idunidade;
      r_nf.destinatario      := v_idunidade;
      r_nf.dataemissao       := sysdate;
      r_nf.statusnf          := 'N';
      r_nf.digitada          := C_NAO;
      r_nf.impresso          := C_SIM;
      r_nf.ident_entrega     := v_idunidade;
      r_nf.tipo              := C_SAIDA;
      r_nf.iddepositante     := r_os.identidade;
      r_nf.movestoque        := C_SIM;
      r_nf.estoqueverificado := C_NAO;
      r_nf.docinterno        := 1;
      r_nf.idarmazem         := r_os.idarmazem;
    
      r_nf.statusroteirizacao       := 0;
      r_nf.transportadoranotafiscal := r_os.identidade;
    
      select o.idoperacao
        into r_nf.idoperacao
        from operacao o
       where o.tipo = 'S'
         and o.tipooper is null
         and rownum = 1;
    
      r_nf.idnotafiscal := pk_notafiscal.insere_cabecalho_nf(r_nf);
    
      update notafiscal
         set codigointerno = r_nf.idnotafiscal
       where idnotafiscal = r_nf.idnotafiscal;
    
      -- Insere Itens da NF de saida
      for c_itens in (select os.idproduto, os.qtde qtdeunit
                        from ordemservico os
                       where os.idordemservico = p_idordemservico
                         and os.combo = 0 -- os de combo não tem saída do produto combo
                      union
                      select re.idproduto, re.qtdeunit * os.qtde qtdeunit
                        from ordemservico os, receitaestojamento re
                       where re.idos = p_idordemservico
                         and re.idos = os.idordemservico)
      loop
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := r_nf.idnotafiscal;
        r_nfdet.barra            := pk_produto.ret_codbarra(c_itens.idproduto,
                                                            1);
        r_nfdet.idproduto        := c_itens.idproduto;
        r_nfdet.precounitliquido := 0;
        r_nfdet.qtde             := c_itens.qtdeunit;
        r_nfdet.qtdeatendida     := c_itens.qtdeunit;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      end loop;
    
      pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
    end gerarNfSaida;
  
    procedure validarOnda is
      v_prod_erro varchar2(4000);
    begin
      -- atualiza a ordem de servico com a onda
      update ordemservico
         set idromaneio = r_romaneio.idromaneio
       where idordemservico = p_idordemservico;
    
      -- Carrega romaneio
      if c_romaneio%isopen then
        close c_romaneio;
      end if;
      open c_romaneio(r_romaneio.idromaneio);
      fetch c_romaneio
        into r_romaneio;
      -- Verifica se tem corte de formacao do romaneio
      if r_romaneio.erro = C_ERRO then
        v_msg       := t_message('HOUVE CORTE NA FORMAÇÃO DO ROMANEIO' ||
                                 chr(13));
        v_prod_erro := v_msg.v_message;
      
        for c_corte in (select p.codigointerno,
                               substr(p.descr, 1, 20) produto,
                               --'Barra: ' || c.barra barra,
                               sum(c.qtdepedido) qtdepedido,
                               nvl(c.qtdedisponivelpk, 0) qtdedisponivelpk,
                               nvl(c.qtdedisponivelpl, 0) qtdedisponivelpl
                          from corteromaneio c, produto p
                         where p.idproduto = c.idproduto
                           and c.idromaneio = r_romaneio.idromaneio
                         group by p.codigointerno, substr(p.descr, 1, 20),
                                  c.qtdedisponivelpk, c.qtdedisponivelpl
                        having sum(c.qtdepedido) > decode(r_os.separacaoespec, 'N', nvl(c.qtdedisponivelpk, 0), nvl(c.qtdedisponivelpl, 0)))
        loop
          v_msg := t_message('{0}' || chr(13) || 'Produto: {1} - {2}' ||
                             chr(13) ||
                             --c_corte.barra || chr(13) ||
                             'Pedido: {3}' || chr(13) || 'Disp.PK: {4}' ||
                             chr(13) || 'Disp.PL: {5}' || chr(13));
          v_msg.addParam(v_prod_erro);
          v_msg.addParam(c_corte.codigointerno);
          v_msg.addParam(c_corte.produto);
          v_msg.addParam(c_corte.qtdepedido);
          v_msg.addParam(c_corte.qtdedisponivelpk);
          v_msg.addParam(c_corte.qtdedisponivelpl);
          v_prod_erro := substr(v_msg.formatMessage, 1, 4000);
        
        end loop;
        raise_application_error(-20000, v_prod_erro);
      end if;
    
      -- Verifica se a formacao foi concluida com sucesso
      if r_romaneio.gerado <> 'S' then
        v_msg := t_message('HOUVE ERRO NA FORMAÇÃO DO ROMANEIO');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Atualiza status
      update romaneiopai
         set faturado = C_FATURADO
       where idromaneio = r_romaneio.idromaneio;
    end validarOnda;
  
    procedure gerarNfEntrada is
    begin
      r_nf.tipo               := C_ENTRADA;
      r_nf.estoqueverificado  := null;
      r_nf.statusroteirizacao := 2;
      r_nf.idnotafiscal       := pk_notafiscal.insere_cabecalho_nf(r_nf);
      update notafiscal
         set codigointerno = r_nf.idnotafiscal
       where idnotafiscal = r_nf.idnotafiscal;
    
      -- Insere Itens da NF de entrada
      r_nfdet.idnfdet          := null;
      r_nfdet.nf               := r_nf.idnotafiscal;
      r_nfdet.barra            := pk_produto.retornar_codbarra(r_os.idproduto,
                                                               1);
      r_nfdet.idproduto        := r_os.idproduto;
      r_nfdet.precounitliquido := getValorUnitarioKit(p_idordemservico);
      r_nfdet.qtde             := r_os.qtde;
      r_nfdet.qtdeatendida     := r_os.qtde;
      if r_nfdet.barra is null then
        v_msg := t_message('Material "{0}" não possui código de barras de fator 1 cadastrado ou ativo.' ||
                           chr(13) || 'Operação Cancelada');
        v_msg.addParam(r_os.produto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
      pk_notafiscal.insere_detalhe_nf(r_nfdet);
    
      pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
    end gerarNfEntrada;
  
    procedure gerarOR is
      cursor c_tiporec is
        select min(t.idtiporecebimento) idtiporecebimento
          from tiporecebimento t
         where t.classificacao = C_MOVINTERNO;
    
      cursor c_doca(p_armazem in armazem.idarmazem%type) is
        select min(d.iddoca) iddoca
          from doca d
         where d.idarmazem = p_armazem;
    
      v_obrigaremetenteor char(1);
      r_doca              c_doca%rowtype;
      r_tiporec           c_tiporec%rowtype;
    begin
      if c_tiporec%isopen then
        close c_tiporec;
      end if;
      open c_tiporec;
      fetch c_tiporec
        into r_tiporec;
      if c_tiporec%found then
        if c_doca%isopen then
          close c_doca;
        end if;
        open c_doca(r_os.idarmazem);
        fetch c_doca
          into r_doca;
        if c_doca%found then
          -- Insere a OR
          if r_tiporec.idtiporecebimento is null then
            v_msg := t_message('TIPO DE RECEBIMENTO DE OPERAÇÕES INTERNAS NÃO CADASTRADO. OPERAÇÃO CANCELADA.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          select d.obrigaremetenteor
            into v_obrigaremetenteor
            from depositante d
           where d.identidade = r_os.identidade;
        
          r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
          r_lotenf.descr             := 'FORMAÇÃO DE ESTOJAMENTO N: ' ||
                                        r_os.idordemservico;
          r_lotenf.data              := sysdate;
          r_lotenf.idusuario         := p_usuario;
          r_lotenf.idarmazem         := r_os.idarmazem;
          r_lotenf.iddoca            := r_doca.iddoca;
          r_lotenf.identidade        := r_os.identidade;
          r_lotenf.modal             := 0;
        
          if v_obrigaremetenteor = 'S' then
            r_lotenf.idremetente := v_idunidade;
          end if;
        
          r_lotenf.idlotenf := pk_recebimento.cadastrar_OR(r_lotenf);
          -- Inserir NF a OR
          update notafiscal
             set idlotenf = r_lotenf.idlotenf
           where idnotafiscal = r_nf.idnotafiscal;
        
          pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
        
        else
          v_msg := t_message('NENHUMA DOCA ENCONTRADA PARA O ARMAZEM SELECIONADO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      else
        v_msg := t_message('TIPO DE RECEBIMENTO NÃO CADASTRADO PARA FORMAÇÃO DE KIT');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end gerarOR;
  
  begin
  
    --validações
    carregarDadosIniciais;
  
    pk_locks.executeLock(r_os.idarmazem, 6);
    v_seq := pk_servico.getSeqLoteIndOS(r_os.idarmazem, r_os.identidade,
                                        p_idordemservico, p_usuario);
  
    -- Grava o cadastro de como o kit eh composto
    gravarOrdemKit;
  
    --gerar nf de saída
    gerarNfSaida;
  
    --gerar separação específica dos lote gerados por inventário de estojo
    gerarSeparacaoEspecifica(r_nf.idnotafiscal, r_os.idordemservico,
                             r_os.idarmazem, p_usuario);
  
    update notafiscal nf
       set nf.statusroteirizacao = 1,
           nf.estoqueverificado  = C_SIM
     where nf.idnotafiscal = r_nf.idnotafiscal;
  
    --gerar onda
    formarOndaOrdemServico(r_romaneio.idromaneio, r_os.idconfiguracaoonda,
                           r_os.idOrdemServico, C_ESTOJAMENTO,
                           r_nf.idnotafiscal, p_usuario, r_os.combo);
  
    validarOnda;
  
    --valida se utilizou mais de um lote indústria para o mesmo produto 
    --(limitação para ter segurança do que está sendo expedido dentro do produto estojador)
    --se formou apenas uma unidade pode misturar lote industria do mesmo produto
    if r_os.qtde > 1 then
      validarMisturaLoteIndOnda(r_os.idOrdemServico, r_romaneio.idromaneio,
                                r_os.tiposervico, p_tipokitsmontados,
                                p_kitsmontados);
    
      if p_tipokitsmontados <> 2 then
        return;
      end if;
    else
      p_tipokitsmontados := 2;
    end if;
  
    --gerar nf de entrada
    gerarNfEntrada;
  
    --gerar OR
    gerarOR;
  
    -- valida sequencia
  
    --atualizar status OS  
    update ordemservico
       set idromaneio        = r_romaneio.idromaneio,
           idlotenf          = r_lotenf.idlotenf,
           dataprocessamento = sysdate,
           situacao          = C_PROCESSADO,
           seqloteind        = v_seq
     where idordemservico = r_os.idordemservico;
  end executarEstojamento;

  procedure executarDesestojamento
  (
    p_idordemservico in ordemservico.idordemservico%type,
    p_usuario        in usuario.idusuario%type
  ) is
    v_msg t_message;
  
    cursor c_os(p_os in ordemservico.idordemservico%type) is
      select os.idordemservico, os.tiposervico, os.idarmazem, os.situacao,
             nvl(os.separacaoespec, 'N') separacaoespec, os.iddoca,
             os.identidade, d.agruparinclusaolotes,
             d.controlefiscalkitcomponente, os.idconfiguracaoonda,
             os.idproduto, os.qtde
        from ordemservico os, depositante d
       where idordemservico = p_os
         and d.identidade = os.identidade;
  
    cursor c_romaneio(p_romaneio in romaneiopai.idromaneio%type) is
      select r.*
        from romaneiopai r
       where r.idromaneio = p_romaneio;
  
    r_os        c_os%rowtype;
    r_nf        notafiscal%rowtype;
    r_nfdet     nfdet%rowtype;
    r_romaneio  c_romaneio%rowtype;
    r_lotenf    lotenf%rowtype;
    v_idunidade number;
  
    procedure carregarDadosIniciais is
      cursor c_comps(p_os in ordemservico.idordemservico%type) is
        select el.idlote
          from classificacaomisturalote el
         where el.idordemservico = p_os;
    
      v_utilizakitsestojamentoonda number;
      r_comps                      c_comps%rowtype;
    
      C_LOTEINDUST_POR_NFCOBERTURA constant number := 2;
    
      function existeLoteSemEstojamento return boolean is
        v_total number;
      begin
        select count(*)
          into v_total
          from classificacaomisturalote c
         where c.idordemservico = p_idOrdemServico
           and not exists (select 1
                  from receitaestojamentolote re
                 where re.idlote = c.idlote)
           and not exists
         (select 1
                  from receitaestojamentolote re
                 where re.idlote = pk_lote.getIdLoteAnterior(c.idlote));
      
        return v_total > 0;
      end existeLoteSemEstojamento;
    begin
      if c_os%isopen then
        close c_os;
      end if;
      open c_os(p_idordemservico);
      fetch c_os
        into r_os;
    
      if r_os.agruparinclusaolotes = C_LOTEINDUST_POR_NFCOBERTURA then
        v_msg := t_message('O depositante esta com o parâmetro <b>Inclusão de estoque na Separção Específica</b> ' ||
                           'configurado como <b>Por Lote Industria Listando NF Cobertura</b>. Não é possível gerar Ordem de Servico. ' ||
                           'Operação cancelada!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_os.idconfiguracaoonda is null then
        v_msg := t_message('Configuração de Onda não informada!');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica se encontrou a OS
      if c_os%notfound then
        v_msg := t_message('OS: {0}, NÃO ENCONTRADA');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select a.identidade, a.utilizakitsestojamentoonda
        into v_idunidade, v_utilizakitsestojamentoonda
        from armazem a
       where a.idarmazem = r_os.idarmazem;
    
      -- Verifica se a OS é de Desestojamento
      if r_os.tiposervico <> C_DESESTOJAMENTO then
        v_msg := t_message('OS: {0}, não é do tipo Desestojamento');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica se armazem foi especificado
      if r_os.idarmazem is null then
        v_msg := t_message('OS: {0}, NÃO POSSUI ARMAZEM SELECIONADO');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Verifica a situagco da OS
      if r_os.situacao <> 'A' then
        v_msg := t_message('OS: {0}, JA ESTÁ EM ANDAMENTO.');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if c_comps%isopen then
        close c_comps;
      end if;
      open c_comps(p_idordemservico);
      fetch c_comps
        into r_comps;
      -- Verifica se existem kits na OS
      if c_comps%notfound then
        v_msg := t_message('OS: {0}, não possui lotes para desestojamento vinculados.');
        v_msg.addParam(p_idordemservico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if existeLoteSemEstojamento then
        v_msg := t_message('Existem lotes vinculados a Ordem de Serviço que não possuem produtos estojados.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end carregarDadosIniciais;
  
    procedure gerarNfSaida is
    begin
      -- Insere NF saida
      r_nf.codigointerno     := '-1';
      r_nf.sequencia         := 'AJUSTE-KIT';
      r_nf.usuario           := p_usuario;
      r_nf.remetente         := v_idunidade;
      r_nf.destinatario      := v_idunidade;
      r_nf.dataemissao       := sysdate;
      r_nf.statusnf          := 'N';
      r_nf.digitada          := C_NAO;
      r_nf.impresso          := C_SIM;
      r_nf.ident_entrega     := v_idunidade;
      r_nf.tipo              := C_SAIDA;
      r_nf.iddepositante     := r_os.identidade;
      r_nf.movestoque        := C_SIM;
      r_nf.estoqueverificado := C_SIM;
      r_nf.docinterno        := 1;
      r_nf.idarmazem         := r_os.idarmazem;
    
      r_nf.statusroteirizacao       := 1;
      r_nf.transportadoranotafiscal := r_os.identidade;
      select o.idoperacao
        into r_nf.idoperacao
        from operacao o
       where o.tipo = 'S'
         and o.tipooper is null
         and rownum = 1;
    
      r_nf.idnotafiscal := pk_notafiscal.insere_cabecalho_nf(r_nf);
    
      update notafiscal
         set codigointerno = r_nf.idnotafiscal
       where idnotafiscal = r_nf.idnotafiscal;
    
      -- Insere Itens da NF de saida
      for c_itens in (select lt.idproduto, sum(el.qtde) qtdeunit
                        from classificacaomisturalote el, lote lt
                       where el.idordemservico = p_idordemservico
                         and lt.idlote = el.idlote
                       group by lt.idproduto)
      loop
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := r_nf.idnotafiscal;
        r_nfdet.barra            := pk_produto.ret_codbarra(c_itens.idproduto,
                                                            1);
        r_nfdet.idproduto        := c_itens.idproduto;
        r_nfdet.precounitliquido := 0;
        r_nfdet.qtde             := c_itens.qtdeunit;
        r_nfdet.qtdeatendida     := c_itens.qtdeunit;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      end loop;
    
      -- insere os lotes vinculados da ordem de servico na separacao especifica
      for c_sepEspecifica in (select lo.idarmazem, lo.idlocal, el.idlote,
                                     sum(el.qtde) qtdeunit
                                from classificacaomisturalote el, lote lt,
                                     local lo
                               where el.idordemservico = p_idordemservico
                                 and lt.idlote = el.idlote
                                 and lo.id = el.idendereco
                               group by lo.idarmazem, lo.idlocal, el.idlote)
      loop
        insert into separacaoespecifica
          (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual, id,
           fonteseparacao, idusuario, dtvinculo)
        values
          (c_sepEspecifica.idarmazem, c_sepEspecifica.idlocal,
           c_sepEspecifica.idlote, r_nf.idnotafiscal,
           c_sepEspecifica.qtdeunit, 'N', seq_separacaoespecifica.nextval, 0,
           p_usuario, sysdate);
      end loop;
    
      pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
    end gerarNfSaida;
  
    procedure validarOnda is
      v_prod_erro varchar2(4000);
    begin
      -- atualiza a ordem de servico com a onda
      update ordemservico
         set idromaneio = r_romaneio.idromaneio
       where idordemservico = p_idordemservico;
    
      -- Carrega romaneio
      if c_romaneio%isopen then
        close c_romaneio;
      end if;
      open c_romaneio(r_romaneio.idromaneio);
      fetch c_romaneio
        into r_romaneio;
      -- Verifica se tem corte de formacao do romaneio
      if r_romaneio.erro = C_ERRO then
        v_msg       := t_message('HOUVE CORTE NA FORMAÇÃO DO ROMANEIO' ||
                                 chr(13));
        v_prod_erro := v_msg.v_message;
      
        for c_corte in (select p.codigointerno,
                               substr(p.descr, 1, 20) produto,
                               --'Barra: ' || c.barra barra,
                               sum(c.qtdepedido) qtdepedido,
                               nvl(c.qtdedisponivelpk, 0) qtdedisponivelpk,
                               nvl(c.qtdedisponivelpl, 0) qtdedisponivelpl
                          from corteromaneio c, produto p
                         where p.idproduto = c.idproduto
                           and c.idromaneio = r_romaneio.idromaneio
                         group by p.codigointerno, substr(p.descr, 1, 20),
                                  c.qtdedisponivelpk, c.qtdedisponivelpl
                        having sum(c.qtdepedido) > decode(r_os.separacaoespec, 'N', nvl(c.qtdedisponivelpk, 0), nvl(c.qtdedisponivelpl, 0)))
        loop
          v_msg := t_message('{0}' || chr(13) || 'Produto: {1} - {2}' ||
                             chr(13) ||
                             --c_corte.barra || chr(13) ||
                             'Pedido: {3}' || chr(13) || 'Disp.PK: {4}' ||
                             chr(13) || 'Disp.PL: {5}' || chr(13));
          v_msg.addParam(v_prod_erro);
          v_msg.addParam(c_corte.codigointerno);
          v_msg.addParam(c_corte.produto);
          v_msg.addParam(c_corte.qtdepedido);
          v_msg.addParam(c_corte.qtdedisponivelpk);
          v_msg.addParam(c_corte.qtdedisponivelpl);
          v_prod_erro := substr(v_msg.formatMessage, 1, 4000);
        
        end loop;
        raise_application_error(-20000, v_prod_erro);
      end if;
    
      -- Verifica se a formacao foi concluida com sucesso
      if r_romaneio.gerado <> 'S' then
        v_msg := t_message('HOUVE ERRO NA FORMAÇÃO DO ROMANEIO');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- Atualiza status
      update romaneiopai
         set faturado = C_FATURADO
       where idromaneio = r_romaneio.idromaneio;
    end validarOnda;
  
    procedure gerarNfEntrada is
      v_tipoServico ordemservico.tiposervico%type;
    begin
      r_nf.tipo               := C_ENTRADA;
      r_nf.estoqueverificado  := null;
      r_nf.statusroteirizacao := 2;
      r_nf.idnotafiscal       := pk_notafiscal.insere_cabecalho_nf(r_nf);
      update notafiscal
         set codigointerno = r_nf.idnotafiscal
       where idnotafiscal = r_nf.idnotafiscal;
    
      for c_itens in (select r.idlote, r.idproduto, p.descr produto,
                             sum(r.qtdeunit) qtdeunit, p.combo,
                             r.idlotecomponente
                        from (select cl.idlote, lt.idproduto, cl.qtde qtdeunit,
                                      (select c.idlotecomponente
                                          from complotekit c, lote lta
                                         where c.idlotekit = cl.idlote
                                           and c.idlotecomponente = lta.idlote
                                           and lta.idproduto = lt.idproduto
                                           and exists
                                         (select 1
                                                  from complotekit cp
                                                 where cp.idlotekit =
                                                       c.idlotecomponente)) idlotecomponente
                                 from classificacaomisturalote cl, lote lt
                                where 1 = 1
                                  and cl.idordemservico = p_idordemservico
                                  and lt.idlote = cl.idlote
                               union all
                               select cl.idlote, re.idprodutocomp idproduto,
                                      (cl.qtde * re.qtdeunit) qtdeunit,
                                      (select c.idlotecomponente
                                          from complotekit c, lote ltc
                                         where c.idlotekit = re.idlote
                                           and ltc.idlote = c.idlotecomponente
                                           and ltc.idproduto = re.idprodutocomp
                                           and rownum = 1) idlotecomponente
                                 from classificacaomisturalote cl,
                                      receitaestojamentolote re
                                where 1 = 1
                                  and cl.idordemservico = p_idordemservico
                                  and re.idlote = cl.idlote
                                  and re.idos =
                                      (select max(r.idos)
                                         from receitaestojamentolote r
                                        where r.idlote = cl.idlote)
                               
                               union all
                               select cl.idlote, re.idprodutocomp idproduto,
                                      (cl.qtde * re.qtdeunit) qtdeunit,
                                      (select c.idlotecomponente
                                          from complotekit c, lote ltc
                                         where c.idlotekit = re.idlote
                                           and ltc.idlote = c.idlotecomponente
                                           and ltc.idproduto = re.idprodutocomp
                                           and rownum = 1) idlotecomponente
                                 from classificacaomisturalote cl,
                                      receitaestojamentolote re
                                where 1 = 1
                                  and cl.idordemservico = p_idordemservico
                                  and re.idlote =
                                      pk_lote.getIdLoteAnterior(cl.idlote)
                                  and not exists
                                (select 1
                                         from receitaestojamentolote r
                                        where r.idlote = cl.idlote)
                                     
                                  and re.idos =
                                      (select max(r.idos)
                                         from receitaestojamentolote r
                                        where r.idlote =
                                              pk_lote.getIdLoteAnterior(cl.idlote))
                               
                               ) r, produto p
                       where p.idproduto = r.idproduto
                         and p.combo = 0
                       group by r.idlote, r.idproduto, p.descr, p.combo,
                                r.idlotecomponente)
      loop
        -- Insere Itens da NF de entrada
        r_nfdet.idnfdet          := null;
        r_nfdet.nf               := r_nf.idnotafiscal;
        r_nfdet.barra            := pk_produto.retornar_codbarra(c_itens.idproduto,
                                                                 1);
        r_nfdet.idproduto        := c_itens.idproduto;
        r_nfdet.precounitliquido := getValorUnitarioKit(p_idordemservico);
        r_nfdet.qtde             := c_itens.qtdeunit;
        r_nfdet.qtdeatendida     := c_itens.qtdeunit;
      
        if r_nfdet.barra is null then
          v_msg := t_message('Material "{0}" nao possui codigo de barras de fator 1 cadastrado ou ativo.' ||
                             chr(13) || 'Operação Cancelada');
          v_msg.addParam(c_itens.produto);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      
        if (c_itens.idlotecomponente is not null) then
        
          begin
            select os.tiposervico
              into v_tipoServico
              from origemlote ol, notafiscal nf, ordemservico os
             where 1 = 1
               and ol.idlote = c_itens.idlotecomponente
               and nf.idnotafiscal = ol.idnotafiscal
               and os.idlotenf = nf.idlotenf
               and os.idosmae is not null
             group by os.tiposervico;
          exception
            when no_data_found then
              begin
                select os.tiposervico
                  into v_tipoServico
                  from origemlote ol, notafiscal nf, ordemservico os
                 where 1 = 1
                   and ol.idlote = c_itens.idlotecomponente
                   and nf.idnotafiscal = ol.idnotafiscal
                   and os.idlotenf = nf.idlotenf
                   and os.idosmae is null
                 group by os.tiposervico;
              exception
                when no_data_found then
                  v_tipoServico := null;
              end;
          end;
        
          if (v_tipoServico in ('E', 'J')) then
            -- receita dos produtos filhos OS
            insert into nfdetreceitaestojamento
              (idnfdet, tiposervico, idproduto, qtdeunit, idlotekitreplicar,
               idordemservico, produtoagrupador)
              select r_nfdet.idnfdet, v_tipoServico tiposervico,
                     r.idprodutocomp, r.qtdeunit, c_itens.idlotecomponente,
                     p_idordemservico, 0
                from receitaestojamentolote r
               where r.idlote = c_itens.idlotecomponente;
          
            -- receita do produto agrupador da OS
            if (sql%rowcount > 0) then
              insert into nfdetreceitaestojamento
                (idnfdet, tiposervico, idproduto, qtdeunit,
                 idlotekitreplicar, idordemservico, produtoagrupador)
                select r_nfdet.idnfdet, v_tipoServico, os.idproduto,
                       1 qtdeunit, c_itens.idlotecomponente,
                       p_idordemservico, 1
                  from receitaestojamentolote r, ordemservico os
                 where 1 = 1
                   and os.idordemservico = r.idos
                   and r.idlote = c_itens.idlotecomponente
                 group by os.idproduto;
            
            end if;
          elsif v_tipoServico in ('K', 'I') then
            insert into nfdetreceitaestojamento
              (idnfdet, tiposervico, idproduto, qtdeunit, idlotekitreplicar,
               idordemservico, produtoagrupador)
              select r_nfdet.idnfdet, v_tipoServico, kp.idproduto,
                     (kp.qtde * e.fatorconversao), c_itens.idlotecomponente,
                     p_idordemservico, 0
                from lote lt, kitproduto kp, embalagem e
               where 1 = 1
                 and kp.idprodutokit = lt.idproduto
                 and e.idproduto = kp.idproduto
                 and e.barra = kp.barra
                 and lt.idlote = c_itens.idlotecomponente;
          
          end if;
        
        end if;
      
      end loop;
    
      pk_notafiscal.p_gerar_nfimpressao(r_nf.idnotafiscal, C_NAO);
    end gerarNfEntrada;
  
    procedure gerarOR is
      cursor c_tiporec is
        select min(t.idtiporecebimento) idtiporecebimento
          from tiporecebimento t
         where t.classificacao = C_MOVINTERNO;
    
      cursor c_doca(p_armazem in armazem.idarmazem%type) is
        select min(d.iddoca) iddoca
          from doca d
         where d.idarmazem = p_armazem;
    
      v_obrigaremetenteor char(1);
      r_doca              c_doca%rowtype;
      r_tiporec           c_tiporec%rowtype;
    begin
      if c_tiporec%isopen then
        close c_tiporec;
      end if;
      open c_tiporec;
      fetch c_tiporec
        into r_tiporec;
      if c_tiporec%found then
        if c_doca%isopen then
          close c_doca;
        end if;
        open c_doca(r_os.idarmazem);
        fetch c_doca
          into r_doca;
        if c_doca%found then
          -- Insere a OR
          if r_tiporec.idtiporecebimento is null then
            v_msg := t_message('TIPO DE RECEBIMENTO DE OPERAÇÕES INTERNAS NÃO CADASTRADO. OPERAÇÃO CANCELADA.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          select d.obrigaremetenteor
            into v_obrigaremetenteor
            from depositante d
           where d.identidade = r_os.identidade;
        
          r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
          r_lotenf.descr             := 'FORMAÇÃO DE DESESTOJAMENTO N: ' ||
                                        r_os.idordemservico;
          r_lotenf.data              := sysdate;
          r_lotenf.idusuario         := p_usuario;
          r_lotenf.idarmazem         := r_os.idarmazem;
          r_lotenf.iddoca            := r_doca.iddoca;
          r_lotenf.identidade        := r_os.identidade;
          r_lotenf.modal             := 0;
        
          if v_obrigaremetenteor = 'S' then
            r_lotenf.idremetente := v_idunidade;
          end if;
        
          r_lotenf.idlotenf := pk_recebimento.cadastrar_OR(r_lotenf);
          -- Inserir NF a OR
          update notafiscal
             set idlotenf = r_lotenf.idlotenf
           where idnotafiscal = r_nf.idnotafiscal;
        
          pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
        
        else
          v_msg := t_message('NENHUMA DOCA ENCONTRADA PARA O ARMAZEM SELECIONADO');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      else
        v_msg := t_message('TIPO DE RECEBIMENTO NÃO CADASTRADO PARA FORMAÇÃO DE KIT');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end gerarOR;
  begin
    --validações
    carregarDadosIniciais;
  
    --gerar nf de saída
    gerarNfSaida;
  
    --gerar onda
    formarOndaOrdemServico(r_romaneio.idromaneio, r_os.idconfiguracaoonda,
                           r_os.idOrdemServico, C_DESESTOJAMENTO,
                           r_nf.idnotafiscal, p_usuario);
  
    validarOnda;
  
    --gerar nf de entrada
    gerarNfEntrada;
  
    --gerar OR
    gerarOR;
  
    --atualizar status OS  
    update ordemservico
       set idromaneio        = r_romaneio.idromaneio,
           idlotenf          = r_lotenf.idlotenf,
           dataprocessamento = sysdate,
           situacao          = C_PROCESSADO
     where idordemservico = r_os.idordemservico;
  end executarDesestojamento;

  procedure vincularLotesOsDesestojamento
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  ) is
  
    v_qtdeDisponivel number;
    v_total          number;
    v_msg            t_message;
  
  begin
    if (p_qtde <= 0) then
      v_msg := t_message('A quantidade informada deve ser maior que zero. Lote id: {0}');
      v_msg.addParam(p_idlote);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_total
      from classificacaomisturalote cml
     where cml.idordemservico = p_idOrdemServico
       and cml.idlote = p_idLote
       and cml.idendereco = p_idEndereco;
  
    if (v_total > 0) then
      pk_servico.desvincularLtsOsMistura(p_idOrdemServico, p_idLote, p_qtde,
                                         p_idEndereco);
    end if;
  
    begin
      select sum(nvl(ll.estoque, 0) - nvl(ll.pendencia, 0) +
                  nvl(ll.adicionar, 0))
        into v_qtdeDisponivel
        from lote lt, lotelocal ll
       where lt.idlote = p_idLote
         and ll.idlote = lt.idlote;
    
    exception
      when no_data_found then
        v_qtdeDisponivel := 0;
    end;
  
    if (p_qtde > v_qtdeDisponivel) then
      v_msg := t_message('Quantidade insuficiente para atender a OS de Mistura.' ||
                         chr(13) || ' idOrdemServico: {0}' || chr(13) ||
                         ' idLote: {1}' || chr(13) ||
                         ' Quantidade solicitada: {2}' || chr(13) ||
                         ' Quantidade disponível: {3}');
      v_msg.addParam(p_idOrdemServico);
      v_msg.addParam(p_idlote);
      v_msg.addParam(p_qtde);
      v_msg.addParam(v_qtdeDisponivel);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    insert into classificacaomisturalote
      (idclassificacao, idordemservico, idlote, qtde, idendereco,
       idnotafiscalcobertura)
    values
      (seq_classificacaomisturalote.nextval, p_idOrdemServico, p_idLote,
       p_qtde, p_idEndereco, null);
  
  end vincularLotesOsDesestojamento;

  procedure desvincularLtsOsDesestojamento
  (
    p_idOrdemServico in number,
    p_idLote         in number,
    p_qtde           in number,
    p_idEndereco     in number
  ) is
  begin
    delete from classificacaomisturalote cml
     where cml.idordemservico = p_idOrdemServico
       and cml.idlote = p_idLote
       and cml.idendereco = p_idEndereco;
  end desvincularLtsOsDesestojamento;

  procedure validarMisturaLoteIndOnda
  (
    p_idordemservico   in number,
    p_idOnda           in number,
    p_tipoServico      in ordemservico.tiposervico%type,
    p_tipokitsmontados out number,
    p_kitsmontados     out number
  ) is
    v_totalSolicitadoKit   number;
    v_qtdeAtendidaTotalKit number;
    v_misturou             number;
    v_loteIndAnt           lote.descr%type;
    v_dtvenc               lote.dtvenc%type;
    v_primeiraLinha        number;
    v_qtdeCompPorKit       number;
  begin
    if p_tipoServico = C_ESTOJAMENTO then
      select os.qtde
        into v_totalSolicitadoKit
        from ordemservico os
       where os.idordemservico = p_idordemservico;
    elsif p_tipoServico = C_KIT_COM_RASTREABILIDADE then
      select os.qtde
        into v_totalSolicitadoKit
        from ordemservico os
       where os.idordemservico = p_idordemservico;
    elsif p_tipoServico = c_kit then
      select op.qtde
        into v_totalSolicitadoKit
        from ordemproduto op
       where op.idordemservico = p_idordemservico;
    else
      return;
    end if;
  
    v_qtdeAtendidaTotalKit := v_totalSolicitadoKit;
  
    for c_produtos in (select nd.idproduto
                         from nfromaneio nfr, nfdet nd, embalagem e
                        where nfr.idromaneio = p_idOnda
                          and nd.nf = nfr.idnotafiscal
                          and e.barra = nd.barra
                          and e.idproduto = nd.idproduto
                        group by nd.idproduto)
    loop
      v_misturou      := 0;
      v_primeiraLinha := 1;
      v_loteIndAnt    := null;
      v_dtvenc        := null;
    
      for c_movimentacao in (select m.idordemestoque, m.quantidade,
                                    m.loteindustria, m.dtvenc
                               from (select min(m.idordemestoque) idordemestoque,
                                             sum(m.quantidade) quantidade,
                                             lt.descr loteindustria, lt.dtvenc
                                        from movimentacao m, lote lt
                                       where lt.idlote = m.idlote
                                         and m.idonda = p_idOnda
                                         and lt.idproduto =
                                             c_produtos.idproduto
                                       group by lt.descr, lt.dtvenc) m
                              order by m.idordemestoque)
      loop
        if v_misturou = 0 then
          if v_primeiraLinha = 1 then
            v_primeiraLinha := 0;
            v_loteIndAnt    := c_movimentacao.loteindustria;
            v_dtvenc        := c_movimentacao.dtvenc;
          
            --verifica quantidade na receita para saber a quantidade atendida do estojamento ou kit
            if p_tipoServico = C_ESTOJAMENTO then
              select sum(c.qtdeunit)
                into v_qtdeCompPorKit
                from (select os.idproduto, 1 qtdeunit
                         from ordemservico os
                        where os.idordemservico = p_idordemservico
                       union all
                       select re.idproduto, re.qtdeunit
                         from receitaestojamento re
                        where re.idos = p_idordemservico
                          and not exists
                        (select 1
                                 from ordemservico os
                                where os.idordemservico = p_idordemservico
                                  and os.idproduto = re.idproduto)) c
               where c.idproduto = c_produtos.idproduto;
            elsif p_tipoServico in (c_kit, C_KIT_COM_RASTREABILIDADE) then
              select sum(c.qtdeunit)
                into v_qtdeCompPorKit
                from (select (kp.qtde * e.fatorconversao) qtdeunit
                         from ordemproduto op, kitproduto kp, embalagem e
                        where op.idordemservico = p_idordemservico
                          and kp.idprodutokit = op.idproduto
                          and e.idproduto = kp.idproduto
                          and e.barra = kp.barra
                          and kp.idproduto = c_produtos.idproduto) c;
            end if;
          
            /*se a quantidade do primeiro vencimento e lote indústria para o produto componente é menor 
            do que a quantidade atendida em componente até o momento, diminui a quantidade atendida*/
            if c_movimentacao.quantidade <
               (v_qtdeCompPorKit * v_qtdeAtendidaTotalKit) then
              v_qtdeAtendidaTotalKit := trunc(c_movimentacao.quantidade /
                                              v_qtdeCompPorKit);
            end if;
          else
            if nvl(v_loteIndAnt, ' ') <>
               nvl(c_movimentacao.loteindustria, ' ')
               or nvl(v_dtvenc, to_date('01/01/1900', 'dd/mm/rrrr')) <>
               nvl(c_movimentacao.dtvenc,
                      to_date('01/01/1900', 'dd/mm/rrrr')) then
              v_misturou := 1;
            end if;
          end if;
        end if;
      end loop;
    end loop;
  
    if v_qtdeAtendidaTotalKit = v_totalSolicitadoKit then
      p_tipokitsmontados := 2;
      p_kitsmontados     := v_qtdeAtendidaTotalKit;
    elsif v_qtdeAtendidaTotalKit = 0 then
      p_tipokitsmontados := 0;
      p_kitsmontados     := 0;
    else
      p_tipokitsmontados := 1;
      p_kitsmontados     := v_qtdeAtendidaTotalKit;
    end if;
  end validarMisturaLoteIndOnda;

  procedure gerarEstojamento
  (
    p_idordemservico in number,
    p_tipoos         in varchar2,
    p_usuario        in number,
    p_tipokitmontado out number,
    p_kitsmontados   out number,
    p_quantidade     in number,
    p_commit         in varchar2 := c_nao
  ) is
    v_idlotenf   ordemservico.idlotenf%type;
    v_idromaneio ordemservico.idromaneio%type;
    v_msg        t_message;
    v_situacao   ordemservico.situacao%type;
  
  begin
    if p_tipoos <> C_ESTOJAMENTO then
      v_msg := t_message('Tipo de serviço não pode ser diferente de Estojamento.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select os.situacao
      into v_situacao
      from ordemservico os
     where os.idordemservico = p_idordemservico
       for update;
  
    if (v_situacao <> 'A') then
      v_msg := t_message('OS: {0}, JA ESTÁ EM ANDAMENTO.');
      v_msg.addParam(p_idordemservico);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_quantidade > 0 then
      update ordemservico
         set qtde = p_quantidade
       where idordemservico = p_idordemservico;
    
      pk_utilities.GeraLog(p_usuario,
                           'Tela: Alterada Ordem de Serviço: idordemservico: ' ||
                            p_idordemservico || ', qtde: ' || p_quantidade,
                           p_idordemservico, 'CA');
      commit;
    end if;
  
    executarEstojamento(p_idordemservico, p_usuario, p_tipokitmontado,
                        p_kitsmontados);
  
    if p_tipokitmontado <> 2 then
      rollback;
    else
      select os.idlotenf, os.idromaneio
        into v_idlotenf, v_idromaneio
        from ordemservico os
       where os.idordemservico = p_idordemservico;
    
      pk_utilities.GeraLog(p_usuario,
                           'Tela: Gerada Ordem de Serviço: idordemservico: ' ||
                            p_idordemservico || ', idlotenf: ' || v_idlotenf ||
                            ', idromaneio: ' || v_idromaneio,
                           p_idordemservico, 'CA');
    
    end if;
  end gerarEstojamento;

  function getSeqLoteIndOS
  (
    p_idArmazem     in number,
    p_idDepositante in number,
    p_idOS          in number,
    p_idUsuario     in number
  ) return number is
    v_seq       number;
    v_qtdLimite number;
    v_ultimaseq number;
    v_msg       t_message;
  begin
  
    select d.qtddigitoseqestojamento
      into v_qtdLimite
      from depositante d
     where d.identidade = p_idDepositante;
  
    begin
      select nvl(max(oli.sequencia), 0)
        into v_ultimaseq
        from oscontroleloteInd oli
       where oli.iddepositante = p_idDepositante
         and oli.idarmazem = p_idarmazem
         and trunc(oli.data) = trunc(sysdate);
    exception
      when no_data_found then
        v_ultimaseq := 0;
    end;
  
    v_seq := v_ultimaseq + 1;
  
    if (length(v_seq) > v_qtdLimite) then
      v_msg := t_message('Quantidade de Ordem de Serviço excede à quantidade permitida no cadastro do Depositante [idDepositante {0}].');
      v_msg.addParam(p_idDepositante);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    insert into oscontroleloteind
      (id, idos, idarmazem, iddepositante, data, sequencia, datainclusao,
       idusuario)
    values
      (seq_oscontroleloteind.nextval, p_idOS, p_idArmazem, p_idDepositante,
       trunc(sysdate), v_seq, sysdate, p_idUsuario);
  
    return v_seq;
  
  end getSeqLoteIndOS;

  function getCloneOS(p_idOS in number) return number is
    v_rOS  ordemservico%rowtype;
    v_idOS number;
  begin
    begin
      select os.*
        into v_rOS
        from ordemservico os
       where os.idordemservico = p_idOS
         and os.tiposervico in ('J', 'D');
    exception
      when no_data_found then
        return null;
    end;
  
    select seq_ordemservico.nextval
      into v_idOS
      from dual;
  
    v_rOS.Tiposervico    := 'E';
    v_rOS.Observacao     := 'Ordem de Serviço Filha - Desmontagem de Estojo';
    v_rOS.Idosmae        := p_idOS;
    v_rOS.Idordemservico := v_idOS;
  
    insert into ordemservico
    values v_rOS;
  
    return v_rOS.Idordemservico;
  end;

  procedure cancelarOS
  (
    p_idordemservico in number,
    p_usuario        in number
  ) is
    v_tipoServico    ordemservico.tiposervico%type;
    v_idlotenf       lotenf.idlotenf%type;
    v_tipoOnda       romaneiopai.tipo%type;
    v_idPreNfEntrada number;
    v_idPreNfSaida   number;
    v_idOnda         number;
    v_situacaoOS     ordemservico.situacao%type;
  
    procedure carregarDadosIniciais is
    begin
      select os.tiposervico, lnf.idlotenf, rp.tipo, nfent.idprenf,
             rp.idromaneio, nfsai.idprenf, os.situacao
        into v_tipoServico, v_idlotenf, v_tipoOnda, v_idPreNfEntrada,
             v_idOnda, v_idPreNfSaida, v_situacaoOS
        from ordemservico os, lotenf lnf, romaneiopai rp, notafiscal nfent,
             nfromaneio nfr, notafiscal nfsai
       where os.idordemservico = p_idordemservico
         and lnf.idlotenf(+) = os.idlotenf
         and rp.idromaneio(+) = os.idromaneio
         and nfent.idlotenf(+) = lnf.idlotenf
         and nfr.idromaneio(+) = rp.idromaneio
         and nfsai.idnotafiscal(+) = nfr.idnotafiscal;
    end carregarDadosIniciais;
  
    procedure validarOS is
      C_TIPOOS_FORMACAOKIT        constant ordemservico.tiposervico%type := 'K';
      C_TIPOOS_DESMONTAGEMKIT     constant ordemservico.tiposervico%type := 'D';
      C_TIPOOS_ESTOJAMENTO        constant ordemservico.tiposervico%type := 'E';
      C_TIPOOS_DESMONTESTOJAMENTO constant ordemservico.tiposervico%type := 'J';
      C_TIPOOS_FORMACAOKITRASTR   constant ordemservico.tiposervico%type := 'I';
      C_STATUSOS_PROCESSADA       constant ordemservico.situacao%type := 'P';
      C_TIPOEXP_ONDA              constant number := 1;
    
      v_qtdeConfEnt number;
      v_msg         t_message;
    begin
      if v_tipoServico not in
         (C_TIPOOS_FORMACAOKIT, C_TIPOOS_DESMONTAGEMKIT,
          C_TIPOOS_ESTOJAMENTO, C_TIPOOS_DESMONTESTOJAMENTO,
          C_TIPOOS_FORMACAOKITRASTR) then
        v_msg := t_message('Cancelamento de OS permitido apenas para ordens de serviço ' ||
                           'dos tipos "Formação de Kit", "Desmontagem de Kit", ' ||
                           '"Estojamento", "Desmontagem de Estojamento" e "Formação de Kit com Rastreabilidade".');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_situacaoOS <> C_STATUSOS_PROCESSADA then
        v_msg := t_message('Cancelamento de OS permitido apenas para OS em execução.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_tipoOnda <> C_TIPOEXP_ONDA then
        v_msg := t_message('Cancelamento de OS permitido apenas para ordens de serviço ' ||
                           'com expedição por Onda.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_idlotenf is null then
        v_msg := t_message('Cancelamento de OS permitido apenas para OS com OR criada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_tipoOnda = 0 then
        v_msg := t_message('Cancelamento de OS permitido apenas para OS formada com expedição por onda.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_qtdeConfEnt
        from conferenciaentradadet cd
       where cd.idlotenf = v_idlotenf
         and cd.ignorada = 'N';
    
      if v_qtdeConfEnt > 0 then
        v_msg := t_message('Cancelamento de OS permitido apenas antes do início da conferência ' ||
                           'de entrada da OR gerada pela OS.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarOS;
  
    procedure desfazerOR is
    begin
      update ordemservico os
         set os.idlotenf = null
       where os.idordemservico = p_idordemservico;
    
      --Exclui a OR
      pk_recebimento.desfazer_or(v_idLotenf, p_usuario, 'N');
    
      --Exclui a nota de entrada
      delete from nfimpressao
       where idprenf = v_idPreNfEntrada;
    end desfazerOR;
  
    procedure desfazerOnda is
    begin
      --Cancela a onda (origem por cancelamento de OS)
      pk_onda_cancelar.cancelarOnda(v_idOnda, p_usuario, 4);
    
      ---Excluir a nota de saida
      delete from nfimpressao
       where idprenf = v_idPreNfSaida;
    end desfazerOnda;
  
    procedure atualizarOSCanc is
    begin
      update ordemservico os
         set os.situacao         = 'X',
             os.idusuariocancel  = p_usuario,
             os.datacancelamento = sysdate
       where os.idordemservico = p_idordemservico;
    
      pk_utilities.GeraLog(p_usuario,
                           'Cancelou O.S.: ' || p_idordemservico || ' OR: ' ||
                            v_idLotenf, p_idordemservico, 'OS');
    end atualizarOSCanc;
  begin
    carregarDadosIniciais;
  
    validarOS;
  
    desfazerOR;
  
    desfazerOnda;
  
    atualizarOSCanc;
  end cancelarOS;

end pk_servico;
/

