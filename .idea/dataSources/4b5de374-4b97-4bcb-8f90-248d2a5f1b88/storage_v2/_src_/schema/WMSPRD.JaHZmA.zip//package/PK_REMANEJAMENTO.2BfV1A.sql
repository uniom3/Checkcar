create package pk_remanejamento is

  -- Author  : LEANDRO
  -- Created : 19/10/2004 14:51:29

  -- constants usadas na package
  C_NORMAL                 constant char(1) := 'N';
  C_LIBERADO               constant char(1) := 'L';
  C_SIM                    constant char(1) := 'S';
  C_AGUARDANDO             constant char(1) := 'A';
  C_NAO                    constant char(1) := 'N';
  C_FINALIZADO             constant char(1) := 'F';
  C_CONSERTO               constant char(1) := 'F';
  C_ENDPICKING             constant char(1) := 'S';
  C_ATIVO                  constant char(1) := 'S';
  C_MULTIENDERECO          constant char(1) := 'S';
  C_LOTE                   constant char(1) := 'L';
  C_PALLET                 constant char(1) := 'P';
  C_REMANEJ_WEB            constant number := 1;
  C_REMANEJ_MANUAL_COLETOR constant number := 2;
  C_REMANEJ_DESTINO        constant number := 3;
  C_REMANEJ_ORIGEM         constant number := 4;
  C_REMANEJ_PLAN_COLETOR   constant number := 5;

  C_LOCAL_PICKING           constant number := 0;
  C_LOCAL_PULMAO_BLOCADO    constant number := 1;
  C_LOCAL_PULMAO_PALETIZADO constant number := 2;

  C_SETOR_MISTO    constant number := 0;
  C_SETOR_UNIDADES constant number := 1;
  C_SETOR_CAIXAS   constant number := 2;

  -- Registro das Dimensoes Fisicas
  type t_dimensoesFisicas is record(
    peso    number,
    cubagem number,
    qtdeplt number);

  type t_rem is record(
    status                       remanejamento.status%type,
    planejado                    remanejamento.planejado%type,
    idlocalorigem                remanejamento.idlocalorigem%type,
    idarmazemorigem              number,
    idremanejamento              number,
    idlocaldestino               remanejamento.idlocaldestino%type,
    idarmazemdestino             number,
    idcontroleavaria             number,
    idinsucessoentrega           number,
    idprodutorecuperado          number,
    tipoexportacaoprodrecuperado number,
    usoexclusivocxmov            number);

  type rec_estlocal is record(
    idlote        lote.idlote%type,
    idlocal       local.idlocal%type,
    disp          number,
    loteindustria lote.descr%type,
    dtvenc        lote.dtvenc%type);

  type cursor_estlocal is ref cursor;

  type rec_lote is record(
    idarmazem      armazem.idarmazem%type,
    idlocal        local.idlocal%type,
    idlote         lote.idlote%type,
    disponivel     number,
    datavencimento lote.dtvenc%type,
    idsetor        setor.idsetor%type,
    fatorconversao embalagem.fatorconversao%type,
    loteindustria  lote.descr%type);

  type cursor_lote is ref cursor;

  /*
  * Func?o que cadastra o remanejamento
  */
  function cadastrar_remanejamento
  (
    p_idarmazemorigem  in number,
    p_idarmazemdestino in number,
    p_idlocalorigem    in local.idlocal%type,
    p_idlocaldestino   in local.idlocal%type,
    p_idusuario        in number,
    p_idromaneio       in number,
    p_descr            in remanejamento.descrpalet%type,
    p_commit           in varchar2 := C_SIM,
    p_planejado        in varchar2 := C_NAO
  ) return number;

  /*
   * Responsavel por trocar os lotes no remanejamento.
  */
  procedure alterar_remanejamento
  (
    p_idremanejamento in number,
    p_lote            in number,
    p_qtde            in number,
    p_usuario         in number
  );

  /*
  * Gera os lotes para serem remanejados do picking para o pulmao
  */
  procedure Gerar_Lotes
  (
    p_remanejamento in number,
    p_idarmazem     in number,
    p_idlocal       in local.idlocal%type,
    p_lotes         in number,
    p_fator         in number,
    p_iduser        in number,
    p_idproduto     in produto.idproduto%type
  );

  procedure recalcula_paletseparacao
  (
    p_lote          in lote.idlote%type,
    p_remanejamento in remanejamento.idremanejamento%type,
    p_usuario       in usuario.idusuario%type
  );

  /*
  * procedure responsavel por gerar os reabastecimentos automaticos
  */
  procedure reabastecer_automatico
  (
    p_idarmazem     in number,
    p_iddepositante in number,
    p_idproduto     in number,
    p_idlocal       in local.idlocal%type,
    p_idusuario     in number
  );

  /*
   * Carrega as informacoes do remanejamento
  */
  function CarregarRemanejamento(p_idremanejamento in number)
    return remanejamento%rowtype;

  /*
   * Retorna a quantidade a ser remanejada
  */
  function CtrlObterQtdeRem
  (
    p_idlocal       in local.idlocal%type,
    p_idLote        in lote.idlote%type,
    p_idProduto     in lote.idproduto%type,
    p_qtdeDispLote  in number,
    p_pedirCodBarra in boolean := false
  ) return number;

  /*
   * Função para retornar se um setor é valido para alocação e remanejamento
  */
  function CtrlvalidarSetor
  (
    p_idlote    in lote.idlote%type,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return boolean;

  /*
   * Validar as restrições físicas do destino
  */
  function CtrlValidarRestriFisicas
  (
    p_idproduto in produto.idproduto%type,
    p_qtde      in number,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type,
    p_barra     in embalagem.barra%type,
    p_tipoerro  in out number
  ) return boolean;

  /* 
   * Validação do picking
  */
  function CtrlValidarPicking
  (
    p_idlote    in lote.idlote%type,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return boolean;

  /*
   * Validação de multiendereco
  */
  function validarMultiendereco
  (
    p_dimensoes     in t_dimensoesFisicas,
    p_multiendereco in produto.multiendereco%type,
    p_idarmazem     in armazem.idarmazem%type,
    p_idlocal       in local.idlocal%type
  ) return t_dimensoesFisicas;

  /*
   * Procedure para Vincular os produtos ao remanejamento
  */
  function CtrlVincularMaterial
  (
    p_idlote           in lote.idlote%type,
    p_tipolote         in lote.tipolote%type,
    p_idproduto        in lote.idproduto%type,
    p_idarmazemorigem  in armazem.idarmazem%type,
    p_idlocalorigem    in local.idlocal%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    p_qtdedisponivel   in number
  ) return varchar;

  /*
   * Limpa os endereços filhos de alocação multiendereço
  */
  procedure RemoveInfMultiEndereco(p_idremanejamento in remanejamento.idremanejamento%type);

  /*
   * Valida se o lote e componente de montagem
  */
  function CtrlValManipCompMont(p_idlote in lote.idlote%type) return boolean;

  /*
   * Inclui no remanejamento os lotes componentes da montagem
  */
  procedure Associar
  (
    p_idRemanejamento in remanejamento.idremanejamento%type,
    p_idlote          in lote.idlote%type
  );

  /*
   * Excluir do remanejamento os lotes componentes da montagem
  */
  procedure Desassociar
  (
    p_idRemanejamento in remanejamento.idremanejamento%type,
    p_idlote          in lote.idlote%type
  );

  /*
   * Retornar consulta de reabastecimentos 
  */
  function ConsultaLoteReab
  (
    p_idremanejamento in number,
    p_idlote          in number default 0
  ) return varchar2;

  /*
  * Valida possibilidade  de geracao de lotes no remanejamento de picking para pulmao
  */
  function ValidarGeracaoLotes
  (
    p_idarmazem     in number,
    p_idlocal       local.idlocal%type,
    p_idproduto     in number,
    p_iddepositante in number,
    p_estado        lote.estado%type,
    p_fator         in number,
    p_qtde          in number,
    p_itemadicional in lote.itemadicional%type,
    p_mensagem      out varchar2,
    p_idlote        in number := 0
  ) return boolean;

  procedure InserirLoteRemanejamento
  (
    p_idremanejamento in number,
    p_idarmazem       in number,
    p_idlocal         in local.idlocal%type,
    p_idusuario       in number,
    p_idlote          in number,
    p_qtde            in number
  );

  procedure InserirComposicaoLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_qtde            in number,
    p_qtdecoberta     in number
  );

  procedure GerarDocumentos
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_iddepositante   in number,
    p_mensagem        out varchar2
  );

  /*
   * Rotina que pesa os lotes do remanejamento
  */
  procedure PesarLotes
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_peso            in number,
    p_mensagem        out varchar2
  );

  procedure EtiquetaImpressaCorreta
  (
    p_idremanejamento in number,
    p_idlote          in number
  );

  /*
   * Rotina que libera lotes com divergencia do remanejamento de PK para Pulmao
  */
  procedure LiberarLotesDivergente
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_idusuario       in number
  );

  /*
   * Rotina que cancela cadastramento de lotes
  */
  procedure CancelarGerarLotes
  (
    p_idremanejamento in number,
    p_idusuario       in number
  );

  /*
   * Rotina que finaliza o cadastramento de Lotes
  */
  procedure FinalizarGerarLotes
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_mensagem        out varchar2,
    p_finalizar       out number,
    p_commit          in char := 'S'
  );

  /*
  * Rotina que gera etiquetas de remanejamento
  */
  procedure GeraEtiqRemanejamento;

  /*
  * Rotina responsavel por gerar o remanejamento por motivo de mudança de setor.
  */
  function NovoRemPorMudancaSetor
  (
    p_idusuario     in number,
    p_idproduto     in number,
    p_idarmazem     in number,
    p_idlocalorigem in local.idlocal%type
  ) return number;

  /*
   * Rotina responsavel por gerar remanejamentos de itens ja alocados de encomendas
  */
  procedure GerarRemItensAlocados
  (
    p_idencomenda in number,
    p_idusuario   in number
  );

  /*
   * Rotina responsavel por realizar a mudança de picking para um produto
  */
  procedure processarMudancaPicking
  (
    p_idusuario      in number,
    p_iddepositante  in number,
    p_idproduto      in number,
    p_idArmazem      in number,
    p_idlocalorigem  in local.idlocal%type,
    p_idlocaldestino in local.idlocal%type
  );

  /*
  * Funcao que verifica como o remanejamento sera executado
  */
  function retornarExecRemanejamento(p_idremanejamento in number)
    return number;

  /*
   * Rotina responsavel por verificar se o remanejamento depende da execucao de outro
  */
  procedure verificarReabPendente(p_idremanejamento in number);

  function getQtdeUnitEmbQueCoube
  (
    p_maxpeso           in number,
    p_maxcubagem        in number,
    p_idlote            in number,
    p_qtde              in number,
    p_remanejarPorFator in char
  ) return number;

  procedure planejarRemanejamentoLote
  (
    p_idusuario              in number,
    p_idarmazem              in number,
    p_idlocalorigem          in local.idlocal%type,
    p_idlocaldestino         in local.idlocal%type,
    p_idlote                 in number,
    p_qtde                   in number,
    p_descricao              in varchar2,
    p_idromaneio             in number := null,
    p_idnotafiscal           in number := null,
    p_verificarMaxDimensao   in char := 'N',
    p_remPorFatorMaxDimensao in char := 'S',
    p_idmovimentacao         in number := null
  );

  function retornarTarefa
  (
    p_idremanejamento in number,
    p_idendereco      in number
  ) return varchar2;

  function retornarQtdeRemPorTarefa
  (
    p_codtarefa in varchar2,
    p_tipo      in varchar := 0
  ) return varchar2;

  function retornarRemPorTarefa(p_codtarefa in varchar2) return varchar2;

  procedure validarBufPickEsteira
  (
    p_idRemanejamento in number,
    p_telaExecRemanej in number default 0
  );

  procedure finalizarRemanejamento
  (
    p_idremanejamento     in number,
    p_idusuario           in number,
    p_telaExecFinalizacao in number default 0
  );
  procedure finalizarRemanejamentoWEB
  (
    p_idremanejamento in number,
    p_idusuario       in number
  );

  procedure finalizarPlanejamento(p_idremanejamento in number);

  procedure reabrirPlanejamento
  (
    p_idremanejamento in number,
    p_idusuario       in number
  );

  /*
   * Carrega o resumo das embalagens a serem utilizadas
   * a partir do produto, local e da qtde a ser movimentada
  */
  function retResumoEmbalagensLocal
  (
    p_idproduto in number,
    p_qtde      in number,
    p_idlocal   in local.idlocal%type
  ) return string;

  procedure associarLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_quantidade      in number,
    p_idusuario       in number
  );

  procedure desassociarLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_idusuario       in number
  );

  procedure MarcarImpressoRemanejamento
  (
    p_idremanejamento in number,
    p_idusuario       in number
  );

  procedure formarLotePickingPulmao
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_moduloSistema   in number := 0
  );

  procedure gerarRemPerdaCorteFisico(p_idusuario in number);

  /*
  * rotina responsavel por desfazer os remanejamentos gerados para o romaneio ao desfazer o romaneio
  */
  procedure desfazerRemanejamento
  (
    p_romaneio     in number,
    p_usuario      in number,
    p_tipo         in number,
    p_idnotafiscal in number
  );

  procedure desfazRemanejBuffPickParaPick
  (
    p_idonda          in number,
    p_idusuario       in number,
    p_idmovimentacoes in varchar2
  );

  procedure validaDispExecucao(p_idremanejamento in number);
  procedure excluirRemanejamento
  (
    p_idremanejamento in number,
    p_usuario         in number
  );

  function getDadosRegraDepositanteLocal
  (
    p_idLocal        in varchar2,
    p_idArmazem      in number,
    p_barraInformada in varchar2
  ) return number;

  function getDadosRegraDepositanteLote
  (
    p_idremanejamento in number,
    p_barraInformada  in varchar2
  ) return number;

  procedure validarFinalizarRemanejamento(p_idRemanejamento number);

  procedure integrarEsteira
  (
    p_idremanejamento number,
    p_idusuario       number
  );

  procedure concluirOrigem
  (
    p_idRemanejamento       in number,
    p_idUsuario             in number,
    p_TipoMenuRemanejamento in number
  );

  procedure ExecOrigemRemBufferPicking
  (
    p_idOnda        in number,
    p_idLocalBuffer in local.idlocal%type,
    p_idProduto     in number,
    p_idUsuario     in number
  );

  procedure conferirLoteIndustria
  (
    p_idremanejamento in remanejamento.idremanejamento%type,
    p_loteIndustria   in lote.descr%type
  );

  /*
   * Função que retorna string descrevendo as qtdes de caixas do reabastecimento.
  */
  function retorna_qtde_caixa
  (
    p_idremanejamento in number,
    p_idproduto       in number default null,
    p_loteIndustria   in varchar2 default null,
    p_conferido       in varchar2 default null
  ) return varchar2;

  function confirmarTrocaLocalDestino
  (
    p_idremanejamento in number,
    p_idtrocalocal    in number,
    p_idusuario       in number
  ) return number;

  function verificaCompOrigemDestino
  (
    p_qtdeTotalLote      in lote.qtdedisponivel%type,
    p_fatorConversaoLote in lote.fatorconversao%type,
    p_qtdeLoteRemanejado in lote.qtdedisponivel%type
  ) return boolean;

  procedure infLoteIndRemanejarMaterial
  (
    p_idLote        in number,
    p_loteIndustria in varchar2
  );

  function validarImpressaoEtqRemanej
  (
    p_idUsuario    in number,
    p_idsupervisor in number := 0
  ) return number;

  procedure regraRemanejamentoLoteUnico(p_idremanejamento in number);

  procedure regraLoteVencimentoUnicoNoEnd(p_idremanejamento in number);

end pk_remanejamento;
/

