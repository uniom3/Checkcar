create view VT_LOTEINVENTARIO as
select ai.idinventario h$tableid, lo.idlocal,
       decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') tipo,
       ai.idlotenovo idlote, en.razaosocial depositante,
       pr.codigointerno codproduto, pr.descr produto, e.barra,
       ai.qtdeunit / e.fatorconversao qtde, e.descrreduzido embalagem,
       e.fatorconversao, ai.qtdeunit qtdeunitaria, ol.idlotenf, ai.idproduto,
       ai.idinventario, lo.idlocalformatado f$idlocal, lo.ordem h$ordem
  from invacaoestentrada ai, local lo, produto pr, embalagem e, orlote ol,
       entidade en
 where lo.id = ai.idendereco
   and pr.idproduto = ai.idproduto
   and e.idproduto = ai.idproduto
   and e.barra = ai.barra
   and ol.idlote(+) = ai.idlotenovo
   and ai.identidade = en.identidade
/

