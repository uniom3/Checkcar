create view VT_GERENCIADORETIQUETAS as
select idrelatorio idetiqueta, upper(descr) descr, tiporelatorio,
       personalizada, ativo, nomearquivojasper h$nomearquivojasper
  from gerenciadorrelatorio
/

