create view VT_CONFIGALERTAINTDEPOSITANTE as
select ed.identidade, ed.razaosocial, ed.fantasia
  from entidade ed, depositante d
 where ed.ativo = 'S'
   and d.identidade = ed.identidade
/

