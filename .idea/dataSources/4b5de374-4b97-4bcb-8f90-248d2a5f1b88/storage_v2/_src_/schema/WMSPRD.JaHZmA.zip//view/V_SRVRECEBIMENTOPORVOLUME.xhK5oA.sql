create view V_SRVRECEBIMENTOPORVOLUME as
select l.idarmazem, l.identidade iddepositante, l.datageracaomapaaloc data,
       pk_produto.getQtdeVolumes(sum(lt.qtdeentrada * lt.fatorconversao),
                                  lt.fatorconversao,
                                  nvl(epd.fatorconversao,
                                       pk_produto.getFatorConversaoMenorMaior(p.idproduto)),
                                  e.caixafechada) volume, l.idlotenf
  from lotenf l, tiporecebimento tr, orlote ol, lote lt, produto p,
       embalagem e, produtodepositante pd, embalagem epd
 where tr.idtiporecebimento = l.idtiporecebimento
   and tr.classificacao <> 'I'
   and lt.idlote = ol.idlote
   and ol.idlotenf = l.idlotenf
   and p.idproduto = lt.idproduto
   and e.idproduto = p.idproduto
   and e.barra = lt.barra
   and lt.tipolote = 'L'
   and l.mapaaloc = 'S'
   and pd.idproduto = p.idproduto
   and pd.identidade = l.identidade
   and pd.embalagemarmazenagem = epd.barra(+)
   and not exists
 (select 1
          from notafiscal nf
         where nf.idlotenf = l.idlotenf
           and ((case
                 when nf.sequencia like '%AVARIA%' then
                  1
                 when nf.sequencia like '%INVENTARIO%' then
                  1
                 when nf.sequencia like '%AJUSTE%' then
                  1
                 when nf.sequencia like '%TRANSFERENCIA%' then
                  1
                 when nf.sequencia like '%KIT%' then
                  1
                 when nf.sequencia like '%RET%' then
                  1
                 else
                  0
               end = 1) or (nf.idinventario is not null)))
 group by l.idarmazem, l.identidade, l.datageracaomapaaloc,
          lt.fatorconversao, l.idlotenf, e.caixafechada, epd.fatorconversao,
          p.idproduto
/

