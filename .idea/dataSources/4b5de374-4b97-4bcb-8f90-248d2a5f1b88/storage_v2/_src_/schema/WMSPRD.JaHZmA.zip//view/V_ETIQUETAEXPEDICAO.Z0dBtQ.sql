create view V_ETIQUETAEXPEDICAO as
select rownum id,
       rp.idromaneio onda,
       to_char(rp.datageracao, 'dd/MM/yyyy hh24:mm') data,
       nf.codigointerno notafiscal,
       vr.idvolume || ' / ' || qv.qtdevolumes volume,
       vr.codbarra barra,
       rem.razaosocial remetente,
       rtrim(ende.tipologr) || ' ' || rtrim(ende.logradouro) || ', ' || rtrim(ende.numero) enderecoremetente,
       rtrim(ende.bairro) || ' - ' || rtrim(ende.cidade) || ' - ' || rtrim(ende.uf) complementoremetente,
       ende.cep cepremetente,
       nfi.nome_dest destinatario,
       nfi.endereco_dest enderecodestinatario,
       rtrim(nfi.bairro_dest) || ' - ' || rtrim(nfi.cidade_dest) || ' - ' || rtrim(nfi.estado_dest) complementodestinatario,
       nfi.cep_dest cepdestinatario,
       nvl(transcarga.razaosocial, trans.razaosocial) transportadora,
       ps.peso,
       pk_romaneio.RetornarSiglaExpedicaoTransp(nvl(transcarga.identidade, trans.identidade), nfi.cep_dest) rota,
       ENTARM.RAZAOSOCIAL razaosocialarmazem , TELARM.IDTELEFONE telefonearmazem
  from romaneiopai rp,
       volumeromaneio vr,
       notafiscal nf,
       entidade rem,
       v_endereco ende,
       nfimpressao nfi,
       entidade trans,
       entidade transcarga,
       carga ca, ENTIDADE ENTARM, ARMAZEM A, TELEFONE TELARM,
       (select idromaneio, count(*) qtdevolumes
           from volumeromaneio
          group by idromaneio) qv,
       (select cv.idvolumeromaneio, (cv.quantidade / e.fatorconversao * e.pesobruto) peso
           from conteudovolume cv, embalagem e, lote l
           where cv.idlote = l.idlote
              and l.barra = e.barra) ps
   where TELARM.IDENTIDADE(+) = A.IDENTIDADE
   AND ENTARM.IDENTIDADE = A.IDENTIDADE
   AND A.IDARMAZEM = RP.IDARMAZEM
   AND rp.idromaneio = vr.idromaneio
   and vr.idnotafiscal = nf.idnotafiscal
   and qv.idromaneio = rp.idromaneio
   and rem.identidade = nf.remetente
   and ende.identidade(+) = rem.identidade
   and nfi.idprenf = nf.idprenf
   and trans.identidade(+) = nf.transportadoranotafiscal
   and transcarga.identidade(+) = ca.identidade
   and ca.idcarga(+) = rp.idcarga
   and rp.tipo = 1
   and ps.idvolumeromaneio = vr.idvolumeromaneio
 order by rp.idromaneio, vr.idvolume
/

