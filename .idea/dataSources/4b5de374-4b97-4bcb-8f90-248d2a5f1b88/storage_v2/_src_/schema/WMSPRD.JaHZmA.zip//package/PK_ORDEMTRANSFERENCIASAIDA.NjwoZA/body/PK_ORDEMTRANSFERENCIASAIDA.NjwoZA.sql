create package body pk_ordemtransferenciasaida is

  procedure validarParametrosOTS
  (
    p_idArmazem armazem.idarmazem%type,
    p_idUsuario usuario.idusuario%type
  ) is
    v_msg  t_message;
    v_qtde number;
  begin
    select count(1)
      into v_qtde
      from gtt_itemordemtransfsaida;
  
    if (v_qtde = 0) then
      v_msg := t_message('Ordem de transferência de saída não informado.');
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
    select count(1)
      into v_qtde
      from armazem a
     where a.idarmazem = p_idarmazem
       and a.ativo = 'S';
  
    if (v_qtde = 0) then
      v_msg := t_message('Armazém não encontrado.');
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
    select count(1)
      into v_qtde
      from usuario u
     where u.idusuario = p_idUsuario;
  
    if (v_qtde = 0) then
      v_msg := t_message('Usuário não encontrado.');
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
  end validarParametrosOTS;

  procedure validarOrdemTransfSaida
  (
    p_idordemtransferenciasaida ordemtransferenciasaida.id%type,
    r_ordemtransferenciasaida   out ordemtransferenciasaida%rowtype
  ) is
    v_msg t_message;
  begin
    if (p_idordemtransferenciasaida is null) then
      v_msg := t_message('Ordem de transferência de saída não informado.');
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
    begin
      select o.*
        into r_ordemtransferenciasaida
        from ordemtransferenciasaida o
       where o.id = p_idordemtransferenciasaida
         for update;
    exception
      when no_data_found then
        v_msg := t_message('Ordem de transferência de saída id {0} não encontrado.');
        v_msg.addparam(p_idordemtransferenciasaida);
        raise_application_error(-20000, v_msg.formatmessage);
    end;
  
    if (r_ordemtransferenciasaida.status =
       pk_ordemtransferenciasaida.C_OTS_STATUS_FINALIZADO) then
      v_msg := t_message('Ordem de transferência de saída id {0} está com status finalizada.');
      v_msg.addparam(p_idordemtransferenciasaida);
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
    if (r_ordemtransferenciasaida.status =
       pk_ordemtransferenciasaida.C_OTS_STATUS_CANCELADO) then
      v_msg := t_message('Ordem de transferência de saída id {0} está com status cancelada.');
      v_msg.addparam(p_idordemtransferenciasaida);
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
    if (r_ordemtransferenciasaida.status =
       pk_ordemtransferenciasaida.C_OTS_STATUS_FIN_CANCELADO) then
      v_msg := t_message('Ordem de transferência de saída id {0} está com status finalizada/cancelada.');
      v_msg.addparam(p_idordemtransferenciasaida);
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
  end validarOrdemTransfSaida;

  procedure criarPedidoOrdemTransSaida
  (
    p_idArmazem        armazem.idarmazem%type,
    p_idUsuario        usuario.idusuario%type,
    p_idTransportadora entidade.identidade%type
  ) is
  
    v_msg                     t_message;
    r_ordemtransferenciasaida ordemtransferenciasaida%rowtype;
  
    r_entidadedepositante  entidade%rowtype;
    r_entidadedestinatario entidade%rowtype;
    r_entidadearmazem      entidade%rowtype;
    r_depositante          depositante%rowtype;
  
    v_cfop operacao.idcfop%type;
  
    v_agrupador    number;
    v_numeroPedido notafiscal.numpedidofornecedor%type;
    v_idNotaFiscal notafiscal.idnotafiscal%type;
  
    v_qtdePedidoOTS number;
  
    procedure validarCriarItemPedidoOTS(p_idordemtransferenciasaida ordemtransferenciasaida.id%type) is
      v_qtde               number;
      v_qtdedisponivelitem number;
      r_otsItem            ordemtransferenciasaidaitem%rowtype;
    begin
      select count(1)
        into v_qtde
        from gtt_itemordemtransfsaida g
       where g.idordemtranssaida = p_idordemtransferenciasaida;
    
      if (v_qtde = 0) then
        v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada pois nenhum item foi informado.');
        v_msg.addparam(p_idordemtransferenciasaida);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
      for c_gtt in (select g.idordemtranssaida, g.idordemtranssaidaitem,
                           g.idproduto,
                           nvl(sum(g.qtdeunitaria), 0) qtdeunitaria
                      from gtt_itemordemtransfsaida g
                     where g.idordemtranssaida = p_idordemtransferenciasaida
                     group by g.idordemtranssaida, g.idordemtranssaidaitem,
                              g.idproduto)
      loop
        if (c_gtt.qtdeunitaria <= 0) then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. IdProduto {1} não possui um valor valido para o campo quantidade {2}.');
          v_msg.addparam(c_gtt.idordemtranssaida);
          v_msg.addparam(c_gtt.idproduto);
          v_msg.addparam(c_gtt.qtdeunitaria);
          raise_application_error(-20000, v_msg.formatmessage);
        end if;
      
        select count(1)
          into v_qtde
          from produto p
         where p.idproduto = c_gtt.idproduto;
      
        if (v_qtde = 0) then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. IdProduto {1} não encontrado.');
          v_msg.addparam(c_gtt.idordemtranssaida);
          v_msg.addparam(c_gtt.idproduto);
          raise_application_error(-20000, v_msg.formatmessage);
        end if;
      
        select count(1)
          into v_qtde
          from produtodepositante pd
         where pd.idproduto = c_gtt.idproduto
           and pd.identidade = r_ordemtransferenciasaida.iddepositante;
      
        if (v_qtde = 0) then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. IdProduto {1} não encontrado para o Depositante id {2}.');
          v_msg.addparam(c_gtt.idordemtranssaida);
          v_msg.addparam(c_gtt.idproduto);
          v_msg.addparam(r_ordemtransferenciasaida.iddepositante);
          raise_application_error(-20000, v_msg.formatmessage);
        end if;
      
        begin
          select i.*
            into r_otsItem
            from ordemtransferenciasaidaitem i
           where 1 = 1
             and i.id = c_gtt.idordemtranssaidaitem
             and i.idordemtransferenciasaida = c_gtt.idordemtranssaida
             and i.idproduto = c_gtt.idproduto
             for update;
        exception
          when no_data_found then
            v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. IdProduto {1} não encontrado na Ordem de Transferência de Saída.');
            v_msg.addparam(c_gtt.idordemtranssaida);
            v_msg.addparam(c_gtt.idproduto);
            raise_application_error(-20000, v_msg.formatmessage);
        end;
      
        v_qtdedisponivelitem := (nvl(r_otsItem.qtdesolicitada, 0) -
                                nvl(r_otsItem.qtdecancelada, 0) -
                                nvl(r_otsItem.qtdereservada, 0));
      
        if (v_qtdedisponivelitem < c_gtt.qtdeunitaria) then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. IdProduto {1} possui {2} de quantidade e na geração do pedido esta sendo informada a quantidade {3}.');
          v_msg.addparam(c_gtt.idordemtranssaida);
          v_msg.addparam(c_gtt.idproduto);
          v_msg.addparam(v_qtdedisponivelitem);
          v_msg.addparam(c_gtt.qtdeunitaria);
          raise_application_error(-20000, v_msg.formatmessage);
        end if;
      
      end loop;
    end validarCriarItemPedidoOTS;
  
    procedure carregarEntidades is
    begin
      select e.*
        into r_entidadedepositante
        from entidade e
       where e.identidade = r_ordemtransferenciasaida.iddepositante;
    
      select d.*
        into r_depositante
        from depositante d
       where d.identidade = r_ordemtransferenciasaida.iddepositante;
    
      select e.*
        into r_entidadedestinatario
        from entidade e
       where e.identidade = r_ordemtransferenciasaida.iddestinatario;
    
      select e.*
        into r_entidadearmazem
        from armazem a, entidade e
       where e.identidade = a.identidade
         and a.idarmazem = p_idarmazem;
    
      if (nvl(r_depositante.utilizaordemtransferenciasaida, 0) <> 1) then
        v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. Depositante id {1} não utiliza Ordem de Transferência de Saída.');
        v_msg.addparam(r_ordemtransferenciasaida.id);
        v_msg.addparam(r_ordemtransferenciasaida.iddepositante);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
      if (r_depositante.idopordemtransfsaid is null) then
        v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. CFOP não informado para Ordem de Transferência de Saída.');
        v_msg.addparam(r_ordemtransferenciasaida.id);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
      begin
        select o.idcfop
          into v_cfop
          from depositante d, operacao o
         where o.idoperacao = d.idopordemtransfsaid
           and d.identidade = r_ordemtransferenciasaida.iddepositante;
      exception
        when no_data_found then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. CFOP não informado para Ordem de Transferência de Saída.');
          v_msg.addparam(r_ordemtransferenciasaida.id);
          raise_application_error(-20000, v_msg.formatmessage);
      end;
    
    end carregarEntidades;
  
    procedure criarPedido(p_idordemtransferenciasaida ordemtransferenciasaida.id%type) is
      v_qtdeitens  number;
      v_cep        int_pedido.cep_dest%type;
      v_logradouro int_pedido.endereco_dest%type;
      v_bairro     int_pedido.bairro_dest%type;
      v_cidade     int_pedido.cidade_dest%type;
      v_UF         int_pedido.estado_dest%type;
      v_idEndereco endereco.idendereco%type;
    
      v_cepDest        int_pedido.cep_dest%type;
      v_logradouroDest int_pedido.endereco_dest%type;
      v_cidadeDest     int_pedido.cidade_dest%type;
    
    begin
      select count(1)
        into v_qtdeitens
        from gtt_itemordemtransfsaida g
       where g.idordemtranssaida = p_idordemtransferenciasaida;
    
      if (r_ordemtransferenciasaida.cep is null) then
        v_idEndereco := pk_entidade.f_ret_idendereco(r_ordemtransferenciasaida.iddestinatario);
      
        if (v_idEndereco is null) then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. Não foi possível determinar o endereço do destinatário.');
          v_msg.addparam(r_ordemtransferenciasaida.id);
          raise_application_error(-20000, v_msg.formatmessage);
        end if;
      
        select e.cep, e.logradouro, c.descr
          into v_cepDest, v_logradouroDest, v_cidadeDest
          from endereco e, cidade c
         where 1 = 1
           and c.idcidade = e.idcidade
           and e.idendereco = v_idEndereco;
      
      end if;
    
      v_cep := nvl(v_cepDest,
                   replace(r_ordemtransferenciasaida.cep, '-', ''));
    
      if (v_cep is null) then
        v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. Não foi possível determinar o endereço do destinatário.');
        v_msg.addparam(r_ordemtransferenciasaida.id);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
      begin
        select nvl(r_ordemtransferenciasaida.endereco, cep.logradouro),
               nvl(r_ordemtransferenciasaida.cidade, c.descr) cidade,
               nvl(c.estadocidade, '--') uf, nvl(b.descr, '-') bairro
          into v_logradouro, v_cidade, v_UF, v_bairro
          from cep, cidade c, bairro b
         where cep.cep = v_cep
           and c.idcidade = cep.idcidade
           and b.idbairro(+) = cep.idbairro;
      exception
        when no_data_found then
          v_logradouro := nvl(r_ordemtransferenciasaida.endereco,
                              v_logradouroDest);
          v_cidade     := nvl(r_ordemtransferenciasaida.cidade, v_cidadeDest);
          v_UF         := '--';
          v_bairro     := '-';
      end;
    
      insert into int_pedido
        (agrupador, numpedido, codigointerno, tipo, cnpj_depositante,
         cnpj_emitente, cfop, data_emissao, pessoa_dest, codigo_dest,
         nome_dest, cnpj_dest, endereco_dest, bairro_dest, cep_dest,
         cidade_dest, estado_dest, vlrprodutos, vlrtotal, pesoliquido,
         num_itens, tiponf, ciffob, cnpj_unidade, idordemtransfsaida)
      values
        (v_agrupador, v_numeroPedido, v_numeroPedido, 'S',
         r_entidadedepositante.cgc, r_entidadedepositante.cgc, v_cfop,
         sysdate, r_entidadedestinatario.pessoa,
         r_entidadedestinatario.codigointerno,
         r_entidadedestinatario.razaosocial, r_entidadedestinatario.cgc,
         v_logradouro, v_bairro, v_cep, v_cidade, v_UF, 0, 0, 0, v_qtdeitens,
         'P', 1, r_entidadearmazem.cgc, r_ordemtransferenciasaida.id);
    
    end criarPedido;
  
    procedure carregarNotaFiscal is
    begin
      begin
        select distinct nf.idnotafiscal
          into v_idnotafiscal
          from logintegracao lg, nfimpressao nfi, notafiscal nf
         where 1 = 1
           and nfi.idprenf = lg.idprenf
           and nf.idprenf = nfi.idprenf
           and lg.tipo = 'S'
           and lg.extencaoarq = 'INF'
           and lg.numpedido = v_numeroPedido
           and lg.agrupador = v_agrupador
           and rownum = 1;
      exception
        when no_data_found then
          v_msg := t_message('Ordem de transferência de saída id {0} não pode ser gerada. Nota Fiscal não foi cadastrada.');
          v_msg.addparam(r_ordemtransferenciasaida.id);
          raise_application_error(-20000, v_msg.formatmessage);
      end;
    end carregarNotaFiscal;
  
    procedure ajustarTransportadora is
    begin
      update notafiscal nf
         set nf.transportadoranotafiscal = p_idTransportadora
       where nf.idnotafiscal = v_idNotaFiscal;
    end ajustarTransportadora;
  
    procedure validarPedidoCriado is
      v_error logintegracao.descr%type;
    begin
      begin
        select lg.descr
          into v_error
          from logintegracao lg
         where lg.tipo = 'E'
           and lg.extencaoarq = 'INF'
           and lg.numpedido = v_numeroPedido
           and lg.agrupador = v_agrupador
           and rownum = 1;
      
        raise_application_error(-20000, v_error);
      exception
        when no_data_found then
          return;
      end;
    end validarPedidoCriado;
  
    procedure criarItemPedido(p_idordemtransferenciasaida number) is
      v_idnfdet nfdet.idnfdet%type;
    
    begin
      for c_gtt in (select g.idordemtranssaida, g.idordemtranssaidaitem,
                           g.idproduto, sum(g.qtdeunitaria) qtdeunitaria,
                           pk_produto.retornar_codbarra(g.idproduto, 1) barraunit
                      from gtt_itemordemtransfsaida g
                     where g.idordemtranssaida = p_idordemtransferenciasaida
                     group by g.idordemtranssaida, g.idordemtranssaidaitem,
                              g.idproduto,
                              pk_produto.retornar_codbarra(g.idproduto, 1))
      loop
        v_idnfdet := seq_nfdet.nextval;
      
        insert into nfdet
          (nf, barra, idproduto, qtde, idnfdet)
        values
          (v_idNotafiscal, c_gtt.barraunit, c_gtt.idproduto,
           c_gtt.qtdeunitaria, v_idnfdet);
      
        insert into ordemtransfsaidaitemnfdet
          (idordemtransfsaidaitemnfdet, idordemtransfsaidaitem, idnfdet,
           qtdeunitaria, idusuariocriacao, datacriacao)
        values
          (seq_ordemtransfsaidaitemnfdet.nextval,
           c_gtt.idordemtranssaidaitem, v_idnfdet, c_gtt.qtdeunitaria,
           p_idusuario, sysdate);
      
        update ordemtransferenciasaidaitem oi
           set oi.qtdereservada = nvl(oi.qtdereservada, 0) +
                                  c_gtt.qtdeunitaria
         where oi.id = c_gtt.idordemtranssaidaitem;
      
      end loop;
    
    end criarItemPedido;
  
  begin
  
    validarParametrosOTS(p_idArmazem, p_idUsuario);
  
    for c in (select g.idordemtranssaida
                from gtt_itemordemtransfsaida g
               group by g.idordemtranssaida)
    loop
      validarOrdemTransfSaida(c.idordemtranssaida,
                              r_ordemtransferenciasaida);
      validarCriarItemPedidoOTS(c.idordemtranssaida);
    
      carregarEntidades;
    
      v_agrupador := seq_agrupadorintegracao.nextval;
    
      select count(1)
        into v_qtdePedidoOTS
        from notafiscal nf
       where nf.idordemtransfsaida = c.idordemtranssaida;
    
      v_numeroPedido := substr(r_ordemtransferenciasaida.numeroordemtransferenciasaida,
                               0, 18) || '-' || (v_qtdePedidoOTS + 1);
    
      pk_triggers_control.disabletrigger('CadastroPedidoOTS');
    
      criarPedido(c.idordemtranssaida);
    
      validarPedidoCriado;
    
      carregarNotaFiscal;
    
      ajustarTransportadora;
    
      criarItemPedido(c.idordemtranssaida);
    
      pk_triggers_control.disableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.disableTrigger('T_AFTER_NFIMPRESSAO');
      pk_notafiscal.p_gerar_nfimpressao(v_idnotafiscal, 'N');
      pk_triggers_control.enableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.enableTrigger('T_AFTER_NFIMPRESSAO');
    
      pk_triggers_control.enabletrigger('CadastroPedidoOTS');
    
      if (r_depositante.libnfexpedicaoautomaticaots = 1) then
        delete from gtt_selecaoliberacao;
      
        insert into gtt_selecaoliberacao
          (idselecionado)
        values
          (v_idnotafiscal);
      
        pk_notafiscal.liberarNFExpedicao(p_idusuario, p_idarmazem);
      end if;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Gerou o Pedido ' || v_numeroPedido ||
                            ' idNotaFiscal ' || v_idnotafiscal ||
                            ' para Ordem de Transferência de Saída id ' ||
                            c.idordemtranssaida, v_idnotafiscal, 'OT');
    
    end loop;
  
  end criarPedidoOrdemTransSaida;

  procedure criarPedidTotalOrdemTransSaida
  (
    p_idOrdemTransferenciaSaida ordemtransferenciasaida.id%type,
    p_idArmazem                 armazem.idarmazem%type,
    p_idUsuario                 usuario.idusuario%type,
    p_idTransportadora          entidade.identidade%type
  ) is
  begin
    delete from gtt_itemordemtransfsaida;
  
    for c in (select i.id, i.idordemtransferenciasaida, i.idproduto,
                     sum(nvl(i.qtdesolicitada, 0) - nvl(i.qtdecancelada, 0) -
                          nvl(i.qtdereservada, 0)) qtdeDisponivel
                from ordemtransferenciasaidaitem i
               where i.idordemtransferenciasaida =
                     p_idOrdemTransferenciaSaida
               group by i.id, i.idordemtransferenciasaida, i.idproduto
              having sum(nvl(i.qtdesolicitada, 0) - nvl(i.qtdecancelada, 0) - nvl(i.qtdereservada, 0)) > 0)
    loop
      insert into gtt_itemordemtransfsaida
        (idordemtranssaida, idordemtranssaidaitem, idproduto, qtdeunitaria)
      values
        (c.idordemtransferenciasaida, c.id, c.idproduto, c.qtdedisponivel);
    end loop;
  
    pk_ordemtransferenciasaida.criarPedidoOrdemTransSaida(p_idArmazem,
                                                          p_idUsuario,
                                                          p_idTransportadora);
  
  end criarPedidTotalOrdemTransSaida;

  procedure removerItensORSNFDet
  (
    p_idordemtransferenciaitem ordemtransferenciasaidaitem.id%type,
    p_idnfdet                  nfdet.idnfdet%type
  ) is
    v_msg    t_message;
    v_status ordemtransferencia.status%type;
  
  begin
  
    select o.status
      into v_status
      from ordemtransferenciasaida o, ordemtransferenciasaidaitem oi
     where o.id = oi.idordemtransferenciasaida
       and oi.id = p_idordemtransferenciaitem;
  
    if (v_status <> C_OTS_STATUS_PENDENTE) then
      v_msg := t_message('Não foi possível desvincular a Nota Fiscal em Ordem de Transferência de Saída com status diferente de Pendente.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_nfDet in (select nvl(td.qtdeunitaria, 0) Qtde
                      from ordemtransfsaidaitemnfdet td
                     where td.idnfdet = p_idnfdet
                       and td.idordemtransfsaidaitem =
                           p_idordemtransferenciaitem)
    loop
      update ordemtransferenciasaidaitem g
         set g.qtdereservada =
             (nvl(g.qtdereservada, 0) - c_nfDet.Qtde)
       where g.id = p_idordemTransferenciaitem;
    end loop;
  
    delete from ordemtransfsaidaitemnfdet t
     where t.idordemtransfsaidaitem = p_idordemTransferenciaitem
       and t.idnfdet = p_idnfdet;
  end removerItensORSNFDet;

  procedure cancelarItemOrdemTransSaida
  (
    p_idArmazem     armazem.idarmazem%type,
    p_idUsuario     usuario.idusuario%type,
    p_telaFinalizar number := 0
  ) is
    r_ordemtransferenciasaida ordemtransferenciasaida%rowtype;
    v_ordemtransfcancelada    ordemtransfcancelada.id%type;
    v_msg                     t_message;
  
    procedure validarCancelOrdemTransfSaida
    (
      p_idordemtranssaidaitem      ordemtransferenciasaidaitem.id%type,
      p_quantidadeUnitCancelamento number
    ) is
      r_otsItem            ordemtransferenciasaidaitem%rowtype;
      v_qtdedisponivelitem number;
    begin
      begin
        select i.*
          into r_otsItem
          from ordemtransferenciasaidaitem i
         where i.id = p_idordemtranssaidaitem
           for update;
      exception
        when no_data_found then
          v_msg := t_message('Item {0} da Ordem de Transferência de Saída não encontrado.');
          v_msg.addparam(p_idordemtranssaidaitem);
          raise_application_error(-20000, v_msg.formatmessage);
      end;
    
      if (nvl(p_quantidadeUnitCancelamento, 0) <= 0) then
        v_msg := t_message('Item {0} da Ordem de Transferência de Saída possui uma quantidade invalida para o cancelamento.');
        v_msg.addparam(p_idordemtranssaidaitem);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
      v_qtdedisponivelitem := (nvl(r_otsItem.qtdesolicitada, 0) -
                              nvl(r_otsItem.qtdecancelada, 0) -
                              nvl(r_otsItem.qtdereservada, 0));
    
      if (v_qtdedisponivelitem < p_quantidadeUnitCancelamento) then
        v_msg := t_message('Ordem de transferência de saída id {0} não pode ser cancelada. IdProduto {1} possui {2} de quantidade disponível e no cancelamento esta sendo informado a quantidade {3}.');
        v_msg.addparam(r_otsItem.Idordemtransferenciasaida);
        v_msg.addparam(r_otsItem.idproduto);
        v_msg.addparam(v_qtdedisponivelitem);
        v_msg.addparam(p_quantidadeUnitCancelamento);
        raise_application_error(-20000, v_msg.formatmessage);
      end if;
    
    end validarCancelOrdemTransfSaida;
  
  begin
    validarParametrosOTS(p_idArmazem, p_idUsuario);
  
    for c_ots in (select ots.idordemtranssaida
                    from gtt_itemordemtransfsaida ots
                   group by ots.idordemtranssaida)
    loop
      validarOrdemTransfSaida(c_ots.idordemtranssaida,
                              r_ordemtransferenciasaida);
    
      v_ordemtransfcancelada := seq_ordemtransfcancelada.nextval;
    
      for c_ots_item in (select item.*
                           from gtt_itemordemtransfsaida item
                          where item.idordemtranssaida =
                                c_ots.idordemtranssaida)
      loop
      
        validarCancelOrdemTransfSaida(c_ots_item.idordemtranssaidaitem,
                                      c_ots_item.qtdeunitaria);
      
        update ordemtransferenciasaidaitem i
           set i.qtdecancelada = nvl(i.qtdecancelada, 0) +
                                 nvl(c_ots_item.qtdeunitaria, 0)
         where i.id = c_ots_item.idordemtranssaidaitem;
      
        insert into ordemtransfcancelada
          (id, idordemtransfsaida, idordemtransfsaidaitem, idproduto,
           qtdeunitariacancelada, idusuario, datacancelamento)
        values
          (v_ordemtransfcancelada, c_ots_item.idordemtranssaida,
           c_ots_item.idordemtranssaidaitem, c_ots_item.idproduto,
           c_ots_item.qtdeunitaria, p_idusuario, sysdate);
      
        pk_utilities.GeraLog(p_idusuario,
                             'Cancelou o item id ' ||
                              c_ots_item.idordemtranssaidaitem ||
                              ' da Ordem de Transferência de Saída id ' ||
                              c_ots_item.idordemtranssaida || ' qtde ' ||
                              c_ots_item.qtdeunitaria || ' idproduto ' ||
                              c_ots_item.idproduto,
                             c_ots_item.idordemtranssaida, 'OT');
      
      end loop;
    
      pk_ordemtransferenciasaida.ajustarStatusOrdemTransSaida(c_ots.idordemtranssaida,
                                                              p_telaFinalizar);
    
      pk_integracao.expTransferCancelNotification(v_ordemtransfcancelada);
    
    end loop;
  
  end cancelarItemOrdemTransSaida;

  procedure finalizarTransSaida
  (
    p_idOrdemTransferenciaSaida ordemtransferenciasaida.id%type,
    p_idArmazem                 armazem.idarmazem%type,
    p_idUsuario                 usuario.idusuario%type
  ) is
    v_existePendente number := 0;
  begin
    delete from gtt_itemordemtransfsaida;
  
    for c in (select i.id, i.idordemtransferenciasaida, i.idproduto,
                     sum(nvl(i.qtdesolicitada, 0) - nvl(i.qtdecancelada, 0) -
                          nvl(i.qtdereservada, 0)) qtdeDisponivel
                from ordemtransferenciasaidaitem i
               where i.idordemtransferenciasaida =
                     p_idOrdemTransferenciaSaida
               group by i.id, i.idordemtransferenciasaida, i.idproduto
              having sum(nvl(i.qtdesolicitada, 0) - nvl(i.qtdecancelada, 0) - nvl(i.qtdereservada, 0)) > 0)
    loop
      v_existePendente := 1;
    
      insert into gtt_itemordemtransfsaida
        (idordemtranssaida, idordemtranssaidaitem, idproduto, qtdeunitaria)
      values
        (c.idordemtransferenciasaida, c.id, c.idproduto, c.qtdedisponivel);
    end loop;
  
    if (v_existePendente = 0) then
      pk_ordemtransferenciasaida.ajustarStatusOrdemTransSaida(p_idOrdemTransferenciaSaida,
                                                              1);
    else
      pk_ordemtransferenciasaida.cancelarItemOrdemTransSaida(p_idArmazem,
                                                             p_idUsuario, 1);
    
    end if;
  
  end finalizarTransSaida;

  procedure expedirOrdemTransSaida(p_idnotafiscal notafiscal.idnotafiscal%type) is
    v_expediu            number := 0;
    v_existeCorte        number := 0;
    v_idordemtransfsaida number;
    v_idArmazem          armazem.idarmazem%type;
  begin
  
    begin
      select nf.idordemtransfsaida, nf.idarmazem
        into v_idordemtransfsaida, v_idArmazem
        from notafiscal nf
       where nf.idnotafiscal = p_idnotafiscal;
    exception
      when no_data_found then
        v_idordemtransfsaida := null;
    end;
  
    if v_idordemtransfsaida is null then
      return;
    end if;
  
    for c_reg in (select otd.idordemtransfsaidaitem,
                         sum(nfd.qtdeatendida * eb.fatorconversao) qtdeatendida
                    from nfdet nfd, notafiscal nf,
                         ordemtransfsaidaitemnfdet otd, embalagem eb,
                         ordemtransferenciasaidaitem i
                   where 1 = 1
                     and nf.idnotafiscal = nfd.nf
                     and otd.idnfdet = nfd.idnfdet
                     and i.id = otd.idordemtransfsaidaitem
                     and nf.idnotafiscal = p_idnotafiscal
                     and nvl(nfd.qtdeatendida, 0) > 0
                     and nf.statusnf = 'P'
                     and nfd.barra = eb.barra
                     and nfd.idproduto = eb.idproduto
                   group by otd.idordemtransfsaidaitem)
    loop
      v_expediu := 1;
    
      update ordemtransferenciasaidaitem ot
         set ot.qtdeexpedida = nvl(ot.qtdeexpedida, 0) +
                               nvl(c_reg.qtdeatendida, 0)
       where ot.id = c_reg.idordemtransfsaidaitem;
    
    end loop;
  
    delete from gtt_itemordemtransfsaida;
  
    for c_reg in (select i.idproduto, i.idordemtransferenciasaida,
                         otd.idordemtransfsaidaitem,
                         sum((nfd.qtde - nfd.qtdeatendida) *
                              eb.fatorconversao) qtdecorte
                    from nfdet nfd, notafiscal nf,
                         ordemtransfsaidaitemnfdet otd, embalagem eb,
                         ordemtransferenciasaidaitem i
                   where 1 = 1
                     and nf.idnotafiscal = nfd.nf
                     and otd.idnfdet = nfd.idnfdet
                     and i.id = otd.idordemtransfsaidaitem
                     and nf.idnotafiscal = p_idnotafiscal
                     and nvl(nfd.qtdeatendida, 0) > 0
                     and nvl(nfd.qtde, 0) > nvl(nfd.qtdeatendida, 0)
                     and nf.statusnf = 'P'
                     and nfd.barra = eb.barra
                     and nfd.idproduto = eb.idproduto
                   group by i.idproduto, i.idordemtransferenciasaida,
                            otd.idordemtransfsaidaitem)
    loop
      v_existeCorte := 1;
    
      insert into gtt_itemordemtransfsaida
        (idordemtranssaida, idordemtranssaidaitem, idproduto, qtdeunitaria)
      values
        (c_reg.idordemtransferenciasaida, c_reg.idordemtransfsaidaitem,
         c_reg.idproduto, c_reg.qtdecorte);
    
      update ordemtransferenciasaidaitem iots
         set iots.qtdereservada = iots.qtdereservada - c_reg.qtdecorte
       where iots.id = c_reg.idordemtransfsaidaitem;
    
    end loop;
  
    if (v_existeCorte = 1) then
      pk_ordemtransferenciasaida.cancelarItemOrdemTransSaida(v_idArmazem, 0);
    end if;
  
    if v_expediu = 1 then
      pk_ordemtransferenciasaida.ajustarStatusOrdemTransSaida(v_idordemtransfsaida);
    end if;
  
  end expedirOrdemTransSaida;

  procedure ajustarStatusOrdemTransSaida
  (
    p_idordemtransfsaida in ordemtransferenciasaida.id%type,
    p_telaFinalizar      in number default 0
  ) is
    v_msg           t_message;
    v_finalizadoOTS number := 0;
  begin
  
    for reg in (select sum(a.qtdesolicitada) qtdesolicitada,
                       sum(a.qtdecancelada) qtdecancelada,
                       sum(a.qtdeexpedida) qtdeexpedida
                  from (select i.qtdesolicitada, i.qtdecancelada,
                                i.qtdeexpedida
                           from ordemtransferenciasaidaitem i,
                                ordemtransferenciasaida ots
                          where 1 = 1
                            and ots.id = i.idordemtransferenciasaida
                            and ots.status = C_OTS_STATUS_PENDENTE
                            and i.idordemtransferenciasaida =
                                p_idordemtransfsaida) a)
    loop
      if (reg.qtdesolicitada = reg.qtdecancelada + reg.qtdeexpedida) then
      
        v_finalizadoOTS := 1;
      
        if (reg.qtdesolicitada = reg.qtdecancelada) then
          update ordemtransferenciasaida ot
             set ot.status           = C_OTS_STATUS_CANCELADO,
                 ot.datacancelamento = sysdate
           where ot.id = p_idordemtransfsaida;
        
        elsif (reg.qtdecancelada > 0) then
          update ordemtransferenciasaida ot
             set ot.status          = C_OTS_STATUS_FIN_CANCELADO,
                 ot.datafinalizacao = sysdate
           where ot.id = p_idordemtransfsaida;
        
        else
          update ordemtransferenciasaida ot
             set ot.status          = C_OTS_STATUS_FINALIZADO,
                 ot.datafinalizacao = sysdate
           where ot.id = p_idordemtransfsaida;
        
        end if;
      end if;
    end loop;
  
    if (v_finalizadoOTS = 0 and nvl(p_telaFinalizar, 0) = 1) then
      v_msg := t_message('Ordem de transferência de saída id {0} não pode ser cancelada. Ainda não foi totalmente expedida.');
      v_msg.addparam(p_idordemtransfsaida);
      raise_application_error(-20000, v_msg.formatmessage);
    end if;
  
  end ajustarStatusOrdemTransSaida;

end pk_ordemtransferenciasaida;
/

