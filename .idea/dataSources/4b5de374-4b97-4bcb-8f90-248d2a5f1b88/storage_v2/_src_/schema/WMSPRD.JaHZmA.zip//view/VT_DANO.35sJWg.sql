create view VT_DANO as
select iddano, descr descricao
  from dano
/

