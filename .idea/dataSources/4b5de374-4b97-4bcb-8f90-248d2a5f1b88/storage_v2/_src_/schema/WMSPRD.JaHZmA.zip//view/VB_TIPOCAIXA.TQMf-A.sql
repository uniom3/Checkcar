create view VB_TIPOCAIXA as
select t.idtipocaixavolume H$TABLEID, t.descr caixa, t.idtipocaixavolume,
       t.codintegracao
  from tipocaixavolume t
 where t.tipo = 0
   and t.idproduto is null
   and t.ativo = 1
 order by t.descr
/

