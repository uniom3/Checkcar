create view VI_INT_ENVIO_AM_RTI as
select agrupador id, vendorpartyid, vendorpartytype, warehouselocationid,
       returnrequestid, returnshipmentid, billofladingid, carriername,
       shipmenttrackingid
  from int_envio_am_rti
/

