create view VB_PACKINGS as
select l.idlocal, to_char(l.id) idEndPacking, l.idarmazem h$idarmazem
  from packing p, local l
 where l.id = p.idendereco
   and l.ativo = 'S'
/

