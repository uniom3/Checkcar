create view VI_INT_ENVRETARMMOVSAIDET as
select id, '#' I, '"' || cfop || '"' cfop,
       '"' || valorcontabil || '"' valorcontabil,
       '"' || baseicms || '"' baseicms,
       '"' || aliquotaicms || '"' aliquotaicms,
       '"' || valoricms || '"' valoricms,
       '"' || isentasicms || '"' isentasicms,
       '"' || outrasicms || '"' outrasicms,
       '"' || baseicmssubstituido || '"' baseicmssubstituido,
       '"' || icmssubstituido || '"' icmssubstituido,
       '"' || filialdefault || '"' filialdefault,
       '"' || numeroitens || '"' numeroitens,
       '"' || numdocumento || '"' numdocumento, '"' || pis || '"' pis,
       '"' || cofins || '"' cofins, '"' || st || '"' st,
       '"' || origem || '"' origem
  from int_envioretmovarm_saida_det
/

