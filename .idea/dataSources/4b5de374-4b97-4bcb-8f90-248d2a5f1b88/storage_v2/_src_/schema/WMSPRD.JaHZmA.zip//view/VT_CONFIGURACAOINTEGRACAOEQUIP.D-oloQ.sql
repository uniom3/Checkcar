create view VT_CONFIGURACAOINTEGRACAOEQUIP as
select cie.idconfintequip, cie.idarmazem h$idarmazem, cie.iddepositante,
       ent.razaosocial as depositante, cie.nome, cie.descricao, cie.url,
       cie.chave, cie.ativo,
       (select count(*)
           from esvaziamentohopper eh
          where idconfintequip = cie.idconfintequip) as h$existeesvaziamento
  from configuracaointegracaoequip cie, entidade ent
 where ent.identidade = cie.iddepositante
 order by cie.idarmazem, cie.nome
/

