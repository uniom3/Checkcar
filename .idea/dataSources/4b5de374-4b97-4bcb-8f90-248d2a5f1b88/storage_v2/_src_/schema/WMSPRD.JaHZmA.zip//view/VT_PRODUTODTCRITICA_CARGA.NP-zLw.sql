create view VT_PRODUTODTCRITICA_CARGA as
select rp.idromaneio, rp.codigointerno codromaneio,
       d.razaosocial depositante, p.codigointerno codproduto,
       p.descr produto, po.idlocal, po.idlote, e.barra, lo.loteindustria,
       trunc(lo.dtfabricacao) dtfabricacao,
       trunc(lo.dtvencimento) dtvencimento, lo.dtshelflife, lo.dtcritica,
       (po.qtde * e.fatorconversao) qtdeembalagem, e.descrreduzido embalagem,
       e.fatorconversao, po.qtde qtdeunitaria, p.prazocritico,
       f.razaosocial familia, l.idproduto, l.iddepositante
  from romaneiopai rp, paleteOndaNF po, lote l, entidade d, produto p,
       embalagem e, loteonda lo, entidade f
 where rp.idromaneio = po.idonda
   and po.idlote = l.idlote
   and l.iddepositante = d.identidade
   and l.idproduto = p.idproduto
   and l.idproduto = e.idproduto
   and l.barra = e.barra
   and l.idlote = lo.idlote
   and rp.idromaneio = lo.idonda
   and f.identidade = p.idfamilia
/

