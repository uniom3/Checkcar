create view VT_CONTEUDOESCANINHO as
select sum(c.quantidade) qtde, p.codigointerno, p.descr produto,
                pk_produto.ret_codbarra(p.idproduto, 1) barraunitaria,
                c.idescaninho h$idescaninho, pd.loteuniconovolume h$loteuniconovolume
           from ConteudoEscaninho c, movimentacao m, lote lt, produto p, produtodepositante pd
          where m.id = c.idmovimentacao
            and lt.idlote = m.idlote
            and p.idproduto = lt.idproduto
            and pd.idproduto = lt.idproduto
            and pd.identidade = lt.iddepositante
          group by p.idproduto, p.codigointerno, p.descr, c.idescaninho, pd.loteuniconovolume
/

