create view VT_DEFINICAOCONTRATOBLOCO as
select n.datacadastro, ed.razaosocial depositante, ed.cgc cnpjdepositante,
       ed.inscrestadual iedepositante, c.numero numero_contrato,
       c.descricao descricao_contrato, n.codigointerno documento,
       n.sequencia serie,
       decode(oper.tipooper, 'G', 'GMB', 'Nota Fiscal') tipodocumento,
       ec.razaosocial entidadepagadora, ec.cgc cnpjpagadora,
       ec.inscrestadual iepagadora, n.dataprocessamento,
       ed.identidade iddepositante, ed.identidade identidadepagadora,
       n.idnotafiscal, n.idprenf, c.id h$idcontrato, n.idarmazem h$idarmazem
  from notafiscal n, entidade ed, operacao oper, contrato c, entidade ec
 where n.tipo = 'E'
   and ed.identidade = n.iddepositante
   and oper.idoperacao = n.idoperacao
   and (oper.tipooper not in ('TA', 'RG', 'TG') or oper.tipooper is null)
   and c.id(+) = n.idcontrato
   and ec.identidade(+) = c.identidadepagadora
   and (n.idlotenf is null or not exists
        (select 1
           from lotenf lnf
          where lnf.idlotenf = n.idlotenf
            and ((case
                  when lnf.mapaaloc = 'E' then
                   'N'
                  when lnf.mapaaloc is null then
                   'N'
                  else
                   lnf.mapaaloc
                end = 'S') or (lnf.cadloteaut = 'S'))))
/

