create view VI_INT_ENVIO_EFD_C100 as
select distinct 'C100' reg, decode(nf.tipo, 'E', 0, 1) ind_oper,
                decode(nf.tipo, 'E', 1, 0) ind_emit,
                decode(nf.tipo, 'E', emit.codigointerno, dest.codigointerno) cod_part,
                '55' cod_mod, '00' cod_sit,
                nvl(substr(nf.sequencia, 0, 3), ' ') ser,
                nf.codigointerno num_doc,
                nvl(nf.chaveacessonfe, ' ') chv_nfe,
                to_char(nf.dataemissao, 'ddmmyyyy') dt_doc,
                case
                   when nvl(nr.datacobertura, nf.datacadastro) <
                        nf.dataemissao then
                    to_char(nf.dataemissao, 'ddmmyyyy')
                   else
                    to_char(nvl(nr.datacobertura, nf.datacadastro), 'ddmmyyyy')
                 end dt_e_s,
                pk_utilities.getNumeroFormatadoEFD(nf.totalgeral) vl_doc,
                2 ind_pgto, nf.valortotaldescontos vl_desc, 0 vl_abat_nt,
                pk_utilities.getNumeroFormatadoEFD(nf.totalprodutos) vl_merc,
                nvl(nf.freteporconta, 2) ind_frt,
                nvl(nf.valorfretepesovol, 0) vl_frt,
                nvl(nf.seguro, 0) vl_seg,
                nvl(nf.despesasacessorias, 0) vl_out_da,
                nvl(nf.baseicms, 0) vl_bc_icms, nvl(nf.valoricms, 0) vl_icms,
                nvl(nf.basesubstituicao, 0) vl_bc_icms_st,
                nvl(nf.valorsubstituicao, 0) vl_icms_st,
                nvl(nf.ipi, 0) vl_ipi, nvl(nf.pis, 0) vl_pis,
                nvl(nf.cofins, 0) vl_cofins, 0 vl_pis_st, 0 vl_cofins_st,
                nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento,
                nf.idnotafiscal
  from notafiscal nf, entidade emit, entidade dest, depositante dp,
       regime re, operacao o, nfremarmazenagem nr
 where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
       nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
   and dest.identidade = nf.destinatario
   and emit.identidade = nf.remetente
   and o.idoperacao = nf.idoperacao
   and decode(nf.statusnf, 'P', 1, 0) = 1
   and decode(nf.retornoreentrega, 'N', 1, 0) = 1
   and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and decode(re.classificacao, 'A', 1, 0) = 1
   and o.idoperacao = nf.idoperacao
   and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
   and nf.totalgeral > 0
   and nr.idnfremessa(+) = nf.idnotafiscal
 group by 'C100', decode(nf.tipo, 'E', 0, 1), decode(nf.tipo, 'E', 1, 0),
          decode(nf.tipo, 'E', emit.codigointerno, dest.codigointerno), '55',
          '00', nvl(substr(nf.sequencia, 0, 3), ' '), nf.codigointerno,
          nf.chaveacessonfe,
          pk_utilities.getNumeroFormatadoEFD(nf.totalgeral), 2,
          nf.valortotaldescontos,
          pk_utilities.getNumeroFormatadoEFD(nf.totalprodutos),
          nf.freteporconta, nf.valorfretepesovol, nf.seguro,
          nf.despesasacessorias, nf.baseicms, nf.valoricms,
          nf.basesubstituicao, nf.valorsubstituicao, nf.ipi, nf.pis,
          nf.cofins, 0, 0, nf.idarmazem,
          trunc(nvl(nr.datacobertura, nf.datacadastro)), nf.idnotafiscal,
          nf.dataemissao,
          to_char(nvl(nr.datacobertura, nf.datacadastro), 'ddmmyyyy'),
          case
            when nvl(nr.datacobertura, nf.datacadastro) < nf.dataemissao then
             to_char(nf.dataemissao, 'ddmmyyyy')
            else
             to_char(nvl(nr.datacobertura, nf.datacadastro), 'ddmmyyyy')
          end
 order by nf.codigointerno asc
/

