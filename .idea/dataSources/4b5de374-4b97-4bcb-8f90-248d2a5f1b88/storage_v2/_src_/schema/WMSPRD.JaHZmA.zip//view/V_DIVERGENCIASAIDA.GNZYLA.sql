create view V_DIVERGENCIASAIDA as
select "id","Status","Data","Id Produto","Produto","Barra","Fator Conversão","Local","Tipo Local","Qtde Encontrada","Qtde Encontrada Cx","Qtde no dia","Qtde separar","Qtde Divergente","Usuário","Tipo","Remanejamento","Nota Fiscal","Depositante","Onda/Romaneio","Id Onda/Romaneio","Usuário Resolução","Data Resolução","Qtde Atual","IDARMAZEM"
  from (select ds.id as "id", ds.status as "Status", ds.data as "Data",
                emb.idproduto as "Id Produto", p.DESCR as "Produto",
                emb.barra as "Barra", emb.fatorConversao as "Fator Conversão",
                l.IDLOCAL as "Local",
                decode(l.tipo, 0, 'Picking', 1, 'Pulmão Blocado', 2,
                        'Pulmão Paletizado', 3, 'Colméia', 4, 'Doca', 5,
                        'Auditoria', 6, 'Rua Expedição', 7, 'Stage', 8,
                        'Packing', 9, 'Serviço', 10, 'Conferência') as "Tipo Local",
                ds.QTDE as "Qtde Encontrada",
                ds.QTDE / emb.fatorConversao as "Qtde Encontrada Cx",
                ds.qtdeEstoque as "Qtde no dia",
                ds.qtdeSeparar as "Qtde separar",
                ds.qtdeSeparar - ds.QTDE as "Qtde Divergente",
                u.NOMEUSUARIO as "Usuário",
                decode(ds.tipo, 0, 'Onda', 1, 'Romaneio', 2, 'Remanejamento',
                        3, 'Reabastecimento') as "Tipo",
                ds.idRemanejamento as "Remanejamento",
                nf.CODIGOINTERNO as "Nota Fiscal",
                ent.RAZAOSOCIAL as "Depositante",
                rp.codigoInterno as "Onda/Romaneio",
                ds.IDONDA as "Id Onda/Romaneio",
                usu.NOMEUSUARIO as "Usuário Resolução",
                ds.dataResolucao as "Data Resolução",
                (select sum(ll.ESTOQUE)
                    from LOTELOCAL ll, LOCAL llocal, LOTE lt, EMBALAGEM embl,
                         DEPOSITANTE dep
                   where ll.IDENDERECO = llocal.id
                     and ll.IDLOTE = lt.IDLOTE
                     and lt.idproduto = embl.idproduto
                     and lt.barra = embl.barra
                     and lt.IDDEPOSITANTE = dep.IDENTIDADE
                     and ll.IDENDERECO = ds.IDLOCAL
                     and lt.idproduto = ds.idproduto
                     and lt.barra = ds.barra
                     and lt.IDDEPOSITANTE = ds.IDDEPOSITANTE) as "Qtde Atual",  l.IDARMAZEM
           from DIVERGENCIASAIDA ds, NOTAFISCAL nf, NOTAFISCALCARGA nfc,
                NFROMANEIO nfr, USUARIO usu, ROMANEIOPAI rp, DEPOSITANTE depo,
                ENTIDADE ent, V_ENDERECO v_end, EMBALAGEM emb, PRODUTO p,
                LOCAL l, USUARIO u
          where ds.IDNOTAFISCAL = nf.IDNOTAFISCAL(+)
            and nf.IDNOTAFISCAL = nfc.IDNOTAFISCAL(+)
            and nf.IDNOTAFISCAL = nfr.IDNOTAFISCAL(+)
            and ds.IDUSUARIORESOLUCAO = usu.IDUSUARIO(+)
            and ds.IDONDA = rp.IDROMANEIO(+)
            and ds.IDDEPOSITANTE = depo.IDENTIDADE
            and depo.IDENTIDADE = ent.IDENTIDADE
            and ent.IDENTIDADE = v_end.IDENTIDADE(+)
            and ds.idproduto = emb.idproduto
            and ds.barra = emb.barra
            and emb.idproduto = p.IDPRODUTO
            and ds.IDLOCAL = l.id
            and ds.IDUSUARIO = u.IDUSUARIO)
/

