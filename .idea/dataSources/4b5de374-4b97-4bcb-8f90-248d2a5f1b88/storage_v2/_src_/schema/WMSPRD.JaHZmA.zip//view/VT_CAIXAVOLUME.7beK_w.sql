create view VT_CAIXAVOLUME as
select t.idtipocaixavolume, t.descr descricao,
       DECODE(T.TIPO, 0, 'PRÓPRIA', 1, 'RETORNÁVEL', 2, 'PACOTE', 3,
               'REUTILIZÁVEL') tipo, t.ativo, t.disponivel, t.presente,
       t.datacadastro dtcadastro,
       t.barra,
       t.altura, t.largura, t.comprimento, t.peso, t.valor,
       P.CODIGOINTERNO CODPRODUTO, P.CODREFERENCIA, P.DESCR PRODUTO,
       t.barrainterna, t.retornavel, t.idproduto, t.codintegracao, t.emusosistematerceiro,t.tipo h$tipo
  FROM TIPOCAIXAVOLUME T, PRODUTO P
 where p.idproduto(+) = t.idproduto
/

