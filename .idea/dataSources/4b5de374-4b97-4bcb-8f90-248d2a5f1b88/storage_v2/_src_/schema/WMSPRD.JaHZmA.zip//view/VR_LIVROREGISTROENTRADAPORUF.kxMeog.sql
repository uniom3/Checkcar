create view VR_LIVROREGISTROENTRADAPORUF as
select lv.idlivrofiscal, initcap(e.razaosocial) firma, e.inscrestadual,
       e.cgc cnpj, lv.numero numerolivro, lv.ultimapagina,
       lv.datainicio || ' a ' || lv.datatermino periodo, il.uf,
       sum(il.valorcontabil) valorcontabil,
       sum(il.basecalculoicms) basecalculoicms,
       sum(il.basecalculoipi) basecalculoipi,
       sum(il.impostoicms) impostoicms,
       sum(il.impostoipi) impostoipi,
       sum(il.valorcontabil - il.basecalculoicms) isentasicms,
       sum(il.valorcontabil - il.basecalculoipi) isentasipi,
       sum(decode(il.codigoicms, 3, il.impostoicms, 0)) outrasicms,
       sum(decode(il.codigoipi, 3, il.impostoipi, 0)) outrasipi, il.dtentrada
  from livrofiscal lv, itemlivrofiscalentrada il, entidade e
 where il.idlivrofiscal = lv.idlivrofiscal
   and e.identidade = lv.identidade
 group by lv.idlivrofiscal, initcap(e.razaosocial), e.inscrestadual,
          e.cgc, lv.numero, lv.ultimapagina,
          lv.datainicio || ' a ' || lv.datatermino, il.uf, il.dtentrada
/

