create view VT_LOGEXPURGO as
select le.id, le.idexpurgo, e.tabelaprincipal tabela, le.datahoraini,
       le.datahorafim, le.status, le.mensagem, le.qtderegdel, le.tipoexec
  from logexpurgo le, expurgo e
 where e.id = le.idexpurgo
 order by id
/

