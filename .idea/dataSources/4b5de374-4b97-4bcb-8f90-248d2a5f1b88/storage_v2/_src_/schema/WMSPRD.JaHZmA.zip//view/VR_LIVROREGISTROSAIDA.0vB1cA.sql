create view VR_LIVROREGISTROSAIDA as
select lv.idlivrofiscal, initcap(e.razaosocial) firma, e.inscrestadual,
       e.cgc cnpj, lv.numero numerolivro, lv.ultimapagina,
       lv.datainicio || ' a ' || lv.datatermino periodo, il.dtsaida,
       il.especie, il.serie, il.numero, il.dtdocumento, il.uf,
       il.valorcontabil, il.contabil, il.fiscal, il.basecalculoicms,
       il.basecalculoipi, il.aliquotaicms, il.aliquotaipi, il.impostoicms,
       il.impostoipi, il.isentoicms, il.isentoipi, il.outrasicms,
       il.outrasipi, lower(il.observacoes) observacoes,
       case
          when (trunc(il.dtsaida, 'month') + 9) >= trunc(il.dtsaida) then
           1
          when trunc(il.dtsaida) > (trunc(il.dtsaida, 'month') + 9)
               and trunc(il.dtsaida) <= (trunc(il.dtsaida, 'month') + 19) then
           2
          else
           3
        end decendio
  from livrofiscal lv, itemlivrofiscalsaida il, entidade e
 where il.idlivrofiscal = lv.idlivrofiscal
   and e.identidade = lv.identidade
/

