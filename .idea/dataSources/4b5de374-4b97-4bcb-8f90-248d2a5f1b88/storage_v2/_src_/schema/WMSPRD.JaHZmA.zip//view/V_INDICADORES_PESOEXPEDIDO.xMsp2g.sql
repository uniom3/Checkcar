create view V_INDICADORES_PESOEXPEDIDO as
select 12 ordem, 'PESO (TON) EXPEDIDO' titulo,
       'Peso total em toneladas expedidos por dia. Ultimos 7 dias' descricao,
       to_char(data, 'DD/MM/YYYY') dado, total valor, 0 tipo, null unidade,
       null inivermelho, null fimvermelho, null iniamarelo, null fimamarelo,
       null iniverde, null fimverde, null valorcockpit, idarmazem, data
  from (select trunc(r.datageracao) data,
                round(sum(nfd.qtdeatendida * e.pesobruto) / 1000000, 2) total,
                r.idarmazem
           from romaneiopai r, nfromaneio nfr, notafiscal nf, nfdet nfd,
                embalagem e
          where r.datageracao >= sysdate - 7
            and r.statusonda <> 5
            and nfr.idromaneio = r.idromaneio
            and nf.idnotafiscal = nfr.idnotafiscal
            and nfd.nf = nf.idnotafiscal
            and e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
          group by trunc(r.datageracao), r.idarmazem)
/

