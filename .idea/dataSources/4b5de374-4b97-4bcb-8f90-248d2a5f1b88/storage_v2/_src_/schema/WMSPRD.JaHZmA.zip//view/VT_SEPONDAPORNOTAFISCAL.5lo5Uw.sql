create view VT_SEPONDAPORNOTAFISCAL as
select distinct m.idonda, rp.codigointerno codromaneio, nf.idnotafiscal,
                nf.codigointerno notafiscal, nf.numpedidofornecedor pedido,
                m.idusuario, u.nomeusuario, ro.descr regiaoorigem,
                rd.descr regiaodestino, ro.idregiao idregiaoorigem,
                rd.idregiao idregiaodestino
  from movimentacao m, romaneiopai rp, notafiscal nf, local lo,
       regiaoarmazenagem ro, local ld, regiaoarmazenagem rd, usuario u
 where m.status in (0, 1)
   and rp.idromaneio = m.idonda
   and u.idusuario(+) = m.idusuario
   and nf.idnotafiscal = m.idnotafiscal
   and ld.id = m.idlocaldestino
   and lo.id = m.idlocalorigem
   and ro.idregiao = lo.idregiao
   and rd.idregiao = ld.idregiao
   and rd.tipo = 6
/

