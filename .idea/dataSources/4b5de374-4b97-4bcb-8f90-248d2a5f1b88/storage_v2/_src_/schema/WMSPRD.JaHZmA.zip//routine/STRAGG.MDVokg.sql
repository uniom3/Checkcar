create FUNCTION stragg(input VARCHAR2) RETURN varchar2
  PARALLEL_ENABLE
  AGGREGATE USING string_agg_type;
/

