create view VT_CONTENTORRECEBIMENTO as
select c.idcontentorrecebimento,
       decode(c.situacao, 0, 'Não Utilizada', 1, 'Utilizada', 2, 'Cancelada') situacao,
       c.datageracao, usuariogeracao.nomeusuario usuariogeracao,
       c.datautilizacao, usuarioutilizacao.nomeusuario usuarioutilizacao,
       c.idlotenf, pk_recebimento.getNrosBarraContentora(c.barra) codbarracontentor, 
       vr.codbarra codbarravolume,c.idarmazem h$idarmazem,
       c.situacao h$situacao, c.barra h$barra
  from CONTENTORRECEBIMENTO c, USUARIO usuariogeracao, volumeromaneio vr,
       USUARIO usuarioutilizacao
 where usuariogeracao.idusuario = c.idusuariogeracao
   and usuarioutilizacao.idusuario = c.idusuarioutilizacao
   and vr.idvolumeromaneio(+) = c.idvolumeromaneio
/

