create view VT_VINCULARNOTAFISCALOR as
select decode(nf.idlotenf, null, 0, 1) marcado, nf.idnotafiscal,
       nf.codigointerno notafiscal, nf.sequencia serie, nf.chaveacessonfe,
       nf.numpedidofornecedor numpedido,
       to_char(nf.dataemissao, 'dd/mm/yyyy') dtemissao,
       decode(nf.tipo, 'E', 'ENTRADA', 'SAIDA') tipo, o.idcfop cfop,
       dep.razaosocial depositante, e.razaosocial remetente,
       d.razaosocial destinatario, nf.idlotenf h$idlotenf,
       nf.iddepositante h$iddepositante, nf.idarmazem h$idarmazem,
       nf.remetente h$idremetente, nf.tipo h$tiponf, nf.statusnf h$statusnf,
       nf.devolucaototal h$devolucaototal, nf.reentrega h$reentrega,
       nf.ordemtransferencia,
       nf.idnotafiscalvinculada h$idnotafiscalvinculada,
       o.idoperacao h$idoperacao, nf.tipoentrada
  from notafiscal nf, entidade dep, entidade e, entidade d, operacao o
 where nvl(nf.sequencia, '0') not like 'AGCOB'
   and nvl(nf.sequencia, '0') not like '%INVENTARIO%'
   and nvl(nf.sequencia, '0') not like '%AJUSTE%'
   and (nf.movestoque = 'S' or (nf.movestoque = 'N' and o.tipooper = 'RT'))
   and dep.identidade = nf.iddepositante
   and e.identidade = nf.remetente
   and d.identidade = nf.destinatario
   and o.idoperacao = nf.idoperacao
   and not exists (select 1
          from notafiscal nv
         where nv.idnotafiscalvinculada = nf.idnotafiscal)
   and not exists (select 1
          from transferenciatitularidade tt
         where tt.idnotafiscalentrada = nf.idnotafiscal)
   and not exists
 (select 1
          from notafiscal n
         where n.idnotafiscal = nf.idnotafiscal
           and n.idtipopedido in
               (select cl.idtipopedido
                  from classificacaotipopedido cl
                 where cl.transferenciatitularidade = 1))
/

