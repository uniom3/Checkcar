create package PK_SEPONDA is

  C_REABASTECIMENTO_PENDENTE CONSTANT number := 0;
  C_ORIGEM_CONCLUIDO         CONSTANT number := 1;
  C_DESTINO_CONCLUIDO        CONSTANT number := 2;

  C_ATIVIDADE_PACKING_COLETOR CONSTANT number := 17;

  /*
  * Rotina responsavel por realizar a separação manual
  */
  function separacaoManual
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_bufferEsteiraOrigem  in number default null,
    p_bufferEsteiraDestino in number default null,
    p_idCaixaSeparacao     in number,
    p_mensagem             in out varchar2
    
  ) return number;

  procedure pausarSeparacao
  (
    p_idOnda          in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_idnotaFiscal    in number,
    p_bufferOrigem    in number,
    p_idRegiaoOrigem  in number,
    p_bufferDestino   in number,
    p_idRegiaoDestino in number
  );

  function getReabPendentePorLocal
  (
    p_idonda          in number,
    p_identificador   in number,
    p_idnotafiscal    in number,
    p_idendereco      in number,
    p_idregiaoorigem  in number,
    p_bufferorigem    in number,
    p_idregiaodestino in number,
    p_bufferdestino   in number
  ) return number;

  procedure validaReabPendente
  (
    p_idOnda     in number,
    p_idlote     in number,
    p_idEndereco in number
  );

  function finalizarSepOnda
  (
    p_idusuario       number,
    p_idonda          number,
    p_idregiaoorigem  number,
    p_bufferorigem    number,
    p_idregiaodestino number,
    p_bufferdestino   number,
    p_identificador   number,
    p_idnotafiscal    number
  ) return number;

  function agruparTarefaSeparacao
  (
    p_idusuario in number,
    p_idonda    in number
  ) return number;

  procedure trocarUsuarioSepOndaID
  (
    p_idOnda             in number,
    p_identificador      in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  );

  procedure trocarUsuarioSepOndaUSR
  (
    p_idOnda             in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  );

  procedure trocarUsuarioSepOndaNF
  (
    p_idOnda             in number,
    p_idnotafiscal       in number,
    p_idregiaoorigem     in number,
    p_idregiaodestino    in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  );

  procedure retirarUsuarioSepOndaNF
  (
    p_idOnda             in number,
    p_idnotafiscal       in number,
    p_idregiaoorigem     in number,
    p_idregiaodestino    in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  );

  procedure separarOrigem
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_idCaixaSeparacao     in number,
    p_reabPendente         in out number,
    p_mensagem             in out varchar2,
    p_bufferesteiraorigem  in number,
    p_bufferesteiradestino in number
  );

  procedure separarDestino
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_validaSepDestino     in boolean,
    p_idCaixaSeparacao     in number,
    p_reabPendente         in out number,
    p_mensagem             in out varchar2,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
  );

  function getCountMovDasEtapasAnterior
  (
    p_idOnda          number,
    p_isBufferOrigem  number,
    p_tipoOrigem      number,
    p_isBufferDestino number,
    p_tipoDestino     number
  ) return number;

  procedure finalizarEntregaParcial
  (
    p_idOnda          in number,
    p_idRegiaoDestino in number,
    p_idLocalOrigem   in number,
    p_bufferDestino   in number,
    p_codBarraTarefa  in varchar2,
    p_identificador   in number,
    p_idUsuario       in number,
    p_idProduto       in number
  );

  procedure finalizarRemanejamentoOrigem
  (
    p_idRemanejamento number,
    p_idUsuario       number
  );

  procedure verificarSeparacaoRem
  (
    p_idRegiaoOrigem       in number,
    p_idRegiaoDestino      in number,
    p_idOnda               in number,
    p_idUsuario            in number,
    p_tipoSeparacao        in number,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
  );

  procedure inserirSeparacaoBufferColmeia
  (
    p_idOnda           in number,
    p_idLocalOrigem    in number,
    p_barra            in varchar2,
    p_qtdeSeparada     in number,
    p_idCaixaSeparacao in number,
    p_idUsuario        in number,
    p_Identificador    in number,
    p_codTarefa        in varchar2
  );

  procedure entregarSeparacaoBufferColmeia
  (
    p_idOnda           in number,
    p_idRegiaoOrigem   in number,
    p_idCaixaSeparacao in number,
    p_idUsuario        in number,
    p_idColmeia        in number
  );

  function retornaTipoConfOnda(p_idOnda number) return number;

  procedure inserirAtividadePackingColetor
  (
    p_idArmazem    in number,
    p_idOnda       in number default null,
    p_idNotaFiscal in number default null
  );

  procedure validarSeparacaoUnicoUsuario
  (
    p_idOnda    in number,
    p_idusuario in number,
    p_mensagem  in out varchar2
  );

  procedure separacaoBoxOutStation;

  /*  function separacaoBoxDestination
  (
    p_tarefa      tarefacaixavolume.tarefa%type,
    p_caixaVolume Tipocaixavolume.barra%type
  ) return varchar2;*/

  function separacaoBoxDestination
  (
    p_tarefa       tarefacaixavolume.tarefa%type,
    p_caixaVolume  Tipocaixavolume.barra%type,
    p_pontoPLC     pontoplc.pontoplc%type,
    p_mensagemErro in out varchar2
  ) return varchar2;

  procedure moverEstoqueOS
  (
    p_idOnda    in number,
    p_idusuario in number
  );

  procedure gerarVolumeEtiquetagem
  (
    p_idOnda             in number,
    p_idRegiaoOrigem     number,
    p_idRegiaoDestino    number,
    p_idLocalEtiquetagem number,
    p_identificador      number,
    p_idusuario          in number
  );

  procedure marcarNFSepExterna
  (
    p_idNotaFiscal in number,
    p_idusuario    in number
  );

  procedure desmarcarNFSepExterna
  (
    p_idNotaFiscal in number,
    p_idusuario    in number
  );

  procedure entrarCaixaSepPorEstacao
  (
    p_barraCaixa     in varchar2,
    p_idUsuario      in number,
    p_idArmazem      in number,
    p_idRegiaoOrigem in number,
    p_idEstacao      in number := 0 /*Todas*/,
    p_barraTarefa    in out varchar2
  );
  
  function proximaEstacao
  (
    p_idEstacao      in number := 0 /*Todas*/,
    p_tarefa      in varchar2,
    p_idOnda in number,
    p_idArmazem in number
  ) return varchar2 ;

  function retBarraCxSepEstTarefa
  (
    p_idonda in number,
    p_tarefa in varchar2
  ) return varchar2;

  procedure finalizarTodasMovDestPacking
  (
    p_idLocalDestino         number,
    p_ConfPorCheckoutExpress number,
    p_SeparacaoConsolidada   number,
    p_exibirAtividadeUnica   number,
    p_idDepositante          number,
    p_idusuario              number,
    p_idonda                 number,
    p_idregiaoorigem         number,
    p_bufferorigem           number,
    p_idregiaodestino        number,
    p_bufferdestino          number,
    p_identificador          number,
    p_idnotafiscal           number
  );

  procedure gravarSeparacaoIniciada;

  procedure gravarMovimentacoesAgrupadas
  (
    p_caixaGrupoIdColmeia        number,
    p_conPorCheckoutExpress      number,
    p_utzCaixaSepEtiquetagem     number,
    p_idLocalOrigem              number,
    p_idRegiaoOrigemArmazenagem  number,
    p_idRegiaoDestinoArmazenagem number,
    p_destinoBuffer              number,
    p_idProduto                  number,
    p_exibirAtividadeUnica       number,
    p_idDepositante              number,
    p_idNotafiscal               number,
    p_idOnda                     number,
    p_idPreEtiquetaPedido        number,
    p_permiteSeparacaoMultipla   number,
    p_identificadorSeparacao     number,
    p_tipoSeparacao              number,
    p_QtdeEmSeparacao            number,
    p_idusuario                  number,
    p_idCaixaGrupo               number,
    p_loteIndustria              lote.descr%type,
    p_codigoTarefa               varchar2
  );
  type cursor_mov is ref cursor;

  type rec_mov is record(
    id            movimentacao.id%type,
    qtderestante  number,
    qtdeconferida number);
    
  function existeReabastecimentoPend
  (
    p_idOnda        number,
    p_identificador number
  ) return number;

end;
/

