create view V_INDICADOR_INVENTARIO as
select idd.idinventario,
       idd.idseq,
       ei.escopo,
       count(distinct idd.idlocal) enderecos,
       count(distinct idd.idproduto) produtos,
       sum(idd.qtd * idd.fator) contados,
       sum(decode(idd.localvazio, 'S', 1, 0)) vazios,
       sum(decode(idd.liberado, 'S', idd.qtd * idd.fator, 0)) liberados,
       sum(decode(idd.liberado, 'N', idd.qtd * idd.fator, 0)) nao_liberados
  from invdet idd,
       (select idinventario, count(*) escopo
          from escopoinventario es
         group by es.idinventario) ei
 where  ei.idinventario = idd.idinventario
group by idd.idinventario, idd.idseq, ei.escopo
/

