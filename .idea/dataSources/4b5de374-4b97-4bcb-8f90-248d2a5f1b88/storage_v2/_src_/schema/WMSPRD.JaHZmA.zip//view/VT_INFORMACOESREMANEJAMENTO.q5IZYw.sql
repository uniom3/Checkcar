create view VT_INFORMACOESREMANEJAMENTO as
select r.rowid h$tableid, r.idremanejamento, rp.idromaneio idonda,
       rp.codigointerno onda, rp.datageracao dtgeracao,
       rp.tituloromaneio titulo,
       rp.transportadoranotafiscal idtransportadora,
       et.razaosocial transportadora, s.pesototal, s.cubagem
  from gtt_selecao g, remanejamento r, remanejamentoromaneio rr,
       (select rp.idromaneio, rp.codigointerno, rp.datageracao,
                rp.tituloromaneio, nf.transportadoranotafiscal
           from romaneiopai rp, nfromaneio nfr, notafiscal nf
          where rp.idromaneio = nfr.idromaneio(+)
            and nfr.idnotafiscal = nf.idnotafiscal(+)) rp, entidade et,
       (select r.idremanejamento,
                sum((lr.qtde / e.fatorconversao) * e.pesobruto) / 1000 pesototal,
                replace(trim(to_char(round(sum((lr.qtde / e.fatorconversao) *
                                                e.largura * e.comprimento *
                                                e.altura) / 1000000000, 6),
                                      '99990.009999')), '.', ',') cubagem
           from remanejamento r, loteremanejamento lr, lote l, embalagem e
          where l.idproduto = e.idproduto
            and l.barra = e.barra
            and l.idlote = lr.idlote
            and lr.idremanejamento = r.idremanejamento
          group by r.idremanejamento) s
 where r.idremanejamento = g.idselecionado
   and rr.idremanejamento = r.idremanejamento
   and rp.idromaneio = rr.idromaneio
   and s.idremanejamento(+) = r.idremanejamento
   and et.identidade(+) = rp.transportadoranotafiscal
/

