create view VT_TRANSFDOCARMAZEM as
select nfs.idnotafiscal, nfs.notaFiscal, nfs.serie, nfs.pedido,
       nfs.cnpjDepositante, nfs.depositante, nfs.cnpjEmitente, nfs.emitente,
       nfs.cnpjDestinatario, nfs.destinatario, nfs.cnpjEntrega, nfs.entrega,
       nfs.Dataemissao, nfs.valorProdutos, nfs.valorTotal,
       nfs.transportadora, nfs.operacao, nfs.cfop, nfs.observacao,
       nfs.chaveacessonfe, nfs.idarmazem h$idarmazem,
       nfs.idarmazemLocal h$idarmazemLocal, nfs.tipooper h$tipooper
  from (select nf. idnotafiscal, nf.codigointerno notaFiscal,
                nf.sequencia serie, nf.pedido, nf.statusnf, nf.tipo,
                nf.iddepositante, dep.cgc cnpjDepositante,
                dep.razaosocial depositante, emit.cgc cnpjEmitente,
                emit.razaosocial emitente, dest.cgc cnpjDestinatario,
                dest.razaosocial destinatario, entr.cgc cnpjEntrega,
                entr.razaosocial entrega, nf.Dataemissao,
                nf.totalprodutos valorProdutos, nf.totalgeral valorTotal,
                transp.razaosocial transportadora, oper.descr operacao,
                oper.idcfop cfop, nf.observacao, nf.chaveacessonfe,
                nf.idarmazem idarmazem, adest.idarmazem idarmazemLocal,
                oper.tipooper tipooper
           from notafiscal nf, entidade dep, entidade emit, entidade dest,
                entidade entr, entidade transp, operacao oper, armazem a,
                romaneiopai p, nfromaneio nfr, armazem adest
          where nf.iddepositante = dep.identidade
            and nf.remetente = emit.identidade
            and nf.destinatario = dest.identidade
            and nf.ident_entrega = entr.identidade
            and nf.idtransportadoraredespacho = transp.identidade(+)
            and nf.idoperacao = oper.idoperacao
            and nf.idarmazem = a.idarmazem
            and nf.idnotafiscal = nfr.idnotafiscal
            and nfr.idromaneio = p.idromaneio
         
         union
         
         select nf. idnotafiscal, nf.codigointerno notaFiscal,
                nf.sequencia serie, nf.pedido, nf.statusnf, nf.tipo,
                nf.iddepositante, dep.cgc cnpjDepositante,
                dep.razaosocial depositante, emit.cgc cnpjEmitente,
                emit.razaosocial emitente, dest.cgc cnpjDestinatario,
                dest.razaosocial destinatario, entr.cgc cnpjEntrega,
                entr.razaosocial entrega, nf.Dataemissao,
                nf.totalprodutos valorProdutos, nf.totalgeral valorTotal,
                transp.razaosocial transportadora, oper.descr operacao,
                oper.idcfop cfop, nf.observacao, nf.chaveacessonfe,
                nf.idarmazem idarmazem, adest.idarmazem idarmazemLocal,
                oper.tipooper tipooper
           from notafiscal nf, entidade dep, entidade emit, entidade dest,
                entidade entr, entidade transp, operacao oper, armazem a,
                nfe nfe, armazem adest
          where nf.iddepositante = dep.identidade
            and nf.remetente = emit.identidade
            and nf.destinatario = dest.identidade
            and nf.ident_entrega = entr.identidade
            and nf.idtransportadoraredespacho = transp.identidade(+)
            and nf.idoperacao = oper.idoperacao
            and nf.idarmazem = a.idarmazem
            and nf.idnotafiscal = nfe.idnotafiscal
            and nfe.situacao = 3) nfs
 where nfs.tipooper <> 'TP'
   and nfs.idnotafiscal not in
       (select idnotafiscalsaida
          from transferenciatitularidade
         where idnotafiscalsaida is not null)
   and nfs.tipo = 'S'
   and nfs.statusnf = 'P'
   and nfs.idarmazem <> nfs.idarmazemLocal
   and not exists (select 1
          from notafiscal n
         where n.codigointerno = nfs.notaFiscal
           and n.totalprodutos = nfs.valorProdutos
           and n.iddepositante = nfs.iddepositante
           and n.idarmazem = nfs.idarmazemLocal)
/

