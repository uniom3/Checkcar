create view VI_INT_ENVIO_AM_TD as
select agrupador id, agrupador, sendpartyid, vendorpartyid,
       warehouselocationid, destinationwarehouselocationid, transfervendorid,
       carriername, inventoryeffectivedatetime, truckid, sealid
  from int_envio_am_td
/

