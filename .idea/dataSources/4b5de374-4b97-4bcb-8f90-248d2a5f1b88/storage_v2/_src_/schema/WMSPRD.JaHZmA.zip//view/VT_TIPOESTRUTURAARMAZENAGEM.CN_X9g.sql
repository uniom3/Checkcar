create view VT_TIPOESTRUTURAARMAZENAGEM as
select id idtipoestrutura, codigointegracao, descricao descricaoestrutura,
       tipo tipoestrutura, altura, largura, comprimento,
       (select count(1)
           from local lo
          where lo.idtipoestrutura = te.id) h$enderecovinculado
  from tipoestruturaarmazenagem te
/

