create package pk_setor is

  C_SUBDOCA constant number := 19;

  procedure addTipoRecebimentoSetor
  (
    p_idsetor           in number,
    p_idtiporecebimento in number,
    p_idusuario         in number,
    p_tela              in varchar2
  );

  procedure isLocalCaixaMovimentacao
  (
    p_idArmazem in number,
    p_local     in varchar2
  );

  procedure removeProdutoAll
  (
    p_idSetor in number,
    idUsuario in number
  );

  procedure addLocalAll
  (
    p_idSetor in number,
    idUsuario in number
  );

  procedure removeLocalAll
  (
    p_idSetor in number,
    idUsuario in number
  );

  procedure alteraLocal
  (
    p_idSetor    in number,
    p_idEndereco in number
  );

  procedure vincularSetorProduto
  (
    p_idSetor    in number,
    p_idproduto  in number,
    p_idusuario  in number,
    p_log        in varchar2,
    p_prioridade in number
  );

  procedure addClassifMatPerigosos
  (
    p_idSetor              in number,
    p_idClassifMatPerigoso in number
  );

  procedure removeClassifMatPerigosos
  (
    p_idSetor              in number,
    p_idClassifMatPerigoso in number
  );

  procedure vincularProdutosAoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  );

  function isSetorTipoProdutoValido
  (
    p_idProduto in produto.idproduto%type,
    p_idSetor   in setor.idsetor%type
  ) return boolean;

  procedure vincularTipoProdutoAoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  );

  procedure removeTipoProdutoDoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  );

end pk_setor;
/

