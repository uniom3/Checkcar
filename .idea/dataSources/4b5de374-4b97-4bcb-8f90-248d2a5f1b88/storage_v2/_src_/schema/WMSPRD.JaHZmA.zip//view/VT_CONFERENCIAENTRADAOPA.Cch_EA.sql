create view VT_CONFERENCIAENTRADAOPA as
select a.depositante, a.cnpj, a.inscrestadual, a.notafiscal, a.serie,
       a.dataemissao, a.cfop, a.baseicms, a.icms, a.totalnf, a.ordemcompra,
       a.dataordemcompra, a.codigoitem, a.descricaoitem, a.lotefornecedor,
       a.datavencimentolote, a.qtdeunidaderecebida, a.padraocaixaunrecebida,
       (a.lastro || 'x' || a.qtdecamada) padraopaletsistema,
       (a.qtdeunidaderecebida / (a.lastro * a.qtdecamada)) padraopaleteunrecebida,
       a.idnotafiscal, a.idarmazem, a.iddepositante, a.razaosocial armazem,
       a.cgc cnpjarmazem, a.armazeminscr
  from (select dep.razaosocial depositante, dep.cgc cnpj, dep.inscrestadual,
                nf.codigointerno notafiscal, nf.sequencia serie,
                nf.dataemissao, o.idcfop cfop, nf.baseicms, nf.valoricms icms,
                nf.totalgeral totalnf, oc.codigoordemcompra ordemcompra,
                oc.datacriacao dataordemcompra, p.codigointerno codigoitem,
                upper(p.descr) descricaoitem, lt.descr lotefornecedor,
                lt.dtvenc datavencimentolote,
                sum(lt.qtdeentrada * emb.fatorconversao) qtdeunidaderecebida,
                emb.descrreduzido padraocaixaunrecebida, emb.lastro,
                emb.qtdecamada, nf.idnotafiscal, nf.idarmazem,
                dep.identidade iddepositante, ar.razaosocial, ar.cgc,
                ar.inscrestadual armazeminscr
           from origemlotedetalhado orld, lote lt, nfdet nd, notafiscal nf,
                entidade dep, operacao o, itemopanfdet idet,
                itemordemcompra ioc, ordemcompra oc, produto p, embalagem emb,
                armazem a, entidade ar
          where 1 = 1
            and lt.idlote = orld.idlote
            and decode(lt.tipolote, 'L', 1, 0) = 1
            and nd.nf = orld.idnotafiscal
            and nd.idproduto = orld.idproduto
            and nf.idnotafiscal = nd.nf
            and nf.iddepositante = dep.identidade
            and nf.idoperacao = o.idoperacao
            and idet.idnfdet(+) = nd.idnfdet
            and ioc.iditemordemcompra(+) = idet.iditemordemcompra
            and oc.idordemcompra(+) = ioc.idordemcompra
            and p.idproduto = nd.idproduto
            and emb.idproduto = nd.idproduto
            and emb.barra = nd.barra
            and a.idarmazem = nf.idarmazem
            and ar.identidade = a.identidade
          group by dep.razaosocial, dep.cgc, dep.inscrestadual,
                   nf.codigointerno, nf.sequencia, nf.dataemissao, o.idcfop,
                   nf.baseicms, nf.valoricms, nf.totalgeral,
                   oc.codigoordemcompra, oc.datacriacao, p.codigointerno,
                   upper(p.descr), lt.descr, lt.dtvenc, emb.descrreduzido,
                   emb.lastro, emb.qtdecamada, nf.idnotafiscal, nf.idarmazem,
                   dep.identidade, ar.razaosocial, ar.cgc, ar.inscrestadual) a
 order by a.cnpj asc, a.notafiscal asc, a.codigoitem asc
/

