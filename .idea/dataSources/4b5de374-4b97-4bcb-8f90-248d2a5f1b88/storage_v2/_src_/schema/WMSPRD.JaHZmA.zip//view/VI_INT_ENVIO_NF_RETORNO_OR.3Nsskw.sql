create view VI_INT_ENVIO_NF_RETORNO_OR as
select id, 7 i, codigointerno, numpedido, cnpj_depositante, cnpj_emitente,
       sequencia, tipo, status, o, motivocancelamento, c, idmovimento,
       idnotafiscal, npalet, seq_entrega, paginageomapa, descrromaneio,
       placa, motorista, cnpj_motorista,
       to_char(dataemissao, 'dd/mm/yyyy') dataemissao, qtdevolume,
       totalpesovolume, cnpj_dest, identificadorpedido, totalcubagemvolume,
       '*' f
  from int_envio_nf_retorno_or
/

