create view VR_ETIQUETACRACHAUSUARIO as
select u.idusuario, u.codbarra, u.nomeusuariocompleto, u.departamento,
       e.razaosocial
  from usuario u, entidade e
 where e.identidade(+) = u.entidadeusuario
/

