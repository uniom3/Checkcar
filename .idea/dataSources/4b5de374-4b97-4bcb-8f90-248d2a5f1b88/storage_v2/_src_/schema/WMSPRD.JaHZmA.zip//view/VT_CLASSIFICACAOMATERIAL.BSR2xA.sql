create view VT_CLASSIFICACAOMATERIAL as
select c.id idclassificacao, c.nome descricao, c.ordem
  from classificacaomaterial c
/

