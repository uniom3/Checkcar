create view VB_CLASSIFICACAOMATERIAL as
select nome classificacaomaterial, id
  from classificacaomaterial
/

