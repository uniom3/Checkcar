create view VT_CONFIGURACAOINTEGRACAO as
select ci.id idconfiguracaointegracao, a.descr armazem,
       e.razaosocial depositante, ci.ativo, ci.dirimportacao,
       ci.dirbkpimportacao dirbackupimp, ci.direxportacao,
       ci.dirbkpexportacao dirbackupexp, ci.erro direrro,
       ci.direxportacaotms, ci.apikey, a.idarmazem,
       e.identidade iddepositante,
       decode(ci.servicorest, 0, ' ',
               decode(ci.codificacaoexprest, 0, 'UFT-8', 'ISO-8859-1')) codificacaoexprest,
       decode(ci.servicorest, 0, ' ',
               decode(ci.tipoarquivoexprest, 0, 'APPLICATION_JSON',
                       'TEXT_PLAIN')) tipoarquivoexprest
  from configuracaointegracao ci, armazem a, entidade e
 where a.idarmazem(+) = ci.idarmazem
   and e.identidade(+) = ci.identidade
/

