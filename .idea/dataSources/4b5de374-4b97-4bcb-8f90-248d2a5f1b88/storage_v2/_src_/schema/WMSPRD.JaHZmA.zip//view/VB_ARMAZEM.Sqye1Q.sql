create view VB_ARMAZEM as
select DESCR, IDARMAZEM
   from armazem
/

