create view VR_BASEMODCOBRANCAAMZINVCUBISC as
select 'CUBISCAN' operacao, p.idproduto, p.descr,
       round(to_number(nvl(replace(a.comprimento, '.', ','), 0)), 2) comprimentocm,
       round(to_number(nvl(replace(a.largura, '.', ','), 0)), 2) larguracm,
       round(to_number(nvl(replace(a.altura, '.', ','), 0)), 2) alturacm,
       round(to_number(nvl(replace(a.comprimento, '.', ','), 0)) *
              to_number(nvl(replace(a.largura, '.', ','), 0)) *
              to_number(nvl(replace(a.altura, '.', ','), 0)), 2) volumecm3,
       round((to_number(nvl(replace(a.peso, '.', ','), 0)) * 1000), 2) pesobrutokg,
       round((to_number(nvl(replace(a.peso, '.', ','), 0)) * 1000), 2) pesoliquidokg,
       a.datahoraimportacao data, count(1) qtde
  from atualizacaoembalagem a, produto p
 where 1 = 1
   and a.idproduto = p.idproduto
 group by 'CUBISCAN', p.idproduto, p.descr,
          round(to_number(nvl(replace(a.comprimento, '.', ','), 0)), 2),
          round(to_number(nvl(replace(a.largura, '.', ','), 0)), 2),
          round(to_number(nvl(replace(a.altura, '.', ','), 0)), 2),
          round(to_number(nvl(replace(a.comprimento, '.', ','), 0)) *
                 to_number(nvl(replace(a.largura, '.', ','), 0)) *
                 to_number(nvl(replace(a.altura, '.', ','), 0)), 2),
          round((to_number(nvl(replace(a.peso, '.', ','), 0)) * 1000), 2),
          round((to_number(nvl(replace(a.peso, '.', ','), 0)) * 1000), 2),
          a.datahoraimportacao
/

