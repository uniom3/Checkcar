create package body pk_sepOndaPriorizada is

  procedure removerPriorizacao
  (
    p_idArmazem         number,
    p_idUsuarioCadastro number,
    p_idUsuario         number := null,
    p_log               number := 1
  ) is
    v_msg t_message;
  begin
    delete from sepondapriorizada s
     where s.idarmazem = p_idArmazem
       and s.idusuario = nvl(p_idUsuario, s.idusuario);
  
    if (sql%rowcount = 0 and p_idUsuario is null) then
      v_msg := t_message('Não existe priorização de atividade de separação de onda cadastrada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_idUsuario is null) then
      pk_utilities.GeraLog(p_idUsuarioCadastro,
                           'REMOVIDAS TODAS AS PRIORIDADES DE ATIVIDADE DE SEPARAÇÃO',
                           p_idArmazem, 'SP');
    else
      if (p_log = 1) then
        pk_utilities.GeraLog(p_idUsuarioCadastro,
                             'REMOVIDA PRIORIDADE DE ATIVIDADE DE SEPARAÇÃO DO USUARIO ' ||
                              p_idUsuario, p_idArmazem, 'SP');
      end if;
    end if;
  
  end removerPriorizacao;

  procedure adicionarPriorizacao
  (
    p_idArmazem         number,
    p_idUsuarioCadastro number,
    p_tipoPriorizacao   number,
    p_packing           number,
    p_packingCheckout   number,
    p_colmeia           number
  ) is
    v_msg  t_message;
    v_qtde number;
  
    procedure validar is
    begin
      if (p_idArmazem is null) then
        v_msg := t_message('Valor do ID Armazem é obrigatório.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_qtde
        from gtt_selecao;
    
      if (v_qtde = 0) then
        v_msg := t_message('Para realizar a priorização das atividades de separação de onda é necessário informar o(s) usuário(s).');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validar;
  
    procedure validarPriorizacao is
      validou boolean := false;
    
      procedure exibirRaiseValidacao is
      begin
        if (p_tipoPriorizacao = 0) then
          v_msg := t_message('Valor de priorização de atividade definida para o packing ou colmeia ou packing checkout está inválida.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (p_tipoPriorizacao = 1) then
          v_msg := t_message('Valor do filtro de priorização de atividade definida para o packing ou colmeia ou packing checkout está inválida.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end exibirRaiseValidacao;
    
    begin
      if (nvl(p_tipoPriorizacao, -1) not in (0, 1)) then
        v_msg := t_message('Valor da priorização de atividade está inválido.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_tipoPriorizacao = 0) then
        if (p_packing is null or p_packingCheckout is null or
           p_colmeia is null) then
          exibirRaiseValidacao;
        end if;
      
        if (p_packing not in (0, 1, 2) or
           p_packingCheckout not in (0, 1, 2) or
           p_colmeia not in (0, 1, 2)) then
          exibirRaiseValidacao;
        end if;
      
      elsif (p_tipoPriorizacao = 1) then
        if (p_packing is null and p_packingCheckout is null and
           p_colmeia is null) then
          exibirRaiseValidacao;
        end if;
      
        if (p_packing = 1) then
          validou := true;
          if (p_packingCheckout is not null or p_colmeia is not null) then
            exibirRaiseValidacao;
          end if;
        end if;
      
        if (p_packingCheckout = 1) then
          validou := true;
          if (p_packing is not null or p_colmeia is not null) then
            exibirRaiseValidacao;
          end if;
        end if;
      
        if (p_colmeia = 1) then
          validou := true;
          if (p_packing is not null or p_packingCheckout is not null) then
            exibirRaiseValidacao;
          end if;
        end if;
      
        if (not validou) then
          exibirRaiseValidacao;
        end if;
      
      end if;
    end validarPriorizacao;
  
  begin
    validar;
    validarPriorizacao;
  
    for c_usuario in (select g.idselecionado idUsuario
                        from gtt_selecao g)
    loop
    
      pk_sepOndaPriorizada.removerPriorizacao(p_idArmazem,
                                              p_idUsuarioCadastro,
                                              c_usuario.idusuario, 0);
    
      insert into histsepondapriorizada
        (idarmazem, idusuario, tipopriorizacao, packingprioridadeordem,
         packingcheckprioridadeordem, colmeiaprioridadeordem,
         idusuariocadastro)
      values
        (p_idArmazem, c_usuario.idusuario, p_tipoPriorizacao, p_packing,
         p_packingCheckout, p_colmeia, p_idUsuarioCadastro);
    
      insert into sepondapriorizada
        (idarmazem, idusuario, tipopriorizacao, packingprioridadeordem,
         packingcheckprioridadeordem, colmeiaprioridadeordem,
         idusuariocadastro)
      values
        (p_idArmazem, c_usuario.idusuario, p_tipoPriorizacao, p_packing,
         p_packingCheckout, p_colmeia, p_idUsuarioCadastro);
    
    end loop;
  
  end adicionarPriorizacao;

  function getTextoPrioridade
  (
    p_idUsuario  number,
    p_tipo       number,
    p_prioridade number
  ) return varchar2 is
    v_qtde  number;
    v_texto varchar2(4000);
  begin
    select count(1)
      into v_qtde
      from sepondapriorizada s
     where s.idusuario = p_idUsuario
       and s.tipopriorizacao = p_tipo;
  
    if (v_qtde = 0) then
      return null;
    end if;
  
    for s in (select *
                from sepondapriorizada s
               where s.idusuario = p_idUsuario
                 and s.tipopriorizacao = p_tipo)
    loop
      if (s.packingprioridadeordem = p_prioridade) then
        v_texto := v_texto || 'PACKING';
      end if;
      if (s.Packingcheckprioridadeordem = p_prioridade) then
        if (v_texto is not null) then
          v_texto := v_texto || '-';
        end if;
        v_texto := v_texto || 'PACKING CHECKOUT';
      end if;
      if (s.colmeiaprioridadeordem = p_prioridade) then
        if (v_texto is not null) then
          v_texto := v_texto || '-';
        end if;
        v_texto := v_texto || 'COLMEIA';
      end if;
    end loop;
  
    return v_texto;
  
  end getTextoPrioridade;

end pk_sepOndaPriorizada;
/

