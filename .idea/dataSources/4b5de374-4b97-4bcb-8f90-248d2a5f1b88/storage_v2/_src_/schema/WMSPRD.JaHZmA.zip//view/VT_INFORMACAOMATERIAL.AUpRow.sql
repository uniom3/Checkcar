create view VT_INFORMACAOMATERIAL as
select idinfomaterial, informacao, sequencia
  from informacaomaterial
/

