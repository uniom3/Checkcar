create view VT_CODIGOONU as
select idcodigoonu, descricao, numeroonu, classerisco, riscosubsidiario,
       numerorisco, grupoemb, provisoesespeciais, qtdelimitporveiculo
  from codigoonu
/

