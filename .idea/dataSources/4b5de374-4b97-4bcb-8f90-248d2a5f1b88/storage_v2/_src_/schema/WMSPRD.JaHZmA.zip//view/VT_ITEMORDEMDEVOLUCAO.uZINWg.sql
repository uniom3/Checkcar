create view VT_ITEMORDEMDEVOLUCAO as
select iod.rowid h$tableid, iod.id iditemordemdevolucao, iod.idproduto,
       p.codigointerno codigoproduto, p.descr produto,
       iod.quantidaderemocao quantidade,
       sum(nvl(pk_ordemdevolucao.getQtdeProdConferidaLote(odr.idremanejamento,
                                                           p.idproduto,
                                                           lr.idlote), 0)) qtdeConferida,
       nvl((select sum(ll.estoque - ll.pendencia + ll.adicionar)
              from lotelocal ll, lote lt, local l, setor s
             where 1 = 1
               and lt.idlote = ll.idlote
               and lt.idarmazem = ll.idarmazem
               and l.idlocal = ll.idlocal
               and l.idarmazem = ll.idarmazem
               and s.idsetor = l.idsetor
               and s.devolucaofornecedor = 1
               and s.expedicao = 'N'
               and lt.liberado = 'S'
               and lt.idproduto = iod.idproduto), 0) estoque,
       nvl((select sum(ll.estoque - ll.pendencia + ll.adicionar)
              from lotelocal ll, lote lt, local l, setor s
             where 1 = 1
               and lt.idlote = ll.idlote
               and lt.idarmazem = ll.idarmazem
               and l.idlocal = ll.idlocal
               and l.idarmazem = ll.idarmazem
               and s.idsetor = l.idsetor
               and s.devolucaofornecedor = 1
               and s.expedicao = 'N'
               and lt.liberado = 'S'
               and lt.idproduto = iod.idproduto), 0) -
        sum(nvl(pk_ordemdevolucao.getQtdeProdConferidaLote(odr.idremanejamento,
                                                           p.idproduto,
                                                           lr.idlote), 0)) diferenca,
       iod.itemlocation codigointegracaosetor,
       iod.idordemdevolucaopai h$idordemdevolucaopai,
       iod.idordemdevolucao h$idordemdevolucao
  from itemOrdemDevolucao iod, produto p, ordemdevolucaoremanejamento odr,
       remanejamento r, loteremanejamento lr, lote l, gtt_selecao g
 where 1 = 1
   and g.idselecionado = iod.idordemdevolucao
   and iod.idproduto = p.idproduto
   and iod.id = odr.iditemordemdevolucao(+)
   and odr.idremanejamento = r.idremanejamento(+)
   and r.idremanejamento = lr.idremanejamento(+)
   and lr.idlote = l.idlote(+)
   and nvl(l.idproduto, p.idproduto) = p.idproduto
 group by iod.rowid, iod.id, iod.idproduto, iod.quantidaderemocao,
          p.codigointerno, p.descr, iod.itemlocation,
          iod.idordemdevolucaopai, iod.idordemdevolucao
/

