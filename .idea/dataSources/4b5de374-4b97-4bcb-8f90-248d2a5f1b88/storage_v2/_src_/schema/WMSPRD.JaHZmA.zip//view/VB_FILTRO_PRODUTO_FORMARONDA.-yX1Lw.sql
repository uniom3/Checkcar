create view VB_FILTRO_PRODUTO_FORMARONDA as
select p.codigointerno codproduto, p.codreferencia, p.descr produto,
       p.idproduto idproduto
  from produto p
 where p.ativo = 'S'
/

