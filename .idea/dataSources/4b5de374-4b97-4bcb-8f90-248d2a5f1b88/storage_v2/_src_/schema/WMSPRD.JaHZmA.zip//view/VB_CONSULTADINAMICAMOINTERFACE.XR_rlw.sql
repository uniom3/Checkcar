create view VB_CONSULTADINAMICAMOINTERFACE as
select s.id, s.nome
  from sql s
 where s.modo = 3
/

