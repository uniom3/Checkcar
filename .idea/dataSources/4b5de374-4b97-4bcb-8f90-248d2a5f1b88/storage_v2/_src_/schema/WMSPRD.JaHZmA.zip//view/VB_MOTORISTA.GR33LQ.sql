create view VB_MOTORISTA as
select e.razaosocial motoristaagregado, e.identidade,
       decode(e.pessoa, 'J', e.cgc, e.cic) cnpjcpf, e.rg
  from entidade e, tipo t
 where e.tipoentidade = t.idtipo
   and upper(t.descr) like '%MOTOR%'
/

