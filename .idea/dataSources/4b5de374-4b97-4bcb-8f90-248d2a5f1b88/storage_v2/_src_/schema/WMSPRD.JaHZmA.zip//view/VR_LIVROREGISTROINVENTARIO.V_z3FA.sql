create view VR_LIVROREGISTROINVENTARIO as
select lf.idlivrofiscal, e.razaosocial firma, e.inscrestadual, e.cgc cnpj,
       lf.ultimapagina,
       case
          when trunc(sysdate) > lf.datatermino then
           lf.datatermino
          else
           trunc(sysdate)
        end estoqueem, est.classificacaofiscal, p.descr discriminacao,
       'UN' unidade, est.estoquefinalperiodo quantidade,
       decode(est.estoquefinalperiodo, 0, 0,
               (est.valorfinalperiodo / est.estoquefinalperiodo)) valorunitario,
       est.valorfinalperiodo valortotal, r.classificacao
  from (select v.idlivrofiscal, v.iddepositante, v.idproduto,
                p.ncm classificacaofiscal,
                sum(v.estoqueanterior + v.movimentacao) estoquefinalperiodo,
                sum(v.valoranterior + v.valormovimentacao) valorfinalperiodo
           from (select e.idlivrofiscal, e.iddepositante, e.idproduto,
                         e.estoqueanterior, e.valoranterior, 0 movimentacao,
                         0 valormovimentacao
                    from estoqueanteriorlivro e
                  union all
                  select lv.idlivrofiscal, nf.iddepositante, i.idproduto, 0, 0,
                         sum(case
                                when i.tipo = 'E' then
                                 i.quantidade
                                else
                                 i.quantidade * -1
                              end) movimentacao,
                         sum(case
                                when i.tipo = 'E' then
                                 i.valor
                                else
                                 i.valor * -1
                              end) valor
                    from livrofiscal lv, itemlivroregistroinventario i,
                         notafiscal nf
                   where i.dtestoque between lv.datainicio and lv.datatermino
                     and i.idlivrofiscal = lv.idlivrofiscal
                     and nf.idnotafiscal = i.idnotafiscal
                   group by lv.idlivrofiscal, nf.iddepositante, i.idproduto) v,
                produto p
          where p.idproduto = v.idproduto
          group by v.idlivrofiscal, v.iddepositante, v.idproduto, p.ncm) est,
       livrofiscal lf, entidade e, produto p, depositante d, regime r
 where lf.idlivrofiscal = est.idlivrofiscal
   and e.identidade = lf.identidade
   and p.idproduto = est.idproduto
   and d.identidade = est.iddepositante
   and r.idregime = d.idregime
   and r.classificacao = 'A'
/

