create view VT_ENVIARSEPARACAOPTL as
select rp.codigointerno onda, rp.dataliberacaoonda dtliberacao,
       nvl(nf.numpedidofornecedor, nf.codigointerno) numpedido,
       m.codbarratarefa, dest.razaosocial destinatario, m.idonda,
       m.idnotafiscal
  from v_tarefas_onda m, lote lt, produto p, local lo, notafiscal nf,
       entidade dest, configuracaoonda co, romaneiopai rp
 where m.etapa = 1
   and m.status = 0
   and m.identificador > 0
   and p.idproduto = lt.idproduto
   and lt.idlote = m.idlote
   and lo.id = m.idlocalorigem
   and dest.identidade = nf.destinatario
   and nf.idnotafiscal = m.idnotafiscal
   and rp.statusonda in (2, 4)
   and rp.idromaneio = m.idonda
   and rp.idconfiguracaoonda = co.idconfiguracaoonda
   and co.exclusivopicktolight = 1
   and co.tipointegracaoptl = 1
   and co.momentoenviosepptl = 2
   and exists (select 1
          from pickingpicktolightonda ptl, produtolocal pl
         where pl.idarmazem = lo.idarmazem
           and pl.idlocal = lo.idlocal
           and pl.idproduto = lt.idproduto
           and pl.identidade = lt.iddepositante
           and pl.idprodutolocal = ptl.idprodutolocal
           and ptl.idconfiguracaoonda = co.idconfiguracaoonda)
   and not exists (select 1
          from tarefacaixavolume tcv
         where tcv.idonda = m.idonda
           and tcv.tarefa = m.codbarratarefa)
 group by rp.codigointerno, rp.dataliberacaoonda,
          nvl(nf.numpedidofornecedor, nf.codigointerno), m.codbarratarefa,
          dest.razaosocial, m.idonda, m.idnotafiscal
 order by rp.dataliberacaoonda, m.codbarratarefa
/

