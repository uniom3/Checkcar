create view V_GERENCIADOR_VOLUME as
select rp.idromaneio as "Id Onda", rp.codigointerno as "Onda/Romaneio",
       rp.datageracao as "Data Geração Onda",
       nf.idnotafiscal as "Id Nota Fiscal",
       nf.numpedidofornecedor as "Pedido", nf.codigointerno as "Nota Fiscal",
       nf.sequencia as "Série", d.identidade as "Id Depositante",
       d.razaosocial as "Depositante", a.identidade as "Id Destinatário",
       a.razaosocial as "Destinatário", vr.idvolumeromaneio as "Id Volume",
       vr.numero as "Volume", vr.codbarra as "Cód de Barras",
       uv.nomeusuario "Usuário criação",
       usupesagem.nomeusuario as "Usuário pesagem", vr.data as "Data Volume",
       lo.idlocal as "Local Origem",
       decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING') as "Tipo Local Origem",
       decode(m.status, 0,
               decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                       'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5,
                       'AUDITORIA', 6, 'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING'),
               1,
               decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                       'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5,
                       'AUDITORIA', 6, 'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING'),
               2,
               decode(ld.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                       'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5,
                       'AUDITORIA', 6, 'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING'),
               4, 'PRODUTOS ENTREGUE') as "Posição Estoque",
       m.status as "Status", g."Status" as "Status Auditoria",
       rp.idarmazem as "Id Armazem",
       vr.dataentvolumedoca as "Data entrega volume doca",
       usudoca.nomeusuario as "Usuário entrega volume doca",
       vr.idusuarioconferencia "IdUsuário coleta",
       vr.dataconferencia "Data coleta", uc.nomeusuario "Usuário coleta"
  from volumeromaneio vr, movimentacao m, romaneiopai rp, nfromaneio nfr,
       notafiscal nf, entidade a, entidade d, local lo, local ld,
       v_gerenciador_auditoria g, usuario uv, usuario usudoca,
       usuario usupesagem, usuario uc
 where vr.statusvolume = 0
   and m.idvolumeromaneio = vr.idvolumeromaneio
   and rp.idromaneio = m.idonda
   and rp.tipo = 1
   and nfr.idromaneio = vr.idromaneio
   and nfr.idnotafiscal = vr.idnotafiscal
   and nf.idnotafiscal = nfr.idnotafiscal
   and a.identidade = nf.destinatario
   and d.identidade = nf.iddepositante
   and lo.id = m.idlocalorigem
   and ld.id = m.idlocaldestino
   and g."Id Volume" = vr.idvolumeromaneio
   and uv.idusuario = vr.idusuario
   and usudoca.idusuario(+) = vr.idusuarioentdoca
   and usupesagem.idusuario(+) = vr.idusuariopesagem
   and uc.idusuario(+) = vr.idusuarioconferencia
 order by vr.idvolumeromaneio desc
/

