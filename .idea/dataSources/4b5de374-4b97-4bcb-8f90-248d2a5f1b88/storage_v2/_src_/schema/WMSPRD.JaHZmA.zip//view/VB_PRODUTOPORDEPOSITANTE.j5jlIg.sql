create view VB_PRODUTOPORDEPOSITANTE as
select p.codigointerno codproduto, pd.codigointerno codprodutodep,
       p.descr produto, e.barra, e.descrreduzido embalagem, e.fatorconversao,
       decode(p.itemadicional, 'S', 'SIM', 'N', 'NÃO') itemadicional,
       p.descritemadicional, pd.idproduto idproduto,
       p.itemadicional h$itemadicional, pd.identidade h$iddepositante,
       pd.idproduto || '-' || e.barra || '-' || pd.identidade h$tableid
  from produtodepositante pd, produto p, embalagem e
 where p.idproduto = pd.idproduto
   and p.ativo = 'S'
   and e.idproduto = p.idproduto
   and e.ativo = 'S'
/

