create view VI_INT_ENVIO_EFD_H005 as
select 'H005' reg, idarmazem, data dt_inv,
       sum(to_number(to_char(valor, 'FM999999999990D00'))) vl_inv,
       '01' mot_inv, count(*) total
  from (select h.idarmazem, h.data,
                to_char(h.valor, 'FM999999999990D00') valor
           from historicoestoquediario h, depositante d, regime r, lote l
          where 1 = 1
            and d.identidade = h.iddepositante
            and d.identidade = l.iddepositante
            and r.idregime = d.idregime
            and h.valor > 0
            and decode(r.classificacao, 'A', 1, 0) = 1
            and l.idlote = h.idlote)
 group by idarmazem, data
/

