create view VB_REGIAOARMAZENAGEM as
select r.descr REGIAO,
       decode(r.tipo, 0, 'PICKING', 1, 'PULMÃO', 2, 'COLMÉIA', 3, 'DOCA', 4,
               'AUDITORIA', 5, 'STAGE', 6, 'PACKING', 7, 'SERVIÇO') TIPOREGIAO,
       r.idregiao, r.tipo h$tipo
  from regiaoarmazenagem r
/

