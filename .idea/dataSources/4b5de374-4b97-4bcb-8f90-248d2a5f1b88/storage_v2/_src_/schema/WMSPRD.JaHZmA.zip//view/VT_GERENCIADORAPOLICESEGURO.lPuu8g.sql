create view VT_GERENCIADORAPOLICESEGURO as
select s.idseguro id, ep.razaosocial entidadepagadora, s.numero,
       es.razaosocial entidadeseguradora, trunc(s.datainicio) datainicio, trunc(s.datafim) datatermino, s.valor,
       s.situacao situacaoseg, s.tipocobranca, ep.identidade h$identidadepagadora,
       es.identidade h$identidadeseguradora
  from seguro s, entidade ep, entidade es
 where s.identidadepagadora = ep.identidade
   and s.identidadeseguradora = es.identidade
/

