create view VB_TRANSPORTADORA as
select e.razaosocial transportadora, e.fantasia,
       decode(e.pessoa, 'J', e.cgc, e.cic) cnpjcpf, e.identidade,
       e.iddepositante h$iddepositante
  from entidade e
 where e.ativo = 'S'
   and e.tipoentidade in (select idtipo
                            from tipo
                           where descr like '%TRANSP%'
                           or descr like '%PROP%')
   and e.estrangeiro = 0
 order by e.codigointerno
/

