create TYPE T_MESSAGE AS OBJECT
  (
    v_message   VARCHAR2(4000),
    parametros T_LIST_MESSAGE_PARAM,
    constructor function T_MESSAGE(p_param in varchar2) return self as result,
    MEMBER procedure addParam(p_value in varchar2),
    MEMBER procedure addParam(p_value in number),
    MEMBER procedure addParam(p_value in date),
    MEMBER function formatMessage return varchar2,
    MEMBER function formatXML return Xmltype
  );

/

