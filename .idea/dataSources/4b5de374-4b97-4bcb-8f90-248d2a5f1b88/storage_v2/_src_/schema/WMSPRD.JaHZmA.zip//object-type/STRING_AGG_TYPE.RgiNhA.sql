create TYPE string_agg_type AS OBJECT
(
  total VARCHAR2(4000),

  STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT string_agg_type)
    RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate
  (
    self  IN OUT string_agg_type,
    value IN VARCHAR2
  ) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate
  (
    self        IN string_agg_type,
    returnValue OUT varchar2,
    flags       IN number
  ) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge
  (
    self IN OUT string_agg_type,
    ctx2 IN string_agg_type
  ) RETURN NUMBER
)
/

