create view VB_TRANSPORTADORACONF as
SELECT RAZAOSOCIAL TRANSPORTADORA, IDENTIDADE
          FROM ENTIDADE
         WHERE ATIVO = 'S'
           AND TIPOENTIDADE IN (SELECT IDTIPO
                                  FROM TIPO
                                 WHERE DESCR LIKE '%TRANSP%')
/

