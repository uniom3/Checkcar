create view VR_VOLUMESEXPEDICAOXD as
select vr.idnotafiscal, nf.sequencia serie, ent.razaosocial depositante,
       pk_recebimento.getNrosBarraContentora(cr.barra) contentor,
       vr.codbarra,
       decode(cr.idvolumeromaneio, null, null, l.idlocalformatado) idlocal,
       p.codigointerno codproduto, p.descr produto, e.barra, s.descr setor,
       r.descr regiao, vr.numero nrovolume, cv.quantidade, a.qtde alocados,
       (na.qtde - a.qtde) naoalocados, transp.razaosocial transportadora
  from volumeromaneio vr, contentorrecebimento cr, movimentacao m, local l,
       setor s, regiaoarmazenagem r, conteudovolume cv, lote lt, produto p,
       embalagem e, entidade ent, notafiscal nf,
       (select count(*) qtde, idnotafiscal
           from (select distinct (vr2.idvolumeromaneio), vr2.idnotafiscal
                    from volumeromaneio vr2, conteudovolume cv2,
                         contentorrecebimento cr2
                   where cv2.idvolumeromaneio = vr2.idvolumeromaneio
                     and cv2.idvolumeromaneio = cr2.idvolumeromaneio)
          group by idnotafiscal) a,
       (select count(*) qtde, idnotafiscal
           from (select distinct (vr2.idvolumeromaneio), vr2.idnotafiscal
                    from volumeromaneio vr2, conteudovolume cv2,
                         contentorrecebimento cr2
                   where cv2.idvolumeromaneio = vr2.idvolumeromaneio
                     and cr2.idvolumeromaneio is null)
          group by idnotafiscal) na, entidade transp, gtt_selecao g
 where cr.idvolumeromaneio(+) = vr.idvolumeromaneio
   and m.idvolumeromaneio = vr.idvolumeromaneio
   and l.id = m.idlocalorigem
   and s.idsetor = l.idsetor
   and r.idregiao = l.idregiao
   and cv.idvolumeromaneio(+) = vr.idvolumeromaneio
   and lt.idlote = cv.idlote
   and p.idproduto = lt.idproduto
   and e.idproduto = p.idproduto
   and e.barra = lt.barra
   and nf.idnotafiscal = vr.idnotafiscal
   and ent.identidade = nf.iddepositante
   and cr.idvolumeromaneio is not null
   and a.idnotafiscal = nf.idnotafiscal
   and na.idnotafiscal = nf.idnotafiscal
   and vr.idnotafiscal = g.idselecionado
   and transp.identidade = nf.transportadoranotafiscal
 order by vr.idnotafiscal
/

