create view VI_INT_ENVIO_EFD_0000 as
select '0000' reg, '009' cod_ver, 0 cod_fin,
       to_char(sysdate, 'ddmmyyyy') dt_ini,
       to_char(sysdate, 'ddmmyyyy') dt_fin, e.razaosocial nome,
       decode(length(replace(replace(replace(e.cgc, '.', ''), '/', ''), '-',
                              '')), 14,
               replace(replace(replace(e.cgc, '.', ''), '/', ''), '-', ''),
               null) cnpj,
       nvl(decode(length(replace(replace(replace(e.cic, '.', ''), '/', ''),
                                  '-', '')), 11,
                   replace(replace(replace(e.cic, '.', ''), '/', ''), '-', ''),
                   null), ' ') cpf, en.uf,
       replace(replace(replace(replace(replace(e.inscrestadual, ' ', ''),
                                        '.', ''), '-', ''), '/', ''), ':', '') ie,
       en.codmunicipio cod_mun, nvl(e.inscrmunicipal, ' ') im,
       nvl(e.inscricaosuframa, ' ') suframa, 'A' ind_perfil, 1 ind_ativ,
       a.idarmazem
  from armazem a, entidade e, v_endereco en
 where e.identidade = a.identidade
   and en.identidade(+) = e.identidade
/

