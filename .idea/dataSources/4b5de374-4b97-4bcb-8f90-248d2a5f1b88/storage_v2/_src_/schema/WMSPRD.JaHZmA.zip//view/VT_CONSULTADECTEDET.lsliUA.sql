create view VT_CONSULTADECTEDET as
select cd.id h$id, cd.idcte, cd.nped, cd.ndoc, cd.serie, cd.demi, cd.chave
  from cte_det cd
/

