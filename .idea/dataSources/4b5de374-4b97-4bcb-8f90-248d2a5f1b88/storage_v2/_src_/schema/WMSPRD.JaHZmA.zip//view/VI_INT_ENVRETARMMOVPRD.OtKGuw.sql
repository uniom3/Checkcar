create view VI_INT_ENVRETARMMOVPRD as
select agrupador id, codigointerno, descr, unmedida, ncm, origem, item_onu,
       cod_onu, nrorisco_onu, classe_onu, descr_onu
  from int_envio_zz_produtos
/

