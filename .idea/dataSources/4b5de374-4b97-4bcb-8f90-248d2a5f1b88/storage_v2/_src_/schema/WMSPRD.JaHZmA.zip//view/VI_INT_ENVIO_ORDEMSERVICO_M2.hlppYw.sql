create view VI_INT_ENVIO_ORDEMSERVICO_M2 as
select datahora, cnpjarmazem, cnpjdepositante, estado, codproduto, produto,
       barra, descricaoreduzida, fatorconversao, qtde, idmovimento_wms,
       loteindustriaanterior, loteindustrianovo, idloteanterior, idlotenovo,
       vencimento, notafiscal, pesokg, tiposervico, i.id, i.agrupador
  from vi_int_envio_ordemservico_m1 i
/

