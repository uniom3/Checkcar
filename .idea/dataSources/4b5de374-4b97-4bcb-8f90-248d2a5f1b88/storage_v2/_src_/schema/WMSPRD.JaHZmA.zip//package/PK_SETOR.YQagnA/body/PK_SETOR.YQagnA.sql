create package body pk_setor is

  v_msg t_message;

  procedure addTipoRecebimentoSetor
  (
    p_idsetor           in number,
    p_idtiporecebimento in number,
    p_idusuario         in number,
    p_tela              in varchar2
  ) is
  
    procedure validarAddTipoRecebimento
    (
      p_idsetor           in number,
      p_idtiporecebimento in number
    ) is
      v_descrclassificacao varchar2(50);
      r_setor              setor%rowtype;
    
      function isSetorPerda(p_idSetor in number) return boolean is
        v_isSetorPerda number;
      begin
        select s.perda
          into v_isSetorPerda
          from setor s
         where s.idsetor = p_idSetor;
      
        return(v_isSetorPerda = 1);
      
      end isSetorPerda;
    
      function isSetorInsucessoEntrega(p_idSetor in number) return boolean is
        v_isSetorInsucessoEntrega number;
      begin
        select s.insucessoentrega
          into v_isSetorInsucessoEntrega
          from setor s
         where s.idsetor = p_idSetor;
      
        return(v_isSetorInsucessoEntrega = 1);
      
      end;
    
      function tipoClassificacao
      (
        p_idtiporecebimento  in number,
        p_descrclassificacao out varchar2
      ) return char is
        v_classificacao char(1);
      begin
        select classificacao,
               decode(classificacao, 'C', 'ENTRADA POR COMPRA', 'D',
                       'DEVOLUÇÃO PARCIAL', 'T', 'DEVOLUÇÃO TOTAL', 'R',
                       'ENTRADA POR REENTREGA', 'A',
                       'ENTRADA POR CROSS DOCKING DIRETO', 'X',
                       'ENTRADA POR CROSS DOCKING COM PICKING DINÂMICO', 'M',
                       'ENTRADA POR CROSS DOCKING ALOCAÇÃO MANUAL', 'I',
                       'ENTRADA POR OPERACOES INTERNAS', 'Z',
                       'CROSS DOCKING ALOCAÇÃO ENDEREÇOS BLOCADOS', 'E',
                       'ENCOMENDA', 'B', 'CROSSDOCKING')
          into v_classificacao, p_descrclassificacao
          from tiporecebimento
         where idtiporecebimento = p_idtiporecebimento;
        return v_classificacao;
      end;
    
      function existeTipoRecebimentoDiferente
      (
        p_idsetor       in number,
        p_classificacao in char
      ) return boolean is
        v_qtde number;
      begin
        select count(1)
          into v_qtde
          from setorrecebimento sr, tiporecebimento tr
         where tr.idtiporecebimento = sr.idtiporecebimento
           and tr.classificacao <> p_classificacao
           and sr.idsetor = p_idsetor;
      
        return v_qtde > 0;
      end;
    
      function existeTipoRecebimento
      (
        p_idsetor       in number,
        p_classificacao in char
      ) return boolean is
        v_qtde number;
      begin
        select count(1)
          into v_qtde
          from setorrecebimento sr, tiporecebimento tr
         where tr.idtiporecebimento = sr.idtiporecebimento
           and tr.classificacao = p_classificacao
           and sr.idsetor = p_idsetor;
      
        return v_qtde > 0;
      end;
    
      function isSetorCaixaMovimentacao(p_idSetor in number) return boolean is
        v_isUsoExclusivoCxMov number;
      begin
        select s.usoexclusivocxmov
          into v_isUsoExclusivoCxMov
          from setor s
         where s.idsetor = p_idSetor;
      
        return(v_isUsoExclusivoCxMov = 1);
      
      end;
    
    begin
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) = 'R')
         and existeTipoRecebimentoDiferente(p_idsetor, 'R') then
        v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE {0}.' ||
                           chr(13) ||
                           'O SETOR POSSUI OUTROS TIPOS DE RECEBIMENTO COM CLASSIFICAÇÃO DIFERENTE DE {1}.');
        v_msg.addParam(v_descrclassificacao);
        v_msg.addParam(v_descrclassificacao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) <> 'R')
         and existeTipoRecebimento(p_idsetor, 'R') then
        v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE {0}.' ||
                           chr(13) ||
                           'O SETOR POSSUI TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE REENTREGA.');
        v_msg.addParam(v_descrclassificacao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) = 'E')
         and existeTipoRecebimentoDiferente(p_idsetor, 'E') then
        v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE {0}.' ||
                           chr(13) ||
                           'O SETOR POSSUI OUTROS TIPOS DE RECEBIMENTO COM CLASSIFICAÇÃO DIFERENTE DE {1}.');
        v_msg.addParam(v_descrclassificacao);
        v_msg.addParam(v_descrclassificacao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) <> 'E')
         and existeTipoRecebimento(p_idsetor, 'E') then
        v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO {0}.' ||
                           chr(13) ||
                           'O SETOR POSSUI TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE ENCOMENDA.');
        v_msg.addParam(v_descrclassificacao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) = 'B') then
        if (existeTipoRecebimentoDiferente(p_idsetor, 'B')) then
          v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE {0}.' ||
                             chr(13) ||
                             'O SETOR POSSUI OUTROS TIPOS DE RECEBIMENTO COM CLASSIFICAÇÃO DIFERENTE DE {1}.');
          v_msg.addParam(v_descrclassificacao);
          v_msg.addParam(v_descrclassificacao);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select *
          into r_setor
          from setor s
         where s.idsetor = p_idsetor;
      
        if (r_setor.tipolocal <> 1 or r_setor.expedicao <> 'S' or
           r_setor.recebeamostra <> 0 or
           r_setor.sobraamostrarecebimento <> 0) then
          v_msg := t_message('Não é permitido vincular o tipo de recebimento com classificação de {0}.' ||
                             chr(13) ||
                             'O setor deve possuir a(s) seguinte(s) caracteristica(s) em seu cadastro:' ||
                             chr(13) || chr(13) ||
                             'Tipo de endereços: PULMÃO' || chr(13) ||
                             'Permite expedição de produto: SIM' || chr(13) ||
                             'Recebe amostra de materiais: NÃO' || chr(13) ||
                             'Recebe sobra de materiais da amostragem no recebimento: NÃO');
          v_msg.addParam(v_descrclassificacao);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end if;
    
      if (tipoClassificacao(p_idtiporecebimento, v_descrclassificacao) <> 'B')
         and (existeTipoRecebimento(p_idsetor, 'B')) then
        v_msg := t_message('NÃO É PERMITIDO VINCULAR O TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO {0}.' ||
                           chr(13) ||
                           'O SETOR POSSUI TIPO DE RECEBIMENTO COM CLASSIFICAÇÃO DE CROSSDOCKING.');
        v_msg.addParam(v_descrclassificacao);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (isSetorPerda(p_idsetor)) then
        v_msg := t_message('Não é permitido vincular tipos de recebimento a um setor de perdas.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (isSetorInsucessoEntrega(p_idsetor)) then
        v_msg := t_message('Não é permitido vincular tipos de recebimento a um setor de Devolução/Insucesso de Entrega.');
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      if (isSetorCaixaMovimentacao(p_idsetor)) then
        v_msg := t_message('Não é permitido vincular tipos de recebimento a um setor de uso exclusivo para caixa de movimentação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end;
  
  begin
    validarAddTipoRecebimento(p_idsetor, p_idtiporecebimento);
  
    insert into setorrecebimento
      (idsetor, idtiporecebimento)
    values
      (p_idsetor, p_idtiporecebimento);
  
  end;

  procedure isLocalCaixaMovimentacao
  (
    p_idArmazem in number,
    p_local     in varchar2
  ) is
    v_usoexclusivocxmov setor.usoexclusivocxmov%type;
    v_setordescricao    setor.descr%type;
  begin
    begin
      select s.usoexclusivocxmov, s.descr
        into v_usoexclusivocxmov, v_setordescricao
        from local l, setor s
       where l.idlocal = p_local
         and l.idarmazem = p_idarmazem
         and s.idsetor = l.idsetor;
    exception
      when no_data_found then
        v_msg := t_message('O local "{0}" não possui nenhum setor vinculado.');
        v_msg.addParam(p_local);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_usoexclusivocxmov = 1) then
      v_msg := t_message('Não é permitido utilizar o local "{0}", pois está vinculado ao setor "{1}" que está parametrizado para utilizar caixa de movimentação.');
      v_msg.addParam(p_local);
      v_msg.addParam(v_setorDescricao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  procedure addLocalAll
  (
    p_idSetor in number,
    idUsuario in number
  ) is
    V_log                   VARCHAR2(512);
    v_qtdRegistrosAlterados number := 0;
  begin
    for c in (select l.idlocal, l.id
                from gtt_selecao v, local l
               where l.id = v.idselecionado)
    loop
      update local l
         set l.idsetor = p_idSetor
       where l.id = c.id;
    
      update local lc
         set lc.idsetor = p_idSetor
       where lc.id in (select l.id
                         from local l
                        where l.idlocaldoca = c.id
                          and l.tipo = C_SUBDOCA);
    
      V_log := 'Tela: Vincular Endereço no Setor - Vinculou o Endereço idLocal: [' ||
               c.idlocal || '] no Setor idSetor: [' || p_idSetor || ']';
      pk_utilities.GeraLog(idUsuario, V_log, p_idSetor, 'CA');
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      --Realizando COmmit parcial dos registros alterados para evitar grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    end loop;
    commit;
  end addLocalAll;

  procedure removeLocalAll
  (
    p_idSetor in number,
    idUsuario in number
  ) is
    V_log                   VARCHAR2(512);
    v_qtdRegistrosAlterados number := 0;
  begin
    for c in (select l.idlocal, l.id
                from gtt_selecao v, local l
               where l.id = v.idselecionado
                 and l.idsetor = p_idsetor)
    loop
      update local l
         set l.idsetor = null
       where l.id = c.id
         and l.idsetor = p_idSetor;
    
      update local lc
         set lc.idsetor = null
       where lc.id in (select l.id
                         from local l
                        where l.idlocaldoca = c.id
                          and l.tipo = C_SUBDOCA
                          and l.idsetor = p_idSetor);
    
      V_log := 'Tela: Vincular Endereço no Setor - Desvinculou o Endereço idLocal: [' ||
               c.idlocal || '] do Setor idSetor: [' || p_idSetor || ']';
      pk_utilities.GeraLog(idUsuario, V_log, p_idSetor, 'CA');
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      --Realizando COmmit parcial dos registros alterados para evitar grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    end loop;
    commit;
  end removeLocalAll;

  procedure removeProdutoAll
  (
    p_idSetor in number,
    idUsuario in number
  ) is
    V_log                   VARCHAR2(512);
    v_qtdRegistrosAlterados number := 0;
  begin
    for c in (select p.idproduto
                from gtt_selecao v, produto p
               where p.idproduto = v.idselecionado
                 and exists (select 1
                        from setorproduto sp
                       where sp.idproduto = p.idproduto
                         and sp.idsetor = p_idSetor))
    loop
      delete from setorproduto sp
       where sp.idsetor = p_idSetor
         and sp.idproduto = c.idproduto;
      V_log := 'Tela: Vincular Produto no Setor - Desvinculou o Produto idProduto: [' ||
               c.idproduto || '] do Setor idSetor: [' || p_idSetor || ']';
    
      pk_utilities.GeraLog(idUsuario, V_log, p_idSetor, 'CA');
    
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      --Realizando COmmit parcial dos registros alterados para evitar grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    end loop;
    commit;
  end removeProdutoAll;

  procedure alteraLocal
  (
    p_idSetor    in number,
    p_idEndereco in number
  ) is
  
  begin
    -- Aqui está desvinculando um endereço
    if (nvl(p_idSetor, 0) = 0) then
      update local l
         set l.idsetor = null
       where l.id = p_idEndereco;
    
      update local lc
         set lc.idsetor = null
       where lc.id in (select l.id
                         from local l
                        where l.idlocaldoca = p_idEndereco
                          and l.tipo = C_SUBDOCA);
    
    else
      -- Aqui está vinculando um endereço  
      update local l
         set l.idsetor = p_idSetor
       where l.id = p_idEndereco;
    
      update local lc
         set lc.idsetor = p_idSetor
       where lc.id in (select l.id
                         from local l
                        where l.idlocaldoca = p_idEndereco
                          and l.tipo = C_SUBDOCA);
    end if;
  end alteraLocal;

  procedure vincularSetorProduto
  (
    p_idSetor    in number,
    p_idproduto  in number,
    p_idusuario  in number,
    p_log        in varchar2,
    p_prioridade in number
  ) is
    v_extiste   number;
    v_idusuario number;
  begin
    select count(*)
      into v_extiste
      from setorproduto sp
     where sp.idproduto = p_idproduto
       and sp.idsetor = p_idSetor;
  
    if (p_idusuario = 0) then
      select nvl(idusuariointegracao, 0) idusuario
        into v_idusuario
        from configuracao;
    end if;
  
    if (v_extiste = 0) then
      insert into setorproduto
        (idproduto, idsetor, prioridade)
      values
        (p_idproduto, p_idSetor, p_prioridade);
    
      pk_utilities.GeraLog(v_idusuario, p_log, p_idSetor, 'CA');
    end if;
  end vincularSetorProduto;

  procedure addClassifMatPerigosos
  (
    p_idSetor              in number,
    p_idClassifMatPerigoso in number
  ) is
    v_existe number;
  begin
    select count(*)
      into v_existe
      from setorclassificacaomatperigoso smp
     where smp.idsetor = p_idSetor
       and smp.idclassificacaomatperigoso = p_idClassifMatPerigoso;
  
    if (v_existe = 0) then
      insert into setorclassificacaomatperigoso
        (id, idsetor, idclassificacaomatperigoso)
      values
        (seq_setorclasomatperigoso.nextval, p_idSetor,
         p_idClassifMatPerigoso);
    end if;
  
  end addClassifMatPerigosos;

  procedure removeClassifMatPerigosos
  (
    p_idSetor              in number,
    p_idClassifMatPerigoso in number
  ) is
  begin
    delete from setorclassificacaomatperigoso smp
     where smp.idsetor = p_idSetor
       and smp.idclassificacaomatperigoso = p_idClassifMatPerigoso;
  end removeClassifMatPerigosos;

  procedure vincularProdutosAoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  ) is
  
    C_NAO constant number := 0;
    C_SIM constant number := 1;
  
    v_msgSucesso t_message;
    v_msgErro    t_message;
  
    v_log                      varchar2(512);
    v_msgDinamicaSetor         varchar2(30);
    v_msgDinamicaProduto       varchar2(30);
    v_msgDinamicaClassificacao varchar2(30);
    v_qtdRegistrosAlterados    number := 0;
    v_qtdeProdVinculado        number := 0;
    v_qtdeProdNaoVinculado     number := 0;
    v_qtdeErroClassificacao    number := 0;
    v_prodMaterialPerigoso     number;
    v_count                    number;
    r_setor                    setor%rowtype;
  
    function produtoCompativelComSetor(p_idProduto in number) return boolean is
    
    begin
    
      -- Rotina responsável por validar se a classificação de material perigoso
      -- do setor é com a classificação de material perigoso do produto
      begin
        select count(1), pd.materialperigoso
          into v_count, v_prodMaterialPerigoso
          from setor s, setordepositante sd, produtodepositante pd
         where s.idsetor = p_idSetor
           and sd.idsetor = s.idsetor
           and pd.identidade = sd.iddepositante
           and pd.idproduto = p_idProduto
           and s.materiaisperigosos != pd.materialperigoso
         group by pd.materialperigoso;
      exception
        when no_data_found then
          v_count                := 0;
          v_prodMaterialPerigoso := r_setor.materiaisperigosos;
      end;
    
      return v_count = 0;
    
    end produtoCompativelComSetor;
  
    procedure inserirSetorProduto
    (
      p_idProduto    in number,
      p_idPrioridade in number
    ) is
    
    begin
    
      insert into setorproduto sp
        (idproduto, idsetor, prioridade)
      values
        (p_idProduto, p_idSetor, p_idPrioridade);
    
      v_log := 'Tela: Vincular Produto no Setor - Vinculou o Produto idProduto: [' ||
               p_idProduto || '] no Setor idSetor: [' || p_idSetor || ']';
    
      pk_utilities.GeraLog(p_idUsuario, v_log, p_idSetor, 'CA');
    
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      v_qtdeProdVinculado     := v_qtdeProdVinculado + 1;
    
      -- Realizando commit parcial dos registros alterados para evitar
      -- grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    
    end inserirSetorProduto;
  
    procedure validarClassificaMaterPerigoso
    (
      p_idProduto    in number,
      p_idPrioridade in number
    ) is
    begin
      -- Verificar se a classificação de material perigoso que está no setor
      -- é compatível com a classificação da produto depositante
      for rec_prodDep in (select nvl(pd.idclassificacaomatperigoso, -1) infPrdDep,
                                 nvl(scmt.idclassificacaomatperigoso, -2) infSetor
                            from produtodepositante pd, setordepositante sd,
                                 setorclassificacaomatperigoso scmt
                           where pd.idproduto = p_idProduto
                             and sd.iddepositante = pd.identidade
                             and sd.idsetor = p_idSetor
                             and scmt.idsetor = sd.idsetor)
      loop
        if (rec_prodDep.infPrdDep = rec_prodDep.infSetor) then
          inserirSetorProduto(p_idProduto, p_idPrioridade);
        else
          v_qtdeErroClassificacao := v_qtdeErroClassificacao + 1;
        end if;
      end loop;
    end validarClassificaMaterPerigoso;
  
  begin
  
    select s.*
      into r_setor
      from setor s
     where s.idsetor = p_idSetor;
  
    for rec in (select g.valor1 idProduto, g.valor2 prioridade
                  from gtt_aux g
                 where not exists (select 1
                          from setorproduto sp
                         where sp.idsetor = p_idSetor
                           and sp.idproduto = g.valor1))
    loop
      if (r_setor.devolucaofornecedor = C_NAO) then
        if (produtoCompativelComSetor(rec.idproduto))
           and (isSetorTipoProdutoValido(rec.idproduto, p_idSetor)) then
          if (r_setor.materiaisperigosos = C_SIM and
             v_prodMaterialPerigoso = C_SIM) then
            validarClassificaMaterPerigoso(rec.idproduto, rec.prioridade);
          else
            inserirSetorProduto(rec.idproduto, rec.prioridade);
          end if;
        elsif (not isSetorTipoProdutoValido(rec.idproduto, p_idSetor)) then
        
          select decode(r_setor.produtosespeciais, C_SIM,
                         'Setor para Produto Especial',
                         'Setor para Produto não Especial'),
                 decode(r_setor.produtosespeciais, C_SIM,
                         'Tipo Produto diferente', 'Tipo Produto Permitido')
            into v_msgDinamicaSetor, v_msgDinamicaProduto
          
            from dual;
        
          v_qtdeProdNaoVinculado := v_qtdeProdNaoVinculado + 1;
        else
          select decode(r_setor.materiaisperigosos, C_SIM,
                         'Setor para Material Perigoso',
                         'Setor para Material Normal')
            into v_msgDinamicaSetor
            from dual;
        
          select decode(v_prodMaterialPerigoso, C_SIM, 'Material Perigoso',
                         'Material Normal')
            into v_msgDinamicaProduto
            from dual;
        
          v_qtdeProdNaoVinculado := v_qtdeProdNaoVinculado + 1;
        end if;
      
      else
        inserirSetorProduto(rec.idproduto, rec.prioridade);
      
      end if;
    
    end loop;
  
    commit;
  
    if (v_qtdeProdVinculado > 0) then
      v_msgSucesso := t_message('Foram vinculados {0} produtos ao setor.');
      v_msgSucesso.addParam(v_qtdeProdVinculado);
      pk_gttresumoexecucao.addResumo('Sucesso', v_msgSucesso.formatMessage,
                                     pk_gttresumoexecucao.TIPO_SUCESSO);
    else
      v_msg := t_message('Não foi vinculado nenhum produto ao setor.');
      pk_gttresumoexecucao.addResumo('Alerta', v_msg.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ALERTA);
    end if;
  
    if (v_qtdeProdNaoVinculado > 0) then
      v_msgErro := t_message('{0} Produto(s) não foi(ram) vinculado(s) ao setor, pois são incompatíveis.');
      v_msgErro.addParam(v_qtdeProdNaoVinculado);
      pk_gttresumoexecucao.addResumo(v_msgDinamicaSetor || ' não aceita ' ||
                                     v_msgDinamicaProduto,
                                     v_msgErro.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    if (v_qtdeErroClassificacao > 0) then
      v_msgErro := t_message('{0} Produto(s) não foi(ram) vinculado(s) ao setor, pois tem classificação de material perigoso incompatíveis.');
      v_msgErro.addParam(v_qtdeErroClassificacao);
      pk_gttresumoexecucao.addResumo('Classificação de Material Perigoso incompatível',
                                     v_msgErro.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
  end vincularProdutosAoSetor;

  function isSetorTipoProdutoValido
  (
    p_idProduto in produto.idproduto%type,
    p_idSetor   in setor.idsetor%type
  ) return boolean is
    v_setor    setor%rowtype;
    v_produto  produto%rowtype;
    v_controle number := 0;
  begin
  
    select *
      into v_setor
      from setor s
     where s.idsetor = p_idSetor;
  
    select *
      into v_produto
      from produto p
     where p.idproduto = p_idProduto;
  
    if (v_setor.produtosespeciais = 0) then
      return true;
    end if;
  
    select count(*)
      into v_controle
      from setortipoproduto s
     where s.idsetor = v_setor.idsetor
       and s.idtipoproduto = v_produto.idTipo;
  
    return v_controle > 0;
  
  end isSetorTipoProdutoValido;

  /**
  * Vincula "TipoProduto" ao "Setor"
  * desde que esteja com a flag "ProdutosEspeciais" ativado
  */
  procedure vincularTipoProdutoAoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  ) is
    v_msgSucesso            t_message;
    v_msgErro               t_message;
    v_log                   varchar2(512);
    r_setor                 setor%rowtype;
    v_qtdRegistrosAlterados number;
    v_qtdeProdVinculado     number;
    v_count                 number;
  
    procedure inserirSetorTipoProduto(p_idTipoProduto in number) is
    
    begin
    
      insert into setortipoproduto stp
        (idsetortipoproduto, idsetor, idtipoproduto)
      values
        (seq_setortipoproduto.nextval, p_idSetor, p_idTipoProduto);
    
      v_log := 'Tela: Vincular Tipo Produto no Setor - Vinculou o Tipo Produto idTipo: [' ||
               p_idTipoProduto || '] no Setor idSetor: [' || p_idSetor || ']';
    
      pk_utilities.GeraLog(p_idUsuario, v_log, p_idSetor, 'CA');
    
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      v_qtdeProdVinculado     := v_qtdeProdVinculado + 1;
    
      -- Realizando commit parcial dos registros alterados para evitar
      -- grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    end inserirSetorTipoProduto;
  
  begin
  
    v_qtdeProdVinculado     := 0;
    v_qtdRegistrosAlterados := 0;
  
    select s.*
      into r_setor
      from setor s
     where s.idsetor = p_idSetor;
  
    if r_setor.materiaisperigosos = 1 then
      v_msgErro := t_message('Não é possível víncular Tipo de Produto em Setor de Materiais Perigosos (Hazmat).');
      pk_gttresumoexecucao.addResumo('Setor incompatível',
                                     v_msgErro.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
    if r_setor.produtosespeciais = 0 then
      v_msgErro := t_message('Setor não habilitado para víncular Tipo de Produto. Ativar o parâmetro Produtos Especiais.');
      pk_gttresumoexecucao.addResumo('Setor não configurado',
                                     v_msgErro.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    for rec in (select g.idselecionado idtipoproduto
                  from gtt_selecao g
                 where not exists
                 (select 1
                          from setortipoproduto stp
                         where stp.idsetor = p_idSetor
                           and stp.idtipoproduto = g.idselecionado))
    loop
      inserirSetorTipoProduto(rec.idtipoproduto);
    end loop;
  
    if (v_qtdeProdVinculado > 0) then
      v_msgSucesso := t_message('Foram vinculado(s) {0} Tipo(s) de Produto(s) do setor.');
      v_msgSucesso.addParam(v_qtdeProdVinculado);
      pk_gttresumoexecucao.addResumo('Sucesso', v_msgSucesso.formatMessage,
                                     pk_gttresumoexecucao.TIPO_SUCESSO);
    else
      v_msg := t_message('Não foi vinculado nenhum Tipo de Produto ao setor.');
      pk_gttresumoexecucao.addResumo('Alerta', v_msg.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ALERTA);
    end if;
  
  end vincularTipoProdutoAoSetor;

  procedure removeTipoProdutoDoSetor
  (
    p_idUsuario in number,
    p_idSetor   in number
  ) is
    v_count                       number;
    v_log                         varchar2(512);
    v_qtdRegistrosAlterados       number;
    v_qtdeProdRemovido            number;
    v_qtdeProdutoVinculadoAoSetor number;
    v_msgSucesso                  t_message;
    v_msgErro                     t_message;
  
    procedure removeSetorTipoProduto(p_idTipoProduto in number) is
    
    begin
    
      delete from setortipoproduto stp
       where stp.idsetor = p_idSetor
         and stp.idtipoproduto = p_idTipoProduto;
    
      v_log := 'Tela: Vincular Tipo Produto no Setor - Desvinculou o Tipo Produto idTipo: [' ||
               p_idTipoProduto || '] no Setor idSetor: [' || p_idSetor || ']';
    
      pk_utilities.GeraLog(p_idUsuario, v_log, p_idSetor, 'CA');
    
      v_qtdRegistrosAlterados := v_qtdRegistrosAlterados + 1;
      v_qtdeProdRemovido      := v_qtdeProdRemovido + 1;
    
      -- Realizando commit parcial dos registros alterados para evitar
      -- grande acúmulo de dados em rollback e prevenir lentidão
      if (v_qtdRegistrosAlterados >= 1000) then
        commit;
        v_qtdRegistrosAlterados := 0;
      end if;
    end removeSetorTipoProduto;
  
    -- Verifica se existe estoque do produto por tipo de produto
    function estoqueProdutoPorTipo(p_idTipoProduto number) return boolean is
      v_qtdeEstoque number;
    begin
      begin
        select count(1)
          into v_qtdeEstoque
          from lote l, lotelocal ll, produto p, local loc
         where ll.idlote = l.idlote
           and loc.idlocal = ll.idlocal
           and p.idproduto = l.idproduto
           and p.idtipo = p_idTipoProduto
           and loc.idsetor = p_idSetor
           and (ll.estoque > 0 or ll.pendencia > 0 or ll.adicionar > 0);
      exception
        when no_data_found then
          v_qtdeEstoque := 0;
      end;
      return v_qtdeEstoque > 0;
    end estoqueProdutoPorTipo;
  
  begin
  
    v_qtdeProdRemovido            := 0;
    v_qtdRegistrosAlterados       := 0;
    v_qtdeProdutoVinculadoAoSetor := 0;
  
    for rec in (select g.idselecionado idtipoproduto
                  from gtt_selecao g)
    loop
      if estoqueProdutoPorTipo(rec.idtipoproduto) then
        v_qtdeProdutoVinculadoAoSetor := v_qtdeProdutoVinculadoAoSetor + 1;
        v_log                         := 'Tela: Vincular Tipo Produto no Setor - Não é possível desvincular "Tipo de Produto": [' ||
                                         rec.idtipoproduto ||
                                         '] em "Setor" : [' || p_idSetor ||
                                         '] com produto(s) já vinculado(s) com estoque ';
      
        pk_utilities.GeraLog(p_idUsuario, v_log, p_idSetor, 'CA');
      else
        removeSetorTipoProduto(rec.idtipoproduto);
      end if;
    
    end loop;
  
    if v_qtdeProdutoVinculadoAoSetor > 0 then
      v_msgErro := t_message('{0} Tipo(s) de Produto(s) não foram removido(s) pois já possue(m) produto(s) com estoque vinculado(s) no Setor.');
      v_msgErro.addParam(v_qtdeProdutoVinculadoAoSetor);
      pk_gttresumoexecucao.addResumo('Tipo de Produto com vínculos',
                                     v_msgErro.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ERRO);
    end if;
  
    if (v_qtdeProdRemovido > 0) then
      v_msgSucesso := t_message('Foram removido(s) {0} Tipo(s) de Produto(s) do setor.');
      v_msgSucesso.addParam(v_qtdeProdRemovido);
      pk_gttresumoexecucao.addResumo('Sucesso', v_msgSucesso.formatMessage,
                                     pk_gttresumoexecucao.TIPO_SUCESSO);
    else
      v_msg := t_message('Não foi removido nenhum tipo de produto do setor.');
      pk_gttresumoexecucao.addResumo('Alerta', v_msg.formatMessage,
                                     pk_gttresumoexecucao.TIPO_ALERTA);
    end if;
  end removeTipoProdutoDoSetor;

end pk_setor;
/

