create package body pk_prioridadeCheckoutExpress is

  v_nivelPrioridade number;
  v_idMovimentacao  number;

  type rec_priori is record(
    criterio     varchar2(100),
    qtdeCriterio number);

  type cursor_priori is ref cursor;

  function getMovimentacaoPrioritaria
  (
    p_idCaixaSeparacao in number,
    p_idProduto        in number,
    p_idDepositante    in number
  ) return number is
    v_idOnda           number;
    v_furaFila         number;
    v_idMovimentacaoOk number;
    v_prioriAtual      number;
    v_dataEspEmbarque  varchar2(20);
    v_idTransportadora number;
    v_uf               varchar2(2);
    v_idServTransp     number;
    v_msg              t_message;
  
    function temNfFuraFila return number is
      v_qtdNfFuraFila number;
    begin
      select count(nf.idnotafiscal)
        into v_qtdNfFuraFila
        from nfromaneio nfr, movimentacao m, notafiscal nf, lote l
       where nfr.idromaneio = m.idonda
         and nfr.idnotafiscal = m.idnotafiscal
         and nfr.idnotafiscal = nf.idnotafiscal
         and m.idlote = l.idlote
         and l.iddepositante = p_idDepositante
         and l.idproduto = p_idProduto
         and nfr.idromaneio = v_idOnda
         and m.status not in (3, 4)
         and nf.furafila = C_FURA_FILA_ATIVADO
         and m.qtdeconferida > m.qtdeemvolume
         and not exists
       (select 1
                from volumeromaneio vr
               where vr.idvolumeromaneio = m.idvolumeromaneio);
      return v_qtdNfFuraFila;
    end;
  
  begin
  
    v_nivelPrioridade := null;
    v_idMovimentacao  := null;
  
    select m.idonda
      into v_idOnda
      from conteudocarrinho cc, movimentacao m
     where cc.idcaixaseparacao = p_idCaixaSeparacao
       and m.id = cc.idmovimentacao
       and m.status not in (3, 4)
       and rownum = 1;
  
    if temNfFuraFila > 0 then
      v_furaFila := C_FURA_FILA_ATIVADO;
    else
      v_furaFila := C_FURA_FILA_DESATIVADO;
    end if;
  
    pk_prioridadeCheckoutExpress.determinarProxPrioridade(v_idOnda,
                                                          v_prioriAtual);
  
    if v_prioriAtual = C_PRIORIDADE_DT_ESP_EMBARQUE then
      v_idMovimentacao := getPrioriDataEspEmbarque(v_idOnda, p_idproduto,
                                                   p_iddepositante,
                                                   v_furaFila,
                                                   v_dataEspEmbarque,
                                                   v_idTransportadora, v_uf,
                                                   v_idServTransp);
    elsif v_prioriAtual = C_PRIORIDADE_TRANSPORTADORA then
      v_idMovimentacao := getPrioriTransportadora(v_idOnda, p_idproduto,
                                                  p_iddepositante, v_furaFila,
                                                  v_dataEspEmbarque,
                                                  v_idTransportadora, v_uf,
                                                  v_idServTransp);
    elsif v_prioriAtual = C_PRIORIDADE_UF then
      v_idMovimentacao := getPrioriUf(v_idOnda, p_idproduto, p_iddepositante,
                                      v_furaFila, v_dataEspEmbarque,
                                      v_idTransportadora, v_uf,
                                      v_idServTransp);
    elsif v_prioriAtual = C_PRIORIDADE_SERVICO_TRANSP then
      v_idMovimentacao := getPrioriServTransp(v_idOnda, p_idproduto,
                                              p_iddepositante, v_furaFila,
                                              v_dataEspEmbarque,
                                              v_idTransportadora, v_uf,
                                              v_idServTransp);
    end if;
  
    begin
      select m.id
        into v_idMovimentacaoOk
        from movimentacao m, lote lt
       where m.id = v_idMovimentacao
         and m.idonda = v_idOnda
         and lt.idlote = m.idlote
         and lt.idproduto = p_idProduto
         and lt.iddepositante = p_idDepositante
         and m.qtdeemvolume = 0
         and m.status not in (3, 4)
         and m.idvolumeromaneio is null;
    exception
      when others then
        v_msg := t_message('A movimentação ({0}) encontrada na seleção por prioridade do Checkout Express não condiz com os parâmetros de entrada da onda.');
        v_msg.addParam(v_idMovimentacao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    return v_idMovimentacao;
  
  end;

  procedure montarSqlPrioridade
  (
    p_sql                  in out varchar2,
    p_idOnda               in number,
    p_idproduto            in number,
    p_iddepositante        in number,
    p_furaFila             in number,
    p_criterioPrioridade   in number,
    p_dataEsperadaEmbarque in varchar2 default null,
    p_idTransportadora     in number default null,
    p_Uf                   in varchar2 default null,
    p_idServTransp         in number default null
  ) is
  
    v_groupBy varchar2(100) := ' group by ';
    v_orderBy varchar2(100) := ' order by ';
    v_compl   varchar2(100);
  
  begin
  
    if p_criterioPrioridade = C_PRIORIDADE_DT_ESP_EMBARQUE then
      p_sql     := 'select to_char(nf.dataesperadaembarque,''dd/mm/yyyy hh24:mi:ss'') dataesperadaembarque, count(1) qtdeNfMesmaData ';
      v_groupBy := v_groupBy || 'nf.dataesperadaembarque';
      v_orderBy := v_orderBy || 'nf.dataesperadaembarque';
    elsif p_criterioPrioridade = C_PRIORIDADE_TRANSPORTADORA then
      p_sql     := 'select nf.transportadoranotafiscal, count(1) qtdeNfMesmaTransp ';
      v_groupBy := v_groupBy || 'nf.transportadoranotafiscal';
      v_orderBy := v_orderBy || 'nf.transportadoranotafiscal';
    elsif p_criterioPrioridade = C_PRIORIDADE_UF then
      p_sql     := 'select c.estadocidade, count(1) qtdeNfMesmaUf ';
      v_groupBy := v_groupBy || 'c.estadocidade';
      v_orderBy := v_orderBy || 'c.estadocidade';
    elsif p_criterioPrioridade = C_PRIORIDADE_SERVICO_TRANSP then
      p_sql     := 'select nf.idservicotransportadora, count(1) qtdeNfMesmoServTransp ';
      v_groupBy := v_groupBy || 'nf.idservicotransportadora';
      v_orderBy := v_orderBy || 'nf.idservicotransportadora';
    else
      p_sql     := 'select idmovimentacao from (select m.id idmovimentacao, nf.idnotafiscal ';
      v_groupBy := null;
      v_orderBy := v_orderBy || 'nf.idnotafiscal)';
      v_compl   := ' where rownum = 1';
    end if;
  
    p_sql := p_sql || 'from movimentacao m, notafiscal nf, lote l, endereco en, cidade c
                    where m.idnotafiscal = nf.idnotafiscal
                      and m.idlote = l.idlote
                      and m.status not in (3, 4)
                      and m.idonda = ' || p_idOnda || '
                      and l.idproduto = ' || p_idproduto || '
                      and l.iddepositante = ' ||
             p_iddepositante || '
                      and nf.ident_entrega = en.identidade
                      and en.idcidade = c.idcidade
                      and en.idendereco = pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
                      and nf.furafila = ' || p_furaFila || '
                      and m.qtdeconferida > m.qtdeemvolume
                      and not exists
                    (select 1
                       from volumeromaneio vr
                      where vr.idvolumeromaneio = m.idvolumeromaneio)';
  
    if p_dataEsperadaEmbarque is not null then
      p_sql := p_sql ||
               ' and to_char(nf.dataesperadaembarque,''dd/mm/yyyy hh24:mi:ss'') = ' || '''' ||
               p_dataEsperadaEmbarque || '''';
    end if;
  
    if p_idTransportadora is not null then
      p_sql := p_sql || ' and nf.transportadoranotafiscal = ' ||
               p_idTransportadora;
    end if;
  
    if p_Uf is not null then
      p_sql := p_sql || ' and c.estadocidade = ' || '''' || p_Uf || '''';
    end if;
  
    if p_idServTransp is not null then
      p_sql := p_sql || ' and nf.idservicotransportadora = ' ||
               p_idServTransp;
    end if;
  
    p_sql := p_sql || ' ' || v_groupBy || v_orderBy || v_compl;
  
  end;

  procedure determinarProxPrioridade
  (
    p_idOnda      in number,
    p_prioriAtual in out number
  ) is
  begin
  
    p_prioriAtual := 0;
  
    for r_priori in (select cp.idtipoprioridade, cp.prioridade
                       from romaneiopai rp, confondaprioridade cp
                      where rp.idromaneio = p_idOnda
                        and cp.idconfiguracaoonda = rp.idconfiguracaoonda
                        and cp.prioridade > nvl(v_nivelPrioridade, 0)
                      order by cp.prioridade)
    loop
      p_prioriAtual     := r_priori.idtipoprioridade;
      v_nivelPrioridade := nvl(v_nivelPrioridade, 0) + 1;
      exit when p_prioriAtual > 0;
    end loop;
  
  end;

  function getPrioriDataEspEmbarque
  (
    p_idOnda           in number,
    p_idproduto        in number,
    p_iddepositante    in number,
    p_furaFila         in number,
    p_dataEspEmbarque  in out varchar2,
    p_idTransportadora in out number,
    p_uf               in out varchar2,
    p_idServTransp     in out number
  ) return number is
    v_sql             varchar2(10000);
    v_cursor          cursor_priori;
    r                 rec_priori;
    v_prioriAtual     number;
    v_nivelPrioridade varchar2(30) := 'Data Esperada de Embarque';
    v_msg             t_message;
  begin
  
    montarSqlPrioridade(v_sql, p_idOnda, p_idproduto, p_iddepositante,
                        p_furaFila, C_PRIORIDADE_DT_ESP_EMBARQUE,
                        p_dataEspEmbarque, p_idTransportadora, p_uf,
                        p_idServTransp);
  
    if v_cursor%isopen then
      close v_cursor;
    end if;
  
    open v_cursor for(v_sql);
  
    loop
      if v_idMovimentacao is not null then
        return(v_idMovimentacao);
      end if;
      fetch v_cursor
        into r;
      exit when v_cursor%notfound;
      if r.qtdeCriterio = 1 then
        begin
          select m.id
            into v_idMovimentacao
            from movimentacao m, notafiscal nf, lote l, endereco en,
                 cidade c
           where m.idnotafiscal = nf.idnotafiscal
             and m.idlote = l.idlote
             and m.idonda = p_idOnda
             and m.status not in (3, 4)
             and l.idproduto = p_idproduto
             and l.iddepositante = p_iddepositante
             and nf.furafila = p_furaFila
             and nvl(to_char(nf.dataesperadaembarque,
                             'dd/mm/yyyy hh24:mi:ss'), '01/01/1900 00:00:00') =
                 nvl(r.criterio,
                     nvl(to_char(nf.dataesperadaembarque,
                                  'dd/mm/yyyy hh24:mi:ss'),
                          '01/01/1900 00:00:00'))
             and nf.ident_entrega = en.identidade
             and en.idendereco =
                 pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
             and en.idcidade = c.idcidade
             and c.estadocidade = nvl(p_uf, c.estadocidade)
             and nf.transportadoranotafiscal =
                 nvl(p_idTransportadora, nf.transportadoranotafiscal)
             and nvl(nf.idservicotransportadora, -1) =
                 nvl(p_idServTransp, nvl(nf.idservicotransportadora, -1))
             and m.qtdeconferida > m.qtdeemvolume
             and not exists
           (select 1
                    from volumeromaneio vr
                   where vr.idvolumeromaneio = m.idvolumeromaneio);
          return(v_idMovimentacao);
        exception
          when others then
            v_msg := t_message('Problemas ao recuperar a movimentação no nível de prioridade: {0}. {1}');
            v_msg.addParam(v_nivelPrioridade);
            v_msg.addParam(sqlerrm);
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      else
        determinarProxPrioridade(p_idOnda, v_prioriAtual);
        p_dataEspEmbarque := r.criterio;
        if v_prioriAtual = C_PRIORIDADE_TRANSPORTADORA then
          v_idMovimentacao := getPrioriTransportadora(p_idOnda, p_idproduto,
                                                      p_iddepositante,
                                                      p_furaFila,
                                                      p_dataEspEmbarque,
                                                      p_idTransportadora,
                                                      p_uf, p_idServTransp);
        elsif v_prioriAtual = C_PRIORIDADE_UF then
          v_idMovimentacao := getPrioriUf(p_idOnda, p_idproduto,
                                          p_iddepositante, p_furaFila,
                                          p_dataEspEmbarque,
                                          p_idTransportadora, p_uf,
                                          p_idServTransp);
        elsif v_prioriAtual = C_PRIORIDADE_SERVICO_TRANSP then
          v_idMovimentacao := getPrioriServTransp(p_idOnda, p_idproduto,
                                                  p_iddepositante, p_furaFila,
                                                  p_dataEspEmbarque,
                                                  p_idTransportadora, p_uf,
                                                  p_idServTransp);
        elsif v_prioriAtual = C_PRIORIDADE_INDEFINIDA then
          v_idMovimentacao := prioridadeIndefinida(p_idOnda, p_idproduto,
                                                   p_iddepositante,
                                                   p_furaFila,
                                                   p_dataEspEmbarque,
                                                   p_idTransportadora, p_uf,
                                                   p_idServTransp);
        end if;
      end if;
    end loop;
  
    return(v_idMovimentacao);
  
  end;

  function getPrioriTransportadora
  (
    p_idOnda           in number,
    p_idproduto        in number,
    p_iddepositante    in number,
    p_furaFila         in number,
    p_dataEspEmbarque  in out varchar2,
    p_idTransportadora in out number,
    p_uf               in out varchar2,
    p_idServTransp     in out number
  ) return number is
    v_sql             varchar2(10000);
    v_cursor          cursor_priori;
    r                 rec_priori;
    v_prioriAtual     number;
    v_nivelPrioridade varchar2(30) := 'Transportadora';
    v_msg             t_message;
  begin
  
    for r_transp in (select identidade
                       from (select pt.identidade, 1 ordem, pt.prioridade
                                from prioridadetransportadora pt, entidade e,
                                     romaneiopai rp
                               where rp.idromaneio = p_idOnda
                                 and pt.idconfiguracaoonda =
                                     rp.idconfiguracaoonda
                                 and e.identidade = pt.identidade
                              union
                              select e.identidade, 2 ordem, null prioridade
                                from entidade e,
                                     (select distinct nf.transportadoranotafiscal
                                         from nfromaneio nfr, notafiscal nf
                                        where nfr.idnotafiscal = nf.idnotafiscal
                                          and nfr.idromaneio = p_idOnda) t
                               where e.identidade = t.transportadoranotafiscal
                                 and not exists
                               (select 1
                                        from prioridadetransportadora pt,
                                             entidade en, romaneiopai rp
                                       where rp.idromaneio = p_idOnda
                                         and pt.idconfiguracaoonda =
                                             rp.idconfiguracaoonda
                                         and en.identidade = pt.identidade
                                         and en.identidade = e.identidade))
                      order by ordem, prioridade, identidade)
    loop
    
      if v_idMovimentacao is not null then
        return(v_idMovimentacao);
      end if;
    
      p_idTransportadora := r_transp.identidade;
    
      montarSqlPrioridade(v_sql, p_idOnda, p_idproduto, p_iddepositante,
                          p_furaFila, C_PRIORIDADE_TRANSPORTADORA,
                          p_dataEspEmbarque, p_idTransportadora, p_uf,
                          p_idServTransp);
    
      if v_cursor%isopen then
        close v_cursor;
      end if;
    
      open v_cursor for(v_sql);
    
      loop
        fetch v_cursor
          into r;
        exit when v_cursor%notfound;
        if r.qtdeCriterio = 1 then
          begin
            select m.id
              into v_idMovimentacao
              from movimentacao m, notafiscal nf, lote l, endereco en,
                   cidade c
             where m.idnotafiscal = nf.idnotafiscal
               and m.idlote = l.idlote
               and m.idonda = p_idOnda
               and l.idproduto = p_idproduto
               and l.iddepositante = p_iddepositante
               and nf.furafila = p_furaFila
               and m.status not in (3, 4)
               and nf.ident_entrega = en.identidade
               and en.idendereco =
                   pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
               and en.idcidade = c.idcidade
               and nf.transportadoranotafiscal = r.criterio
               and c.estadocidade = nvl(p_uf, c.estadocidade)
               and nvl(to_char(nf.dataesperadaembarque,
                               'dd/mm/yyyy hh24:mi:ss'),
                       '01/01/1900 00:00:00') =
                   nvl(p_dataEspEmbarque,
                       nvl(to_char(nf.dataesperadaembarque,
                                    'dd/mm/yyyy hh24:mi:ss'),
                            '01/01/1900 00:00:00'))
               and nvl(nf.idservicotransportadora, -1) =
                   nvl(p_idServTransp, nvl(nf.idservicotransportadora, -1))
               and m.qtdeconferida > m.qtdeemvolume
               and not exists
             (select 1
                      from volumeromaneio vr
                     where vr.idvolumeromaneio = m.idvolumeromaneio);
          exception
            when others then
              v_msg := t_message('Problemas ao recuperar a movimentação no nível de prioridade: {0}. {1}');
              v_msg.addParam(v_nivelPrioridade);
              v_msg.addParam(sqlerrm);
              raise_application_error(-20000, v_msg.formatMessage);
          end;
          return(v_idMovimentacao);
        else
          determinarProxPrioridade(p_idOnda, v_prioriAtual);
          p_idTransportadora := r.criterio;
          if v_prioriAtual = C_PRIORIDADE_DT_ESP_EMBARQUE then
            v_idMovimentacao := getPrioriDataEspEmbarque(p_idOnda,
                                                         p_idproduto,
                                                         p_iddepositante,
                                                         p_furaFila,
                                                         p_dataEspEmbarque,
                                                         p_idTransportadora,
                                                         p_uf, p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_UF then
            v_idMovimentacao := getPrioriUf(p_idOnda, p_idproduto,
                                            p_iddepositante, p_furaFila,
                                            p_dataEspEmbarque,
                                            p_idTransportadora, p_uf,
                                            p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_SERVICO_TRANSP then
            v_idMovimentacao := getPrioriServTransp(p_idOnda, p_idproduto,
                                                    p_iddepositante,
                                                    p_furaFila,
                                                    p_dataEspEmbarque,
                                                    p_idTransportadora, p_uf,
                                                    p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_INDEFINIDA then
            v_idMovimentacao := prioridadeIndefinida(p_idOnda, p_idproduto,
                                                     p_iddepositante,
                                                     p_furaFila,
                                                     p_dataEspEmbarque,
                                                     p_idTransportadora, p_uf,
                                                     p_idServTransp);
          end if;
        end if;
      end loop;
    
    end loop;
  
    return(v_idMovimentacao);
  
  end;

  function getPrioriUf
  (
    p_idOnda           in number,
    p_idproduto        in number,
    p_iddepositante    in number,
    p_furaFila         in number,
    p_dataEspEmbarque  in out varchar2,
    p_idTransportadora in out number,
    p_uf               in out varchar2,
    p_idServTransp     in out number
  ) return number is
    v_sql             varchar2(10000);
    v_cursor          cursor_priori;
    r                 rec_priori;
    v_prioriAtual     number;
    v_nivelPrioridade varchar2(30) := 'UF';
    v_msg             t_message;
  begin
  
    for r_uf in (select uf
                   from (select pe.uf, 1 ordem, pe.prioridade
                            from prioridadeestado pe, estado e, romaneiopai rp
                           where pe.idconfiguracaoonda = rp.idconfiguracaoonda
                             and e.idpais = pe.idpais
                             and e.uf = pe.uf
                             and rp.idromaneio = p_idOnda
                          
                          union
                          select c.estadocidade uf, 2 ordem, null prioridade
                            from nfromaneio nfr, notafiscal nf, endereco en,
                                 cidade c
                           where nfr.idnotafiscal = nf.idnotafiscal
                             and nf.ident_entrega = en.identidade
                             and en.idcidade = c.idcidade
                             and en.idendereco =
                                 pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
                             and nfr.idromaneio = p_idOnda
                             and nf.furafila = p_furaFila
                             and c.estadocidade not in
                                 (select pe.uf
                                    from prioridadeestado pe, estado e,
                                         romaneiopai rp
                                   where pe.idconfiguracaoonda =
                                         rp.idconfiguracaoonda
                                     and e.idpais = pe.idpais
                                     and e.uf = pe.uf
                                     and rp.idromaneio = p_idOnda))
                  order by ordem, prioridade, uf)
    loop
    
      if v_idMovimentacao is not null then
        return(v_idMovimentacao);
      end if;
    
      p_uf := r_uf.uf;
    
      montarSqlPrioridade(v_sql, p_idOnda, p_idproduto, p_iddepositante,
                          p_furaFila, C_PRIORIDADE_UF, p_dataEspEmbarque,
                          p_idTransportadora, p_uf, p_idServTransp);
    
      if v_cursor%isopen then
        close v_cursor;
      end if;
    
      open v_cursor for(v_sql);
    
      loop
        fetch v_cursor
          into r;
        exit when v_cursor%notfound;
        if r.qtdeCriterio = 1 then
          begin
            select m.id
              into v_idMovimentacao
              from movimentacao m, notafiscal nf, lote l, endereco en,
                   cidade c
             where m.idnotafiscal = nf.idnotafiscal
               and m.idlote = l.idlote
               and nf.ident_entrega = en.identidade
               and en.idendereco =
                   pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
               and en.idcidade = c.idcidade
               and m.idonda = p_idOnda
               and l.idproduto = p_idproduto
               and l.iddepositante = p_iddepositante
               and nf.furafila = p_furaFila
               and c.estadocidade = r.criterio
               and nvl(to_char(nf.dataesperadaembarque,
                               'dd/mm/yyyy hh24:mi:ss'),
                       '01/01/1900 00:00:00') =
                   nvl(p_dataEspEmbarque,
                       nvl(to_char(nf.dataesperadaembarque,
                                    'dd/mm/yyyy hh24:mi:ss'),
                            '01/01/1900 00:00:00'))
               and nf.transportadoranotafiscal =
                   nvl(p_idTransportadora, nf.transportadoranotafiscal)
               and nvl(nf.idservicotransportadora, -1) =
                   nvl(p_idServTransp, nvl(nf.idservicotransportadora, -1))
               and m.qtdeconferida > m.qtdeemvolume
               and m.status not in (3, 4)
               and not exists
             (select 1
                      from volumeromaneio vr
                     where vr.idvolumeromaneio = m.idvolumeromaneio);
          exception
            when others then
              v_msg := t_message('Problemas ao recuperar a movimentação no nível de prioridade: {0}. {1}');
              v_msg.addParam(v_nivelPrioridade);
              v_msg.addParam(sqlerrm);
              raise_application_error(-20000, v_msg.formatMessage);
          end;
          return(v_idMovimentacao);
        else
          determinarProxPrioridade(p_idOnda, v_prioriAtual);
          p_uf := r.criterio;
          if v_prioriAtual = C_PRIORIDADE_DT_ESP_EMBARQUE then
            v_idMovimentacao := getPrioriDataEspEmbarque(p_idOnda,
                                                         p_idproduto,
                                                         p_iddepositante,
                                                         p_furaFila,
                                                         p_dataEspEmbarque,
                                                         p_idTransportadora,
                                                         p_uf, p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_TRANSPORTADORA then
            v_idMovimentacao := getPrioriTransportadora(p_idOnda,
                                                        p_idproduto,
                                                        p_iddepositante,
                                                        p_furaFila,
                                                        p_dataEspEmbarque,
                                                        p_idTransportadora,
                                                        p_uf, p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_SERVICO_TRANSP then
            v_idMovimentacao := getPrioriServTransp(p_idOnda, p_idproduto,
                                                    p_iddepositante,
                                                    p_furaFila,
                                                    p_dataEspEmbarque,
                                                    p_idTransportadora, p_uf,
                                                    p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_INDEFINIDA then
            v_idMovimentacao := prioridadeIndefinida(p_idOnda, p_idproduto,
                                                     p_iddepositante,
                                                     p_furaFila,
                                                     p_dataEspEmbarque,
                                                     p_idTransportadora, p_uf,
                                                     p_idServTransp);
          end if;
        end if;
      end loop;
    
    end loop;
  
    return(v_idMovimentacao);
  
  end;

  function getPrioriServTransp
  (
    p_idOnda           in number,
    p_idproduto        in number,
    p_iddepositante    in number,
    p_furaFila         in number,
    p_dataEspEmbarque  in out varchar2,
    p_idTransportadora in out number,
    p_uf               in out varchar2,
    p_idServTransp     in out number
  ) return number is
    v_sql             varchar2(10000);
    v_cursor          cursor_priori;
    r                 rec_priori;
    v_prioriAtual     number;
    v_nivelPrioridade varchar2(30) := 'Serviço de Transporte';
    v_msg             t_message;
  begin
  
    for r_serv in (select idservicotransportadora
                     from (select st.idservicotransportadora, 1 ordem,
                                   st.prioridadecheckoutexpress
                              from servicotransportadora st, nfromaneio nfr,
                                   notafiscal nf, transpdepositante td
                             where nfr.idromaneio = p_idOnda
                               and nfr.idnotafiscal = nf.idnotafiscal
                               and td.idtransportadora =
                                   nf.transportadoranotafiscal
                               and td.iddepositante = nf.iddepositante
                               and st.idtranspdepositante =
                                   td.idtranspdepositante
                               and st.idservicotransportadora =
                                   nf.idservicotransportadora
                               and st.prioridadecheckoutexpress is not null
                               and nf.furafila = p_furaFila
                            union
                            select st.idservicotransportadora, 2 ordem,
                                   st.prioridadecheckoutexpress
                              from servicotransportadora st, nfromaneio nfr,
                                   notafiscal nf, transpdepositante td
                             where nfr.idromaneio = p_idOnda
                               and nfr.idnotafiscal = nf.idnotafiscal
                               and td.idtransportadora =
                                   nf.transportadoranotafiscal
                               and td.iddepositante = nf.iddepositante
                               and st.idtranspdepositante =
                                   td.idtranspdepositante
                               and st.idservicotransportadora =
                                   nf.idservicotransportadora
                               and st.prioridadecheckoutexpress is null
                               and nf.furafila = p_furaFila
                            union
                            select null idservicotransportadora, 3 ordem,
                                   null prioridadecheckoutexpress
                              from dual)
                    order by ordem, prioridadecheckoutexpress,
                             idservicotransportadora)
    loop
    
      if v_idMovimentacao is not null then
        return(v_idMovimentacao);
      end if;
    
      p_idServTransp := r_serv.idservicotransportadora;
    
      montarSqlPrioridade(v_sql, p_idOnda, p_idproduto, p_iddepositante,
                          p_furaFila, C_PRIORIDADE_SERVICO_TRANSP,
                          p_dataEspEmbarque, p_idTransportadora, p_uf,
                          p_idServTransp);
    
      if v_cursor%isopen then
        close v_cursor;
      end if;
    
      open v_cursor for(v_sql);
    
      loop
        fetch v_cursor
          into r;
        exit when v_cursor%notfound;
        if r.qtdeCriterio = 1 then
          begin
            select m.id
              into v_idMovimentacao
              from movimentacao m, notafiscal nf, lote l, endereco en,
                   cidade c
             where m.idnotafiscal = nf.idnotafiscal
               and m.idlote = l.idlote
               and m.idonda = p_idOnda
               and l.idproduto = p_idproduto
               and l.iddepositante = p_iddepositante
               and nf.furafila = p_furaFila
               and nvl(nf.idservicotransportadora, -1) =
                   nvl(r.criterio, nvl(nf.idservicotransportadora, -1))
               and nf.ident_entrega = en.identidade
               and en.idendereco =
                   pk_entidade.F_RET_IDENDERECO(nf.ident_entrega)
               and en.idcidade = c.idcidade
               and c.estadocidade = nvl(p_uf, c.estadocidade)
               and nvl(to_char(nf.dataesperadaembarque,
                               'dd/mm/yyyy hh24:mi:ss'),
                       '01/01/1900 00:00:00') =
                   nvl(p_dataEspEmbarque,
                       nvl(to_char(nf.dataesperadaembarque,
                                    'dd/mm/yyyy hh24:mi:ss'),
                            '01/01/1900 00:00:00'))
               and nf.transportadoranotafiscal =
                   nvl(p_idTransportadora, nf.transportadoranotafiscal)
               and m.qtdeconferida > m.qtdeemvolume
               and m.status not in (3, 4)
               and not exists
             (select 1
                      from volumeromaneio vr
                     where vr.idvolumeromaneio = m.idvolumeromaneio);
          exception
            when others then
              v_msg := t_message('Problemas ao recuperar a movimentação no nível de prioridade: {0}. {1}');
              v_msg.addParam(v_nivelPrioridade);
              v_msg.addParam(sqlerrm);
              raise_application_error(-20000, v_msg.formatMessage);
          end;
          return(v_idMovimentacao);
        else
          determinarProxPrioridade(p_idOnda, v_prioriAtual);
          p_idServTransp := r.criterio;
          if v_prioriAtual = C_PRIORIDADE_DT_ESP_EMBARQUE then
            v_idMovimentacao := getPrioriDataEspEmbarque(p_idOnda,
                                                         p_idproduto,
                                                         p_iddepositante,
                                                         p_furaFila,
                                                         p_dataEspEmbarque,
                                                         p_idTransportadora,
                                                         p_uf, p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_TRANSPORTADORA then
            v_idMovimentacao := getPrioriTransportadora(p_idOnda,
                                                        p_idproduto,
                                                        p_iddepositante,
                                                        p_furaFila,
                                                        p_dataEspEmbarque,
                                                        p_idTransportadora,
                                                        p_uf, p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_UF then
            v_idMovimentacao := getPrioriUf(p_idOnda, p_idproduto,
                                            p_iddepositante, p_furaFila,
                                            p_dataEspEmbarque,
                                            p_idTransportadora, p_uf,
                                            p_idServTransp);
          elsif v_prioriAtual = C_PRIORIDADE_INDEFINIDA then
            v_idMovimentacao := prioridadeIndefinida(p_idOnda, p_idproduto,
                                                     p_iddepositante,
                                                     p_furaFila,
                                                     p_dataEspEmbarque,
                                                     p_idTransportadora, p_uf,
                                                     p_idServTransp);
          end if;
        end if;
      end loop;
    
    end loop;
  
    return(v_idMovimentacao);
  
  end;

  function prioridadeIndefinida
  (
    p_idOnda           in number,
    p_idproduto        in number,
    p_iddepositante    in number,
    p_furaFila         in number,
    p_dataEspEmbarque  in out varchar2,
    p_idTransportadora in out number,
    p_uf               in out varchar2,
    p_idServTransp     in out number
  ) return number is
    v_sql    varchar2(10000);
    v_cursor cursor_priori;
  begin
  
    montarSqlPrioridade(v_sql, p_idOnda, p_idproduto, p_iddepositante,
                        p_furaFila, C_PRIORIDADE_INDEFINIDA,
                        p_dataEspEmbarque, p_idTransportadora, p_uf,
                        p_idServTransp);
  
    if v_cursor%isopen then
      close v_cursor;
    end if;
  
    open v_cursor for(v_sql);
    fetch v_cursor
      into v_idMovimentacao;
  
    return(v_idMovimentacao);
  
  end prioridadeIndefinida;

end;
/

