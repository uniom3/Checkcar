create view VI_LOTE_ONDA_NF as
select l.idlote, pk_lote.getLoteIndustria(l.idlote) lote,
       pnf.idromaneio idonda, nf.idprenf, pnf.idnotafiscal,
       p.codigointerno codigoindustria, l.idproduto, pnf.idnfdet,
       pnf.qtdeunidade qtde, l.valorlote, l.qtdeentrada, l.fatorconversao,
       e.pesobruto
  from paletseparacaonf pnf, lote l, produto p, notafiscal nf, embalagem e,
       produtodepositante pd
 where pnf.idlote = l.idlote
   and e.barra = l.barra
   and e.idproduto = l.idproduto
   and nf.idnotafiscal = pnf.idnotafiscal
   and l.idproduto = p.idproduto
   and pd.idproduto = l.idproduto
   and pd.identidade = l.iddepositante
/

