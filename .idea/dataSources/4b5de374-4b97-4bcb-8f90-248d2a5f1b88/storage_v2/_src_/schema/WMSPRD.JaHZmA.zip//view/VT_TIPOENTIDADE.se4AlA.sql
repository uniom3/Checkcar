create view VT_TIPOENTIDADE as
select idtipo, descr tipoentidade
  from tipo
/

