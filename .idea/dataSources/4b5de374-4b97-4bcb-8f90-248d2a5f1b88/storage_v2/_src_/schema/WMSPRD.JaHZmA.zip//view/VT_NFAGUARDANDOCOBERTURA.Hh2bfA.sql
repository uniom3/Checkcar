create view VT_NFAGUARDANDOCOBERTURA as
select rownum h$tableid, v."IDLOTENF",v."NOTAFISCAL",v."SERIE",v."DTEMISSAO",v."CNPJDEPOSITANTE",v."DEPOSITANTE",v."EMITENTE",v."FANTASIAEMITENTE",v."IDNOTAFISCAL",v."IDDEPOSITANTE",v."H$IDARMAZEM",v."H$PERMITECOBRIR",v."H$CLASSIFICACAOREGIME",v."H$CONTRIBUINTEICMS"
  from (select distinct c.idlotenf, c.numnf notafiscal, c.serie,
                         c.dataemissao dtemissao, c.cnpjdepositante,
                         c.depositante, c.emitente,
                         c.emitentefantasia fantasiaemitente, c.idnotafiscal,
                         c.iddepositante, c.idarmazem h$idarmazem,
                         decode(at.status, null, 1, 4, 1, 0) h$permiteCobrir,
                         c.classificacaoRegime h$classificacaoRegime,
                         c.contribuinteIcms h$contribuinteIcms
           from v_cobertura_notafiscal c, lotenf lnf, agendatransporte at
          where lnf.idlotenf = c.idlotenf
            and at.idagenda(+) = lnf.idagendarecebimento) v
/

