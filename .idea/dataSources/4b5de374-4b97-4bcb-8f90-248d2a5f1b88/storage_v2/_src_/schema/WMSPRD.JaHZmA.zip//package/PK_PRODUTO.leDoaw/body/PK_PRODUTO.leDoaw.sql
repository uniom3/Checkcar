create package body pk_produto is

  EXIBE_ALERTA_PACKING     constant number := 1;
  NAO_EXIBE_ALERTA_PACKING constant number := 0;

  /*
   * Permite que o Delphi guarde uma imagem em Blob.
  */
  procedure retBlobImage(p_idproduto in number) is
    v_var_img long raw;
  begin
    select ip.img
      into v_var_img
      from imagem_produto ip
     where ip.idproduto = p_idproduto;
  
    if v_var_img is not null then
      update imagem_produto
         set img1 = v_var_img,
             img  = null
       where idproduto = p_idproduto;
    
      commit;
    end if;
  end;

  /*
   * Permite que o Delphi obtenha uma imagem Blob em Long Raw.
  */
  procedure retLRawImage
  (
    p_idproduto in number,
    p_commit    in char := 'S'
  ) is
    v_var_img long raw;
  begin
    begin
      select ip.img1
        into v_var_img
        from imagem_produto ip
       where ip.idproduto = p_idproduto;
    
      update imagem_produto
         set img = v_var_img
       where idproduto = p_idproduto;
    
      if p_commit = 'S' then
        commit;
      end if;
    exception
      when others then
        v_var_img := null;
    end;
  end;
  /*
   * Carrega as informacoes da embalagem
  */
  function CarregarEmbalagem
  (
    p_produto in number,
    p_fator   in number
  ) return embalagem%rowtype is
    cursor c_embalagem
    (
      p_produto in number,
      p_fator   in number
    ) is
      select e.idproduto, e.barra, e.descr, e.apresentacao, e.fatorconversao,
             e.altura, e.largura, e.comprimento, e.unidadebasicacompra,
             e.unidadebasicavenda, e.lastro, e.qtdecamada, e.pesobruto,
             e.pesoliquido, e.ativo
        from embalagem e
       where e.fatorconversao = p_fator
         and e.idproduto = p_produto
         and e.ativo = 'S';
  
    r_embalagem c_embalagem%rowtype;
    v_embalagem embalagem%rowtype;
  begin
    if c_embalagem%isopen then
      close c_embalagem;
    end if;
    open c_embalagem(p_produto, p_fator);
    fetch c_embalagem
      into r_embalagem;
    if c_embalagem%found then
      v_embalagem.idproduto           := p_produto;
      v_embalagem.barra               := r_embalagem.barra;
      v_embalagem.descr               := r_embalagem.descr;
      v_embalagem.apresentacao        := r_embalagem.apresentacao;
      v_embalagem.fatorconversao      := r_embalagem.fatorconversao;
      v_embalagem.altura              := r_embalagem.altura;
      v_embalagem.largura             := r_embalagem.largura;
      v_embalagem.comprimento         := r_embalagem.comprimento;
      v_embalagem.unidadebasicacompra := r_embalagem.unidadebasicacompra;
      v_embalagem.unidadebasicavenda  := r_embalagem.unidadebasicavenda;
      v_embalagem.lastro              := r_embalagem.lastro;
      v_embalagem.qtdecamada          := r_embalagem.qtdecamada;
      v_embalagem.pesobruto           := r_embalagem.pesobruto;
      v_embalagem.pesoliquido         := r_embalagem.pesoliquido;
      v_embalagem.ativo               := r_embalagem.ativo;
    else
      v_embalagem := null;
    end if;
    return v_embalagem;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao
   * se nao achar a embalagem a rotina forca um erro (exception)
  */
  function ret_codbarra
  (
    p_produto in number,
    p_fator   in number
  ) return string is
    v_barra embalagem.barra%type;
    v_msg   t_message;
  begin
    v_barra := retornar_codbarra(p_produto, p_fator);
  
    if v_barra is not null then
      return v_barra;
    else
      v_msg := t_message('CODIGO DE BARRAS NAO CADASTRADO PARA O IDPRODUTO: {0}' ||
                         ' E FATOR CONVERSAO: {1}');
      v_msg.addParam(p_produto);
      v_msg.addParam(p_fator);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao
   * se nao achar a embalagem a rotina forca o retorno de -1 para a barra
  */
  function ret_codbarra_tratando_erro
  (
    p_produto in number,
    p_fator   in number
  ) return string is
    v_barra embalagem.barra%type;
  begin
    v_barra := retornar_codbarra(p_produto, p_fator);
  
    if v_barra is not null then
      return v_barra;
    else
      return '-1';
    end if;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao
  */
  function retornar_codbarra
  (
    p_produto   in number,
    p_fator     in number,
    p_nfRetorno in number := 0
  ) return string is
    v_barra embalagem.barra%type;
  begin
    begin
      if (p_nfRetorno = 0) then
      
        select e.barra
          into v_barra
          from embalagem e
         where e.idproduto = p_produto
           and e.fatorconversao = p_fator
           and e.ativo = 'S'
           and rownum = 1;
      
      elsif (p_nfRetorno = 1) then
      
        select e.barra
          into v_barra
          from (select e.barra
                   from embalagem e
                  where e.idproduto = p_produto
                    and e.fatorconversao = p_fator
                    and e.ativo = 'S'
                  order by nvl(e.barrainterna, 0) asc) e
         where rownum = 1;
      else
        return null;
      end if;
    
      return v_barra;
    
    exception
      when no_data_found then
        return null;
    end;
  end retornar_codbarra;

  procedure MudarCodBarra
  (
    p_produto     in number,
    p_barra_atual in embalagem.barra%type,
    p_barra_nova  in embalagem.barra%type,
    p_usuario     in number
  ) is
    v_idproduto number;
    v_fc_atual  number;
    v_fc_nova   number;
    v_msg       t_message;
  begin
    -- verifica se a barra esta sendo realmente sendo modificada
    if p_barra_nova is null then
    
      v_msg := t_message('BARRA NÃO PODE SER VAZIA.' || chr(13) ||
                         'OPERACAO CANCELADA.');
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  
    if p_barra_nova = p_barra_atual then
    
      v_msg := t_message('BARRA ESTÁ SENDO ALTERADA PELO MESMO VALOR.' ||
                         chr(13) || 'OPERACAO CANCELADA.');
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
    -- insere a nova barra
    begin
      insert into embalagem
        (idproduto, barra, descr, idtipoembalagem, apresentacao,
         fatorconversao, altura, largura, comprimento, unidadebasicacompra,
         unidadebasicavenda, lastro, qtdecamada, pesobruto, pesoliquido, su,
         empilhamentomax, ativo, separacao, imprimeetiqueta, datacadastro,
         dataalteracao, fc_antigo, atz_lwl, precadastro, idusuario,
         descrreduzido, caixafechada, controlaestoque, seqemb, barralegivel,
         barrainterna, embalagempadrao)
        select e.idproduto, p_barra_nova, e.descr, e.idtipoembalagem,
               e.apresentacao, e.fatorconversao, e.altura, e.largura,
               e.comprimento, e.unidadebasicacompra, e.unidadebasicavenda,
               e.lastro, e.qtdecamada, e.pesobruto, e.pesoliquido, e.su,
               e.empilhamentomax, e.ativo, e.separacao, e.imprimeetiqueta,
               e.datacadastro, sysdate, e.fc_antigo, 'N', e.precadastro,
               p_usuario, e.descrreduzido, e.caixafechada, e.controlaestoque,
               e.seqemb, e.barralegivel, e.barrainterna, e.embalagempadrao
          from embalagem e
         where e.idproduto = p_produto
           and e.barra = p_barra_atual;
    exception
      when others then
        --coletando dados da embalagem nova
        select idproduto, fatorconversao
          into v_idproduto, v_fc_nova
          from embalagem
         where barra = p_barra_nova;
      
        --coletando dados da embalagem atual
        select fatorconversao
          into v_fc_atual
          from embalagem
         where barra = p_barra_atual;
      
        --comparando produto
        if v_idproduto <> p_produto then
          v_msg := t_message('Código de barras informado: {0}' ||
                             ' pertence ao produto id: {1}.' ||
                             ' Operação cancelada.');
          v_msg.addParam(p_barra_nova);
          v_msg.addParam(v_idproduto);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        --comparando fator de conversao
        if v_fc_atual <> v_fc_nova then
          v_msg := t_message('Código de barras informado: {0}' ||
                             ' já existe no sistema com fator de conversão diferente.' ||
                             ' Operação cancelada.');
          v_msg.addParam(p_barra_nova);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
    end;
  
    -- atualiza as tabelas relacionadas
    update ajustemovtoentrada
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update corteromaneio
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update embalagemequivalente
       set barraprincipal = p_barra_nova
     where barraprincipal = p_barra_atual
       and idprodutoprincipal = p_produto;
    update embalagemequivalente
       set barraequivalente = p_barra_nova
     where barraequivalente = p_barra_atual
       and idprodutoequivalente = p_produto;
    update estornopalet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update historicoestoque
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update criticainventario
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update invdet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update invdetliberado
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update invacaoinventario
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update produtocontinventario
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update produtoauditado
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    insert into confpalet
      (idproduto, barra, idromaneio, idpalet, idconf, idusuario, qtde,
       liberado, datahora)
      select c.idproduto, p_barra_nova, c.idromaneio, c.idpalet, c.idconf,
             c.idusuario, c.qtde, c.liberado, c.datahora
        from confpalet c
       where c.idproduto = p_produto
         and c.barra = p_barra_atual;
    update logconfpalet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    delete from confpalet
     where idproduto = p_produto
       and barra = p_barra_atual;
    update confpaletregiao
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update conferenciaentradadet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update kitproduto
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update ordemkit
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update lote
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update ocorrencia
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update ocorrenciasaida
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update padraopallet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update nfdetimpressao
       set barra = p_barra_nova
     where barra = p_barra_atual;
    update lote
       set barraoriginal = p_barra_nova
     where barraoriginal = p_barra_atual;
  
    for c_nfdet in (select idnfdet
                      from nfdet
                     where barra = p_barra_atual
                       and idproduto = p_produto)
    loop
      insert into nfdet
        (nf, barra, idproduto, codprodmix, codigoindustria, valoricms,
         baseicms, icmssubst, baseicmssubst, icmssubstcobrarvarejo,
         icmssubstindustria, ipi, frete, seguro, despesaacessoria, pis,
         cofins, precounitbruto, precounitliquido, porcdesconto, desconto,
         valordescgrupo, total, totalliquido, pesobruto, pesoliquido,
         aliqicms, aliqipi, st, classificacaofiscal, qtde, qtdebonific,
         vlrdesc, tipo, vlrisento, vlroutras, nfnumformulario, baixacanhoto,
         databaixacanhoto, acertofinanceiro, dataacerto, obsacerto,
         qtdeatendida, qtdeestoque, qtdecoberta, valordefinido,
         motivodocorte, idtiponotafiscal, cfop, origemproduto,
         modalidadebcicms, reducaoicms, mvaicmsst, bcicmsst, reducaoicmsst,
         icmsst, cstipi, bcipi, cstpis, bcpis, aliqpis, cstcofins, bccofins,
         aliqcofins, valorbcii, valordespaduaneiras, valorii,
         valoriioperfinanceiras, diproduto, aliqicmsst, modalidadebcicmsst,
         idoperacao, idnfdet, idnotafiscalref, idnfdetref, barraref,
         idprodutoref, chaveidentificacaoext, codigobeneficiofiscal,
         valorIcmsDesonerado, motivoDesoneracaoICMS)
        select nf, p_barra_nova, idproduto, codprodmix, codigoindustria,
               valoricms, baseicms, icmssubst, baseicmssubst,
               icmssubstcobrarvarejo, icmssubstindustria, ipi, frete, seguro,
               despesaacessoria, pis, cofins, precounitbruto,
               precounitliquido, porcdesconto, desconto, valordescgrupo,
               total, totalliquido, pesobruto, pesoliquido, aliqicms,
               aliqipi, st, classificacaofiscal, qtde, qtdebonific, vlrdesc,
               tipo, vlrisento, vlroutras, nfnumformulario, baixacanhoto,
               databaixacanhoto, acertofinanceiro, dataacerto, obsacerto,
               qtdeatendida, qtdeestoque, qtdecoberta, valordefinido,
               motivodocorte, idtiponotafiscal, cfop, origemproduto,
               modalidadebcicms, reducaoicms, mvaicmsst, bcicmsst,
               reducaoicmsst, icmsst, cstipi, bcipi, cstpis, bcpis, aliqpis,
               cstcofins, bccofins, aliqcofins, valorbcii,
               valordespaduaneiras, valorii, valoriioperfinanceiras,
               diproduto, aliqicmsst, modalidadebcicmsst, idoperacao,
               seq_nfdet.nextval, idnotafiscalref, idnfdetref, barraref,
               idprodutoref, chaveidentificacaoext, codigobeneficiofiscal,
               valorIcmsDesonerado, motivoDesoneracaoICMS
          from nfdet
         where idnfdet = c_nfdet.idnfdet;
    
      update nfdet
         set barraref   = p_barra_nova,
             idnfdetref = seq_nfdet.currval
       where idnfdetref = c_nfdet.idnfdet;
    
      update origemlotedetalhado
         set idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update coberturalote
         set idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update coberturalote
         set idnfdetentrada = seq_nfdet.currval
       where idnfdetentrada = c_nfdet.idnfdet;
    
      update coberturalotedispnf
         set idnfdetcobertura = seq_nfdet.currval
       where idnfdetcobertura = c_nfdet.idnfdet;
    
      update coberturalotedispnf
         set idnfdetentrada = seq_nfdet.currval
       where idnfdetentrada = c_nfdet.idnfdet;
    
      -- Alterando o idnfdet da nota de cobertura
      update coberturanotafiscal cn
         set cn.idnfdetcobertura = seq_nfdet.currval
       where cn.idnfdetcobertura = c_nfdet.idnfdet;
    
      -- Alterando o idnfdet da nota de entrada
      update coberturanotafiscal cn
         set cn.idnfdetentrada = seq_nfdet.currval
       where cn.idnfdetentrada = c_nfdet.idnfdet;
    
      -- Alterando o idnfdet da nota de retorno
      update coberturanotafiscal cn
         set cn.idnfdetret = seq_nfdet.currval
       where cn.idnfdetret = c_nfdet.idnfdet;
    
      update lotepallet
         set iditemnotafiscal = seq_nfdet.currval
       where iditemnotafiscal = c_nfdet.idnfdet;
    
      update paletseparacaonf
         set idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update nfdetimpressao
         set idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update itemopanfdet
         set idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update itemopanfdetorig ido
         set ido.idnfdet = seq_nfdet.currval
       where ido.idnfdet = c_nfdet.idnfdet;
    
      update errogeracaoonda eg
         set eg.idnfdet = null
       where idnfdet = c_nfdet.idnfdet;
    
      update sepespporloteindustria s
         set s.idnfdet = seq_nfdet.currval
       where idnfdet = c_nfdet.idnfdet;
    
      update coberturaloteest clt
         set clt.idnfdetcobertura = seq_nfdet.currval
       where clt.idnfdetcobertura = c_nfdet.idnfdet;
    
      update coberturaloteest cll
         set cll.idnfdetentrada = seq_nfdet.currval
       where cll.idnfdetentrada = c_nfdet.idnfdet;
    
      update coberturaloteestcomp clc
         set clc.idnfdetcobertura = seq_nfdet.currval
       where clc.idnfdetcobertura = c_nfdet.idnfdet;
    
      update coberturaloteestcomp clp
         set clp.idnfdetentrada = seq_nfdet.currval
       where clp.idnfdetentrada = c_nfdet.idnfdet;
    
      update TDNITEMNFDET td
         set td.idnfdet = seq_nfdet.currval
       where td.idnfdet = c_nfdet.idnfdet;
    
      update resumoconferencianf rn
         set rn.idnfdet = seq_nfdet.currval
       where rn.idnfdet = c_nfdet.idnfdet;
    
      update backlist b
         set b.idnfdet = seq_nfdet.currval
       where b.idnfdet = c_nfdet.idnfdet;
    
      update nfdetrastro nr
         set nr.idnfdet = seq_nfdet.currval
       where nr.idnfdet = c_nfdet.idnfdet;
    
      update movimentacao m
         set m.idnfdet = seq_nfdet.currval
       where m.idnfdet = c_nfdet.idnfdet;
    
      update ordemtransfsaidaitemnfdet nr
         set nr.idnfdet = seq_nfdet.currval
       where nr.idnfdet = c_nfdet.idnfdet;
    
      delete from nfdet
       where idnfdet = c_nfdet.idnfdet;
    end loop;
  
    update mapaseparacaoonda
       set barra = p_barra_nova
     where barra = p_barra_atual;
  
    update mapasepondapedido
       set barra = p_barra_nova
     where barra = p_barra_atual;
  
    insert into paletseparacao
      (idarmazem, idlocal, idlote, idproduto, idromaneio, idpalet, barra,
       idusuario, ordem, qtde, qtdeunit, dtinicio, dtfim, separado,
       processado)
      select p.idarmazem, p.idlocal, p.idlote, p.idproduto, p.idromaneio,
             p.idpalet, p_barra_nova, p.idusuario, p.ordem, p.qtde,
             p.qtdeunit, p.dtinicio, p.dtfim, p.separado, p.processado
        from paletseparacao p
       where p.idproduto = p_produto
         and p.barra = p_barra_atual;
    update paletseparacaocliente
       set barra = p_barra_nova
     where idproduto = p_produto
       and barra = p_barra_atual;
    delete from paletseparacao
     where idproduto = p_produto
       and barra = p_barra_atual;
  
    update romaneio
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update sumprodlote
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update produtopalet
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
  
    update paletseparacaonf
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
    update ocorrenciasaidanf
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
  
    update ocorrenciasaidanf
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
  
    update produtoconfpacking
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
  
    update divergenciasaida
       set barra = p_barra_nova
     where barra = p_barra_atual
       and idproduto = p_produto;
  
    update confpacking
       set barracaixareutilizavel = p_barra_nova
     where barracaixareutilizavel = p_barra_atual;
  
    update produtoexcedido
       set barra = p_barra_nova
     where barra = p_barra_atual;
  
    update produtodepositante
       set embalagemestoque = p_barra_nova
     where idproduto = p_produto
       and embalagemestoque = p_barra_atual;
  
    update produtodepositante
       set embalagemarmazenagem = p_barra_nova
     where idproduto = p_produto
       and embalagemarmazenagem = p_barra_atual;
  
    update invmanual im
       set im.barra = p_barra_nova
     where im.idproduto = p_produto
       and im.barra = p_barra_atual;
  
    update CONFEXPEDICAOCARGADET cdet
       set cdet.barra = p_barra_nova
     where cdet.barra = p_barra_atual
       and cdet.idproduto = p_produto;
  
    update OCORRENCIACONFEXPEDICAO oc
       set oc.barra = p_barra_nova
     where oc.barra = p_barra_atual
       and oc.idproduto = p_produto;
  
    update RESUMOCONFEXPEDICAO rc
       set rc.barra = p_barra_nova
     where rc.barra = p_barra_atual
       and rc.idproduto = p_produto;
  
    update separacaoporcarga sc
       set sc.barra = p_barra_nova
     where sc.barra = p_barra_atual
       and sc.idproduto = p_produto;
  
    update invacaoestentrada iee
       set iee.barra = p_barra_nova
     where iee.idproduto = p_produto
       and iee.barra = p_barra_atual;
  
    update embalagemcontroleprecadastro ecpc
       set ecpc.barra = p_barra_nova
     where ecpc.idproduto = p_produto
       and ecpc.barra = p_barra_atual;
  
    -- apaga a barra antiga
    pk_triggers_control.disableTrigger('t_exclui_embalagem');
  
    delete from embalagem
     where idproduto = p_produto
       and barra = p_barra_atual;
  
    pk_utilities.GeraLog(p_usuario,
                         'ALTERADA BARRA DA EMBALAGEM DO PRODUTO ID ' ||
                          p_produto || ' - BARRA ANTERIOR: ' ||
                          p_barra_atual || ' - BARRA NOVA: ' || p_barra_nova,
                         p_produto, 'EM');
  end;

  /*
  * Funo que retorno string com os Codigs SKU  
  */
  function retorna_codsku
  (
    p_entidade in number,
    p_produto  in number
  ) return string is
  
    v_sku varchar2(2000);
  begin
    for c_sku in (select codsku
                    from equivalenciasku
                   where identidade = p_entidade
                     and idproduto = p_produto)
    loop
      if v_sku is null then
        v_sku := 'Codigo SKU: ' || c_sku.codsku;
      else
        v_sku := v_sku || ', ' || c_sku.codsku;
      end if;
    
    end loop;
  
    return v_sku;
  
  end;

  -- Retorna maior fator conversao 
  -- Eduardo M. Pereira
  function RetornarCodBarraMaiorFator(p_idproduto in embalagem.idproduto%type)
    return embalagem.barra%type is
    v_codbarra embalagem.barra%type;
    v_msg      t_message;
  begin
    select barra
      into v_codbarra
      from embalagem e
     where e.idproduto = p_idproduto
       and e.fatorconversao = (select max(fatorconversao)
                                 from embalagem
                                where idproduto = p_idproduto
                                  and ativo = c_sim)
       and ativo = c_sim
       and rownum = 1;
    return v_codbarra;
  exception
    when no_data_found then
      v_msg := t_message('O CODIGO DE BARRAS DE MAIOR FATOR NAO CADASTRADO OU DESATIVADO PARA O IDPRODUTO: {0}');
      v_msg.addParam(p_idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  function RetornarCodBarraMaiorFatorNoEx(p_idproduto in embalagem.idproduto%type)
    return embalagem.barra%type is
  begin
  
    return RetornarCodBarraMaiorFator(p_idproduto);
  
  exception
    when others then
      return null;
  end;

  -- Retorna menor fator conversao
  -- Eduardo M. Pereira
  function RetornarCodBarraMenorFator(p_idproduto in embalagem.idproduto%type)
    return embalagem.barra%type is
    v_codbarra embalagem.barra%type;
    v_msg      t_message;
  begin
    select barra
      into v_codbarra
      from (select barra
               from embalagem e
              where e.idproduto = p_idproduto
                and e.fatorconversao = 1
                and e.ativo = c_sim
              order by decode(upper(trim(e.descrreduzido)), 'UN', 0, 1))
     where rownum = 1;
  
    return v_codbarra;
  exception
    when no_data_found then
      v_msg := t_message('O CODIGO DE BARRAS DE MENOR FATOR NAO CADASTRADO OU DESATIVADO PARA O IDPRODUTO: {0}');
      v_msg.addParam(p_idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  function cadastrarTipo(p_descr in tipoproduto.descr%type) return number as
    v_id    number;
    v_descr tipoproduto.descr%type;
  begin
    if trim(p_descr) is null then
      v_descr := 'N/D';
    else
      v_descr := upper(trim(p_descr));
    end if;
  
    select idtipo
      into v_id
      from tipoproduto
     where descr = v_descr
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_tipoproduto.nextval id
        into v_id
        from dual;
    
      insert into tipoproduto
        (idtipo, descr, codigo)
      values
        (v_id, v_descr, v_id);
    
      return v_id;
  end;

  function cadastrarMarca(p_descr in string) return number as
    v_id    number;
    v_descr marca.descr%type;
  begin
    if trim(p_descr) is null then
      v_descr := 'N/D';
    else
      v_descr := upper(trim(p_descr));
    end if;
  
    select idmarca
      into v_id
      from marca
     where descr = v_descr
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_marca.nextval
        into v_id
        from dual;
    
      insert into marca
        (idmarca, descr, ativo, codigo)
      values
        (v_id, v_descr, 'S', v_id);
      return v_id;
  end;

  function cadastrarCest
  (
    p_cest in varchar2,
    p_ncm  in varchar2
  ) return number as
    v_id   number;
    v_cest codigoespecificadost.codigo%type;
  begin
    v_cest := upper(trim(p_cest));
  
    select idcodigo
      into v_id
      from codigoespecificadost
     where codigo = v_cest
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_codigoespecificadost.nextval
        into v_id
        from dual;
    
      insert into codigoespecificadost
        (idcodigo, descricao, codigo, ncm)
      values
        (v_id, v_cest, v_cest, upper(p_ncm));
      return v_id;
  end;

  function cadastrarSubfamilia(p_descr in string) return number as
    v_id    number;
    v_descr subfamilia.descr%type;
  begin
    if trim(p_descr) is null then
      v_descr := 'N/D';
    else
      v_descr := upper(trim(p_descr));
    end if;
  
    select idsubfamilia
      into v_id
      from subfamilia
     where descr = v_descr
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_subfamilia.nextval
        into v_id
        from dual;
    
      insert into subfamilia
        (idsubfamilia, descr, codigo)
      values
        (v_id, v_descr, v_id);
      return v_id;
  end;

  function cadastrarSubmarca
  (
    p_idmarca in submarca.idmarca%type,
    p_descr   in submarca.descr%type
  ) return number as
    v_id    number;
    v_descr submarca.descr%type;
  begin
    if p_descr is null then
      v_descr := 'N/D';
    else
      v_descr := upper(trim(p_descr));
    end if;
  
    select idsubmarca
      into v_id
      from submarca
     where idmarca = p_idmarca
       and descr = v_descr
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_submarca.nextval
        into v_id
        from dual;
    
      insert into submarca
        (idsubmarca, idmarca, descr, codigo)
      values
        (v_id, p_idmarca, v_descr, v_id);
      return v_id;
  end;

  function cadastrarSubtipo
  (
    p_idtipo in subtipoproduto.idtipo%type,
    p_descr  in subtipoproduto.descr%type
  ) return number as
    v_id    number;
    v_descr subtipoproduto.descr%type;
  begin
    if nvl(p_descr, '*') = '*' then
      v_descr := 'N/D';
    else
      v_descr := upper(trim(p_descr));
    end if;
  
    select idsubtipo
      into v_id
      from subtipoproduto
     where idtipo = p_idtipo
       and descr = v_descr
       and rownum = 1;
  
    return v_id;
  exception
    when no_data_found then
      select seq_subtipoprod.nextval
        into v_id
        from dual;
    
      insert into subtipoproduto
        (idtipo, idsubtipo, descr, codigo)
      values
        (p_idtipo, v_id, v_descr, v_id);
      return v_id;
  end;

  function retornarIdProduto
  (
    p_iddepositante in number,
    p_codprod       in string
  ) return number is
    v_idprod                  number;
    v_codigointernosequencial number;
  begin
    select c.codigointernoprodutosequencial
      into v_codigointernosequencial
      from configuracao c
     where c.ativo = 'S';
  
    if (v_codigointernosequencial = 1) then
      begin
        select pd.idproduto
          into v_idprod
          from produtodepositante pd
         where pd.identidade = p_iddepositante
           and upper(pd.codigointerno) = upper(p_codprod);
      
        return v_idprod;
      exception
        when no_data_found then
          return null;
      end;
    end if;
  
    select p.idproduto
      into v_idprod
      from produto p
     where upper(p.codigointerno) = upper(p_codprod);
  
    return v_idprod;
  exception
    when no_data_found then
      return null;
  end;

  procedure cadastrarSetor
  (
    p_idproduto     number,
    p_iddepositante number
  ) is
    v_total                   number;
    v_idDepositanteLock       number;
    v_log                     varchar2(512);
    C_HAZMAT_SPECIALIZED_AREA varchar2(23) := 'HAZMAT SPECIALIZED AREA';
  begin
    select d.identidade
      into v_idDepositanteLock
      from depositante d
     where d.identidade = p_iddepositante
       for update;
  
    for c in (select pid.idsetor, pid.prioridade
                from padraointdepositantesetor pid, setor s,
                     produtodepositante pd, produto p
               where pid.identidade = p_iddepositante
                 and s.idsetor = pid.idsetor
                 and pd.identidade = pid.identidade
                 and pd.idproduto = p_idproduto
                 and pd.materialperigoso = s.materiaisperigosos
                 and pd.materialperigoso = 0
                 and s.produtosespeciais = 0
                 and p.idproduto = pd.idproduto
                 and p.idtipo not in
                     (select stp.idtipoproduto
                        from setortipoproduto stp
                       where stp.idtipoproduto = p.idtipo)
              union
              select pid.idsetor, pid.prioridade
                from padraointdepositantesetor pid, setor s,
                     produtodepositante pd,
                     setorclassificacaomatperigoso scmp,
                     classificacaomaterialperigoso cmp
               where pid.identidade = p_iddepositante
                 and s.idsetor = pid.idsetor
                 and pd.identidade = pid.identidade
                 and pd.idproduto = p_idproduto
                 and pd.materialperigoso = s.materiaisperigosos
                 and pd.materialperigoso = 1
                 and pd.idclassificacaomatperigoso =
                     scmp.idclassificacaomatperigoso
                 and scmp.idsetor = s.idsetor
                 and s.produtosespeciais = 0
                 and cmp.id = pd.idclassificacaomatperigoso
                 and upper(cmp.localizacaofc) = C_HAZMAT_SPECIALIZED_AREA
              union
              select pid.idsetor, pid.prioridade
                from padraointdepositantesetor pid, setor s,
                     produtodepositante pd, setortipoproduto stp, produto p
               where pid.identidade = p_iddepositante
                 and s.idsetor = pid.idsetor
                 and pd.identidade = pid.identidade
                 and pd.idproduto = p_idproduto
                 and pd.materialperigoso = s.materiaisperigosos
                 and pd.materialperigoso = 0
                 and s.produtosespeciais = 1
                 and stp.idsetor = pid.idsetor
                 and stp.idtipoproduto = p.idtipo
                 and p.idproduto = pd.idproduto)
    loop
      select count(1)
        into v_total
        from setordepositante sd
       where sd.idsetor = c.idsetor
         and sd.iddepositante = p_iddepositante;
    
      if (v_total = 0) then
        insert into setordepositante
          (idsetor, iddepositante)
        values
          (c.idsetor, p_iddepositante);
      end if;
    
      select count(1)
        into v_total
        from setorproduto sp
       where sp.idproduto = p_idproduto
         and sp.idsetor = c.idsetor;
    
      if (v_total = 0) then
        v_log := 'SETOR ID: ' || c.idsetor || ' VINCULADO AO PRODUTO ID: ' ||
                 p_idproduto || ' VIA INTEGRACAO';
      
        pk_setor.vincularSetorProduto(c.idsetor, p_idproduto, 0, v_log,
                                      c.prioridade);
      end if;
    end loop;
  end;

  procedure cadastrarProduto
  (
    p_produto            in out pk_integracao.t_produto,
    p_produtodepositante in out produtodepositante%rowtype
  ) is
    v_idproduto               number;
    v_idtipo                  number;
    v_idsubtipo               number;
    v_idmarca                 number;
    v_idsubmarca              number;
    v_idsubfamilia            number;
    v_ncm                     produto.ncm%type;
    v_idcest                  codigoespecificadost.idcodigo%type;
    v_importarprodprecadastro number;
    v_codigointernosequencial number;
  
    procedure atualizar is
    begin
      if (v_codigointernosequencial = 1) then
        p_produto.codigointerno := v_idproduto;
      end if;
    
      update produto
         set idtipo                = v_idtipo,
             idsubtipo             = v_idsubtipo,
             idfamilia             = p_produto.idfamilia,
             idsubfamilia          = v_idsubfamilia,
             idmarca               = v_idmarca,
             idsubmarca            = v_idsubmarca,
             codigointerno         = upper(nvl(p_produto.codigointerno,
                                               codigointerno)),
             descr                 = nvl(p_produto.descricao, descr),
             cor                   = nvl(p_produto.cor, cor),
             perctolerancia        = nvl(p_produto.perctolerancia,
                                         perctolerancia),
             ativo                 = nvl(p_produto.ativo, ativo),
             manufaturado          = nvl(p_produto.manufaturado, manufaturado),
             sazonal               = nvl(p_produto.sazonal, sazonal),
             segregado             = nvl(p_produto.segregado, segregado),
             dataalteracao         = sysdate,
             codreferencia         = nvl(p_produto.codigoreferencia,
                                         codreferencia),
             prazovalidade         = nvl(p_produto.prazovalidade,
                                         prazovalidade),
             prazocomercializacao  = nvl(p_produto.prazocomercializacao,
                                         prazocomercializacao),
             prazocritico          = nvl(p_produto.prazocritico, prazocritico),
             ncm                   = nvl(v_ncm, ncm),
             idcest                = v_idcest,
             controlefifo          = nvl(p_produto.controlefifo, controlefifo),
             controlalote          = nvl(p_produto.controlalote, controlalote),
             multiendereco         = nvl(p_produto.multiendereco,
                                         multiendereco),
             otimizaseparacao      = nvl(p_produto.otimizaseparacao,
                                         otimizaseparacao),
             descrimpr             = nvl(p_produto.descrimpr, descrimpr),
             pontoreabastecimento  = nvl(p_produto.pontoreabastecimento,
                                         pontoreabastecimento),
             movestoque            = nvl(p_produto.movestoque, movestoque),
             pontoressuprimento    = nvl(p_produto.pontoressuprimento,
                                         pontoressuprimento),
             fracionado            = nvl(p_produto.fracionado, fracionado),
             produtocritico        = nvl(p_produto.produtocritico,
                                         produtocritico),
             pesavel               = nvl(p_produto.pesavel, pesavel),
             codigoprodanvisa      = p_produto.codigoprodanvisa,
             precomaximoconsumidor = p_produto.precomaximoconsumidor,
             codigoinmetro         = p_produto.codigoinmetro,
             motivoisencao         = p_produto.motivoIsencao
       where idproduto = v_idproduto;
    end atualizar;
  
    procedure cadastrar is
    begin
      select (seq_produto.nextval) idproduto
        into v_idproduto
        from dual;
    
      if (v_codigointernosequencial = 1) then
        p_produto.codigointerno := v_idproduto;
      end if;
    
      -- Inserindo o produto
      begin
        insert into produto
          (idproduto, idtipo, idsubtipo, idfamilia, idsubfamilia, idmarca,
           idsubmarca, codigointerno, descr, cor, perctolerancia, ativo,
           manufaturado, sazonal, controlefifo, segregado, datacadastro,
           dataalteracao, codreferencia, controlalote, prazovalidade,
           prazocomercializacao, prazocritico, multiendereco, precadastro,
           otimizaseparacao, ncm, idcest, descrimpr, pontoreabastecimento,
           movestoque, pontoressuprimento, fracionado, produtocritico,
           pesavel, codigoprodanvisa, precomaximoconsumidor, codigoinmetro,
           tempoparamaturacaoemdias, motivoisencao)
        values
          (v_idproduto, v_idtipo, v_idsubtipo, p_produto.idfamilia,
           v_idsubfamilia, v_idmarca, v_idsubmarca,
           upper(trim(p_produto.codigointerno)), trim(p_produto.descricao),
           substr(trim(p_produto.cor), 1, 20),
           nvl(p_produto.perctolerancia, 0), nvl(p_produto.ativo, 'N'),
           nvl(p_produto.manufaturado, 'N'), nvl(p_produto.sazonal, 'N'),
           nvl(p_produto.controlefifo, 'N'), nvl(p_produto.segregado, 'N'),
           sysdate, sysdate, trim(p_produto.codigoreferencia),
           nvl(p_produto.controlalote, 'S'), nvl(p_produto.prazovalidade, 0),
           nvl(p_produto.prazocomercializacao, 0),
           nvl(p_produto.prazocritico, 0), nvl(p_produto.multiendereco, 'N'),
           nvl(p_produto.precadastro,
                decode(v_importarprodprecadastro, 1, 'S', 'N')),
           nvl(p_produto.otimizaseparacao, 'S'), v_ncm, v_idcest,
           trim(p_produto.descrimpr), nvl(p_produto.pontoreabastecimento, 0),
           nvl(p_produto.movestoque, 'S'),
           nvl(p_produto.pontoressuprimento, 0),
           nvl(p_produto.fracionado, 'N'), nvl(p_produto.produtocritico, 0),
           nvl(p_produto.pesavel, 0), p_produto.codigoprodanvisa,
           p_produto.precomaximoconsumidor, p_produto.codigoinmetro,
           nvl(p_produto.tempoparamaturacaoemdias, 0),
           p_produto.motivoIsencao);
      exception
        when dup_val_on_index then
          select idproduto
            into v_idproduto
            from produto
           where codigointerno = trim(p_produto.codigointerno);
        
          atualizar;
      end;
    end cadastrar;
  
    procedure carregarVariaveis is
    begin
      if p_produto.idtipoproduto is not null then
        v_idtipo := p_produto.idtipoproduto;
      else
        v_idtipo := cadastrarTipo(p_produto.tipoproduto);
      end if;
    
      if p_produto.idsubtipo is not null then
        v_idsubtipo := p_produto.idsubtipo;
      else
        v_idsubtipo := cadastrarSubtipo(v_idtipo, p_produto.subtipo);
      end if;
    
      if p_produto.idmarca is not null then
        v_idmarca := p_produto.idmarca;
      else
        v_idmarca := cadastrarMarca(p_produto.marca);
      end if;
    
      if p_produto.idsubmarca is not null then
        v_idsubmarca := p_produto.idsubmarca;
      else
        v_idsubmarca := cadastrarSubmarca(v_idmarca, p_produto.submarca);
      end if;
    
      if p_produto.idsubfamilia is not null then
        v_idsubfamilia := p_produto.idsubfamilia;
      else
        v_idsubfamilia := cadastrarSubfamilia(p_produto.subfamilia);
      end if;
    
      if (p_produto.ncm is null or p_produto.ncm = '*') then
        v_ncm := null;
      else
        v_ncm := p_produto.ncm;
      end if;
    
      if p_produto.idcest is not null then
        v_idcest := p_produto.idcest;
      elsif p_produto.cest is null then
        v_idcest := null;
      else
        v_idcest := cadastrarCest(p_produto.cest, v_ncm);
      end if;
    end carregarVariaveis;
  
  begin
    select c.importarprodprecadastro, c.codigointernoprodutosequencial
      into v_importarprodprecadastro, v_codigointernosequencial
      from configuracao c
     where c.ativo = 'S';
  
    v_idproduto := retornarIdProduto(p_produtodepositante.identidade,
                                     p_produto.codigointerno);
    carregarVariaveis;
  
    -- atribuição do código interno deve ser antes do cdastrar/atualizar, pois,
    -- se estiver configurado para código interno sequencial do produto irá trocar o código pelo id do produto
    p_produtodepositante.codigointerno := p_produto.codigointerno;
  
    if v_idproduto is null then
      cadastrar;
    else
      atualizar;
    end if;
  
    p_produtodepositante.idproduto := v_idproduto;
  
    p_produto.idproduto := v_idproduto;
  
    pk_entidade.CadastrarProdutoDepositante(p_produtodepositante);
  
    cadastrarSetor(v_idproduto, p_produtodepositante.identidade);
  
  end;

  function cadastrarTipoEmbalagem(p_descr in tipoembalagem.descr%type)
    return number as
    v_id    number;
    v_descr tipoembalagem.descr%type;
  begin
    v_descr := nvl(p_descr, 'N/D');
    v_descr := upper(v_descr);
  
    begin
      select min(idtipoembalagem)
        into v_id
        from tipoembalagem
       where descr = v_descr;
    exception
      when no_data_found then
        v_id := null;
    end;
  
    if v_id is null then
      select seq_tipoembalagem.nextval
        into v_id
        from dual;
    
      insert into tipoembalagem
        (idtipoembalagem, descr, ordem)
      values
        (v_id, v_descr, v_id);
    end if;
  
    return v_id;
  end;

  function retornarBarraEquivalente
  (
    p_idproduto in number,
    p_barra     in embalagem.barra%type
  ) return varchar2 is
    v_barra varchar2(30000);
  begin
    for c_barra in (select barraequivalente
                      from embalagemequivalente
                     where idprodutoprincipal = p_idproduto
                       and barraprincipal = p_barra)
    loop
      if v_barra is null then
        v_barra := c_barra.barraequivalente;
      else
        v_barra := v_barra || ' / ' || c_barra.barraequivalente;
      end if;
    end loop;
    return substr(v_barra, 1, 3000);
  end;

  /*
  * Rotina que pesa o produto
  */
  procedure PesarProduto
  (
    p_peso       in number,
    p_pesoantigo in number,
    p_produto    in number,
    p_barra      in varchar2,
    p_usuario    in number
  ) is
  begin
    update embalagem
       set pesobruto     = p_peso,
           pesoliquido   = p_peso,
           dataalteracao = sysdate
     where idproduto = p_produto
       and barra = p_barra;
  
    pk_utilities.GeraLog(p_usuario,
                         'ALTERADO PESO DE ' || p_pesoantigo || ' PARA ' ||
                          p_peso || ' DO PRODUTO COM BARRA: ' || p_barra,
                         p_produto, 'C');
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao
   * se nao achar a embalagem a rotina forca um erro (exception)
  */
  function ret_codbarra_nao_precad
  (
    p_produto in number,
    p_fator   in number
  ) return string is
    v_barra embalagem.barra%type;
    v_msg   t_message;
  begin
    v_barra := retornar_codbarra_nao_precad(p_produto, p_fator);
  
    if v_barra is not null then
      return v_barra;
    else
      v_msg := t_message('CODIGO DE BARRAS NAO CADASTRADO PARA O IDPRODUTO: {0}' ||
                         ' E FATOR CONVERSAO: {1}');
      v_msg.addParam(p_produto);
      v_msg.addParam(p_fator);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao no pr-cadastro
  */
  function retornar_codbarra_nao_precad
  (
    p_produto in number,
    p_fator   in number
  ) return string is
  
    --Não pré-cadastro
    cursor c_barra
    (
      p_produto in number,
      p_fator   in number
    ) is
      select barra
        from embalagem
       where idproduto = p_produto
         and fatorconversao = p_fator
         and ativo = 'S'
         and nvl(precadastro, 'N') = 'N'
       order by nvl(precadastro, 'N'), nvl(barrainterna, 0) asc;
  
    -- Pré-cadastro
    cursor c_barraprecad
    (
      p_produto in number,
      p_fator   in number
    ) is
      select barra
        from embalagem
       where idproduto = p_produto
         and fatorconversao = p_fator
         and ativo = 'S'
       order by nvl(precadastro, 'N'), nvl(barrainterna, 0) asc;
  
    cursor c_barrainativa
    (
      p_produto in number,
      p_fator   in number
    ) is
      select barra
        from embalagem
       where idproduto = p_produto
         and fatorconversao = p_fator
         and nvl(precadastro, 'N') = 'N'
       order by nvl(precadastro, 'N'), nvl(barrainterna, 0) asc;
  
    r_barra        c_barra%rowtype;
    r_barraprecad  c_barraprecad%rowtype;
    r_barrainativa c_barrainativa%rowtype;
  begin
    open c_barra(p_produto, p_fator);
    fetch c_barra
      into r_barra;
  
    if c_barra%found then
      return r_barra.barra;
    else
      open c_barraprecad(p_produto, p_fator);
      fetch c_barraprecad
        into r_barraprecad;
    
      if c_barraprecad%found then
        return r_barraprecad.barra;
      else
        open c_barrainativa(p_produto, p_fator);
        fetch c_barrainativa
          into r_barrainativa;
        if c_barrainativa%found then
          return r_barrainativa.barra;
        else
          return null;
        end if;
      end if;
    end if;
  
    close c_barra;
    close c_barraprecad;
    close c_barrainativa;
  end;

  /*
  * Retorna Barra de maior fator que no seja pr-cadastro
  */
  function RetBarraMaiorFator_nao_precad(p_idproduto in embalagem.idproduto%type)
    return embalagem.barra%type is
    v_codbarra embalagem.barra%type;
    v_msg      t_message;
  begin
    select barra
      into v_codbarra
      from (select barra
               from embalagem e
              where e.idproduto = p_idproduto
                and e.fatorconversao =
                    (select max(fatorconversao)
                       from embalagem
                      where idproduto = p_idproduto
                        and ativo = c_sim)
                and ativo = c_sim
                and nvl(precadastro, 'N') = 'N'
              order by nvl(barrainterna, 0) asc)
     where rownum = 1;
    return v_codbarra;
  
  exception
    when no_data_found then
      begin
        select barra
          into v_codbarra
          from (select barra
                   from embalagem e
                  where e.idproduto = p_idproduto
                    and e.fatorconversao =
                        (select max(fatorconversao)
                           from embalagem
                          where idproduto = p_idproduto
                            and ativo = c_sim)
                    and ativo = c_sim
                  order by nvl(barrainterna, 0) asc)
         where rownum = 1;
        return v_codbarra;
      
      exception
        when no_data_found then
          v_msg := t_message('O CODIGO DE BARRAS DE MAIOR FATOR NAO CADASTRADO OU DESATIVADO PARA O IDPRODUTO: {0}');
          v_msg.addParam(p_idproduto);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
  end;

  function RetBarraMaiorFatorSemErro(p_idproduto in embalagem.idproduto%type)
    return embalagem.barra%type is
    v_codbarra embalagem.barra%type;
  begin
    select barra
      into v_codbarra
      from embalagem e
     where e.idproduto = p_idproduto
       and e.fatorconversao = (select max(fatorconversao)
                                 from embalagem
                                where idproduto = p_idproduto
                                  and ativo = c_sim)
       and ativo = c_sim
       and nvl(precadastro, 'N') = 'N'
       and rownum = 1;
    return v_codbarra;
  
  exception
    when no_data_found then
      begin
        select barra
          into v_codbarra
          from embalagem e
         where e.idproduto = p_idproduto
           and e.fatorconversao = (select max(fatorconversao)
                                     from embalagem
                                    where idproduto = p_idproduto
                                      and ativo = c_sim)
           and ativo = c_sim
           and rownum = 1;
        return v_codbarra;
      
      exception
        when no_data_found then
          return v_codbarra;
      end;
  end;

  procedure gerarTipoCaixaVolume
  (
    p_pesoinicial in number,
    p_pesofinal   in number,
    p_intervalo   in number
  ) is
    v_peso   number;
    v_existe number;
  begin
    v_peso := p_pesoinicial;
    while v_peso <= p_pesofinal
    loop
      select count(idtipocaixavolume)
        into v_existe
        from tipocaixavolume
       where peso = v_peso;
    
      if v_existe = 0 then
        insert into tipocaixavolume
          (idtipocaixavolume, descr, peso)
        values
          (seq_tipocaixavolume.nextval, 'CAIXA DE ' || v_peso || ' Gr.',
           v_peso);
      end if;
      if v_peso = p_pesoinicial
         and v_peso < p_intervalo then
        v_peso := p_intervalo;
      else
        v_peso := v_peso + p_intervalo;
      end if;
    end loop;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao indepedente de ativo ou no.
  */
  function retornar_codigobarra
  (
    p_produto in number,
    p_fator   in number
  ) return string is
    cursor c_barra
    (
      p_produto in number,
      p_fator   in number
    ) is
      select barra, ativo, precadastro
        from (select barra, ativo, precadastro
                 from embalagem
                where idproduto = p_produto
                  and fatorconversao = p_fator
                order by ativo desc, precadastro)
       where rownum = 1;
  
    r_barra c_barra%rowtype;
  begin
    if c_barra%isopen then
      close c_barra;
    end if;
    open c_barra(p_produto, p_fator);
    fetch c_barra
      into r_barra;
  
    if c_barra%found then
      return r_barra.barra;
    else
      return null;
    end if;
  end;

  /*
   * Carrega a embalagem a partir do produto e do fator de conversao
   * se nao achar a embalagem a rotina forca um erro (exception)
  */
  function ret_codbarraweb
  (
    p_produto in number,
    p_fator   in number
  ) return string is
    v_barra embalagem.barra%type;
  begin
    v_barra := retornar_codbarra_nao_precad(p_produto, p_fator);
  
    if v_barra is not null then
      return v_barra;
    else
      return '-1';
      /*
      raise_application_error(-20000, 'CODIGO DE BARRAS NAO CADASTRADO PARA O IDPRODUTO: ' ||
                               p_produto || ' E FATOR CONVERSAO: ' ||
                               p_fator);*/
    end if;
  end;

  procedure ImagemProduto
  (
    p_idproduto in number,
    p_imagem    in blob,
    p_commit    in char := 'S'
  ) is
    v_total number;
  begin
    select count(*)
      into v_total
      from imagem_produto
     where idproduto = p_idproduto;
  
    if v_total = 0 then
      insert into imagem_produto
        (idproduto, img1)
      values
        (p_idproduto, p_imagem);
    else
      update imagem_produto
         set img1 = p_imagem
       where idproduto = p_idproduto;
    end if;
  
    if p_commit = 'S' then
      commit;
    end if;
  end;

  function RetornarDescrReduzidaeFator(p_idproduto in embalagem.idproduto%type)
    return varchar2 is
    v_descricao embalagem.barra%type;
  begin
    select e.descrreduzido || ' - Fator Conversão: ' || e.fatorconversao
      into v_descricao
      from embalagem e
     where e.idproduto = p_idproduto
       and e.fatorconversao = (select max(fatorconversao)
                                 from embalagem
                                where idproduto = p_idproduto
                                  and ativo = c_sim)
       and ativo = c_sim
       and rownum = 1;
    return v_descricao;
  exception
    when no_data_found then
      return 'Embalagem não cadastrada.';
  end;

  function getMaiorFatorConversao(p_idproduto in embalagem.idproduto%type)
    return number is
    v_fatorconversao embalagem.fatorconversao%type;
  begin
    select e.fatorconversao
      into v_fatorconversao
      from embalagem e
     where e.idproduto = p_idproduto
       and e.fatorconversao = (select max(fatorconversao)
                                 from embalagem
                                where idproduto = p_idproduto
                                  and ativo = c_sim)
       and ativo = c_sim
       and rownum = 1;
    return v_fatorconversao;
  exception
    when no_data_found then
      return 'Embalagem não cadastrada.';
  end;

  function getQtdeFormatadaPorFator
  (
    p_qtdeunitaria in number,
    p_idproduto    in number,
    p_barra        in embalagem.barra%type,
    p_exibirFator  in number := 0
  ) return varchar2 is
    v_resultado               varchar2(30);
    v_qtde                    number;
    v_fatorconversao          number;
    v_descrreduzido           embalagem.descrreduzido%type;
    v_descrreduzidomenorfator embalagem.descrreduzido%type;
  begin
    select e.fatorconversao, e.descrreduzido
      into v_fatorconversao, v_descrreduzido
      from embalagem e
     where e.idproduto = p_idproduto
       and e.barra = p_barra;
  
    v_qtde := mod(p_qtdeUnitaria, v_fatorconversao);
  
    if (p_qtdeUnitaria >= v_fatorconversao) then
      v_resultado := trunc(p_qtdeUnitaria / v_fatorconversao);
    end if;
  
    if (v_qtde > 0) then
      select e.descrreduzido
        into v_descrreduzidomenorfator
        from embalagem e
       where e.idproduto = p_idproduto
         and e.barra =
             pk_produto.retornar_codbarra_nao_precad(p_idproduto, 1);
    
      if (v_resultado is not null) then
        v_resultado := v_resultado || ' ' || v_descrreduzido;
      
        if (p_exibirFator = 1) then
          v_resultado := v_resultado || ' (' || v_fatorconversao || ')';
        end if;
      
        v_resultado := v_resultado || ' e ';
      end if;
    
      v_resultado := v_resultado || (case
                       when v_qtde < 1 then
                        '0' || v_qtde
                       else
                        v_qtde || ''
                     end) || ' ' || v_descrreduzidomenorfator;
    
      if (p_exibirFator = 1) then
        v_resultado := v_resultado || ' (1)';
      end if;
    else
      v_resultado := v_resultado || ' ' || v_descrreduzido;
    
      if (p_exibirFator = 1) then
        v_resultado := v_resultado || ' (' || v_fatorconversao || ')';
      end if;
    end if;
  
    return v_resultado;
  end;

  function getQtdeFormatadaOnda
  (
    p_qtdeunitaria  in number,
    p_idproduto     in number,
    p_idonda        in number,
    p_iddepositante in number,
    p_idEndereco    in number := null,
    p_tipoInf       in number := 0,
    p_moduloChamada in number := 0,
    p_idLote        in number := 0
  ) return varchar2 is
    v_resultado        varchar2(4000);
    v_qtdeDistribuir   number;
    v_tipoVisualizacao number;
    v_tipoLocal        number;
    v_buffer           local.buffer%type;
    v_fator            embalagem.fatorconversao%type;
    v_descrred         embalagem.descrreduzido%type;
    v_ativo            embalagem.ativo%type;
    v_fracionado       number;
    v_os_estojamento   number;
  begin
    /*
    p_tipoInf = indica o tipo de informao que ser retornada
    0 - quantidade
    1 - fator
    2 - barra
    */
  
    select count(1)
      into v_os_estojamento
      from dual
     where exists (select 1
              from ordemservico os
             where os.idromaneio = p_idonda
               and os.tiposervico = 'E');
  
    if (v_os_estojamento > 0) then
      if p_tipoInf = 0 then
        v_resultado := to_char(p_qtdeunitaria) || ' UN';
      elsif p_tipoInf = 1 then
        v_resultado := '1';
      elsif p_tipoInf = 2 then
        v_resultado := pk_produto.retornar_codbarra(p_idproduto, 1);
      end if;
    
      return v_resultado;
    end if;
  
    select decode(nvl(p.fracionado, 'N'), 'N', 0, 1)
      into v_fracionado
      from produto p
     where p.idproduto = p_idproduto;
  
    if (v_fracionado = 1 and mod(p_qtdeunitaria, 1) <> 0) then
      if p_tipoInf = 0 then
        select descrreduzido
          into v_descrred
          from (select e.descrreduzido
                   from embalagem e
                  where e.idproduto = p_idproduto
                    and e.ativo = 'S'
                    and e.fatorconversao = 1
                  order by e.fatorconversao desc, e.barra)
         where rownum = 1;
      
        v_resultado := trim(to_char(p_qtdeunitaria, '900.99')) || ' ' ||
                       v_descrred;
      
        if (v_resultado like ('%##%')) then
          v_resultado := p_qtdeunitaria || ' ' || v_descrred;
        end if;
      
      elsif p_tipoInf = 1 then
        v_resultado := '1';
      elsif p_tipoInf = 2 then
        v_resultado := pk_produto.retornar_codbarra(p_idproduto, 1);
      end if;
    
      return v_resultado;
    end if;
  
    v_qtdeDistribuir := p_qtdeunitaria;
  
    begin
      select e.fatorconversao, e.descrreduzido, e.ativo
        into v_fator, v_descrred, v_ativo
        from embalagem e, produtodepositante pd, romaneiopai rp,
             configuracaoonda co
       where e.idproduto = p_idproduto
         and pd.identidade = p_iddepositante
         and pd.idproduto = e.idproduto
         and pd.embalagemarmazenagem = e.barra
         and rp.idromaneio = p_idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and co.utilizaembalagemarmazenagem = 1;
    
      if v_ativo = 'S' then
        v_resultado := to_char(p_qtdeunitaria / v_fator) || ' ' ||
                       to_char(v_descrred);
      else
        return 'REVISE EMB. ARM.';
      end if;
    
      v_qtdeDistribuir := 0;
    exception
      when no_data_found then
        if p_idEndereco is not null then
          select lo.tipo, lo.buffer
            into v_tipoLocal, v_buffer
            from local lo
           where lo.id = p_idEndereco;
        end if;
      
        -- PEGA A CONFIGURACAO DA EXIBIO DA QUANTIDADE
        -- 0 - Unidades, 1 - Maior Embalagem,  2 - Otimizada
      
        v_tipoVisualizacao := pk_onda.getModoVisualizacaoSeparacao(p_idonda,
                                                                   p_idEndereco,
                                                                   v_tipoLocal,
                                                                   v_buffer);
      
        if v_tipoVisualizacao = 0 then
          -- RETORNA A QUANTIDADE EM UNIDADES
          if p_tipoInf = 0 then
            v_resultado := to_char(p_qtdeunitaria) || ' UN';
          elsif p_tipoInf = 1 then
            v_resultado := '1';
          elsif p_tipoInf = 2 then
            v_resultado := pk_produto.retornar_codbarra(p_idproduto, 1);
          end if;
        
          v_qtdeDistribuir := 0;
        elsif v_tipoVisualizacao = 1 then
          -- LOCALIZA O MAIOR FATOR PELO QUAL A QUANTIDADE UNITARIA PODE SER DIVISIVEL SEM RESTO
          for c_emb in (select fatorconversao, descrreduzido, barra
                          from (select e.fatorconversao, e.descrreduzido,
                                        e.barra
                                   from embalagem e
                                  where e.idproduto = p_idproduto
                                    and e.ativo = 'S'
                                    and mod(p_qtdeunitaria, e.fatorconversao) = 0
                                  order by e.fatorconversao desc, e.barra)
                         where rownum = 1)
          loop
            if p_tipoInf = 0 then
              v_resultado := to_char(p_qtdeunitaria / c_emb.fatorconversao) || ' ' ||
                             to_char(c_emb.descrreduzido) || '(' ||
                             c_emb.fatorconversao || ')';
            elsif p_tipoInf = 1 then
              v_resultado := to_char(c_emb.fatorconversao);
            elsif p_tipoInf = 2 then
              v_resultado := c_emb.barra;
            end if;
          
            v_qtdeDistribuir := 0;
          end loop;
        elsif v_tipoVisualizacao = 2 then
          if p_moduloChamada = 0 then
            for c_emb in (select fatorconversao, descrreduzido, barra
                            from (select e.fatorconversao, e.descrreduzido,
                                          e.barra
                                     from embalagem e
                                    where e.idproduto = p_idproduto
                                      and e.ativo = 'S'
                                      and e.fatorconversao <= p_qtdeunitaria
                                    order by e.fatorconversao desc, e.barra)
                           where rownum = 1)
            loop
              if p_tipoInf = 0 then
                v_resultado := to_char(trunc(p_qtdeunitaria /
                                             c_emb.fatorconversao, 0)) || ' ' ||
                               to_char(c_emb.descrreduzido) || '(' ||
                               c_emb.fatorconversao || ')';
              elsif p_tipoInf = 1 then
                v_resultado := to_char(c_emb.fatorconversao);
              elsif p_tipoInf = 2 then
                v_resultado := c_emb.barra;
              end if;
            
              v_qtdeDistribuir := 0;
            end loop;
          else
            if p_tipoInf = 0 then
              -- RETORNA A QUANTIDADE OTIMIZADA
              for c_emb in (select e.fatorconversao, e.descrreduzido
                              from embalagem e
                             where e.idproduto = p_idproduto
                               and e.ativo = 'S'
                               and e.fatorconversao <= p_qtdeunitaria
                             order by e.fatorconversao desc, e.barra)
              loop
                if trunc(v_qtdeDistribuir / c_emb.fatorconversao) > 0 then
                  if v_resultado is null then
                    v_resultado := to_char(trunc(v_qtdeDistribuir /
                                                 c_emb.fatorconversao)) || ' ' ||
                                   c_emb.descrreduzido || '(' ||
                                   c_emb.fatorconversao || ')';
                  else
                    if mod(v_qtdeDistribuir, c_emb.fatorconversao) = 0 then
                      v_resultado := v_resultado || ' e ' ||
                                     to_char(trunc(v_qtdeDistribuir /
                                                   c_emb.fatorconversao)) || ' ' ||
                                     c_emb.descrreduzido || '(' ||
                                     c_emb.fatorconversao || ')';
                    else
                      v_resultado := v_resultado || ', ' ||
                                     to_char(trunc(v_qtdeDistribuir /
                                                   c_emb.fatorconversao)) || ' ' ||
                                     c_emb.descrreduzido || '(' ||
                                     c_emb.fatorconversao || ')';
                    end if;
                  end if;
                
                  v_qtdeDistribuir := v_qtdeDistribuir -
                                      trunc(v_qtdeDistribuir /
                                            c_emb.fatorconversao) *
                                      c_emb.fatorconversao;
                end if;
              
                if v_qtdeDistribuir = 0 then
                  exit;
                end if;
              end loop;
              -- RETORNA O FATOR DE CONVERSAO
            elsif p_tipoInf = 1 then
              for c_emb in (select e.fatorconversao, e.descrreduzido, e.barra
                              from embalagem e
                             where e.idproduto = p_idproduto
                               and e.ativo = 'S'
                               and e.fatorconversao <= p_qtdeunitaria
                             order by e.fatorconversao desc, e.barra)
              loop
                if trunc(v_qtdeDistribuir / c_emb.fatorconversao) > 0 then
                  if v_resultado is null then
                    v_resultado := to_char(c_emb.fatorconversao);
                  else
                    v_resultado := to_char(c_emb.fatorconversao);
                  end if;
                
                  v_qtdeDistribuir := v_qtdeDistribuir -
                                      trunc(v_qtdeDistribuir /
                                            c_emb.fatorconversao) *
                                      c_emb.fatorconversao;
                end if;
              
                if v_qtdeDistribuir = 0 then
                  exit;
                end if;
              end loop;
            elsif p_tipoInf = 2 then
              for c_emb in (select e.fatorconversao, e.descrreduzido, e.barra
                              from embalagem e
                             where e.idproduto = p_idproduto
                               and e.ativo = 'S'
                               and e.fatorconversao <= p_qtdeunitaria
                             order by e.fatorconversao desc, e.barra)
              loop
                if mod(v_qtdeDistribuir, c_emb.fatorconversao) = 0 then
                  v_resultado      := c_emb.barra;
                  v_qtdeDistribuir := 0;
                  exit;
                end if;
              
                if (c_emb.fatorconversao = 1) then
                  v_resultado      := c_emb.barra;
                  v_qtdeDistribuir := 0;
                  exit;
                end if;
              end loop;
            end if;
          end if;
        elsif (v_tipoVisualizacao = 4)
              and (p_idLote is not null) then
          -- RETORNA A QUANTIDADE OTIMIZADA CONFERINDO EMBALAGENS LOTE ESTOQUE
          for c_embLL in (select lt.barra, lt.fatorconversao, e.descrreduzido,
                                 em.barra mnBarra,
                                 em.fatorconversao mnFatorconversao,
                                 em.descrreduzido mnDescrReduzido
                            from lote lt, embalagem e, embalagem em
                           where lt.idproduto = e.idproduto
                             and lt.barra = e.barra
                             and lt.idlote = p_idLote
                             and lt.idproduto = p_idproduto
                             and em.idproduto = e.idproduto
                             and em.barra =
                                 pk_produto.RetornarCodBarraMenorFator(e.idproduto)
                             and lt.iddepositante = p_iddepositante)
          loop
            if p_tipoInf = 0 then
              if (trunc(v_qtdeDistribuir / c_embLL.Fatorconversao) > 0) then
                v_resultado      := to_char(trunc(v_qtdeDistribuir /
                                                  c_embLL.fatorconversao)) || ' ' ||
                                    c_embLL.descrreduzido || '(' ||
                                    c_embLL.Fatorconversao || ')';
                v_qtdeDistribuir := v_qtdeDistribuir -
                                    (trunc(v_qtdeDistribuir /
                                           c_embLL.Fatorconversao) *
                                    c_embLL.Fatorconversao);
              end if;
            
              if (v_qtdeDistribuir > 0) then
                if (v_resultado is null) then
                  v_resultado := to_char(v_qtdeDistribuir) || ' ' ||
                                 c_embLL.mndescrreduzido || '(' ||
                                 c_embLL.mnFatorconversao || ')';
                else
                  v_resultado := v_resultado || ' e ' ||
                                 to_char(v_qtdeDistribuir) || ' ' ||
                                 c_embLL.Mndescrreduzido || '(' ||
                                 c_embLL.mnFatorconversao || ')';
                end if;
              end if;
            elsif p_tipoInf = 1 then
              if ((trunc(v_qtdeDistribuir / c_embLL.Fatorconversao) > 0)) then
                v_resultado := to_char(c_embLL.fatorconversao);
              else
                v_resultado := to_char(c_embLL.Mnfatorconversao);
              end if;
            
            elsif p_tipoInf = 2 then
              if ((trunc(v_qtdeDistribuir / c_embLL.Fatorconversao) > 0)) then
                v_resultado := c_embLL.barra;
              else
                v_resultado := c_embLL.mnbarra;
              end if;
            
            end if;
            v_qtdeDistribuir := 0;
          end loop;
        else
          if p_tipoInf = 0 then
            -- RETORNA A QUANTIDADE OTIMIZADA
            for c_emb in (select e.fatorconversao, e.descrreduzido
                            from embalagem e
                           where e.idproduto = p_idproduto
                             and e.ativo = 'S'
                             and e.fatorconversao <= p_qtdeunitaria
                           order by e.fatorconversao desc, e.barra)
            loop
              if trunc(v_qtdeDistribuir / c_emb.fatorconversao) > 0 then
                if v_resultado is null then
                  v_resultado := to_char(trunc(v_qtdeDistribuir /
                                               c_emb.fatorconversao)) || ' ' ||
                                 c_emb.descrreduzido || '(' ||
                                 c_emb.fatorconversao || ')';
                else
                  if mod(v_qtdeDistribuir, c_emb.fatorconversao) = 0 then
                    v_resultado := v_resultado || ' e ' ||
                                   to_char(trunc(v_qtdeDistribuir /
                                                 c_emb.fatorconversao)) || ' ' ||
                                   c_emb.descrreduzido || '(' ||
                                   c_emb.fatorconversao || ')';
                  else
                    v_resultado := v_resultado || ', ' ||
                                   to_char(trunc(v_qtdeDistribuir /
                                                 c_emb.fatorconversao)) || ' ' ||
                                   c_emb.descrreduzido || '(' ||
                                   c_emb.fatorconversao || ')';
                  end if;
                end if;
              
                v_qtdeDistribuir := v_qtdeDistribuir - trunc(v_qtdeDistribuir /
                                                             c_emb.fatorconversao) *
                                    c_emb.fatorconversao;
              end if;
            
              if v_qtdeDistribuir = 0 then
                exit;
              end if;
            end loop;
          elsif p_tipoInf = 1 then
            v_resultado      := '1';
            v_qtdeDistribuir := 0;
          elsif p_tipoInf = 2 then
            v_resultado      := pk_produto.retornar_codbarra(p_idproduto, 1);
            v_qtdeDistribuir := 0;
          end if;
        end if;
    end;
  
    if v_qtdeDistribuir > 0 then
      -- PEDE PARA REVER CADASTRO DE EMBALAGENS
      v_resultado := 'REVISE EMB.';
    end if;
  
    return v_resultado;
  end;

  function converterQtdeProduto
  (
    p_idproduto in number,
    p_qtdeUnit  in number
  ) return number is
    cursor c_emb(p_idproduto in number) is
      select fatorconversao
        from embalagem e
       where e.idproduto = p_idproduto
         and e.ativo = 'S'
       order by e.fatorconversao desc;
  
    r_emb c_emb%rowtype;
  
    v_qtdeRestante   number;
    v_qtdeConvertida number;
    v_qtde           number;
  begin
    v_qtdeRestante   := p_qtdeUnit;
    v_qtdeConvertida := 0;
  
    if c_emb%isopen then
      close c_emb;
    end if;
    open c_emb(p_idproduto);
    fetch c_emb
      into r_emb;
  
    while c_emb%found
          and v_qtdeRestante > 0
    loop
      v_qtde := trunc(v_qtdeRestante / r_emb.fatorconversao);
      if v_qtde > 0 then
        v_qtdeConvertida := v_qtdeConvertida + v_qtde;
        v_qtdeRestante   := v_qtdeRestante -
                            (trunc(v_qtdeRestante / r_emb.fatorconversao) *
                            r_emb.fatorconversao);
      end if;
    
      fetch c_emb
        into r_emb;
    end loop;
    close c_emb;
  
    return v_qtdeConvertida;
  end;

  function retornarUltimoValorUnitVenda
  (
    p_idproduto     in number,
    p_idDepositante in number := 0
  ) return number is
    v_preco number := 0;
  begin
    begin
      select valor
        into v_preco
        from (select nf.idnotafiscal, n.precounitliquido valor
                 from nfdet n, notafiscal nf
                where n.idproduto = p_idproduto
                  and nf.idnotafiscal = n.nf
                  and nvl(n.precounitliquido, 0) > 0
                  and nf.tiponf in ('N', 'E')
                  and nf.tipo = 'S'
                  and decode(p_idDepositante, 0, 1, nf.iddepositante) =
                      decode(p_idDepositante, 0, 1, p_idDepositante)
                  and nf.statusnf <> 'X'
                  and not exists
                (select 1
                         from retornosimbolico
                        where idnotafiscalvenda = nf.idnotafiscal)
                  and not exists
                (select 1
                         from notafiscaldevolucao
                        where idnfdevolucao = nf.idnotafiscal)
                order by nf.idnotafiscal desc) n
       where rownum = 1;
    exception
      when others then
        v_preco := 0;
    end;
  
    return v_preco;
  end;

  function retornarUltimoValorUnitCompra(p_idproduto in number) return number is
    v_data  date;
    v_preco number;
  begin
    v_preco := 0;
  
    select max(trunc(nf.dataemissao))
      into v_data
      from notafiscal nf, nfdet nd
     where nvl(nd.precounitliquido, 0) > 0
       and nd.idproduto = p_idproduto
       and nd.nf = nf.idnotafiscal
       and nf.tiponf in ('N', 'E')
       and nf.tipo = 'E'
       and nf.dataemissao is not null
       and nvl(nf.sequencia, ' ') not like 'AGCOB';
  
    if v_data is not null then
      begin
        select n.precounitliquido
          into v_preco
          from nfdet n
         where n.idproduto = p_idproduto
           and n.nf in (select max(nf.idnotafiscal)
                          from notafiscal nf, nfdet nd
                         where nvl(nd.precounitliquido, 0) > 0
                           and nd.idproduto = n.idproduto
                           and nd.nf = nf.idnotafiscal
                           and nf.tiponf in ('N', 'E')
                           and nf.tipo = 'E'
                           and nvl(nf.sequencia, ' ') not like 'AGCOB'
                           and trunc(nf.dataemissao) = v_data);
      exception
        when others then
          v_preco := 0;
      end;
    end if;
  
    return v_preco;
  end;

  function retornarProdutoPesavel(p_idproduto in number) return number is
    v_pesavel number;
  begin
    begin
      select pesavel
        into v_pesavel
        from produto
       where idproduto = p_idproduto;
    exception
      when others then
        v_pesavel := 0;
    end;
    return v_pesavel;
  end;

  function retornarPercentualTolerancia
  (
    p_idproduto     in number,
    p_iddepositante in number,
    p_tipo          in char
  ) return number is
    v_percentual number;
  begin
    select decode(p_tipo, 'E', nvl(pd.percentualentrada, 0),
                   nvl(pd.percentualsaida, 0))
      into v_percentual
      from produtodepositante pd
     where pd.idproduto = p_idproduto
       and pd.identidade = p_iddepositante;
  
    return v_percentual;
  exception
    when no_data_found then
      return 0;
  end;

  function getFatorEmbCompra(p_idproduto in number) return number is
    v_fatorconversao number;
  begin
    begin
      select e.fatorconversao
        into v_fatorconversao
        from embalagem e
       where e.idproduto = p_idproduto
         and nvl(e.unidadebasicacompra, 'N') = 'S'
         and e.ativo = 'S'
         and rownum = 1;
    exception
      when no_data_found then
        begin
          select e.fatorconversao
            into v_fatorconversao
            from embalagem e
           where e.idproduto = p_idproduto
             and e.fatorconversao = (select max(fatorconversao)
                                       from embalagem
                                      where idproduto = p_idproduto
                                        and ativo = 'S')
             and ativo = 'S'
             and rownum = 1;
        exception
          when no_data_found then
            select e.fatorconversao
              into v_fatorconversao
              from embalagem e
             where e.idproduto = p_idproduto
               and e.fatorconversao =
                   (select max(fatorconversao)
                      from embalagem
                     where idproduto = p_idproduto
                       and ativo = 'N')
               and ativo = 'N'
               and rownum = 1;
        end;
    end;
    return v_fatorconversao;
  end;

  function getQtdePaletes
  (
    p_qtdeunit                in number,
    p_lastro                  in number,
    p_qtdecamada              in number,
    p_fatorconversao          in number,
    p_calculapalete           in char := 'S',
    p_caixafechada            in char := 'N',
    p_considerarSomentePalete in char := 'N'
  ) return number is
  begin
    if (p_fatorconversao = 1 and p_caixafechada = 'N' and
       p_considerarSomentePalete = 'N')
       or (p_calculapalete = 'N') then
      return 0;
    end if;
  
    if (p_considerarSomentePalete = 'N') then
      return trunc(p_qtdeunit /
                   (p_lastro * p_qtdecamada * p_fatorconversao));
    else
      return ceil(p_qtdeunit /
                  (p_lastro * p_qtdecamada * p_fatorconversao));
    end if;
  end;

  function getQtdeCaixas
  (
    p_qtdeunit               in number,
    p_lastro                 in number,
    p_qtdecamada             in number,
    p_fatorconversao         in number,
    p_calculapalete          in char := 'S',
    p_calculacaixa           in char := 'S',
    p_caixafechada           in char := 'N',
    p_considerarSomenteCaixa in char := 'N'
  ) return number is
    v_qtdepaleteunit number;
  begin
    if ((p_fatorconversao = 1 and p_caixafechada = 'N' and
       p_considerarSomenteCaixa = 'N') or (p_calculacaixa = 'N')) then
      return 0;
    end if;
  
    if (p_calculapalete = 'S' and p_considerarSomenteCaixa = 'N') then
      v_qtdepaleteunit := getQtdePaletes(p_qtdeunit, p_lastro, p_qtdecamada,
                                         p_fatorconversao, p_calculapalete,
                                         p_caixafechada) * p_lastro *
                          p_qtdecamada * p_fatorconversao;
    else
      v_qtdepaleteunit := 0;
    end if;
  
    if (p_considerarSomenteCaixa = 'N') then
      return trunc((p_qtdeunit - v_qtdepaleteunit) / p_fatorconversao);
    else
      return ceil((p_qtdeunit - v_qtdepaleteunit) / p_fatorconversao);
    end if;
  end;

  function getQtdeUnidades
  (
    p_qtdeunit       in number,
    p_lastro         in number,
    p_qtdecamada     in number,
    p_fatorconversao in number,
    p_calculapalete  in char := 'S',
    p_calculacaixa   in char := 'S',
    p_caixafechada   in char := 'N'
  ) return number is
    v_qtdepaleteunit number;
    v_qtdecaixaunit  number;
  begin
    if p_calculapalete = 'S' then
      v_qtdepaleteunit := getQtdePaletes(p_qtdeunit, p_lastro, p_qtdecamada,
                                         p_fatorconversao, p_calculapalete,
                                         p_caixafechada) * p_lastro *
                          p_qtdecamada * p_fatorconversao;
    else
      v_qtdepaleteunit := 0;
    end if;
  
    if p_calculacaixa = 'S' then
      v_qtdecaixaunit := getQtdeCaixas(p_qtdeunit, p_lastro, p_qtdecamada,
                                       p_fatorconversao, p_calculapalete,
                                       p_calculacaixa, p_caixafechada) *
                         p_fatorconversao;
    else
      v_qtdecaixaunit := 0;
    end if;
  
    return p_qtdeunit - v_qtdepaleteunit - v_qtdecaixaunit;
  end;

  function getQtdeVolumes
  (
    p_qtdeunit                 in number,
    p_fatorconversao           in number,
    p_fatorconversaoarmazengem in number,
    p_caixafechada             in char
  ) return number is
  begin
  
    if (p_fatorconversao <> 1) then
      return ceil(p_qtdeunit / p_fatorconversao);
    end if;
  
    if (p_caixafechada = 'S') then
      return p_qtdeunit;
    end if;
  
    return ceil(p_qtdeunit / p_fatorconversaoarmazengem);
  
  end getQtdeVolumes;

  function getAreaEmbalagem
  (
    p_qtde    in number,
    p_produto in number,
    p_barra   in varchar2
  ) return number is
    v_metroquadrado number;
  begin
    begin
      select p_qtde * (nvl(e.comprimento, 0) * nvl(e.largura, 0))
        into v_metroquadrado
        from embalagem e
       where e.barra = p_barra
         and e.idproduto = p_produto;
    exception
      when no_data_found then
        v_metroquadrado := 0;
    end;
  
    return v_metroquadrado;
  end;

  function getFatorConversaoMenorMaior(p_idproduto in embalagem.idproduto%type)
    return number is
    v_fatorconversao embalagem.fatorconversao%type;
  begin
    select e.fatorconversao
      into v_fatorconversao
      from embalagem e
     where e.idproduto = p_idproduto
       and e.fatorconversao =
           (select min(emb.fatorconversao)
              from embalagem emb
             where emb.idproduto = p_idproduto
               and emb.ativo = c_sim
               and emb.precadastro <> c_sim
               and emb.fatorconversao <> 1)
       and ativo = c_sim
       and rownum = 1;
    return v_fatorconversao;
  exception
    when no_data_found then
      return 1;
  end;

  procedure ReplicarPeso
  (
    p_idproduto in number,
    p_peso      in number,
    p_barra     in varchar2
  ) is
    v_fatorconversao number;
    v_msg            t_message;
  begin
    --pega o fator de conversao da barra isnerida na tela
    begin
      select e.fatorconversao
        into v_fatorconversao
        from embalagem e
       where e.barra = p_barra
         and e.ativo = 'S';
    
      --pega os fatores de conversao daquele produto  
      for c in (select e.fatorconversao, e.barra, e.idproduto
                  from embalagem e
                 where e.idproduto = p_idproduto
                   and e.ativo = 'S')
      
      loop
        if (c.fatorconversao = v_fatorconversao) then
          update embalagem
             set pesobruto     = nvl(p_peso, 0),
                 pesoliquido   = nvl(p_peso, 0),
                 dataalteracao = sysdate
           where idproduto = c.idproduto
             and barra = c.barra;
        end if;
      
        if (c.fatorconversao <> v_fatorconversao) then
          update embalagem
             set pesobruto    =
                 (nvl(p_peso, 0) / v_fatorconversao) * c.fatorconversao,
                 pesoliquido  =
                 (nvl(p_peso, 0) / v_fatorconversao) * c.fatorconversao,
                 dataalteracao = sysdate
           where idproduto = c.idproduto
             and barra = c.barra;
        end if;
      end loop;
    exception
      when no_data_found then
        v_msg := t_message('NENHUM FATOR DE CONVERSÃO ENCONTRADO PARA ESTA EMBALAGEM: {0}');
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  end;

  procedure validarExclusaoEmbalagem
  (
    p_barra     in varchar2,
    p_exportado in char
  ) is
    v_total number;
    v_msg   t_message;
  begin
    select count(*)
      into v_total
      from ajustemovtoentrada
     where barra = p_barra;
  
    if v_total > 0 then
      v_msg := t_message('Embalagem não pode ser excluída, pois existe ajuste de movimentação feito com ela.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_exportado = 'S' then
      v_msg := t_message('Embalagem não pode ser excluída, pois ela possui dados exportados para o ERP.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  procedure validarAlteracaoEmbalagem
  (
    p_barra           in out varchar2,
    p_altura          in number,
    p_largura         in number,
    p_comprimento     in number,
    p_pesobruto       in number,
    p_pesoliquido     in number,
    p_fatorconversao  in number,
    p_precadastro     in char,
    p_descrreduzido   in varchar2,
    p_qtdecamada      in number,
    p_empilhamentomax in number,
    p_lastro          in number
  ) is
    v_msg t_message;
  begin
    p_barra := trim(upper(p_barra));
    p_barra := replace(p_barra, ' ', '');
  
    if p_altura < 0 then
      v_msg := t_message('O campo altura não pode ser negativo');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_largura < 0 then
      v_msg := t_message('O campo largura não pode ser negativo');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_comprimento < 0 then
      v_msg := t_message('O campo comprimento não pode ser negativo');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_pesobruto < 0 then
      v_msg := t_message('O campo peso bruto não pode ser negativo');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_pesoliquido < 0 then
      v_msg := t_message('O campo peso liquido não pode ser negativo');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_fatorconversao, 1) > 0 then
      v_msg := t_message('O fator de conversão da embalagem deve ser um número inteiro. ' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_altura, 1) > 0 then
      v_msg := t_message('A altura da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_largura, 1) > 0 then
      v_msg := t_message('A largura da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_comprimento, 1) > 0 then
      v_msg := t_message('O comprimento da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_lastro, 1) > 0 then
      v_msg := t_message('O lastro da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_qtdecamada, 1) > 0 then
      v_msg := t_message('A quantidade de camada da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if mod(p_empilhamentomax, 1) > 0 then
      v_msg := t_message('O empilhamento máximo da embalagem deve ser um número inteiro.' ||
                         chr(13) || 'Operao Cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_precadastro = 'N' then
      if (nvl(p_pesobruto, 0) = 0 or nvl(p_pesoliquido, 0) = 0) then
        v_msg := t_message('O peso da embalagem do produto não pode ser zero para embalagem não marcada como pré-cadastro.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    if trim(p_descrreduzido) is null then
      v_msg := t_message('O Campo Descrição Reduzida, é de preenchimento obrigatório.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if nvl(p_fatorconversao, 0) <= 0 then
      v_msg := t_message('O Campo fator de conversão não pode ser menor que 1 ou vazio');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if nvl(p_lastro, 0) < 1 then
      v_msg := t_message('O Campo lastro não pode ser menor que 1 ou vazio');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if nvl(p_qtdecamada, 0) < 1 then
      v_msg := t_message('O Campo camada não pode ser menor que 1 ou vazio');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if nvl(p_empilhamentomax, 0) < 1 then
      v_msg := t_message('O Campo empilhamento máximo não pode ser menor que 1 ou vazio');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_qtdecamada > p_empilhamentomax then
      v_msg := t_message('A Qtde de Camada da embalagem não pode ser maior que o Empilhamento Máximo.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  function gerarCodigoBarras(p_idproduto in number) return varchar2 is
    v_barra varchar2(32);
    v_total number;
  begin
    select '2' || lpad(p.idproduto, 10, '0')
      into v_barra
      from produto p
     where idproduto = p_idproduto;
  
    select count(barra)
      into v_total
      from embalagem
     where idproduto = p_idproduto
       and barra like v_barra || '%';
  
    v_barra := v_barra || lpad(v_total + 1, 2, '0');
    return v_barra;
  end;

  function possuiInformacaoAssociada(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from informacaomatdep
     where idproduto = p_idproduto;
  
    return(v_total > 0);
  end;

  function ehKit(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from kitproduto
     where idprodutokit = p_idproduto;
  
    return v_total > 0;
  end;

  function ehComponenteKit(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from kitproduto
     where idproduto = p_idproduto;
  
    return v_total > 0;
  end;

  function possuiEstoqueFracionado(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from lotelocal ll, lote l
     where l.idlote = ll.idlote
       and l.idproduto = p_idproduto
       and (mod(estoque, 1) > 0 or mod(pendencia, 1) > 0 or
           mod(adicionar, 1) > 0);
  
    return v_total > 0;
  end;

  function possuiNotaFracionada(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from notafiscal nf, nfdet nd
     where nd.nf = nf.idnotafiscal
       and nf.statusnf not in ('X', 'P')
       and mod(nd.qtde, 1) > 0
       and nd.idproduto = p_idproduto;
  
    return v_total > 0;
  end;

  function possuiAjusteFracionado(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from ajustemovto a, ajustemovtoentrada ae
     where a.gerado = 'N'
       and ae.idajustemovto = a.idajustemovto
       and mod(ae.qtde, 1) > 0
       and ae.idproduto = p_idproduto;
  
    if v_total = 0 then
      select count(*)
        into v_total
        from ajustemovto a, ajustemovtosaida ajs, lote l
       where a.gerado = 'N'
         and ajs.idajustemovto = a.idajustemovto
         and ajs.idlote = l.idlote
         and mod(ajs.qtde, 1) > 0
         and l.idproduto = p_idproduto;
    end if;
  
    return v_total > 0;
  end;

  procedure RetBarraMaiorFatorDivisivel
  (
    p_idproduto in embalagem.idproduto%type,
    p_qtde      in number,
    p_embalagem in out embalagem.barra%type,
    p_qtdenova  in out number,
    p_fatornovo in out number
  ) is
    v_msg t_message;
  begin
    for c_emb in (select barra, fatorconversao
                    from embalagem e
                   where e.idproduto = p_idproduto
                     and ativo = c_sim
                     and nvl(precadastro, 'N') = 'N'
                   order by fatorconversao desc)
    loop
      if mod(p_qtde, c_emb.fatorconversao) = 0 then
        p_embalagem := c_emb.barra;
        p_qtdenova  := p_qtde / c_emb.fatorconversao;
        p_fatornovo := c_emb.fatorconversao;
        exit;
      end if;
    end loop;
  
    if p_embalagem is null then
      select barra, p_qtde, 1
        into p_embalagem, p_qtdenova, p_fatornovo
        from embalagem e
       where e.idproduto = p_idproduto
         and e.fatorconversao = 1
         and ativo = c_sim
         and rownum = 1;
    end if;
  
  exception
    when no_data_found then
      v_msg := t_message('Código de barras de fator unitário não cadastrado para o produto id: {0}');
      v_msg.addParam(p_idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  procedure cadastrarEmbalagem
  (
    r_embalagem        in out embalagem%rowtype,
    v_codproduto       in produto.codigointerno%type,
    p_tipoimportacao   in number,
    p_agrupador        in number := null,
    p_cnpjDepositante  in varchar2 := null,
    p_inscrestadualDep in varchar2 := null
  ) is
    v_idprodutoemb                number;
    v_codprodutoemb               produto.codigointerno%type;
    v_importaEmbalagemEquivalente number;
    r_embEquiv                    embalagem%rowtype;
    r_padraointdepositante        padraointdepositante%rowtype;
    v_usarDadoImportado           number := 0;
    v_codigointernoseq            number;
    v_caixafechadaconfsaida       number;
  
    c_int_modelo_silt constant number := 0;
    c_int_modelo_tab  constant number := 2;
  
    v_msg     t_message;
    v_msgNull t_message;
  
    function trocabarraembalagem
    (
      r_embalagem  embalagem%rowtype,
      p_codproduto in produto.codigointerno%type,
      p_agrupador  number := null
    ) return boolean is
      v_codprodutoembexistente produto.codigointerno%type;
      v_idtrocanaopermitida    number;
    begin
    
      begin
        delete embalagem e
         where e.barra = r_embalagem.barra;
      exception
        when others then
          select p.codigointerno
            into v_codprodutoembexistente
            from produto p
           where p.codigointerno <> p_codproduto
             and exists (select 1
                    from embalagem e
                   where e.idproduto = p.idproduto
                     and e.barra = r_embalagem.barra);
        
          select seq_trocabarraembalagemupc.nextval
            into v_idtrocanaopermitida
            from dual;
        
          insert into trocabarraembalagemupc
            (idtroca, arquivointegracaoupc, dataintegracao,
             codigoprodutonovo, codigoprodutoexistente,
             codigobarrasintegracao)
            select v_idtrocanaopermitida, i.arquivo, SYSDATE, p_codproduto,
                   v_codprodutoembexistente, r_embalagem.barra
              from integracao i
             where i.agrupador = p_agrupador;
        
          return false;
      end;
    
      return true;
    end;
  
    procedure identificarProduto is
      v_iddepositante      number := null;
      v_idproduto          number := null;
      v_idprodutoembalagem number := null;
      v_existeBarraFator1  number;
    
      procedure validarDepositante is
      begin
        select e.identidade
          into v_iddepositante
          from entidade e, depositante dep
         where e.cgc = pk_entidade.formatCNPJCPF(p_cnpjDepositante)
           and dep.identidade = e.identidade;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrado depositante com o cnpj: {0}');
          v_msg.addParam(p_cnpjDepositante);
          raise_application_error(-20000, v_msg.formatMessage);
        when too_many_rows then
          begin
            select e.identidade
              into v_iddepositante
              from entidade e, depositante dep
             where e.cgc = pk_entidade.formatCNPJCPF(p_cnpjDepositante)
               and dep.identidade = e.identidade
               and pk_entidade.retValorSemMascara(nvl(trim(e.inscrestadual),
                                                      0)) =
                   pk_entidade.retValorSemMascara(nvl(trim(p_inscrestadualDep),
                                                      0));
          exception
            when no_data_found then
              v_msg := t_message('A Inscrição Estadual informada difere da inscrição estadual cadastrada' ||
                                 '{0} ou não existe inscrição estadual cadastrada para o depositante de CNPJ: {1}');
              v_msg.addParam(p_inscrestadualDep);
              v_msg.addParam(p_cnpjDepositante);
              raise_application_error(-20000, v_msg.formatMessage);
          end;
      end validarDepositante;
    
      procedure cadastrarProdutoDepositante is
        r_produtodepositante produtodepositante%rowtype;
        r_produto            produto%rowtype;
      begin
        select *
          into r_produto
          from produto
         where idproduto = v_idproduto;
      
        r_produtodepositante.idproduto     := v_idproduto;
        r_produtodepositante.identidade    := v_iddepositante;
        r_produtodepositante.codigointerno := v_codproduto;
        r_produtodepositante.descrimp      := r_produto.descr;
        r_produtodepositante.ativo         := r_produto.ativo;
        r_produtodepositante.fatorestoque  := 1;
      
        select decode(pi.itemrastreado, 1, 'S', 'N'),
               decode(pi.generico, 1, 'S', 'N'),
               decode(pi.coletaloteindust, 1, 'S', 'N'),
               pi.coletadtavenclote, pi.tipoalocacaopaletecompleto,
               pi.tipoalocacaopaleteincompleto, pi.tipoalocacaopaletesobra,
               pi.tipoalocacaopaleteunidade,
               decode(pi.movimentaestoque, 1, 'S', 'N'), pi.embalagempadrao,
               pi.pickingdinamico,
               nvl(r_produto.precadastro,
                    decode(pi.precadastro, 1, 'S', 0, 'N')),
               pi.loteunicoendereco, pi.loteunicovolume, pi.qtdemaxpicking,
               pi.regrapersonalizadaexpedprod, pi.tipopicking,
               pi.validarmesano, pi.coletaamostraunica
          into r_produtodepositante.itemrastreado,
               r_produtodepositante.generico,
               r_produtodepositante.coletaloteindust,
               r_produtodepositante.coletadtavenclote,
               r_produtodepositante.tipoalocpalletcompleto,
               r_produtodepositante.tipoalocpalletincompleto,
               r_produtodepositante.tipoalocpalletsobra,
               r_produtodepositante.tipoalocpalletquebra,
               r_produtodepositante.movestoque,
               r_produtodepositante.utilizaembpadrao,
               r_produtodepositante.pickingdinamico, r_produto.precadastro,
               r_produtodepositante.loteuniconoendereco,
               r_produtodepositante.loteuniconovolume,
               r_produtodepositante.qtdemaxpicking,
               r_produtodepositante.regrapersonalizadaexpedprod,
               r_produtodepositante.tipopicking,
               r_produtodepositante.validarmesano,
               r_produtodepositante.coletaamostraunica
          from padraointdepositante pi
         where identidade = v_iddepositante;
      
        pk_entidade.CadastrarProdutoDepositante(r_produtodepositante);
      end cadastrarProdutoDepositante;
    
      procedure ajustarProdutoDepositante is
      begin
        -- trocando idproduto da PRODUTODEPOSITANTE para o mesmo idproduto da embalagem
        update produtodepositante pd
           set pd.idproduto = v_idprodutoembalagem
         where pd.idproduto = v_idproduto
           and pd.identidade = v_iddepositante;
      
        -- removendo produto que perdeu o vinculo com o depositante
        begin
          delete from produto p
           where p.idproduto = v_idproduto;
        exception
          when others then
            null;
        end;
      
        -- alterando para trabalhar com produto da embalagem encontrada
        v_idproduto := v_idprodutoembalagem;
      end ajustarProdutoDepositante;
    
    begin
      -- se utiliza cdigo interno do produto sequencial ou possui cnpj informado, valida o depositante
      if ((p_cnpjDepositante is not null) or (v_codigointernoseq = 1)) then
        validarDepositante;
      
        if (v_codigointernoseq = 1) then
          -- se o depositante for vlido, procura o produto pelo PRODUTODEPOSITANTE
          begin
            select pd.idproduto
              into v_idproduto
              from produtodepositante pd
             where pd.identidade = v_iddepositante
               and upper(pd.codigointerno) = upper(v_codproduto);
          exception
            when no_data_found then
              v_msg := t_message('Produto não encontrado. Operação Cancelada.');
              raise_application_error(-20000, v_msg.formatMessage);
          end;
        end if;
      end if;
    
      if (v_idproduto is null) then
        begin
          select p.idproduto
            into v_idproduto
            from produto p
           where upper(p.codigointerno) = upper(v_codproduto);
        
          if (v_codigointernoseq = 1) then
            -- caso no tenha encontrado o produto pelo PRODUTODEPOSITANTE vincula o depositante ao produto encontrado          
            cadastrarProdutoDepositante;
          end if;
        exception
          when no_data_found then
            v_msg := t_message('Produto não encontrado. Operação Cancelada.');
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      end if;
    
      -- se o fator de converso da embalagem for maior que 1, verifica se o produto possui alguma embalagem de fator 1
      if (pk_produto.validaFatorConversao(r_embalagem.fatorconversao) > 1) then
        select count(e.barra)
          into v_existeBarraFator1
          from embalagem e
         where e.idproduto = v_idproduto
           and e.fatorconversao = 1;
      
        if (v_existeBarraFator1 = 0) then
          v_msg := t_message('A Embalagem barra: {0} possui fator de conversão maior que 1 e o Produto id {1} ' ||
                             'não possui embalagem cadastrada com fator de conversão igual a 1. Operação Cancelada.');
          v_msg.addParam(r_embalagem.barra);
          v_msg.addParam(v_idproduto);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if (v_codigointernoseq = 1) then
        begin
          -- verifica se a barra j est vinculada a um produto
          select e.idproduto
            into v_idprodutoembalagem
            from embalagem e
           where e.barra = r_embalagem.barra;
        exception
          when no_data_found then
            v_idprodutoembalagem := v_idproduto;
        end;
      
        -- caso a embalagem j esteja vinculada a um produto que seja diferente do produto localizado pelo codigo interno
        -- ir remover o produto antigo e ajustar a proutodepositante para usar o produto da embalagem
        if (v_idproduto <> v_idprodutoembalagem) then
          ajustarProdutoDepositante;
        end if;
      end if;
    
      r_embalagem.idproduto := v_idproduto;
    end identificarProduto;
  
  begin
    begin
      select decode(c.criaembequivintegracao, 'S', 1, 0),
             c.codigointernoprodutosequencial
        into v_importaEmbalagemEquivalente, v_codigointernoseq
        from configuracao c
       where c.ativo = 'S';
    exception
      when no_data_found then
        v_importaEmbalagemEquivalente := 0;
        v_codigointernoseq            := 0;
    end;
  
    identificarProduto;
  
    -- Ateno a possibilidade de o produto da embalagem estar vinculado a mais de um depositante
    select max(pid.precadastro), max(pid.caixafechada),
           max(pid.barrainterna), max(pid.lastro), max(pid.qtdecamada),
           max(pid.empilhamentomax), max(pid.altura), max(pid.largura),
           max(pid.comprimento), max(pid.pesobruto), max(pid.pesoliquido),
           max(pid.embalagempadrao)
      into r_padraointdepositante.precadastro,
           r_padraointdepositante.caixafechada,
           r_padraointdepositante.barrainterna,
           r_padraointdepositante.lastro, r_padraointdepositante.qtdecamada,
           r_padraointdepositante.empilhamentomax,
           r_padraointdepositante.altura, r_padraointdepositante.largura,
           r_padraointdepositante.comprimento,
           r_padraointdepositante.pesobruto,
           r_padraointdepositante.pesoliquido,
           r_padraointdepositante.embalagempadrao
      from padraointdepositante pid
     where exists (select 1
              from produtodepositante pd
             where pd.identidade = pid.identidade
               and pd.idproduto = r_embalagem.idproduto);
  
    if (nvl(validaFatorConversao(r_embalagem.fatorconversao), 1) > 1) then
      v_caixafechadaconfsaida := 1;
    else
      select decode(nvl(r_embalagem.caixafechada,
                         decode(r_padraointdepositante.caixafechada, 1, 'S',
                                 'N')), 'N', 0, 1)
        into v_caixafechadaconfsaida
        from dual;
    end if;
  
    insert into embalagem
      (idproduto, barra, descr, idtipoembalagem, apresentacao,
       fatorconversao, altura, largura, comprimento, unidadebasicacompra,
       unidadebasicavenda, lastro, qtdecamada, pesobruto, pesoliquido, su,
       empilhamentomax, ativo, separacao, imprimeetiqueta, datacadastro,
       dataalteracao, precadastro, idusuario, descrreduzido, caixafechada,
       controlaestoque, barralegivel, barrainterna, embalagempadrao,
       caixafechadaconfsaida)
    values
      (r_embalagem.idproduto, r_embalagem.barra, r_embalagem.descr,
       r_embalagem.idtipoembalagem, nvl(r_embalagem.apresentacao, '1x1'),
       nvl(validaFatorConversao(r_embalagem.fatorconversao), 1),
       nvl(r_embalagem.altura, nvl(r_padraointdepositante.altura, 1)),
       nvl(r_embalagem.largura, nvl(r_padraointdepositante.largura, 1)),
       nvl(r_embalagem.comprimento,
            nvl(r_padraointdepositante.comprimento, 1)),
       nvl(r_embalagem.unidadebasicacompra, 'S'),
       nvl(r_embalagem.unidadebasicavenda, 'S'),
       nvl(r_embalagem.lastro, nvl(r_padraointdepositante.lastro, 1)),
       nvl(r_embalagem.qtdecamada, nvl(r_padraointdepositante.qtdecamada, 1)),
       nvl(r_embalagem.pesobruto, nvl(r_padraointdepositante.pesobruto, 1)),
       nvl(r_embalagem.pesoliquido,
            nvl(r_padraointdepositante.pesoliquido, 1)), r_embalagem.su,
       nvl(r_embalagem.empilhamentomax,
            nvl(r_padraointdepositante.empilhamentomax, 1)),
       nvl(upper(r_embalagem.ativo), 'S'), nvl(r_embalagem.separacao, 'S'),
       nvl(r_embalagem.imprimeetiqueta, 'N'), sysdate, sysdate,
       nvl(r_embalagem.precadastro,
            nvl(decode(r_padraointdepositante.precadastro, 0, 'N', 'S'), 'S')),
       r_embalagem.idusuario, nvl(r_embalagem.descrreduzido, 'UN'),
       nvl(r_embalagem.caixafechada,
            nvl(decode(r_padraointdepositante.caixafechada, 0, 'N', 'S'), 'N')),
       nvl(r_embalagem.controlaestoque, 'S'),
       nvl(r_embalagem.barralegivel, 'S'),
       nvl(r_embalagem.barrainterna,
            nvl(r_padraointdepositante.barrainterna, 0)),
       nvl(r_embalagem.embalagempadrao,
            nvl(r_padraointdepositante.embalagempadrao, 0)),
       v_caixafechadaconfsaida);
  
    if (v_importaEmbalagemEquivalente > 0)
       and (length(r_embalagem.barra) < 13) then
      r_embEquiv       := r_embalagem;
      r_embEquiv.Barra := lpad(r_embalagem.barra, 13, '0');
    
      cadastrarEmbalagem(r_embEquiv, v_codproduto);
    
      insert into embalagemequivalente
        (idprodutoprincipal, barraprincipal, idprodutoequivalente,
         barraequivalente)
      values
        (r_embalagem.idproduto, r_embalagem.barra, r_embEquiv.Idproduto,
         r_embEquiv.Barra);
    end if;
  exception
    when dup_val_on_index then
      if nvl(p_tipoimportacao, 0) in (c_int_modelo_silt, c_int_modelo_tab) then
        v_usarDadoImportado := 1;
      end if;
    
      update embalagem
         set descr               = nvl(r_embalagem.descr, descr),
             idtipoembalagem     = nvl(r_embalagem.idtipoembalagem,
                                       idtipoembalagem),
             apresentacao        = nvl(r_embalagem.apresentacao, apresentacao),
             fatorconversao      = nvl(r_embalagem.fatorconversao,
                                       fatorconversao),
             altura              = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.altura, altura),
                                          altura),
             largura             = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.largura, largura),
                                          altura),
             comprimento         = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.comprimento,
                                               comprimento), comprimento),
             unidadebasicacompra = nvl(r_embalagem.unidadebasicacompra,
                                       unidadebasicacompra),
             unidadebasicavenda  = nvl(r_embalagem.unidadebasicavenda,
                                       unidadebasicavenda),
             lastro              = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.lastro, lastro),
                                          lastro),
             qtdecamada          = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.qtdecamada,
                                               qtdecamada), qtdecamada),
             pesobruto           = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.pesobruto, pesobruto),
                                          pesobruto),
             pesoliquido         = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.pesoliquido,
                                               pesoliquido), pesoliquido),
             su                  = nvl(r_embalagem.su, su),
             empilhamentomax     = decode(v_usarDadoImportado, 1,
                                          nvl(r_embalagem.empilhamentomax,
                                               empilhamentomax),
                                          empilhamentomax),
             ativo               = nvl(r_embalagem.ativo, ativo),
             separacao           = nvl(r_embalagem.separacao, separacao),
             imprimeetiqueta     = nvl(r_embalagem.imprimeetiqueta,
                                       imprimeetiqueta),
             dataalteracao       = sysdate,
             descrreduzido       = nvl(r_embalagem.descrreduzido,
                                       descrreduzido),
             caixafechada        = nvl(r_embalagem.caixafechada, caixafechada),
             controlaestoque     = nvl(r_embalagem.controlaestoque,
                                       controlaestoque),
             seqemb              = nvl(r_embalagem.seqemb, seqemb),
             barralegivel        = nvl(r_embalagem.barralegivel, barralegivel),
             barrainterna        = nvl(r_embalagem.barrainterna, barrainterna),
             embalagempadrao     = nvl(r_embalagem.embalagempadrao,
                                       embalagempadrao),
             precadastro         = nvl(r_embalagem.precadastro,
                                       nvl(decode(r_padraointdepositante.precadastro,
                                                   0, 'N', 'S'), 'S'))
       where idproduto = r_embalagem.idproduto
         and barra = r_embalagem.barra;
    
      -- Se no encontra nada dever dar erro, pois a integrao no ocorreu com sucesso
      if sql%rowcount = 0 then
      
        begin
          -- Pegar produto que se encontra a barra cadastrada se for diferente do enviado
          select p.idproduto, p.codigointerno
            into v_idprodutoemb, v_codprodutoemb
            from produto p
           where p.codigointerno <> v_codproduto
             and exists (select 1
                    from embalagem e
                   where e.idproduto = p.idproduto
                     and e.barra = r_embalagem.barra);
        exception
          when no_data_found then
            v_msgNull := t_message('NULO');
            v_msg     := t_message('Embalagem de barra: {0}' ||
                                   ' não encontrada para o produto id: {1}.' ||
                                   ' Operação Cancelada. {2}');
            v_msg.addParam(r_embalagem.barra);
            v_msg.addParam(r_embalagem.idproduto);
            v_msg.addParam(nvl(v_codproduto, v_msgNull.formatMessage));
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      
        if (p_tipoimportacao = c_int_modelo_tab) then
          if (trocabarraembalagem(r_embalagem, v_codproduto, p_agrupador)) then
            cadastrarEmbalagem(r_embalagem, v_codproduto, c_int_modelo_tab,
                               p_agrupador);
          else
            v_msg := t_message('Embalagem já cadastrada para o produto código: ' ||
                               '{0} / id: {1}. Operação Cancelada.');
            v_msg.addParam(v_codprodutoemb);
            v_msg.addParam(v_idprodutoemb);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          v_msg := t_message('Embalagem já cadastrada para o produto código: ' ||
                             '{0} / id: {1}. Operação Cancelada.');
          v_msg.addParam(v_codprodutoemb);
          v_msg.addParam(v_idprodutoemb);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      else
        if (v_importaEmbalagemEquivalente > 0)
           and (length(r_embalagem.barra) < 13) then
          r_embEquiv       := r_embalagem;
          r_embEquiv.Barra := lpad(r_embalagem.barra, 13, '0');
        
          cadastrarEmbalagem(r_embEquiv, v_codproduto);
        
          insert into embalagemequivalente
            (idprodutoprincipal, barraprincipal, idprodutoequivalente,
             barraequivalente)
          values
            (r_embalagem.idproduto, r_embalagem.barra, r_embEquiv.Idproduto,
             r_embEquiv.Barra);
        end if;
      end if;
  end;

  procedure vincularSetor
  (
    p_idproduto  in produto.idproduto%type,
    p_idsetor    in setor.idsetor%type,
    p_prioridade in number
  ) is
  
    C_NAO constant number := 0;
    C_SIM constant number := 1;
  
    v_existe                      number;
    v_produtoTemDepositante       number;
    v_setorAceitaMaterialPerigoso number;
    v_infoMessageSetor            varchar2(20);
    v_infoMessageProd             varchar2(30);
    v_classifMatPerigosoVincSetor number;
    v_setorDevolucaoFornecedor    number;
    C_HAZMAT_SPECIALIZED_AREA     varchar2(23) := 'HAZMAT SPECIALIZED AREA';
  
    v_msg t_message;
  
    function isDevolucaoFornecedor(p_idsetor in setor.idsetor%type)
      return number is
      isDevolucaoFornecedor number;
    begin
      begin
        select s.devolucaofornecedor
          into isDevolucaoFornecedor
          from setor s
         where s.idsetor = p_idsetor;
      exception
        when no_data_found then
          isDevolucaoFornecedor := 0;
      end;
    
      return isDevolucaoFornecedor;
    
    end isDevolucaoFornecedor;
  
  begin
    v_setorDevolucaoFornecedor := isDevolucaoFornecedor(p_idsetor);
  
    select s.materiaisperigosos
      into v_setorAceitaMaterialPerigoso
      from setor s
     where s.idsetor = p_idsetor;
  
    v_produtoTemDepositante := C_NAO;
  
    if (v_setorDevolucaoFornecedor = C_NAO) then
      if (v_setorAceitaMaterialPerigoso = C_SIM) then
        v_infoMessageSetor := ' trabalha ';
      else
        v_infoMessageSetor := ' não trabalha ';
      end if;
    
      for c_prodDep in (select pd.identidade, pd.materialperigoso,
                               pd.idclassificacaomatperigoso,
                               cmp.localizacaofc
                          from produtodepositante pd,
                               classificacaomaterialperigoso cmp
                         where pd.idproduto = p_idproduto
                           and pd.idclassificacaomatperigoso = cmp.id(+))
      loop
      
        v_produtoTemDepositante := C_SIM;
      
        if (c_prodDep.materialperigoso = C_SIM) then
          v_infoMessageProd := ' trabalha ';
        else
          v_infoMessageProd := ' não trabalha ';
        end if;
      
        if (v_setorAceitaMaterialPerigoso <> c_prodDep.materialperigoso) then
        
          if (v_setorAceitaMaterialPerigoso = 0 and
             c_prodDep.materialperigoso = 1 and
             c_prodDep.Localizacaofc = C_HAZMAT_SPECIALIZED_AREA) then
          
            v_msg := t_message('Um Produto cuja sua classificação de material perigoso possui a informação de "LOCATION IN FC" igual a "0" só pode ser armazenado em setor específico');
            v_msg.addParam(C_HAZMAT_SPECIALIZED_AREA);
            raise_application_error(-20000, v_msg.formatMessage);
          
          elsif (v_setorAceitaMaterialPerigoso = 0 and
                c_prodDep.materialperigoso = 1 and
                nvl(c_prodDep.Localizacaofc, 0) <>
                C_HAZMAT_SPECIALIZED_AREA) then
          
            null;
          
          else
            v_msg := t_message('Setor id:[{0}] {1} com Materiais Perigosos (HAZMAT). O Produto id:[{2}] do Depositante id:[{3}] {4} com Materiais Perigosos (HAZMAT).');
            v_msg.addParam(p_idsetor);
            v_msg.addParam(v_infoMessageSetor);
            v_msg.addParam(p_idproduto);
            v_msg.addParam(c_prodDep.identidade);
            v_msg.addParam(v_infoMessageProd);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        else
          if (v_setorAceitaMaterialPerigoso = 1 and
             c_prodDep.materialperigoso = 1) then
            begin
              select count(1)
                into v_classifMatPerigosoVincSetor
                from setorclassificacaomatperigoso scmp
               where scmp.idclassificacaomatperigoso =
                     c_prodDep.idclassificacaomatperigoso
                 and scmp.idsetor = p_idsetor;
            
            exception
              when no_data_found then
                v_classifMatPerigosoVincSetor := 0;
            end;
          
            if (v_classifMatPerigosoVincSetor = 0) then
              v_msg := t_message('Setor id:[{0}] não possui a classificação de material perigoso id:[{1}] vinculada.');
              v_msg.addParam(p_idsetor);
              v_msg.addParam(c_prodDep.idclassificacaomatperigoso);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
          end if;
        end if;
      
      end loop;
    
      if (v_produtoTemDepositante = C_NAO) then
        v_msg := t_message('Produto id:[{0}] não possui Depositante vinculado!');
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end if;
  
    select count('x')
      into v_existe
      from setorproduto
     where idproduto = p_idproduto
       and idsetor = p_idsetor;
  
    if (v_setorDevolucaoFornecedor = C_NAO) then
      if (pk_setor.isSetorTipoProdutoValido(p_idproduto, p_idsetor)) then
        if (v_existe = 0) then
          insert into setorproduto
            (idproduto, idsetor, prioridade)
          values
            (p_idproduto, p_idsetor, p_prioridade);
        else
          update setorproduto
             set prioridade = p_prioridade
           where idproduto = p_idproduto
             and idsetor = p_idsetor;
        end if;
      else
        v_msg := t_message('Produto id:[{0}] não possui tipo de produto cadastrado no setor!.</br> Setor configurado para produtos especiais.');
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      if (v_existe = 0) then
        insert into setorproduto
          (idproduto, idsetor, prioridade)
        values
          (p_idproduto, p_idsetor, p_prioridade);
      else
        update setorproduto
           set prioridade = p_prioridade
         where idproduto = p_idproduto
           and idsetor = p_idsetor;
      end if;
    end if;
  
  end vincularSetor;

  procedure removerSetor
  (
    p_idproduto in produto.idproduto%type,
    p_idsetor   in setor.idsetor%type
  ) is
  begin
    delete setorproduto
     where idproduto = p_idproduto
       and idsetor = p_idsetor;
  end removerSetor;

  function getEmbalagemEquivalente
  (
    p_idproduto     in number,
    p_barra         in embalagem.barra%type,
    p_fatoconvercao in number
  ) return varchar2 is
    v_barraprincipal embalagem.barra%type;
    v_barra          embalagem.barra%type;
    v_qtde           number;
  begin
    v_barraprincipal := nvl(pk_produto.retornar_codbarra(p_idproduto,
                                                         p_fatoconvercao),
                            p_barra);
  
    select count(1)
      into v_qtde
      from embalagemequivalente e, embalagem ep, embalagem ee
     where e.barraprincipal = v_barraprincipal
       and e.barraequivalente = p_barra
       and ep.idproduto = e.idprodutoprincipal
       and ep.barra = e.barraprincipal
       and ep.ativo = 'S'
       and ee.idproduto = e.idprodutoequivalente
       and ee.barra = e.barraequivalente
       and ee.ativo = 'S';
  
    if v_qtde > 0 then
      v_barra := p_barra;
    else
      v_barra := v_barraprincipal;
    end if;
  
    return v_barra;
  end;

  function retornarCodBarraMaiorFatorQtde
  (
    p_idproduto in number,
    p_qtdeUnit  in number
  ) return varchar2 is
    cursor c_emb(p_idproduto in number) is
      select fatorconversao, barra
        from embalagem e
       where e.idproduto = p_idproduto
         and e.ativo = 'S'
       order by e.fatorconversao desc;
  
    r_emb      c_emb%rowtype;
    v_barra    embalagem.barra%type;
    v_qtdeUnit number;
  begin
    v_qtdeUnit := p_qtdeUnit;
  
    if (v_qtdeUnit < 1) then
      v_qtdeUnit := 1;
    end if;
  
    if c_emb%isopen then
      close c_emb;
    end if;
    open c_emb(p_idproduto);
    fetch c_emb
      into r_emb;
    v_barra := null;
  
    while (c_emb%found and v_barra is null)
    loop
      if trunc(v_qtdeUnit / r_emb.fatorconversao) > 0 then
        v_barra := r_emb.barra;
      end if;
    
      fetch c_emb
        into r_emb;
    end loop;
    close c_emb;
  
    return v_barra;
  end;

  procedure validarCriacaoKit
  (
    p_idprodutopai in number,
    p_idproduto    in number,
    p_estojo       in number
  ) is
    v_codproduto          varchar2(60);
    v_descricaoproduto    varchar2(120);
    v_codprodutoaux       varchar2(60);
    v_descricaoprodutoaux varchar2(120);
    v_msg                 t_message;
    v_existe              number;
  begin
    select count(1)
      into v_existe
      from kitproduto
     where idproduto IN (select idprodutokit
                           from kitproduto
                          where idproduto = p_idprodutopai);
  
    -- Verifica se o componente tem um "avo" (kit de kit)
    if (v_existe >= 1) then
      select codigointerno, descr
        into v_codproduto, v_descricaoproduto
        from produto
       where idproduto = p_idprodutopai;
    
      v_msg := t_message('Parametrização de inclusão de componente não permitida' ||
                         ' para o produto [idProduto: {0}] <b>{1} - {2}</b>.</br>' ||
                         ' O produto é parte de uma composição em que seu agrupador' ||
                         ' é item de receita de Estojo ou Kit.');
    
      v_msg.addParam(p_idprodutopai);
      v_msg.addParam(v_codproduto);
      v_msg.addParam(v_descricaoproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_existe
      from kitproduto k
     where k.idprodutokit = p_idproduto
       and exists (select 1
              from kitproduto kit
             where kit.idprodutokit = k.idproduto);
  
    -- Verifica se um componente do componente que está sendo inserido é um kit
    if (v_existe >= 1) then
      select codigointerno, descr
        into v_codproduto, v_descricaoproduto
        from produto
       where idproduto = p_idproduto;
    
      v_msg := t_message('Parametrização de inclusão de componente não permitida.' ||
                         ' O produto <b>{0} - {1}</b> possui um Estojo ou Kit' ||
                         ' como sua receita.');
    
      v_msg.addParam(v_codproduto);
      v_msg.addParam(v_descricaoproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_existe
      from kitproduto
     where idproduto = p_idprodutopai;
  
    -- Verifica se o componente que está sendo inserido é um estojo de um produto que é kit
    if (v_existe >= 1 and p_estojo = 1) then
      select codigointerno, descr
        into v_codproduto, v_descricaoproduto
        from produto
       where idproduto = p_idproduto;
    
      v_msg := t_message('Parametrização de inclusão de componente não permitida.' ||
                         ' O produto <b>{0} - {1}</b> não pode ser Estojo, pois seu produto' ||
                         ' agrupador já pertence a um kit.');
    
      v_msg.addParam(v_codproduto);
      v_msg.addParam(v_descricaoproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    --
    select count(1)
      into v_existe
      from kitproduto k
     where k.idprodutokit = p_idproduto
       and exists (select 1
              from kitproduto kit
             where kit.idproduto = p_idprodutopai);
  
    -- verifica se o produto que está sendo vinculado é um kit, e verifica se o produto selecionado
    -- é componente de um kit
    if (v_existe >= 1) then
    
      select codigointerno, descr
        into v_codproduto, v_descricaoproduto
        from produto
       where idproduto = p_idprodutopai;
    
      select codigointerno, descr
        into v_codprodutoaux, v_descricaoprodutoaux
        from produto
       where idproduto = p_idproduto;
    
      v_msg := t_message('Parametrização de inclusão de componente não permitida.' ||
                         ' O produto <b>{0} - {1}</b> é componente de um kit e o produto ' ||
                         ' <b>{2} - {3}</b> é um Estojo ou Kit');
    
      v_msg.addParam(v_codproduto);
      v_msg.addParam(v_descricaoproduto);
      v_msg.addParam(v_codprodutoaux);
      v_msg.addParam(v_descricaoprodutoaux);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
    --
  
  end validarCriacaoKit;

  procedure addProdutoKit
  (
    p_idproduto    in number,
    p_idprodutopai in number,
    p_barra        in varchar2,
    p_qtde         in number,
    p_estojo       in number
  ) as
    v_temmovimentacao     number;
    v_embfatorconversaoum number;
    v_fracionado          number;
    v_existe              number;
    v_msg                 t_message;
  
    function isPermitidoComoComponente
    (
      p_idProduto in number,
      p_soEstojo  in number
    ) return boolean is
      v_controle      number := 0;
      v_msg           t_message;
      v_codigoInterno produto.codigointerno%type;
    begin
    
      select p.codigointerno
        into v_codigoInterno
        from produto p
       where p.idproduto = p_idProduto;
    
      select count(*)
        into v_controle
        from produto p
       where p.idproduto = p_idProduto
         and p.combo = 1;
    
      if (v_controle > 0) then
        v_msg := t_message('Operação não permitida, o produto [idProduto: {0} - {1}] não pode ser utilizado como componente pois é um agrupador de Estojo / Combo.');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(v_codigoInterno);
        raise_application_error(-20000, v_msg.formatMessage());
      end if;
    
      -- Validar sucessores....
      select count(*)
        into v_controle
        from kitproduto k
       where k.idprodutokit = p_idProduto
         and k.estojo = 1;
      if (v_controle > 0) then
        v_msg := t_message('Operação não permitida, o produto [idProduto: {0} - {1}] não pode ser utilizado como componente pois é um Kit que possui estojo em sua composição.');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(v_codigoInterno);
        raise_application_error(-20000, v_msg.formatMessage());
      end if;
    
      select count(*)
        into v_controle
        from kitproduto k
       where k.idprodutokit = p_idProduto
         and exists (select 1
                from kitproduto ka
               where ka.idprodutokit = k.idproduto);
      if (v_controle > 0) then
        v_msg := t_message('Operação não permitida, o produto [idProduto: {0} - {1}] não pode ser utilizado como componente pois é um Kit que possui Kit em sua composição.');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(v_codigoInterno);
        raise_application_error(-20000, v_msg.formatMessage());
      end if;
    
      -- validar antecessores...
      if (p_soEstojo = 1) then
        select count(*)
          into v_controle
          from Kitproduto k
         where k.idproduto = p_idProduto
           and exists (select 1
                  from Kitproduto ka
                 where ka.idproduto = k.idprodutokit);
      
        if (v_controle > 0) then
          v_msg := t_message('Operação não permitida, o produto [idProduto: {0} - {1}] não pode ser utilizado como componente estojo, o mesmo é receita de Kit que por sua vez é receita de outro Kit.');
          v_msg.addParam(p_idProduto);
          v_msg.addParam(v_codigoInterno);
          raise_application_error(-20000, v_msg.formatMessage());
        end if;
      end if;
    
      select count(*)
        into v_controle
        from produto p
       where p.idproduto = p_idprodutopai
         and exists
       (select 1
                from Kitproduto ka
               where ka.idproduto = p.idproduto
                 and exists
               (select 1
                        from kitproduto kb
                       where kb.idproduto = ka.idprodutokit));
      if (v_controle > 0) then
        v_msg := t_message('Operação não permitida, o produto [idProduto: {0} - {1}] não pode ser utilizado como componente, pois o seu produto agrupador já é componente de Kit que por sua vez é receita de outro Kit.');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(v_codigoInterno);
        raise_application_error(-20000, v_msg.formatMessage());
      end if;
    
      return true;
    end isPermitidoComoComponente;
  
  begin
  
    select count(1)
      into v_temmovimentacao
      from nfdet
     where idproduto = p_idprodutopai;
  
    if (v_temmovimentacao >= 1) then
      v_msg := t_message('Não foi possível incluir ou alterar produto do kit. O Produto ' ||
                         '{0} tem movimentação.');
      v_msg.addParam(p_idprodutopai);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_embfatorconversaoum
      from embalagem
     where idproduto = p_idproduto
       and fatorconversao = 1
       and ativo = 'S';
  
    if (v_embfatorconversaoum = 0) then
      v_msg := t_message('Não é possível inserir ou alterar registro. Embalagem de menor fator no cadastrada para o produto. Id Produto: {0}');
      v_msg.addParam(p_idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_fracionado
      from produto
     where idproduto = p_idproduto
       and pesavel = 1;
  
    if (v_fracionado = 1) then
      v_msg := t_message('Não é possível inserir ou alterar registros. Produto fracionado não pode compor receita de Kit. Id Produto: {0}');
      v_msg.addParam(p_idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if ehKit(p_idproduto)
       and p_estojo = 1 then
      v_msg := t_message('Não é possível ativar "Permitir apenas estojo" para componente que seja kit.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (isPermitidoComoComponente(p_idproduto, p_estojo)) then
      select count(1)
        into v_existe
        from kitproduto
       where idprodutokit = p_idprodutopai
         and idproduto = p_idproduto
         and barra = p_barra;
    
      if (v_existe = 0) then
        insert into kitproduto
          (idprodutokit, idproduto, barra, qtde, estojo)
        values
          (p_idprodutopai, p_idproduto, p_barra, p_qtde, p_estojo);
      else
        update kitproduto
           set qtde   = p_qtde,
               estojo = p_estojo
         where idprodutokit = p_idprodutopai
           and idproduto = p_idproduto
           and barra = p_barra;
      end if;
    end if;
  
  end addProdutoKit;

  procedure removerProdutoKit
  (
    p_idproduto    in number,
    p_idprodutopai in number,
    p_barra        in VARCHAR2
  ) as
    v_temmovimentacao number;
    v_msg             t_message;
  begin
    select count(1)
      into v_temmovimentacao
      from nfdet
     where idproduto = p_idprodutopai;
  
    if (v_temmovimentacao >= 1) then
      v_msg := t_message('Não foi possível retirar produto do kit. O Produto ' ||
                         '{0} tem movimentação.');
      v_msg.addParam(p_idprodutopai);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from kitproduto
     where IDPRODUTOKIT = p_idprodutopai
       and IDPRODUTO = p_idproduto
       and barra = p_barra;
  end;

  function retCodSeparadoBarraProdLote
  (
    p_codbarra       in varchar2,
    p_iddepositante  in number,
    p_tipoRetorno    in number,
    p_infoespecifica in number := 0
  ) return varchar2 is
    v_identLoteIndustria number := 0;
    v_loteIndustria      varchar2(300);
    v_dataVencimento     date;
    v_qtde               number;
  begin
    return retCodSeparadoBarraProdLoteMap(p_codbarra, p_iddepositante,
                                          p_tipoRetorno,
                                          v_identLoteIndustria,
                                          v_loteIndustria, v_dataVencimento,
                                          p_infoespecifica, null, v_qtde);
  end retCodSeparadoBarraProdLote;

  function retCodSeparadoBarraProdLoteMap
  (
    p_codbarra           in varchar2,
    p_iddepositante      in number,
    p_tipoRetorno        in number,
    p_identLoteIndustria in out number,
    p_loteIndustria      in out varchar2,
    p_dtVencimento       in out date,
    p_infoespecifica     in number := 0,
    p_idLote             in number,
    p_qtde               in out number
  ) return varchar2 is
  
    C_RET_COD_PRODUTO number := 0;
    C_RET_COD_LOTE    number := 1;
  
    v_utilizacodbarraprodutolote number;
    v_numcharcodbarraproduto     number;
    v_retorno                    varchar2(100);
    v_buscaEmbalagemRegra        varchar2(100);
    v_embalagemEncontrada        number;
    v_msg                        t_message;
  
    function getBarraRegraDepositante return varchar2 is
      C_REGRA_ENCONTRADA CONSTANT NUMBER := 1;
      v_resultado     number;
      v_codProduto    produto.codigointerno%type;
      v_barraProduto  embalagem.barra%type;
      v_qtde          number;
      v_loteIndustria lote.descr%type;
      v_dtVencimento  date;
    begin
      v_resultado := pk_depositante.getDadosBarraRegraDepositante(p_iddepositante,
                                                                  p_codbarra,
                                                                  v_codProduto,
                                                                  v_barraProduto,
                                                                  v_qtde,
                                                                  v_loteIndustria,
                                                                  v_dtVencimento);
    
      p_loteIndustria := v_loteIndustria;
      p_dtVencimento  := v_dtVencimento;
      p_qtde          := v_qtde;
    
      if (v_resultado = C_REGRA_ENCONTRADA) then
        if (v_barraProduto is not null) then
          return v_barraProduto;
        end if;
      
        if (v_barraProduto is null and v_codProduto is not null) then
          begin
            select emb.barra
              into v_barraProduto
              from produtodepositante pd, embalagem emb
             where pd.identidade = p_iddepositante
               and pd.codigointerno = v_codProduto
               and emb.idproduto = pd.idproduto
               and emb.barra =
                   pk_produto.ret_codbarra_nao_precad(pd.idproduto, 1);
          exception
            when no_data_found then
              v_barraProduto := null;
          end;
        end if;
      end if;
    
      return v_barraProduto;
    end getBarraRegraDepositante;
  
    procedure defineRetornoBarraLote is
    begin
      select count(1)
        into v_embalagemEncontrada
        from embalagem e
       where e.barra = v_retorno;
    
      if (v_embalagemEncontrada = 0) then
        begin
        
          select e.barra
            into v_retorno
            from lote lt, embalagem e
           where e.idproduto = lt.idproduto
             and e.barra = lt.barra
             and lt.iddepositante = p_iddepositante
             and (lt.descr = upper(p_loteIndustria) or
                 to_char(lt.idlote) = to_char(p_codbarra))
             and lt.idlote = nvl(p_idLote, lt.idlote)
           group by e.barra;
        
          p_identLoteIndustria := 1;
        
        exception
          when others then
            v_msg := t_message('BARRA DO PRODUTO OU LOTE INDÚSTRIA NÃO ENCONTRADO: {0}');
            v_msg.addParam(p_codbarra);
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      end if;
    end defineRetornoBarraLote;
  
  begin
    if p_codbarra is null then
      return null;
    end if;
  
    p_identLoteIndustria := 0;
  
    if p_iddepositante is null then
      v_msg := t_message('Depositante está nulo.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    begin
      select d.utilizacodbarraprodutocomlote,
             nvl(d.numcharcodbarraproduto, 0)
        into v_utilizacodbarraprodutolote, v_numcharcodbarraproduto
        from depositante d
       where d.identidade = p_iddepositante;
    
    exception
      when no_data_found then
        v_msg := t_message('Depositante com id: {0} no encontrado.');
        v_msg.addParam(p_iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    v_retorno := upper(p_codbarra);
  
    select count(1)
      into v_embalagemEncontrada
      from embalagem e
     where e.barra = v_retorno;
  
    if (v_embalagemEncontrada = 0) then
      v_buscaEmbalagemRegra := getBarraRegraDepositante;
    
      if (p_tipoRetorno = C_RET_COD_LOTE) then
        p_identLoteIndustria := 1;
      end if;
    
      if (v_buscaEmbalagemRegra is not null) then
        return v_buscaEmbalagemRegra;
      end if;
    end if;
  
    --Separa o codigo de barras e atribui o v_retorno de acordo com o p_tipoRetorno(0 - Cod. Produto | 1 - Lote)
    if v_utilizacodbarraprodutolote = 1
       and v_numcharcodbarraproduto > 0 then
      if p_tipoRetorno = C_RET_COD_PRODUTO then
        v_retorno := substr(p_codbarra, 0, v_numcharcodbarraproduto);
      end if;
    
      if ((p_tipoRetorno = C_RET_COD_LOTE) and
         (length(v_retorno) > v_numcharcodbarraproduto)) then
        v_retorno := upper(substr(p_codbarra, v_numcharcodbarraproduto + 1));
        if (nvl(p_infoespecifica, 0) = 0) then
          defineRetornoBarraLote;
        end if;
      end if;
    end if;
  
    if v_utilizacodbarraprodutolote = 0
       and p_tipoRetorno = C_RET_COD_LOTE
       and nvl(p_infoespecifica, 0) = 0 then
      defineRetornoBarraLote;
    end if;
  
    if (v_embalagemEncontrada = 0 and nvl(p_infoespecifica, 0) = 0) then
      if (upper(v_retorno) = upper(p_codbarra)) then
        return null;
      end if;
    end if;
  
    return v_retorno;
  end;

  -- Verifica se existe mais de um depositante para o mesmo endereo.<br>
  -- Se tiver mais de um depositante para o mesmo endereo, desconsidera a regra de separar o codigo do produto do lote (presente no codigo de barras lido).
  FUNCTION F_BUSCABARRAOULOTE
  (
    P_BARRA      IN VARCHAR2,
    P_IDLOCAL    IN VARCHAR2,
    P_IDARMAZEM  IN VARCHAR2,
    TIPO_RETORNO IN NUMBER
  ) RETURN VARCHAR2 IS
    v_barra            varchar2(100);
    v_qtdeDepositantes number := 0;
    v_idDepositante    number;
    v_msg              t_message;
  
    C_RET_COD_PRODUTO number := 0; -- retorna somente a barra do produto sem o lote
    C_RET_COD_LOTE    number := 1; -- retorna o lote
  
  BEGIN
    v_barra := P_BARRA;
    if (TIPO_RETORNO not in (C_RET_COD_PRODUTO, C_RET_COD_LOTE)) then
      v_msg := t_message('Tipo de retorno inválido: {0}.' ||
                         ' Tipos permitidos: 0 retorno Produto, 1 retorno Lote');
      v_msg.addParam(TIPO_RETORNO);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count('x')
      into v_qtdeDepositantes
      from (select identidade
               from produtolocal
              where idarmazem = P_IDARMAZEM
                and idlocal = P_IDLOCAL
              group by idarmazem, idlocal, identidade);
  
    if (v_qtdeDepositantes = 1) then
      select identidade
        into v_idDepositante
        from (select identidade
                 from produtolocal
                where idarmazem = P_IDARMAZEM
                  and idlocal = P_IDLOCAL
                group by idarmazem, idlocal, identidade);
    
      v_barra := pk_produto.retCodSeparadoBarraProdLote(v_barra,
                                                        v_idDepositante,
                                                        TIPO_RETORNO);
    end if;
    return v_barra;
  END F_BUSCABARRAOULOTE;

  procedure removerInformacaoEspecifica
  (
    p_idproduto  in produto.idproduto%type,
    p_identidade in entidade.identidade%type,
    p_idusuario  in usuario.idusuario%type
  ) as
    v_qtde         number;
    v_delEst       number;
    v_delInfMatDep number;
    v_msg          t_message;
  begin
    select count(pd.identidade)
      into v_qtde
      from produtodepositante pd
     where pd.identidade = p_identidade
       and pd.idproduto = p_idproduto;
  
    if (v_qtde = 0) then
      v_msg := t_message('Produto no vinculado ao depositante');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    --Alterao para a menor rastreabilidade
    update produtodepositante pd
       set pd.rastrearinfoespecifica = 2
     where pd.identidade = p_identidade
       and pd.idproduto = p_idproduto;
  
    insert into historicoestoqueinfespec
      (id, idarmazem, idproduto, identidade, idinfomaterial,
       identificadorinfo, numerooperacao, operacao, dataoperacao, valorantes,
       valordepois, idloteantes, idlotedepois, conferidoantes,
       conferidodepois, expedidoantes, expedidodepois)
      select seq_historicoestoqueinfespec.nextval, e.idarmazem, e.idproduto,
             e.identidade, e.idinfomaterial, e.identificadorinfo,
             e.idproduto,
             'REMOVIDO ESTOQUE INFORMACAO ESPECIFICA DO PRODUTO', sysdate,
             e.valor, e.valor, e.idlote, e.idlote, e.conferido, e.conferido,
             e.expedida, e.expedida
        from estoqueinformacaoespecifica e
       where e.expedida = 0
         and e.conferido = 0
         and e.identidade = p_identidade
         and e.idproduto = p_idproduto;
  
    delete estoqueinformacaoespecifica e
     where e.expedida = 0
       and e.conferido = 0
       and e.identidade = p_identidade
       and e.idproduto = p_idproduto;
  
    v_delEst := sql%rowcount;
  
    delete informacaomatdep imd
     where imd.identidade = p_identidade
       and imd.idproduto = p_idproduto;
  
    v_delInfMatDep := sql%rowcount;
  
    if (v_delEst > 0 or v_delInfMatDep > 0) then
      pk_utilities.GeraLog(p_idusuario,
                           'REMOO DE INFORMAO ESPECFICA (IDPRODUTO: ' ||
                            p_idproduto || ', IDENTIDADE: ' || p_identidade ||
                            '). QTDE REGISTROS ESTOQUEINFORMACAOESPECIFICA: ' ||
                            v_delEst || ', INFORMACAOMATDEP: ' ||
                            v_delInfMatDep, p_idproduto, 'RI');
    else
      pk_utilities.GeraLog(p_idusuario,
                           'NENHUMA REMOO DE INFORMAO ESPECFICA (IDPRODUTO: ' ||
                            p_idproduto || ', IDENTIDADE: ' || p_identidade || ')',
                           p_idproduto, 'RI');
    end if;
  
  end;

  function getDepositantesRegraDaBarra(p_barraInformada in varchar2)
    return number is
    v_qtdDepositantes number;
    v_qtdDepRetornar  number;
    v_msg             t_message;
  begin
    v_qtdDepositantes := 0;
    v_qtdDepRetornar  := 0;
  
    delete from GTT_BARRA_REGRADEPOSITANTE;
  
    if (p_barraInformada is null OR length(p_barraInformada) = 0) then
      v_msg := t_message(' necessrio informar uma barra para buscar a regra.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for r_Regras in (select r.iddepositante, e.razaosocial, p_barraInformada
                       from regrabarradepositante r, entidade e
                      where r.tamanho = length(p_barraInformada)
                        and e.identidade = r.iddepositante)
    loop
      pk_depositante.encontrarRegraBarraDepositante(r_Regras.iddepositante,
                                                    p_barraInformada,
                                                    v_qtdDepositantes);
      if (v_qtdDepositantes > 0) then
        v_qtdDepRetornar := v_qtdDepRetornar + 1;
      end if;
    end loop;
  
    return v_qtdDepRetornar;
  end getDepositantesRegraDaBarra;

  function isExibirPontoAlerta
  (
    p_idproduto        in number,
    p_qtdeUnitSeparada in number,
    p_idOnda           confpacking.idOnda%type,
    p_codBarraTarefa   confpacking.codBarraTarefa%type
  ) return number is
    v_possuiTipoEmbalAlertaPacking number;
  begin
    select count(1)
      into v_possuiTipoEmbalAlertaPacking
      from embalagem e
     where e.idproduto = p_idproduto
       and e.ativo = 'S'
       and exists
     (select 1
              from tipoembalagem te
             where e.idtipoembalagem = te.idtipoembalagem
               and e.fatorconversao <= p_qtdeUnitSeparada
               and te.exibiralertapacking = EXIBE_ALERTA_PACKING);
  
    if (v_possuiTipoEmbalAlertaPacking <> 0) then
      return EXIBE_ALERTA_PACKING;
    end if;
  
    return NAO_EXIBE_ALERTA_PACKING;
  end;

  function sugestaoEmbalagem
  (
    p_idproduto        in number,
    p_qtdeUnitSeparada in number
  ) return varchar2 is
    v_msg varchar(4000);
  
  begin
    for c in (select *
                from (select e.descrreduzido
                         from embalagem e, tipoembalagem t
                        where e.idproduto = p_idproduto
                          and e.ativo = 'S'
                          and e.fatorconversao <= p_qtdeUnitSeparada
                          and t.idtipoembalagem = e.idtipoembalagem
                          and t.exibiralertapacking = EXIBE_ALERTA_PACKING
                        order by fatorconversao desc)
               where rownum = 1)
    loop
      v_msg := c.descrreduzido;
    end loop;
  
    return v_msg;
  end;

  function getBarraFatorMaiorGS1
  (
    p_codbarra   in embalagem.barra%type,
    p_quantidade in number
  ) return varchar2 is
    v_isbarrafatorunitario number;
    v_fatorconversao       number;
    v_barraencontrada      embalagem.barra%type;
    v_msg                  t_message;
  
  begin
    if p_codbarra is null then
      v_msg := t_message('Essa barra GS1 não possui código de barras EAN.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if p_quantidade is null then
      v_msg := t_message('Essa barra GS1 não possui o valor da quantidade.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_isbarrafatorunitario
      from embalagem e
     where e.barra = p_codbarra
       and e.fatorconversao = 1
       and e.ativo = 'S';
  
    if v_isbarrafatorunitario = 1
       and p_quantidade > 1 then
      v_fatorconversao := p_quantidade;
      begin
        select ef.barra
          into v_barraencontrada
          from embalagem ef, embalagem e
         where e.barra = p_codbarra
           and ef.idproduto = e.idproduto
           and ef.fatorconversao = v_fatorconversao
           and ef.ativo = 'S'
           and rownum = 1;
      exception
        when no_data_found then
          v_msg := t_message('Nenhuma embalagem encontrada com o fator de converso: {0}');
          v_msg.addParam(v_fatorconversao);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
      return v_barraencontrada;
    
    else
      return p_codbarra;
    end if;
  
  end;

  procedure cadastrarProdutoImportacao
  (
    p_origem        in number,
    p_iddepositante in number,
    p_produto       in out pk_integracao.t_produto,
    p_embalagem     in out embalagem%rowtype,
    p_erro          in out varchar2
  ) is
    r_padraointdepositante padraointdepositante%rowtype;
    r_produtodepositante   produtodepositante%rowtype;
    r_emb                  embalagem%rowtype;
    r_prod                 pk_integracao.t_produto;
  
    v_movestoque             char(1);
    v_msg                    t_message;
    v_descricaoVazio         varchar2(50);
    v_cadastraProdImpInbound number;
  
    type t_depositante is record(
      cadastrarProduto       depositante.cadprodutointegracao%type,
      cadastrarProdutoXOPA   depositante.cadastraprodutocompraxopa%type,
      cadastrarProdutoTDN    depositante.cadastraprodutoimportartdn%type,
      existePadraoIntDep     padraointdepositante.identidade%type,
      existeDadosDepositante number,
      cnpj                   entidade.cgc%type,
      inscricaoEstadual      entidade.inscrestadual%type,
      cadastrarProdutoTR     depositante.cadastraprodutoimportartr%type,
      cadastrarProdutoImpAsn depositante.cadastraprodutoimpasn%type);
  
    r_depositante t_depositante;
  
    procedure carregarDados is
    begin
      begin
        select d.cadprodutointegracao, d.cadastraprodutocompraxopa,
               d.cadastraprodutoimportartdn,
               nvl(pid.identidade, 0) existePadraoIntDep, e.cgc,
               e.inscrestadual, d.cadastraprodutoimportartr,
               d.cadastraprodutoimpasn
          into r_depositante.cadastrarProduto,
               r_depositante.cadastrarProdutoXOPA,
               r_depositante.cadastrarProdutoTDN,
               r_depositante.existePadraoIntDep, r_depositante.cnpj,
               r_depositante.inscricaoEstadual,
               r_depositante.cadastrarProdutoTR,
               r_depositante.cadastrarProdutoImpAsn
          from depositante d, entidade e, padraointdepositante pid
         where d.identidade = p_iddepositante
           and e.identidade = d.identidade
           and pid.identidade(+) = d.identidade;
      exception
        when no_data_found then
          --analisar pois dever sair da pk_produto
          r_depositante.existeDadosDepositante := 0;
      end;
    end carregarDados;
  
    procedure carregarDadosPadraoIntDeposit is
    begin
      select *
        into r_padraointdepositante
        from padraointdepositante
       where identidade = p_iddepositante;
    end carregarDadosPadraoIntDeposit;
  
    procedure preencherProdutoDepositante is
    begin
      r_produtodepositante.identidade                  := p_iddepositante;
      r_produtodepositante.idproduto                   := null;
      r_produtodepositante.codigointerno               := p_produto.codigointerno;
      r_produtodepositante.descrimp                    := p_produto.descricao;
      r_produtodepositante.fatorestoque                := 1;
      r_produtodepositante.qtdeminimaproducaokit       := null;
      r_produtodepositante.somaitemduplicadoimp        := null;
      r_produtodepositante.multivolume                 := null;
      r_produtodepositante.idprodutogenerico           := null;
      r_produtodepositante.identidadegenerico          := null;
      r_produtodepositante.tipoalocpalletcompleto      := r_padraointdepositante.tipoalocacaopaletecompleto;
      r_produtodepositante.tipoalocpalletincompleto    := r_padraointdepositante.tipoalocacaopaleteincompleto;
      r_produtodepositante.tipoalocpalletsobra         := r_padraointdepositante.tipoalocacaopaletesobra;
      r_produtodepositante.tipoalocpalletquebra        := r_padraointdepositante.tipoalocacaopaleteunidade;
      r_produtodepositante.tipoparticipacaomontagem    := r_padraointdepositante.tipoparticipacaomontagem;
      r_produtodepositante.utilizaembpadrao            := null;
      r_produtodepositante.utilizaestoquepulmao        := null;
      r_produtodepositante.utilizalastroproduto        := null;
      r_produtodepositante.percentualentrada           := null;
      r_produtodepositante.percentualsaida             := null;
      r_produtodepositante.pickingdinamico             := r_padraointdepositante.pickingdinamico;
      r_produtodepositante.coletadtavenclote           := r_padraointdepositante.coletadtavenclote;
      r_produtodepositante.loteuniconoendereco         := r_padraointdepositante.loteunicoendereco;
      r_produtodepositante.loteuniconovolume           := r_padraointdepositante.loteunicovolume;
      r_produtodepositante.qtdemaxpicking              := r_padraointdepositante.qtdemaxpicking;
      r_produtodepositante.regrapersonalizadaexpedprod := r_padraointdepositante.regrapersonalizadaexpedprod;
      r_produtodepositante.tipopicking                 := r_padraointdepositante.tipopicking;
      r_produtodepositante.validarmesano               := r_padraointdepositante.validarmesano;
      r_produtodepositante.coletaamostraunica          := r_padraointdepositante.coletaamostraunica;
      r_produtodepositante.controlartempodematuracao   := r_padraointdepositante.controlartempodematuracao;
    
      if r_padraointdepositante.ativo = 1 then
        r_produtodepositante.ativo := 'S';
      else
        r_produtodepositante.ativo := 'N';
      end if;
    
      if r_padraointdepositante.itemrastreado = 1 then
        r_produtodepositante.itemrastreado := 'S';
      else
        r_produtodepositante.itemrastreado := 'N';
      end if;
    
      if r_padraointdepositante.generico = 1 then
        r_produtodepositante.generico := 'S';
      else
        r_produtodepositante.generico := 'N';
      end if;
    
      if r_padraointdepositante.coletaloteindust = 1 then
        r_produtodepositante.coletaloteindust := 'S';
      else
        r_produtodepositante.coletaloteindust := 'N';
      end if;
    
      if r_padraointdepositante.movimentaestoque = 1 then
        r_produtodepositante.movestoque := 'S';
      else
        r_produtodepositante.movestoque := 'N';
      end if;
    end preencherProdutoDepositante;
  
    procedure cadastrarNovoProduto is
    begin
      r_prod.idproduto                := null;
      r_prod.codigointerno            := p_produto.codigointerno;
      r_prod.descricao                := p_produto.descricao;
      r_prod.tipoproduto              := null;
      r_prod.idtipoproduto            := r_padraointdepositante.idtipo;
      r_prod.subtipo                  := null;
      r_prod.idsubtipo                := r_padraointdepositante.idsubtipo;
      r_prod.marca                    := null;
      r_prod.idmarca                  := r_padraointdepositante.idmarca;
      r_prod.submarca                 := null;
      r_prod.idsubmarca               := r_padraointdepositante.idsubmarca;
      r_prod.subfamilia               := null;
      r_prod.idsubfamilia             := r_padraointdepositante.idsubfamilia;
      r_prod.idfamilia                := r_padraointdepositante.idfamilia;
      r_prod.codigoreferencia         := nvl(p_produto.codigoreferencia,
                                             p_produto.codigointerno);
      r_prod.cor                      := null;
      r_prod.perctolerancia           := null;
      r_prod.manufaturado             := null;
      r_prod.sazonal                  := null;
      r_prod.controlefifo             := null;
      r_prod.controlalote             := null;
      r_prod.prazovalidade            := r_padraointdepositante.prazovalidade;
      r_prod.prazocomercializacao     := r_padraointdepositante.prazocomercializacao;
      r_prod.prazocritico             := r_padraointdepositante.prazocritico;
      r_prod.multiendereco            := null;
      r_prod.precadastro              := null;
      r_prod.otimizaseparacao         := null;
      r_prod.ncm                      := p_produto.ncm;
      r_prod.cest                     := p_produto.cest;
      r_prod.descrimpr                := p_produto.descricao;
      r_prod.pontoreabastecimento     := r_padraointdepositante.pontoreabastecimento;
      r_prod.pontoressuprimento       := r_padraointdepositante.pontoressuprimento;
      r_prod.produtocritico           := r_padraointdepositante.produtocritico;
      r_prod.pesavel                  := r_padraointdepositante.pesavel;
      r_prod.codigoprodanvisa         := p_produto.codigoprodanvisa;
      r_prod.precomaximoconsumidor    := p_produto.precomaximoconsumidor;
      r_prod.tempoparamaturacaoemdias := r_padraointdepositante.tempoparamaturacaoemdias;
      r_prod.motivoIsencao            := p_produto.motivoIsencao;
    
      if r_padraointdepositante.precadastro = 1 then
        r_prod.precadastro := 'S';
      else
        r_prod.precadastro := 'N';
      end if;
      if r_padraointdepositante.ativo = 1 then
        r_prod.ativo := 'S';
      else
        r_prod.ativo := 'N';
      end if;
      if r_padraointdepositante.segregado = 1 then
        r_prod.segregado := 'S';
      else
        r_prod.segregado := 'N';
      end if;
      if r_padraointdepositante.movimentaestoque = 1 then
        r_prod.movestoque := 'S';
      else
        r_prod.movestoque := 'N';
      end if;
      if r_padraointdepositante.fracionado = 1 then
        r_prod.fracionado := 'S';
      else
        r_prod.fracionado := 'N';
      end if;
      p_produto.movestoque := r_prod.movestoque;
    
      preencherProdutoDepositante;
      pk_produto.cadastrarProduto(r_prod, r_produtodepositante);
    end cadastrarNovoProduto;
  
    procedure cadastrarEmbalagemImportacao is
    begin
      r_emb.unidadebasicacompra := null;
      r_emb.unidadebasicavenda  := null;
      r_emb.su                  := null;
      r_emb.separacao           := null;
      r_emb.imprimeetiqueta     := null;
      r_emb.fc_antigo           := null;
      r_emb.atz_lwl             := null;
      r_emb.precadastro         := null;
      r_emb.idusuario           := null;
      r_emb.controlaestoque     := null;
      r_emb.seqemb              := null;
    
      r_emb.idproduto       := r_prod.idproduto;
      r_emb.barra           := p_embalagem.barra;
      r_emb.descr           := p_produto.descricao;
      r_emb.apresentacao    := p_embalagem.apresentacao;
      r_emb.fatorconversao  := 1;
      r_emb.idtipoembalagem := pk_produto.cadastrarTipoEmbalagem('');
      r_emb.altura          := r_padraointdepositante.altura;
      r_emb.largura         := r_padraointdepositante.largura;
      r_emb.comprimento     := r_padraointdepositante.comprimento;
      r_emb.lastro          := r_padraointdepositante.lastro;
      r_emb.qtdecamada      := r_padraointdepositante.qtdecamada;
      r_emb.pesobruto       := r_padraointdepositante.pesobruto;
      r_emb.pesoliquido     := r_padraointdepositante.pesoliquido;
      r_emb.empilhamentomax := r_padraointdepositante.empilhamentomax;
      r_emb.descrreduzido   := nvl(p_embalagem.descrreduzido,
                                   r_padraointdepositante.descrreduzido);
      r_emb.embalagempadrao := r_padraointdepositante.embalagempadrao;
      r_emb.barrainterna    := r_padraointdepositante.barrainterna;
    
      if r_padraointdepositante.precadastro = 1 then
        r_emb.precadastro := 'S';
      else
        r_emb.precadastro := 'N';
      end if;
    
      if r_padraointdepositante.ativo = 1 then
        r_emb.ativo := 'S';
      else
        r_emb.ativo := 'N';
      end if;
    
      if r_padraointdepositante.barralegivel = 1 then
        r_emb.barralegivel := 'S';
      else
        r_emb.barralegivel := 'N';
      end if;
    
      if r_padraointdepositante.caixafechada = 1 then
        r_emb.caixafechada := 'S';
      else
        r_emb.caixafechada := 'N';
      end if;
    
      pk_produto.cadastrarEmbalagem(r_emb, p_produto.codigointerno, null,
                                    null, r_depositante.cnpj,
                                    r_depositante.inscricaoEstadual);
    end cadastrarEmbalagemImportacao;
  
  begin
    p_produto.idproduto := null;
  
    carregarDados;
  
    if (nvl(r_depositante.existeDadosDepositante, 1) = 0) then
      return;
    end if;
  
    -- se a origem for da notafiscal verifica o parmetro de cadastro de produto pela nota fiscal    
    if (p_origem = 0) then
      if (nvl(r_depositante.cadastrarProduto, 0) = 0) then
        p_embalagem.barra := null;
        return;
      end if;
    end if;
  
    -- se a origem for de XOPA verifica o parmetro de cadastro de produto XOPA
    if (p_origem = 1) then
      if (nvl(r_depositante.cadastrarProdutoXOPA, 0) = 0) then
        p_embalagem.barra := null;
        return;
      end if;
    end if;
  
    -- se a origem for de TDN verifica o parmetro de cadastro de produto TDN
    if (p_origem = 2) then
      if (nvl(r_depositante.cadastrarProdutoTDN, 0) = 0) then
        p_embalagem.barra := null;
        return;
      end if;
    end if;
  
    -- se a origem for de TR verifica o parâmetro de cadastro de produto TR
    if (p_origem = 3) then
      if (nvl(r_depositante.cadastrarProdutoTR, 0) = 0) then
        p_embalagem.barra := null;
        return;
      end if;
    end if;
  
    if (p_origem = 4) then
      select d.cadastraprodutoimpasn
        into v_cadastraProdImpInbound
        from depositante d
       where d.identidade = p_iddepositante;
    
      if (v_cadastraProdImpInbound = 0) then
        v_msg := t_message('Depositante id: {0} não está configurado para cadastrar produto na importação do InboudASN');
        v_msg.addParam(p_iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    if (r_depositante.existePadraoIntDep = 0) then
      v_msg  := t_message('Não foi encontrado cadastro de informações ' ||
                          'padrões do produto para o depositante.');
      p_erro := v_msg.formatMessage;
      return;
    end if;
  
    if (p_produto.codigointerno is null) then
      v_msg            := t_message('VAZIA');
      v_descricaoVazio := v_msg.formatMessage;
      v_msg            := t_message('O CODIGO INTERNO DO PRODUTO (DESCRICAO: ' ||
                                    '{0}) ESTA VAZIO.');
      v_msg.addParam(nvl(p_produto.descricao, v_descricaoVazio));
      p_erro := v_msg.formatMessage;
      return;
    end if;
  
    r_prod.codigointerno            := p_produto.codigointerno;
    r_prod.idproduto                := pk_produto.retornarIdProduto(p_iddepositante,
                                                                    p_produto.codigointerno);
    r_produtodepositante.idproduto  := r_prod.idproduto;
    r_produtodepositante.identidade := p_iddepositante;
  
    carregarDadosPadraoIntDeposit;
  
    if r_prod.idproduto is null then
      cadastrarNovoProduto;
    else
      select movestoque
        into v_movestoque
        from produto
       where idproduto = r_prod.idproduto;
    
      p_produto.movestoque := v_movestoque;
    
      begin
        select decode(pi.itemrastreado, 1, 'S', 'N'),
               decode(pi.generico, 1, 'S', 'N'),
               decode(pi.coletaloteindust, 1, 'S', 'N'),
               pi.coletadtavenclote, pi.tipoalocacaopaletecompleto,
               pi.tipoalocacaopaleteincompleto, pi.tipoalocacaopaletesobra,
               pi.tipoalocacaopaleteunidade,
               decode(pi.movimentaestoque, 1, 'S', 'N'), pi.embalagempadrao,
               pi.pickingdinamico, nvl(r_prod.precadastro, pi.precadastro),
               pi.idfamilia, pi.loteunicovolume, pi.loteunicoendereco,
               pi.qtdemaxpicking, pi.tipopicking, pi.validarmesano,
               pi.barrainterna
          into r_produtodepositante.itemrastreado,
               r_produtodepositante.generico,
               r_produtodepositante.coletaloteindust,
               r_produtodepositante.coletadtavenclote,
               r_produtodepositante.tipoalocpalletcompleto,
               r_produtodepositante.tipoalocpalletincompleto,
               r_produtodepositante.tipoalocpalletsobra,
               r_produtodepositante.tipoalocpalletquebra,
               r_produtodepositante.movestoque,
               r_produtodepositante.utilizaembpadrao,
               r_produtodepositante.pickingdinamico, r_prod.precadastro,
               r_prod.idfamilia, r_padraointdepositante.loteunicovolume,
               r_padraointdepositante.loteunicoendereco,
               r_produtodepositante.qtdemaxpicking,
               r_produtodepositante.tipopicking,
               r_produtodepositante.validarmesano,
               r_padraointdepositante.barrainterna
          from padraointdepositante pi
         where identidade = r_produtodepositante.identidade;
      exception
        when no_data_found then
          -- Comando apenas para no ocasionar erro
          r_produtodepositante.itemrastreado := r_produtodepositante.itemrastreado;
      end;
    
      pk_produto.cadastrarProduto(r_prod, r_produtodepositante);
    end if;
  
    cadastrarEmbalagemImportacao;
  
    if (r_emb.idproduto <> r_prod.idproduto) then
      r_prod.idproduto := r_emb.idproduto;
    end if;
  
    cadastrarSetor(r_prod.idproduto, p_iddepositante);
  
    -- atualizando dados utilizados pela rotina de cadastro de item da nota
    p_produto.idproduto := r_prod.idproduto;
    p_produto.ncm       := r_prod.ncm;
    p_produto.cest      := r_prod.cest;
    p_produto.descricao := r_prod.descricao;
  
    p_embalagem.pesobruto     := r_emb.pesobruto;
    p_embalagem.pesoliquido   := r_emb.pesoliquido;
    p_embalagem.descrreduzido := r_emb.descrreduzido;
  end;

  function comporBarraGS1
  (
    p_idlote     in lote.idlote%type,
    p_tipo       number := 0,
    p_dataMatrix number := 0
  ) return varchar2 is
    r_lote                      lote%rowtype;
    v_barra                     lote.barra%type;
    v_quantidade                lote.qtdeentrada%type;
    v_msg                       t_message;
    v_groupSeparator            armazem.gs1128%type;
    v_tagBarra                  varchar(2) := '01';
    v_incluirCodigoProduto      number;
    v_incluirQuantidadeUnitaria number;
    v_codigoInterno             varchar(50);
  begin
    begin
      select lt.*
        into r_lote
        from lote lt, armazem a
       where lt.idlote = p_idlote
         and a.idarmazem = lt.idarmazem;
    
      select a.gs1128
        into v_groupSeparator
        from lote lt, armazem a
       where lt.idlote = p_idlote
         and a.idarmazem = lt.idarmazem;
    
    exception
      when no_data_found then
        v_msg := t_message('Nenhum lote encontrado para IDLOTE({0}).' ||
                           ' Não foi possível gerar a barra no padro GS1-128.');
        v_msg.addParam(p_idlote);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (r_lote.idproduto is null) then
      return null;
    end if;
    begin
    
      select pd.incluircodigoproduto, pd.incluirquantidadeunitaria,
             nvl(pd.codigointerno, prd.codigointerno)
        into v_incluirCodigoProduto, v_incluirQuantidadeUnitaria,
             v_codigoInterno
        from produtodepositante pd, produto prd
       where prd.idproduto = pd.idproduto
         and pd.identidade = r_lote.iddepositante
         and pd.idproduto = r_lote.idproduto;
    
    exception
      when no_data_found then
        v_incluirCodigoProduto      := 0;
        v_incluirQuantidadeUnitaria := 0;
    end;
    if (p_dataMatrix = 0) then
      v_barra := pk_produto.RetornarCodBarraMenorFator(r_lote.idproduto);
    elsif (p_dataMatrix = 1) then
      v_barra := r_lote.barra;
      if (nvl(r_lote.fatorconversao, 1) > 1) then
        v_tagBarra := '02';
      end if;
    end if;
  
    if v_barra is null then
      v_msg := t_message('Barra não encontrada para produto IDPRODUTO({0}).' ||
                         ' Não foi possível gerar a barra no padrão GS1-128.');
      v_msg.addParam(r_lote.idproduto);
      raise_application_error(-20000, v_msg.formatMessage);
    else
      if LENGTH(v_barra) = 13 then
        if (p_tipo = 0) then
          v_barra := v_tagBarra || '0' || SUBSTR(v_barra, 0, 12) || '';
        elsif (p_tipo = 1) then
          v_barra := ']C1' || v_tagBarra || '0' || SUBSTR(v_barra, 0, 13);
        elsif (p_tipo = 2) then
          v_barra := '(' || v_tagBarra || ')' || '0' ||
                     SUBSTR(v_barra, 0, 13);
        end if;
      else
        if LENGTH(v_barra) = 14 then
          if (p_tipo = 0) then
            v_barra := v_tagBarra || SUBSTR(v_barra, 0, 13) || '';
          elsif (p_tipo = 1) then
            v_barra := ']C1' || v_tagBarra || SUBSTR(v_barra, 0, 14);
          elsif (p_tipo = 2) then
            v_barra := '(' || v_tagBarra || ')' || SUBSTR(v_barra, 0, 14);
          end if;
        else
          return '';
        end if;
      end if;
    
      if r_lote.dtvenc is not null then
        if (p_tipo = 0) then
          v_barra := v_barra || '17' || to_char(r_lote.dtvenc, 'YYMMDD');
        elsif (p_tipo = 1) then
          v_barra := v_barra || '17' || to_char(r_lote.dtvenc, 'YYMMDD');
        elsif (p_tipo = 2) then
          v_barra := v_barra || '(17)' || to_char(r_lote.dtvenc, 'YYMMDD');
        end if;
      end if;
    
      if r_lote.descr is not null then
        if (p_tipo = 0) then
          v_barra := v_barra || '10' || r_lote.descr || '';
        elsif (p_tipo = 1) then
          v_barra := v_barra || '10' || r_lote.descr || v_groupSeparator;
        elsif (p_tipo = 2) then
          v_barra := v_barra || '(10)' || r_lote.descr;
        end if;
      end if;
    
      if v_incluirCodigoProduto = 1 then
        if (p_tipo = 0) then
          v_barra := v_barra || '240' || substr(v_codigoInterno, 1, 30) || '';
        elsif (p_tipo = 1) then
          v_barra := v_barra || '240' || substr(v_codigoInterno, 1, 30) ||
                     v_groupSeparator;
        elsif (p_tipo = 2) then
          v_barra := v_barra || '(240)' || substr(v_codigoInterno, 1, 30);
        end if;
      end if;
    
      if r_lote.qtdeentrada is not null
         and r_lote.fatorconversao is not null then
        if (p_dataMatrix = 0 or v_incluirQuantidadeUnitaria = 1) then
          select decode(r_lote.fatorconversao, 1, r_lote.qtdeentrada,
                         r_lote.fatorconversao * r_lote.qtdeentrada) /
                  (select count(1)
                     from gtt_selecao
                    where idselecionado = r_lote.idlote)
            into v_quantidade
            from dual;
        elsif (p_dataMatrix = 1) then
          if (nvl(r_lote.fatorconversao, 1) = 1) then
            v_quantidade := r_lote.qtdeentrada;
          else
            v_quantidade := 1;
          end if;
        end if;
      
        if (p_tipo = 0) then
          v_barra := v_barra || '30' || v_quantidade;
        elsif (p_tipo = 1) then
          v_barra := v_barra || '30' || v_quantidade;
        elsif (p_tipo = 2) then
          v_barra := v_barra || '(30)' || v_quantidade;
        end if;
      
      end if;
    end if;
  
    return v_barra;
  end comporBarraGS1;

  function permtirAlterarTipoProduto(p_idProduto in number) return boolean is
    v_bloquearAlterarProduto number;
    v_countMovimentacoes     number;
    v_msg                    t_message;
  begin
    begin
      select c.bloqalterarprodutomov
        into v_bloquearAlterarProduto
        from configuracao c;
    exception
      when no_data_found then
        v_msg := t_message('Configuração geral não encontrada');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_bloquearAlterarProduto = 0) then
      return true;
    end if;
  
    select count(1)
      into v_countMovimentacoes
      from int_envio_nf_armazenagemdet i
     where i.idproduto = p_idProduto;
  
    return v_countMovimentacoes = 0;
  end;

  /*
   * Carrega a embalagem a partir do produto e da descricao reduzida indepedente de ativo ou no.
  */
  function getBarraDescrReduzida
  (
    p_produto       in number,
    p_descrreduzida in varchar2
  ) return varchar2 is
    cursor c_barra
    (
      p_produto       in number,
      p_descrreduzida in varchar2
    ) is
      select barra
        from (select e.barra
                 from embalagem e
                where e.idproduto = p_produto
                  and (e.descrreduzido = p_descrreduzida or
                      upper(e.descrreduzido) = upper(p_descrreduzida))
                order by e.ativo desc, e.precadastro,
                         decode(e.descrreduzido, p_descrreduzida, 0, 1) asc)
       where rownum = 1;
  
    r_barra c_barra%rowtype;
  begin
    if c_barra%isopen then
      close c_barra;
    end if;
    open c_barra(p_produto, p_descrreduzida);
    fetch c_barra
      into r_barra;
  
    if c_barra%found then
      return r_barra.barra;
    else
      return null;
    end if;
  end getBarraDescrReduzida;

  function getBarraBipada
  (
    p_idproduto        in number,
    p_idVolumeRomaneio in number
  ) return varchar2 is
    v_barra embalagem.barra%type;
  
    C_STATUS_VOLUME_MONTADO        constant number := 1;
    C_STATUS_PRODCONFPACKING_ATIVO constant number := 1;
  begin
  
    begin
      select pp.barra
        into v_barra
        from confpacking c, produtoconfpacking pp
       where c.idvolumeromaneio = p_idVolumeRomaneio
         and c.status = C_STATUS_VOLUME_MONTADO
         and pp.idconfpacking = c.id
         and pp.idproduto = p_idproduto
         and pp.status = C_STATUS_PRODCONFPACKING_ATIVO
         and rownum = 1;
    exception
      when no_data_found then
        begin
          select cf.codbarra
            into v_barra
            from movimentacao mov, confescaninho cf
           where mov.idvolumeromaneio = p_idVolumeRomaneio
             and cf.idmovimentacao = mov.id
             and cf.idproduto = p_idproduto
             and rownum = 1;
        exception
          when no_data_found then
            v_barra := pk_produto.retornar_codbarra_nao_precad(p_idproduto,
                                                               1);
        end;
    end;
    return v_barra;
  end getBarraBipada;

  function validaFatorConversao(p_fatorConversao in varchar2) return number is
    v_fatorConversao number := 0;
    v_msg            t_message;
  begin
    begin
      select to_number(p_fatorConversao)
        into v_fatorConversao
        from dual;
    exception
      when others then
        v_msg := t_message('Caracter localizado na coluna conversão.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if ((v_fatorConversao >= 999999) or (v_fatorConversao <= 0)) then
      v_msg := t_message('Valor de conversão excedente.');
      raise_application_error(-20000, v_msg.formatMessage);
    else
      if (v_fatorConversao - trunc(v_fatorConversao)) > 0 then
        v_msg := t_message('Valor de conversão com casas decimais.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
    return v_fatorConversao;
  end validaFatorConversao;

  procedure verificarQtdeRegraDepositante
  (
    p_idonda             in number,
    p_codbarra           in varchar2,
    p_tipoRetorno        in number,
    p_qtdeRegra          in out number,
    p_iddepositante      in out number,
    p_identLoteIndustria in out number,
    p_loteIndustria      in out varchar2,
    p_dtVencimento       in out date,
    p_qtde               in out number
  ) is
    v_barraEncontrada varchar(3000);
  begin
    p_qtdeRegra := 0;
    if (p_iddepositante is null) then
      for c_dep in (select distinct nf.iddepositante
                      from notafiscal nf, nfromaneio nfr, romaneiopai rp
                     where rp.idromaneio = p_idonda
                       and rp.idromaneio = nfr.idromaneio
                       and nfr.idnotafiscal = nf.idnotafiscal)
      loop
        v_barraEncontrada := null;
        begin
          v_barraEncontrada := pk_produto.retCodSeparadoBarraProdLoteMap(p_codbarra,
                                                                         c_dep.iddepositante,
                                                                         p_tipoRetorno,
                                                                         p_identLoteIndustria,
                                                                         p_loteIndustria,
                                                                         p_dtVencimento,
                                                                         null,
                                                                         null,
                                                                         p_qtde);
        
        exception
          when others then
            -- Suprimir o erro caso um depositante envolvido na 
            -- operao no tenha regra de barra do depositante
            -- pois, caso o depositante no tenha regra de barra
            -- ocorre erro no momento de extrair informaes 
            -- da barra bipada pelo operador
            null;
        end;
        if (v_barraEncontrada is not null and
           ((p_tipoRetorno = 0 and p_identLoteIndustria = 0) or
           (p_tipoRetorno = 1 and p_identLoteIndustria = 1))) then
          p_iddepositante := c_dep.iddepositante;
          p_qtdeRegra     := p_qtdeRegra + 1;
        end if;
      end loop;
    
    else
    
      select count(1)
        into p_qtdeRegra
        from regrabarradepositante r
       where r.iddepositante = p_iddepositante
         and r.tamanho = length(p_codbarra);
    
    end if;
  end verificarQtdeRegraDepositante;

  function getMaiorFatorProduto(p_idProduto in number) return number is
    v_fatorconversao number;
  begin
    --Tenta localizar o maior fator ativo e no precadastro
    select max(e.fatorconversao)
      into v_fatorconversao
      from embalagem e
     where e.idproduto = p_idproduto
       and e.ativo = 'S'
       and e.precadastro = 'N';
  
    if v_fatorconversao is null then
      --Tenta localizar o maior fator ativo
      select max(e.fatorconversao)
        into v_fatorconversao
        from embalagem e
       where e.idproduto = p_idproduto
         and e.ativo = 'S';
    end if;
  
    return nvl(v_fatorconversao, 1);
  end;

  procedure validarMesAno
  (
    p_idproduto     in number,
    p_iddepositante in number,
    p_validaMesAno  in number
  ) is
    v_msg t_message;
  
    procedure inventario is
      v_inventarios varchar2(1000);
      C_INVENTARIO_FINALIZADO constant char := 'F';
      C_INVENTARIO_CANCELADO  constant char := 'X';
    begin
      select stragg(inv.idinventario) idinventario
        into v_inventarios
        from inventario inv, depositanteinventario dv
       where dv.identidade = p_iddepositante
         and inv.situacao not in
             (C_INVENTARIO_FINALIZADO, C_INVENTARIO_CANCELADO)
         and dv.idinventario = inv.idinventario
         and (exists (select 1
                        from invdet det
                       where det.idproduto = p_idproduto
                         and det.idinventario = inv.idinventario
                         and det.ignorada = 'N') or exists
              (select 1
                 from produtoinventario pv
                where pv.idproduto = p_idproduto
                  and pv.idinventario = inv.idinventario));
    
      if (v_inventarios is not null) then
        v_msg := t_message('Não é permitido alterar o campo "Validar Apenas Mês e Ano do Vencimento", pois, o produto com id {0} encontra-se no(s) inventario(s) {1}.');
        v_msg.addParam(p_idproduto);
        v_msg.addParam(v_inventarios);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end inventario;
  
    procedure ordemRecebimento is
      v_ors varchar2(1000);
      C_OR_ALOCADA constant number := 2;
    begin
      select stragg(l.idlotenf)
        into v_ors
        from (select l.idlotenf
                 from lotenf l, tiporecebimento tr
                where l.identidade = p_iddepositante
                  and case
                        when (tr.geraralocacaoporpalete = 1) then
                         decode(pk_alocacao.isLoteMapaPendenteGeracao(l.idlotenf),
                                1, 0, decode(l.faltamalocar, 0, 2, 1))
                        else
                         decode(l.faltamalocar, -1, 0, 0, 2, 1)
                      end <> C_OR_ALOCADA
                  and tr.idtiporecebimento = l.idtiporecebimento
                  and exists (select 1
                         from conferenciaentradadet cd
                        where cd.idlotenf = l.idlotenf
                          and cd.ignorada = 'N'
                          and cd.idproduto = p_idproduto)
                group by l.idlotenf) l;
    
      if (v_ors is not null) then
        v_msg := t_message('Não é permitido alterar o campo "Validar Apenas Mês e Ano do Vencimento", pois, o produto com id {0} encontra-se na(s) or(s): {1}.');
        v_msg.addParam(p_idproduto);
        v_msg.addParam(v_ors);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end ordemRecebimento;
  
    function alteradoParametro return boolean is
      v_validar number;
    begin
      begin
        select pd.validarmesano
          into v_validar
          from produtodepositante pd
         where pd.idproduto = p_idproduto
           and pd.identidade = p_iddepositante;
      exception
        when no_data_found then
          v_validar := 0;
      end;
    
      if (v_validar <> p_validaMesAno) then
        return true;
      end if;
    
      return false;
    
    end alteradoParametro;
  
  begin
    if (not alteradoParametro) then
      return;
    end if;
  
    inventario;
    ordemRecebimento;
  end validarMesAno;

  procedure atualizarMesAnoVencimento
  (
    p_idproduto     in number,
    p_iddepositante in number,
    p_validaMesAno  in number
  ) is
  
    C_MARCADO    constant number := 1;
    C_DESMARCADO constant number := 0;
  
    procedure atualizarDataVencimento is
    begin
      update lote l
         set l.dtvencoriginal = l.dtvenc,
             l.dtvenc         = last_day(trunc(l.dtvenc))
       where l.idproduto = p_idproduto
         and l.iddepositante = p_iddepositante
         and l.dtvenc is not null;
    end atualizarDataVencimento;
  
    procedure retornarVencimentoOriginal is
    begin
      update lote l
         set l.dtvenc         = l.dtvencoriginal,
             l.dtvencoriginal = null
       where l.idproduto = p_idproduto
         and l.iddepositante = p_iddepositante
         and l.dtvenc is not null;
    end retornarVencimentoOriginal;
  
  begin
    if (p_validaMesAno = C_MARCADO) then
      atualizarDataVencimento;
      return;
    end if;
  
    if (p_validaMesano = C_DESMARCADO) then
      retornarVencimentoOriginal;
      return;
    end if;
  end atualizarMesAnoVencimento;

  function retFatorCodBarraNotaFiscal
  (
    p_idlotenf  in number,
    p_idproduto in number
  ) return number is
    v_fatorconversao number;
  begin
    select e.fatorconversao
      into v_fatorconversao
      from notafiscal nf, nfdet nd, embalagem e
     where nf.idlotenf = p_idlotenf
       and nd.nf = nf.idnotafiscal
       and nd.idproduto = p_idproduto
       and e.idproduto = nd.idproduto
       and e.barra = nd.barra
     group by e.fatorconversao;
  
    return v_fatorconversao;
  
  exception
    when no_data_found then
      return 1;
    when too_many_rows then
      return 1;
  end retFatorCodBarraNotaFiscal;

  procedure vincularProdutoDestinatario
  (
    p_idproduto  in produto.idproduto%type,
    p_identidade in entidade.identidade%type
  ) is
  begin
    insert into produtodestinatario
      (idproduto, identidade)
    values
      (p_idproduto, p_identidade);
  end;

  procedure removerProdutoDestinatario
  (
    p_idproduto  in produto.idproduto%type,
    p_identidade in entidade.identidade%type
  ) is
  begin
    delete from produtodestinatario
     where idproduto = p_idproduto
       and identidade = p_identidade;
  end;

  procedure excluirEmbalagem
  (
    p_idproduto in number,
    p_barra     in varchar2,
    p_idUsuario in number
  ) is
  begin
    delete from embalagem e
     where e.idproduto = p_idproduto
       and e.barra = p_barra;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'EXCLUIDA BARRA ' || p_barra || ' DO IDPRODUTO ' ||
                          p_idproduto, p_idproduto, 'EM');
  end excluirEmbalagem;

  procedure existeEstoqEstojKitRastreado
  (
    p_idproduto     in number,
    p_iddepositante in number,
    p_msg           in t_message
  ) is
  begin
    for c_kit_rast_estojo in (select distinct v.idlote
                                from vt_estoquelocalporlote v
                               where (v.estoqueun <> 0 or v.pendenciaun <> 0 or
                                     v.adicionarun <> 0)
                                 and v.idproduto = p_idproduto
                                 and exists
                               (select 1
                                        from origemlote ol, notafiscal nf,
                                             composicaolote cp,
                                             ordemservico os
                                       where ol.idnotafiscal =
                                             nf.idnotafiscal
                                         and ol.idlote = cp.idlotenovo
                                         and nf.idlotenf = os.idlotenf
                                         and os.tiposervico in ('E', 'I')
                                         and ol.idlote = v.idlote
                                         and p_iddepositante = (CASE
                                               when (p_iddepositante is not null) then
                                                (os.identidade)
                                               else
                                                (p_iddepositante)
                                             END)))
    loop
      raise_application_error(-20000, p_msg.formatMessage);
    end loop;
  end existeEstoqEstojKitRastreado;

  procedure verificarAtivKitExpExplodida
  (
    p_idproduto     in number,
    p_ativaDesativa in number
  ) is
    v_kit boolean;
    v_msg t_message;
  begin
  
    v_kit := ehKit(p_idproduto);
  
    if v_kit then
      v_msg := t_message('NÃO É PERMITIDO ALTERAR O PARÂMETRO KIT DE EXPEDIÇÃO ' ||
                         'EXPLODIDA PARA KIT RASTREADO/ESTOJO QUE CONTÉM ESTOQUE.');
      existeEstoqEstojKitRastreado(p_idproduto, null, v_msg);
    
      for c_componentes in (select kp.idproduto,
                                   decode(p.kitexpexplodida, 'S', 1, 0) kitexpexplodida
                              from kitproduto kp, produto p
                             where kp.idprodutokit = p_idproduto
                               and kp.idproduto = p.idproduto)
      
      loop
        if c_componentes.kitexpexplodida <> p_ativaDesativa then
          v_msg := t_message('NÃO É PERMITIDO ALTERAR O PARÂMETRO KIT DE EXPEDIÇÃO ' ||
                             'EXPLODIDA PARA PRODUTO KIT RASTREADO/ESTOJO, ' ||
                             'POIS O COMPONENTE ID {0} ' ||
                             'ESTÁ COM O KIT DE EXPEDIÇÃO EXPLODIDA {1} ' ||
                             'O PARÂMETRO DE TODOS OS COMPONENTES E TENTE NOVAMENTE.');
        
          v_msg.addParam(c_componentes.idproduto);
        
          if c_componentes.kitexpexplodida = 1 then
            v_msg.addParam('ATIVADO. DESATIVE');
          else
            v_msg.addParam('DESATIVADO. ATIVE');
          end if;
        
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    
    end if;
  
  end verificarAtivKitExpExplodida;

  procedure verificarDesatProdDepLoteInd
  (
    p_idproduto     in number,
    p_iddepositante in number
  ) is
    v_msg t_message;
  begin
  
    v_msg := t_message('NÃO É PERMITIDO DESMARCAR O PARÂMETRO <b>COLETAR LOTE ' ||
                       'INDÚSTRIA</b> PARA KIT RASTREADO/ESTOJO QUE CONTÉM ESTOQUE.');
    existeEstoqEstojKitRastreado(p_idproduto, p_iddepositante, v_msg);
  
  end verificarDesatProdDepLoteInd;

  function isKitOuEstojo(p_idproduto in number) return boolean is
    v_total number;
  begin
    select count(*)
      into v_total
      from ordemkit
     where idprodutokit = p_idproduto;
  
    return v_total > 0;
  end;

  procedure verificarDesativAgrupadorCombo(p_idproduto in number) is
    v_msg           t_message;
    v_existeEstoque number;
  begin
  
    select count(1)
      into v_existeEstoque
      from vt_estoquelocalporlote v
     where (v.estoqueun <> 0 or v.pendenciaun <> 0 or v.adicionarun <> 0)
       and v.idproduto = p_idproduto;
  
    if v_existeEstoque >= 1 then
      v_msg := t_message('NÃO É PERMITIDO DESMARCAR O PARÂMETRO <b>AGRUPADOR COMBO ' ||
                         'ESTOJAMENTO</b> QUANDO O PRODUTO CONTÉM ESTOQUE.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end verificarDesativAgrupadorCombo;

  function isTrocaDeSetorPermitido
  (
    p_idProduto     in produto.idproduto%type,
    p_idTipoProduto in tipoproduto.idtipo%type
  ) return number is
  
    v_qtdSetorEspecial       number := 0;
    v_qtdSetorNaoConfigurado number := 0;
  begin
  
    select count(1)
      into v_qtdSetorEspecial
      from setorproduto sp, setor s
     where sp.idproduto = p_idProduto
       and sp.idsetor = s.idsetor
       and s.produtosespeciais = 1;
  
    if (v_qtdSetorEspecial = 0) then
      return 1;
    else
      select count(1)
        into v_qtdSetorNaoConfigurado
        from setorproduto sp, setor s
       where sp.idsetor = s.idsetor
         and sp.idproduto = p_idProduto
         and s.produtosespeciais = 1
         and not exists
       (select 1
                from setortipoproduto stp
               where stp.idsetor = s.idsetor
                 and stp.idtipoproduto = p_idTipoProduto);
      if (v_qtdSetorNaoConfigurado > 0) then
        return 0;
      else
        return 1;
      end if;
    end if;
  
  end isTrocaDeSetorPermitido;

  /*
   * Pesquisa produto por código interno
  */
  function pesquisaProdutoPorCodInterno(p_codigoInterno in produto.codigointerno%type)
    return produto%rowtype is
  
    cursor c_produto(p_codigoInterno in varchar2) is
      select p.*
        from produto p
       where trim(p.codigointerno) = trim(p_codigoInterno);
  
    r_produto c_produto%rowtype;
  begin
    if c_produto%isopen then
      close c_produto;
    end if;
    open c_produto(p_codigoInterno);
    fetch c_produto
      into r_produto;
    if c_produto%found then
      close c_produto;
      return r_produto;
    else
      close c_produto;
      return null;
    end if;
  end;

end pk_produto;
/

