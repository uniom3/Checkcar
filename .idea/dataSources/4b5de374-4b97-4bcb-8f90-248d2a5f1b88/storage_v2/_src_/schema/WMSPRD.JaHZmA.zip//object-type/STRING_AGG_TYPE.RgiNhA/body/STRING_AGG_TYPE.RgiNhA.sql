create TYPE BODY string_agg_type IS

  STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT string_agg_type)
    RETURN NUMBER IS
  BEGIN
    sctx := string_agg_type(null);
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateIterate
  (
    self  IN OUT string_agg_type,
    value IN varchar2
  ) RETURN NUMBER IS
  BEGIN
    self.total := substr(self.total || ',' || value, 1, 3999);
    RETURN ODCIConst.Success;
  END;
  MEMBER FUNCTION ODCIAggregateTerminate
  (
    self        IN string_agg_type,
    returnValue OUT varchar2,
    flags       IN number
  ) RETURN NUMBER IS
  BEGIN
    returnValue := substr(ltrim(self.total, ','), 1, 3999);
    return ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateMerge
  (
    self IN OUT string_agg_type,
    ctx2 IN string_agg_type
  ) RETURN NUMBER IS
  BEGIN
    self.total := substr(self.total || ctx2.total, 1, 3999);
    return ODCIConst.Success;
  END;

end;
/

