create PACKAGE BODY PK_ORDEMTRANSFERENCIA IS

  function retornaUsuarioConfigGeral return number is
    v_idusuario usuario.idusuario%type;
  begin
  
    begin
      select c.idusuariointegracao
        into v_idusuario
        from configuracao c
       where c.ativo = 'S'
         and c.idusuariointegracao is not null;
    exception
      when no_data_found then
        v_idusuario := null;
    end;
  
    return v_idusuario;
  end retornaUsuarioConfigGeral;

  procedure vinculaTDNnfdetAuto
  (
    p_idnfdet       in tdnitemnfdet.idnfdet%type,
    p_idordemTransf in ordemtransferenciaitem.idordemtransferencia%type,
    p_qtde          in nfdet.qtde%type,
    p_idusuario     in tdnitemnfdet.idusuariocriacao%type
  ) is
    type t_item is record(
      idprenf                  number,
      numeronf                 notafiscal.codigointerno%type,
      codproduto               produto.codigointerno%type,
      idproduto                number,
      numeroordemtransferencia ordemtransferencia.numeroordemtransferencia%type,
      fatorconversao           number);
  
    r_item t_item;
  
    v_idusuario tdnitemnfdet.idusuariocriacao%type;
    e_interromperfluxo exception;
  
    procedure carregarDados is
    begin
    
      select nf.idprenf, nf.codigointerno, p.codigointerno, p.idproduto,
             ot.numeroordemtransferencia, e.fatorconversao
        into r_item.idprenf, r_item.numeronf, r_item.codproduto,
             r_item.idproduto, r_item.numeroordemtransferencia,
             r_item.fatorconversao
        from nfdet nd, notafiscal nf, produto p, ordemtransferencia ot,
             embalagem e
       where nd.idnfdet = p_idnfdet
         and nf.idnotafiscal = nd.nf
         and p.idproduto = nd.idproduto
         and ot.idordemtransferencia = p_idordemTransf
         and e.barra = nd.barra
         and e.idproduto = nd.idproduto;
    
      if (p_idusuario is null) then
        v_idusuario := retornaUsuarioConfigGeral;
      else
        v_idusuario := p_idusuario;
      end if;
    end carregarDados;
  
    procedure validacoes is
      v_saldoun number;
    begin
      if (v_idusuario is null) then
        pk_utilities.geraLogInt(r_item.idprenf, null,
                                'Vínculo automático de Nota Fiscal com Ordem de Transferência.',
                                'E', null,
                                'Usuário de integração padrão não preenchido nas configurações gerais do sistema. Número Ordem de Transferência: ' ||
                                 r_item.numeroordemtransferencia, null, null,
                                null, r_item.numeronf, r_item.codproduto,
                                null);
        raise e_interromperfluxo;
      end if;
    
      select sum(oi.qtdeinformada - oi.qtderecebida)
        into v_saldoun
        from ordemtransferenciaitem oi
       where oi.idordemtransferencia = p_idordemTransf
         and oi.idproduto = r_item.idproduto;
    
      if ((p_qtde * r_item.fatorconversao) > v_saldoun) then
        pk_utilities.geraLogInt(r_item.idprenf, null,
                                'Vínculo automático de Nota Fiscal com Ordem de Transferência.',
                                'E', null,
                                'Quantidade da ordem de transferência não atende a quantidade do item na nota fiscal. Número Ordem de Transferência: ' ||
                                 r_item.numeroordemtransferencia, null, null,
                                null, r_item.numeronf, r_item.codproduto,
                                null);
      
        raise e_interromperfluxo;
      end if;
    end validacoes;
  
    procedure associarItem is
      v_qtdeun    number;
      v_qtdeutzun number;
    begin
      v_qtdeun := p_qtde * r_item.fatorconversao;
      for r_ordemitem in (select o.idordemtransferenciaitem,
                                 o.qtdeinformada - o.qtderecebida disponivel,
                                 o.itemlocation
                            from ordemtransferenciaitem o, nfdet nd
                           where o.idordemtransferencia = p_idordemTransf
                             and o.idproduto = nd.idproduto
                             and nd.idnfdet = p_idnfdet
                             and o.qtdeinformada - o.qtderecebida > 0)
      loop
        if (v_qtdeun > r_ordemitem.disponivel) then
          v_qtdeutzun := r_ordemitem.disponivel;
        else
          v_qtdeutzun := v_qtdeun;
        end if;
      
        v_qtdeun := v_qtdeun - v_qtdeutzun;
      
        insert into tdnitemnfdet
          (idtdnitemnfdet, idordemtransferenciaitem, idnfdet, qtde,
           idusuariocriacao, datacriacao, itemlocation)
        values
          (seq_tdnitemnfdet.nextval, r_ordemitem.idordemtransferenciaitem,
           p_idnfdet, v_qtdeutzun, v_idusuario, sysdate,
           r_ordemitem.itemlocation);
      
        update ordemtransferenciaitem s
           set s.qtderecebida = qtderecebida + v_qtdeutzun
         where s.idordemtransferenciaitem =
               r_ordemitem.idordemtransferenciaitem;
      
        exit when v_qtdeun = 0;
      end loop;
    end associarItem;
  
  begin
    carregarDados;
  
    begin
      validacoes;
    exception
      when e_interromperfluxo then
        return;
    end;
  
    associarItem;
  
    pk_utilities.geraLogInt(r_item.idprenf, null,
                            'Vínculo automático de Nota Fiscal com Ordem de Transferência',
                            'S', p_idusuario,
                            'Vínculo do item da nota fiscal com o item da ordem de transferência realizado com sucesso. Número Ordem de Transferência: ' ||
                             r_item.numeroordemtransferencia, null, null,
                            null, r_item.numeronf, r_item.codproduto, null);
  
  end vinculaTDNnfdetAuto;

  procedure removerTDNNFDet
  (
    p_idordemTransferenciaitem in tdnitemnfdet.idordemtransferenciaitem%type,
    p_idnfdet                  in tdnitemnfdet.idnfdet%type
  ) is
    v_msg    t_message;
    v_status ordemtransferencia.status%type;
  
    procedure validarNFdetOT is
      v_idLoteNF     notafiscal.idlotenf%type;
      v_idNotaFiscal notafiscal.idnotafiscal%type;
    begin
      select nvl(nf.idlotenf, 0), nf.idnotafiscal
        into v_idLoteNF, v_idNotaFiscal
        from notafiscal nf, nfdet nd
       where nf.idnotafiscal = nd.nf
         and nd.idnfdet = p_idnfdet;
    
      if (v_idLoteNF > 0) then
        v_msg := t_message('Não foi possível desvincular a Nota Fiscal [ idNotaFiscal: {0} ]. Nota Fiscal está vinculada em uma Ordem de recebimento');
        v_msg.addParam(v_idNotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarNFdetOT;
  
  begin
  
    select o.status
      into v_status
      from ordemtransferencia o, ordemtransferenciaitem oi
     where o.idordemtransferencia = oi.idordemtransferencia
       and oi.idordemtransferenciaitem = p_idordemTransferenciaitem;
  
    if (v_status <> C_OT_PENDENTE) then
      v_msg := t_message('Não foi possível desvincular a Nota Fiscal em Ordem de Transferência id {0} com status diferente de \"Pendente\".');
      v_msg.addParam(p_idordemTransferenciaitem);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarNFdetOT;
  
    for c_nfDet in (select *
                      from tdnitemnfdet td
                     where td.idnfdet = p_idnfdet
                       and td.idordemtransferenciaitem =
                           p_idordemTransferenciaitem)
    loop
      update ordemtransferenciaitem
         set qtderecebida = nvl((qtderecebida - c_nfDet.Qtde), 0)
       where idordemtransferenciaitem = p_idordemTransferenciaitem
         and itemlocation = c_nfDet.Itemlocation;
    end loop;
  
    delete from tdnitemnfdet t
     where t.idordemtransferenciaitem = p_idordemTransferenciaitem
       and t.idnfdet = p_idnfdet;
  
  end removerTDNNFDet;

  procedure cancelarOrdemTransferencia(p_idordemTransferencia in ordemtransferencia.idordemtransferencia%type) is
  
  begin
  
    validarOT(p_idOrdemTransferencia, C_CANCELAR);
  
    for c_itemOT in (select oi.idordemtransferenciaitem, td.idnfdet
                       from ordemtransferenciaitem oi, tdnitemnfdet td
                      where oi.idordemtransferenciaitem =
                            td.idordemtransferenciaitem
                        and oi.idordemtransferencia = p_idordemtransferencia)
    loop
      removerTDNNFDet(c_itemOT.Idordemtransferenciaitem, c_itemOT.Idnfdet);
    end loop;
  
    update ordemtransferencia o
       set o.status = 2
     where o.idordemtransferencia = p_idordemTransferencia;
  
  end cancelarOrdemTransferencia;

  procedure atualizarSaldoAlocado
  (
    p_idLotenf  in number,
    p_idUsuario in number
  ) is
    C_ORDEM_FINALIZADA constant number := 1;
    v_qtdeAlocada number;
    v_qtdeBaixar  number;
  
    v_ordemtransferenciaitem number;
  
  begin
    for c_nf in (select nf.idnotafiscal
                   from notafiscal nf, depositante d
                  where nf.idlotenf = p_idlotenf
                    and d.identidade = nf.iddepositante
                    and d.utilizaordemtransferencia = 1)
    loop
      for c_nd in (select od.idnfdet, sum(od.qtde) qtde, s.codigointegracao
                     from orlote ol, origemlotedetalhado od, mapaalocacao m,
                          local lc, setor s
                    where ol.idlotenf = p_idlotenf
                      and od.idnotafiscal = c_nf.idnotafiscal
                      and od.idlote = ol.idlote
                      and m.idlote = od.idlote
                      and lc.idlocal = m.idlocal
                      and lc.idarmazem = m.idarmazem
                      and s.idsetor = lc.idsetor
                    group by od.idnfdet, s.codigointegracao
                    order by od.idnfdet, s.codigointegracao)
      loop
        v_qtdeAlocada := c_nd.qtde;
      
        for c_itemOT in (select i.idtdnitemnfdet, i.idordemtransferenciaitem,
                                i.qtde qtdeAssociada,
                                oti.idordemtransferencia,
                                decode(c_nd.codigointegracao, i.itemlocation,
                                        i.itemlocation, null) itemlocation,
                                oti.idproduto
                           from tdnitemnfdet i, ordemtransferenciaitem oti
                          where i.idnfdet = c_nd.idnfdet
                            and oti.idordemtransferenciaitem =
                                i.idordemtransferenciaitem
                            and i.itemlocation = oti.itemlocation
                          order by itemlocation)
        loop
          if (c_itemOT.itemlocation is not null) then
            if (c_itemOT.Qtdeassociada > v_qtdeAlocada) then
              v_qtdeBaixar := v_qtdeAlocada;
            else
              v_qtdeBaixar := c_itemOT.Qtdeassociada;
            end if;
          
            v_qtdeAlocada := v_qtdeAlocada - v_qtdeBaixar;
          
            update tdnitemnfdet i
               set i.qtdealocada = nvl(v_qtdeBaixar, 0),
                   i.qtde        = nvl(v_qtdeBaixar, 0),
                   i.idlotenf    = p_idlotenf
             where i.idtdnitemnfdet = c_itemOT.Idtdnitemnfdet
               and i.itemlocation = c_itemOT.Itemlocation;
          
            update ordemtransferenciaitem iot
               set iot.qtderecebida = nvl(iot.qtderecebida, 0) -
                                      (nvl(c_itemOT.qtdeAssociada, 0) -
                                       nvl(v_qtdeBaixar, 0))
             where iot.idordemtransferenciaitem =
                   c_itemOT.Idordemtransferenciaitem;
          
            pk_utilities.GeraLog(p_idUsuario,
                                 'Item da Ordem de Transferência alterado: ' ||
                                  ' idusuarioalteracao = ' || p_idUsuario ||
                                  ' dataalteracao = ' || sysdate ||
                                  ' qtdealocada  = ' || v_qtdeBaixar ||
                                  ' idlotenf = ' || p_idLotenf ||
                                  '. Ordemtransferenciaitem: idordemtransferenciaitem = ' ||
                                  c_itemOT.idordemtransferenciaitem ||
                                  ' qtderecebida = ' || v_qtdeAlocada,
                                 c_itemOT.idordemtransferencia, 'OT');
          
            exit when v_qtdeAlocada = 0;
          
          else
            insert into ordemtransferenciaitem
              (idordemtransferenciaitem, idordemtransferencia, idproduto,
               qtdeinformada, qtderecebida, itemlocation)
            values
              (seq_ordemtransferenciaitem.nextval,
               c_itemOT.Idordemtransferencia, c_itemOT.Idproduto, 0,
               c_nd.qtde, c_nd.codigointegracao)
            returning idordemtransferenciaitem into v_ordemtransferenciaitem;
          
            insert into tdnitemnfdet
              (idtdnitemnfdet, idordemtransferenciaitem, idnfdet, qtde,
               idusuariocriacao, datacriacao, qtdealocada, idlotenf,
               itemlocation)
            values
              (seq_tdnitemnfdet.nextval, v_ordemtransferenciaitem,
               c_nd.idnfdet, c_nd.qtde, p_idUsuario, sysdate, c_nd.qtde,
               p_idlotenf, c_nd.codigointegracao);
          
            pk_utilities.GeraLog(p_idUsuario,
                                 'Item da Ordem de Transferência alterado: ' ||
                                  ' idusuarioalteracao = ' || p_idUsuario ||
                                  ' dataalteracao = ' || sysdate ||
                                  ' qtdealocada  = ' || c_nd.qtde ||
                                  ' idlotenf = ' || p_idLotenf ||
                                  '. Ordemtransferenciaitem: idordemtransferenciaitem = ' ||
                                  v_ordemtransferenciaitem ||
                                  ' qtderecebida = ' || c_nd.qtde,
                                 c_itemOT.idordemtransferencia, 'OT');
          
          end if;
        
        end loop;
      
      end loop;
    
    end loop;
  
    for c_nf in (select nf.idnotafiscal
                   from notafiscal nf, depositante d
                  where nf.idlotenf = p_idlotenf
                    and d.identidade = nf.iddepositante
                    and d.utilizaordemtransferencia = 1)
    loop
      for r_itemnaorecebido in (select nd.idnfdet
                                  from nfdet nd
                                 where nd.nf = c_nf.idnotafiscal
                                   and not exists
                                 (select 1
                                          from origemlotedetalhado ol
                                         where ol.idnfdet = nd.idnfdet))
      loop
        for r_itemordem in (select i.idtdnitemnfdet,
                                   i.idordemtransferenciaitem, i.qtde
                              from tdnitemnfdet i
                             where i.idnfdet = r_itemnaorecebido.idnfdet
                               and nvl(i.qtdealocada, 0) = 0)
        loop
          update ordemtransferenciaitem oti
             set oti.qtderecebida = case
                                      when (nvl(oti.qtderecebida, 0) = 0) then
                                       0
                                      else
                                       oti.qtderecebida - r_itemordem.qtde
                                    end
           where oti.idordemtransferenciaitem =
                 r_itemordem.idordemtransferenciaitem;
        
          delete tdnitemnfdet i
           where i.idtdnitemnfdet = r_itemordem.idtdnitemnfdet;
        end loop;
      end loop;
    
      for r_itemnaorecebido in (select oti.idordemtransferenciaitem,
                                       i.idnfdet, oti.itemlocation,
                                       i.idtdnitemnfdet
                                  from tdnitemnfdet i,
                                       ordemtransferenciaitem oti, nfdet nd
                                 where 1 = 1
                                   and nd.idnfdet = i.idnfdet
                                   and nd.nf = c_nf.idnotafiscal
                                   and oti.idordemtransferenciaitem =
                                       i.idordemtransferenciaitem
                                   and i.itemlocation = oti.itemlocation
                                   and not exists
                                 (select 1
                                          from orlote ol,
                                               origemlotedetalhado od,
                                               mapaalocacao m, local lc,
                                               setor s
                                         where ol.idlotenf = p_idlotenf
                                           and od.idnotafiscal =
                                               c_nf.idnotafiscal
                                           and od.idlote = ol.idlote
                                           and m.idlote = od.idlote
                                           and lc.idlocal = m.idlocal
                                           and lc.idarmazem = m.idarmazem
                                           and s.idsetor = lc.idsetor
                                           and od.idnfdet = i.idnfdet
                                           and s.codigointegracao =
                                               i.itemlocation))
      loop
        update ordemtransferenciaitem oti
           set oti.qtderecebida = 0
         where oti.idordemtransferenciaitem =
               r_itemnaorecebido.idordemtransferenciaitem
           and oti.itemlocation = r_itemnaorecebido.itemlocation;
      
        update tdnitemnfdet i
           set i.qtde = 0
         where i.idtdnitemnfdet = r_itemnaorecebido.idtdnitemnfdet
           and i.itemlocation = r_itemnaorecebido.itemlocation
           and i.idordemtransferenciaitem =
               r_itemnaorecebido.idordemtransferenciaitem;
      end loop;
    
    end loop;
  
    for c_ordemTranferencia in (select distinct ioc.idordemtransferencia
                                  from tdnitemnfdet ii,
                                       ordemtransferenciaitem ioc
                                 where ioc.idordemtransferenciaitem =
                                       ii.idordemtransferenciaitem
                                   and ii.idlotenf = p_idLoteNf
                                   and not exists
                                 (select 1
                                          from ordemtransferenciaitem i,
                                               tdnitemnfdet idet
                                         where i.idordemtransferencia =
                                               ioc.idordemtransferencia
                                           and idet.idordemtransferenciaitem(+) =
                                               i.idordemtransferenciaitem
                                           and (i.qtdeinformada <>
                                               i.qtderecebida or
                                               nvl(idet.qtdealocada, 0) <>
                                               nvl(idet.qtde, 0))))
    loop
      update ordemtransferencia ot
         set ot.status = C_ORDEM_FINALIZADA
       where ot.idordemtransferencia =
             c_ordemTranferencia.Idordemtransferencia;
    end loop;
  
  end atualizarSaldoAlocado;

  procedure excluirOrdemTransferencia
  (
    p_idordemtransferencia in ordemtransferencia.idordemtransferencia%type,
    p_idusuario            in number
  ) is
  begin
  
    validarOT(p_idOrdemTransferencia, C_EXCLUIR);
  
    for c_itemOT in (select oi.idordemtransferenciaitem, td.idnfdet
                       from ordemtransferenciaitem oi, tdnitemnfdet td
                      where oi.idordemtransferenciaitem =
                            td.idordemtransferenciaitem
                        and oi.idordemtransferencia = p_idordemtransferencia)
    loop
      removerTDNNFDet(c_itemOT.Idordemtransferenciaitem, c_itemOT.Idnfdet);
    end loop;
  
    delete from ordemtransferenciaitem oi
     where oi.idordemtransferencia = p_idordemtransferencia;
  
    delete from ordemtransferencia ot
     where ot.idordemtransferencia = p_idordemtransferencia;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Ordem de transferência excluída com sucesso.',
                         p_idordemtransferencia, 'OT');
  end excluirOrdemTransferencia;

  procedure finalizarOrdemTransferencia
  (
    p_idOrdemTransferencia in number,
    p_idUsuario            in number,
    p_automatico           in number := 0
  ) is
    v_msg t_message;
  
    C_ORDEM_FINALIZADA constant number := 1;
  
    procedure validarSaldoOT is
      v_possuiAlgumItemVinculado number;
      v_possuiAlgumItemAlocado   number;
    begin
      select count(1)
        into v_possuiAlgumItemVinculado
        from dual
       where exists (select 1
                from ordemtransferenciaitem i, tdnitemnfdet idet
               where i.idordemtransferencia = p_idOrdemTransferencia
                 and idet.idordemtransferenciaitem =
                     i.idordemtransferenciaitem);
    
      if (v_possuiAlgumItemVinculado = 0 and p_automatico = 0) then
        v_msg := t_message('Operação não permitida. Nenhum item da Ordem de Transferência (ID: {0}) esta associado a algum item de nota fiscal.');
        v_msg.addParam(p_idOrdemTransferencia);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_possuiAlgumItemAlocado
        from dual
       where exists (select 1
                from ordemtransferenciaitem i, tdnitemnfdet idet
               where i.idordemtransferencia = p_idOrdemTransferencia
                 and idet.idordemtransferenciaitem =
                     i.idordemtransferenciaitem
                 and nvl(idet.qtdealocada, 0) > 0);
    
      if (v_possuiAlgumItemAlocado = 0 and p_automatico = 0) then
        v_msg := t_message('Operação não permitida. Nenhum item da Ordem de Transferência (ID: {0}) foi alocado.');
        v_msg.addParam(p_idOrdemTransferencia);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarSaldoOT;
  
  begin
  
    validarOT(p_idOrdemTransferencia, C_FINALIZAR);
    validarSaldoOT;
  
    update ordemtransferencia ot
       set ot.status = C_ORDEM_FINALIZADA
     where ot.idordemtransferencia = p_idOrdemTransferencia;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Ordem de transferenia id: ' ||
                          p_idOrdemTransferencia ||
                          ' finalizada pelo usuario id: ' || p_idUsuario,
                         p_idOrdemTransferencia, 'OT');
  
  end finalizarOrdemTransferencia;

  procedure estornarCancOrdemTransferencia
  (
    p_idOrdemTransferencia in ordemtransferencia.idordemtransferencia%type,
    p_idUsuario            in number
  ) is
  begin
  
    validarOT(p_idOrdemTransferencia, C_ESTORNARCANCELAMENTO);
  
    update ordemtransferenciaitem oi
       set oi.qtderecebida = 0
     where oi.idordemtransferencia = p_idOrdemTransferencia;
  
    update ordemtransferencia ot
       set ot.status = C_OT_PENDENTE
     where ot.idordemtransferencia = p_idOrdemTransferencia;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Ordem de transferência id: ' ||
                          p_idOrdemTransferencia ||
                          ' Cancelamento Estornado pelo usuario id: ' ||
                          p_idUsuario, p_idOrdemTransferencia, 'OT');
  
  end estornarCancOrdemTransferencia;

  /* validar o Status da Ordem de Transferência para Tipo de Ação */
  procedure validarOT
  (
    p_idOrdemTransferencia in ordemtransferencia.idordemtransferencia%type,
    p_tipoAcao             number
  ) is
    v_status ordemtransferencia.status%type;
    v_msg    t_message;
  
    procedure verificarNFEmConferencia is
      v_validar number;
    begin
      v_validar := pk_ordemtransferencia.isNFEmConferencia(p_idOrdemTransferencia);
    
      if (v_validar > 0) then
        v_msg := t_message('Existem notas vinculadas à ordem de transferência, que encontram-se em conferência.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end verificarNFEmConferencia;
  
    procedure verificarNfsEmOR is
      v_retorno number;
    begin
    
      select count(*)
        into v_retorno
        from ordemtransferenciaitem oi, tdnitemnfdet t, nfdet d,
             notafiscal nf
       where oi.idordemtransferencia = p_idOrdemTransferencia
         and oi.idordemtransferenciaitem = t.idordemtransferenciaitem
         and t.idnfdet = d.idnfdet
         and d.nf = nf.idnotafiscal
         and nvl(nf.idlotenf, 0) > 0;
    
      if (v_retorno > 0) then
        v_msg := t_message('Ação cancelada, existem Notas Fiscais que estão vinculadas em uma Ordem de Recebimento.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end verificarNfsEmOR;
  
  begin
    begin
      select ot.status
        into v_status
        from ordemtransferencia ot
       where ot.idordemtransferencia = p_idOrdemTransferencia;
    exception
      when no_data_found then
        v_msg := t_message('Ação não permitida, a Ordem de Transferência [ idOrdemTransferencia : {0} ] não foi encontarada .');
        v_msg.addParam(p_idOrdemTransferencia);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (p_tipoAcao = C_ESTORNARCANCELAMENTO and v_status <> C_OT_CANCELADO) then
      v_msg := t_message('Ação não permitida, a Ordem de Transferência [ idOrdemTransferencia : {0} ] não está com status \"Cancelada\" .');
      v_msg.addParam(p_idOrdemTransferencia);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_tipoAcao in (C_CANCELAR, C_EXCLUIR, C_FINALIZAR) and
       v_status <> C_OT_PENDENTE) then
      v_msg := t_message('Ação não permitida, a Ordem de Transferência [ idOrdemTransferencia : {0} ] não está com status \"Pendente\" .');
      v_msg.addParam(p_idOrdemTransferencia);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (p_tipoAcao in (C_CANCELAR, C_FINALIZAR)) then
      verificarNFEmConferencia;
    end if;
  
    if (p_tipoAcao = C_EXCLUIR) then
      verificarNfsEmOR;
    end if;
  
  end validarOT;

  procedure removeVariasNFsTDN is
  begin
    for c_Nf in (select i.idordemtransferenciaitem, i.idnfdet
                   from gtt_selecao g, nfdet nfd, tdnitemnfdet i
                  where nfd.nf = g.idselecionado
                    and i.idnfdet = nfd.idnfdet)
    loop
      removerTDNNFDet(c_Nf.idordemtransferenciaitem, c_Nf.Idnfdet);
    end loop;
  end removeVariasNFsTDN;

  procedure addNfDetTDN
  (
    p_idusuario                in number,
    p_idnfdet                  in number,
    p_iditemordemtransferencia in number,
    p_qtdeUN                   in number
  ) is
    type t_item is record(
      qtdeassociada            number,
      qtdedisponiveltdn        number,
      qtdedisponivelnf         number,
      statusordemtransferencia number,
      numeroordemtransferencia varchar2(100),
      idlotenf                 number,
      idnotafiscal             number,
      idprodutotdn             number,
      idprodutonf              number,
      produtofracionado        char(1),
      iddepositantenf          number,
      iddepositantetdn         number,
      idordemtransferencia     number,
      idarmazem                number,
      ordemTransferencia       notafiscal.ordemtransferencia%type,
      idtdnitemnfdet           tdnitemnfdet.idtdnitemnfdet%type,
      itemlocation             ordemtransferenciaitem.itemlocation%type,
      idprodutoOT              Ordemtransferenciaitem.Idproduto%type);
  
    r_item t_item;
    v_msg  t_message;
  
    procedure carregarDados is
    begin
      r_item.qtdeassociada := p_qtdeUN;
    
      select a.qtdedisponiveltdn, a.status, a.numeroordemtransferencia,
             pd.idproduto, a.fracionado, a.iddepositante,
             a.idordemtransferencia, a.idarmazem, a.itemlocation,
             a.idproduto
        into r_item.qtdedisponiveltdn, r_item.statusordemtransferencia,
             r_item.numeroordemtransferencia, r_item.idprodutotdn,
             r_item.produtofracionado, r_item.iddepositantetdn,
             r_item.idordemtransferencia, r_item.idarmazem,
             r_item.itemlocation, r_item.idprodutoOT
        from (select (oti.qtdeinformada - oti.qtderecebida) qtdedisponiveltdn,
                      ot.status, ot.numeroordemtransferencia, p.idproduto,
                      p.fracionado, ot.iddepositante, ot.idordemtransferencia,
                      ot.idarmazem, oti.itemlocation
                 from ordemtransferenciaitem oti, ordemtransferencia ot,
                      produto p
                where oti.idordemtransferenciaitem =
                      p_iditemordemtransferencia
                  and ot.idordemtransferencia = oti.idordemtransferencia
                  and p.idproduto = oti.idproduto) a, produtodepositante pd
       where pd.identidade(+) = a.iddepositante
         and pd.idproduto(+) = a.idproduto;
    
      select (nd.qtde * e.fatorconversao) -
              nvl((select sum(tdni.qtde)
                    from tdnitemnfdet tdni
                   where tdni.idnfdet = nd.idnfdet), 0), nf.idlotenf,
             nf.idnotafiscal, nd.idproduto, nf.iddepositante,
             nf.ordemtransferencia
        into r_item.qtdedisponivelnf, r_item.idlotenf, r_item.idnotafiscal,
             r_item.idprodutonf, r_item.iddepositantenf,
             r_item.OrdemTransferencia
        from nfdet nd, embalagem e, notafiscal nf
       where nd.idnfdet = p_idnfdet
         and e.idproduto = nd.idproduto
         and e.barra = nd.barra
         and nf.idnotafiscal = nd.nf;
    
    end carregarDados;
  
    procedure validacoes is
      ORDEM_ABERTA constant number := 0;
    begin
    
      if r_item.idprodutotdn is null then
        v_msg := t_message('O produto não está vinculado ao depositante' ||
                           chr(13) || 'IDDEPOSITANTE: {0}' || chr(13) ||
                           'IDPRODUTO: {1}');
        v_msg.addParam(r_item.iddepositantetdn);
        v_msg.addParam(r_item.idprodutoOT);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.OrdemTransferencia = 0) then
        v_msg := t_message('Nota Fiscal não pertence ao fluxo de Ordem de Transferência. Não é possível vincular Nota Fiscal.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdeassociada <= 0) then
        v_msg := t_message('A qtde informada deve ser maior que zero.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                           chr(13) || 'QTDE ASSOCIADA: {1}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.statusordemtransferencia <> ORDEM_ABERTA) then
        v_msg := t_message('A Ordem de Transferência deve possuir o status EM ABERTO.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdedisponiveltdn < r_item.qtdeassociada) then
        v_msg := t_message('Não existe quantidade disponível no item da Ordem de Transferência para associar ao item da Nota Fiscal.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                           chr(13) || 'QTDEDISPONIVEL: {1}' || chr(13) ||
                           'QTDE ASSOCIADA: {2}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        v_msg.addParam(r_item.qtdedisponiveltdn);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.idlotenf is not null) then
        v_msg := t_message('A Nota Fiscal já esta vinculada a uma Ordem de Recebimento.' ||
                           chr(13) || 'ORDEM DE RECEBIMENTO: {0}' ||
                           chr(13) || 'NOTA FISCAL ID: {1}');
        v_msg.addParam(r_item.idlotenf);
        v_msg.addParam(r_item.idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdedisponivelnf < r_item.qtdeassociada) then
        v_msg := t_message('A qtde restante do item da Nota Fiscal para associar aos itens da Ordem de Transferência, não confere com a quantidade informada.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                           chr(13) || 'QTDERESTANTE NF: {1}' || chr(13) ||
                           'QTDE INFORMADA: {2}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        v_msg.addParam(r_item.qtdedisponivelnf);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.idprodutotdn <> r_item.idprodutonf) then
        v_msg := t_message('O produto informado para o item da Ordem de Transferência não é o mesmo do item da nota fiscal.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                           chr(13) ||
                           'IDPRODUTO ORDEM DE TRANSFERÊNCIA: {1}' ||
                           chr(13) || 'IDPRODUTO NOTA FISCAL: {2}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        v_msg.addParam(r_item.idprodutotdn);
        v_msg.addParam(r_item.idprodutonf);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdeassociada <> trunc(r_item.qtdeassociada) and
         r_item.produtofracionado = 'N') then
        v_msg := t_message('Não é permitido informar quantidade fracionada para produto que não foi configurado como FRACIONADO.' ||
                           chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                           chr(13) || 'IDPRODUTO: {1}');
        v_msg.addParam(r_item.numeroordemtransferencia);
        v_msg.addParam(r_item.idprodutotdn);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.iddepositantetdn is not null) then
        if (r_item.iddepositantenf <> r_item.iddepositantetdn) then
          v_msg := t_message('O depositante informado para o item da Ordem de Transferência não é o mesmo do item da Nota Fiscal.' ||
                             chr(13) || 'ORDEM DE TRANSFERÊNCIA: {0}' ||
                             chr(13) ||
                             'IDDEPOSITANTE ORDEM DE TRANSFERÊNCIA: {1}' ||
                             chr(13) || 'IDDEPOSITANTE NOTA FISCAL: {2}');
          v_msg.addParam(r_item.numeroordemtransferencia);
          v_msg.addParam(r_item.iddepositantetdn);
          v_msg.addParam(r_item.iddepositantenf);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validacoes;
  
    procedure validarVinculoTDNNfDet is
    begin
    
      begin
        select i.idtdnitemnfdet, i.itemlocation
          into r_item.idtdnitemnfdet, r_item.itemlocation
          from tdnitemnfdet i, ordemtransferenciaitem oti
         where i.idnfdet = p_idnfdet
           and i.idordemtransferenciaitem = oti.idordemtransferenciaitem
           and i.itemlocation = oti.itemlocation
           and oti.idordemtransferenciaitem = p_iditemordemtransferencia;
      exception
        when no_data_found then
        
          insert into tdnitemnfdet
            (idtdnitemnfdet, idordemtransferenciaitem, idnfdet, qtde,
             idusuariocriacao, datacriacao, idlotenf, itemlocation)
          values
            (seq_tdnitemnfdet.nextval, p_iditemordemtransferencia,
             p_idnfdet, p_qtdeUN, p_idusuario, sysdate, r_item.idlotenf,
             r_item.itemlocation);
        
          return;
      end;
    
      update tdnitemnfdet i
         set qtde               = qtde + p_qtdeUN,
             idusuarioalteracao = p_idusuario,
             dataalteracao      = sysdate
       where i.idtdnitemnfdet = r_item.idtdnitemnfdet;
    
    end validarVinculoTDNNfDet;
  
  begin
  
    carregarDados;
  
    validacoes;
  
    update notafiscal
       set idarmazem = r_item.idarmazem
     where idnotafiscal = r_item.idnotafiscal
       and idarmazem is null;
  
    if (r_item.iddepositantetdn is null) then
      update ordemtransferencia ot
         set ot.iddepositante = r_item.iddepositantenf
       where ot.idordemtransferencia = r_item.idordemtransferencia;
    end if;
  
    validarVinculoTDNNfDet;
  
    -- Adiciona qtde do item da nfe no item da Ordem de Transferência
    update ordemtransferenciaitem o
       set o.qtderecebida =
           (o.qtderecebida + p_qtdeUn)
     where o.idordemtransferenciaitem = p_iditemordemtransferencia;
  
  end addNfDetTDN;

  procedure finalizarOrdemTransfAuto(p_idDepositante number := null) is
    v_idUsuario number;
  begin
    v_idusuario := retornaUsuarioConfigGeral;
  
    for c in (select o.idordemtransferencia,
                     trunc(o.dataintegracao) datacadastro,
                     (select max(trunc(m.dataalocacao))
                         from ordemtransferenciaitem i, tdnitemnfdet t,
                              orlote ol, mapaalocacao m
                        where 1 = 1
                          and t.idordemtransferenciaitem =
                              i.idordemtransferenciaitem
                          and i.idordemtransferencia = o.idordemtransferencia
                          and ol.idlotenf = t.idlotenf
                          and m.idlote = ol.idlote) data_max_vinculo,
                     nvl(d.qtdediafinautoordemtransfcomre, 0) qtdediafinautoordemtransfcomre,
                     nvl(d.qtdediafinautoordemtransfsemre, 0) qtdediafinautoordemtransfsemre
                from ordemtransferencia o, depositante d
               where 1 = 1
                 and d.identidade = o.iddepositante
                 and o.status = C_OT_PENDENTE
                 and d.identidade = nvl(p_idDepositante, d.identidade)
                 and pk_ordemtransferencia.isNFEmConferencia(o.idordemtransferencia) = 0
               order by o.idordemtransferencia)
    loop
      if (c.qtdediafinautoordemtransfsemre > 0 and
         c.data_max_vinculo is null) then
      
        if (trunc(sysdate) - trunc(c.datacadastro) >
           c.qtdediafinautoordemtransfsemre) then
          pk_ordemtransferencia.finalizarOrdemTransferencia(c.idordemtransferencia,
                                                            v_idUsuario, 1);
          pk_integracao.exportarTCN(c.idordemtransferencia);
        
        end if;
      
      elsif (c.qtdediafinautoordemtransfcomre > 0 and
            c.data_max_vinculo is not null) then
      
        if (trunc(sysdate) - trunc(c.data_max_vinculo) >
           c.qtdediafinautoordemtransfcomre) then
          pk_ordemtransferencia.finalizarOrdemTransferencia(c.idordemtransferencia,
                                                            v_idUsuario, 1);
          pk_integracao.exportarTCN(c.idordemtransferencia);
        end if;
      
      end if;
    
    end loop;
  
  end finalizarOrdemTransfAuto;

  function isNFEmConferencia(p_idOrdemTransferencia number) return number is
    v_retorno number;
  begin
    select count(1)
      into v_retorno
      from ordemtransferenciaitem oi, tdnitemnfdet t, nfdet d, notafiscal nf,
           lotenf lnf
     where oi.idordemtransferencia = p_idOrdemTransferencia
       and lnf.status <> C_OR_PROCESSADA
       and lnf.flaglibnf = C_OR_EM_CONFERENCIA
       and (lnf.faltamalocar > 0 or lnf.faltamalocar = -1)
       and oi.idordemtransferenciaitem = t.idordemtransferenciaitem
       and t.idnfdet = d.idnfdet
       and d.nf = nf.idnotafiscal
       and nf.idlotenf = lnf.idlotenf;
  
    return v_retorno;
  
  end isNFEmConferencia;

  procedure reabrirOrdemTransferencia(p_idOrdemTransferencia number) is
    C_ORDEM_PENDENTE   constant number := 0;
    C_ORDEM_FINALIZADO constant number := 1;
    v_totalSaldo number;
    v_msg        t_message;
  
    function saldoPendenteRecebimento return boolean is
    begin
      select count(*)
        into v_totalSaldo
        from (select o.idordemtransferencia, o.idproduto,
                      sum(o.qtdeinformada) qtdeinformada,
                      sum(o.qtderecebida) qtderecebida
                 from ordemtransferenciaitem o, ordemtransferencia ot
                where o.idordemtransferencia = p_idOrdemTransferencia
                  and ot.idordemtransferencia = o.idordemtransferencia
                  and ot.status = C_ORDEM_FINALIZADO
                group by o.idordemtransferencia, o.idproduto) a
       where a.qtdeinformada > a.qtderecebida;
    
      return v_totalSaldo > 0;
    
    end saldoPendenteRecebimento;
  
  begin
  
    if not saldoPendenteRecebimento then
      v_msg := t_message('O saldo da ordem de transferência {0} já foi totalmente recebido.');
      v_msg.addParam(p_idOrdemTransferencia);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update ordemtransferencia o
       set o.status = C_ORDEM_PENDENTE
     where o.idordemtransferencia = p_idOrdemTransferencia;
  
  end;

END PK_ORDEMTRANSFERENCIA;
/

