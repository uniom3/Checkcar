create view VT_HISTORICOTROCADOCA as
select (select do.descr
           from doca do
          where do.iddoca = h.iddocaanterior) docaanterior,
       (select do.descr
           from doca do
          where do.iddoca = h.iddocanova) docanova, u.nomeusuario usuario,
       h.data, h.moduloorigem origemtroca, h.idcarga h$coleta,
       h.id h$tableid
  from historicotrocadoca h, usuario u
 where h.idusuario = u.idusuario
/

