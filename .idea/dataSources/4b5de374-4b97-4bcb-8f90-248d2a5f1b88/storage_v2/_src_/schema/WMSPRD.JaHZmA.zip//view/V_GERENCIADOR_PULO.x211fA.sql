create view V_GERENCIADOR_PULO as
select psp.id as "Id", psp.idarmazem as "Id Armazém", a.descr as "Armazém",
       psp.idonda as "Id Onda", rp.codigointerno as "Onda",
       psp.idproduto as "Id Produto", p.descr as "Produto", lo.idlocal,
       psp.idusuario as "Id Usuário Pulo", up.nomeusuario as "Usuário Pulo",
       psp.idusuarioleitura as "Id Usuário Supervisor",
       ul.nomeusuario as "Supervisor", psp.lido as "Status",
       lo.idlocalformatado f$idlocal
  from pularsepproduto psp, romaneiopai rp, produto p, local lo, usuario up,
       usuario ul, armazem a
 where a.idarmazem = psp.idarmazem
   and ul.idusuario(+) = psp.idusuarioleitura
   and up.idusuario = psp.idusuario
   and lo.id = psp.idlocalorigem
   and p.idproduto = psp.idproduto
   and rp.idromaneio = psp.idonda
 order by psp.id, psp.idonda, lo.idlocal
/

