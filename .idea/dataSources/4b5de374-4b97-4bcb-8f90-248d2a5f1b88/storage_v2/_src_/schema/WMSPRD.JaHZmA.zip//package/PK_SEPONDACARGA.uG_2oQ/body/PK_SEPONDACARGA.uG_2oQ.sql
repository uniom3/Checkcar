create package body pk_sepondacarga is

  function separacaoManual
  (
    p_idOnda        in number,
    p_tarefa        separacaoporcarga.tarefa%type,
    p_idusuario     in number,
    p_mensagem      in out varchar2,
    p_tipoSeparacao in number := 1
  ) return number is
  
    C_MENSAGEM                 CONSTANT number := 3;
    C_REABASTECIMENTO_PENDENTE CONSTANT number := 0;
    C_ORIGEM_CONCLUIDO         CONSTANT number := 1;
    C_DESTINO_CONCLUIDO        CONSTANT number := 2;
    C_SEP_ANDAMENTO            CONSTANT number := 1;
    C_SEP_PENDENTE             CONSTANT number := 0;
  
    E_REAB_PENDENTE EXCEPTION;
    E_MENSAGEM      EXCEPTION;
  
    v_isSepararOrigem number;
    v_reabPendente    number;
    v_retorno         number;
  
    v_msg t_message;
  
    procedure validarReabastecimento is
    begin
      for c in (select distinct res.idlocal, res.idlote
                  from separacaoporcarga sep, reservaestoqueondacarga res
                 where res.idseparacaoporcarga = sep.idseparacaoporcarga
                   and sep.idonda = p_idonda
                   and sep.status = C_SEP_PENDENTE
                   and sep.tarefa = p_tarefa)
      loop
        insert into gtt_reabpendente
          (idproduto, idendereco, idremanejamento)
          select lt.idproduto, l.id idendereco, r.idremanejamento
            from loteremanejamento lr, remanejamento r, lote lt, local l
           where lr.idremanejamento = r.idremanejamento
             and lr.idlote = lt.idlote
             and r.idarmazemdestino = l.idarmazem
             and r.idlocaldestino = l.idlocal
             and lr.idlote = c.idlote
             and l.idlocal = c.idlocal
             and r.status <> 'F'
           group by lt.idproduto, l.id, r.idremanejamento;
      end loop;
    
      select nvl(count(*), 0)
        into v_reabPendente
        from gtt_reabpendente;
    
      if v_reabPendente > 0 then
        raise E_REAB_PENDENTE;
      end if;
    
    end validarReabastecimento;
  
    procedure validarUsuarioSeparacao is
      v_idusuario   number;
      v_nomeUsuario usuario.nomeusuario%type;
    begin
      select count(1)
        into v_isSepararOrigem
        from dual
       where exists (select 1
                from separacaoporcarga s
               where s.idonda = p_idOnda
                 and s.tarefa = p_tarefa
                 and s.status = C_SEP_PENDENTE);
    
      if (v_isSepararOrigem = 0) then
        begin
          select sep.idusuario, u.nomeusuario
            into v_idusuario, v_nomeUsuario
            from separacaoporcarga sep, usuario u
           where sep.idonda = p_idOnda
             and sep.tarefa = p_tarefa
             and sep.status = C_SEP_ANDAMENTO
             and sep.idusuario = u.idusuario
             and rownum = 1;
        exception
          when no_data_found then
            p_mensagem := 'Nenhuma separação encontrada';
            raise E_MENSAGEM;
        end;
      
        if (v_idusuario <> p_idusuario) then
          p_mensagem := 'Esta separação ja foi iniciada pelo usuario ' ||
                        v_nomeUsuario || ' (id ' || v_idusuario ||
                        '). Operação cancelada.';
          raise E_MENSAGEM;
        end if;
      
      end if;
    end validarUsuarioSeparacao;
  
    function separarDestinoOnda return number is
      v_textoLocalSeparacao varchar2(100);
    
      procedure finalizarConvocacaoAtiva is
        v_totalTarefas          number;
        v_totalTarefasSeparadas number;
        v_descricao             varchar2(100);
        v_codigoOnda            romaneiopai.codigointerno%type;
        v_palete                separacaoporcarga.palete%type;
        v_idArmazem             separacaoporcarga.idArmazem%type;
      begin
        begin
          select count(s.idseparacaoporcarga) as total,
                 count(case
                          when s.status = 2 then
                           1
                        end) as separado, rp.codigointerno, s.palete,
                 s.idarmazem
            into v_totalTarefas, v_totalTarefasSeparadas, v_codigoOnda,
                 v_palete, v_idArmazem
            from separacaoporcarga s, romaneiopai rp
           where s.idonda = p_idOnda
             and s.tarefa = p_tarefa
             and rp.idromaneio = s.idonda
           group by rp.codigointerno, s.palete, s.idarmazem;
        
        exception
          when no_data_found then
            v_msg := t_message('Não existe nenhuma tarefa pendente para finalização da convocação ativa vinculada na onda id {0}. Operação cancelada.');
            v_msg.addParam(p_idOnda);
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      
        if (v_totalTarefas = v_totalTarefasSeparadas) then
          pk_convocacao.finalizaseparacaoonda(p_idusuario, p_idOnda,
                                              0, p_tarefa);
        
          v_descricao := 'Conferência da Carga - Onda: ' || v_codigoOnda ||
                         ' Palete: ' || v_palete;
        
          pk_convocacao.insereConfPaleteCarga(p_idusuario, v_codigoOnda,
                                              v_idArmazem, v_descricao,
                                              v_palete);
        
        end if;
      end finalizarConvocacaoAtiva;
    
    begin
      delete from gtt_picking_dinamico;
    
      for c in (select sep.idarmazem, sep.idlocal origem, lo.tipo tipoOrigem,
                       res.idlote, ld.idlocal destino,
                       sum(res.qtde) qtdemovimentada,
                       sum(res.qtde) qtdeadicionar, lt.idproduto,
                       lt.iddepositante, pnf.idnotafiscal
                  from separacaoporcarga sep, reservaestoqueondacarga res,
                       destinosaidaonda ds, lote lt, local lo, local ld,
                       paleteondanf pnf
                 where sep.idonda = p_idonda
                   and sep.tarefa = p_tarefa
                   and sep.status = 1
                   and sep.datatermino is null
                   and res.idseparacaoporcarga = sep.idseparacaoporcarga
                   and ds.idonda = sep.idonda
                   and lt.idlote = res.idlote
                   and lo.idlocal = sep.idlocal
                   and lo.idarmazem = sep.idarmazem
                   and ld.id = ds.iddoca
                   and pnf.idpaleteondanf = res.idpaleteondanf
                 group by sep.idarmazem, sep.idlocal, lo.tipo, res.idlote,
                          ld.idlocal, lt.idproduto, lt.iddepositante,
                          pnf.idnotafiscal
                 order by sep.idarmazem, sep.idlocal, res.idlote,
                          pnf.idnotafiscal)
      loop
        pk_estoque.retirar_pendencia(c.idarmazem, c.origem, c.idlote,
                                     c.qtdemovimentada, p_idusuario,
                                     'SEPARACAO EXECUTADA, REMOVIDO PENDENCIA PARA SEPARACAO DA TAREFA ' ||
                                      p_tarefa || ', DA ONDA ID:' ||
                                      p_idonda);
        pk_estoque.retirar_estoque(c.idarmazem, c.origem, c.idlote,
                                   c.qtdemovimentada, p_idusuario,
                                   'SEPARACAO EXECUTADA, RETIRADO ESTOQUE PARA SEPARACAO DA TAREFA ' ||
                                    p_tarefa || ', DA ONDA ID:' || p_idonda,
                                   'N');
      
        if (c.tipoOrigem = 0) then
          pk_picking_dinamico.addGttPickingDinamico(c.idProduto,
                                                    c.iddepositante,
                                                    c.origem, c.idarmazem, 0);
        end if;
      
        pk_estoque.incluir_estoque(c.idarmazem, c.destino, c.idlote,
                                   c.qtdemovimentada, p_idusuario,
                                   'SEPARACAO EXECUTADA, ADICIONADO ESTOQUE PARA SEPARACAO DE ' ||
                                    v_textoLocalSeparacao || ', DA ONDA ID:' ||
                                    p_idonda, 'N');
        pk_estoque.incluir_pendencia(c.idarmazem, c.destino, c.idlote,
                                     c.qtdemovimentada, p_idusuario,
                                     'SEPARACAO EXECUTADA, ADICIONADO PENDENCIA PARA SEPARACAO DE ' ||
                                      v_textoLocalSeparacao ||
                                      ', DA ONDA ID:' || p_idonda);
      
        update saidapornf snf
           set snf.qtdeseparada       = snf.qtdeseparada + c.qtdemovimentada,
               snf.separado           = 1,
               snf.dataseparacao      = sysdate,
               snf.idusuarioseparacao = p_idusuario
         where snf.idnotafiscal = c.idnotafiscal
           and snf.idonda = p_idonda;
      end loop;
    
      pk_picking_dinamico.deletar_picking_dinamico;
      pk_picking_dinamico.inserir_picking_dinamico;
    
      update separacaoporcarga sep1
         set sep1.status        = 2,
             sep1.idusuario     = p_idusuario,
             sep1.datatermino   = sysdate,
             sep1.tiposeparacao = p_tipoSeparacao
       where sep1.tarefa = p_tarefa
         and sep1.idonda = p_idOnda
         and sep1.status = 1;
    
      finalizarConvocacaoAtiva;
    
      update romaneiopai r
         set r.separado = 'S'
       where r.idromaneio = p_idOnda;
    
      return C_DESTINO_CONCLUIDO;
    end separarDestinoOnda;
  
    function separarOrigemOnda return number is
    
      procedure alteraSaidaPorNf is
      begin
        for c in (select s.idonda, pnf.idnotafiscal, sum(rs.qtde) qtde
                    from separacaoporcarga s, reservaestoqueondacarga rs,
                         paleteondanf pnf
                   where s.idOnda = p_idOnda
                     and s.tarefa = p_tarefa
                     and s.status = 1
                     and rs.idseparacaoporcarga = s.idseparacaoporcarga
                     and pnf.idpaleteondanf = rs.idpaleteondanf
                   group by s.idonda, pnf.idnotafiscal)
        loop
          update saidapornf snf
             set snf.separacaoiniciada = snf.separacaoiniciada + c.qtde
           where snf.idnotafiscal = c.idnotafiscal
             and snf.idonda = c.idonda;
        end loop;
      end alteraSaidaPorNf;
    
    begin
      if (p_tipoSeparacao = 2) then
        v_msg := t_message('Não é possível realizar a separação de origem via coletor de dados com este fluxo.');
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      update separacaoporcarga sep
         set sep.status        = 1,
             sep.idusuario     = p_idUsuario,
             sep.datainicio    = sysdate,
             sep.tiposeparacao = 1
       where sep.idonda = p_idonda
         and sep.tarefa = p_tarefa
         and sep.status = 0;
    
      update romaneiopai r
         set r.statusonda = 4
       where r.idromaneio = p_idOnda;
    
      alteraSaidaPorNf;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Separação Manual Iniciada para a tarefa: ' ||
                            p_tarefa || ' / idOnda: ' || p_idOnda, p_idOnda,
                           'SO');
    
      return C_ORIGEM_CONCLUIDO;
    end separarOrigemOnda;
  
  begin
    begin
      pk_seponda.validarSeparacaoUnicoUsuario(p_idOnda, p_idusuario,
                                              p_mensagem);
    
      if (p_mensagem is not null) then
        raise E_MENSAGEM;
      end if;
    
      validarReabastecimento;
      validarUsuarioSeparacao;
    
      if (v_isSepararOrigem = 1) then
        v_retorno := separarOrigemOnda;
      else
        v_retorno := separarDestinoOnda;
      end if;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Separação Manual Finalizada para o identificador: ' ||
                            p_tarefa || ' / idOnda: ' || p_idOnda, p_idOnda,
                           'SO');
    
      return v_retorno;
    exception
      when E_REAB_PENDENTE then
        return C_REABASTECIMENTO_PENDENTE;
      when E_MENSAGEM then
        return C_MENSAGEM;
    end;
  
  end separacaoManual;

  procedure pausarSeparacao
  (
    p_idOnda    in number,
    p_tarefa    separacaoporcarga.tarefa%type,
    p_idusuario in number
  ) is
    v_isPausado number;
    v_idUsuario number;
  
    v_msg t_message;
  begin
    select decode(sep.datapausa, null, 0, 1), sep.idusuario
      into v_isPausado, v_idUsuario
      from separacaoporcarga sep, reservaestoqueondacarga res, local lo,
           local ld, destinosaidaonda ds
     where sep.idseparacaoporcarga = res.idseparacaoporcarga
       and res.idlocal = lo.idlocal
       and sep.idonda = ds.idonda
       and ld.id = ds.iddoca
       and sep.status = 1
       and sep.tarefa = p_tarefa
       and sep.idonda = p_idonda
       and rownum = 1;
  
    if (v_idUsuario <> p_idusuario) then
      v_msg := t_message('Apenas o usuario que esta separando esta regiao pode pausa-la');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update separacaoporcarga sep
       set sep.tempopausa = decode(v_isPausado, 0, sep.tempopausa,
                                   floor((sysdate - sep.datainicio) * 24 * 60 * 60) +
                                    nvl(sep.tempopausa, 0))
     where sep.idonda = p_idonda
       and sep.tarefa = p_tarefa;
  
  end;

  function getProximaSeparacao
  (
    p_idonda in number,
    p_tarefa in varchar2
  ) return number is
    C_STATUS_PENDENTE constant number := 0;
    v_proximaSeparacao number;
  begin
    begin
      select idseparacaoporcarga
        into v_proximaSeparacao
        from (select idseparacaoporcarga
                 from separacaoporcarga s
                where s.idonda = p_idonda
                  and s.tarefa = p_tarefa
                  and s.status = C_STATUS_PENDENTE
                order by ordem)
       where rownum = 1;
    exception
      when no_data_found then
        v_proximaSeparacao := 0;
    end;
  
    return v_proximaSeparacao;
  end getProximaSeparacao;

  function finalizarSeparacaoCarga
  (
    p_idSeparacaoCarga number,
    p_idUsuario        number
  ) return number is
    C_STATUS_EM_ANDAMENTO constant number := 1;
    C_EM_EXECUCAO         constant number := 4;
    v_idOnda number;
    v_tarefa separacaoporcarga.tarefa%type;
  
    procedure tratarConcorrencia is
      C_STATUS_NAO_SEPARADO constant number := 0;
      v_status number;
    
      v_msg t_message;
    begin
      select s.status
        into v_status
        from separacaoporcarga s
       where s.idseparacaoporcarga = p_idseparacaocarga
         for update;
    
      if (v_status <> C_STATUS_NAO_SEPARADO) then
        v_msg := t_message('A separação deste produto já foi realizada. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end tratarConcorrencia;
  
    procedure iniciarSeparacao is
    begin
      select s.idonda, s.tarefa
        into v_idOnda, v_tarefa
        from separacaoporcarga s
       where s.idseparacaoporcarga = p_idSeparacaoCarga;
    
      update romaneiopai
         set statusonda = C_EM_EXECUCAO
       where idromaneio = v_idOnda
         and statusonda <> C_EM_EXECUCAO;
    
      update separacaoporcarga s
         set s.status     = C_STATUS_EM_ANDAMENTO,
             s.datainicio = sysdate,
             s.idusuario  = p_idUsuario
       where s.idseparacaoporcarga = p_idSeparacaoCarga;
    end iniciarSeparacao;
  
    procedure alteraSaidaPorNf is
    begin
      for c in (select s.idonda, pnf.idnotafiscal, sum(rs.qtde) qtde
                  from separacaoporcarga s, reservaestoqueondacarga rs,
                       paleteondanf pnf
                 where s.idseparacaoporcarga = p_idSeparacaoCarga
                   and rs.idseparacaoporcarga = s.idseparacaoporcarga
                   and pnf.idpaleteondanf = rs.idpaleteondanf
                 group by s.idonda, pnf.idnotafiscal)
      loop
        update saidapornf snf
           set snf.separacaoiniciada = snf.separacaoiniciada + c.qtde
         where snf.idnotafiscal = c.idnotafiscal
           and snf.idonda = c.idonda;
      end loop;
    end alteraSaidaPorNf;
  
  begin
  
    tratarConcorrencia;
  
    iniciarSeparacao;
  
    alteraSaidaPorNf;
    
    pk_convocacao.finalizaSeparacaoOnda(p_idUsuario, v_idOnda, p_idSeparacaoCarga, v_tarefa);
  
    return getProximaSeparacao(v_idOnda, v_tarefa);
  
  end finalizarSeparacaoCarga;

end pk_sepondacarga;
/

