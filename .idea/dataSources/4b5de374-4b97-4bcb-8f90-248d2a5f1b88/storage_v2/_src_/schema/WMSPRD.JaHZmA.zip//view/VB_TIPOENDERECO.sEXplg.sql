create view VB_TIPOENDERECO as
select idtipoendereco IdTipo, descr tipoendereco,
       idtipoendereco h$idtipoendereco
  from tipoendereco
/

