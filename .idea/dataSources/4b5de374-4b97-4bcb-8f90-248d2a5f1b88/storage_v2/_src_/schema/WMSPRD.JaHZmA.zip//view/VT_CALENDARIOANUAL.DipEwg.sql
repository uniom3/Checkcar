create view VT_CALENDARIOANUAL as
select id h$id, iddepositante, ano as anoCalendario, to_char(dtinicio,'dd/mm/rrrr') as dataInicioCalendario
  from calendarioanual
/

