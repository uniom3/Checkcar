create view VI_INT_OR_I as
select NROOR "OR", CODIGOINTERNO CODIGOPRODUTO, QTDE, ESTADO, ID, '*' F,
       BARRA, CODINTEGRACAOSETOR, idreplicacao
  from int_envio_or_i o
/

