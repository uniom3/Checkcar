create view VI_INT_ENVIO_ORDEMSERVICO_M1 as
select datahora, cnpjarmazem, cnpjdepositante, estado, codproduto, produto,
       barra, descricaoreduzida, fatorconversao, qtde, idmovimento_wms,
       loteindustriaanterior, loteindustrianovo, idloteanterior, idlotenovo,
       vencimento, notafiscal, pesokg, tiposervico, i.agrupador id, agrupador
  from int_envio_ordemservico i
/

