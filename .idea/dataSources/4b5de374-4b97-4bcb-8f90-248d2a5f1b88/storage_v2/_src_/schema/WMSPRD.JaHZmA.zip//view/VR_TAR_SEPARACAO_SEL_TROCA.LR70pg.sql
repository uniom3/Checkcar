create view VR_TAR_SEPARACAO_SEL_TROCA as
select count(distinct z.idlocalorigem) numenderecos, z.codigointerno,
       z.numpedido, z.regiao, z.identificador, z.codbarratarefa,
       sum(z.cubagem) cubagem, sum(z.peso) peso, z.transportadora,
       z.notafiscal, z.titulo, sum(z.quantidade) qtdepecas, z.tipo
  from (select o.codigointerno,
                decode(co.conferenciaporcheckoutexpress, 1, 'CHECKOUT EXPRESS',
                        nvl(n.numpedidofornecedor, ' ')) numpedido,
                ro.descr regiao, m.identificador, m.codbarratarefa,
                round((((e.altura * e.largura * e.comprimento) /
                       e.fatorconversao) * m.quantidade) / 1000000000, 4) cubagem,
                round(((e.pesobruto / e.fatorconversao) * m.quantidade) / 1000,
                       4) peso, m.idlocalorigem,
                decode(co.conferenciaporcheckoutexpress, 1, ' ', t.razaosocial) transportadora,
                decode(co.conferenciaporcheckoutexpress, 1, '',
                        decode(n.tiponf, 'P', ' ', n.codigointerno)) notafiscal,
                o.tituloromaneio titulo, m.quantidade, 0 tipo
           from v_tarefas_onda m, romaneiopai o, local lo,
                regiaoarmazenagem ro, notafiscal n, entidade t, lote l,
                embalagem e, configuracaoonda co
          where m.idonda in (select idselecionado
                               from gtt_selecao)
            and m.status in (0, 1, 2)
            and exists
          (select 1
                   from movafetadatrocalotesep ms
                  where ms.idmovimentacao = m.ID
                    and ms.acao = 1)
            and o.idromaneio = m.idonda
            and lo.id = m.idlocalorigem
            and ro.idregiao = lo.idregiao
            and n.idnotafiscal = m.idnotafiscal
            and t.identidade = n.transportadoranotafiscal
            and m.idlote = l.idlote
            and e.barra = l.barra
            and e.idproduto = l.idproduto
            and co.idconfiguracaoonda = o.idconfiguracaoonda) z
 group by z.codigointerno, z.numpedido, z.regiao, z.identificador,
          z.codbarratarefa, z.transportadora, z.notafiscal, z.titulo, z.tipo
 order by codigointerno asc, codbarratarefa, z.tipo
/

