create view VT_INFORMACAOMATERIALDEP as
select imd.idinfomaterial, im.informacao, imd.imprimeetiqueta,
       imd.valorunico, imd.controlainfespectemporaria, imd.naovalidainfoespecifica, imd.identidade h$iddepositante,
       imd.idproduto h$idproduto
  from informacaomatdep imd, informacaomaterial im
 where im.idinfomaterial = imd.idinfomaterial
/

