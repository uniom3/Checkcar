create view VR_XMLCARTACORRECAO as
select 'ID' || '110110' || n.chaveacesso ||
        lpad((select count(nn.id) + 1 nSeqEvento
               from nfe nn
              where nn.idnotafiscal = n.idnotafiscal
                and nn.tipoevento = 1
                and nn.situacao not in (2, 4, 5)
                and nvl(nn.codigoresultado, '-1') not in ('-1', '572')
                and nn.tipoacao = 1), 2, '0') infEvento_Id,
       pk_utilities.getCodigoFederecaoEstado(c.uf) infEvento_cOrgao,
       c.tipoambiente infEvento_tpAmb,
       decode(length(replace(replace(replace(em.cgc, '.', ''), '/', ''), '-',
                              '')), 14,
               replace(replace(replace(em.cgc, '.', ''), '/', ''), '-', ''),
               null) infEvento_CNPJ, n.chaveacesso infEvento_chNFe,
       to_char(systimestamp, 'YYYY-MM-DD"T"hh24:mi:ssTZH:TZM') infEvento_dhEvento,
       '110110' infEvento_tpEvento,
       to_char((select count(nn.id) + 1 nSeqEvento
                  from nfe nn
                 where nn.idnotafiscal = n.idnotafiscal
                   and nn.tipoevento = 1
                   and nn.situacao not in (2, 4, 5)
                   and nvl(nn.codigoresultado, '-1') not in ('-1', '572')
                   and nn.tipoacao = 1)) infEvento_nSeqEvento,
       '1.00' infEvento_verEvento,
       n.protocoloretorno infEvento_detEvento_nProt,
       n.idnotafiscal h$idnotafiscal, nf.idprenf h$idprenf
  from nfe n, notafiscal nf, certificadoservidor c, entidade em
 where n.tipoacao = 0
   and n.situacao = 3
   and nf.idnotafiscal = n.idnotafiscal
   and c.id = n.certificadoservidor
   and em.identidade = nf.remetente
/

