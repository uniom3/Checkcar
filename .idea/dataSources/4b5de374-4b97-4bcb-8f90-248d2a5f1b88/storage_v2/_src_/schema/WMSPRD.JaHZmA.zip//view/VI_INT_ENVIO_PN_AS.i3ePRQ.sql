create view VI_INT_ENVIO_PN_AS as
select agrupador id, filetype, data, hour, sku, lotnumber, sing, LPAD(trunc(quantity), 9, '0') || LPAD((MOD(quantity, 1) * 1000), 3, '0') quantity,
       adjustmenttype, wharehouse, locationtype
  from int_envio_pn_as
/

