create view VR_ETIQUETALOCALARMAZENAGEM as
select a.descr armazem, l.idlocal, l.idlocalformatado, l.bloco, l.rua,
       l.predio, l.andar, l.apartamento, l.digitoverificador,
       substr(p.descr, 1, 50) produto, p.codigointerno codproduto,
       p.codreferencia, 0 h$tipo
  from gtt_selecao g, local l, armazem a, produtolocal lp, produto p
 where l.id = g.idselecionado
   and a.idarmazem = l.idarmazem
   and lp.idarmazem(+) = l.idarmazem
   and lp.idlocal(+) = l.idlocal
   and p.idproduto(+) = lp.idproduto
union
select a.descr armazem, l.idlocal, l.idlocalformatado, l.bloco, l.rua,
       l.predio, l.andar, l.apartamento, l.digitoverificador, '' produto,
       '' codproduto, '' codreferencia, 1 h$tipo
  from gtt_selecao g, local l, armazem a
 where l.id = g.idselecionado
   and a.idarmazem = l.idarmazem
 order by idlocal, produto
/

