create view VB_OSMISTURA as
select os.idordemservico, e.razaosocial, os.datacadastro, e.identidade,
       os.idproduto, to_char(os.idordemservico) codigointerno,
       os.idarmazem h$idarmazem
  from ordemservico os, entidade e
 where os.tiposervico = 'T'
   and os.situacao = 'P'
   and e.identidade = os.identidade
/

