create view V_EXPORTARORINFOESPEC as
select lnf.idlotenf, nvl(nfprod.codigoindustria, p.codigointerno) codprod,
       im.informacao, es.valor,
       lpad(lnf.idlotenf, 7, '0') ||
        rpad(substr(nvl(nfprod.codigoindustria, p.codigointerno), 0, 20), 20,
             ' ') || rpad(nvl(im.informacao, ' '), 50, ' ') ||
        rpad(nvl(es.valor, ' '), 50, ' ') ||
        rpad(nvl(nfprod.codigoindustria, p.codigointerno), 60, ' ') || '*' texto,
       decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'TRUNCADO') estado, ES.IDENTIFICADORINFO
  from lotenf lnf, estoqueinformacaoespecifica es, informacaomaterial im,
       produto p,
       (select nvl(nf.idlotenf, 0) idlotenf, nd.idproduto,
                max(ndi.codigoindustria) codigoindustria
           from notafiscal nf, nfdet nd, nfdetimpressao ndi
          where nd.nf = nf.idnotafiscal
            and ndi.idnfdet = nd.idnfdet
          group by nf.idlotenf, nd.idproduto) nfprod, depositante d, lote l
 where im.idinfomaterial = es.idinfomaterial
   and p.idproduto = es.idproduto
   and nfprod.idproduto = es.idproduto
   and nfprod.idlotenf = es.idlotenf
   and d.identidade = lnf.identidade
   and es.idlotenf = lnf.idlotenf
   and l.idlote(+) = es.idlote
/

