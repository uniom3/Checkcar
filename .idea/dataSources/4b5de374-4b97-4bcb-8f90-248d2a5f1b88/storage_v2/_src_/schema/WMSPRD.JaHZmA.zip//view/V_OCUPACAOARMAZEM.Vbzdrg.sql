create view V_OCUPACAOARMAZEM as
select a.idarmazem, a.descr armazem, 'Ocupados' endereco, 0 tipo,
       nvl(s.descr, 'SETOR NÃO DEFINIDO') setor,
       sum(decode(l.idlocal, null, 0, 1)) qtde
  from armazem a, local l, setor s, entidade e, regiaoarmazenagem r
 where r.idregiao(+) = l.idregiao
   and e.identidade(+) = l.iddepositante
   and s.idsetor(+) = l.idsetor
   and l.ativo = 'S'
   and l.tipo < 3
   and l.buffer = 'N'
   and l.idarmazem = a.idarmazem
   and exists
 (select 1
          from lotelocal ll, lote l
         where l.idlote = ll.idlote
           and nvl(l.tipolote, 'L') = 'L'
           and ll.idlocal = l.idlocal
           and ll.idarmazem = l.idarmazem
           and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
               (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0)
 group by a.idarmazem, a.descr, nvl(s.descr, 'SETOR NÃO DEFINIDO')
union
select a.idarmazem, a.descr armazem, 'Vazios' endereco, 1 tipo,
       nvl(s.descr, 'SETOR NÃO DEFINIDO') setor,
       sum(decode(l.idlocal, null, 0, 1)) qtde
  from armazem a, local l, setor s, entidade e, regiaoarmazenagem r
 where r.idregiao(+) = l.idregiao
   and e.identidade(+) = l.iddepositante
   and s.idsetor(+) = l.idsetor
   and l.ativo = 'S'
   and l.tipo < 3
   and l.buffer = 'N'
   and l.idarmazem = a.idarmazem
   and not exists (select 1
          from lotelocal ll, lote l
         where l.idlote = ll.idlote
           and nvl(l.tipolote, 'L') = 'L'
           and ll.idlocal = l.idlocal
           and ll.idarmazem = l.idarmazem
           and (nvl(ll.estoque, 0) + nvl(ll.adicionar, 0)) -
               (nvl(ll.pendencia, 0) + nvl(ll.reservado, 0)) > 0)
 group by a.idarmazem, a.descr, nvl(s.descr, 'SETOR NÃO DEFINIDO')

/

