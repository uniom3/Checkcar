create view VT_ARQERROINTEGRACAO as
select r.idarquivoerro, r.datahoramodificacao data, r.extensao, r.caminho,
       r.idconfiguracaoalerta, r.nomearquivo
  from arquivoErroIntegracao r
/

