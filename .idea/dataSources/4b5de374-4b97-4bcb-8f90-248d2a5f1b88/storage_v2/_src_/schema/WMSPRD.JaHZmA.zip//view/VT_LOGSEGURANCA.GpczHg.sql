create view VT_LOGSEGURANCA (DATAHORA, NOMEUSUARIO, NIVEL, IDOPERACAO, LOG, IDUSUARIO, IDLOG, H$DTHORA, H$TIPOLOG) as
select l.datahora, u.nomeusuario, n.nivel || ' - ' || n.descricao nivel,
       l.id idoperacao, upper(l.log) log, l.idusuario, l.idlog,
       l.datahora h$dtHora, l.tipolog h$tipolog
  from loguser l, usuario u, nivelusuario n
 where u.idusuario = l.idusuario
   and n.nivel = u.nivel
/

