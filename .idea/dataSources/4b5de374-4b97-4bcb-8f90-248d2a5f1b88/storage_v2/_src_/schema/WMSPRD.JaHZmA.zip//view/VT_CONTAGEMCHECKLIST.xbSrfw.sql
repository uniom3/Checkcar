create view VT_CONTAGEMCHECKLIST as
select id.idinventario h$idinventario, id.idinvdet, id.idseq, cl.questao,
       inf.valor resposta, id.idlocal, e.identidade iddepositante, e.identidade h$iddepositante,
       e.razaosocial depositante, pr.codigointerno codprod, pr.descr produto,
       us.nomeusuario, id.idproduto, inf.idchecklistmaterial,
       l.idlocalformatado f$idlocal, l.ordem h$ordem,
       pk_inventario_planejado.identificadorCheckList(id.idinvdet) h$identificadorCheckList
  from invdetchecklistvalor inf, checklistmaterial cl, invdet id, usuario us,
       produto pr, local l, entidade e
 where id.idcorrespondente = inf.idinvdet
   and us.idusuario = id.idusuario
   and cl.idchecklistmaterial = inf.idchecklistmaterial
   and pr.idproduto = id.idproduto
   and id.idlocal = l.idlocal
   and id.idarmazem = l.idarmazem
   and e.identidade = id.identidade
 order by idinvdet, idseq
/

