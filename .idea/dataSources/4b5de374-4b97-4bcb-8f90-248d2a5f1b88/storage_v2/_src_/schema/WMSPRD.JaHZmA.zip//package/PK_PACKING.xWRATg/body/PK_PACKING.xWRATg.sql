create package body PK_PACKING is

  TIPO_CONF_POR_NF            constant number := 0;
  CONFPACKING_AGRUPADA_PEDIDO constant number := 1;
  MULTI_USUARIO_CONF_CHECKOUT constant number := 1;

  C_STATUS_EM_CONTAGEM    constant number := 0;
  C_STATUS_VOLUME_MONTADO constant number := 1;
  C_STATUS_CANCELADO      constant number := 2;

  STATUS_MOV_AGUARDANDO constant number := 0;
  STATUS_MOV_EXECUTANDO constant number := 1;
  STATUS_MOV_FINALIZADO constant number := 2;
  STATUS_MOV_CANCELADO  constant number := 3;
  STATUS_MOV_CONCLUIDO  constant number := 4;

  function gerarVolume
  (
    p_idConfPacking        in number,
    p_idTipoCaixa          in number,
    p_idusuario            in number,
    p_qtdeVolumesAgrupador in number default 0,
    p_idSupervisor         in number default null,
    p_novabarracaixaret    in varchar2 default null,
    p_ptl                  in number default 0
  ) return number is
    row_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(row_locked, -54);
  
    cursor c_movPorTarefa
    (
      pc_idonda        number,
      pc_idpacking     number,
      pc_idnotafiscal  number,
      pc_tarefa        varchar2,
      pc_idproduto     number,
      pc_idconfpacking number,
      p_ltIndustria    lote.descr%type,
      p_dtVencimento   lote.dtvenc%type
    ) is
      select a.id, a.qtde, a.idlote, a.identificador
        from (select m.identificador, m.id,
                      (m.qtdemovimentada - m.qtdeemvolume) qtde, m.idlote,
                      (select count(1)
                          from estoqueinformacaoespecifica
                         where idlote = lt.idlote
                           and idconfpacking = pc_idconfpacking) infespecifica
                 from v_tarefas_onda m, lote lt
                where m.idonda = pc_idonda
                  and m.status = 2
                  and m.idlocaldestino = pc_idpacking
                  and m.idnotafiscal = pc_idnotafiscal
                  and m.qtdeemvolume < m.qtdemovimentada
                  and m.codbarratarefa = pc_tarefa
                  and lt.idlote = m.idlote
                  and (nvl(lt.descr, '-1') =
                      nvl(nvl(p_ltIndustria, lt.descr), '-1') and
                      nvl(lt.dtvenc, sysdate) =
                      nvl(nvl(p_dtVencimento, lt.dtvenc), sysdate))
                  and lt.idproduto = pc_idproduto) a
       order by a.infespecifica desc, a.idlote;
  
    cursor c_movSemTarefa
    (
      pc_idonda        number,
      pc_idpacking     number,
      pc_idnotafiscal  number,
      pc_idproduto     number,
      pc_idconfpacking number,
      p_ltIndustria    lote.descr%type,
      p_dtVencimento   lote.dtvenc%type
    ) is
      select a.id, a.qtde, a.idlote, null identificador
        from (select m.id, (m.qtdemovimentada - m.qtdeemvolume) qtde,
                      m.idlote,
                      (select count(1)
                          from estoqueinformacaoespecifica
                         where idlote = lt.idlote
                           and idconfpacking = pc_idconfpacking) infespecifica
                 from v_tarefas_onda m, lote lt
                where m.idonda = pc_idonda
                  and m.status = 2
                  and m.idlocaldestino = pc_idpacking
                  and m.idnotafiscal = pc_idnotafiscal
                  and m.qtdeemvolume < m.qtdemovimentada
                  and lt.idlote = m.idlote
                  and lt.idproduto = pc_idproduto
                  and (nvl(lt.descr, '-1') =
                      nvl(nvl(p_ltIndustria, lt.descr), '-1') and
                      nvl(lt.dtvenc, sysdate) =
                      nvl(nvl(p_dtVencimento, lt.dtvenc), sysdate))
                  and not exists
                (select c.codbarratarefa
                         from confpacking c, volumeromaneio vr
                        where c.idonda = m.idonda
                          and c.idnotafiscal = m.idnotafiscal
                          and c.codbarratarefa is not null
                          and c.codbarratarefa = m.codbarratarefa
                          and vr.idvolumeromaneio = c.idvolumeromaneio
                          and vr.statusvolume = 0
                          and c.status = C_STATUS_EM_CONTAGEM)) a
       order by a.infespecifica desc, a.idlote;
  
    type t_mov is record(
      id            number,
      qtde          number,
      idlote        number,
      identificador number);
  
    r_mov                       t_mov;
    v_confpacking               confpacking%rowtype;
    v_idvolumeromaneio          number;
    r_movimentacao              movimentacao%rowtype;
    v_localdestino              number;
    v_qtdemovimentada           number;
    v_etapa                     number;
    v_idmovimentacao            number;
    v_idconteudo                number;
    v_qtderestante              number;
    v_qtdeconteudo              number;
    v_qtdeconteudoprod          number;
    v_conteudovolume            number;
    v_qtdetotalvolume           number;
    v_qtdemin                   number;
    v_qtdemax                   number;
    v_erroGeracaoVolume         number;
    v_idTipoCaixa               number;
    v_msg                       t_message;
    v_idConfiguracaoOnda        number;
    v_gerarVolumeSemConteudo    number;
    v_qtdeVolumesGerar          number;
    v_barraVolSemConteudo       varchar2(20);
    v_pesoCaixa                 number;
    v_ondaControlaPeso          number;
    v_depControlaPeso           char(1);
    v_qtdenaoconferida          number;
    v_utilizaZpl                number;
    v_qtdeTarefa                number;
    v_utzPreEtiquetaVol         configuracaoonda.utzpreetiqvolped%type;
    v_modeloEtiquetaVol         configuracaoonda.idetiqvolped%type;
    v_tipoNF                    notafiscal.tiponf%type;
    v_identificadorTarefa       number;
    v_momentoFaturamentoPedido  number;
    v_infonotafiscal            pk_integracao.t_infonotafiscal;
    r_saidapornf                saidapornf%rowtype;
    v_envioautomatico           number;
    v_confirmarloteexpedido     number;
    v_transferenciatitularidade number;
    v_romaneiopai               romaneiopai%rowtype;
    v_utilizaVolumeAgrupador    number;
    v_identificador             number;
    v_pedidoclubecompra         number;
    v_seppkporestacao           number;
  
    c_ondaControlaPeso_desativado constant number := 0;
    c_ondaControlaPeso_nao        constant number := 2;
  
    C_FATURAR_PEDIDO_CONFPESAGEM constant number := 0;
  
    procedure validarConfPacking
    (
      p_confpacking in confpacking%rowtype,
      p_idusuario   in number
    ) is
      v_totalProdutosContados number;
      v_totalProdutoPesavel   number;
      v_permitemultusuario    number;
    begin
    
      begin
        select co.permitirconferirmultiusuario
          into v_permitemultusuario
          from confpacking cp, configuracaoonda co, romaneiopai rp
         where cp.idpacking = p_confpacking.idpacking
           and cp.idonda = p_confpacking.idonda
           and cp.id = p_confpacking.id
           and rp.idromaneio = cp.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and co.conferenciaporcheckoutexpress = 1;
      exception
        when no_data_found then
          v_permitemultusuario := 0;
      end;
    
      if (p_confpacking.idusuario <> p_idusuario and
         v_permitemultusuario < MULTI_USUARIO_CONF_CHECKOUT) then
        v_msg := t_message('Usuario que esta tentando montar o volume não é o mesmo usuario que conferiu os produtos.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_confpacking.status <> 0) then
        v_msg := t_message('Esta conferencia não esta com o status correto para montagem de volumes.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_confpacking.idvolumeromaneio is not null) then
        v_msg := t_message('Esta conferencia já possui volume gerado.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_totalProdutosContados
        from produtoconfpacking p
       where p.idconfpacking = p_confpacking.id
         and p.status = 1;
    
      if (v_totalProdutosContados = 0) then
        v_msg := t_message('Nenhum produto contado no packing para geração do volume.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (p_confpacking.codbarratarefa is null) then
        select count(*)
          into v_totalProdutoPesavel
          from v_produtoconfpacking v
         where v.idnotafiscal = p_confpacking.idnotafiscal
           and v.pesavel > 0;
      
        select count(1)
          into v_totalProdutosContados
          from (select sum(qtdecontada) qtdecontada,
                        sum(qtdeseparada) qtdeseparada,
                        sum(qtdeemvolume) qtdeemvolume
                   from v_produtoconfpacking v
                  where v.idnotafiscal = p_confpacking.idnotafiscal) x
         where x.qtdecontada > (x.qtdeseparada - x.qtdeemvolume);
      
      else
        select count(*)
          into v_totalProdutoPesavel
          from v_tarefaprodutoconfpacking v
         where v.idnotafiscal = p_confpacking.idnotafiscal
           and v.codbarratarefa = p_confpacking.codbarratarefa
           and v.pesavel > 0;
      
        select count(*)
          into v_totalProdutosContados
          from (select v.idonda, v.codbarratarefa, v.idenderecopacking,
                        v.idnotafiscal, v.idproduto, v.codigointerno,
                        v.descricao, v.qtdetotal, v.qtdeseparada,
                        v.qtdecontada, v.qtdeemvolume, v.fracionado, v.pesavel,
                        v.iddepositante
                   from (select pcp.codbarratarefa, pcp.idonda,
                                 pcp.idenderecopacking, pcp.idnotafiscal,
                                 pcp.idproduto, pcp.codigointerno, pcp.descricao,
                                 pcp.fracionado, pcp.pesavel, pcp.iddepositante,
                                 pcp.qtdetotal, pcp.qtdeseparada,
                                 nvl(ct.qtdecontada, 0) qtdecontada,
                                 nvl(vm.qtdeemvolume, 0) qtdeemvolume
                            from (select m.codbarratarefa, m.idonda,
                                          pa.idendereco idenderecopacking,
                                          m.idnotafiscal, lt.idproduto,
                                          p.codigointerno, p.descr descricao,
                                          p.fracionado, p.pesavel,
                                          lt.iddepositante,
                                          sum(m.quantidade) qtdetotal,
                                          sum(decode(m.status, 2, m.quantidade, 0)) qtdeseparada
                                     from v_tarefas_onda m, lote lt, produto p,
                                          packing pa
                                    where m.idlocaldestino = pa.idendereco
                                      and m.status in (0, 1, 2)
                                      and lt.idlote = m.idlote
                                      and p.idproduto = lt.idproduto
                                      and m.idnotafiscal =
                                          p_confpacking.idnotafiscal
                                      and m.idonda = p_confpacking.idonda
                                    group by m.codbarratarefa, m.idonda,
                                             pa.idendereco, m.idnotafiscal,
                                             lt.idproduto, p.codigointerno,
                                             p.descr, p.fracionado, p.pesavel,
                                             lt.iddepositante
                                   having sum(m.quantidade) > 0) pcp,
                                 (select c.codbarratarefa, c.idonda,
                                          c.idnotafiscal, pc.idproduto,
                                          sum(pc.qtde * e.fatorconversao) qtdecontada
                                     from confpacking c, produtoconfpacking pc,
                                          embalagem e
                                    where c.status = C_STATUS_EM_CONTAGEM
                                      and pc.idconfpacking = c.id
                                      and pc.status = 1
                                      and e.idproduto = pc.idproduto
                                      and e.barra = pc.barra
                                      and c.idnotafiscal =
                                          p_confpacking.idnotafiscal
                                      and c.idonda = p_confpacking.idonda
                                    group by c.codbarratarefa, c.idonda,
                                             c.idnotafiscal, pc.idproduto) ct,
                                 (select m.codbarratarefa, m.idonda,
                                          m.idnotafiscal, lt.idproduto,
                                          sum(m.qtdeemvolume) qtdeemvolume
                                     from v_tarefas_onda m, lote lt
                                    where m.status in (0, 1, 2)
                                      and lt.idlote = m.idlote
                                      and m.idnotafiscal =
                                          p_confpacking.idnotafiscal
                                      and m.idonda = p_confpacking.idonda
                                    group by m.codbarratarefa, m.idonda,
                                             m.idnotafiscal, lt.idproduto) vm
                           where nvl(ct.codbarratarefa(+), pcp.codbarratarefa) =
                                 pcp.codbarratarefa
                             and ct.idonda(+) = pcp.idonda
                             and ct.idnotafiscal(+) = pcp.idnotafiscal
                             and ct.idproduto(+) = pcp.idproduto
                             and nvl(vm.codbarratarefa(+), pcp.codbarratarefa) =
                                 pcp.codbarratarefa
                             and vm.idonda(+) = pcp.idonda
                             and vm.idnotafiscal(+) = pcp.idnotafiscal
                             and vm.idproduto(+) = pcp.idproduto) v) v
         where v.idnotafiscal = p_confpacking.idnotafiscal
           and v.codbarratarefa = p_confpacking.codbarratarefa
           and v.qtdecontada > (v.qtdeseparada - v.qtdeemvolume);
      end if;
    
      if (v_totalProdutosContados > 0 and v_totalProdutoPesavel = 0) then
        v_msg := t_message('Produto ainda não foi totalmente separado, favor providenciar que a separação seja concluída.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      for c in (select (case
                          when f.pesavel = 1 then
                           case
                             when f.qtdecontada + f.qtdeemvolume > f.qtdemax then
                              1
                             else
                              0
                           end
                          else
                           case
                             when f.qtdecontada + f.qtdeemvolume > f.qtdetotal then
                              1
                             else
                              0
                           end
                        end) passoudacontagem
                  from (select x.pesavel, sum(x.qtdecontada) qtdecontada,
                                sum(x.qtdeemvolume) qtdeemvolume,
                                sum(x.qtdemax) qtdemax,
                                sum(x.qtdetotal) qtdetotal
                           from (select v.pesavel, v.qtdecontada, v.qtdeemvolume,
                                         v.qtdemax, qtdetotal
                                    from v_produtoconfpacking v, confpacking c
                                   where v.idonda = c.idonda
                                     and v.idenderecopacking = c.idpacking
                                     and v.idnotafiscal = c.idnotafiscal
                                     and c.id = p_idConfPacking
                                     and nvl(v.codbarratarefa, '-1') =
                                         nvl(p_confpacking.codbarratarefa, '-1')
                                  union all
                                  select v.pesavel, v.qtdecontada, v.qtdeemvolume,
                                         v.qtdemax, qtdetotal
                                    from v_produtoconfpackinglotevenci v,
                                         confpacking c
                                   where v.idonda = c.idonda
                                     and v.idenderecopacking = c.idpacking
                                     and v.idnotafiscal = c.idnotafiscal
                                     and c.id = p_idConfPacking
                                     and nvl(p_ptl, 0) = 0
                                     and nvl(v.codbarratarefa, '-1') =
                                         nvl(p_confpacking.codbarratarefa, '-1')) x
                          group by x.pesavel) f)
      loop
        if (c.passoudacontagem = 1) then
          v_msg := t_message('O volume não pode ser gerado pois mais produtos foram contados que a quantidade pedida em notafiscal.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    end validarConfPacking;
  
    procedure regraNaoGerarVolumesSemPesar(p_confpacking in confpacking%rowtype) is
      v_bloqgeracaovolumesempesar number;
      v_totalvolumes              number;
    begin
      select a.bloqgeracaovolumesempesar
        into v_bloqgeracaovolumesempesar
        from armazem a, local l
       where a.idarmazem = l.idarmazem
         and l.id = p_confpacking.idpacking;
    
      if (v_bloqgeracaovolumesempesar = 1) then
        select nvl(count(*), 0)
          into v_totalvolumes
          from volumeromaneio vr
         where vr.idromaneio = p_confpacking.idonda
           and vr.idnotafiscal = p_confpacking.idnotafiscal
           and vr.statusvolume = 0;
      
        if (v_totalvolumes > 0) then
          v_msg := t_message('A configuração do armazém esta definida para não permitir gerar novo volume com volume já gerado sem pesagem liberada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end regraNaoGerarVolumesSemPesar;
  
    -- Refactored procedure validarTipoCaixa 
    procedure validarTipoCaixa
    (
      p_idTipoCaixa in number,
      p_confpacking in confpacking%rowtype
    ) is
      v_tipocaixa      tipocaixavolume%rowtype;
      v_caixavolumepbl number;
    begin
      select *
        into v_tipocaixa
        from tipocaixavolume t
       where t.idtipocaixavolume = p_idTipoCaixa;
    
      if (v_tipocaixa.ativo = 0) then
        v_msg := t_message('A caixa selecionada para gerar o volume não esta ativa.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_tipocaixa.retornavel = 1 and v_gerarVolumeSemConteudo = 1) then
        v_msg := t_message('Não é possível utilizar caixa retornável para onda está configurada para gerar volumes sem conteúdo.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_tipocaixa.tipo = 0 and v_tipocaixa.idproduto is not null and
         v_gerarVolumeSemConteudo = 1) then
        v_msg := t_message('Não é possível utilizar caixa própria que controla estoque para onda está configurada para gerar volumes sem conteúdo.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_tipocaixa.retornavel = 1 and v_tipocaixa.disponivel = 0 and
         nvl(v_tipocaixa.idonda, 0) = 0) then
      
        select count(*)
          into v_caixavolumepbl
          from tarefacaixavolume tcv
         where tcv.idonda = p_confpacking.idonda
           and tcv.tarefa = p_confpacking.codbarratarefa
           and tcv.idtipocaixavolume = v_tipocaixa.idtipocaixavolume;
      
        if (v_caixavolumepbl = 0) then
          v_msg := t_message('A caixa retornável selecionada para gerar o volume não esta disponível.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      --Indica o tipo da caixa onde: 0 - Propria, 1 - Retornavel, 2 - Pacote e 3 - Reutilizavel
      if (v_tipocaixa.tipo = 2) then
        if (p_confpacking.alturacaixa is null) then
          v_msg := t_message('A caixa selecionada do tipo pacote exige que a altura seja informada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
        if (p_confpacking.larguracaixa is null) then
          v_msg := t_message('A caixa selecionada do tipo pacote exige que a largura seja informada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
        if (p_confpacking.comprimentocaixa is null) then
          v_msg := t_message('A caixa selecionada do tipo pacote exige que a comprimento seja informada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if (v_tipocaixa.tipo = 3) then
        if (p_confpacking.barracaixareutilizavel is null or
           p_confpacking.idprodutocxreutilizavel is null) then
          v_msg := t_message('A caixa selecionada do tipo reutilizável exige que uma embalagem seja informada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (p_confpacking.alturacaixa is null or
           p_confpacking.larguracaixa is null or
           p_confpacking.comprimentocaixa is null) then
          v_msg := t_message('As dimensções da caixa selecionada do tipo reutilizável não foram informadas.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validarTipoCaixa;
  
    procedure addConteudoVolume
    (
      p_idvolumeromaneio in number,
      p_idconteudo       in out number,
      p_qtderestante     in out number,
      r_mov              t_mov
    ) is
      v_qtdeemvolume  number;
      v_idselecionado number;
    begin
      select nvl(count(*), 0)
        into v_idselecionado
        from gtt_selecao
       where idselecionado = r_mov.id;
    
      if (v_idselecionado = 0) then
        insert into gtt_selecao
          (idselecionado)
        values
          (r_mov.id);
      end if;
    
      -- calcula a qtde correta para a geração do conteudo do volume 
      if (r_mov.qtde > p_qtderestante) then
        v_qtdeemvolume := p_qtderestante;
      else
        v_qtdeemvolume := r_mov.qtde;
      end if;
    
      p_qtderestante := p_qtderestante - v_qtdeemvolume;
    
      -- atualiza a qtde em volume da movimentacao
      update movimentacao m
         set m.qtdeemvolume = round(m.qtdeemvolume + v_qtdeemvolume, 6)
       where m.id = r_mov.id;
    
      -- grava conteudo do volume
      begin
        select cv.id
          into p_idconteudo
          from conteudovolume cv
         where cv.idvolumeromaneio = p_idvolumeromaneio
           and cv.idlote = r_mov.idlote
           and cv.idmovimentacao = r_mov.id;
      exception
        when no_data_found then
          p_idconteudo := 0;
      end;
    
      if (p_idconteudo = 0) then
        select seq_conteudovolume.nextval
          into p_idconteudo
          from dual;
      
        insert into conteudovolume
          (id, quantidade, idlote, idvolumeromaneio, quantidadefracionada,
           idmovimentacao)
        values
          (p_idconteudo, v_qtdeemvolume, r_mov.idlote, p_idvolumeromaneio,
           0, r_mov.id);
      else
        update conteudovolume cv
           set cv.quantidade           = cv.quantidade + v_qtdeemvolume,
               cv.quantidadefracionada = cv.quantidadefracionada + 0
         where cv.id = p_idconteudo;
      end if;
    end addConteudoVolume;
  
    procedure associarEstoqueInfoEspecifica
    (
      v_idvolumeromaneio in number,
      v_idConfPacking    in number
    ) is
    begin
      update estoqueinformacaoespecifica ei
         set ei.idvolumeromaneio = v_idvolumeromaneio,
             ei.nrooperacao      = v_idvolumeromaneio,
             ei.operacao         = 'MONTAGEM VOLUME PACKING'
       where ei.idconfpacking = v_idConfPacking;
    end associarEstoqueInfoEspecifica;
  
    procedure volumeCaixaFechada is
      v_montvolautocxfchdapack      number;
      v_gerarvolumesemconteudo      number;
      v_solicitaqtdecaixapacking    number;
      v_gerarvolumesautomaticamente number;
    
    begin
      select co.montvolautocxfchdapack, co.gerarvolumesemconteudo,
             d.solicitaqtdecaixapacking, d.gerarvolumesautomaticamente
        into v_montvolautocxfchdapack, v_gerarvolumesemconteudo,
             v_solicitaqtdecaixapacking, v_gerarvolumesautomaticamente
        from confpacking c, romaneiopai o, configuracaoonda co,
             notafiscal nf, depositante d
       where id = p_idConfPacking
         and o.idromaneio = c.idonda
         and co.idconfiguracaoonda = o.idconfiguracaoonda
         and nf.idnotafiscal = c.idnotafiscal
         and d.identidade = nf.iddepositante;
    
      v_idTipoCaixa := p_idTipoCaixa;
      if ((v_montvolautocxfchdapack = 1 and
         (v_idTipoCaixa is null or v_idTipoCaixa = 0) AND
         v_gerarvolumesemconteudo = 0) or
         (v_gerarvolumesautomaticamente = 1 and
         (v_idTipoCaixa is null or v_idTipoCaixa = 0))) then
        begin
          select idtipocaixavolume
            into v_idTipoCaixa
            from tipocaixavolume
           where tipo = 3
             and rownum = 1;
        
        exception
          when no_data_found then
            v_msg := t_message('Para gerar um volume de caixa fechada/Quantidade de volume informada é necessário possuir um tipo de caixa retornável cadastrado.');
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      elsif ((v_idTipoCaixa is null or v_idTipoCaixa = 0) AND
            v_gerarvolumesemconteudo = 1) then
        begin
          select t.idtipocaixavolume
            into v_idTipoCaixa
            from tipocaixavolume t
           where t.ativo = 1;
        exception
          when no_data_found then
            v_msg := t_message('Para gerar um volume de caixa fechada é necessário possuir um tipo de caixa de volume ativa.');
            raise_application_error(-20000, v_msg.formatMessage);
          
          when too_many_rows then
            v_msg := t_message('Não foi possível gerar o volume, existe mais de 1 caixa de volume ativa e a configuração de onda está marcada para Gerar Volume sem Conteúdo.');
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      end if;
    end volumeCaixaFechada;
  
    procedure controlaQtdeVolumesNotafiscal is
      v_qtdeVolumesCalculado number;
      v_novaQtdeVolumes      number;
      v_qtdeVolumesNF        number;
      v_qtdeVolumesGerados   number;
    begin
      begin
        select nvl(n.qtdeVolumesCalculado, 0), nvl(n.novaQtdeVolumes, 0)
          into v_qtdeVolumesCalculado, v_novaQtdeVolumes
          from confpacking c, romaneiopai o, nfromaneio n, notafiscal nt,
               configuracaoonda co
         where c.id = p_idConfPacking
           and o.idromaneio = c.idonda
           and n.idnotafiscal = c.idnotafiscal
           and n.idromaneio = o.idromaneio
           and co.idconfiguracaoonda = o.idconfiguracaoonda
           and nt.idnotafiscal = n.idnotafiscal
           and co.calcularnumerovolumes > 0
           and co.usoexclusivokitsestojamento = 0;
      exception
        when no_data_found then
          return;
      end;
    
      select count(idvolumeromaneio)
        into v_qtdeVolumesGerados
        from volumeromaneio v
       where v.idnotafiscal = v_confpacking.idnotafiscal
         and v.idromaneio = v_confpacking.idonda
         and v.statusvolume = 0;
    
      v_qtdeVolumesNF := v_qtdeVolumesCalculado;
      if (v_novaQtdeVolumes > 0) then
        v_qtdeVolumesNF := v_novaQtdeVolumes;
      end if;
    
      update notafiscal n
         set n.qtdevolumescontrolado = nvl(v_qtdeVolumesNF,
                                           v_qtdeVolumesGerados)
       where n.idnotafiscal = v_confpacking.idnotafiscal;
    end;
  
    procedure controlaGeracaoUltimoVolumeNf is
      v_qtdevolumescontrolado number;
      v_qtdeRestante          number;
      v_qtdeVolumes           number;
    begin
      begin
        select nvl(nt.qtdevolumescontrolado, 0)
          into v_qtdevolumescontrolado
          from confpacking c, romaneiopai o, nfromaneio n, notafiscal nt,
               configuracaoonda co
         where c.id = p_idConfPacking
           and o.idromaneio = c.idonda
           and n.idnotafiscal = c.idnotafiscal
           and n.idromaneio = o.idromaneio
           and co.idconfiguracaoonda = o.idconfiguracaoonda
           and nt.idnotafiscal = n.idnotafiscal
           and co.calcularnumerovolumes > 0
           and co.usoexclusivokitsestojamento = 0
           and co.exclusivopicktolight = 0;
      exception
        when no_data_found then
          return;
      end;
    
      select nvl(sum(qtdemovimentada), 0)
        into v_qtdeRestante
        from movimentacao m
       where m.idnotafiscal = v_confpacking.idnotafiscal
         and m.idonda = v_confpacking.idonda
         and m.qtdemovimentada - m.qtdeemvolume > 0
         and m.idvolumeromaneio is null;
    
      if (v_qtdeRestante > 0) then
        return;
      end if;
    
      select count(idvolumeromaneio)
        into v_qtdeVolumes
        from volumeromaneio v
       where v.idnotafiscal = v_confpacking.idnotafiscal
         and v.idromaneio = v_confpacking.idonda
         and v.statusvolume = 0;
    
      if (v_qtdeVolumes <> v_qtdevolumescontrolado) then
        v_msg := t_message('A quantidade de volumes montada no packing não é a mesma quantidade definida para montagem.' ||
                           chr(13) || 'Foram montados {0}' ||
                           ' volume(s) e definido(s) {1} volume(s).' ||
                           chr(13) || 'idNotaFiscal: {2}' || chr(13) ||
                           'idConfPacking: {3}' || chr(13) || 'idOnda: {4}');
        v_msg.addParam(v_qtdeVolumes);
        v_msg.addParam(v_qtdevolumescontrolado);
        v_msg.addParam(v_confpacking.idnotafiscal);
        v_msg.addParam(p_idConfPacking);
        v_msg.addParam(v_confpacking.idonda);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure validarUsoEtiquetaExterna(p_confpacking in confpacking%rowtype) is
    
      v_utilizaZpl        number;
      v_etiquetaImportada number;
      v_codigoRastreio    notafiscal.codigorastreio%type;
      v_idDepositante     notafiscal.iddepositante%type;
      v_idArmazem         notafiscal.idarmazem%type;
    
    begin
      select nf.utilizazpl, nf.codigorastreio, nf.iddepositante,
             nf.idarmazem
        into v_utilizaZpl, v_codigoRastreio, v_idDepositante, v_idArmazem
        from notafiscal nf
       where nf.idnotafiscal = p_confpacking.idnotafiscal;
    
      if (v_utilizaZpl > 0) then
      
        begin
          select count(1)
            into v_etiquetaImportada
            from arquivo_zpl z
           where upper(z.identificadorzpl) = upper(v_codigoRastreio)
             and z.iddepositante = v_idDepositante
             and z.idarmazem = v_idArmazem
             and dbms_lob.getlength(z.zpl) > 0;
        exception
          when no_data_found then
            v_etiquetaImportada := 0;
        end;
      
        if (v_etiquetaImportada = 0) then
          v_msg := t_message('Volume não pode ser gerado pois o fluxo obriga o uso de Etiqueta ZPL e a mesma ainda não foi importada.');
          v_msg.addParam(v_confpacking.idonda);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validarUsoEtiquetaExterna;
  
    procedure controlaVolumeSemConteudo is
      v_idVolumeSemConteudo number;
    begin
      if (v_gerarVolumeSemConteudo = 0) then
        return;
      end if;
    
      v_qtdeVolumesGerar := v_qtdeVolumesGerar - 1;
    
      if (v_qtdeVolumesGerar > 0) then
      
        select vr.pesocaixa
          into v_pesoCaixa
          from volumeromaneio vr
         where vr.idvolumeromaneio = v_idvolumeromaneio;
      
        for i in 1 .. v_qtdeVolumesGerar
        loop
          v_idVolumeSemConteudo := pk_onda.criarVolume(v_confpacking.idnotafiscal,
                                                       v_confpacking.idonda,
                                                       p_idusuario,
                                                       v_idTipoCaixa);
          if v_idVolumeSemConteudo is not null then
            v_qtdeVolumesGerar := v_qtdeVolumesGerar - 1;
          
            update volumeromaneio vr
               set vr.pesocaixa = v_pesoCaixa
             where vr.idvolumeromaneio = v_idVolumeSemConteudo
               and vr.statusvolume = 0;
          
            if (v_ondaControlaPeso = c_ondaControlaPeso_desativado and
               v_depControlaPeso = 'N')
               or (v_ondaControlaPeso = c_ondaControlaPeso_nao) then
            
              update volumeromaneio vr
                 set vr.pesagemliberada = 1,
                     vr.pesoteorico     = 0,
                     vr.peso            = 0,
                     datapesagem        = sysdate,
                     idusuariopesagem   = p_idusuario
               where vr.idvolumeromaneio = v_idVolumeSemConteudo
                 and vr.statusvolume = 0;
            
              select vr.codbarra
                into v_barraVolSemConteudo
                from volumeromaneio vr
               where vr.idvolumeromaneio = v_idVolumeSemConteudo;
            
              pk_utilities.GeraLog(p_idusuario,
                                   'Pesou o volume Cod. Barra: ' ||
                                    v_barraVolSemConteudo,
                                   v_barraVolSemConteudo, 'VL');
            end if;
          end if;
        end loop;
      end if;
    
      v_momentoFaturamentoPedido := pk_packing.getMomentoFaturamentoPedido(v_confpacking.idonda,
                                                                           v_confpacking.idnotafiscal);
    
      if (v_envioautomatico > 0 and v_transferenciatitularidade = 0) then
        select rp.*
          into v_romaneiopai
          from romaneiopai rp
         where 1 = 1
           and rp.idromaneio = v_confpacking.idonda;
      
        select s.*
          into r_saidapornf
          from saidapornf s
         where 1 = 1
           and s.idnotafiscal = v_confpacking.idnotafiscal
           and s.idonda = v_confpacking.idonda;
      
        v_infonotafiscal.idnotafiscal := r_saidapornf.idnotafiscal;
        v_infonotafiscal.separado     := r_saidapornf.separado;
        v_infonotafiscal.pesado       := r_saidapornf.pesado;
      
        if (v_momentofaturamentopedido = C_FATURAR_PEDIDO_CONFPESAGEM) then
          pk_integracao.expFaturamentoPedido(v_confpacking.idnotafiscal,
                                             v_confpacking.idonda,
                                             v_infonotafiscal, null, null,
                                             v_romaneiopai,
                                             r_saidapornf.pesado);
        end if;
      end if;
    end controlaVolumeSemConteudo;
  
    procedure controlaVolumeAgrupador is
      v_crossdocking     number;
      v_localIntegracao  number;
      v_numnf            number;
      v_serienf          varchar2(20);
      v_cliente          varchar2(3);
      v_utzServicoTransp number;
      v_idservicotransp  number;
    
      procedure criarVolumeSemConteudo is
      
        v_idvolume                number;
        v_numerovolume            number;
        v_codbarra                varchar2(255);
        v_idCodRastreabilidade    number;
        v_idvolumeromaneioSemCont number;
        v_codbarratipo            varchar2(255);
        v_msg                     t_message;
      
      begin
      
        begin
          select max(vr.idvolume)
            into v_idvolume
            from volumeromaneio vr
           where vr.idromaneio = v_confpacking.idonda;
        exception
          when no_data_found then
            v_idvolume := 0;
        end;
      
        v_idvolume := nvl(v_idvolume, 0) + 1;
      
        select min(vr.numero)
          into v_numerovolume
          from volumeromaneio vr
         where vr.idromaneio = v_confpacking.idonda
           and to_number(substr(vr.codbarra, 4, 7)) =
               v_confpacking.idnotafiscal
           and vr.statusvolume = 1
           and not exists
         (select 1
                  from volumeromaneio v
                 where v.idromaneio = vr.idromaneio
                   and v.idnotafiscal = to_number(substr(vr.codbarra, 4, 7))
                   and v.numero = vr.numero
                   and v.statusvolume = 0);
      
        if v_numerovolume is null then
          select nvl(max(vr.numero), 0) + 1
            into v_numerovolume
            from volumeromaneio vr
           where statusvolume = 0
             and vr.idromaneio = v_confpacking.idonda
             and vr.idnotafiscal = v_confpacking.idnotafiscal;
        end if;
      
        if (v_numerovolume > 9999) then
          v_msg := t_message('O MAXIMO DE VOLUMES POR NOTA FISCAL É 9999.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select seq_volumeromaneio.nextval
          into v_idvolumeromaneioSemCont
          from dual;
      
        v_codbarra := lpad(v_localIntegracao, 3, '0') ||
                      lpad(substr(v_confpacking.idnotafiscal, 0, 7), 7, '0') ||
                      lpad(v_numerovolume, 4, '0');
      
        v_codbarratipo := 1 || lpad(v_cliente, 3, '0') ||
                          lpad(v_serienf, 2, '0') || lpad(v_numnf, 6, '0') ||
                          lpad(v_numerovolume, 4, '0');
      
        if (v_utzServicoTransp > 0) then
          v_idCodRastreabilidade := pk_expedicao.getCodRastreioVolume(v_confpacking.idnotafiscal);
        end if;
      
        insert into volumeromaneio
          (idvolumeromaneio, idromaneio, idnotafiscal, idvolume, codbarra,
           data, numero, idusuario, idtipocaixavolume, codbarratipo,
           idcodrasttransdep, idvolumeagrupador, pesagemliberada,
           pesoteorico, peso, datapesagem, idusuariopesagem)
        values
          (v_idvolumeromaneioSemCont, v_confpacking.idonda,
           v_confpacking.idnotafiscal, v_idvolume, v_codbarra, sysdate,
           v_numerovolume, p_idusuario, p_idTipoCaixa, v_codbarratipo,
           v_idCodRastreabilidade, v_idvolumeromaneio, 1, 0, 0, sysdate,
           p_idusuario);
      
        v_barraVolSemConteudo := v_codbarra;
      
        pk_utilities.GeraLog(p_idusuario,
                             'Pesou o volume Cod. Barra: ' ||
                              v_barraVolSemConteudo, v_barraVolSemConteudo,
                             'VL');
      
        v_qtdeVolumesGerar := v_qtdeVolumesGerar - 1;
      
      end criarVolumeSemConteudo;
    
    begin
      if (v_utilizaVolumeAgrupador = 0) then
        return;
      end if;
    
      if (p_qtdeVolumesAgrupador is null or p_qtdeVolumesAgrupador <= 0) then
        v_msg := t_message('Não é possível gerar volume. A quantidade de volumes agrupados informado deve ser maior que zero, pois, a onda está configurada para utilizar volume agrupador.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_qtdeVolumesGerar := p_qtdeVolumesAgrupador - 1;
    
      if (v_qtdeVolumesGerar > 0) then
      
        if (v_crossdocking = 1) then
          v_localIntegracao := 0;
        else
          begin
            select l.localintegracao
              into v_localIntegracao
              from destinosaidaonda d, local l
             where d.idonda = v_confpacking.idonda
               and ((d.identidade =
                   (select decode(a.agruparvolumesruaexpedicao, 1,
                                     nf.iddepositante,
                                     nf.transportadoranotafiscal)
                        from notafiscal nf, armazem a
                       where nf.idnotafiscal = v_confpacking.idnotafiscal
                         and a.idarmazem = nf.idarmazem)) or
                   (d.identidade is null and v_pedidoclubecompra = 1))
               and l.id = d.iddoca;
          exception
            when no_data_found then
              v_msg := t_message('Local de integracao nao encontrado para a onda ' ||
                                 '{0} da nota fiscal {1}.');
              v_msg.addParam(v_confpacking.idonda);
              v_msg.addParam(v_confpacking.idnotafiscal);
              raise_application_error(-20002, v_msg.formatMessage);
            when too_many_rows then
              v_msg := t_message('Mais de um local de integracao encontado para a onda ' ||
                                 '{0} da nota fiscal {1}.');
              v_msg.addParam(v_confpacking.idonda);
              v_msg.addParam(v_confpacking.idnotafiscal);
              raise_application_error(-20002, v_msg.formatMessage);
          end;
        end if;
      
        select nf.codigointerno, nvl(nf.sequencia, '00'),
               nvl(en.codigosorter, '000') cliente,
               nf.idservicotransportadora
          into v_numnf, v_serienf, v_cliente, v_idservicotransp
          from notafiscal nf, entidade en
         where nf.idnotafiscal = v_confpacking.idnotafiscal
           and en.identidade = nf.REMETENTE;
      
        select count(st.idservicotransportadora)
          into v_utzServicoTransp
          from servicotransportadora st
         where st.idservicotransportadora = v_idservicotransp
           and st.utilizacodrastr = 1;
      
        for i in 1 .. v_qtdeVolumesGerar
        loop
          criarVolumeSemConteudo;
        end loop;
      
      end if;
    end controlaVolumeAgrupador;
  
    procedure validarGerVolParcialSepEst(p_confpacking in confpacking%rowtype) is
      v_qtdeRest number;
    begin
      --valida se o está sendo gerado volume parcial e é expedição por estação
      --nesse caso é obrigatório informar uma nova caixa retornavel
      if v_seppkporestacao = 0 then
        return;
      end if;
    
      v_qtdeRest := isConteudoRestanteCxSeparacao(p_confpacking.idpacking,
                                                  p_confpacking.id,
                                                  p_confpacking.idonda,
                                                  p_confpacking.idnotafiscal,
                                                  p_confpacking.codbarratarefa);
    
      if v_qtdeRest > 0
         and p_novaBarraCaixaRet is null then
        v_msg := t_message('É obrigatório informadar uma nova caixa de volume para a continuação da conferência' ||
                           ' quando a tarefa é conferida parcialmente e a onda utiliza separação por estação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarGerVolParcialSepEst;
  
    procedure utilizarNovaCaixaRetornavel(p_idconfpacking in confpacking%rowtype) is
      r_tipoCaixaVolume tipocaixavolume%rowtype;
    
    begin
      validarCaixaSelecionada(p_novaBarraCaixaRet, r_tipoCaixaVolume);
    
      insert into tarefacaixavolume
        (id, idonda, tarefa, idtipocaixavolume)
      values
        (seq_tarefacaixavolume.nextval, p_idconfpacking.idonda,
         p_idconfpacking.codbarratarefa, r_tipoCaixaVolume.idtipocaixavolume);
    
      update tipocaixavolume
         set disponivel = 0,
             idonda     = p_idconfpacking.idonda
       where idtipocaixavolume = r_tipoCaixaVolume.idtipocaixavolume;
    
      pk_utilities.GeraLog(p_idUsuario,
                           'Caixa de Volume Barra: ' || p_novaBarraCaixaRet ||
                            ' vinculada a Tarefa de Separação: ' ||
                            p_idconfpacking.codbarratarefa || '. IdOnda: ' ||
                            p_idconfpacking.idonda, p_idconfpacking.idonda,
                           'SO');
    end utilizarNovaCaixaRetornavel;
  
  begin
    begin
      select *
        into v_confpacking
        from confpacking cp
       where cp.id = p_idConfPacking
         and cp.status = C_STATUS_EM_CONTAGEM
         for update nowait;
    exception
      when row_locked then
        v_msg := t_message('Já existe um volume sendo gerado para este packing. Favor tentar novamente a operação.');
        raise_application_error(-20000, v_msg.formatMessage);
      when no_data_found then
        v_msg := t_message('Conferência do packing não encontrada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    -- Obtendo lock devido a problemas de deadlock
    select rp.idromaneio, rp.idconfiguracaoonda
      into v_confpacking.idonda, v_idConfiguracaoOnda
      from romaneiopai rp
     where rp.idromaneio = v_confpacking.idonda
       for update;
  
    select co.gerarvolumesemconteudo, co.controlapeso, co.utzpreetiqvolped,
           co.idetiqvolped, co.utilizavolumeagrupador,
           nvl(co.pedidoclubecompra, 0), co.seppkporestacao
      into v_gerarVolumeSemConteudo, v_ondaControlaPeso, v_utzPreEtiquetaVol,
           v_modeloEtiquetaVol, v_utilizaVolumeAgrupador,
           v_pedidoclubecompra, v_seppkporestacao
      from configuracaoonda co
     where co.idconfiguracaoonda = v_idConfiguracaoOnda;
  
    select nf.quantidade, d.controlapeso, nf.utilizazpl, nf.tiponf,
           d.faturamentoautomoatico, d.confirmarloteexpedido,
           nvl(c.transferenciatitularidade, 0)
      into v_qtdeVolumesGerar, v_depControlaPeso, v_utilizaZpl, v_tipoNF,
           v_envioautomatico, v_confirmarloteexpedido,
           v_transferenciatitularidade
      from notafiscal nf, depositante d, classificacaotipopedido c
     where nf.idnotafiscal = v_confpacking.idnotafiscal
       and nf.iddepositante = d.identidade
       and c.idtipopedido(+) = nf.idtipopedido;
  
    if (v_gerarVolumeSemConteudo > 0 or v_utilizaZpl > 0) then
      select sum(case
                    when v.qtdetotal - v.qtdeemvolume - v.qtdecontada < 0 then
                     0
                    else
                     v.qtdetotal - v.qtdeemvolume - v.qtdecontada
                  end) qtdeRestante
        into v_qtdenaoconferida
        from v_produtoconfpacking v
       where v.idonda = v_confpacking.idonda
         and v.idnotafiscal = v_confpacking.idnotafiscal;
    
      if (v_qtdenaoconferida > 0) then
        if (v_utilizaZpl > 0) then
          v_msg := t_message('Não é possível gerar volume sem que a conferência do total do pedido tenha sido finalizada, pois o pedido está configurado para utilizar etiqueta externa.');
          raise_application_error(-20000, v_msg.formatMessage);
        else
          v_msg := t_message('Não é possível gerar volume sem que a conferência do total do pedido tenha sido finalizada, pois a onda está configurada para gerar volumes sem conteúdo.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if (v_utilizaZpl > 0) then
        select count(distinct v.codbarratarefa) qtdetarefa
          into v_qtdeTarefa
          from v_tarefas_onda v
         where v.idonda = v_confpacking.idonda
           and v.idnotafiscal = v_confpacking.idnotafiscal
           and v.idlote is not null
           and v.status in (0, 1, 2);
      
        if (v_qtdeTarefa > 1) then
          v_msg := t_message('Não é possível gerar volume quando existir mais de uma tarefa para o pedido, pois o mesmo está configurado para utilizar etiqueta externa.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end if;
  
    volumeCaixaFechada;
    validarConfPacking(v_confpacking, p_idusuario);
    regraNaoGerarVolumesSemPesar(v_confpacking);
    validarTipoCaixa(v_idTipoCaixa, v_confpacking);
    validarUsoEtiquetaExterna(v_confpacking);
    validarGerVolParcialSepEst(v_confpacking);
  
    pk_ordemseparacao.validaPedFatOrdemSep(v_confpacking.idnotafiscal,
                                           pk_ordemseparacao.C_OF_BLOQUEIA_GERACAOVOLUME);
  
    v_idvolumeromaneio := pk_onda.criarVolume(v_confpacking.idnotafiscal,
                                              v_confpacking.idonda,
                                              p_idusuario, v_idTipoCaixa);
  
    pk_onda.utilizarCaixaVolume(v_confpacking.idpacking, v_idvolumeromaneio,
                                v_idTipoCaixa, v_confpacking.idusuario, 'S');
  
    pk_armazem.utilizarCaixaRetornavel(v_idTipoCaixa, v_idvolumeromaneio);
  
    delete from gtt_selecao;
  
    for c in (select p.idproduto, sum(p.qtde * e.fatorconversao) qtde,
                     pd.pesavel, p.valor, p.loteindustria, p.vencimento
                from produtoconfpacking p, embalagem e, produto pd
               where p.idconfpacking = v_confpacking.id
                 and p.status = 1
                 and e.idproduto = p.idproduto
                 and e.barra = p.barra
                 and pd.idproduto = p.idproduto
               group by p.idproduto, pd.pesavel, p.valor, p.loteindustria,
                        p.vencimento
               order by p.loteindustria asc nulls last)
    loop
      -- calcula a qtde total no conteudo
      select sum(cv.quantidadefracionada)
        into v_qtdeconteudoprod
        from conteudovolume cv, lote l
       where l.idlote = cv.idlote
         and l.idproduto = c.idproduto
         and cv.idvolumeromaneio = v_idvolumeromaneio;
    
      if (c.pesavel = 1) then
        if (v_confpacking.codbarratarefa is null) then
          select sum(v.qtdeemvolume) + c.qtde + nvl(v_qtdeconteudoprod, 0),
                 sum(v.qtdemin), sum(v.qtdemax),
                 sum(v.qtdetotal) - sum(v.qtdeemvolume)
            into v_qtdetotalvolume, v_qtdemin, v_qtdemax, v_qtderestante
            from v_produtoconfpacking v
           where v.idnotafiscal = v_confpacking.idnotafiscal
             and v.idonda = v_confpacking.idonda
             and v.idproduto = c.idproduto;
        else
          select sum(v.qtdeemvolume) + c.qtde + nvl(v_qtdeconteudoprod, 0),
                 sum(v.qtdemin), sum(v.qtdemax),
                 sum(v.qtdetotal) - sum(v.qtdeemvolume)
            into v_qtdetotalvolume, v_qtdemin, v_qtdemax, v_qtderestante
            from v_tarefaprodutoconfpacking v
           where v.idnotafiscal = v_confpacking.idnotafiscal
             and v.idonda = v_confpacking.idonda
             and v.idproduto = c.idproduto
             and v.codbarratarefa = v_confpacking.codbarratarefa;
        end if;
      
        if not (v_qtdetotalvolume >= v_qtdemin and
            v_qtdetotalvolume <= v_qtdemax) then
          v_qtderestante := c.qtde;
        end if;
      else
        v_qtderestante := c.qtde;
      end if;
    
      -- para cada produto contado o sistema procura pelas movimenta??es
      -- para descobrir qual lote deve criar para o conteudo do volume
      -- e associar as movimentações nos grupos corretos
      if (v_confpacking.codbarratarefa is not null) then
        open c_movPorTarefa(v_confpacking.idonda, v_confpacking.idpacking,
                            v_confpacking.idnotafiscal,
                            v_confpacking.codbarratarefa, c.idproduto,
                            p_idConfPacking, c.loteindustria, c.vencimento);
      
        fetch c_movPorTarefa
          into r_mov;
      
        while (c_movPorTarefa%found)
        loop
        
          if (v_identificadorTarefa is null and
             r_mov.identificador is not null) then
            v_identificadorTarefa := r_mov.identificador;
          end if;
        
          if (v_identificadorTarefa <> r_mov.identificador) then
            v_identificadorTarefa := -1;
          end if;
        
          addConteudoVolume(v_idvolumeromaneio, v_idconteudo,
                            v_qtderestante, r_mov);
        
          exit when v_qtderestante = 0;
        
          fetch c_movPorTarefa
            into r_mov;
        end loop;
      
        close c_movPorTarefa;
      else
        open c_movSemTarefa(v_confpacking.idonda, v_confpacking.idpacking,
                            v_confpacking.idnotafiscal, c.idproduto,
                            p_idConfPacking, c.loteindustria, c.vencimento);
      
        fetch c_movSemTarefa
          into r_mov;
      
        while (c_movSemTarefa%found)
        loop
          addConteudoVolume(v_idvolumeromaneio, v_idconteudo,
                            v_qtderestante, r_mov);
        
          exit when v_qtderestante = 0;
        
          fetch c_movSemTarefa
            into r_mov;
        end loop;
      
        close c_movSemTarefa;
      end if;
    
      update conteudovolume cv
         set cv.quantidadefracionada = cv.quantidadefracionada + c.qtde
       where cv.id = v_idconteudo;
    
      pk_onda.associarCartPresenteContVol(v_confpacking.idnotafiscal,
                                          c.idproduto, v_idconteudo);
      pk_onda.associarEmbPresenteContVol(v_confpacking.idnotafiscal,
                                         c.idproduto, v_idconteudo);
    
      pk_ordemseparacao.associaCustOrderItemInfContVol(v_confpacking.idnotafiscal,
                                                       c.idproduto,
                                                       v_idconteudo);
    
      select count(1)
        into v_conteudovolume
        from conteudovolume cv, lote lt
       where cv.idvolumeromaneio = v_idvolumeromaneio
         and lt.idlote = cv.idlote
         and lt.idproduto = c.idproduto;
    
      if (v_conteudovolume = 0) then
        v_msg := t_message('Problema ao gerar volume: nao foi encontrada movimentação para o produto com id {0}.');
        v_msg.addParam(c.idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end loop;
  
    -- busca destino para criar a nova movimentacao de volume
    select d.iddoca
      into v_localdestino
      from destinosaidaonda d
     where d.idonda = v_confpacking.idonda
       and d.identidade =
           (select decode(a.agruparvolumesruaexpedicao, 1, nf.iddepositante,
                           nf.transportadoranotafiscal)
              from notafiscal nf, armazem a
             where nf.idnotafiscal = v_confpacking.idnotafiscal
               and a.idarmazem = nf.idarmazem);
  
    -- calcula a qtde total no conteudo
    select sum(c.quantidadefracionada)
      into v_qtdeconteudo
      from conteudovolume c
     where c.idvolumeromaneio = v_idvolumeromaneio;
  
    -- calcula a qtde total conferida
    select sum(p.qtde * e.fatorconversao)
      into v_qtdemovimentada
      from produtoconfpacking p, embalagem e
     where p.idconfpacking = v_confpacking.id
       and p.status = 1
       and e.idproduto = p.idproduto
       and e.barra = p.barra;
  
    if (v_qtdemovimentada <> v_qtdeconteudo) then
      v_msg := t_message('Quantidade conferida no packing é diferente da quantidade a ser gerada em volume.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select sum(c.quantidade)
      into v_qtdemovimentada
      from conteudovolume c
     where c.idvolumeromaneio = v_idvolumeromaneio;
  
    -- finaliza a conferencia do packing para este volume
    update confpacking cp
       set cp.idvolumeromaneio = v_idvolumeromaneio,
           cp.status           = C_STATUS_VOLUME_MONTADO
     where cp.id = v_confpacking.id;
  
    select decode(cp.codbarratarefa, null, 0,
                   to_number(substr(cp.codbarratarefa,
                                     length(cp.codbarratarefa) - 3,
                                     length(cp.codbarratarefa))))
      into v_identificador
      from confpacking cp
     where cp.id = v_confpacking.id;
  
    -- seleciona a ultima etapa para a nova movimentacao
    select max(m.etapa + 1)
      into v_etapa
      from movimentacao m
     where m.idonda = v_confpacking.idonda;
  
    -- controla agrupamento de volumes
    controlaVolumeAgrupador;
  
    -- Verifica controle de volumes antes de gerar o retorno carregando corretamente Volume COntrolado 
    controlaQtdeVolumesNotafiscal;
  
    -- configura os valores para a nova movimentação
    r_movimentacao.idlocalorigem    := v_confpacking.idpacking;
    r_movimentacao.idlocaldestino   := v_localdestino;
    r_movimentacao.idlote           := null;
    r_movimentacao.idvolumeromaneio := v_idvolumeromaneio;
    r_movimentacao.qtdemovimentada  := v_qtdemovimentada;
    r_movimentacao.quantidade       := v_qtdemovimentada;
    r_movimentacao.etapa            := v_etapa;
    r_movimentacao.identificador    := v_identificador;
    r_movimentacao.idnotafiscal     := v_confpacking.idnotafiscal;
    r_movimentacao.idonda           := v_confpacking.idonda;
    r_movimentacao.qtdeconferida    := 0;
    if (nvl(v_identificadorTarefa, -1) <> -1) then
      r_movimentacao.identificador := v_identificadorTarefa;
    end if;
    v_idmovimentacao := pk_onda.inserirMovimentacao(r_movimentacao);
  
    -- vincula as movimentações aos grupos necessários
    for cm in (select idselecionado id
                 from gtt_selecao)
    loop
      insert into grupomovimentacao
        (idgrupo, idmovimentacao)
      values
        (cm.id, v_idmovimentacao);
    
      insert into grupomovimentacao
        (idgrupo, idmovimentacao)
      values
        (v_idmovimentacao, cm.id);
    end loop;
  
    delete from gtt_selecao;
  
    update volumeromaneio vr
       set vr.alturacaixa      = v_confpacking.alturacaixa,
           vr.larguracaixa     = v_confpacking.larguracaixa,
           vr.comprimentocaixa = v_confpacking.comprimentocaixa,
           vr.ispreetiqueta    = decode(v_utzPreEtiquetaVol, 0, 0,
                                        decode(v_tipoNF, 'P', 1, 0)),
           vr.idpreetiquetavol = decode(v_utzPreEtiquetaVol, 0, null,
                                        decode(v_modeloEtiquetaVol, 'P', 1,
                                                null))
    
     where idvolumeromaneio = v_idvolumeromaneio;
  
    -- valida o conteudo fracionado do volume
    select count(1)
      into v_erroGeracaoVolume
      from dual
     where exists
     (select a.idproduto, sum(a.totalconfpacking) totalconfpacking,
                   sum(a.totalfracionado)
              from (select pc.idproduto,
                            sum(pc.qtde * e.fatorconversao) totalconfpacking,
                            0 totalfracionado
                       from confpacking c, produtoconfpacking pc, embalagem e
                      where c.id = p_idConfPacking
                        and pc.idconfpacking = c.id
                        and e.barra = pc.barra
                        and e.idproduto = pc.idproduto
                        and pc.status = 1
                      group by pc.idproduto
                     union all
                     select lt.idproduto, 0 totalconfpacking,
                            sum(cv.quantidadefracionada) totalfracionado
                       from confpacking c, conteudovolume cv, lote lt
                      where c.id = p_idConfPacking
                        and cv.idvolumeromaneio = c.idvolumeromaneio
                        and lt.idlote = cv.idlote
                      group by lt.idproduto) a
             group by a.idproduto
            having sum(a.totalconfpacking) <> sum(a.totalfracionado));
  
    if (v_erroGeracaoVolume = 1) then
      v_msg := t_message('Quantidade contada no packing não confere com a quantidade a ser gerada para o volume.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_romaneio.AtualizaStatusAuditoria(v_confpacking.idonda);
  
    pk_onda.liberarPesagemVolume(v_idvolumeromaneio, p_idusuario);
  
    associarEstoqueInfoEspecifica(v_idvolumeromaneio, p_idConfPacking);
  
    pk_ordemdevolucao.finalizaConferencia(v_confpacking.idonda);
  
    select *
      into v_confpacking
      from confpacking cp
     where cp.id = p_idConfPacking;
  
    controlaQtdeVolumesNotafiscal;
    controlaGeracaoUltimoVolumeNf;
    controlaVolumeSemConteudo;
    pk_ordemseparacao.validaPedFatOrdemSep(v_confpacking.idnotafiscal,
                                           pk_ordemseparacao.C_OF_BLOQUEIA_GERACAOVOLUME);
  
    registrarTotVolSaidaPorNf(v_confpacking.idonda,
                              v_confpacking.idnotafiscal, p_idUsuario,
                              p_idSupervisor);
  
    coletaAutomaticaAposUltimoVol(v_confpacking.idonda, p_idUsuario);
  
    if (v_seppkporestacao = 1 and
       isConteudoRestanteCxSeparacao(v_confpacking.idpacking,
                                      v_confpacking.id, v_confpacking.idonda,
                                      v_confpacking.idnotafiscal,
                                      v_confpacking.codbarratarefa) > 0) then
      utilizarNovaCaixaRetornavel(v_confpacking);
    end if;
  
    return v_idvolumeromaneio;
  end;

  function indiceConfPacking
  (
    p_id             in number,
    p_idnotafiscal   in number,
    p_idonda         in number,
    p_codbarratarefa in varchar2,
    p_status         in number
  ) return varchar2 deterministic is
    v_retorno varchar2(1000);
  begin
    if (p_status > 0) then
      v_retorno := 'PK' || p_id;
      return v_retorno;
    end if;
  
    v_retorno := 'O' || p_idonda || 'NF' || p_idnotafiscal || 'T' ||
                 p_codbarratarefa;
    return v_retorno;
  end;

  function isConferenciaPorTarefa(p_identificador in number) return boolean is
    v_resultado number;
  begin
    select count(1)
      into v_resultado
      from romaneiopai rp, nfromaneio nfr, configuracaoonda co,
           notafiscal nf
     where rp.idromaneio = nfr.idromaneio
       and rp.idconfiguracaoonda = co.idconfiguracaoonda
       and nf.idnotafiscal = nfr.idnotafiscal
       and nf.statusnf not in ('X', 'P')
       and nfr.idnotafiscal = p_identificador
       and co.confpackingagrupadaporpedido <> CONFPACKING_AGRUPADA_PEDIDO
       and co.tipoconferenciapacking <> TIPO_CONF_POR_NF;
  
    return v_resultado > 0;
  end;

  procedure entrarIdentificadorPacking
  (
    p_idArmazem     in number,
    p_identificador in out varchar2,
    p_idPacking     in number,
    p_idusuario     in number,
    p_checkout      in number default 0
  ) is
  
    ERROR_CODE_PACKING_EXCEPTION constant number := -20001;
    LOTE_UNICO_NO_VOLUME         constant number := 1;
    STATUS_ONDA_PROCESSADA       constant number := 3;
    STATUS_ONDA_CANCELADA        constant number := 5;
  
    cursor c_reserva
    (
      pc_idretornocortepacking number,
      pc_idenderecopacking     number
    ) is
      select mn.id idmovimentacao, ld.idarmazem, ld.idlocal, mn.idlote,
             mn.qtdemovimentada, lret.idlocal idlocalpacking
        from cortefisico cf, cortefisiconf cnf, resestoquecortefisiconf r,
             movimentacao mn, local ld, local lret
       where cf.idretornocortepacking = pc_idretornocortepacking
         and cnf.idcortefisico = cf.id
         and cnf.qtdeseparacao <> cnf.qtdeutilizada
         and r.idcortefisiconf = cnf.id
         and mn.id = r.idmovimentacaonova
         and mn.idlocaldestino <> pc_idenderecopacking
         and ld.id = mn.idlocaldestino
         and lret.id = pc_idenderecopacking
       order by mn.idlote;
  
    C_CONFIRMAR_RETORNO_CORTE constant number := 0;
    C_PRODUTO_EXCEDIDO        constant number := 1;
    C_CONFPACKING_OK          constant number := 2;
    C_PONTO_ALERTA_PENDENTE   constant number := 3;
  
    TIPO_CONF_POR_TAREFA constant number := 1;
  
    e_confirmar_retorno_corte exception;
    e_produto_excedido        exception;
    e_ponto_alerta_pendente   exception;
    e_erro_tarefaPickToLight  exception;
  
    r_confpacking confpacking%rowtype;
  
    r_identpacking     gtt_identificacaopacking%rowtype := null;
    r_configuracaoonda configuracaoonda%rowtype;
  
    v_idonda                 number;
    v_idnotafiscal           number;
    v_msg                    t_message;
    v_identcodBarraSeparacao number := 0;
  
    procedure encontrarConfAguardando is
      row_locked EXCEPTION;
      PRAGMA EXCEPTION_INIT(row_locked, -54);
    
      function isConfPorTarefa(p_identificador in number) return boolean is
      begin
        -- caso a conferencia seja por checkout libera 
        -- conferencia por NF em onde de tarefa
        if (p_checkout = 1) then
          return false;
        end if;
      
        return pk_packing.isConferenciaPorTarefa(p_identificador);
      end isConfPorTarefa;
    
    begin
      --encontrando confpacking para caixa retornavel
      begin
        select cp.*
          into r_confpacking
          from confpacking cp
         where 1 = 1
           and exists
         (select 1
                  from tarefacaixavolume tc, tipocaixavolume tv
                 where tv.idtipocaixavolume = tc.idtipocaixavolume
                   and tv.barra = p_identificador
                   and tc.tarefa = cp.codbarratarefa)
           and cp.status = C_STATUS_EM_CONTAGEM
           and cp.idpacking = p_idPacking
              -- inserido exists para realizar lock somente na linha da confpacking
           and exists
         (select 1
                  from romaneiopai r, configuracaoonda cf
                 where 1 = 1
                   and r.idromaneio = cp.idonda
                   and r.statusonda not in
                       (STATUS_ONDA_PROCESSADA, STATUS_ONDA_CANCELADA)
                   and r.idconfiguracaoonda = cf.idconfiguracaoonda
                   and ((cf.conferenciaporcheckoutexpress = 0) or
                       (cf.conferenciaporcheckoutexpress = 1 and
                       (cf.permitirconferirmultiusuario =
                       MULTI_USUARIO_CONF_CHECKOUT or
                       (cf.permitirconferirmultiusuario <
                       MULTI_USUARIO_CONF_CHECKOUT and
                       cp.idusuario = p_idusuario)))))
           for update nowait;
      
        return;
      exception
        when row_locked then
          v_msg := t_message('Já existe uma conferência sendo iniciada em seu packing. Favor tentar novamente a operação.');
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          r_confpacking := null;
      end;
    
      begin
        select cp.*
          into r_confpacking
          from confpacking cp
         where 1 = 1
           and cp.status = C_STATUS_EM_CONTAGEM
           and cp.idpacking = p_idPacking
              -- inserido exists para realizar lock somente na linha da confpacking
           and exists
         (select 1
                  from notafiscal nf, romaneiopai r, configuracaoonda cf
                 where 1 = 1
                   and nf.idnotafiscal = cp.idnotafiscal
                   and r.statusonda not in
                       (STATUS_ONDA_PROCESSADA, STATUS_ONDA_CANCELADA)
                   and nf.barraseparacao = trim(p_identificador)
                   and r.idromaneio = cp.idonda
                   and r.idconfiguracaoonda = cf.idconfiguracaoonda
                   and ((cf.conferenciaporcheckoutexpress = 0) or
                       (cf.conferenciaporcheckoutexpress = 1 and
                       (cf.permitirconferirmultiusuario =
                       MULTI_USUARIO_CONF_CHECKOUT or
                       (cf.permitirconferirmultiusuario <
                       MULTI_USUARIO_CONF_CHECKOUT and
                       cp.idusuario = p_idusuario)))))
           for update nowait;
      exception
        when row_locked then
          v_msg := t_message('Já existe uma conferência sendo iniciada em seu packing. Favor tentar novamente a operação.');
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          r_confpacking := null;
      end;
    
      if (not pk_utilities.isNumber(p_identificador)) then
        return;
      end if;
    
      begin
        select cp.*
          into r_confpacking
          from confpacking cp
         where 1 = 1
           and cp.codbarratarefa = p_identificador
           and cp.status = C_STATUS_EM_CONTAGEM
           and cp.idpacking = p_idPacking
              -- inserido exists para realizar lock somente na linha da confpacking
           and exists
         (select 1
                  from romaneiopai r, configuracaoonda cf
                 where 1 = 1
                   and r.idromaneio = cp.idonda
                   and r.statusonda not in
                       (STATUS_ONDA_PROCESSADA, STATUS_ONDA_CANCELADA)
                   and r.idconfiguracaoonda = cf.idconfiguracaoonda
                   and ((cf.conferenciaporcheckoutexpress = 0) or
                       (cf.conferenciaporcheckoutexpress = 1 and
                       (cf.permitirconferirmultiusuario =
                       MULTI_USUARIO_CONF_CHECKOUT or
                       (cf.permitirconferirmultiusuario <
                       MULTI_USUARIO_CONF_CHECKOUT and
                       cp.idusuario = p_idusuario)))))
           for update nowait;
      exception
        when row_locked then
          v_msg := t_message('Já existe uma conferência sendo iniciada em seu packing. Favor tentar novamente a operação.');
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          r_confpacking := null;
      end;
    
      if (r_confpacking.id is null) then
      
        if (isConfPorTarefa(p_identificador)) then
          v_msg := t_message('Não é permitido realizar a conferência por nota fiscal, pois a configuração da onda está definida para utilizar conferência por tarefa.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        begin
          select cp.*
            into r_confpacking
            from confpacking cp
           where 1 = 1
             and cp.idnotafiscal = to_number(p_identificador)
             and cp.status = C_STATUS_EM_CONTAGEM
             and cp.idpacking = p_idPacking
                -- inserido exists para realizar lock somente na linha da confpacking
             and exists
           (select 1
                    from romaneiopai rp, configuracaoonda cf
                   where 1 = 1
                     and rp.idromaneio = cp.idonda
                     and rp.statusonda not in
                         (STATUS_ONDA_PROCESSADA, STATUS_ONDA_CANCELADA)
                     and rp.idconfiguracaoonda = cf.idconfiguracaoonda
                     and ((cf.conferenciaporcheckoutexpress = 0) or
                         (cf.conferenciaporcheckoutexpress = 1 and
                         (cf.permitirconferirmultiusuario =
                         MULTI_USUARIO_CONF_CHECKOUT or
                         (cf.permitirconferirmultiusuario <
                         MULTI_USUARIO_CONF_CHECKOUT and
                         cp.idusuario = p_idusuario)))))
             for update nowait;
          v_idnotafiscal := p_identificador;
        exception
          when row_locked then
            v_msg := t_message('Já existe uma conferência sendo iniciada em seu packing. Favor tentar novamente a operação.');
            raise_application_error(-20000, v_msg.formatMessage);
          when too_many_rows then
            v_msg := t_message('Múltiplas conferências iniciadas para os mesmos Packing e Pedido/Nota Fiscal. ' ||
                               'Operação não permitida. Contate o suporte.');
            raise_application_error(-20000, v_msg.formatMessage);
          when no_data_found then
            begin
              select rp.idromaneio
                into v_idonda
                from romaneiopai rp
               where rp.idarmazem = p_idArmazem
                 and rp.codigointerno = p_identificador
                 and rp.statusonda in (2, 4);
            
              begin
                select nfr.idnotafiscal
                  into v_idnotafiscal
                  from nfromaneio nfr
                 where nfr.idromaneio = v_idonda
                   and p_checkout = 0;
              exception
                when too_many_rows then
                  v_msg := t_message('Onda possui mais de uma nota fiscal. Informe o identificador do packing ou a tarefa.');
                  raise_application_error(-20000, v_msg.formatMessage);
              end;
            
              if (isConfPorTarefa(v_idnotafiscal)) then
                v_msg := t_message('Não é permitido realizar a conferência por nota fiscal, pois a configuração da onda está definida para utilizar conferência por tarefa.');
                raise_application_error(-20000, v_msg.formatMessage);
              end if;
            
              update confpacking cp
                 set cp.status           = 2,
                     cp.datacancelamento = sysdate
               where cp.idnotafiscal = v_idnotafiscal
                 and cp.status = C_STATUS_EM_CONTAGEM
                 and cp.idpacking <> p_idPacking;
            
              select cp.*
                into r_confpacking
                from confpacking cp
               where 1 = 1
                 and cp.idnotafiscal = v_idnotafiscal
                 and cp.status = C_STATUS_EM_CONTAGEM
                 and cp.idpacking = p_idPacking
                    -- inserido exists para realizar lock somente na linha da confpacking
                 and exists
               (select 1
                        from romaneiopai r, configuracaoonda cf
                       where 1 = 1
                         and r.idromaneio = cp.idonda
                         and r.statusonda not in
                             (STATUS_ONDA_PROCESSADA, STATUS_ONDA_CANCELADA)
                         and r.idconfiguracaoonda = cf.idconfiguracaoonda
                         and ((cf.conferenciaporcheckoutexpress = 0) or
                             (cf.conferenciaporcheckoutexpress = 1 and
                             (cf.permitirconferirmultiusuario =
                             MULTI_USUARIO_CONF_CHECKOUT or
                             (cf.permitirconferirmultiusuario <
                             MULTI_USUARIO_CONF_CHECKOUT and
                             cp.idusuario = p_idusuario)))))
                 for update nowait;
            exception
              when row_locked then
                v_msg := t_message('Já existe uma conferência sendo iniciada em seu packing. Favor tentar novamente a operação.');
                raise_application_error(-20000, v_msg.formatMessage);
              when no_data_found then
                v_idnotafiscal := p_identificador;
                r_confpacking  := null;
            end;
        end;
      end if;
    end encontrarConfAguardando;
  
    procedure confPorCaixaSepRetornavel is
      v_existeConfPendente number;
    begin
      begin
        select distinct m.idonda, rp.codigointerno, m.idnotafiscal,
                        nf.idprenf, nf.codigointerno, m.codbarratarefa,
                        pc.idendereco, co.controlacubagemcaixavolume,
                        co.permiteinicioconfquebrapend,
                        co.alertatipocaixavolpacking,
                        co.exclusivopicktolight, co.conferenciacegapacking,
                        co.montvolsomentepedconf, co.impnfdanfemontvolume,
                        co.visualizarimpetiquetavolume,
                        co.visualizaimpetiquetatransp, co.visualizarimpdanfe,
                        co.visualizarimpcartaopresente,
                        nf.transportadoranotafiscal, nf.numpedidofornecedor,
                        nf.iddepositante, co.conferenciacegapacking,
                        dest.utilizacaixaretornavel,
                        co.utilizaidentificadorpedido,
                        nf.imprimeetiquetatransportador,
                        decode(nf.tiponf, 'N', 0, 'P', 1, 2),
                        decode(nf.digitada, 'S', 1, 0),
                        nvl(co.exibeprodexcessofinalpack, 0),
                        nvl(co.confcodigobarrascaixa, 0), nf.sequencia,
                        co.calcularnumerovolumes,
                        (select cp1.id
                            from confpacking cp1, romaneiopai r,
                                 configuracaoonda cf
                           where cp1.status = 0
                             and cp1.codbarratarefa = m.codbarratarefa
                             and cp1.idnotafiscal = m.idnotafiscal
                             and cp1.idonda = m.idonda
                             and r.idromaneio = cp1.idonda
                             and r.idconfiguracaoonda = cf.idconfiguracaoonda
                             and ((cf.conferenciaporcheckoutexpress = 0) or
                                 (cf.conferenciaporcheckoutexpress = 1 and
                                 (cf.permitirconferirmultiusuario =
                                 MULTI_USUARIO_CONF_CHECKOUT or
                                 (cf.permitirconferirmultiusuario <
                                 MULTI_USUARIO_CONF_CHECKOUT and
                                 cp1.idusuario = p_idusuario))))) id,
                        nvl(o.tipooper, '-'), co.tipoconferencia,
                        co.gerarvolumesemconteudo, nf.utilizazpl,
                        co.visualizarimpmensagempresprod,
                        co.utilziar2etiquetasvolume, tc.idtipocaixavolume,
                        tc.barra, co.seppkporestacao
          into r_identpacking.idonda, r_identpacking.codigoonda,
               r_identpacking.idnotafiscal, r_identpacking.idprenf,
               r_identpacking.numeronf, r_identpacking.codbarratarefa,
               r_identpacking.idpacking,
               r_identpacking.controlacubagemvolume,
               r_identpacking.iniciaconfcomquebrapend,
               r_identpacking.alertatipocaixamontagem,
               r_identpacking.picktolight,
               r_identpacking.utilizaconferenciacega,
               r_identpacking.montavolaposconftodanf,
               r_identpacking.impressaodanfe,
               r_identpacking.visualizaimpretiquetavolume,
               r_identpacking.visualizaimpretiquetatransp,
               r_identpacking.visualizaimprdanfe,
               r_identpacking.visualizaimprcartaopresente,
               r_identpacking.idtransportadora, r_identpacking.numeropedido,
               r_identpacking.iddepositante, r_identpacking.conferenciacega,
               r_identpacking.destutilizacxretornavel,
               r_identpacking.utzidentificadorpedido,
               r_identpacking.imprimeetiquetatransportador,
               r_identpacking.tiponf, r_identpacking.nfdigitada,
               r_identpacking.ordenaProdutosExcesso,
               r_identpacking.confcodigobarrascaixa, r_identpacking.serienf,
               r_identpacking.calcularnumerovolumes,
               r_identpacking.idconfpacking, r_identpacking.tipooper,
               r_identpacking.tipoconferenciaonda,
               r_identpacking.gerarvolumesemconteudo,
               r_identpacking.utilizazpl,
               r_identpacking.visualizarimpmensagempresprod,
               r_identpacking.utilziar2etiquetasvolume,
               r_identpacking.idcaixatarefa,
               r_identpacking.codbarracaixatarefa,
               r_identpacking.seppkporestacao
          from tipocaixavolume tc, tarefacaixavolume tcv, v_tarefas_onda m,
               romaneiopai rp, notafiscal nf, configuracaoonda co,
               packing pc, entidade dest, operacao o
         where tc.barra = p_identificador
           and tc.retornavel = 1
           and tcv.idtipocaixavolume = tc.idtipocaixavolume
           and m.codbarratarefa = tcv.tarefa
           and m.idonda = tcv.idonda
           and m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and m.idlocaldestino = p_idPacking
           and rp.idromaneio = m.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and co.tipoconferenciapacking = TIPO_CONF_POR_TAREFA
           and co.seppkporestacao = 1
           and pc.idendereco = m.idlocaldestino
           and nf.idnotafiscal = m.idnotafiscal
           and rp.idarmazem = p_idArmazem
           and dest.identidade = nf.destinatario
           and o.idoperacao = nf.idoperacao
           and not exists
         (select 1
                  from volumeromaneio vr, movimentacao mv
                 where vr.idtipocaixavolume = tc.idtipocaixavolume
                   and vr.statusvolume = 0
                   and mv.idvolumeromaneio = vr.idvolumeromaneio
                   and mv.status in
                       (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                        STATUS_MOV_FINALIZADO));
      exception
        when no_data_found then
          begin
            select m.idnotafiscal,
                   case
                     when (sum(m.qtdeemvolume) < sum(m.qtdemovimentada)) then
                      1
                     else
                      0
                   end
              into r_identpacking.idnotafiscal, v_existeConfPendente
              from tipocaixavolume tc, tarefacaixavolume tcv,
                   v_tarefas_onda m
             where tc.barra = p_identificador
               and tc.retornavel = 1
               and tcv.idtipocaixavolume = tc.idtipocaixavolume
               and m.codbarratarefa = tcv.tarefa
               and m.idonda = tcv.idonda
               and m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                                STATUS_MOV_FINALIZADO)
               and m.idlocaldestino = p_idPacking
             group by m.idnotafiscal;
          
            if (v_existeConfPendente = 0) then
              raise e_produto_excedido;
            end if;
          
          exception
            when no_data_found then
              r_identpacking := null;
          end;
      end;
    end confPorCaixaSepRetornavel;
  
    procedure conferenciaPorTarefa is
    begin
      begin
        select distinct m.idonda, rp.codigointerno, m.idnotafiscal,
                        nf.idprenf, nf.codigointerno, m.codbarratarefa,
                        pc.idendereco, co.controlacubagemcaixavolume,
                        co.permiteinicioconfquebrapend,
                        co.alertatipocaixavolpacking,
                        co.exclusivopicktolight, co.conferenciacegapacking,
                        co.montvolsomentepedconf,
                        decode(dep.utilizaautorizacaoexpedicao, 1, 0,
                                co.impnfdanfemontvolume) impnfdanfemontvolume,
                        co.visualizarimpetiquetavolume,
                        co.visualizaimpetiquetatransp, co.visualizarimpdanfe,
                        co.visualizarimpcartaopresente,
                        nf.transportadoranotafiscal, nf.numpedidofornecedor,
                        nf.iddepositante, co.conferenciacegapacking,
                        dest.utilizacaixaretornavel,
                        co.utilizaidentificadorpedido,
                        nf.imprimeetiquetatransportador,
                        decode(nf.tiponf, 'N', 0, 'P', 1, 2),
                        decode(nf.digitada, 'S', 1, 0),
                        nvl(co.exibeprodexcessofinalpack, 0),
                        nvl(co.confcodigobarrascaixa, 0), nf.sequencia,
                        co.calcularnumerovolumes,
                        (select cp1.id
                            from confpacking cp1, romaneiopai r,
                                 configuracaoonda cf
                           where cp1.status = C_STATUS_EM_CONTAGEM
                             and cp1.codbarratarefa = p_identificador
                             and r.idromaneio = cp1.idonda
                             and r.idconfiguracaoonda = cf.idconfiguracaoonda
                             and cp1.codbarratarefa = m.codbarratarefa
                             and cp1.idnotafiscal = m.idnotafiscal
                             and cp1.idonda = m.idonda
                             and ((cf.conferenciaporcheckoutexpress = 0) or
                                 (cf.conferenciaporcheckoutexpress = 1 and
                                 (cf.permitirconferirmultiusuario =
                                 MULTI_USUARIO_CONF_CHECKOUT or
                                 (cf.permitirconferirmultiusuario <
                                 MULTI_USUARIO_CONF_CHECKOUT and
                                 cp1.idusuario = p_idusuario))))) id,
                        nvl(o.tipooper, '-'), co.tipoconferencia,
                        co.gerarvolumesemconteudo, nf.utilizazpl,
                        co.visualizarimpmensagempresprod,
                        dep.permitetrocaloteindconfpacking,
                        co.utilizavolumeagrupador,
                        co.utilziar2etiquetasvolume,
                        co.tipoconferenciapacking, co.seppkporestacao
          into r_identpacking.idonda, r_identpacking.codigoonda,
               r_identpacking.idnotafiscal, r_identpacking.idprenf,
               r_identpacking.numeronf, r_identpacking.codbarratarefa,
               r_identpacking.idpacking,
               r_identpacking.controlacubagemvolume,
               r_identpacking.iniciaconfcomquebrapend,
               r_identpacking.alertatipocaixamontagem,
               r_identpacking.picktolight,
               r_identpacking.utilizaconferenciacega,
               r_identpacking.montavolaposconftodanf,
               r_identpacking.impressaodanfe,
               r_identpacking.visualizaimpretiquetavolume,
               r_identpacking.visualizaimpretiquetatransp,
               r_identpacking.visualizaimprdanfe,
               r_identpacking.visualizaimprcartaopresente,
               r_identpacking.idtransportadora, r_identpacking.numeropedido,
               r_identpacking.iddepositante, r_identpacking.conferenciacega,
               r_identpacking.destutilizacxretornavel,
               r_identpacking.utzidentificadorpedido,
               r_identpacking.imprimeetiquetatransportador,
               r_identpacking.tiponf, r_identpacking.nfdigitada,
               r_identpacking.ordenaProdutosExcesso,
               r_identpacking.confcodigobarrascaixa, r_identpacking.serienf,
               r_identpacking.calcularnumerovolumes,
               r_identpacking.idconfpacking, r_identpacking.tipooper,
               r_identpacking.tipoconferenciaonda,
               r_identpacking.gerarvolumesemconteudo,
               r_identpacking.utilizazpl,
               r_identpacking.visualizarimpmensagempresprod,
               r_identpacking.permitetrocaloteindconfpacking,
               r_identpacking.utilizavolumeagrupador,
               r_identpacking.utilziar2etiquetasvolume,
               r_identpacking.tipoconferenciapacking,
               r_identpacking.seppkporestacao
          from v_tarefas_onda m, romaneiopai rp, notafiscal nf,
               configuracaoonda co, packing pc, entidade dest, operacao o,
               depositante dep
         where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and rp.idromaneio = m.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and co.tipoconferenciapacking = TIPO_CONF_POR_TAREFA
           and co.conferenciaporcheckoutexpress = 0
           and m.codbarratarefa = p_identificador
           and m.idonda = to_number(substr(p_identificador, 1, 10))
           and pc.idendereco = m.idlocaldestino
           and nf.idnotafiscal = m.idnotafiscal
           and rp.idarmazem = p_idArmazem
           and dest.identidade = nf.destinatario
           and o.idoperacao = nf.idoperacao
           and dep.identidade = nf.iddepositante
           and (co.seppkporestacao = 0 or not exists
                (select 1
                   from tarefacaixavolume tcv
                  where tcv.tarefa = m.codbarratarefa
                    and tcv.idonda = m.idonda));
      exception
        when no_data_found then
          r_identpacking := null;
      end;
    end conferenciaPorTarefa;
  
    procedure validarConferencia is
      STATUS_CORTE_AGUARDANDO constant number := 0;
      STATUS_ONDA_EXECUCAO    constant number := 4;
      TIPO_REGIAO_PACKING     constant number := 6;
      STATUS_NF_PROCESSADA    constant char(1) := 'P';
    
      v_separacaoConcluida           number;
      v_existeConfPorNF              number;
      v_existeConfPorTarefa          number;
      v_nomeusuario                  usuario.nomeusuario%type;
      v_statusonda                   number;
      v_existeSeparacaoConcluida     number;
      v_existeConfPendente           number;
      v_statusnf                     notafiscal.statusnf%type;
      v_exigeSeparacaoConcluida      number;
      v_existecorteseparacaopendente number;
      v_naoExisteSeparacaoConcluida  number;
      v_notafiscallido               notafiscal.lido%type;
      v_outroUsuario                 varchar2(50);
      v_count                        number;
    begin
      select r.statusonda
        into v_statusonda
        from romaneiopai r
       where r.idromaneio = r_confpacking.idonda;
    
      if (v_statusonda <> STATUS_ONDA_EXECUCAO) then
        v_msg := t_message('Esta conferência pertence a uma onda que não esta em execução.' ||
                           chr(13) || 'IDONDA: {0}');
        v_msg.addParam(r_confpacking.idonda);
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    
      select co.*
        into r_configuracaoonda
        from romaneiopai rp, configuracaoonda co
       where rp.idromaneio = r_confpacking.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda;
    
      --trava na verificação se a onda for conferência por checkout e a conferência for no packing
      if (r_configuracaoonda.conferenciaporcheckoutexpress = 1 and
         p_checkout = 0) then
        v_msg := t_message('Esta é uma conferência do tipo Checkout Express e está sendo feita pelo Packing. Operação cancelada!');
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    
      if (r_confpacking.codbarratarefa is not null) then
        select count(1)
          into v_existeConfPorNF
          from confpacking cp
         where cp.idnotafiscal = r_confpacking.idnotafiscal
           and cp.idonda = r_confpacking.idonda
           and cp.status = C_STATUS_EM_CONTAGEM
           and cp.codbarratarefa is null;
      
        if (v_existeConfPorNF > 0) then
          v_msg := t_message('Conferência já iniciada utilizando identificador por nota fiscal.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      if (r_confpacking.codbarratarefa is null) then
        select count(1)
          into v_existeConfPorTarefa
          from confpacking cp
         where cp.idnotafiscal = r_confpacking.idnotafiscal
           and cp.idonda = r_confpacking.idonda
           and cp.status = C_STATUS_EM_CONTAGEM
           and cp.codbarratarefa is not null;
      
        if (v_existeConfPorTarefa > 0) then
          v_msg := t_message('Conferência já iniciada utilizando identificador por tarefa.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      select s.separado
        into v_separacaoConcluida
        from saidapornf s
       where s.idnotafiscal = r_confpacking.idnotafiscal
         and s.idonda = r_confpacking.idonda;
    
      if (r_configuracaoonda.confpackingagrupadaporpedido = 1 and
         v_separacaoConcluida = 0) then
        v_msg := t_message('Como a configuração onda id {0}' ||
                           ' define o agrupamento de tarefas por pedido, este pedido só poderá ter sua conferência iniciada quando toda a separação de todas as tarefas de separação.');
        v_msg.addParam(r_confpacking.idonda);
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    
      if (r_confpacking.idusuario is null) then
        begin
          select cp.idusuario, cp.id
            into r_confpacking.idusuario, r_confpacking.id
            from confpacking cp
           where cp.idnotafiscal = r_confpacking.idnotafiscal
             and cp.status = C_STATUS_EM_CONTAGEM
             and cp.idpacking = r_confpacking.idpacking
             and decode(r_confpacking.codbarratarefa, '-1',
                        cp.codbarratarefa) =
                 nvl(r_confpacking.codbarratarefa, '-1');
        exception
          when no_data_found then
            null;
        end;
      end if;
    
      if (r_confpacking.idusuario is not null and
         r_confpacking.idusuario <> p_idusuario and
         (r_configuracaoonda.conferenciaporcheckoutexpress = 0 or
         (r_configuracaoonda.conferenciaporcheckoutexpress = 1 and
         r_configuracaoonda.permitirconferirmultiusuario <
         MULTI_USUARIO_CONF_CHECKOUT))) then
      
        if (r_configuracaoonda.exclusivopicktolight = 1 or
           (p_checkout = 1 and r_confpacking.id is not null)) then
          update confpacking cp
             set cp.idusuario = p_idUsuario
           where cp.id = r_confpacking.id;
        
          r_confpacking.idusuario := p_idUsuario;
        else
          select u.nomeusuario
            into v_nomeusuario
            from usuario u
           where u.idusuario = r_confpacking.idusuario;
        
          v_msg := t_message('A conferência já foi iniciada por outro usuário. ({0})');
          v_msg.addParam(v_nomeusuario);
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      else
        r_confpacking.idusuario := r_identpacking.idusuario;
      end if;
    
      select count(1)
        into v_existeSeparacaoConcluida
        from v_tarefas_onda m
       where m.status = STATUS_MOV_FINALIZADO
         and m.idnotafiscal = r_confpacking.idnotafiscal
         and m.idonda = r_confpacking.idonda
         and m.idlocaldestino = r_confpacking.idpacking
         and m.codbarratarefa =
             nvl(r_confpacking.codbarratarefa, m.codbarratarefa);
    
      if (v_existeSeparacaoConcluida = 0) then
        v_msg := t_message('Não existe nenhuma movimentação concluída para esta conferência.');
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_existeConfPendente
        from v_tarefas_onda m
       where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                          STATUS_MOV_FINALIZADO)
         and m.qtdeemvolume < m.qtdemovimentada
         and m.idnotafiscal = r_confpacking.idnotafiscal
         and m.idonda = r_confpacking.idonda
         and m.idlocaldestino = r_confpacking.idpacking
         and m.codbarratarefa =
             nvl(r_confpacking.codbarratarefa, m.codbarratarefa);
    
      if (v_existeConfPendente = 0) then
        select nf.statusnf
          into v_statusnf
          from notafiscal nf
         where nf.idnotafiscal = r_confpacking.idnotafiscal;
      
        if (v_statusnf <> STATUS_NF_PROCESSADA) then
          raise e_produto_excedido;
        end if;
      
        v_msg := t_message('Não existe nenhum produto pendente para esta conferência.');
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    
      if (r_configuracaoonda.permiteinicioconfquebrapend = 0) then
        select count(1)
          into v_existecorteseparacaopendente
          from cortefisico cf, cortefisiconf cnf, local lf,
               regiaoarmazenagem r, resestoquecortefisiconf re,
               v_tarefas_onda m
         where cf.idonda = r_confpacking.idonda
           and cf.status = STATUS_CORTE_AGUARDANDO
           and cnf.idcortefisico = cf.id
           and cnf.idnotafiscal = r_confpacking.idnotafiscal
           and cnf.qtdeseparacao <> cnf.qtdeutilizada
           and lf.id = cf.idenderecofalta
           and r.idregiao = lf.idregiao
           and r.tipo <> TIPO_REGIAO_PACKING
           and re.idcortefisiconf = cnf.id
           and m.id = re.idmovimentacaoafetada
           and m.codbarratarefa =
               nvl(r_confpacking.codbarratarefa, m.codbarratarefa);
      
        if (v_existecorteseparacaopendente > 0) then
          v_msg := t_message('Esta conferência possui corte físico de separação pendente de resolução.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      select a.iniciarmontagemvolumepacking
        into v_exigeSeparacaoConcluida
        from local l, armazem a
       where l.id = r_confpacking.idpacking
         and a.idarmazem = l.idarmazem;
    
      if (v_exigeSeparacaoConcluida = 0) then
        select count(1)
          into v_naoExisteSeparacaoConcluida
          from v_tarefas_onda m
         where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and m.qtdeconferida < m.qtdemovimentada
           and m.idnotafiscal = r_confpacking.idnotafiscal
           and m.idonda = r_confpacking.idonda
           and m.idlocaldestino = r_confpacking.idpacking
           and m.codbarratarefa =
               nvl(r_confpacking.codbarratarefa, m.codbarratarefa);
      
        if (v_naoExisteSeparacaoConcluida > 0) then
          v_msg := t_message('Existem movimentações pendentes de separação para esta conferência.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      if (r_configuracaoonda.separacaoconsolidada = 1 and p_checkout = 0) then
        select nf.lido
          into v_notafiscallido
          from notafiscal nf
         where nf.idnotafiscal = r_confpacking.idnotafiscal;
      
        if (v_notafiscallido = 0) then
          v_msg := t_message('A triagem da Nota Fiscal id {0} não foi realizado. Operação Cancelada');
          v_msg.addParam(r_confpacking.idnotafiscal);
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      -- Valida se a configuração de onda trabalha com Conferência por Apenas um Usuário
      -- e não é fluxo de Checkout Express
      if (r_configuracaoonda.confporumusuario = C_SIM and
         r_configuracaoonda.conferenciaporcheckoutexpress = C_NAO) then
      
        -- Verifica se existe alguma conferência em aberto realizada para a onda em questão
        -- por um usuário diferente do qual está tentando realizar esta conferência
        begin
          select count(1), u.nomeusuario
            into v_count, v_outroUsuario
            from confpacking cp, usuario u
           where cp.idonda = r_identpacking.idonda
             and cp.idusuario <> p_idusuario
             and cp.status = C_STATUS_EM_CONTAGEM
             and u.idusuario = cp.idusuario
           group by u.nomeusuario;
        exception
          when no_data_found then
            v_count := 0;
        end;
      
        if (v_count > 0) then
          v_msg := t_message('Configuração da onda definida para realizar Conferência por Apenas um Usuário!' ||
                             chr(13) ||
                             'O usuário ({0}) já iniciou a conferência da Onda id: {1}.');
          v_msg.addParam(v_outroUsuario);
          v_msg.addParam(r_confpacking.idonda);
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end if;
    end validarConferencia;
  
    procedure retornoCorteNoPacking is
      r_retornocortepacking retornocortepacking%rowtype;
      v_complementar        lotelocal.complementar%type;
    
      procedure validarRetornoCorte is
        STATUS_CORTE_AGUARDANDO constant number := 0;
        TIPO_REGIAO_PACKING     constant number := 6;
      
        v_existeCortePendente number;
        v_existeConfPendente  number;
        v_idlocalretornocorte local.idlocal%type;
      begin
        begin
          select r.*
            into r_retornocortepacking
            from retornocortepacking r
           where r.idonda = r_confpacking.idonda
             and r.idnotafiscal = r_confpacking.idnotafiscal
             and r.finalizado = 0
             and r.tarefanova = r_confpacking.codbarratarefa
             for update;
        exception
          when no_data_found then
            r_retornocortepacking.id := null;
            return;
        end;
      
        if (r_retornocortepacking.finalizado = 1) then
          v_msg := t_message('Retorno de produtos do corte no packing ja finalizado.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      
        select count(1)
          into v_existeCortePendente
          from cortefisico cf, cortefisiconf cnf, local lo,
               regiaoarmazenagem r
         where cf.status = STATUS_CORTE_AGUARDANDO
           and cf.idonda = r_retornocortepacking.idonda
           and cnf.idcortefisico = cf.id
           and cnf.idnotafiscal = r_retornocortepacking.idnotafiscal
           and cnf.qtdeseparacao <> cnf.qtdeutilizada
           and lo.id = cf.idenderecofalta
           and r.idregiao = lo.idregiao
           and r.tipo = TIPO_REGIAO_PACKING;
      
        if (v_existeCortePendente > 0) then
          v_msg := t_message('Corte Físico pendente de resolução');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      
        select count(1)
          into v_existeConfPendente
          from v_tarefas_onda m, romaneiopai rp, configuracaoonda co,
               packing pc
         where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and m.qtdeemvolume < m.qtdemovimentada
           and m.idnotafiscal = r_confpacking.idnotafiscal
           and m.idonda = r_confpacking.idonda
           and rp.idromaneio = m.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and pc.idendereco = m.idlocaldestino
           and not exists
         (select 1
                  from retornocortepacking rt
                 where rt.idonda = m.idonda
                   and rt.idnotafiscal = m.idnotafiscal
                   and rt.tarefanova = m.codbarratarefa);
      
        if (v_existeConfPendente > 0) then
          v_msg := t_message('Esta tarefa representa retorno de corte físico. Todas as tarefas pendentes do pedido devem ser concluídas.');
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      
        if (r_retornocortepacking.idenderecopacking is null) then
          r_identPacking.Idretornocortepacking := r_retornocortepacking.id;
          raise e_confirmar_retorno_corte;
        end if;
      
        if (r_retornocortepacking.idenderecopacking <> p_idPacking) then
          select l.idlocal
            into v_idlocalretornocorte
            from local l
           where l.id = r_retornocortepacking.idenderecopacking;
        
          v_msg := t_message('O endereço de packing atualmente em conferência não é o mesmo endereço de packing definido para retorno dos produtos de corte físico recusado. O endereço de packing definido para retorno é {0}.');
          v_msg.addParam(v_idlocalretornocorte);
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                  v_msg.formatMessage);
        end if;
      end validarRetornoCorte;
    
    begin
      if (r_confpacking.codbarratarefa is null) then
        return;
      end if;
    
      validarRetornoCorte;
    
      for r_reserva in c_reserva(r_retornocortepacking.id, p_idPacking)
      loop
        v_complementar := ' EM FUNÇÃO DO RETORNO DE ESTOQUE PARA O PACKING APOS RECUSAR CORTE FÍSICO. ' ||
                          'ESTOQUE MOVIDO PARA CONFERÊNCIA EM OUTRO PACKING. ' ||
                          'ONDA COM ID: ' || r_retornocortepacking.idonda ||
                          ', RETORNOCORTEPACKING ID: ' ||
                          r_retornocortepacking.id;
      
        pk_estoque.retirar_pendencia(r_reserva.idarmazem, r_reserva.idlocal,
                                     r_reserva.idlote,
                                     r_reserva.qtdemovimentada, p_idusuario,
                                     'RETIRADO PENDENCIA' || v_complementar);
      
        pk_estoque.retirar_estoque(r_reserva.idarmazem, r_reserva.idlocal,
                                   r_reserva.idlote,
                                   r_reserva.qtdemovimentada, p_idusuario,
                                   'RETIRADO ESTOQUE' || v_complementar);
      
        pk_estoque.incluir_estoque(r_reserva.idarmazem,
                                   r_reserva.idlocalpacking,
                                   r_reserva.idlote,
                                   r_reserva.qtdemovimentada, p_idusuario,
                                   'INCLUIDO ESTOQUE' || v_complementar);
      
        pk_estoque.incluir_pendencia(r_reserva.idarmazem,
                                     r_reserva.idlocalpacking,
                                     r_reserva.idlote,
                                     r_reserva.qtdemovimentada, p_idusuario,
                                     'INCLUIDO PENDENCIA' || v_complementar);
      
        update movimentacao m
           set m.idlocaldestino = p_idPacking
         where m.id = r_reserva.idmovimentacao;
      end loop;
    
      update retornocortepacking r
         set r.finalizado = 1
       where r.id = r_retornocortepacking.id;
    
      r_confpacking.idpacking := p_idPacking;
    end retornoCorteNoPacking;
  
    procedure validarLocalPacking is
    begin
      if (r_confpacking.idpacking <> p_idPacking) then
        v_msg := t_message('Esta conferência não pertence a este local de packing.');
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                v_msg.formatMessage);
      end if;
    end validarLocalPacking;
  
    procedure inserirConfpacking is
    begin
      if (r_confpacking.id is not null) then
        return;
      end if;
    
      begin
        insert into confpacking
          (id, idpacking, idnotafiscal, idusuario, idonda, data, status,
           codbarratarefa)
        values
          (seq_confpacking.nextval, r_confpacking.idpacking,
           r_confpacking.idnotafiscal, p_idusuario, r_confpacking.idonda,
           sysdate, C_STATUS_EM_CONTAGEM, r_confpacking.codbarratarefa) return id into r_identpacking.idconfpacking;
      exception
        when dup_val_on_index then
          v_msg := t_message('Uma conferência já foi iniciada para a Nota Fiscal: {0} Onda: {1} no Packing: {2}');
          v_msg.addParam(r_confpacking.idnotafiscal);
          v_msg.addParam(r_confpacking.idonda);
          v_msg.addParam(r_confpacking.idpacking);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end inserirConfpacking;
  
    procedure conferenciaPorNF(p_isPrimeiraBusca boolean default true) is
    begin
      begin
        select distinct m.idonda, rp.codigointerno, m.idnotafiscal,
                        nf.idprenf, nf.codigointerno, pc.idendereco,
                        co.controlacubagemcaixavolume,
                        co.permiteinicioconfquebrapend,
                        co.alertatipocaixavolpacking,
                        co.exclusivopicktolight, co.conferenciacegapacking,
                        co.montvolsomentepedconf,
                        decode(dep.utilizaautorizacaoexpedicao, 1, 0,
                                co.impnfdanfemontvolume) impnfdanfemontvolume,
                        co.visualizarimpetiquetavolume,
                        co.visualizaimpetiquetatransp, co.visualizarimpdanfe,
                        co.visualizarimpcartaopresente,
                        nf.transportadoranotafiscal, nf.numpedidofornecedor,
                        nf.iddepositante, co.conferenciacegapacking,
                        dest.utilizacaixaretornavel,
                        co.utilizaidentificadorpedido,
                        nf.imprimeetiquetatransportador,
                        decode(nf.tiponf, 'N', 0, 'P', 1, 2),
                        decode(nf.digitada, 'S', 1, 0),
                        nvl(co.exibeprodexcessofinalpack, 0),
                        nvl(co.confcodigobarrascaixa, 0), nf.sequencia,
                        co.calcularnumerovolumes, nvl(o.tipooper, '-'),
                        co.tipoconferencia, co.gerarvolumesemconteudo,
                        nf.utilizazpl, co.visualizarimpmensagempresprod,
                        dep.permitetrocaloteindconfpacking,
                        co.utilizavolumeagrupador,
                        co.utilziar2etiquetasvolume,
                        co.tipoconferenciapacking, co.seppkporestacao
          into r_identpacking.idonda, r_identpacking.codigoonda,
               r_identpacking.idnotafiscal, r_identpacking.idprenf,
               r_identpacking.numeronf, r_identpacking.idpacking,
               r_identpacking.controlacubagemvolume,
               r_identpacking.iniciaconfcomquebrapend,
               r_identpacking.alertatipocaixamontagem,
               r_identpacking.picktolight,
               r_identpacking.utilizaconferenciacega,
               r_identpacking.montavolaposconftodanf,
               r_identpacking.impressaodanfe,
               r_identpacking.visualizaimpretiquetavolume,
               r_identpacking.visualizaimpretiquetatransp,
               r_identpacking.visualizaimprdanfe,
               r_identpacking.visualizaimprcartaopresente,
               r_identpacking.idtransportadora, r_identpacking.numeropedido,
               r_identpacking.iddepositante, r_identpacking.conferenciacega,
               r_identpacking.destutilizacxretornavel,
               r_identpacking.utzidentificadorpedido,
               r_identpacking.imprimeetiquetatransportador,
               r_identpacking.tiponf, r_identpacking.nfdigitada,
               r_identpacking.ordenaProdutosExcesso,
               r_identpacking.confcodigobarrascaixa, r_identpacking.serienf,
               r_identpacking.calcularnumerovolumes, r_identpacking.tipooper,
               r_identpacking.tipoconferenciaonda,
               r_identpacking.gerarvolumesemconteudo,
               r_identpacking.utilizazpl,
               r_identpacking.visualizarimpmensagempresprod,
               r_identpacking.permitetrocaloteindconfpacking,
               r_identpacking.utilizavolumeagrupador,
               r_identpacking.utilziar2etiquetasvolume,
               r_identpacking.tipoconferenciapacking,
               r_identpacking.seppkporestacao
          from v_tarefas_onda m, romaneiopai rp, notafiscal nf,
               configuracaoonda co, packing pc, entidade dest, operacao o,
               depositante dep
         where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and rp.idromaneio = m.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and decode(p_checkout, 1, 0, co.tipoconferenciapacking) =
               TIPO_CONF_POR_NF
           and m.idnotafiscal = v_idnotafiscal
           and pc.idendereco = m.idlocaldestino
           and nf.idnotafiscal = m.idnotafiscal
           and rp.idarmazem = p_idArmazem
           and dest.identidade = nf.destinatario
           and o.idoperacao = nf.idoperacao
           and m.idlocaldestino = p_idPacking
           and dep.identidade = nf.iddepositante
           and (co.seppkporestacao = 0 or not exists
                (select 1
                   from tarefacaixavolume tcv
                  where tcv.tarefa = m.codbarratarefa
                    and tcv.idonda = m.idonda));
      exception
        when no_data_found then
          if (not p_isPrimeiraBusca) then
            raise;
          end if;
        
          begin
            select rp.idromaneio
              into v_idonda
              from romaneiopai rp
             where rp.idarmazem = p_idArmazem
               and rp.codigointerno = p_identificador
               and rp.statusonda in (2, 4);
          
            begin
              select nfr.idnotafiscal
                into v_idnotafiscal
                from nfromaneio nfr
               where nfr.idromaneio = v_idonda;
            exception
              when too_many_rows then
                v_msg := t_message('Onda possui mais de uma nota fiscal. Informe o identificador do packing ou a tarefa.');
                raise_application_error(-20000, v_msg.formatMessage);
            end;
          
            if (isConferenciaPorTarefa(v_idnotafiscal)) then
              v_msg := t_message('Não é permitido realizar a conferência por nota fiscal, pois a configuração da onda está definida para utilizar conferência por tarefa.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
            conferenciaPorNF(false);
          exception
            when no_data_found then
              v_msg := t_message('Identificador do packing não encontrado.');
              raise_application_error(ERROR_CODE_PACKING_EXCEPTION,
                                      v_msg.formatMessage);
          end;
      end;
    end conferenciaPorNF;
  
    procedure conferenciaPorBarraSeparacao is
    begin
      begin
        select distinct m.idonda, rp.codigointerno, m.idnotafiscal,
                        nf.idprenf, nf.codigointerno, m.codbarratarefa,
                        pc.idendereco, co.controlacubagemcaixavolume,
                        co.permiteinicioconfquebrapend,
                        co.alertatipocaixavolpacking,
                        co.exclusivopicktolight, co.conferenciacegapacking,
                        co.montvolsomentepedconf,
                        decode(dep.utilizaautorizacaoexpedicao, 1, 0,
                                co.impnfdanfemontvolume) impnfdanfemontvolume,
                        co.visualizarimpetiquetavolume,
                        co.visualizaimpetiquetatransp, co.visualizarimpdanfe,
                        co.visualizarimpcartaopresente,
                        nf.transportadoranotafiscal, nf.numpedidofornecedor,
                        nf.iddepositante, co.conferenciacegapacking,
                        dest.utilizacaixaretornavel,
                        co.utilizaidentificadorpedido,
                        nf.imprimeetiquetatransportador,
                        decode(nf.tiponf, 'N', 0, 'P', 1, 2),
                        decode(nf.digitada, 'S', 1, 0),
                        nvl(co.exibeprodexcessofinalpack, 0),
                        nvl(co.confcodigobarrascaixa, 0), nf.sequencia,
                        co.calcularnumerovolumes,
                        (select cp1.id
                            from confpacking cp1, romaneiopai r,
                                 configuracaoonda cf
                           where cp1.status = C_STATUS_EM_CONTAGEM
                             and cp1.codbarratarefa = p_identificador
                             and r.idromaneio = cp1.idonda
                             and r.idconfiguracaoonda = cf.idconfiguracaoonda
                             and cp1.codbarratarefa = m.codbarratarefa
                             and cp1.idnotafiscal = m.idnotafiscal
                             and cp1.idonda = m.idonda
                             and ((cf.conferenciaporcheckoutexpress = 0) or
                                 (cf.conferenciaporcheckoutexpress = 1 and
                                 (cf.permitirconferirmultiusuario =
                                 MULTI_USUARIO_CONF_CHECKOUT or
                                 (cf.permitirconferirmultiusuario <
                                 MULTI_USUARIO_CONF_CHECKOUT and
                                 cp1.idusuario = p_idusuario))))) id,
                        nvl(o.tipooper, '-'), co.tipoconferencia, 1,
                        co.gerarvolumesemconteudo, nf.utilizazpl,
                        co.visualizarimpmensagempresprod,
                        dep.permitetrocaloteindconfpacking,
                        co.utilizavolumeagrupador,
                        co.utilziar2etiquetasvolume,
                        co.tipoconferenciapacking, co.seppkporestacao
          into r_identpacking.idonda, r_identpacking.codigoonda,
               r_identpacking.idnotafiscal, r_identpacking.idprenf,
               r_identpacking.numeronf, r_identpacking.codbarratarefa,
               r_identpacking.idpacking,
               r_identpacking.controlacubagemvolume,
               r_identpacking.iniciaconfcomquebrapend,
               r_identpacking.alertatipocaixamontagem,
               r_identpacking.picktolight,
               r_identpacking.utilizaconferenciacega,
               r_identpacking.montavolaposconftodanf,
               r_identpacking.impressaodanfe,
               r_identpacking.visualizaimpretiquetavolume,
               r_identpacking.visualizaimpretiquetatransp,
               r_identpacking.visualizaimprdanfe,
               r_identpacking.visualizaimprcartaopresente,
               r_identpacking.idtransportadora, r_identpacking.numeropedido,
               r_identpacking.iddepositante, r_identpacking.conferenciacega,
               r_identpacking.destutilizacxretornavel,
               r_identpacking.utzidentificadorpedido,
               r_identpacking.imprimeetiquetatransportador,
               r_identpacking.tiponf, r_identpacking.nfdigitada,
               r_identpacking.ordenaProdutosExcesso,
               r_identpacking.confcodigobarrascaixa, r_identpacking.serienf,
               r_identpacking.calcularnumerovolumes,
               r_identpacking.idconfpacking, r_identpacking.tipooper,
               r_identpacking.tipoconferenciaonda, v_identcodBarraSeparacao,
               r_identpacking.gerarvolumesemconteudo,
               r_identpacking.utilizazpl,
               r_identpacking.visualizarimpmensagempresprod,
               r_identpacking.permitetrocaloteindconfpacking,
               r_identpacking.utilizavolumeagrupador,
               r_identpacking.utilziar2etiquetasvolume,
               r_identpacking.tipoconferenciapacking,
               r_identpacking.seppkporestacao
          from v_tarefas_onda m, romaneiopai rp, notafiscal nf,
               configuracaoonda co, packing pc, entidade dest, operacao o,
               depositante dep
         where m.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and rp.idromaneio = m.idonda
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
           and nf.barraseparacao = trim(p_identificador)
           and pc.idendereco = m.idlocaldestino
           and nf.idnotafiscal = m.idnotafiscal
           and rp.idarmazem = p_idArmazem
           and dest.identidade = nf.destinatario
           and o.idoperacao = nf.idoperacao
           and dep.identidade = nf.iddepositante
           and (co.seppkporestacao = 0 or not exists
                (select 1
                   from tarefacaixavolume tcv
                  where tcv.tarefa = m.codbarratarefa
                    and tcv.idonda = m.idonda));
      exception
        when no_data_found then
          r_identpacking := null;
      end;
    end conferenciaPorBarraSeparacao;
  
    procedure verificarLoteUnicoVolume is
    begin
      begin
        select decode(count(pd.loteuniconovolume), 0, 0, 1)
          into r_identpacking.utilizaLoteUnicoVolume
          from movimentacao m, lote lt, produtodepositante pd
         where 1 = 1
           and lt.idlote = m.idlote
           and pd.idproduto = lt.idproduto
           and pd.identidade = lt.iddepositante
           and pd.loteuniconovolume = LOTE_UNICO_NO_VOLUME
           and m.idnotafiscal = r_confpacking.idnotafiscal
           and m.status <> STATUS_MOV_CANCELADO;
      exception
        when no_data_found then
          return;
      end;
    end verificarLoteUnicoVolume;
  
    procedure verificarPontoAlerta is
    begin
      begin
        select p.idpontoalerta, p.mensagem, p.tipousuario
          into r_identpacking.idpontoalerta, r_identpacking.msgpontoalerta,
               r_identpacking.tipousuariopontoalerta
          from pontoalerta p
         where p.idnotafiscal = r_confpacking.idnotafiscal
           and p.idusuariolib is null;
        raise e_ponto_alerta_pendente;
      exception
        when no_data_found then
          return;
      end;
    end verificarPontoAlerta;
  
    procedure carregarDadosDoca is
    begin
      select distinct d.descr doca
        into r_identpacking.docanotafiscal
        from destinosaidaonda ds, doca d
       where ds.identidade =
             (select decode(a.agruparvolumesruaexpedicao, 1, nf.iddepositante,
                             nf.transportadoranotafiscal)
                from notafiscal nf, armazem a
               where nf.idnotafiscal = r_identpacking.idnotafiscal
                 and a.idarmazem = nf.idarmazem)
         and ds.idonda = r_identpacking.idonda
         and d.idendereco = ds.iddoca;
    exception
      when no_data_found then
        r_identpacking.docanotafiscal := null;
    end carregarDadosDoca;
  
    procedure carregarDadosConferencia is
    begin
      conferenciaPorBarraSeparacao;
    
      if (r_identpacking.idonda is null) then
        confPorCaixaSepRetornavel;
      end if;
    
      if (not pk_utilities.isNumber(p_identificador)) then
        return;
      end if;
    
      if (r_identpacking.idonda is null) then
        conferenciaPorTarefa;
      end if;
    
      if (r_identpacking.idonda is null) then
        conferenciaPorNF;
      end if;
    
      if (r_identpacking.idnotafiscal is not null) then
        carregarDadosDoca;
      end if;
    
      if (r_identpacking.picktolight = 1) then
        select sum(total)
          into r_identpacking.tarefaPickToLight
          from (select decode(count(1), 0, 0, 1) total
                   from int_envio_tarefa_separacao
                  where idonda = r_identpacking.idonda
                    and tarefa = r_identpacking.codbarratarefa
                    and status in (1, 2)
                 union all
                 select decode(count(1), 0, 0, 1) total
                   from tarefacaixavolume tcv, tipocaixavolume tc
                  where tcv.idonda = r_identpacking.idonda
                    and tcv.tarefa = r_identpacking.codbarratarefa
                    and tc.idtipocaixavolume = tcv.idtipocaixavolume
                    and tc.retornavel = 1
                    and tc.disponivel = 0);
      
        if (r_identpacking.tarefaPickToLight = 1) then
          begin
            select tc.idtipocaixavolume
              into r_identpacking.idcaixatarefa
              from tarefacaixavolume tcv, tipocaixavolume tc
             where tcv.idonda = r_identpacking.idonda
               and tcv.tarefa = r_identpacking.codbarratarefa
               and tc.idtipocaixavolume = tcv.idtipocaixavolume
               and tc.retornavel = 1
               and tc.disponivel = 0
               and not exists
             (select 1
                      from volumeromaneio vr
                     where vr.idromaneio = tcv.idonda
                       and vr.idtipocaixavolume = tcv.idtipocaixavolume
                       and vr.statusvolume = 0);
          exception
            when no_data_found then
              r_identpacking.idcaixatarefa := null;
          end;
        end if;
      end if;
    
      select u.idusuario, u.nomeusuario
        into r_identpacking.idusuario, r_identpacking.nomeusuario
        from usuario u
       where u.idusuario = p_idusuario;
    
    end carregarDadosConferencia;
  
    procedure preencherDadosConfPacking is
    begin
      r_confpacking.idpacking      := r_identpacking.idpacking;
      r_confpacking.idnotafiscal   := r_identpacking.idnotafiscal;
      r_confpacking.idonda         := r_identpacking.idonda;
      r_confpacking.codbarratarefa := r_identpacking.codbarratarefa;
      r_confpacking.data           := sysdate;
      r_confpacking.status         := 0;
      r_confpacking.id             := r_identpacking.idconfpacking;
    end preencherDadosConfPacking;
  
    procedure validarDadosConfPacking is
    begin
      if (r_confpacking.idpacking <> r_identpacking.idpacking) then
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION, '');
      end if;
    
      if (r_confpacking.idnotafiscal <> r_identpacking.idnotafiscal) then
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION, '');
      end if;
    
      if (r_confpacking.idonda <> r_identpacking.idonda) then
        raise_application_error(ERROR_CODE_PACKING_EXCEPTION, '');
      end if;
    
      if (r_confpacking.codbarratarefa is not null and
         r_identpacking.codbarratarefa is not null) then
        if (r_confpacking.codbarratarefa <> r_identpacking.codbarratarefa) then
          raise_application_error(ERROR_CODE_PACKING_EXCEPTION, '');
        end if;
      end if;
    
      r_identpacking.idconfpacking           := r_confpacking.id;
      r_identpacking.statusConfPacking       := r_confpacking.status;
      r_identpacking.idvolumeromaneio        := r_confpacking.idvolumeromaneio;
      r_identpacking.datacancelamento        := r_confpacking.datacancelamento;
      r_identpacking.idtipocaixa             := r_confpacking.idtipocaixa;
      r_identpacking.alturacaixa             := r_confpacking.alturacaixa;
      r_identpacking.larguracaixa            := r_confpacking.larguracaixa;
      r_identpacking.comprimentocaixa        := r_confpacking.comprimentocaixa;
      r_identpacking.barracaixareutilizavel  := r_confpacking.barracaixareutilizavel;
      r_identpacking.idprodutocxreutilizavel := r_confpacking.idprodutocxreutilizavel;
    end validarDadosConfPacking;
  
    procedure carregarDadosCubagemVolume is
    begin
      begin
        select (decode(cubCaixa, 0, cubPacote, cubCaixa) - cubagemConferida) cubagemDisponivel,
               cubagemConferida cubagemUtilizada, tipoCaixa,
               decode(cubCaixa, 0, cubPacote, cubCaixa) cubagemTotalCaixa
          into r_identpacking.cubagemDisponivel,
               r_identpacking.cubagemUtilizada, r_identpacking.tipocaixa,
               r_identpacking.cubagemtotalcaixa
          from (select (nvl(cp.alturacaixa, 0) * nvl(cp.larguracaixa, 0) *
                         nvl(cp.comprimentocaixa, 0)) cubPacote,
                        tcv.idtipocaixavolume,
                        (nvl(tcv.altura, 0) * nvl(tcv.largura, 0) *
                         nvl(tcv.comprimento, 0)) cubCaixa,
                        nvl(tcv.tipo, 2) tipoCaixa,
                        (select nvl(sum(p.qtde * e.altura * e.largura *
                                          e.comprimento), 0) cubagem
                            from produtoconfpacking p, embalagem e
                           where p.idconfpacking = cp.id
                             and p.status = 1
                             and e.idproduto = p.idproduto
                             and e.barra = p.barra) cubagemConferida
                   from confpacking cp, tipocaixavolume tcv
                  where cp.id = r_confPacking.Id
                    and tcv.idtipocaixavolume(+) = cp.idtipocaixa);
      exception
        when no_data_found then
          return;
      end;
    end carregarDadosCubagemVolume;
  
    procedure carregarVolumesGerados is
    begin
      select decode(count(1), 0, 0, 1)
        into r_identpacking.possuivolumesgerados
        from (select 1
                 from confpacking cp, volumeromaneio vr
                where vr.idvolumeromaneio = cp.idvolumeromaneio
                  and vr.statusvolume = 0
                  and cp.idnotafiscal = r_confpacking.idnotafiscal
                  and cp.idonda = r_confpacking.idonda
                  and cp.idusuario = r_confpacking.idusuario
                  and r_confpacking.codbarratarefa is null
                  and cp.codbarratarefa is null
                  and ((r_configuracaoonda.conferenciaporcheckoutexpress = 0) or
                      (r_configuracaoonda.conferenciaporcheckoutexpress = 1 and
                      (r_configuracaoonda.permitirconferirmultiusuario =
                      MULTI_USUARIO_CONF_CHECKOUT or
                      (r_configuracaoonda.permitirconferirmultiusuario <
                      MULTI_USUARIO_CONF_CHECKOUT and
                      cp.idusuario = p_idusuario))))
               union
               select 1
                 from confpacking cp, volumeromaneio vr
                where vr.idvolumeromaneio = cp.idvolumeromaneio
                  and vr.statusvolume = 0
                  and cp.idnotafiscal = r_confpacking.idnotafiscal
                  and cp.idonda = r_confpacking.idonda
                  and cp.idusuario = r_confpacking.idusuario
                  and r_confpacking.codbarratarefa is not null
                  and cp.codbarratarefa = r_confpacking.codbarratarefa
                  and ((r_configuracaoonda.conferenciaporcheckoutexpress = 0) or
                      (r_configuracaoonda.conferenciaporcheckoutexpress = 1 and
                      (r_configuracaoonda.permitirconferirmultiusuario =
                      MULTI_USUARIO_CONF_CHECKOUT or
                      (r_configuracaoonda.permitirconferirmultiusuario <
                      MULTI_USUARIO_CONF_CHECKOUT and
                      cp.idusuario = p_idusuario)))));
    end carregarVolumesGerados;
  
    procedure verificarOrdemSeparacao is
    begin
      begin
        select os.idordemseparacao, os.idtipocaixavolume
          into r_identpacking.idordemseparacao,
               r_identpacking.idcaixaboxrecomendation
          from notafiscal nf, ordemseparacao os
         where nf.idnotafiscal = os.idnotafiscal
           and nf.idnotafiscal = r_confpacking.idnotafiscal;
      exception
        when no_data_found then
          return;
      end;
    end verificarOrdemSeparacao;
  
    procedure carregarInformacoesCaixaVolume is
    begin
      if (r_identpacking.barracaixareutilizavel is not null) then
        select p.descr
          into r_identpacking.descrprodutocxreutilizavel
          from produto p
         where p.idproduto = r_identpacking.idprodutocxreutilizavel;
      end if;
    
      if (r_identpacking.idtipocaixa is not null) then
        select tcv.descr, tcv.tipo
          into r_identPacking.descrTipoCaixaVolume, r_identPacking.Tipocaixa
          from tipocaixavolume tcv
         where tcv.idtipocaixavolume = r_identpacking.idtipocaixa;
      end if;
    end carregarInformacoesCaixaVolume;
  
    procedure verificaSePossuiItemConferido is
    begin
      select decode(count(1), 0, 0, 1)
        into r_identpacking.possuiconferencia
        from confpacking cp, produtoconfpacking pc
       where cp.id = r_identpacking.idconfpacking
         and cp.status = C_STATUS_EM_CONTAGEM
         and pc.idconfpacking = cp.id
         and pc.status = 1;
    end verificaSePossuiItemConferido;
  
    procedure verificarSePodeMontarVolume is
      v_possuiItemExcesso number;
    begin
      if (r_identpacking.resultadoIdentificacao = C_PRODUTO_EXCEDIDO) then
        v_possuiItemExcesso := 1;
      else
        v_possuiItemExcesso := 0;
      end if;
    
      if ((r_identpacking.possuiconferencia > 0) and
         (v_possuiItemExcesso = 0)) then
        r_identpacking.podemontarvolume := 1;
      else
        r_identpacking.podemontarvolume := 0;
      end if;
    end verificarSePodeMontarVolume;
  
    procedure carregaDadosVolumesDaNf is
    begin
      -- Caso a onda esteja configurada para Gerar Volume sem Conteúdo
      -- utilizará a quantidade volumes informada na importação do cabeçalho de faturamento
      if (r_configuracaoonda.gerarvolumesemconteudo = 1) then
        select nf.quantidade
          into r_identpacking.quantidadevolumes
          from notafiscal nf
         where nf.idnotafiscal = r_identpacking.idnotafiscal;
      else
        select nvl(nf.novaqtdevolumes, nf.qtdevolumescalculado)
          into r_identpacking.quantidadevolumes
          from nfromaneio nf
         where idnotafiscal = r_identpacking.idnotafiscal;
      
        select min(numero)
          into r_identpacking.numerovolume
          from volumeromaneio v
         where idromaneio = r_identpacking.idonda
           and statusvolume = 1
           and to_number(substr(codbarra, 4, 7)) =
               r_identpacking.idnotafiscal
           and not exists
         (select 1
                  from volumeromaneio vl
                 where vl.idromaneio = v.idromaneio
                   and vl.idnotafiscal = r_identpacking.idnotafiscal
                   and vl.numero = v.numero
                   and vl.statusvolume = 0);
      
        if (r_identpacking.numerovolume is null) then
          select count(idvolumeromaneio) + 1
            into r_identpacking.numerovolume
            from volumeromaneio v
           where v.statusvolume = 0
             and idnotafiscal = r_identpacking.idnotafiscal;
        end if;
      end if;
    end carregaDadosVolumesDaNf;
  
    procedure carregarInstrucaoFaturamento is
    begin
      begin
        select c.msgpontoalerta, c.confirmapacking, c.idtipopedido
          into r_identpacking.instrucaofaturamento,
               r_identpacking.confirmapacking, r_identpacking.idtipopedido
          from notafiscal nf, classificacaotipopedido c
         where nf.idnotafiscal = r_identpacking.idnotafiscal
           and c.idtipopedido = nf.idtipopedido;
      exception
        when no_data_found then
          r_identpacking.instrucaofaturamento := null;
      end;
    end carregarInstrucaoFaturamento;
  
    procedure carregarDadosArmazem is
    begin
      select nvl(a.exibirProdPendentesPacking, 0)
        into r_identpacking.exibirProdPendentesPacking
        from notafiscal nf, armazem a
       where a.idarmazem = nf.idarmazem
         and nf.idnotafiscal = r_identpacking.idnotafiscal;
    end carregarDadosArmazem;
  
    procedure carregarMotivoRetencaoExped is
    begin
      begin
        select concat(concat(m.codigo, ' - '), m.descr)
          into r_identpacking.motivoretencao
          from notafiscal nf, motivo m
         where nf.idnotafiscal = r_identpacking.idnotafiscal
           and m.idmotivo = nf.idmotivoretencao;
      exception
        when no_data_found then
          r_identpacking.motivoretencao := null;
      end;
    end carregarMotivoRetencaoExped;
  
    procedure carregarTotalNumeroVolume is
    begin
      begin
        select qtdevolumesgerados, numerovolume
          into r_identpacking.qtdetotalvolume,
               r_identpacking.ultimonumerovolume
          from (select count(1) qtdevolumesgerados
                   from volumeromaneio v
                  where v.idnotafiscal = r_identpacking.idnotafiscal
                    and v.idromaneio = r_identpacking.idonda
                    and v.statusvolume = 0) volgerados,
               (select max(vr.numero) numerovolume
                   from volumeromaneio vr
                  where vr.idromaneio = r_identpacking.idonda
                    and vr.idnotafiscal = r_identpacking.idnotafiscal
                    and vr.statusvolume = 0) numerovol;
      exception
        when no_data_found then
          r_identpacking.qtdetotalvolume    := null;
          r_identpacking.ultimonumerovolume := null;
      end;
    
      begin
        select sum(case
                      when v.qtdetotal - v.qtdeemvolume - v.qtdecontada < 0 then
                       0
                      else
                       v.qtdetotal - v.qtdeemvolume - v.qtdecontada
                    end) qtdeRestante
          into r_identpacking.qtderestante
          from v_produtoconfpacking v
         where v.idonda = r_identpacking.idonda
           and v.idnotafiscal = r_identpacking.idnotafiscal;
      exception
        when no_data_found then
          r_identpacking.qtderestante := null;
      end;
    end carregarTotalNumeroVolume;
  
    procedure definirUsuarioConferencia
    (
      p_idUsuario       number,
      p_idOnda          number,
      p_tipoConferencia number
    ) is
      C_CONFERENCIA_POR_NF     constant number := 0;
      C_CONFERENCIA_POR_TAREFA constant number := 1;
    begin
      -- Define o usuário que deve realizar a conferência para a Onda
      -- baseando-se nas movimentações geradas
      if p_tipoConferencia = C_CONFERENCIA_POR_NF then
      
        for c_regNf in (select b.idenderecopacking, b.idnotafiscal, b.idonda,
                               b.idarmazem, b.idromaneio
                          from (select a.idenderecopacking, a.idnotafiscal,
                                        a.idonda, a.idarmazem,
                                        nvl((select sum(nvl(pc.qtde *
                                                             e.fatorconversao, 0)) qtdecontada
                                               from confpacking cp,
                                                    produtoconfpacking pc,
                                                    embalagem e,
                                                    volumeromaneio v
                                              where cp.idpacking =
                                                    a.idenderecopacking
                                                and cp.idnotafiscal =
                                                    a.idnotafiscal
                                                and cp.idonda = a.idonda
                                                and cp.status in
                                                    (C_STATUS_EM_CONTAGEM,
                                                     C_STATUS_VOLUME_MONTADO)
                                                and pc.idconfpacking = cp.id
                                                and pc.status = 1
                                                and e.idproduto = pc.idproduto
                                                and e.barra = pc.barra
                                                and v.idvolumeromaneio =
                                                    cp.idvolumeromaneio
                                                and v.statusvolume = 0), 0) qtdeconpacking,
                                        a.quantidade qtdetotal, a.idromaneio
                                   from (select ld.id idenderecopacking,
                                                 m.idnotafiscal, m.idonda,
                                                 ld.idarmazem,
                                                 sum(m.quantidade) quantidade,
                                                 rp.idromaneio
                                            from romaneiopai rp, movimentacao m,
                                                 local ld, notafiscal nf, lote lt,
                                                 configuracaoonda co
                                           where rp.tipo = 1 -- Onda
                                             and m.idonda = rp.idromaneio
                                             and m.etapa = 1 -- Etapa da movimentação do lote
                                             and m.status <>
                                                 STATUS_MOV_CANCELADO -- Cancelada
                                             and ld.id = m.idlocaldestino
                                             and ld.tipo = 8 -- Packing
                                             and nf.idnotafiscal =
                                                 m.idnotafiscal
                                             and lt.idlote = m.idlote
                                             and co.idconfiguracaoonda =
                                                 rp.idconfiguracaoonda
                                             and rp.processado = 'N'
                                             and not exists
                                           (select 1
                                                    from vt_gerenciadorpackingnfmov v,
                                                         confpacking c
                                                   where v.idonda = p_idOnda
                                                     and v.statuspacking < 100
                                                     and v.h$idmovimentacao = m.id
                                                     and c.idpacking =
                                                         v.idenderecopacking
                                                     and c.idonda = v.idonda
                                                     and c.idnotafiscal =
                                                         v.idnotafiscal
                                                     and c.status =
                                                         C_STATUS_EM_CONTAGEM)
                                           group by ld.id, m.idnotafiscal,
                                                    m.idonda, ld.idarmazem,
                                                    rp.idromaneio) a) b
                         where trunc((b.qtdeconpacking * 100) / b.qtdetotal) <> 100
                           and not exists
                         (select 1
                                  from confpacking c
                                 where c.idonda = b.idonda
                                   and c.idnotafiscal = b.idnotafiscal
                                   and c.status = C_STATUS_EM_CONTAGEM)
                           and b.idromaneio = p_idOnda)
        loop
          insert into confpacking
            (id, idpacking, idnotafiscal, idusuario, idonda, status,
             codBarraTarefa)
          values
            (seq_confpacking.nextval, c_regNf.idenderecopacking,
             c_regNf.idnotafiscal, p_idUsuario, p_idOnda,
             C_STATUS_EM_CONTAGEM, null);
        end loop;
      
      elsif p_tipoConferencia = C_CONFERENCIA_POR_TAREFA then
      
        for c_regTarefa in (select a.idenderecopacking, a.idnotafiscal,
                                   a.tarefa, a.id
                              from (select ld.id idenderecopacking,
                                            m.idnotafiscal,
                                            m.codbarratarefa tarefa,
                                            sum(m.quantidade) quantidade,
                                            sum(m.qtdeemvolume) qtdeemvolume,
                                            m.id, rp.idromaneio
                                       from romaneiopai rp, v_tarefas_onda m,
                                            local ld, notafiscal nf, lote lt,
                                            configuracaoonda co
                                      where rp.tipo = 1 -- Onda
                                        and m.idonda = p_idOnda
                                        and m.etapa = 1 -- Etapa da movimentação do lote 
                                        and m.status <> 3 -- Cancelada
                                        and ld.id = m.idlocaldestino
                                        and ld.tipo = 8 -- Packing
                                        and nf.idnotafiscal = m.idnotafiscal
                                        and lt.idlote = m.idlote
                                        and co.idconfiguracaoonda =
                                            rp.idconfiguracaoonda
                                        and co.tipoconferenciapacking = 1
                                        and rp.processado = 'N'
                                        and not exists
                                      (select 1
                                               from v_packingtarefa v,
                                                    confpacking c
                                              where v.idonda = p_idOnda
                                                and v.statuspacking < 100
                                                and v.h$idmovimentacao = m.id
                                                and c.idpacking =
                                                    v.idenderecopacking
                                                and c.idonda = v.idonda
                                                and c.idnotafiscal =
                                                    v.idnotafiscal
                                                and c.status =
                                                    C_STATUS_EM_CONTAGEM)
                                      group by ld.id, m.idnotafiscal, m.idonda,
                                               m.codbarratarefa, rp.processado,
                                               m.id, rp.idromaneio) a
                             where trunc((a.qtdeemvolume * 100) /
                                         a.quantidade) <> 100
                               and not exists
                             (select 1
                                      from confpacking c
                                     where c.idonda = a.idromaneio
                                       and c.idnotafiscal = a.idnotafiscal
                                       and c.codBarraTarefa = a.tarefa
                                       and c.status = C_STATUS_EM_CONTAGEM))
        loop
          insert into confpacking
            (id, idpacking, idnotafiscal, idusuario, idonda, status,
             codBarraTarefa)
          values
            (seq_confpacking.nextval, c_regTarefa.idenderecopacking,
             c_regTarefa.idnotafiscal, p_idUsuario, p_idOnda,
             C_STATUS_EM_CONTAGEM, c_regTarefa.tarefa);
        end loop;
      end if;
    end definirUsuarioConferencia;
  
    procedure carregarDadosDepositanteNF is
    begin
      if (r_identpacking.iddepositante is not null) then
        select d.permitetrocaloteindconfpacking
          into r_identpacking.depositantepermtrocaloteind
          from depositante d
         where d.identidade = r_identpacking.iddepositante;
      else
        r_identpacking.depositantepermtrocaloteind := 0;
      end if;
    
    end;
  
    procedure verificarCaixaRecomendavel is
    
      v_qtdUtiliza           number := 0;
      v_qtdNUtiliza          number := 0;
      v_caixaRecomendadaSIOC number := 0;
    begin
    
      select nvl(sum(decode(x.utilizacaixarecomendada, 0, 1, 0)), 0) nUtiliza,
             nvl(sum(decode(x.utilizacaixarecomendada, 1, 1, 0)), 0) utiliza
        into v_qtdNUtiliza, v_qtdUtiliza
        from (select distinct pd.idproduto, pd.utilizacaixarecomendada
                 from notafiscal nf, nfdet nd, produtodepositante pd
                where nf.idnotafiscal = nd.nf
                  and nd.idproduto = pd.idproduto
                  and nf.iddepositante = pd.identidade
                  and nf.idnotafiscal = r_identpacking.idnotafiscal) x;
    
      if (v_qtdUtiliza > 0 and v_qtdNUtiliza = 0) then
        v_caixaRecomendadaSIOC := 1;
      else
        v_caixaRecomendadaSIOC := 0;
      end if;
    
      r_identpacking.caixarecomendadasioc := v_caixaRecomendadaSIOC;
    
    end verificarCaixaRecomendavel;
  
  begin
    begin
      encontrarConfAguardando;
      carregarDadosConferencia;
    
      if (not pk_utilities.isNumber(p_identificador) and
         v_identcodBarraSeparacao = 0 and
         nvl(r_identpacking.seppkporestacao, 0) = 0) then
        v_msg := t_message('Entre com identificador válido.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_confpacking.id is null) then
        preencherDadosConfPacking;
      else
        validarDadosConfPacking;
      end if;
    
      validarConferencia;
      validarLocalPacking;
      retornoCorteNoPacking;
      inserirConfpacking;
      verificarLoteUnicoVolume;
      verificarPontoAlerta;
    
      r_identpacking.resultadoIdentificacao := C_CONFPACKING_OK;
    
    exception
      when e_confirmar_retorno_corte then
        r_identpacking.resultadoIdentificacao := C_CONFIRMAR_RETORNO_CORTE;
      when e_produto_excedido then
        r_identpacking.resultadoIdentificacao := C_PRODUTO_EXCEDIDO;
      when e_ponto_alerta_Pendente then
        r_identpacking.resultadoIdentificacao := C_PONTO_ALERTA_PENDENTE;
    end;
  
    carregarDadosCubagemVolume;
    carregarVolumesGerados;
    verificarOrdemSeparacao;
    carregarInformacoesCaixaVolume;
    verificaSePossuiItemConferido;
    verificarSePodeMontarVolume;
    carregaDadosVolumesDaNf;
    carregarInstrucaoFaturamento;
    carregarDadosArmazem;
    carregarMotivoRetencaoExped;
    carregarTotalNumeroVolume;
    carregarDadosDepositanteNF;
    verificarCaixaRecomendavel;
  
    if (r_configuracaoonda.confporumusuario = 1 and
       r_configuracaoonda.conferenciaporcheckoutexpress = 0) then
    
      definirUsuarioConferencia(p_idUsuario, r_identpacking.idonda,
                                r_configuracaoonda.tipoconferenciapacking);
    end if;
  
    insert into gtt_identificacaopacking
    values r_identpacking;
  end;

  procedure definirDimensoesCaixaPacote
  (
    p_idconfpacking in number,
    p_altura        in number,
    p_largura       in number,
    p_comprimento   in number
  ) is
    v_idTipoCaixaVolume number;
    v_msg               t_message;
    C_TIPO_CAIXA_PCT constant number := 2;
  begin
    begin
      select t.idtipocaixavolume
        into v_idTipoCaixaVolume
        from tipocaixavolume t
       where t.tipo = C_TIPO_CAIXA_PCT
         and rownum = 1;
    exception
      when no_data_found then
        v_msg := t_message('Não foi encontrada nenhuma definição de Tipo de Caixa para Pacote, para definir um pacote para o Packing é necessário definir uma caixa do tipo Pacote.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    update confpacking cp
       set cp.alturacaixa             = p_altura,
           cp.larguracaixa            = p_largura,
           cp.comprimentocaixa        = p_comprimento,
           cp.barracaixareutilizavel  = null,
           cp.idprodutocxreutilizavel = null,
           cp.idtipocaixa             = v_idTipoCaixaVolume
     where cp.id = p_idconfpacking;
  end;

  procedure definirCaixaReutilizavel
  (
    p_idconfpacking in number,
    p_barra         in varchar2
  ) is
    r_embalagem         embalagem%rowtype;
    v_idTipoCaixaVolume number;
    v_msg               t_message;
    C_TIPO_CX_REUTILIZAVEL constant number := 3;
  
    procedure validarDados is
      v_controlaCubagemVolume number;
      v_cubagemCaixaVolume    number;
      v_totalCubagemConferida number;
    begin
      select co.controlacubagemcaixavolume,
             nvl((select nvl(sum(p.qtde * e.altura * e.largura *
                                  e.comprimento), 0) cubagem
                    from confpacking c, produtoconfpacking p, embalagem e
                   where c.id = cp.id
                     and p.idconfpacking = c.id
                     and p.status = 1
                     and e.idproduto = p.idproduto
                     and e.barra = p.barra), 0) cubagemConferida
        into v_controlaCubagemVolume, v_totalCubagemConferida
        from confpacking cp, romaneiopai rp, notafiscal nf,
             configuracaoonda co, tipocaixavolume tcv
       where cp.id = p_idConfPacking
         and rp.idromaneio = cp.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and nf.idnotafiscal = cp.idnotafiscal
         and tcv.idtipocaixavolume(+) = cp.idtipocaixa;
    
      if (v_controlaCubagemVolume = 0) then
        return;
      end if;
    
      v_cubagemCaixaVolume := (nvl(r_embalagem.altura, 0) *
                              nvl(r_embalagem.largura, 0) *
                              nvl(r_embalagem.comprimento, 0));
    
      if (v_cubagemCaixaVolume < v_totalCubagemConferida) then
        v_msg := t_message('A caixa de volume barra {0}' ||
                           ' não possui capacidade suficiente para ser utilizada neste conferência.');
        v_msg.addParam(p_barra);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarDados;
  
  begin
    begin
      select t.idtipocaixavolume
        into v_idTipoCaixaVolume
        from tipocaixavolume t
       where t.tipo = C_TIPO_CX_REUTILIZAVEL
         and rownum = 1;
    exception
      when no_data_found then
        v_msg := t_message('Não foi encontrada nenhuma definição de Tipo de Caixa Reutilizável, para definir uma Caixa Reutilizável para o Packing é necessário definir uma caixa do tipo Caixa Reutilizável.');
        raise_application_error(-20000, v_msg.formatMessage);
        --        p_tipoRetorno := 1;
      --        return;
    end;
  
    begin
      select *
        into r_embalagem
        from embalagem e
       where e.barra = p_barra;
    exception
      when no_data_found then
        v_msg := t_message('Embalagem não encontrada');
        raise_application_error(-20000, v_msg.formatMessage);
        --        p_tipoRetorno := 2;
      --        return;
    end;
  
    validarDados;
  
    update confpacking cp
       set cp.alturacaixa             = r_embalagem.altura,
           cp.larguracaixa            = r_embalagem.largura,
           cp.comprimentocaixa        = r_embalagem.comprimento,
           cp.barracaixareutilizavel  = r_embalagem.barra,
           cp.idprodutocxreutilizavel = r_embalagem.idproduto,
           cp.idtipocaixa             = v_idTipoCaixaVolume
     where cp.id = p_idconfpacking;
  end;

  function definirCaixaVolAutoCheckout(p_idconfpacking in number)
    return boolean is
    C_TIPO_CX_PROPRIA constant number := 0;
  
    v_countCaixas         number;
    v_countCaixasProprias number;
    r_caixavolume         tipocaixavolume%rowtype;
    v_msg                 t_message;
  
    procedure validarDados is
      v_controlaCubagemVolume number;
      v_cubagemCaixaVolume    number;
      v_totalCubagemConferida number;
    begin
      select co.controlacubagemcaixavolume,
             nvl((select nvl(sum(p.qtde * e.altura * e.largura *
                                  e.comprimento), 0) cubagem
                    from confpacking c, produtoconfpacking p, embalagem e
                   where c.id = cp.id
                     and p.idconfpacking = c.id
                     and p.status = 1
                     and e.idproduto = p.idproduto
                     and e.barra = p.barra), 0) cubagemConferida
        into v_controlaCubagemVolume, v_totalCubagemConferida
        from confpacking cp, romaneiopai rp, notafiscal nf,
             configuracaoonda co, tipocaixavolume tcv
       where cp.id = p_idConfPacking
         and rp.idromaneio = cp.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and nf.idnotafiscal = cp.idnotafiscal
         and tcv.idtipocaixavolume(+) = cp.idtipocaixa;
    
      if (v_controlaCubagemVolume = 0) then
        return;
      end if;
    
      v_cubagemCaixaVolume := (nvl(r_caixavolume.altura, 0) *
                              nvl(r_caixavolume.largura, 0) *
                              nvl(r_caixavolume.comprimento, 0));
    
      if (v_cubagemCaixaVolume < v_totalCubagemConferida) then
        v_msg := t_message('A caixa de volume barra {0}' ||
                           ' não possui capacidade suficiente para ser utilizada nesta conferência.');
        v_msg.addParam(r_caixavolume.barra);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarDados;
  
  begin
    select count(1), sum(decode(t.tipo, C_TIPO_CX_PROPRIA, 1, 0))
      into v_countCaixas, v_countCaixasProprias
      from tipocaixavolume t
     where t.ativo = 1;
  
    if (v_countCaixas <> 1 or v_countCaixasProprias <> 1) then
      return false;
    end if;
  
    begin
      select t.*
        into r_caixavolume
        from tipocaixavolume t
       where t.tipo = C_TIPO_CX_PROPRIA
         and t.ativo = 1
         and rownum = 1;
    exception
      when no_data_found then
        v_msg := t_message('Não foi encontrada nenhuma definição de Tipo de Caixa Própria, para definir uma Caixa Própria para o Packing é necessário definir uma caixa do tipo Caixa Própria.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    validarDados;
  
    update confpacking cp
       set cp.alturacaixa      = r_caixavolume.altura,
           cp.larguracaixa     = r_caixavolume.largura,
           cp.comprimentocaixa = r_caixavolume.comprimento,
           cp.idtipocaixa      = r_caixavolume.idtipocaixavolume
     where cp.id = p_idconfpacking;
  
    update gtt_identificacaopacking gtt
       set gtt.idtipocaixa = r_caixavolume.idtipocaixavolume,
           gtt.tipocaixa   = C_TIPO_CX_PROPRIA;
  
    return true;
  end definirCaixaVolAutoCheckout;

  procedure definirCaixaVolume
  (
    p_idconfpacking in number,
    p_idtipocaixa   in number
  ) is
  
    procedure validarDados is
      v_controlaCubagemVolume number;
      v_cubagemCaixaVolume    number;
      v_totalCubagemConferida number;
      v_DescrCaixa            tipocaixavolume.descr%type;
      v_msg                   t_message;
    begin
      select co.controlacubagemcaixavolume,
             nvl((select nvl(sum(p.qtde * e.altura * e.largura *
                                  e.comprimento), 0) cubagem
                    from confpacking c, produtoconfpacking p, embalagem e
                   where c.id = cp.id
                     and p.idconfpacking = c.id
                     and p.status = 1
                     and e.idproduto = p.idproduto
                     and e.barra = p.barra), 0) cubagemConferida
        into v_controlaCubagemVolume, v_totalCubagemConferida
        from confpacking cp, romaneiopai rp, notafiscal nf,
             configuracaoonda co, tipocaixavolume tcv
       where cp.id = p_idConfPacking
         and rp.idromaneio = cp.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and nf.idnotafiscal = cp.idnotafiscal
         and tcv.idtipocaixavolume(+) = cp.idtipocaixa;
    
      if (v_controlaCubagemVolume = 0) then
        return;
      end if;
    
      begin
        select (nvl(tcv.altura, 0) * nvl(tcv.largura, 0) *
                nvl(tcv.comprimento, 0)) cubagemTipoCaixa, tcv.descr
          into v_cubagemCaixaVolume, v_DescrCaixa
          from tipocaixavolume tcv
         where tcv.idtipocaixavolume(+) = p_idtipocaixa;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada caixa de volume para o id informado. ID: {0}');
          v_msg.addParam(p_idtipocaixa);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
      if (v_cubagemCaixaVolume < v_totalCubagemConferida) then
        v_msg := t_message('A caixa de volume {0}' ||
                           ' não possui capacidade suficiente para ser utilizada neste conferência.');
        v_msg.addParam(v_DescrCaixa);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarDados;
  
  begin
    validarDados;
  
    update confpacking cp
       set cp.idtipocaixa             = p_idtipocaixa,
           cp.alturacaixa             = null,
           cp.larguracaixa            = null,
           cp.comprimentocaixa        = null,
           cp.barracaixareutilizavel  = null,
           cp.idprodutocxreutilizavel = null
     where cp.id = p_idconfpacking;
  end;

  procedure entrarBarraOuLoteConferencia
  (
    p_idconfpacking in number,
    p_barra         in varchar2,
    p_qtde          in number,
    p_idusuario     in number,
    p_checkout      in number := 0,
    p_solicitaEmb   in number := 0,
    p_solicitaQtde  in number := 0,
    p_solicitaCaixa in number := 0
  ) is
  
    PROD_ID_POR_EMBALAGEM   constant number := 0;
    PROD_ID_POR_LOTE        constant number := 1;
    PROD_ID_POR_INFO        constant number := 2;
    PROD_ID_POR_LTINDUSTRIA constant number := 3;
  
    C_RAST_TODA_MOVIMENTACAO constant number := 0;
    C_RAST_ENTRADA_SAIDA     constant number := 1;
    C_RAST_SOMENTE_SAIDA     constant number := 2;
  
    C_RET_COD_PRODUTO constant number := 0;
    C_RET_COD_LOTE    constant number := 1;
    C_INATIVO         constant varchar2(1) := 'N';
  
    C_FATOR_MAIOR_1_CX_FECHADA constant number := 0;
    C_CAIXA_FECHADA_CONF_SAIDA constant number := 1;
  
    C_CONFERENCIA_OK             constant number := 0;
    C_GERAR_VOLUME_CAIXA_FECHADA constant number := 22;
    C_GERAR_VOLUME_CHECKOUT      constant number := 23;
  
    C_CONFPACKING_NOTFOUND constant number := -20101;
    E_CONFPACKING_NOTFOUND EXCEPTION;
  
    C_USERCONF_DIVERGENTE constant number := -20102;
    E_USERCONF_DIVERGENTE EXCEPTION;
  
    C_EMBALAGEM_NOTFOUND constant number := -20103;
    E_EMBALAGEM_NOTFOUND EXCEPTION;
  
    C_EMBALAGEM_INATIVA constant number := -20104;
    E_EMBALAGEM_INATIVA EXCEPTION;
  
    C_NAO_IDENT_POR_LOTE constant number := -20105;
    E_NAO_IDENT_POR_LOTE EXCEPTION;
  
    C_NAO_E_PALETEFECHADO constant number := -20106;
    E_NAO_E_PALETEFECHADO EXCEPTION;
  
    E_PRODUTOCONF_NOTFOUND exception;
    C_PRODUTOCONF_NOTFOUND        constant number := -20107;
    C_PRODUTOCONF_CONFIRMAR_BARRA constant number := -20108;
  
    E_PRDCONF_NAOPOSSUIRESTQTDCONF exception;
    C_PRDCONF_NAOPOSSUIRESTQTDCONF constant number := -20109;
  
    E_INFORME_BARRAFATOR_UNIT exception;
    C_INFORME_BARRAFATOR_UNIT constant number := -20110;
  
    E_INFOESPEC_NAOPERTENCE_CONF exception;
    C_INFOESPEC_NAOPERTENCE_CONF constant number := -20111;
  
    E_SOLICITAR_INFOESPEC exception;
    C_SOLICITAR_INFOESPEC constant number := -20112;
  
    E_QTD_INFOESPEC_DIV_QTDE exception;
    C_QTD_INFOESPEC_DIV_QTDE constant number := -20113;
  
    E_SOLICITAR_QTDE exception;
    C_SOLICITAR_QTDE constant number := -20114;
  
    E_INFO_ESPEC_NAO_ENCONTRADA exception;
    C_INFO_ESPEC_NAO_ENCONTRADA constant number := -20115;
  
    E_INFO_ESPEC_JA_CONFERIDA exception;
    C_INFO_ESPEC_JA_CONFERIDA constant number := -20116;
  
    E_ERRO_QTDE_PROD_CONF exception;
    C_ERRO_QTDE_PROD_CONF constant number := -20117;
  
    E_ERRO_VALIDACAO_TIPO_CAIXA exception;
    C_ERRO_VALIDACAO_TIPO_CAIXA constant number := -20118;
  
    E_ERRO_QTDE_FRACIONADA exception;
    C_ERRO_QTDE_FRACIONADA constant number := -20119;
  
    E_SOLICITA_LOTE_INDUSTRIA exception;
    C_SOLICITA_LOTE_INDUSTRIA constant number := -20120;
  
    E_SOLICITA_VENCIMENTO exception;
    C_SOLICITA_VENCIMENTO constant number := -20121;
  
    E_SOLICITA_IDENTIFICADORPROD exception;
    C_SOLICITA_IDENTIFICADORPROD constant number := -20124;
  
    E_LOTE_IND_FORA_CONF exception;
    C_LOTE_IND_FORA_CONF constant number := -20125;
  
    E_ERRO_MONT_VOLUME exception;
    C_ERRO_MONT_VOLUME constant number := -20126;
  
    E_SOLICITA_QTDE_CAIXA_VOLUME exception;
    C_SOLICITA_QTDE_CAIXA_VOLUME constant number := -20127;
  
    E_VARIOS_LOTEINDUSTRIA exception;
    C_VARIOS_LOTEINDUSTRIA constant number := -20128;
  
    E_SOLICITAR_CONFCANCEL exception;
    C_SOLICITAR_CONFCANCEL constant number := -20129;
  
    E_SOLICITAR_CONFCANCEL_LOCAL exception;
    C_SOLICITAR_CONFCANCEL_LOCAL constant number := -20130;
  
    EXIBE_ALERTA_PACKING constant number := 1;
  
    C_TIPO_CONF_CODIGO_BARRAS    constant number := 0;
    C_TIPO_CONF_LOTE             constant number := 1;
    C_TIPO_CONF_LOTE_BARRAS      constant number := 2;
    C_TIPO_CONF_LOTE_CTRL_LT_IND constant number := 3;
  
    pragma exception_init(E_CONFPACKING_NOTFOUND, -20101);
    pragma exception_init(E_USERCONF_DIVERGENTE, -20102);
    pragma exception_init(E_EMBALAGEM_NOTFOUND, -20103);
    pragma exception_init(E_EMBALAGEM_INATIVA, -20104);
    pragma exception_init(E_NAO_IDENT_POR_LOTE, -20105);
    pragma exception_init(E_NAO_E_PALETEFECHADO, -20106);
    pragma exception_init(E_PRODUTOCONF_NOTFOUND, -20107);
    pragma exception_init(E_PRDCONF_NAOPOSSUIRESTQTDCONF, -20109);
    pragma exception_init(E_INFORME_BARRAFATOR_UNIT, -20110);
    pragma exception_init(E_INFOESPEC_NAOPERTENCE_CONF, -20111);
    pragma exception_init(E_SOLICITAR_INFOESPEC, -20112);
    pragma exception_init(E_QTD_INFOESPEC_DIV_QTDE, -20113);
    pragma exception_init(E_SOLICITAR_QTDE, -20114);
    pragma exception_init(E_INFO_ESPEC_NAO_ENCONTRADA, -20115);
    pragma exception_init(E_INFO_ESPEC_JA_CONFERIDA, -20116);
    pragma exception_init(E_ERRO_QTDE_PROD_CONF, -20117);
    pragma exception_init(E_ERRO_VALIDACAO_TIPO_CAIXA, -20118);
    pragma exception_init(E_ERRO_QTDE_FRACIONADA, -20119);
    pragma exception_init(E_SOLICITA_LOTE_INDUSTRIA, -20120);
    pragma exception_init(E_SOLICITA_VENCIMENTO, -20121);
    pragma exception_init(E_SOLICITA_IDENTIFICADORPROD, -20124);
    pragma exception_init(E_LOTE_IND_FORA_CONF, -20125);
    pragma exception_init(E_ERRO_MONT_VOLUME, -20126);
    pragma exception_init(E_SOLICITA_QTDE_CAIXA_VOLUME, -20127);
    pragma exception_init(E_VARIOS_LOTEINDUSTRIA, -20128);
    pragma exception_init(E_SOLICITAR_CONFCANCEL, -20129);
    pragma exception_init(E_SOLICITAR_CONFCANCEL_LOCAL, -20130);
  
    type t_barraPadrao128 is record(
      identificadorCodPrd  produto.codigointerno%type,
      identificadorProduto embalagem.barra%type,
      identificadorCaixa   varchar2(100),
      identificadorLote    lote.descr%type,
      identificadorLoteAd  lote.loteadicional%type,
      identificadorqtde    number,
      identificadorpeso    number,
      identificadorpesoLiq number,
      identificadorvenc    lote.dtvenc%type,
      identificadorfabric  lote.dtfabricacao%type);
  
    type t_conferencia is record(
      iddepositante                number,
      barraPadrao128               t_barraPadrao128,
      idenderecopacking            number,
      idarmazem                    number,
      codbarratarefa               confpacking.codbarratarefa%type,
      idonda                       number,
      idnotafiscal                 number,
      confcodbarrasprodnaopedido   number,
      conferenciacegapacking       number,
      autoconferirqtde             number,
      autoconferirqtdeUnit         number,
      tipoIdentificacaoProduto     number,
      confsaidaunitaria            number,
      idusuario                    number,
      limitaconfcegamaxqtdeproduto number,
      controlacubagemcaixavolume   number,
      alertatipocaixamontagem      number,
      idtipocaixa                  number,
      tipocaixavolume              number,
      cubagemCaixaVolume           number,
      ltIndustria                  lote.descr%type,
      totalCubagemConferida        number,
      dtVencimento                 lote.dtvenc%type,
      montvolautocxfchdapack       configuracaoonda.montvolautocxfchdapack%type,
      loteuniconovolume            produtodepositante.loteuniconovolume%type,
      checkout                     configuracaoonda.conferenciaporcheckoutexpress%type,
      idconfpacking                confpacking.id%type,
      tipoconferencia              configuracaoonda.tipoconferencia%type,
      permitemultiusuario          number,
      solicitaqtdecaixapacking     number,
      gerarvolumesautomaticamente  number,
      utzcaixafecft1geracaovolqtde number,
      validarCxFechadaPacking      configuracaoonda.validarCxFechadaPacking%type,
      tipovolumecaixafechada       configuracaoonda.tipovolumecaixafechada%type,
      seppkporestacao              number);
  
    r_embalagemConf embalagem%rowtype;
  
    v_loteIndustriaIdentificado lote.descr%type;
    v_loteVencimento            lote.dtvenc%type;
  
    v_identLoteIndustria number;
  
    r_estoqueInfo estoqueinformacaoespecifica%rowtype;
  
    r_conferencia        t_conferencia;
    r_produtoConferencia gtt_produtoConferencia%rowtype;
  
    v_resultado_conferencia number := C_CONFERENCIA_OK;
  
    v_pedeQuantidadeCaixa number := 0;
  
    v_qtde number;
  
    v_idlote lote.idlote%type := null;
  
    v_msg t_message;
  
    function isLoteIndNaConf
    (
      p_loteIndustria in varchar2,
      p_dtVencimento  in date
    ) return boolean is
    
      v_loteNaConf        number;
      v_loteComDataNaConf number;
    
    begin
      if (p_dtVencimento is not null and
         r_conferencia.tipoconferencia <> C_TIPO_CONF_LOTE_CTRL_LT_IND) then
        select count(1)
          into v_loteComDataNaConf
          from vt_tarefaprodconfpackloteunico vl, produtodepositante pd
         where vl.descrlote = upper(p_loteIndustria)
           and decode(pd.validarmesano, 0, vl.h$vencproduto,
                      last_day(vl.h$vencproduto)) =
               decode(pd.validarmesano, 0,
                      to_date(p_dtVencimento, 'dd/MM/yy'),
                      last_day(to_date(p_dtVencimento, 'dd/MM/yy')))
           and vl.h$idOnda = r_conferencia.idonda
           and vl.h$idPacking = r_conferencia.idenderecopacking
           and vl.h$idnotafiscal = r_conferencia.idnotafiscal
           and pd.identidade = r_conferencia.iddepositante
           and pd.idproduto = vl.h$idProduto;
      else
        select count(1)
          into v_loteNaConf
          from vt_tarefaprodconfpackloteunico vl
         where vl.descrlote = upper(p_loteIndustria)
           and vl.h$idOnda = r_conferencia.idonda
           and vl.h$idPacking = r_conferencia.idenderecopacking
           and vl.h$idnotafiscal = r_conferencia.idnotafiscal;
      end if;
    
      -- Avalia se o lote indústria está presente na conferência independente
      -- se foi conferido ou não
    
      if ((v_loteNaConf = 0) or
         (v_loteComDataNaConf = 0 and p_dtVencimento is not null)) then
        return false;
      else
        return true;
      end if;
    end isLoteIndNaConf;
  
    function getReturnNumber(p_returnNumber in number) return number is
    begin
      if (p_returnNumber > -20100) then
        return p_returnNumber;
      end if;
      return((p_returnNumber * (-1)) - 20100);
    end;
  
    procedure inserirRetorno is
    begin
      if (r_conferencia.tipoconferencia = C_TIPO_CONF_LOTE_CTRL_LT_IND) then
        if (r_produtoConferencia.Descreduzidaemb is not null and
           r_produtoconferencia.fatorconversaoembalagem is not null) then
          r_produtoConferencia.Descreduzidaemb := r_produtoConferencia.Descreduzidaemb ||
                                                  ' (Fator ' ||
                                                  r_produtoconferencia.fatorconversaoembalagem || ')';
        end if;
      
        if (r_produtoConferencia.Descricao is not null and
           r_embalagemConf.Barra is not null) then
          r_produtoConferencia.Descricao := r_produtoConferencia.Descricao ||
                                            ' - ( ' ||
                                            r_embalagemConf.Barra || ' )';
        end if;
      end if;
    
      insert into gtt_produtoConferencia
      values r_produtoConferencia;
    end inserirRetorno;
  
    function getMensagemRetorno
    (
      p_msg       in varchar2,
      p_resultado in number
    ) return varchar2 is
    
    begin
      return(replace(p_msg, 'ORA' || p_resultado || ': '));
    end getMensagemRetorno;
  
    procedure inserirDadosRetorno
    (
      p_Resultado in number,
      p_Msg       in varchar2
    ) is
    begin
      r_produtoConferencia.resultado                := getReturnNumber(p_Resultado);
      r_produtoConferencia.msgretorno               := getMensagemRetorno(p_Msg,
                                                                          p_Resultado);
      r_produtoConferencia.tipoidentificacaoproduto := r_conferencia.tipoIdentificacaoProduto;
      r_produtoConferencia.idconfpacking            := p_idconfpacking;
    
      inserirRetorno;
    end inserirDadosRetorno;
  
    procedure carregarConfPacking is
      row_locked EXCEPTION;
      PRAGMA EXCEPTION_INIT(row_locked, -54);
      r_confpacking confpacking%rowtype;
    begin
      select *
        into r_confpacking
        from confpacking cp
       where cp.id = p_idConfPacking
         for update nowait;
    
      if (r_confpacking.status = 2) then
        v_msg := t_message('A conferência atual do packing foi cancelada. Entre novamente e realize a conferência.');
        raise_application_error(C_CONFPACKING_NOTFOUND, v_msg.formatMessage);
      end if;
    
      select rp.idromaneio, nf.idnotafiscal, r_confpacking.idpacking,
             r_confpacking.codbarratarefa, co.controlacubagemcaixavolume,
             co.alertatipocaixavolpacking, co.conferenciacegapacking,
             nf.iddepositante, co.confsaidaunitaria,
             r_confpacking.idtipocaixa, r_confpacking.idusuario,
             nf.idarmazem, co.limitaconfcegamaxqtdeproduto,
             co.montvolautocxfchdapack, d.razaosocial,
             co.conferenciaporcheckoutexpress, r_confpacking.id,
             co.tipoconferencia, co.permitirconferirmultiusuario,
             de.solicitaqtdecaixapacking, de.gerarvolumesautomaticamente,
             de.utzcaixafecft1geracaovolqtde, co.validarcxfechadapacking,
             co.tipovolumecaixafechada, co.seppkporestacao
        into r_conferencia.idonda, r_conferencia.idnotafiscal,
             r_conferencia.idenderecopacking, r_conferencia.codbarratarefa,
             r_conferencia.controlacubagemcaixavolume,
             r_conferencia.alertatipocaixamontagem,
             r_conferencia.conferenciacegapacking,
             r_conferencia.iddepositante, r_conferencia.confsaidaunitaria,
             r_conferencia.idtipocaixa, r_conferencia.idusuario,
             r_conferencia.idarmazem,
             r_conferencia.limitaconfcegamaxqtdeproduto,
             r_conferencia.montvolautocxfchdapack,
             r_produtoConferencia.depositante, r_conferencia.checkout,
             r_conferencia.idconfpacking, r_conferencia.tipoconferencia,
             r_conferencia.permitemultiusuario,
             r_conferencia.solicitaqtdecaixapacking,
             r_conferencia.gerarvolumesautomaticamente,
             r_conferencia.utzcaixafecft1geracaovolqtde,
             r_conferencia.validarCxFechadaPacking,
             r_conferencia.tipovolumecaixafechada,
             r_conferencia.seppkporestacao
        from romaneiopai rp, notafiscal nf, configuracaoonda co, entidade d,
             depositante de
       where rp.idromaneio = r_confpacking.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and nf.idnotafiscal = r_confpacking.idnotafiscal
         and d.identidade = nf.iddepositante
         and nf.iddepositante = de.identidade
            -- Onda de OS não confere manualmente
         and not exists (select 1
                from ordemservico os
               where os.idromaneio = rp.idromaneio)
         and exists
       (select 1
                from movimentacao m
               where m.status in
                     (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                      STATUS_MOV_FINALIZADO)
                 and m.idonda = rp.idromaneio
                 and m.idnotafiscal = nf.idnotafiscal
                 and m.idlocaldestino = r_confpacking.idpacking);
    
      r_produtoConferencia.iddepositante  := r_conferencia.iddepositante;
      r_produtoConferencia.barraconferida := p_barra;
    
      select nvl(sum(p.qtde * e.altura * e.largura * e.comprimento), 0) cubagem
        into r_conferencia.totalCubagemConferida
        from produtoconfpacking p, embalagem e
       where p.idconfpacking = r_confpacking.id
         and p.status = 1
         and e.idproduto = p.idproduto
         and e.barra = p.barra;
    
      if (r_confpacking.idtipocaixa is not null) then
        select tcv.tipo,
               (nvl(tcv.altura, 0) * nvl(tcv.largura, 0) *
                nvl(tcv.comprimento, 0)) cubagemTipoCaixa
          into r_conferencia.tipocaixavolume,
               r_conferencia.cubagemCaixaVolume
          from tipocaixavolume tcv
         where tcv.idtipocaixavolume = r_confpacking.idtipocaixa;
      end if;
    exception
      when row_locked then
        v_msg := t_message('Já existe uma conferência sendo processada em seu packing. Favor tentar novamente a operação.');
        raise_application_error(-20000, v_msg.formatMessage);
      when no_data_found then
        v_msg := t_message('Não foi encontrada conferência pendente no packing para este identificador.');
        raise_application_error(C_CONFPACKING_NOTFOUND, v_msg.formatMessage);
    end carregarConfPacking;
  
    procedure extrairBarraPadrao128 is
      IDENTIFICADOR_PRODUTO  constant varchar2(3) := '01';
      IDENTIFICADOR_LOTE     constant varchar2(3) := '10';
      IDENTIFICADOR_QTDE     constant varchar2(2) := '30';
      IDENTIFICADOR_PESO     constant varchar2(4) := '310x';
      IDENTIFICADOR_VENC     constant varchar2(2) := '17';
      IDENTIFICADOR2_PRODUTO constant varchar2(3) := '240';
    
      v_resuladoCode128 number;
      PADRAO_CODE_128 constant number := 1;
    
      v_dtVencimento varchar2(6);
    begin
      v_resuladoCode128 := pk_utilities.extrairCODE128(p_barra,
                                                       r_conferencia.iddepositante,
                                                       null,
                                                       r_conferencia.barraPadrao128.identificadorCodPrd,
                                                       r_conferencia.barraPadrao128.identificadorProduto,
                                                       r_conferencia.barraPadrao128.identificadorCaixa,
                                                       r_conferencia.barraPadrao128.identificadorqtde,
                                                       r_conferencia.barraPadrao128.identificadorLote,
                                                       r_conferencia.barraPadrao128.identificadorLoteAd,
                                                       r_conferencia.barraPadrao128.identificadorvenc,
                                                       r_conferencia.barraPadrao128.identificadorfabric,
                                                       r_conferencia.barraPadrao128.identificadorpeso,
                                                       r_conferencia.barraPadrao128.identificadorpesoLiq);
    
      if (v_resuladoCode128 != PADRAO_CODE_128 or
         r_conferencia.barraPadrao128.identificadorProduto is null) then
      
        select nvl(replace(regexp_substr(p_barra,
                                          '(\(' || IDENTIFICADOR_PRODUTO ||
                                           '\))([_0-9a-zA-Z\.\,\-]+)'),
                            '(' || IDENTIFICADOR_PRODUTO || ')'),
                    replace(regexp_substr(p_barra,
                                           '(\(' || IDENTIFICADOR2_PRODUTO ||
                                            '\))([_0-9a-zA-Z\.\,\-]+)'),
                             '(' || IDENTIFICADOR2_PRODUTO || ')')),
               replace(regexp_substr(p_barra,
                                      '(\(' || IDENTIFICADOR_LOTE ||
                                       '\))([_0-9a-zA-Z*\.\,\* \*/\-]+)'),
                        '(' || IDENTIFICADOR_LOTE || ')'),
               to_number(replace(replace(regexp_substr(p_barra,
                                                        '(\(' ||
                                                         IDENTIFICADOR_QTDE ||
                                                         '\))([_0-9a-zA-Z\.\,\-]+)'),
                                          '(' || IDENTIFICADOR_QTDE || ')'),
                                  '.', ',')),
               replace(regexp_substr(p_barra,
                                      '(\(' || IDENTIFICADOR_VENC ||
                                       '\))([_0-9a-zA-Z\.\,\-]+)'),
                        '(' || IDENTIFICADOR_VENC || ')'),
               replace(regexp_substr(p_barra,
                                      '(\(' || IDENTIFICADOR_PESO ||
                                       '\))([_0-9a-zA-Z\.\,\-]+)'),
                        '(' || IDENTIFICADOR_PESO || ')')
          into r_conferencia.barraPadrao128.identificadorProduto,
               r_conferencia.barraPadrao128.identificadorLote,
               r_conferencia.barraPadrao128.identificadorqtde,
               v_dtVencimento,
               r_conferencia.barraPadrao128.identificadorpeso
          from dual;
      
        select to_date(decode(substr(v_dtVencimento,
                                      length(v_dtVencimento) - 1,
                                      length(v_dtVencimento)), '00',
                               substr(v_dtVencimento, 0,
                                       length(v_dtVencimento) - 2) ||
                                to_char(extract(day from
                                                last_day(to_date(substr(v_dtVencimento,
                                                                        0,
                                                                        length(v_dtVencimento) - 2) || '01',
                                                                 'YYMMDD')))),
                               v_dtVencimento), 'YYMMDD')
          into r_conferencia.barraPadrao128.identificadorvenc
          from dual;
      end if;
    
      if (r_conferencia.tipoconferencia in
         (C_TIPO_CONF_LOTE, C_TIPO_CONF_LOTE_BARRAS,
           C_TIPO_CONF_LOTE_CTRL_LT_IND)) then
        r_conferencia.ltIndustria  := r_conferencia.barraPadrao128.identificadorLote;
        r_conferencia.dtVencimento := r_conferencia.barraPadrao128.identificadorvenc;
      
      end if;
    
      if (r_conferencia.barraPadrao128.identificadorProduto is not null) then
        r_conferencia.autoconferirqtde := nvl(r_conferencia.barraPadrao128.identificadorqtde,
                                              0) + nvl(r_conferencia.barraPadrao128.identificadorpeso,
                                                       0);
      end if;
    
    end extrairBarraPadrao128;
  
    procedure identificarPorLoteUnicoVolume
    (
      p_barra     in varchar2,
      p_tipoBarra in number
    ) is
      v_coletaLtInd      produtodepositante.coletaloteindust%type;
      v_coletaVencimento produtodepositante.coletadtavenclote%type;
    begin
      begin
        select distinct pd.loteuniconovolume
          into r_conferencia.loteuniconovolume
          from confpacking c, movimentacao m, lote l, produtodepositante pd,
               embalagem e
         where c.id = p_idConfPacking
           and m.idnotafiscal = c.idnotafiscal
           and m.status in (STATUS_MOV_EXECUTANDO, STATUS_MOV_FINALIZADO)
           and l.idlote = m.idlote
           and pd.identidade = l.iddepositante
           and pd.idproduto = l.idproduto
           and e.idproduto = pd.idproduto
           and (e.barra = nvl(r_conferencia.barraPadrao128.identificadorProduto,
                              p_barra) or
               l.descr = nvl(r_conferencia.barraPadrao128.identificadorLote,
                              decode(p_tipoBarra, PROD_ID_POR_LTINDUSTRIA,
                                      p_barra, null)));
      exception
        when no_data_found then
          return;
        when too_many_rows then
          begin
            select distinct pd.loteuniconovolume
              into r_conferencia.loteuniconovolume
              from confpacking c, movimentacao m, lote l,
                   produtodepositante pd, embalagem e
             where c.id = p_idConfPacking
               and m.idnotafiscal = c.idnotafiscal
               and m.status in
                   (STATUS_MOV_EXECUTANDO, STATUS_MOV_FINALIZADO)
               and l.idlote = m.idlote
               and pd.identidade = l.iddepositante
               and pd.idproduto = l.idproduto
               and e.idproduto = pd.idproduto
               and (e.barra = nvl(r_conferencia.barraPadrao128.identificadorProduto,
                                  p_barra) and
                   l.descr = nvl(r_conferencia.barraPadrao128.identificadorLote,
                                  decode(p_tipoBarra, PROD_ID_POR_LTINDUSTRIA,
                                          p_barra, null)));
          exception
            when no_data_found then
              return;
          end;
      end;
    
      if (r_conferencia.loteuniconovolume = 0) then
        return;
      end if;
    
      r_conferencia.tipoIdentificacaoProduto := p_tipoBarra;
    
      if (r_conferencia.barraPadrao128.identificadorLote is null and
         p_tipoBarra = PROD_ID_POR_LTINDUSTRIA) then
        r_conferencia.barraPadrao128.identificadorLote := p_barra;
      end if;
    
      if (r_conferencia.barraPadrao128.identificadorProduto is null and
         p_tipoBarra = PROD_ID_POR_EMBALAGEM) then
        r_conferencia.barraPadrao128.identificadorProduto := p_barra;
      end if;
    
      begin
        select distinct e.*
          into r_embalagemConf
          from confpacking c, movimentacao m, lote l, embalagem e
         where c.id = p_idConfPacking
           and c.status = C_STATUS_EM_CONTAGEM
           and m.idlocaldestino = c.idpacking
           and m.idonda = c.idonda
           and m.status = STATUS_MOV_FINALIZADO
           and m.idnotafiscal = c.idnotafiscal
           and l.idlote = m.idlote
           and e.barra =
               decode(r_conferencia.barraPadrao128.identificadorProduto,
                      null,
                      pk_produto.RetornarCodBarraMenorFator(l.idproduto),
                      r_conferencia.barraPadrao128.identificadorProduto)
           and decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', l.descr) =
               decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', r_conferencia.barraPadrao128.identificadorLote)
           and e.idproduto = l.idproduto;
      
        select pd.coletaloteindust, pd.coletadtavenclote
          into v_coletaLtInd, v_coletaVencimento
          from produtodepositante pd
         where pd.idproduto = r_embalagemConf.idproduto
           and exists (select 1
                  from confpacking c, notafiscal nf
                 where c.id = p_idConfPacking
                   and nf.idnotafiscal = c.idnotafiscal
                   and nf.iddepositante = pd.identidade);
      
        -- Validação para garantir que sempre vai solicitar vencimento
        -- caso a barra bipada seja EAN13 e o produto colete uma das duas informações
        if (r_conferencia.barraPadrao128.identificadorLote is null and
           r_conferencia.barraPadrao128.identificadorvenc is null and
           p_tipoBarra = PROD_ID_POR_EMBALAGEM)
           and (v_coletaVencimento = 1 or v_coletaLtInd = 'S') then
        
          r_produtoConferencia.idproduto := r_embalagemConf.idproduto;
        
          v_msg := t_message('Solicitar Vencimento');
          raise_application_error(C_SOLICITA_VENCIMENTO,
                                  v_msg.formatMessage);
        end if;
      
        return;
      exception
        when no_data_found then
          return;
        when too_many_rows then
        
          r_produtoConferencia.idproduto := r_embalagemConf.idproduto;
        
          if (r_conferencia.barraPadrao128.identificadorLote is null) then
            v_msg := t_message('Solicitar Lote Indústria');
            raise_application_error(C_SOLICITA_LOTE_INDUSTRIA,
                                    v_msg.formatMessage);
          end if;
      end;
    
      begin
        select e.*
          into r_embalagemConf
          from confpacking c, movimentacao m, lote l, embalagem e
         where c.id = p_idConfPacking
           and c.status = C_STATUS_EM_CONTAGEM
           and m.idlocaldestino = c.idpacking
           and m.idonda = c.idonda
           and m.status = STATUS_MOV_FINALIZADO
           and m.idnotafiscal = c.idnotafiscal
           and m.qtdeconferida <> m.qtdeemvolume
           and l.idlote = m.idlote
           and e.barra =
               decode(r_conferencia.barraPadrao128.identificadorProduto,
                      null,
                      pk_produto.RetornarCodBarraMenorFator(l.idproduto),
                      r_conferencia.barraPadrao128.identificadorProduto)
           and decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', l.descr) =
               decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', r_conferencia.barraPadrao128.identificadorLote)
           and decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                      sysdate, l.dtvenc) =
               decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                      sysdate, r_conferencia.barraPadrao128.identificadorvenc)
              
           and e.idproduto = l.idproduto
              -- Caso a data for informada e ainda sim retornar mais de 1 pega o primeiro lote
           and decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                      1, rownum) = 1;
      exception
        when no_data_found then
          if (r_conferencia.conferenciacegapacking = 0) then
            return;
          else
            begin
              select e.*
                into r_embalagemConf
                from confpacking c, movimentacao m, lote l, embalagem e
               where c.id = p_idConfPacking
                 and c.status = C_STATUS_EM_CONTAGEM
                 and m.idlocaldestino = c.idpacking
                 and m.idonda = c.idonda
                 and m.status = STATUS_MOV_FINALIZADO
                 and m.idnotafiscal = c.idnotafiscal
                 and l.idlote = m.idlote
                 and e.barra =
                     decode(r_conferencia.barraPadrao128.identificadorProduto,
                            null,
                            pk_produto.RetornarCodBarraMenorFator(l.idproduto),
                            r_conferencia.barraPadrao128.identificadorProduto)
                 and decode(r_conferencia.barraPadrao128.identificadorLote,
                            null, '-1', l.descr) =
                     decode(r_conferencia.barraPadrao128.identificadorLote,
                            null, '-1',
                            r_conferencia.barraPadrao128.identificadorLote)
                 and decode(r_conferencia.barraPadrao128.identificadorvenc,
                            null, sysdate, l.dtvenc) =
                     decode(r_conferencia.barraPadrao128.identificadorvenc,
                            null, sysdate,
                            r_conferencia.barraPadrao128.identificadorvenc)
                    
                 and e.idproduto = l.idproduto
                    -- Caso a data for informada e ainda sim retornar mais de 1 pega o primeiro lote
                 and decode(r_conferencia.barraPadrao128.identificadorvenc,
                            null, 1, rownum) = 1;
            exception
              when no_data_found then
                return;
              when too_many_rows then
                if (r_conferencia.barraPadrao128.identificadorvenc is null) then
                  v_msg := t_message('Solicitar Vencimento');
                  raise_application_error(C_SOLICITA_VENCIMENTO,
                                          v_msg.formatMessage);
                end if;
            end;
          end if;
        when too_many_rows then
          if (r_conferencia.barraPadrao128.identificadorvenc is null) then
            v_msg := t_message('Solicitar Vencimento');
            raise_application_error(C_SOLICITA_VENCIMENTO,
                                    v_msg.formatMessage);
          end if;
      end;
    
      begin
        select e.*
          into r_embalagemConf
          from confpacking c, movimentacao m, lote l, embalagem e
         where c.id = p_idConfPacking
           and c.status = C_STATUS_EM_CONTAGEM
           and m.idlocaldestino = c.idpacking
           and m.idonda = c.idonda
           and m.status = STATUS_MOV_FINALIZADO
           and m.idnotafiscal = c.idnotafiscal
           and m.qtdeconferida <> m.qtdeemvolume
           and l.idlote = m.idlote
           and e.barra =
               decode(r_conferencia.barraPadrao128.identificadorProduto,
                      null,
                      pk_produto.RetornarCodBarraMenorFator(l.idproduto),
                      r_conferencia.barraPadrao128.identificadorProduto)
           and decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', l.descr) =
               decode(r_conferencia.barraPadrao128.identificadorLote, null,
                      '-1', r_conferencia.barraPadrao128.identificadorLote)
           and decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                      sysdate, l.dtvenc) =
               decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                      sysdate, r_conferencia.barraPadrao128.identificadorvenc)
              
           and e.idproduto = l.idproduto
           and e.barra = l.barra
           and rownum = 1;
      exception
        when no_data_found then
          return;
        when too_many_rows then
          v_msg := t_message('Solicitar Embalagem');
          raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                  v_msg.formatMessage);
      end;
    end identificarPorLoteUnicoVolume;
  
    procedure validarUsuarioConferencia is
    begin
      if (r_conferencia.idusuario <> p_idUsuario and
         r_conferencia.permitemultiusuario < MULTI_USUARIO_CONF_CHECKOUT) then
        v_msg := t_message('Usuário que está realizando a conferência de produto é diferente do que começou a conferir este identificador. IdUsuario Informado: {0}' ||
                           ', IdUsuario que está conferindo este identificador: {1}');
        v_msg.addParam(p_idusuario);
        v_msg.addParam(r_conferencia.idusuario);
        raise_application_error(C_USERCONF_DIVERGENTE, v_msg.formatMessage);
      end if;
    end validarUsuarioConferencia;
  
    function qtdePendenteConfLotInd(p_idproduto number) return number is
      v_qtdeMovimentacao number;
      v_qtdeConferida    number;
    begin
      if (r_conferencia.tipoconferencia <> C_TIPO_CONF_LOTE_CTRL_LT_IND) then
        return 0;
      end if;
    
      select nvl(sum(m.quantidade), 0)
        into v_qtdeMovimentacao
        from movimentacao m, lote lt, produtodepositante pd
       where 1 = 1
         and lt.idlote = m.idlote
         and pd.idproduto = lt.idproduto
         and pd.identidade = lt.iddepositante
         and pd.coletaloteindust = 'S'
         and lt.descr is not null
         and m.status <> STATUS_MOV_CANCELADO
         and m.idnotafiscal = r_conferencia.idnotafiscal
         and m.idonda = r_conferencia.idonda
         and lt.idproduto = p_idproduto;
    
      select nvl(sum(pc.qtde * e.fatorconversao), 0)
        into v_qtdeConferida
        from confpacking cp, produtoconfpacking pc, notafiscal nf,
             produtodepositante pd2, embalagem e
       where 1 = 1
         and pc.idconfpacking = cp.id
         and nf.idnotafiscal = cp.idnotafiscal
         and pd2.idproduto = pc.idproduto
         and pd2.identidade = nf.iddepositante
         and e.idproduto = pc.idproduto
         and e.barra = pc.barra
         and pd2.coletaloteindust = 'S'
         and pc.loteindustria is not null
         and pc.status = 1
         and cp.status <> C_STATUS_CANCELADO
         and cp.idnotafiscal = r_conferencia.idnotafiscal
         and cp.idonda = r_conferencia.idonda
         and pc.idproduto = p_idproduto;
    
      return v_qtdeMovimentacao - v_qtdeConferida;
    
    end qtdePendenteConfLotInd;
  
    procedure conferenciaPorBarra is
      v_barraEncontrada varchar(3000);
      v_codProduto      varchar2(50);
      v_barraProduto    varchar2(50);
      v_qtdAux          number;
      v_loteIndustria   varchar2(50);
      v_dtVencimento    date;
      v_qtdeRegra       number;
      v_coletaLtInd     produtodepositante.coletaloteindust%type;
    
      procedure identificarPorPaletFechado is
        v_qtdeEntrada number;
        v_barraLote   lote.barra%type;
        v_estoque     number;
        v_idlote      number;
      begin
        extrairBarraPadrao128;
      
        begin
          select (lt.qtdeentrada * e.fatorconversao), lt.barra
            into v_qtdeEntrada, v_barraLote
            from lote lt, embalagem e
           where lt.idlote =
                 nvl(r_conferencia.barraPadrao128.identificadorLote, p_barra)
             and e.barra = lt.barra;
        exception
          when no_data_found then
            return;
        end;
      
        begin
          select ll.estoque
            into v_estoque
            from lotelocal ll
           where ll.idlote = v_idlote;
        exception
          when no_data_found then
            v_estoque := 0;
        end;
      
        if (v_estoque <> v_qtdeEntrada) then
          v_msg := t_message('Este lote não é um palet fechado, utilize a barra do produto');
          raise_application_error(C_NAO_E_PALETEFECHADO,
                                  v_msg.formatMessage);
        end if;
      
        select *
          into r_embalagemConf
          from embalagem e
         where e.barra = v_barraLote;
      
        if (r_conferencia.autoconferirqtde is null) then
          r_conferencia.autoconferirqtde := v_qtdeEntrada;
        end if;
      
        r_produtoConferencia.descreduzidaemb         := r_embalagemConf.descrreduzido;
        r_produtoConferencia.fatorconversaoembalagem := r_embalagemConf.fatorconversao;
        r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_LOTE;
      end identificarPorPaletFechado;
    
      procedure identificarPorLoteInterno is
      begin
        extrairBarraPadrao128;
      
        if (pk_utilities.isNumber(nvl(r_conferencia.barraPadrao128.identificadorLote,
                                      p_barra)) = false) then
          return;
        end if;
      
        begin
          select e.*
            into r_embalagemConf
            from lote lt, embalagem e, produto p
           where lt.idlote =
                 nvl(r_conferencia.barraPadrao128.identificadorLote, p_barra)
             and e.barra = lt.barra
             and lt.idproduto = p.idproduto
             and p.pesavel = 1;
        exception
          when no_data_found then
            return;
          when others then
            begin
              select e.*
                into r_embalagemConf
                from lote lt, embalagem e, produto p
               where to_char(lt.idlote) =
                     to_char(nvl(r_conferencia.barraPadrao128.identificadorLote,
                                 p_barra))
                 and e.barra = lt.barra
                 and lt.idproduto = p.idproduto
                 and p.pesavel = 1;
            exception
              when no_data_found then
                return;
            end;
        end;
      end identificarPorLoteInterno;
    
      procedure identificarPorInfoEspecifica is
      begin
        if (r_embalagemConf.barra is not null) then
          return;
        end if;
      
        begin
          select e.idproduto, e.identificadorinfo, e.idlote,
                 e.idinfomaterial, e.valor
            into r_estoqueInfo.idproduto, r_estoqueInfo.identificadorInfo,
                 r_estoqueinfo.idlote, r_estoqueinfo.idinfomaterial,
                 r_estoqueinfo.valor
            from estoqueinformacaoespecifica e, informacaomatdep im
           where e.valor = upper(p_barra)
             and e.expedida = 0
             and e.conferido = 0
             and e.identidade = r_conferencia.iddepositante
             and im.idinfomaterial = e.idinfomaterial
             and im.identidade = e.identidade
             and im.idproduto = e.idproduto
             and im.valorunico = 'S'
             and exists
           (select 1
                    from movimentacao m, lote lt
                   where m.idonda = r_conferencia.idonda
                     and m.idnotafiscal = r_conferencia.idnotafiscal
                     and m.idlocaldestino = r_conferencia.idenderecopacking
                     and m.status in
                         (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                          STATUS_MOV_FINALIZADO)
                     and lt.idlote = m.idlote
                     and lt.idproduto = e.idproduto);
        exception
          when no_data_found then
            return;
        end;
      
        insert into gtt_infespecconfpacking
          (idproduto, idinfomaterial, valor)
        values
          (r_estoqueinfo.idproduto, r_estoqueinfo.idinfomaterial,
           upper(r_estoqueinfo.valor));
      
        if (r_estoqueinfo.idlote is not null) then
          select e.*
            into r_embalagemConf
            from embalagem e, lote lt
           where e.idproduto = lt.idproduto
             and e.barra = lt.barra
             and lt.idlote = r_estoqueinfo.idlote;
        
          r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_INFO;
          r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
          r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
          return;
        end if;
      
        begin
          select e.*
            into r_embalagemConf
            from embalagem e
           where e.idproduto = r_estoqueInfo.idproduto
             and e.fatorconversao = 1
             and e.ativo = 'S'
             and rownum = 1;
        exception
          when no_data_found then
            v_msg := t_message('Ao buscar uma embalagem para o produto id {0}' ||
                               ' para a conferência atual onde foi informada a informação específica única {1}' ||
                               ' não foi encontrada nenhuma embalagem de fator 1 ativa.');
            v_msg.addParam(r_estoqueInfo.idproduto);
            v_msg.addParam(r_estoqueInfo.Valor);
            raise_application_error(C_EMBALAGEM_NOTFOUND,
                                    v_msg.formatMessage);
        end;
      
        r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
        r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
        r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_INFO;
      end identificarPorInfoEspecifica;
    
    begin
      v_barraEncontrada := null;
    
      if (r_conferencia.barraPadrao128.identificadorProduto is not null) then
        v_barraEncontrada := r_conferencia.barraPadrao128.identificadorProduto;
      end if;
    
      if (r_conferencia.tipoconferencia in
         (C_TIPO_CONF_LOTE, C_TIPO_CONF_LOTE_BARRAS,
           C_TIPO_CONF_LOTE_CTRL_LT_IND)) then
        if (r_conferencia.barraPadrao128.identificadorLote is not null) then
          v_identLoteIndustria        := 1;
          v_loteIndustria             := r_conferencia.barraPadrao128.identificadorLote;
          v_loteIndustriaIdentificado := r_conferencia.barraPadrao128.identificadorLote;
        end if;
      
        if (r_conferencia.barraPadrao128.identificadorvenc is not null) then
          v_dtVencimento   := r_conferencia.barraPadrao128.identificadorvenc;
          v_loteVencimento := r_conferencia.barraPadrao128.identificadorvenc;
        end if;
      end if;
    
      if (p_qtde is not null and
         nvl(r_conferencia.barraPadrao128.identificadorqtde, 0) = 0) then
        v_qtde := p_qtde;
      elsif (p_qtde is not null and
            nvl(r_conferencia.barraPadrao128.identificadorqtde, 0) > 0) then
        v_qtde := r_conferencia.barraPadrao128.identificadorqtde;
      elsif (p_qtde is null and
            nvl(r_conferencia.barraPadrao128.identificadorqtde, 0) > 0) then
        v_qtde := r_conferencia.barraPadrao128.identificadorqtde;
      end if;
    
      --Identifica Inicialmente pela barra
      if (v_barraEncontrada is null) then
        v_barraEncontrada := pk_produto.retCodSeparadoBarraProdLoteMap(p_barra,
                                                                       r_conferencia.iddepositante,
                                                                       C_RET_COD_PRODUTO,
                                                                       v_identLoteIndustria,
                                                                       v_loteIndustriaIdentificado,
                                                                       v_loteVencimento,
                                                                       null,
                                                                       null,
                                                                       v_qtdeRegra);
      
        if (v_barraEncontrada is not null) then
          v_loteIndustria := v_loteIndustriaIdentificado;
          v_dtVencimento  := v_loteVencimento;
        end if;
      end if;
    
      -- Verificar se a barra digitada é diferente da barra encontrada, se a quantidade é nula
      -- e se não foi encontrada a barra do produto através da GS1
      if (v_barraEncontrada is not null and v_barraEncontrada <> p_barra and
         p_qtde is null and
         r_conferencia.barraPadrao128.identificadorProduto is null) then
        -- Se as barras forem diferentes e não possui GS1 é porque foi utilzada uma regra de
        -- código de barra do depositante, então retorna a quantidade se houver na barra
        if (pk_depositante.getDadosBarraRegraDepositante(r_conferencia.iddepositante,
                                                         p_barra,
                                                         v_codProduto,
                                                         v_barraProduto,
                                                         v_qtdAux,
                                                         v_loteIndustria,
                                                         v_dtVencimento) = 1 and
           v_qtdAux is not null and v_qtdAux > 0) then
          v_qtde := v_qtdAux;
        end if;
      end if;
    
      --se o tipo de conferencia for 2 (Barra e Lote Indústria), e o lote indústria não tiver sido informado,
      --e a barra foi encontrada, e o produto coleta lote industria
      if (r_conferencia.tipoconferencia in
         (C_TIPO_CONF_LOTE_BARRAS, C_TIPO_CONF_LOTE_CTRL_LT_IND) and
         v_loteIndustria is null and v_barraEncontrada is not null) then
        select pd.coletaloteindust
          into v_coletaLtInd
          from produtodepositante pd
         where exists (select 1
                  from embalagem e
                 where e.barra = v_barraEncontrada
                   and e.idproduto = pd.idproduto)
           and exists
         (select 1
                  from notafiscal nf
                 where nf.idnotafiscal = r_conferencia.idnotafiscal
                   and nf.iddepositante = pd.identidade);
      
        if (v_coletaLtInd = 'S') then
          select p.idproduto
            into r_produtoConferencia.idproduto
            from produto p
           where exists (select 1
                    from embalagem e
                   where e.barra = v_barraEncontrada
                     and e.idproduto = p.idproduto);
        
          if (r_conferencia.tipoconferencia = C_TIPO_CONF_LOTE_CTRL_LT_IND) then
            if (p_solicitaEmb = 0 and
               qtdePendenteConfLotInd(r_produtoConferencia.Idproduto) > 0) then
              v_msg := t_message('É obrigatório identificar esse produto pelo Lote Indústria. O Lote indústria {0} não foi encontrado ou não foi separado.');
              v_msg.addParam(p_barra);
              raise_application_error(C_NAO_IDENT_POR_LOTE,
                                      v_msg.formatMessage);
            end if;
          else
            v_msg := t_message('Solicitar Lote Indústria');
            raise_application_error(C_SOLICITA_LOTE_INDUSTRIA,
                                    v_msg.formatMessage);
          
          end if;
        end if;
      end if;
    
      if (v_loteIndustria is not null) then
        if (isLoteIndNaConf(v_loteIndustria, v_dtVencimento)) then
          r_produtoConferencia.Descrloteidentificado     := upper(v_loteIndustriaIdentificado);
          r_conferencia.barraPadrao128.identificadorvenc := v_dtVencimento;
        else
          v_msg := t_message('O Lote Indústria ou Data de Vencimento identificado não pertence à esta conferência.');
          raise_application_error(C_LOTE_IND_FORA_CONF, v_msg.formatMessage);
          return;
        end if;
      end if;
    
      -- Validação necessária para quando a barra é de regra de depositante
      if (v_loteIndustriaIdentificado is not null) then
        r_conferencia.barraPadrao128.identificadorLote := upper(v_loteIndustriaIdentificado);
      end if;
    
      identificarPorLoteUnicoVolume(v_barraEncontrada,
                                    PROD_ID_POR_EMBALAGEM);
      if (r_embalagemConf.Barra is not null) then
        v_barraEncontrada                            := r_embalagemConf.Barra;
        r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
        r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
        r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_EMBALAGEM;
        return;
      end if;
    
      identificarPorLoteInterno;
      if (r_embalagemConf.Barra is not null) then
        r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
        r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
        r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_LOTE;
        return;
      end if;
    
      if (v_barraEncontrada is not null) then
        begin
          select e.*
            into r_embalagemConf
            from embalagem e
           where e.barra = nvl(r_conferencia.barraPadrao128.identificadorProduto,
                               v_barraEncontrada);
        
          r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
          r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
          r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_EMBALAGEM;
        
          -- Já encontrou a embalagem
          return;
        exception
          when no_data_found then
            v_msg := t_message('Não foi encontrada nenhuma embalagem para a barra informada.' ||
                               chr(13) || ' Barra: {0}');
            v_msg.addParam(p_barra);
            raise_application_error(C_EMBALAGEM_NOTFOUND,
                                    v_msg.formatMessage);
        end;
      end if;
    
      --se foi escaneada informação numérica, verifica se foi o lote
      if pk_utilities.soNumero(p_barra) = p_barra then
        identificarPorPaletFechado;
      end if;
    
      if (r_embalagemConf.Barra is not null) then
        --Caso tenha encontrado por ID do Lote retorna;
        return;
      end if;
    
      --Em último caso tentará encontrar por valor de info específica.
      identificarPorInfoEspecifica;
    end conferenciaPorBarra;
  
    procedure conferenciaPorLoteIndustria is
      v_qtdAux           number;
      v_codProduto       produto.codigointerno%type;
      v_barraDummy       embalagem.barra%type;
      v_qtdeRegra        number;
      r_embalagemLoteInd embalagem%rowtype;
    begin
      if (r_embalagemConf.Barra is not null) then
        r_produtoConferencia.Descreduzidaemb   := r_embalagemConf.Descrreduzido;
        r_conferencia.tipoIdentificacaoProduto := PROD_ID_POR_LTINDUSTRIA;
        return;
      end if;
    
      begin
        select distinct lt.descr,
                        decode(r_conferencia.tipoconferencia, 1,
                                pk_produto.RetornarCodBarraMenorFator(lt.idproduto),
                                lt.barra) barra
          into v_loteIndustriaIdentificado, r_embalagemConf.Barra
          from confpacking c, notafiscal nf, nfdet nd, lote lt,
               produtodepositante pd, embalagem e, movimentacao m
         where c.id = p_idconfpacking
           and nf.idnotafiscal = c.idnotafiscal
           and nd.nf = nf.idnotafiscal
           and lt.idproduto = nd.idproduto
           and (upper(lt.descr) = upper(p_barra) or
               (upper(lt.descr) = upper(r_conferencia.ltIndustria)))
           and pd.identidade = lt.iddepositante
           and pd.idproduto = lt.idproduto
           and pd.coletaloteindust =
               decode(r_conferencia.tipoconferencia,
                      C_TIPO_CONF_LOTE_CTRL_LT_IND, 'S', pd.coletaloteindust)
           and e.idproduto(+) = lt.idproduto
           and e.barra(+) =
               nvl(r_conferencia.barraPadrao128.identificadorProduto, '')
           and lt.fatorconversao = nvl(e.fatorconversao, 1)
           and m.idnotafiscal = nf.idnotafiscal
           and m.idlote = lt.idlote;
      exception
        when no_data_found then
          begin
            --verificando se foi escaneado diretamente o lote indústria
            select distinct lt.descr,
                            decode(r_conferencia.tipoconferencia, 1,
                                    pk_produto.RetornarCodBarraMenorFator(lt.idproduto),
                                    lt.barra) barra
              into v_loteIndustriaIdentificado, r_embalagemConf.Barra
              from confpacking c, notafiscal nf, movimentacao m, lote lt,
                   produtodepositante pd
             where c.id = p_idconfpacking
               and nf.idnotafiscal = c.idnotafiscal
               and m.idnotafiscal = nf.idnotafiscal
               and lt.idlote = m.idlote
               and (upper(lt.descr) = upper(p_barra) or
                   (upper(lt.descr) = upper(r_conferencia.ltIndustria)))
               and pd.identidade = lt.iddepositante
               and pd.idproduto = lt.idproduto
               and pd.coletaloteindust =
                   decode(r_conferencia.tipoconferencia,
                          C_TIPO_CONF_LOTE_CTRL_LT_IND, 'S',
                          pd.coletaloteindust);
          exception
            when no_data_found then
              if (r_conferencia.tipoconferencia =
                 C_TIPO_CONF_LOTE_CTRL_LT_IND) then
                conferenciaPorBarra;
                return;
              end if;
            
              v_loteIndustriaIdentificado := null;
              r_embalagemConf.Barra       := null;
            when too_many_rows then
              v_msg := t_message('O mesmo Lote indústria foi encontrado para mais de um produto. Informe a embalagem do produto!');
              if (r_conferencia.tipoconferencia =
                 C_TIPO_CONF_LOTE_CTRL_LT_IND) then
                raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                        v_msg.formatMessage);
              else
                raise_application_error(C_VARIOS_LOTEINDUSTRIA,
                                        v_msg.formatMessage);
              end if;
          end;
        when too_many_rows then
          v_msg := t_message('O mesmo Lote indústria foi encontrado para mais de um produto. Informe a embalagem do produto!');
          if (r_conferencia.tipoconferencia = C_TIPO_CONF_LOTE_CTRL_LT_IND) then
            raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                    v_msg.formatMessage);
          else
            raise_application_error(C_VARIOS_LOTEINDUSTRIA,
                                    v_msg.formatMessage);
          end if;
      end;
    
      if (v_loteIndustriaIdentificado is not null and
         r_conferencia.tipoconferencia = C_TIPO_CONF_LOTE_CTRL_LT_IND) then
      
        if (r_conferencia.barraPadrao128.identificadorProduto is not null) then
          begin
            select e.*
              into r_embalagemLoteInd
              from embalagem e
             where 1 = 1
               and e.barra =
                   r_conferencia.barraPadrao128.identificadorProduto;
          exception
            when no_data_found then
              v_msg := t_message('Solicitar Embalagem');
              raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                      v_msg.formatMessage);
          end;
        
          if ((qtdePendenteConfLotInd(r_embalagemLoteInd.Idproduto) <
             r_embalagemLoteInd.Fatorconversao) and
             qtdePendenteConfLotInd(r_embalagemLoteInd.Idproduto) <> 0) then
            v_msg := t_message('Solicitar Embalagem');
            raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                    v_msg.formatMessage);
          end if;
        else
          v_msg := t_message('Solicitar Embalagem');
          raise_application_error(C_SOLICITA_IDENTIFICADORPROD,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      if (r_conferencia.barraPadrao128.identificadorqtde is not null) then
        v_qtde := r_conferencia.barraPadrao128.identificadorqtde;
      end if;
    
      if ((v_loteIndustriaIdentificado is null) or
         (length(v_loteIndustriaIdentificado) = 0)) then
        r_embalagemConf.Barra := pk_produto.retCodSeparadoBarraProdLoteMap(p_barra,
                                                                           r_conferencia.iddepositante,
                                                                           C_RET_COD_LOTE,
                                                                           v_identLoteIndustria,
                                                                           v_loteIndustriaIdentificado,
                                                                           v_loteVencimento,
                                                                           null,
                                                                           null,
                                                                           v_qtdeRegra);
        if (v_qtdeRegra is not null and v_qtdeRegra <> 0) then
          v_qtde := v_qtdeRegra;
        end if;
      end if;
    
      --Verificar se a barra digitada é diferente da barra encontrada
      if (r_embalagemConf.Barra is not null and
         r_embalagemConf.Barra <> p_barra and v_qtde is null and
         r_conferencia.barraPadrao128.identificadorProduto is null and
         v_loteIndustriaIdentificado is null) then
        --Se as barras forem diferentes é porque foi utilzada uma regra de código de barra do depositante, então retorna a quantidade se houver na barra
        if (pk_depositante.getDadosBarraRegraDepositante(r_conferencia.iddepositante,
                                                         p_barra,
                                                         v_codProduto,
                                                         v_barraDummy,
                                                         v_qtdAux,
                                                         v_loteIndustriaIdentificado,
                                                         v_loteVencimento) = 1 and
           v_qtde is null and v_qtdAux is not null and v_qtdAux > 0) then
          v_qtde := v_qtdAux;
        end if;
      end if;
    
      if (v_loteIndustriaIdentificado is not null) then
        if (isLoteIndNaConf(v_loteIndustriaIdentificado, v_loteVencimento)) then
          r_produtoConferencia.Descrloteidentificado     := upper(v_loteIndustriaIdentificado);
          r_conferencia.barraPadrao128.identificadorvenc := nvl(v_loteVencimento,
                                                                r_conferencia.barraPadrao128.identificadorvenc);
        else
          v_msg := t_message('O Lote Indústria ou Data de Vencimento identificado não pertence à esta conferência.');
          raise_application_error(C_LOTE_IND_FORA_CONF, v_msg.formatMessage);
          return;
        end if;
      end if;
    
      identificarPorLoteUnicoVolume(v_loteIndustriaIdentificado,
                                    PROD_ID_POR_LTINDUSTRIA);
    
      if ((v_loteIndustriaIdentificado is null) or
         (length(v_loteIndustriaIdentificado) = 0)) then
        v_msg := t_message('Onda utiliza conferência por lote, informe o Lote Indústria ou a separação do lote indústria não foi concluída.');
        raise_application_error(C_NAO_IDENT_POR_LOTE, v_msg.formatMessage);
      end if;
    
      begin
        select e.*
          into r_embalagemConf
          from embalagem e
         where e.barra =
               nvl(r_embalagemLoteInd.Barra, r_embalagemConf.Barra);
      
        r_conferencia.ltIndustria                    := v_loteIndustriaIdentificado;
        r_conferencia.tipoIdentificacaoProduto       := PROD_ID_POR_LTINDUSTRIA;
        r_produtoConferencia.Descreduzidaemb         := r_embalagemConf.Descrreduzido;
        r_produtoConferencia.Fatorconversaoembalagem := r_embalagemConf.Fatorconversao;
      exception
        when no_data_found then
          v_msg := t_message('Onda utiliza conferência por lote, informe o Lote Indústria ou a separação do lote indústria não foi concluída.');
          raise_application_error(C_NAO_IDENT_POR_LOTE, v_msg.formatMessage);
      end;
    end conferenciaPorLoteIndustria;
  
    procedure identificarEmbalagemConf is
      v_escaneadoInfEspec number;
    begin
      extrairBarraPadrao128;
    
      r_embalagemConf.Barra := null;
    
      select count(1)
        into v_escaneadoInfEspec
        from confpacking c, notafiscal nf, movimentacao m, lote lt
       where c.id = p_idconfpacking
         and nf.idnotafiscal = c.idnotafiscal
         and m.idnotafiscal = nf.idnotafiscal
         and lt.idlote = m.idlote
         and (exists (select 1
                        from estoqueinformacaoespecifica ee
                       where ee.idlote = lt.idlote
                         and ee.valor = upper(p_barra)) or exists
              (select 1
                 from estoqueinformacaoespecifica eei
                where eei.idproduto = lt.idproduto
                  and eei.valor = upper(p_barra)
                  and eei.idlote is null
                  and eei.conferido = 0));
    
      if (r_conferencia.tipoconferencia in
         (C_TIPO_CONF_LOTE, C_TIPO_CONF_LOTE_CTRL_LT_IND) and
         p_solicitaEmb = 0 and v_escaneadoInfEspec = 0) then
        conferenciaPorLoteIndustria;
        return;
      end if;
    
      conferenciaPorBarra;
    
    end identificarEmbalagemConf;
  
    procedure validarEmbalagem is
    begin
      select count(1)
        into r_produtoConferencia.Possuiimagem
        from dual
       where exists (select 1
                from imagem_produto ip
               where ip.idproduto = r_embalagemConf.Idproduto);
    
      if (r_embalagemConf.Idproduto is null) then
        v_msg := t_message('Não foi encontrada nenhuma embalagem para a barra informada.' ||
                           chr(13) || ' Barra: {0}');
        v_msg.addParam(p_barra);
        raise_application_error(C_EMBALAGEM_NOTFOUND, v_msg.formatMessage);
      end if;
    
      if (r_embalagemConf.Ativo = C_INATIVO) then
        v_msg := t_message('A embalagem encontrada para a barra {0} não está ativa.');
        v_msg.addParam(p_barra);
        raise_application_error(C_EMBALAGEM_INATIVA, v_msg.formatMessage);
      end if;
    end validarEmbalagem;
  
    procedure buscarProdutoPendente is
    begin
      begin
        if (r_conferencia.loteuniconovolume = 1 or
           r_conferencia.tipoconferencia = C_TIPO_CONF_LOTE_BARRAS) then
          select v.idProduto, v.codigoInterno, v.descr, v.qtdetotal,
                 v.qtdeContada, v.qtdeemvolume, v.qtdeseparada,
                 v.barralegivel, v.fracionado, v.pesavel, v.qtdetolerancia,
                 v.qtdemin, v.qtdemax, v.descrlote, v.vencproduto
            into r_produtoConferencia.idProduto,
                 r_produtoConferencia.codigoInterno,
                 r_produtoConferencia.descricao,
                 r_produtoConferencia.qtdetotal,
                 r_produtoConferencia.qtdeContada,
                 r_produtoConferencia.qtdeEmVolume,
                 r_produtoConferencia.qtdeseparada,
                 r_produtoConferencia.barralegivel,
                 r_produtoConferencia.fracionado,
                 r_produtoConferencia.pesavel,
                 r_produtoConferencia.qtdetolerancia,
                 r_produtoConferencia.qtdemin, r_produtoConferencia.qtdemax,
                 r_conferencia.ltIndustria, r_conferencia.dtVencimento
            from (select lt.idProduto, p.codigoInterno, p.descr,
                          sum(t.quantidade) qtdetotal,
                          (select sum(pc.qtde * e.fatorconversao) qtdecontada
                              from confpacking c, produtoconfpacking pc,
                                   embalagem e
                             where c.status = 0
                               and c.idonda = t.idonda
                               and c.idnotafiscal = t.idnotafiscal
                               and pc.idconfpacking = c.id
                               and pc.status = 1
                               and pc.idproduto = lt.idproduto
                               and e.idproduto = pc.idproduto
                               and e.barra = pc.barra) qtdeContada,
                          sum(t.qtdeemvolume) qtdeemvolume,
                          sum(decode(t.status, STATUS_MOV_FINALIZADO,
                                      t.quantidade, 0)) qtdeseparada,
                          (select decode(sum(decode(e.barralegivel, 'N', 1, 0)),
                                           0, 'S', 'N') barralegivel
                              from embalagem e
                             where e.idproduto = lt.idproduto) barralegivel,
                          p.fracionado, p.pesavel,
                          decode(p.pesavel, 1,
                                  (sum(t.quantidade) / 100) *
                                   pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                           lt.iddepositante,
                                                                           'S'),
                                  0) qtdetolerancia,
                          decode(p.pesavel, 1,
                                  (sum(t.quantidade) -
                                   (sum(t.quantidade) / 100) *
                                   pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                            lt.iddepositante,
                                                                            'S')),
                                  sum(t.quantidade)) qtdemin,
                          decode(p.pesavel, 1,
                                  (sum(t.quantidade) +
                                   (sum(t.quantidade) / 100) *
                                   pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                            lt.iddepositante,
                                                                            'S')),
                                  sum(t.quantidade)) qtdemax,
                          case
                             when ((co.usoexclusivokitsestojamento = 0) and
                                  ((pd.loteuniconovolume = 1) or
                                  (co.tipoconferencia = 2))) then
                              lt.descr
                             else
                              null
                           end descrlote,
                          case
                             when ((co.usoexclusivokitsestojamento = 0) and
                                  ((pd.loteuniconovolume = 1) or
                                  (co.tipoconferencia = 2))) then
                              lt.dtvenc
                             else
                              null
                           end vencproduto
                     from v_tarefas_onda t, lote lt, produto p,
                          produtodepositante pd, romaneiopai rp,
                          configuracaoonda co
                    where decode(r_conferencia.codbarratarefa, null, '-1',
                                 t.codbarratarefa) =
                          decode(r_conferencia.codbarratarefa, null, '-1',
                                 r_conferencia.codbarratarefa)
                      and t.idonda = r_conferencia.Idonda
                      and t.status in
                          (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                           STATUS_MOV_FINALIZADO)
                      and t.idlocaldestino = r_conferencia.idenderecopacking
                      and t.idnotafiscal = r_conferencia.idnotafiscal
                      and lt.idlote = t.idlote
                      and lt.idproduto = r_embalagemConf.idproduto
                      and p.idproduto = lt.idproduto
                      and pd.idproduto = lt.idproduto
                      and pd.identidade = lt.iddepositante
                      and rp.idromaneio = t.idonda
                      and co.idconfiguracaoonda = rp.idconfiguracaoonda
                    group by t.idonda, t.idnotafiscal, lt.idProduto,
                             lt.iddepositante, p.codigoInterno, p.descr,
                             p.fracionado, p.pesavel,
                             co.usoexclusivokitsestojamento,
                             pd.loteuniconovolume, co.tipoconferencia,
                             lt.descr, lt.dtvenc) v
           where v.qtdetotal <> v.qtdeemvolume
             and decode(r_conferencia.barraPadrao128.identificadorLote, null,
                        '-1', v.descrlote) =
                 decode(r_conferencia.barraPadrao128.identificadorLote, null,
                        '-1', r_conferencia.barraPadrao128.identificadorLote)
             and decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                        sysdate, v.vencproduto) =
                 decode(r_conferencia.barraPadrao128.identificadorvenc, null,
                        sysdate,
                        r_conferencia.barraPadrao128.identificadorvenc);
        
          return;
        end if;
      
        select lt.idProduto, p.codigoInterno, p.descr,
               sum(t.quantidade) qtdetotal,
               (select sum(pc.qtde * e.fatorconversao) qtdecontada
                   from confpacking c, produtoconfpacking pc, embalagem e
                  where c.status = 0
                    and decode(r_conferencia.codbarratarefa, null, '-1',
                               c.codbarratarefa) =
                        decode(r_conferencia.codbarratarefa, null, '-1',
                               r_conferencia.codbarratarefa)
                    and c.idonda = t.idonda
                    and c.idnotafiscal = t.idnotafiscal
                    and pc.idconfpacking = c.id
                    and pc.status = 1
                    and pc.idproduto = lt.idproduto
                    and e.idproduto = pc.idproduto
                    and e.barra = pc.barra) qtdeContada,
               sum(t.qtdeemvolume) qtdeemvolume,
               sum(decode(t.status, STATUS_MOV_FINALIZADO, t.quantidade, 0)) qtdeseparada,
               (select decode(sum(decode(e.barralegivel, 'N', 1, 0)), 0, 'S',
                                'N') barralegivel
                   from embalagem e
                  where e.idproduto = lt.idproduto) barralegivel,
               p.fracionado, p.pesavel,
               decode(p.pesavel, 1,
                       (sum(t.quantidade) / 100) *
                        pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                lt.iddepositante,
                                                                'S'), 0) qtdetolerancia,
               decode(p.pesavel, 1,
                       (sum(t.quantidade) -
                        (sum(t.quantidade) / 100) *
                        pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                 lt.iddepositante,
                                                                 'S')),
                       sum(t.quantidade)) qtdemin,
               decode(p.pesavel, 1,
                       (sum(t.quantidade) +
                        (sum(t.quantidade) / 100) *
                        pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                 lt.iddepositante,
                                                                 'S')),
                       sum(t.quantidade)) qtdemax
          into r_produtoConferencia.idProduto,
               r_produtoConferencia.codigoInterno,
               r_produtoConferencia.descricao,
               r_produtoConferencia.qtdetotal,
               r_produtoConferencia.qtdeContada,
               r_produtoConferencia.qtdeEmVolume,
               r_produtoConferencia.qtdeseparada,
               r_produtoConferencia.barralegivel,
               r_produtoConferencia.fracionado, r_produtoConferencia.pesavel,
               r_produtoConferencia.qtdetolerancia,
               r_produtoConferencia.qtdemin, r_produtoConferencia.qtdemax
          from v_tarefas_onda t, lote lt, produto p
         where decode(r_conferencia.codbarratarefa, null, '-1',
                      t.codbarratarefa) =
               decode(r_conferencia.codbarratarefa, null, '-1',
                      r_conferencia.codbarratarefa)
           and t.idonda = r_conferencia.Idonda
           and t.status in (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                            STATUS_MOV_FINALIZADO)
           and t.idlocaldestino = r_conferencia.idenderecopacking
           and t.idnotafiscal = r_conferencia.Idnotafiscal
           and lt.idlote = t.idlote
           and lt.idproduto = r_embalagemConf.Idproduto
           and p.idproduto = lt.idproduto
         group by t.idonda, t.idnotafiscal, lt.idProduto, lt.iddepositante,
                  p.codigoInterno, p.descr, p.fracionado, p.pesavel;
      
        return;
      exception
        when no_data_found then
          if (r_conferencia.loteuniconovolume = 1 and
             r_conferencia.conferenciacegapacking = 1) then
            begin
              select v.idProduto, v.codigoInterno, v.descr, v.qtdetotal,
                     v.qtdeContada, v.qtdeemvolume, v.qtdeseparada,
                     v.barralegivel, v.fracionado, v.pesavel,
                     v.qtdetolerancia, v.qtdemin, v.qtdemax, v.descrlote,
                     v.vencproduto
                into r_produtoConferencia.idProduto,
                     r_produtoConferencia.codigoInterno,
                     r_produtoConferencia.descricao,
                     r_produtoConferencia.qtdetotal,
                     r_produtoConferencia.qtdeContada,
                     r_produtoConferencia.qtdeEmVolume,
                     r_produtoConferencia.qtdeseparada,
                     r_produtoConferencia.barralegivel,
                     r_produtoConferencia.fracionado,
                     r_produtoConferencia.pesavel,
                     r_produtoConferencia.qtdetolerancia,
                     r_produtoConferencia.qtdemin,
                     r_produtoConferencia.qtdemax, r_conferencia.ltIndustria,
                     r_conferencia.dtVencimento
                from (select lt.idProduto, p.codigoInterno, p.descr,
                              sum(t.quantidade) qtdetotal,
                              (select sum(pc.qtde * e.fatorconversao) qtdecontada
                                  from confpacking c, produtoconfpacking pc,
                                       embalagem e
                                 where c.status = 0
                                   and c.idonda = t.idonda
                                   and c.idnotafiscal = t.idnotafiscal
                                   and pc.idconfpacking = c.id
                                   and pc.status = 1
                                   and pc.idproduto = lt.idproduto
                                   and e.idproduto = pc.idproduto
                                   and e.barra = pc.barra) qtdeContada,
                              sum(t.qtdeemvolume) qtdeemvolume,
                              sum(decode(t.status, STATUS_MOV_FINALIZADO,
                                          t.quantidade, 0)) qtdeseparada,
                              (select decode(sum(decode(e.barralegivel, 'N', 1,
                                                          0)), 0, 'S', 'N') barralegivel
                                  from embalagem e
                                 where e.idproduto = lt.idproduto) barralegivel,
                              p.fracionado, p.pesavel,
                              decode(p.pesavel, 1,
                                      (sum(t.quantidade) / 100) *
                                       pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                               lt.iddepositante,
                                                                               'S'),
                                      0) qtdetolerancia,
                              decode(p.pesavel, 1,
                                      (sum(t.quantidade) -
                                       (sum(t.quantidade) / 100) *
                                       pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                                lt.iddepositante,
                                                                                'S')),
                                      sum(t.quantidade)) qtdemin,
                              decode(p.pesavel, 1,
                                      (sum(t.quantidade) +
                                       (sum(t.quantidade) / 100) *
                                       pk_produto.retornarPercentualTolerancia(lt.idproduto,
                                                                                lt.iddepositante,
                                                                                'S')),
                                      sum(t.quantidade)) qtdemax,
                              case
                                 when ((co.usoexclusivokitsestojamento = 0) and
                                      ((pd.loteuniconovolume = 1) or
                                      (co.tipoconferencia = 2))) then
                                  lt.descr
                                 else
                                  null
                               end descrlote,
                              case
                                 when ((co.usoexclusivokitsestojamento = 0) and
                                      ((pd.loteuniconovolume = 1) or
                                      (co.tipoconferencia = 2))) then
                                  lt.dtvenc
                                 else
                                  null
                               end vencproduto
                         from v_tarefas_onda t, lote lt, produto p,
                              produtodepositante pd, romaneiopai rp,
                              configuracaoonda co
                        where decode(r_conferencia.codbarratarefa, null, '-1',
                                     t.codbarratarefa) =
                              decode(r_conferencia.codbarratarefa, null, '-1',
                                     r_conferencia.codbarratarefa)
                          and t.idonda = r_conferencia.Idonda
                          and t.status in
                              (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                               STATUS_MOV_FINALIZADO)
                          and t.idlocaldestino =
                              r_conferencia.idenderecopacking
                          and t.idnotafiscal = r_conferencia.idnotafiscal
                          and lt.idlote = t.idlote
                          and lt.idproduto = r_embalagemConf.idproduto
                          and p.idproduto = lt.idproduto
                          and pd.idproduto = lt.idproduto
                          and pd.identidade = lt.iddepositante
                          and rp.idromaneio = t.idonda
                          and co.idconfiguracaoonda = rp.idconfiguracaoonda
                        group by t.idonda, t.idnotafiscal, lt.idProduto,
                                 lt.iddepositante, p.codigoInterno, p.descr,
                                 p.fracionado, p.pesavel,
                                 co.usoexclusivokitsestojamento,
                                 pd.loteuniconovolume, co.tipoconferencia,
                                 lt.descr, lt.dtvenc) v
               where decode(r_conferencia.barraPadrao128.identificadorLote,
                            null, '-1', v.descrlote) =
                     decode(r_conferencia.barraPadrao128.identificadorLote,
                            null, '-1',
                            r_conferencia.barraPadrao128.identificadorLote)
                 and decode(r_conferencia.barraPadrao128.identificadorvenc,
                            null, sysdate, v.vencproduto) =
                     decode(r_conferencia.barraPadrao128.identificadorvenc,
                            null, sysdate,
                            r_conferencia.barraPadrao128.identificadorvenc);
            
            exception
              when no_data_found then
                raise E_PRODUTOCONF_NOTFOUND;
            end;
          else
            raise E_PRODUTOCONF_NOTFOUND;
          end if;
        when too_many_rows then
          if (r_conferencia.barraPadrao128.identificadorvenc is null) then
            v_msg := t_message('Solicitar Vencimento');
            raise_application_error(C_SOLICITA_VENCIMENTO,
                                    v_msg.formatMessage);
          end if;
      end;
    end buscarProdutoPendente;
  
    -- Refactored procedure validarCancelamentoProduto 
    procedure validarCancelamentoProduto is
    begin
      if (p_checkout = 1) then
      
        select count(1)
          into r_produtoConferencia.Possuicancelamento
          from ordemseparacao os, ordemseparacaoitem osi,
               ordemseparacaocancelamento osc,
               ordemseparacaocancelamentoitem osci, depositante d,
               notafiscal nf
         where os.idnotafiscal = r_conferencia.idnotafiscal
           and osci.idordemseparacaocancelamento = osc.id
           and osc.idordemseparacao = os.idordemseparacao
           and osc.poderecebercancelamentoitem = 1
           and osci.idproduto = osi.idproduto
           and osi.idproduto = r_produtoConferencia.Idproduto
           and osi.idordemsep = os.idordemseparacao
           and osci.status = 0
           and osci.dataefetivacao is null
           and os.status = 0
           and nf.iddepositante = d.identidade
           and nf.idnotafiscal = os.idnotafiscal
           and d.utilizaautorizacaoexpedicao = 1;
      
        if (r_produtoConferencia.Possuicancelamento = 1 and
           p_solicitaEmb = 0) then
        
          v_msg := t_message('Foi solicitado cancelamento do produto. Cod.: ' ||
                             r_produtoConferencia.Codigointerno ||
                             ', Descr.: ' || r_produtoConferencia.Descricao ||
                             ', favor segregá-lo.');
          raise_application_error(C_SOLICITAR_CONFCANCEL,
                                  v_msg.formatMessage);
        
        elsif (r_produtoConferencia.Possuicancelamento = 1 and
              p_solicitaEmb = 1) then
        
          v_msg := t_message('Foi solicitado cancelamento do produto. Cod.: ' ||
                             r_produtoConferencia.Codigointerno ||
                             ', Descr.: ' || r_produtoConferencia.Descricao ||
                             ', favor retorne o produto ao estoque.');
          raise_application_error(C_SOLICITAR_CONFCANCEL_LOCAL,
                                  v_msg.formatMessage);
        
        end if;
      end if;
    end validarCancelamentoProduto;
  
    procedure buscarProdutoPorLote is
    begin
      begin
        select pc.qtde
          into r_produtoConferencia.qtdeContada
          from produtoconfpacking pc
         where pc.idconfpacking = p_idconfpacking
           and pc.loteindustria = p_barra
           and pc.status = 1;
      exception
        when others then
          buscarProdutoPendente;
      end;
    
    end buscarProdutoPorLote;
  
    procedure getTipoErroProdutoConfNotFound(p_errorCode in number) is
      v_ConfCodBarrasProdNaoPedido number;
      v_CodInternoProduto          produto.codigointerno%type;
      v_DescrProduto               produto.descr%type;
    begin
      select nvl(a.confCodBarrasProdNaoPedido, 0)
        into v_ConfCodBarrasProdNaoPedido
        from local l, armazem a
       where l.id = r_conferencia.idenderecopacking
         and a.idarmazem = l.idarmazem;
    
      if (v_ConfCodBarrasProdNaoPedido = 1) then
        select p.descr, p.codigointerno
          into v_DescrProduto, v_CodInternoProduto
          from produto p
         where p.idproduto = r_embalagemConf.Idproduto;
      
        inserirDadosRetorno(p_errorCode,
                            'O produto código: ' || v_CodInternoProduto ||
                             ' nome: ' || v_DescrProduto ||
                             ' não pertence ao pedido. Confirme novamente o código de barras do produto para continuar e separe ele dos demais.');
        return;
      end if;
    
      inserirDadosRetorno(p_errorCode,
                          'Produto ' || p_barra ||
                           ' não pertence a esta conferência.');
    end getTipoErroProdutoConfNotFound;
  
    procedure validarProdutoPendente is
    
      procedure validarInformacaoEspecifica is
      begin
        select pd.rastrearinfoespecifica,
               (select count(1)
                   from informacaomatdep imd
                  where imd.idproduto = pd.idproduto
                    and imd.identidade = pd.identidade) possuiInfoEspec
          into r_produtoConferencia.Tiporastinfoespec,
               r_produtoConferencia.Possuiinfespecifica
          from produtodepositante pd
         where pd.idproduto = r_produtoConferencia.Idproduto
           and pd.identidade = r_conferencia.iddepositante;
      
        if ((r_conferencia.tipoIdentificacaoProduto = PROD_ID_POR_INFO) and
           (v_qtde is null or v_qtde <= 1)) then
          return;
        end if;
      
        if ((r_produtoConferencia.Possuiinfespecifica > 0) and
           r_embalagemConf.Fatorconversao > 1) then
          v_msg := t_message('Este material possui informações específicas. Por favor, entre com codigo de barras de embalagem de fator 1.');
          raise_application_error(C_INFORME_BARRAFATOR_UNIT,
                                  v_msg.formatMessage);
        end if;
      end validarInformacaoEspecifica;
    
    begin
      if (v_qtde is null or v_qtde <= 0) then
        v_qtde := p_qtde;
      end if;
    
      if ((r_produtoConferencia.qtderestante <= 0) and
         (r_conferencia.conferenciacegapacking = 0)) then
        v_msg := t_message('Produto {0}' ||
                           ' sem quantidade restante para conferência do packing.');
        v_msg.addParam(r_produtoConferencia.Descricao);
        raise_application_error(C_PRDCONF_NAOPOSSUIRESTQTDCONF,
                                v_msg.formatMessage);
      end if;
    
      if (r_produtoConferencia.fracionado = 'N') then
        if (trunc(v_qtde) <> v_qtde) then
          v_msg := t_message('Produto {0}' ||
                             ' não permite conferir quantidade fracionada. Qtde. Informada: ' ||
                             '{1}.');
          v_msg.addParam(r_produtoConferencia.Descricao);
          v_msg.addParam(v_qtde);
          raise_application_error(C_ERRO_QTDE_FRACIONADA,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      validarInformacaoEspecifica;
    
    end validarProdutoPendente;
  
    procedure validarConferencia is
      v_fracionalote          number;
      v_qtdInfoEspecInformada number;
      v_qtdeRestante          number;
      v_qtdeUnitaria          number;
      v_qtdeTotal             number;
    
      procedure validarLoteUnicoVolume is
        v_loteIndustria    lote.descr%type;
        v_vencimento       lote.dtvenc%type;
        v_validarLoteUnico number;
      begin
        select decode(sum(loteuniconovolume), 0, 0, 1)
          into v_validarLoteUnico
          from (
                 -- valida se algum produto dentro do volume possui lote unico
                 select pd.loteuniconovolume
                   from produtoconfpacking pc, confpacking c, notafiscal n,
                         produtodepositante pd
                  where pc.idconfpacking = p_idConfPacking
                    and c.id = pc.idconfpacking
                    and n.idnotafiscal = c.idnotafiscal
                    and pd.identidade = n.iddepositante
                    and pd.idproduto = pc.idproduto
                 union
                 -- valida se o produto que estou contando utiliza lote unico
                 select pd.loteuniconovolume
                   from confpacking c, notafiscal n, produtodepositante pd
                  where c.id = p_idConfPacking
                    and n.idnotafiscal = c.idnotafiscal
                    and pd.identidade = n.iddepositante
                    and pd.idproduto = r_produtoConferencia.Idproduto);
      
        if (v_validarLoteUnico = 0) then
          return;
        end if;
      
        begin
          select loteindustria, vencimento
            into v_loteIndustria, v_vencimento
            from produtoconfpacking pc
           where pc.idconfpacking = p_idConfPacking
             and pc.status <> 0
             and (nvl(pc.loteindustria, '-1') <>
                 nvl(r_conferencia.ltIndustria, '-1') or
                 nvl(pc.vencimento, sysdate) <>
                 nvl(r_conferencia.dtVencimento, sysdate))
             and rownum = 1;
        exception
          when no_data_found then
            return;
        end;
      
        v_msg := t_message('Existem produtos contados no volume com outro vencimento e lote indústria, a configuração atual não permite misturar lote indústria e vencimentos diferentes no mesmo volume. LOTE INDUSTRIA: ' ||
                           '{0} VENCIMENTO: {1}');
        v_msg.addParam(v_loteIndustria);
        v_msg.addParam(v_vencimento);
        raise_application_error(C_QTD_INFOESPEC_DIV_QTDE,
                                v_msg.formatMessage);
      end validarLoteUnicoVolume;
    
    begin
    
      if (nvl(r_conferencia.solicitaqtdecaixapacking, 0) > 0 and
         (r_embalagemConf.fatorconversao > 1 or
         (r_embalagemConf.caixafechada = 'S' and
         r_conferencia.utzcaixafecft1geracaovolqtde = 1))) then
        begin
          select sum(((nvl(m.quantidade, 0) - nvl(p.qtde, 0)) /
                      r_embalagemConf.fatorconversao))
            into v_qtde
            from movimentacao m, lote lt,
                 (select pa.idlote, pa.qtde
                     from produtoconfpacking pa
                    where pa.idconfpacking = r_conferencia.idconfpacking
                      and pa.status <> 0) p
           where m.idonda = r_conferencia.idonda
             and m.idnotafiscal = r_conferencia.idnotafiscal
             and lt.idlote = m.idlote
             and lt.idproduto = r_produtoconferencia.idproduto
             and lt.idarmazem = r_conferencia.idarmazem
             and lt.idlote = p.idlote(+);
        exception
          when no_data_found then
            v_qtde := 0;
        end;
      
        if (v_qtde >= r_conferencia.solicitaqtdecaixapacking and
           nvl(p_solicitaCaixa, 0) = 0) then
          v_msg := t_message('Informe a quantidade de caixas a serem conferidas.');
          raise_application_error(C_SOLICITA_QTDE_CAIXA_VOLUME,
                                  v_msg.formatMessage);
        end if;
      
        v_pedeQuantidadeCaixa := 1;
        v_qtde                := p_qtde;
      else
        -- Volume caixa fechada quantidade sempre 1
        if (r_conferencia.montvolautocxfchdapack = 1) then
          -- se o tipo de caixa fechada a considerar para geração de volume de caixa fechada for o padrão
          -- e a embalagem é fator 1 e não for caixa fechada, então não gera volume    
          if (r_conferencia.tipovolumecaixafechada =
             C_FATOR_MAIOR_1_CX_FECHADA and
             (r_embalagemConf.fatorconversao > 1 or
             r_embalagemConf.caixafechada = 'S')) then
            v_qtde := 1;
            -- se o tipo de caixa fechada a considerar para geração de volume de caixa fechada for somente
            -- embalagens configuradas como caixa fechada na conferencia de saída e a embalagem nao estiver
            -- parametrizada, então não gera volume
          elsif (r_conferencia.tipovolumecaixafechada =
                C_CAIXA_FECHADA_CONF_SAIDA and
                r_embalagemConf.caixafechadaconfsaida = 1) then
            v_qtde := 1;
          end if;
        end if;
      
        select d.fracionarlote
          into v_fracionalote
          from depositante d
         where d.identidade = r_conferencia.iddepositante;
      
        if ((nvl(v_qtde, 0) = 0) and (r_conferencia.tipoIdentificacaoProduto =
           PROD_ID_POR_LTINDUSTRIA) and (p_solicitaQtde = C_NAO) and
           (v_fracionalote = C_NAO) and
           (r_conferencia.confsaidaunitaria = C_NAO)) then
        
          select m.quantidade / r_embalagemConf.Fatorconversao, lt.idlote
            into v_qtde, v_idlote
            from movimentacao m, lote lt
           where m.idonda = r_conferencia.idonda
             and m.idnotafiscal = r_conferencia.idnotafiscal
             and lt.idlote = m.idlote
             and lt.idproduto = r_produtoconferencia.idproduto
             and lt.idarmazem = r_conferencia.idarmazem
             and lt.descr = r_conferencia.ltIndustria
             and not exists
           (select 1
                    from produtoconfpacking p
                   where p.idconfpacking = r_conferencia.idconfpacking
                     and p.idlote = lt.idlote
                     and p.status <> 0)
             and rownum = 1;
        end if;
      end if;
    
      if ((nvl(v_qtde, 0) = 0) AND
         (p_solicitaQtde = 1 OR r_conferencia.confsaidaunitaria = C_NAO) AND
         (nvl(r_conferencia.autoconferirqtde, 0) = 0) AND
         (r_conferencia.tipoIdentificacaoProduto <> PROD_ID_POR_INFO)) then
        v_msg := t_message('Informe a quantidade conferida do produto.');
        raise_application_error(C_SOLICITAR_QTDE, v_msg.formatMessage);
      end if;
    
      if (nvl(r_conferencia.autoconferirqtde, 0) > 0) then
        v_qtdeUnitaria                     := r_conferencia.autoconferirqtde;
        r_conferencia.autoconferirqtdeUnit := round(r_conferencia.autoconferirqtde /
                                                    r_embalagemConf.Fatorconversao,
                                                    6);
      else
        v_qtdeUnitaria := nvl(v_qtde, 1) * r_embalagemConf.Fatorconversao;
      end if;
    
      if (r_conferencia.conferenciacegapacking <> 1 or
         r_conferencia.limitaconfcegamaxqtdeproduto = 1) then
      
        if ((nvl(v_qtdeUnitaria, 1) + r_produtoConferencia.Qtdecontada +
           r_produtoConferencia.Qtdeemvolume) >
           r_produtoConferencia.Qtdemax) then
          v_msg := t_message('Quantidade excedida');
          raise_application_error(C_ERRO_QTDE_PROD_CONF,
                                  v_msg.formatMessage);
        end if;
      
        if (r_produtoConferencia.Pesavel = 1) then
          v_qtdeRestante := r_produtoConferencia.Qtdemax -
                            r_produtoConferencia.Qtdeemvolume -
                            r_produtoConferencia.Qtdecontada;
          if (v_qtdeRestante <= 0) then
            v_msg := t_message('Produto sem quantidade restante para conferência do packing.');
            raise_application_error(C_ERRO_QTDE_PROD_CONF,
                                    v_msg.formatMessage);
          end if;
        
          if (v_qtdeUnitaria > v_qtdeRestante) then
            v_msg := t_message('Quantidade é maior que a quantidade tolerada para conferência.');
            raise_application_error(C_ERRO_QTDE_PROD_CONF,
                                    v_msg.formatMessage);
          end if;
        else
          if (r_produtoConferencia.Qtderestante <= 0) then
            v_msg := t_message('Produto sem quantidade restante para conferência do packing.');
            raise_application_error(C_ERRO_QTDE_PROD_CONF,
                                    v_msg.formatMessage);
          end if;
        end if;
      
        if (v_qtdeUnitaria > ((r_produtoconferencia.qtdeseparada -
           r_produtoconferencia.qtdecontada) +
           r_produtoconferencia.qtdetolerancia)) then
          v_msg := t_message('Quantidade informada ainda não foi separada até ao packing.');
          raise_application_error(C_ERRO_QTDE_PROD_CONF,
                                  v_msg.formatMessage);
        end if;
      else
        v_qtdeTotal := r_produtoconferencia.qtdeContada + v_qtdeUnitaria;
      
        if ((v_qtdeTotal > 9223372036854775807) OR
           (v_qtdeTotal < (-9223372036854775808))) then
          v_msg := t_message('Quantidade informada excedida.');
          raise_application_error(-2000, v_msg.formatMessage);
        end if;
      end if;
    
      if (r_produtoConferencia.Possuiinfespecifica = 1 and
         r_conferencia.tipoIdentificacaoProduto <> PROD_ID_POR_INFO) then
      
        if ((nvl(v_qtdeUnitaria, 1) + r_produtoConferencia.Qtdecontada +
           r_produtoConferencia.Qtdeemvolume) >
           r_produtoConferencia.Qtdemax) then
          v_msg := t_message('A quantidade de produtos informada excede a quantidade deste produto para essa nota. Este cenário não é permitido para produtos que coletam informação específica.');
          raise_application_error(C_QTD_INFOESPEC_DIV_QTDE,
                                  v_msg.formatMessage);
        end if;
      
        select count(1)
          into v_qtdInfoEspecInformada
          from GTT_INFESPECCONFPACKING;
      
        if (v_qtdInfoEspecInformada = 0) then
          v_msg := t_message('Para prosseguir a conferência é necessário coletar informações específicas');
          raise_application_error(C_SOLICITAR_INFOESPEC,
                                  v_msg.formatMessage);
        end if;
      
        if (v_qtdInfoEspecInformada > 0 and
           v_qtdInfoEspecInformada <> nvl(v_qtde, 1)) then
          v_msg := t_message('Quantidade de informações coletadas é diferente da quantidade de itens informados.');
          raise_application_error(C_QTD_INFOESPEC_DIV_QTDE,
                                  v_msg.formatMessage);
        end if;
      end if;
    
      validarLoteUnicoVolume;
    end validarConferencia;
  
    procedure validarCaixaVolume is
      C_CX_VOL_PROPRIA    constant number := 0;
      C_CX_VOL_RETORNAVEL constant number := 1;
      v_cubagemConferencia number;
    begin
      if (r_conferencia.controlacubagemcaixavolume = 1) then
        if ((r_conferencia.idtipocaixa is null) OR
           (r_conferencia.tipocaixavolume is null)) then
          v_msg := t_message('Onda configurada para Controlar Cubagem da Caixa na Geração do Volume e Tipo da Caixa não está configurado para o packing');
          raise_application_error(C_ERRO_VALIDACAO_TIPO_CAIXA,
                                  v_msg.formatMessage);
        end if;
        if ((r_conferencia.tipocaixavolume = C_CX_VOL_PROPRIA) OR
           (r_conferencia.tipocaixavolume = C_CX_VOL_RETORNAVEL)) then
          v_cubagemConferencia := r_embalagemConf.Altura *
                                  r_embalagemConf.Largura *
                                  r_embalagemConf.Comprimento;
        
          if (v_cubagemConferencia > (r_conferencia.cubagemCaixaVolume -
             r_conferencia.totalCubagemConferida)) then
            v_msg := t_message('O tipo de caixa selecionada não possui cubagem disponível para armazenar o produto conferido.');
            raise_application_error(C_ERRO_VALIDACAO_TIPO_CAIXA,
                                    v_msg.formatMessage);
          end if;
        end if;
      end if;
    end validarCaixaVolume;
  
    procedure atualizaDadosSaidaPorNf(p_qtdConferida in number) is
    begin
      if (p_qtdConferida is null or p_qtdConferida < 0) then
        v_msg := t_message('Ocorreu um erro de conferencia.' || chr(13) ||
                           'IdNotaFiscal: {0}.' || chr(13) ||
                           'Operação cancelada.');
        v_msg.addParam(r_conferencia.idnotafiscal);
        raise_application_error(C_ERRO_QTDE_PROD_CONF, v_msg.formatMessage);
      end if;
    
      update saidapornf snf
         set snf.conferenciainiciada = nvl(snf.qtdeconferida, 0) +
                                       p_qtdConferida
       where snf.idnotafiscal = r_conferencia.idnotafiscal;
    end atualizaDadosSaidaPorNf;
  
    procedure realizarConferencia is
    
      v_qtdeIdentificada number;
      procedure inserirProdConfPacking
      (
        pcf_idConfPacking     in number,
        pcf_idproduto         in number,
        pcf_barra             in varchar2,
        pcf_qtde              in number,
        pcf_idInfoMaterial    in number,
        pcf_valInfoEspecifica in estoqueinformacaoespecifica.valor%type,
        pcf_ltIndustria       in lote.descr%type,
        pcf_vencimento        in lote.dtvenc%type
      ) is
        v_qtdemovimentada number;
      begin
        validarCaixaVolume;
      
        insert into produtoconfpacking
          (id, idconfpacking, idproduto, barra, qtde, data, status,
           idinfomaterial, valor, loteindustria, vencimento, idlote)
          select seq_produtoconfpacking.nextval, pcf_idConfPacking,
                 pcf_idproduto, pcf_barra, pcf_qtde, sysdate, 1,
                 pcf_idInfoMaterial, pcf_valInfoEspecifica,
                 case
                   when (r_conferencia.tipoconferencia =
                        C_TIPO_CONF_LOTE_CTRL_LT_IND) then
                    upper(pcf_ltIndustria)
                   else
                    pcf_ltIndustria
                 end,
                 case
                   when (r_conferencia.tipoconferencia =
                        C_TIPO_CONF_LOTE_CTRL_LT_IND) then
                    null
                   else
                    pcf_vencimento
                 end, v_idlote
            from dual;
      
        select sum(p.qtde * e.fatorconversao)
          into v_qtdemovimentada
          from produtoconfpacking p, embalagem e
         where p.idconfpacking = pcf_idConfPacking
           and p.idproduto = pcf_idproduto
           and p.status = 1
           and e.idproduto = p.idproduto
           and e.barra = p.barra;
      
        r_produtoConferencia.Qtdecontada := v_qtdemovimentada;
      
        atualizaDadosSaidaPorNf(v_qtdemovimentada);
      end inserirProdConfPacking;
    
      procedure conferirInformacaoEspecifica is
        v_identificadorInfo estoqueinformacaoespecifica.identificadorinfo%type;
        v_idInfoMaterial    estoqueinformacaoespecifica.idinfomaterial%type;
        v_valor             gtt_infespecconfpacking.valor%type;
        v_informacao        informacaomaterial.informacao%type;
        v_existeInformacao  number;
      
        procedure rastreabilidadeCompleta is
          v_loteExiste       number;
          v_QtdInfoInformada number;
        begin
          select count(1)
            into v_QtdInfoInformada
            from gtt_infespecconfpacking;
        
          if (v_QtdInfoInformada = 0) then
            v_msg := t_message('Para prosseguir a conferência é necessário coletar informações específicas');
            raise_application_error(C_SOLICITAR_INFOESPEC,
                                    v_msg.formatMessage);
          end if;
        
          begin
            select ei.identificadorinfo,
                   upper(pk_produto.retCodSeparadoBarraProdLote(g.valor,
                                                                 imd.identidade,
                                                                 1, 1)),
                   im.informacao, im.idinfomaterial
              into v_identificadorInfo, v_valor, v_informacao,
                   v_idInfoMaterial
              from GTT_INFESPECCONFPACKING g, informacaomatdep imd,
                   informacaomaterial im, estoqueinformacaoespecifica ei
             where imd.idproduto = g.idproduto
               and imd.identidade = r_conferencia.iddepositante
               and imd.idinfomaterial = imd.idinfomaterial
               and imd.valorunico = 'S'
               and im.idinfomaterial = imd.idinfomaterial
               and ei.idproduto = g.idproduto
               and ei.idinfomaterial = imd.idinfomaterial
               and ei.valor =
                   upper(pk_produto.retCodSeparadoBarraProdLote(g.valor,
                                                                imd.identidade,
                                                                1, 1))
               and ei.conferido = C_NAO
               and ei.idlote is not null
               and rownum = 1;
          exception
            when no_data_found then
              select upper(g.valor)
                into v_valor
                from gtt_infespecconfpacking g
               where rownum = 1;
            
              v_msg := t_message('Não foi encontrada informação específica única com valor ' ||
                                 '{0} pendente de conferência para o produto ' ||
                                 '{1} com código interno {2}.');
              v_msg.addParam(v_valor);
              v_msg.addParam(r_produtoConferencia.Descricao);
              v_msg.addParam(r_produtoconferencia.codigointerno);
              raise_application_error(C_INFO_ESPEC_NAO_ENCONTRADA,
                                      v_msg.formatMessage);
          end;
        
          if (r_estoqueinfo.idlote is null) then
            begin
              select e.idproduto, e.idlote, e.identificadorinfo
                into r_estoqueinfo.idproduto, r_estoqueinfo.idlote,
                     r_estoqueinfo.identificadorinfo
                from estoqueinformacaoespecifica e, lote lt, movimentacao m
               where e.idproduto = r_produtoConferencia.Idproduto
                 and e.identidade = r_conferencia.iddepositante
                 and e.valor = upper(v_valor)
                 and e.conferido = 0
                 and e.expedida = 0
                 and lt.idlote = e.idlote
                 and m.idlote = lt.idlote
                 and m.status <> 3
                 and m.idonda = r_conferencia.idonda
                 and m.idnotafiscal = r_conferencia.idnotafiscal
                 and nvl(lt.descr, 0) =
                     nvl(r_conferencia.ltIndustria, nvl(lt.descr, 0))
                 and rownum = 1;
            exception
              when no_data_found then
                if (r_conferencia.ltIndustria is not null) then
                  v_msg := t_message('A informação específica não pertence ao lote indústria: {0}');
                  v_msg.addParam(r_conferencia.ltIndustria);
                  raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                          v_msg.formatMessage);
                else
                  v_msg := t_message('A informação específica não pertence ao produto id: {0}');
                  v_msg.addParam(r_produtoConferencia.Idproduto);
                  raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                          v_msg.formatMessage);
                end if;
            end;
          end if;
        
          select count(1)
            into v_loteExiste
            from v_tarefas_onda m, local ld
           where m.idonda = r_conferencia.idonda
             and m.status in (2, decode(ld.tipo, 3, 1, 2))
             and ld.id = m.idlocaldestino
             and m.idlocaldestino = r_conferencia.idenderecopacking
             and m.idnotafiscal = r_conferencia.idnotafiscal
             and m.qtdeemvolume < m.qtdemovimentada
             and m.codbarratarefa =
                 nvl(r_conferencia.codbarratarefa, m.codbarratarefa)
             and m.idlote = r_estoqueinfo.idlote;
        
          if (v_loteExiste = 0) then
            v_msg := t_message('A informação específica não pertence a esta conferência.');
            raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                    v_msg.formatMessage);
          end if;
        
          update estoqueinformacaoespecifica e
             set e.conferido     = 1,
                 e.idconfpacking = p_idconfpacking,
                 e.idnotafiscal  = r_conferencia.idnotafiscal,
                 e.operacao      = 'CONFERENCIA PACKING',
                 e.nrooperacao   = p_idconfpacking
           where e.idproduto = r_estoqueinfo.idproduto
             and e.identidade = r_conferencia.iddepositante
             and e.idlote = r_estoqueinfo.idlote
             AND e.conferido = 0;
        
          if (sql%rowcount = 0) then
            rollback;
            v_msg := t_message('NÃO FOI POSSÍVEL CONFERIR O PRODUTO NA RASTREABILIDADE COMPLETA! ' ||
                               chr(13) || 'IDNOTAFISCAL: {0}' || chr(13) ||
                               'IDPRODUTO: {1}' || chr(13) ||
                               'IDDEPOSITANTE: {2}' || chr(13) ||
                               'IDLOTE: {3}');
          
            v_msg.addParam(r_conferencia.idnotafiscal);
            v_msg.addParam(r_estoqueinfo.idproduto);
            v_msg.addParam(r_conferencia.iddepositante);
            v_msg.addParam(r_estoqueinfo.idlote);
          
            raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                    v_msg.formatMessage);
          end if;
        
          inserirProdConfPacking(p_idconfPacking,
                                 r_produtoConferencia.Idproduto,
                                 r_embalagemConf.Barra, 1, v_idInfoMaterial,
                                 v_valor, r_conferencia.ltIndustria,
                                 r_conferencia.dtVencimento);
        
        end rastreabilidadeCompleta;
      
        procedure rastreabilidadeEntradaSaida is
          v_idlote           number;
          v_QtdInfoInformada number;
        begin
          select count(1)
            into v_QtdInfoInformada
            from gtt_infespecconfpacking;
        
          if (v_QtdInfoInformada = 0) then
            v_msg := t_message('Para prosseguir a conferência é necessário coletar informações específicas');
            raise_application_error(C_SOLICITAR_INFOESPEC,
                                    v_msg.formatMessage);
          end if;
        
          begin
            select ei.identificadorinfo, upper(g.valor), im.informacao,
                   im.idinfomaterial
              into v_identificadorInfo, v_valor, v_informacao,
                   v_idInfoMaterial
              from GTT_INFESPECCONFPACKING g, informacaomatdep imd,
                   informacaomaterial im, estoqueinformacaoespecifica ei
             where imd.idproduto = g.idproduto
               and imd.identidade = r_conferencia.iddepositante
               and imd.valorunico = 'S'
               and im.idinfomaterial = imd.idinfomaterial
               and ei.idproduto(+) = g.idproduto
               and ei.valor(+) = upper(g.valor)
               and ei.conferido = C_NAO
               and ei.idlote is null
               and rownum = 1;
          exception
            when no_data_found then
              select upper(g.valor)
                into v_valor
                from gtt_infespecconfpacking g
               where rownum = 1;
              v_msg := t_message('Não foi encontrada informação específica única com valor ' ||
                                 '{0} pendente de conferência para o produto ' ||
                                 '{1} com código interno {2}.');
              v_msg.addParam(v_valor);
              v_msg.addParam(r_produtoConferencia.Descricao);
              v_msg.addParam(r_produtoconferencia.codigointerno);
              raise_application_error(C_INFO_ESPEC_NAO_ENCONTRADA,
                                      v_msg.formatMessage);
          end;
        
          begin
            select idlote
              into v_idlote
              from (select m.idlote
                       from v_tarefas_onda m, local ld, lote lt
                      where m.idonda = r_conferencia.idonda
                        and m.status in (2, decode(ld.tipo, 3, 1, 2))
                        and ld.id = m.idlocaldestino
                        and m.idlocaldestino =
                            r_conferencia.idenderecopacking
                        and m.idnotafiscal = r_conferencia.idnotafiscal
                        and m.qtdeemvolume < m.qtdemovimentada
                        and m.codbarratarefa =
                            nvl(r_conferencia.codbarratarefa, m.codbarratarefa)
                        and lt.idlote = m.idlote
                        and lt.idproduto = r_produtoConferencia.idproduto
                      group by m.idlote, m.idnotafiscal
                     having sum(m.quantidade) > (select count(distinct
                                                              e.identificadorinfo)
                                                  from estoqueinformacaoespecifica e,
                                                       produtodepositante pd
                                                 where e.idlote = m.idlote
                                                   and e.idnotafiscal =
                                                       m.idnotafiscal
                                                   and e.idconfpacking =
                                                       p_idConfPacking
                                                   and pd.identidade =
                                                       r_produtoConferencia.Iddepositante
                                                   and pd.idproduto =
                                                       e.idproduto
                                                   and pd.rastrearinfoespecifica =
                                                       C_RAST_ENTRADA_SAIDA))
             where rownum = 1;
          exception
            when no_data_found then
              v_msg := t_message('A informação específica não pertence a esta conferência.');
              raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                      v_msg.formatMessage);
          end;
        
          update estoqueinformacaoespecifica e
             set e.conferido     = 1,
                 e.idconfpacking = p_idconfpacking,
                 e.idlote        = v_idlote,
                 e.idnotafiscal  = r_conferencia.idnotafiscal,
                 e.operacao      = 'CONFERENCIA PACKING',
                 e.nrooperacao   = p_idconfpacking
           where e.idproduto = r_produtoConferencia.idproduto
             and e.identidade = r_conferencia.iddepositante
             and e.identificadorinfo = v_identificadorinfo
             and e.conferido = 0;
        
          if (sql%rowcount = 0) then
            rollback;
            v_msg := t_message('NÃO FOI POSSÍVEL CONFERIR O PRODUTO NA RASTREABILIDADE ENTRADA E SAÍDA!! ' ||
                               chr(13) || 'IDNOTAFISCAL: {0}' || chr(13) ||
                               'IDPRODUTO: {1}' || chr(13) ||
                               'IDDEPOSITANTE: {2}' || chr(13) ||
                               'IDENTIFICADORINFO: {3}');
          
            v_msg.addParam(r_conferencia.idnotafiscal);
            v_msg.addParam(r_estoqueinfo.idproduto);
            v_msg.addParam(r_conferencia.iddepositante);
            v_msg.addParam(r_estoqueinfo.identificadorinfo);
          
            raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                    v_msg.formatMessage);
          end if;
        
          inserirProdConfPacking(p_idconfPacking,
                                 r_produtoConferencia.Idproduto,
                                 r_embalagemConf.Barra, 1, v_idInfoMaterial,
                                 v_valor, r_conferencia.ltIndustria,
                                 r_conferencia.dtVencimento);
        
        end rastreabilidadeEntradaSaida;
      
        procedure rastreabilidadeSomenteSaida is
          v_idlote            number;
          v_identificadorInfo number;
          v_idlotenf          number;
          v_QtdInfoInformada  number;
          v_idinfomaterial    number;
          v_valor             estoqueinformacaoespecifica.valor%type;
        begin
          select count(1)
            into v_QtdInfoInformada
            from gtt_infespecconfpacking;
        
          if (v_QtdInfoInformada = 0) then
            v_msg := t_message('Para prosseguir a conferência é necessário coletar informações específicas');
            raise_application_error(C_SOLICITAR_INFOESPEC,
                                    v_msg.formatMessage);
          end if;
        
          select upper(g.valor), g.idinfomaterial
            into v_valor, v_idinfomaterial
            from gtt_infespecconfpacking g, informacaomatdep imd
           where imd.identidade = r_conferencia.iddepositante
             and imd.idproduto = g.idproduto
             and imd.idinfomaterial = g.idinfomaterial
             and imd.valorunico = 'S'
             and rownum = 1;
        
          begin
            select idlote
              into v_idlote
              from (select m.idlote
                       from v_tarefas_onda m, local ld, lote lt
                      where m.idonda = r_conferencia.idonda
                        and m.status in (2, decode(ld.tipo, 3, 1, 2))
                        and ld.id = m.idlocaldestino
                        and m.idlocaldestino =
                            r_conferencia.idenderecopacking
                        and m.idnotafiscal = r_conferencia.idnotafiscal
                        and m.qtdeemvolume < m.qtdemovimentada
                        and m.codbarratarefa =
                            nvl(r_conferencia.codbarratarefa, m.codbarratarefa)
                        and lt.idlote = m.idlote
                        and lt.idproduto = r_produtoConferencia.idproduto
                      group by m.idlote, m.idnotafiscal
                     having sum(m.quantidade) > (select count(distinct
                                                              e.identificadorinfo)
                                                  from estoqueinformacaoespecifica e,
                                                       produtodepositante pd
                                                 where e.idlote = m.idlote
                                                   and e.idnotafiscal =
                                                       m.idnotafiscal
                                                   and e.idconfpacking =
                                                       p_idConfPacking
                                                   and pd.identidade =
                                                       r_produtoConferencia.Iddepositante
                                                   and pd.idproduto =
                                                       e.idproduto
                                                   and pd.rastrearinfoespecifica =
                                                       C_RAST_SOMENTE_SAIDA))
             where rownum = 1;
          exception
            when no_data_found then
              v_msg := t_message('A quantidade de produtos em separação é menor que quantidade de informações coletadas para o produto ' ||
                                 '{0}-{1}');
              v_msg.addParam(r_produtoConferencia.Codigointerno);
              v_msg.addParam(r_produtoConferencia.Descricao);
              raise_application_error(C_QTD_INFOESPEC_DIV_QTDE,
                                      v_msg.formatMessage);
          end;
        
          v_identificadorInfo := null;
        
          select count(1)
            into v_existeInformacao
            from estoqueinformacaoespecifica ei, informacaomatdep i,
                 gtt_infespecconfpacking g
           where ei.valor = upper(g.valor)
             and ei.idproduto = g.idproduto
             and ei.identidade = r_conferencia.iddepositante
             and ei.expedida = 0
             and i.idinfomaterial = ei.idinfomaterial
             and i.idproduto = ei.idproduto
             and i.identidade = ei.identidade
             and i.valorunico = 'S';
        
          if (v_existeInformacao > 0) then
            v_msg := t_message('Informação específica {0}' ||
                               ' já foi conferida para o produto ' ||
                               '{1} e seu valor deve ser único.');
            v_msg.addParam(v_valor);
            v_msg.addParam(r_produtoConferencia.idproduto);
            raise_application_error(C_INFO_ESPEC_JA_CONFERIDA,
                                    v_msg.formatMessage);
          end if;
        
          if (v_identificadorInfo is null) then
            select seq_identificadorinfo.nextval
              into v_identificadorInfo
              from dual;
          end if;
        
          begin
            select ol.idlotenf
              into v_idlotenf
              from orlote ol
             where ol.idlote = v_idlote;
          exception
            when no_data_found then
              v_idlotenf := null;
          end;
        
          insert into estoqueinformacaoespecifica
            (id, idproduto, identidade, idinfomaterial, valor, idlote,
             expedida, conferido, idconfpacking, idnotafiscal,
             identificadorinfo, idarmazem, operacao, nrooperacao, idlotenf)
            select seq_estinformacaoespecifica.nextval, g.idproduto,
                   r_conferencia.iddepositante, g.idinfomaterial, g.valor,
                   v_idlote, C_NAO, C_SIM, p_idconfPacking,
                   r_conferencia.idnotafiscal, v_identificadorInfo,
                   r_conferencia.idarmazem, 'CONFERENCIA PACKING',
                   p_idconfPacking, v_idlotenf
              from gtt_infespecconfpacking g
             where upper(g.valor) = v_valor;
        
          if (sql%rowcount = 0) then
            rollback;
            v_msg := t_message('NÃO FOI POSSÍVEL CONFERIR O PRODUTO NA RASTREABILIDADE SOMENTE SAÍDA!! ' ||
                               chr(13) || 'IDNOTAFISCAL: {0}' || chr(13) ||
                               'IDPRODUTO: {1}' || chr(13) ||
                               'IDDEPOSITANTE: {2}' || chr(13) ||
                               'IDENTIFICADORINFO: {3}');
          
            v_msg.addParam(r_conferencia.idnotafiscal);
            v_msg.addParam(r_estoqueinfo.idproduto);
            v_msg.addParam(r_conferencia.iddepositante);
            v_msg.addParam(r_estoqueinfo.identificadorinfo);
          
            raise_application_error(C_INFOESPEC_NAOPERTENCE_CONF,
                                    v_msg.formatMessage);
          end if;
        
          inserirProdConfPacking(p_idconfPacking,
                                 r_produtoConferencia.Idproduto,
                                 r_embalagemConf.Barra, 1, v_idinfomaterial,
                                 v_valor, r_conferencia.ltIndustria,
                                 r_conferencia.dtVencimento);
        end rastreabilidadeSomenteSaida;
      begin
      
        if (r_produtoConferencia.Tiporastinfoespec = C_RAST_SOMENTE_SAIDA) then
          rastreabilidadeSomenteSaida;
          return;
        end if;
      
        if (r_produtoConferencia.Tiporastinfoespec = C_RAST_ENTRADA_SAIDA) then
          rastreabilidadeEntradaSaida;
          return;
        end if;
      
        if (r_produtoConferencia.Tiporastinfoespec =
           C_RAST_TODA_MOVIMENTACAO) then
          rastreabilidadeCompleta;
          return;
        end if;
      end conferirInformacaoEspecifica;
    
    begin
      if (r_produtoConferencia.Possuiinfespecifica > 0) then
        conferirInformacaoEspecifica;
        return;
      end if;
    
      select decode(nvl(r_conferencia.autoconferirqtde, 0), 0, 1,
                     r_conferencia.autoconferirqtde)
        into v_qtdeIdentificada
        from dual;
    
      r_produtoConferencia.Qtdecontada := r_produtoConferencia.Qtdecontada +
                                          (nvl(v_qtde, v_qtdeIdentificada) *
                                          r_produtoConferencia.Fatorconversaoembalagem);
    
      inserirProdConfPacking(p_idconfPacking,
                             r_produtoConferencia.Idproduto,
                             r_embalagemConf.Barra,
                             nvl(v_qtde, v_qtdeIdentificada), null, null,
                             r_conferencia.ltIndustria,
                             r_conferencia.dtVencimento);
    end realizarConferencia;
  
    procedure alertaTipoCaixaVolPacking is
      v_msg varchar(4000);
    begin
      if ((r_conferencia.alertatipocaixamontagem = 0) or
         (r_conferencia.conferenciacegapacking = 1)) then
        r_produtoConferencia.Possuisugestaoembalagem := 0;
        r_produtoConferencia.Sugestaoembalagem       := null;
        return;
      end if;
      if ((r_produtoConferencia.Qtdecontada = 0) and
         (r_produtoConferencia.Qtdeemvolume = 0)) then
      
        if (pk_produto.isExibirPontoAlerta(r_produtoConferencia.Idproduto,
                                           nvl(r_produtoConferencia.Qtdeseparada,
                                                1), r_conferencia.idonda,
                                           r_conferencia.codbarratarefa) =
           EXIBE_ALERTA_PACKING) then
        
          r_produtoConferencia.Possuisugestaoembalagem := C_SIM;
          v_msg                                        := pk_produto.sugestaoEmbalagem(r_produtoConferencia.Idproduto,
                                                                                       nvl(r_produtoConferencia.Qtdeseparada,
                                                                                            1));
          if (v_msg is not null) then
            r_produtoConferencia.Sugestaoembalagem := 'O Produto deverá ser embalado em Caixa do Tipo: ' ||
                                                      chr(13) || v_msg;
          end if;
        end if;
      end if;
    end alertaTipoCaixaVolPacking;
  
    procedure gerarVolumeCaixaFechada is
      v_totalProdutoUnitario  number;
      v_totalProdutoCxFechada number;
    begin
      if (p_solicitaCaixa = 1) then
        return;
      end if;
    
      if (r_conferencia.montvolautocxfchdapack = 0) then
        return;
      end if;
    
      if (r_conferencia.seppkporestacao = 1) then
        return;
      end if;
    
      -- se o tipo de caixa fechada a considerar para geração de volume de caixa fechada for o padrão
      -- e a embalagem é fator 1 e não for caixa fechada, então não gera volume    
      if (r_conferencia.tipovolumecaixafechada = C_FATOR_MAIOR_1_CX_FECHADA and
         r_embalagemConf.fatorconversao = 1 and
         r_embalagemConf.caixafechada = 'N') then
        return;
        -- se o tipo de caixa fechada a considerar para geração de volume de caixa fechada for somente
        -- embalagens configuradas como caixa fechada na conferencia de saída e a embalagem nao estiver
        -- parametrizada, então não gera volume
      elsif (r_conferencia.tipovolumecaixafechada =
            C_CAIXA_FECHADA_CONF_SAIDA and
            r_embalagemConf.caixafechadaconfsaida = 0) then
        return;
      end if;
    
      if (r_produtoConferencia.qtdetotal =
         r_produtoConferencia.qtdeemvolume) then
        return;
      end if;
    
      select count(1)
        into v_totalProdutoUnitario
        from produtoconfpacking pc, confpacking cp, embalagem e
       where pc.idconfpacking = cp.id
         and pc.status = 1
         and cp.status = C_STATUS_EM_CONTAGEM
         and cp.idnotafiscal = r_conferencia.idnotafiscal
         and pc.idconfpacking = r_conferencia.idconfpacking
         and pc.barra = e.barra
         and pc.idproduto = e.idproduto
         and ((r_conferencia.tipovolumecaixafechada =
             C_FATOR_MAIOR_1_CX_FECHADA and e.fatorconversao = 1 and
             e.caixafechada = 'N') or
             (r_conferencia.tipovolumecaixafechada =
             C_CAIXA_FECHADA_CONF_SAIDA and e.caixafechadaconfsaida = 0));
    
      if (v_totalProdutoUnitario > 0) then
        v_msg := t_message('Ja existem produtos contados no volume, para gerar um volume de caixa fechada primeiro gere o volume dos produtos ja contados.');
        raise_application_error(C_ERRO_MONT_VOLUME, v_msg.formatMessage);
      end if;
    
      if (r_conferencia.validarCxFechadaPacking = C_SIM) then
        select count(1)
          into v_totalProdutoCxFechada
          from produtoconfpacking pc, confpacking cp, embalagem e
         where pc.idconfpacking = cp.id
           and pc.status = 1
           and cp.status = 0
           and cp.idnotafiscal = r_conferencia.idnotafiscal
           and pc.idconfpacking = r_conferencia.idconfpacking
           and pc.barra = e.barra
           and pc.idproduto = e.idproduto
           and (e.fatorconversao > 1 or e.caixafechada = 'S');
      
        if (v_totalProdutoCxFechada > 1) then
          v_msg := t_message('Ja existem produtos contados no volume, para gerar um volume de caixa fechada primeiro gere o volume dos produtos ja contados.');
          raise_application_error(C_ERRO_MONT_VOLUME, v_msg.formatMessage);
        end if;
      end if;
    
      definirCaixaReutilizavel(p_idconfPacking, r_embalagemConf.Barra);
    
      v_resultado_conferencia := C_GERAR_VOLUME_CAIXA_FECHADA;
    end gerarVolumeCaixaFechada;
  
    procedure validarLoteConferido is
      v_qtdeMovimentacao       number;
      v_qtdeConferencia        number;
      v_validarmovloteconf     number;
      v_coletadtavenclote      produtodepositante.coletadtavenclote%type;
      v_dtVencLoteIndExisteMov number;
    begin
      select conf.validarmovloteconf
        into v_validarmovloteconf
        from configuracao conf
       where conf.ativo = 'S';
    
      if (v_validarmovloteconf = 0) then
        return;
      end if;
    
      if (r_conferencia.tipoconferencia in
         (C_TIPO_CONF_LOTE, C_TIPO_CONF_LOTE_CTRL_LT_IND)) then
        select nvl(sum(m.quantidade), 0)
          into v_qtdeMovimentacao
          from movimentacao m, lote lt
         where lt.idlote = m.idlote
           and m.idonda = r_conferencia.idonda
           and m.idnotafiscal = r_conferencia.idnotafiscal
           and m.status <> STATUS_MOV_CANCELADO
           and lt.idproduto = r_produtoconferencia.idproduto
           and lt.idarmazem = r_conferencia.idarmazem
           and upper(lt.descr) = upper(r_conferencia.ltIndustria);
      
        select nvl(sum(pc.qtde * e.fatorconversao), 0)
          into v_qtdeConferencia
          from confpacking cf, produtoconfpacking pc, embalagem e
         where pc.status = 1
           and cf.status in (C_STATUS_EM_CONTAGEM, C_STATUS_VOLUME_MONTADO)
           and cf.id = pc.idconfpacking
           and cf.idonda = r_conferencia.idonda
           and cf.idnotafiscal = r_conferencia.idnotafiscal
           and pc.idproduto = r_produtoconferencia.idproduto
           and upper(pc.loteindustria) = upper(r_conferencia.ltIndustria)
           and e.idproduto = pc.idproduto
           and e.barra = pc.barra;
      
        if (v_qtdeConferencia > v_qtdeMovimentacao) then
          v_msg := t_message('Quantidade do lote {0} excedida.' || chr(13) ||
                             'Quantidade solicitada: {1}' || chr(13) ||
                             'Quantidade conferida: {2}' || chr(13) ||
                             'Produto: {3}');
          v_msg.addParam(r_conferencia.ltIndustria);
          v_msg.addParam(v_qtdeMovimentacao);
          v_msg.addParam(v_qtdeConferencia);
          v_msg.addParam(r_produtoConferencia.codigoInterno);
        
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select nvl(pd.coletadtavenclote, 0)
          into v_coletadtavenclote
          from produtodepositante pd
         where 1 = 1
           and pd.idproduto = r_produtoConferencia.Idproduto
           and pd.identidade = r_produtoConferencia.Iddepositante;
      
        if (v_coletadtavenclote in (1, 3) and
           r_conferencia.ltIndustria is not null and
           r_conferencia.dtVencimento is not null) then
        
          select count(1)
            into v_dtVencLoteIndExisteMov
            from movimentacao m, lote lt, produtodepositante pd
           where lt.idlote = m.idlote
             and pd.idproduto = lt.idproduto
             and pd.identidade = lt.iddepositante
             and m.idonda = r_conferencia.idonda
             and m.idnotafiscal = r_conferencia.idnotafiscal
             and m.status <> STATUS_MOV_CANCELADO
             and lt.idproduto = r_produtoconferencia.idproduto
             and lt.idarmazem = r_conferencia.idarmazem
             and upper(lt.descr) = upper(r_conferencia.ltIndustria)
             and decode(pd.validarmesano, 0, trunc(nvl(lt.dtvenc, sysdate)),
                        last_day(trunc(nvl(lt.dtvenc, sysdate)))) =
                 decode(pd.validarmesano, 0,
                        trunc(r_conferencia.dtVencimento),
                        last_day(trunc(r_conferencia.dtVencimento)));
        
          if (v_dtVencLoteIndExisteMov = 0) then
            v_msg := t_message('Quantidade do lote {0} excedida.' ||
                               chr(13) || 'Quantidade solicitada: {1}' ||
                               chr(13) || 'Quantidade conferida: {2}' ||
                               chr(13) || 'Produto: {3}');
            v_msg.addParam(r_conferencia.ltIndustria);
            v_msg.addParam(v_qtdeMovimentacao);
            v_msg.addParam(v_qtdeConferencia);
            v_msg.addParam(r_produtoConferencia.codigoInterno);
          
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        end if;
      
      end if;
    end validarLoteConferido;
  
  begin
    begin
      carregarConfPacking;
      validarUsuarioConferencia;
      identificarEmbalagemConf;
      validarEmbalagem;
      buscarProdutoPendente;
      validarCancelamentoProduto;
      validarProdutoPendente;
      alertaTipoCaixaVolPacking;
      validarConferencia;
      realizarConferencia;
      validarLoteConferido;
    
      if (r_conferencia.Codbarratarefa is null) then
        buscarProdutoPorLote;
      end if;
    
      if (v_pedeQuantidadeCaixa = 0) then
        gerarVolumeCaixaFechada;
      
        if (p_checkout = 1 or r_conferencia.checkout = 1) then
          if (definirCaixaVolAutoCheckout(p_idconfPacking)) then
            v_resultado_conferencia := C_GERAR_VOLUME_CAIXA_FECHADA;
          else
            v_resultado_conferencia := C_GERAR_VOLUME_CHECKOUT;
          end if;
        end if;
      else
        definirCaixaReutilizavel(p_idconfPacking, r_embalagemConf.barra);
      end if;
    
      inserirDadosRetorno(v_resultado_conferencia,
                          'Conferência do produto ' ||
                           r_produtoConferencia.Descricao ||
                           ' realizada com sucesso.');
    exception
      when E_CONFPACKING_NOTFOUND
           or E_USERCONF_DIVERGENTE
           or E_EMBALAGEM_NOTFOUND
           or E_EMBALAGEM_INATIVA
           or E_NAO_IDENT_POR_LOTE
           or E_NAO_E_PALETEFECHADO
           or E_PRDCONF_NAOPOSSUIRESTQTDCONF
           or E_INFORME_BARRAFATOR_UNIT
           or E_INFOESPEC_NAOPERTENCE_CONF
           or E_SOLICITAR_INFOESPEC
           or E_QTD_INFOESPEC_DIV_QTDE
           or E_SOLICITAR_QTDE
           or E_INFO_ESPEC_JA_CONFERIDA
           or E_SOLICITA_VENCIMENTO
           or E_SOLICITA_LOTE_INDUSTRIA
           or E_SOLICITA_IDENTIFICADORPROD
           or E_ERRO_MONT_VOLUME
           or E_LOTE_IND_FORA_CONF
           or E_SOLICITA_QTDE_CAIXA_VOLUME
           or E_VARIOS_LOTEINDUSTRIA
           or E_SOLICITAR_CONFCANCEL
           or E_SOLICITAR_CONFCANCEL_LOCAL then
        inserirDadosRetorno(sqlcode, sqlerrm);
      when E_PRODUTOCONF_NOTFOUND then
        getTipoErroProdutoConfNotFound(sqlcode);
    end;
  end entrarBarraOuLoteConferencia;

  procedure obterDadosPosGeracaoVolume
  (
    p_idConfPacking    in number,
    p_idVolumeRomaneio in number
  ) is
    r_volumeRomaneio      volumeromaneio%rowtype;
    r_dadospormontvolumes gtt_dadospormontvolumes%rowtype;
  
    procedure carregarDadosVolume is
    begin
      select vr.*
        into r_volumeRomaneio
        from volumeromaneio vr
       where vr.idvolumeromaneio = p_idVolumeRomaneio;
    end carregarDadosVolume;
  
    procedure verificarProdutoEmbPresente is
    begin
      select count(1)
        into r_dadospormontvolumes.prdembpresente
        from ordemseparacao os, ordemseparacaoitem osi
       where os.idnotafiscal = r_volumeRomaneio.Idnotafiscal
         and osi.idordemsep = os.idordemseparacao
         and osi.giftwrapid is not null;
    end verificarProdutoEmbPresente;
  
    procedure verificaPresenteSemEmb is
    begin
      select count(1)
        into r_dadospormontvolumes.prdnaoembpresente
        from ordemseparacao os, ordemseparacaoitem osi
       where os.idnotafiscal = r_volumeRomaneio.Idnotafiscal
         and osi.idordemsep = os.idordemseparacao
         and osi.giftwrapid is null;
    end verificaPresenteSemEmb;
  
    procedure embalarParaPresente is
    begin
      select nvl(sum(conta.qtdItem - conta.qtdVolumes), -1) qtd
        into r_dadospormontvolumes.embalarpresente
        from (select nvl(item.qtd, 0) qtdItem,
                      nvl(outrovol.qtd, 0) qtdVolumes
                 from (select sum(osi.qtdeitem) qtd, osi.idproduto
                          from ordemseparacao os, ordemseparacaoitem osi
                         where os.idnotafiscal = r_volumeRomaneio.Idnotafiscal
                           and osi.idordemsep = os.idordemseparacao
                           and osi.giftwrapid is not null
                         group by osi.idproduto) item,
                      (select sum(cv.quantidade) qtd, lt.idproduto
                          from volumeromaneio vr, conteudovolume cv, lote lt
                         where vr.idnotafiscal = r_volumeRomaneio.Idnotafiscal
                           and vr.idvolumeromaneio <>
                               r_volumeRomaneio.Idvolumeromaneio
                           and cv.idvolumeromaneio = vr.idvolumeromaneio
                           and lt.idlote = cv.idlote
                         group by lt.idproduto) outrovol
                where outrovol.idproduto(+) = item.idproduto) conta;
    end embalarParaPresente;
  
    procedure verificaPedidoConcluido is
      r_confPacking confpacking%rowtype;
    begin
      select decode(count(1), 0, 1, 0)
        into r_dadospormontvolumes.pedidoconcluido
        from (select 1 qtde
                 from (select m.idonda, pa.idendereco idenderecopacking,
                               m.idnotafiscal, lt.idproduto, p.codigointerno,
                               p.descr descricao, sum(m.quantidade) qtdetotal,
                               0 qtdecontada, 0 qtdeemvolume,
                               sum(decode(m.status, 2, m.quantidade, 0)) qtdeseparada,
                               p.fracionado, p.pesavel, lt.iddepositante,
                               null data
                          from confpacking c, movimentacao m, lote lt, produto p,
                               packing pa
                         where c.id = p_idConfPacking
                           and m.idonda = c.idonda
                           and pa.idendereco = c.idpacking
                           and m.idnotafiscal = c.idnotafiscal
                           and m.idlocaldestino = pa.idendereco
                           and m.status in (0, 1, 2)
                           and lt.idlote = m.idlote
                           and p.idproduto = lt.idproduto
                         group by m.idonda, pa.idendereco, m.idnotafiscal,
                                  lt.idproduto, p.codigointerno, p.descr,
                                  p.fracionado, p.pesavel, lt.iddepositante
                        having sum(m.quantidade) > 0
                        union all
                        select c.idonda, c.idpacking idenderecopacking,
                               c.idnotafiscal, pc.idproduto, p.codigointerno,
                               p.descr descricao, 0 qtdetotal,
                               nvl(sum(pc.qtde * e.fatorconversao), 0) qtdecontada,
                               0 qtdeemvolume, 0 qtdeseparada, p.fracionado,
                               p.pesavel, n.iddepositante, pc.data
                          from confpacking c, produtoconfpacking pc, produto p,
                               embalagem e, romaneiopai rp, notafiscal n,
                               nfromaneio nfr
                         where c.id = p_idConfPacking
                           and pc.idconfpacking = c.id
                           and pc.status = 1
                           and p.idproduto = pc.idproduto
                           and c.status = 0
                           and c.idnotafiscal = n.idnotafiscal
                           and e.idproduto = pc.idproduto
                           and e.barra = pc.barra
                           and rp.idromaneio = c.idonda
                           and rp.statusonda in (2, 4)
                           and nfr.idromaneio = rp.idromaneio
                           and nfr.idnotafiscal = n.idnotafiscal
                         group by c.idonda, c.idpacking, c.idnotafiscal,
                                  pc.idproduto, p.codigointerno, p.descr,
                                  p.fracionado, p.pesavel, n.iddepositante,
                                  pc.data
                        union all
                        select m.idonda, pa.idendereco idenderecopacking,
                               m.idnotafiscal, lt.idproduto, p.codigointerno,
                               p.descr descricao, 0 qtdetotal, 0 qtdecontada,
                               nvl(sum(cv.quantidade +
                                        nvl((select sum(cva.quantidaderemovida)
                                              from cortevolumeauditoria cva,
                                                   cortefisico cf
                                             where cva.idconteudovolume = cv.id
                                               and cf.id = cva.idcortefisico
                                               and cf.status in (0, 1)), 0)), 0) qtdeemvolume,
                               0 qtdeseparada, p.fracionado, p.pesavel,
                               lt.iddepositante, null data
                          from confpacking c, movimentacao m, conteudoVolume cv,
                               lote lt, produto p, packing pa
                         where c.id = p_idConfPacking
                           and m.idonda = c.idonda
                           and pa.idendereco = c.idpacking
                           and m.idnotafiscal = c.idnotafiscal
                           and m.status in (0, 1, 2)
                           and cv.idvolumeromaneio = m.idvolumeromaneio
                           and lt.idlote = cv.idlote
                           and p.idproduto = lt.idproduto
                           and pa.idendereco = m.idlocalorigem
                         group by m.idonda, pa.idendereco, m.idnotafiscal,
                                  lt.idproduto, p.codigointerno, p.descr,
                                  p.fracionado, p.pesavel, lt.iddepositante,
                                  lt.descr, lt.dtvenc) z,
                      produtodepositante pd
                where z.idproduto = pd.idproduto
                  and z.iddepositante = pd.identidade
                group by idonda, idenderecopacking, idnotafiscal, z.idproduto,
                         z.codigointerno, descricao, fracionado, pesavel,
                         iddepositante
               having(sum(z.qtdetotal) - decode(pesavel, 1,((sum(z.qtdetotal) / 100) * pk_produto.retornarPercentualTolerancia(z.idproduto, z.iddepositante, 'S')), 0) - sum(z.qtdeemvolume) > 0 or sum(z.qtdeemvolume) = 0));
    
    end verificaPedidoConcluido;
  
    procedure getQtdSugeridaEtqTransportador is
      v_isImprimeEtiquetaTrans number;
    begin
      if (r_dadospormontvolumes.pedidoconcluido = 0) then
        r_dadospormontvolumes.qtdsugeridaetqtransportador := 0;
        return;
      end if;
    
      select nf.imprimeetiquetatransportador
        into v_isImprimeEtiquetaTrans
        from notafiscal nf
       where nf.idnotafiscal = r_volumeRomaneio.Idnotafiscal;
    
      if (v_isImprimeEtiquetaTrans = 0) then
        r_dadospormontvolumes.qtdsugeridaetqtransportador := 0;
        return;
      end if;
    
      r_dadospormontvolumes.qtdsugeridaetqtransportador := pk_transporte.retornarQtdeEtiqTransportador(r_volumeRomaneio.idnotafiscal);
    
    end getQtdSugeridaEtqTransportador;
  begin
    carregarDadosVolume;
    embalarParaPresente;
    verificarProdutoEmbPresente;
    r_dadospormontvolumes.contemmensagempresente := verificarMensagemPresente(r_volumeromaneio.idnotafiscal,
                                                                              r_volumeromaneio.idvolumeromaneio);
    r_dadospormontvolumes.contemmensagemproduto  := verificarMensagemProduto(r_volumeromaneio.idnotafiscal,
                                                                             r_volumeromaneio.idvolumeromaneio);
    verificaPresenteSemEmb;
    verificaPedidoConcluido;
    getQtdSugeridaEtqTransportador;
  
    insert into GTT_DADOSPORMONTVOLUMES
    values r_dadospormontvolumes;
  end obterDadosPosGeracaoVolume;

  procedure cancelarContagens
  (
    p_idConfPacking in number,
    p_idProduto     in number,
    p_idUsuario     in number
  ) is
    C_RAST_TODA_MOVIMENTACAO constant number := 0;
    C_RAST_ENTRADA_SAIDA     constant number := 1;
    C_RAST_SOMENTE_SAIDA     constant number := 2;
  
    procedure cancelarContagemInfoEspec
    (
      p_idConf              in number,
      p_idNotaFiscal        in number,
      p_idPrd               in number,
      p_tipoRastreabilidade in number
    ) is
      procedure cancelarRastSomenteSaida is
      begin
        insert into historicoestoqueinfespec
          (id, idarmazem, idproduto, identidade, idinfomaterial,
           identificadorinfo, numerooperacao, operacao, dataoperacao,
           valorantes, valordepois, idloteantes, idlotedepois,
           conferidoantes, conferidodepois, expedidoantes, expedidodepois)
          select seq_historicoestoqueinfespec.nextval, e.idarmazem,
                 e.idproduto, e.identidade, e.idinfomaterial,
                 e.identificadorinfo, p_idConf,
                 'CANCELAMENTO CONTAGEM PACKING', sysdate, e.valor, e.valor,
                 e.idlote, e.idlote, e.conferido, e.conferido, e.expedida,
                 e.expedida
            from estoqueinformacaoespecifica e
           where e.idnotafiscal = p_idNotaFiscal
             and e.idconfpacking = p_idConf
             and e.idproduto = p_idPrd
             and e.expedida = 0
             and e.conferido = 1
             and e.idvolumeromaneio is null;
      
        delete from estoqueinformacaoespecifica ei
         where ei.idnotafiscal = p_idNotaFiscal
           and ei.idconfpacking = p_idConf
           and ei.idproduto = p_idPrd
           and ei.expedida = 0
           and ei.conferido = 1
           and ei.idvolumeromaneio is null;
      end cancelarRastSomenteSaida;
    
      procedure cancelarRastEntradaSaida is
      begin
        update estoqueinformacaoespecifica ei
           set ei.conferido     = 0,
               ei.idlote        = null,
               ei.idnotafiscal  = null,
               ei.idconfpacking = null,
               ei.nrooperacao   = p_idConf,
               ei.operacao      = 'CANCELAMENTO CONTAGEM PACKING'
         where ei.idnotafiscal = p_idNotaFiscal
           and ei.idconfpacking = p_idConf
           and ei.idproduto = p_idPrd
           and ei.expedida = 0
           and ei.conferido = 1
           and ei.idvolumeromaneio is null;
      end cancelarRastEntradaSaida;
    
      procedure cancelarRastCompleto is
      begin
        update estoqueinformacaoespecifica ei
           set ei.conferido     = 0,
               ei.idconfpacking = null,
               ei.idnotafiscal  = null,
               ei.nrooperacao   = p_idConf,
               ei.operacao      = 'CANCELAMENTO CONTAGEM PACKING'
         where ei.idnotafiscal = p_idNotaFiscal
           and ei.idconfpacking = p_idConf
           and ei.idproduto = p_idPrd
           and ei.expedida = 0
           and ei.conferido = 1
           and ei.idvolumeromaneio is null;
      end cancelarRastCompleto;
    begin
      if (p_tipoRastreabilidade = C_RAST_TODA_MOVIMENTACAO) then
        cancelarRastCompleto;
        return;
      end if;
      if (p_tipoRastreabilidade = C_RAST_ENTRADA_SAIDA) then
        cancelarRastEntradaSaida;
        return;
      end if;
      if (p_tipoRastreabilidade = C_RAST_SOMENTE_SAIDA) then
        cancelarRastSomenteSaida;
        return;
      end if;
    end cancelarContagemInfoEspec;
  begin
    for cont in (select sum(pc.qtde * e.fatorconversao) qtde, pc.idproduto,
                        pd.rastrearinfoespecifica, nf.idnotafiscal,
                        cp.id idConfPacking, pc.id idprodconfpacking
                   from confpacking cp, produtoconfpacking pc, notafiscal nf,
                        produtodepositante pd, embalagem e
                  where cp.id = p_idConfPacking
                    and pc.idconfpacking = cp.id
                    and pc.status = 1
                    and pc.idproduto = nvl(p_idproduto, pc.idproduto)
                    and nf.idnotafiscal = cp.idnotafiscal
                    and pd.identidade = nf.iddepositante
                    and pd.idproduto = pc.idproduto
                    and e.idproduto = pc.idproduto
                    and e.barra = pc.barra
                  group by pc.idproduto, pd.rastrearinfoespecifica,
                           nf.idnotafiscal, cp.id, pc.id)
    loop
      update produtoconfpacking pc
         set pc.status           = 0,
             pc.datacancelamento = sysdate
       where pc.idproduto = cont.idproduto
         and pc.id = cont.idprodconfpacking
         and pc.idconfpacking = cont.idconfpacking;
    
      pk_utilities.GeraLog(p_idUsuario,
                           'Cancelado a contagem do idproduto: ' ||
                            cont.idproduto || ', idprodconfpacking ' ||
                            cont.idprodconfpacking || ' idconfpacking ' ||
                            cont.idconfpacking, cont.idconfpacking, 'CA');
    
      update saidapornf snf
         set snf.conferenciainiciada = decode(snf.conferenciainiciada, null,
                                              0,
                                              snf.conferenciainiciada -
                                               cont.qtde)
       where snf.idnotafiscal = cont.Idnotafiscal;
    
      cancelarContagemInfoEspec(cont.idConfPacking, cont.idNotaFiscal,
                                cont.idproduto, cont.rastrearinfoespecifica);
    
    end loop;
  end cancelarContagens;

  function carregarConfPacking(p_idConfPacking in number)
    return confpacking%rowtype is
    v_msg         t_message;
    r_confPacking confpacking%rowtype;
  begin
    begin
      select cp.*
        into r_confPacking
        from confpacking cp
       where cp.id = p_idConfPacking
         and cp.idvolumeromaneio is null;
    
      return r_confPacking;
    exception
      when no_data_found then
        v_msg := t_message('Conferência não encontrada');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  end carregarConfPacking;

  procedure validarUsuario
  (
    p_idUsuario   in number,
    p_confPacking in confpacking%rowtype
  ) is
    v_nomeUsuario usuario.nomeusuario%type;
    v_msg         t_message;
  begin
    if (p_confPacking.Idusuario <> p_idUsuario) then
      select u.nomeusuario
        into v_nomeUsuario
        from usuario u
       where u.idusuario = p_confPacking.Idusuario;
      v_msg := t_message('Conferência já inciada para o usuário {0}');
      v_msg.addParam(v_nomeUsuario);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end validarUsuario;

  procedure cancelarTodasAsContagens
  (
    p_idConfPacking in number,
    p_idUsuario     in number
  ) is
    r_confPacking confpacking%rowtype;
  
    procedure cancelarConferenciaAtual is
    begin
      update confpacking cp
         set cp.status           = C_STATUS_CANCELADO,
             cp.datacancelamento = sysdate
       where cp.id = p_idconfpacking;
    end cancelarConferenciaAtual;
  begin
    r_confPacking := carregarConfPacking(p_idConfPacking);
    validarUsuario(p_idUsuario, r_confPacking);
    cancelarContagens(r_confPacking.id, null, p_idUsuario);
    cancelarConferenciaAtual;
  end cancelarTodasAsContagens;

  procedure cancelarContagemProduto
  (
    p_idConfPacking in number,
    p_idProduto     in number,
    p_idUsuario     in number
  ) is
    r_confPacking confpacking%rowtype;
  begin
    r_confPacking := carregarConfPacking(p_idConfPacking);
    validarUsuario(p_idUsuario, r_confPacking);
    cancelarContagens(r_confPacking.id, p_idProduto, p_idUsuario);
  end cancelarContagemProduto;

  procedure entrarQtdeExcedidaProduto
  (
    p_barra          embalagem.barra%type,
    p_qtde           in number,
    p_idNotaFiscal   in number,
    p_idOnda         in number,
    p_idPacking      in number,
    p_codBarraTarefa in produtoexcedido.idtarefa%type,
    p_idUsuario      in number
  ) is
    v_isProdutoFracionado number;
    v_IdProduto           number;
    v_isEmbalagemAtiva    number;
    v_msg                 t_message;
  
    procedure validarUsuario is
      v_existe number;
    begin
      if (p_idUsuario is null) then
        v_msg := t_message('Usuário não informado.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_existe
        from usuario u
       where u.idusuario = p_idUsuario;
    
      if (v_existe = 0) then
        v_msg := t_message('Usuário não encontrado. IdUsuario: {0}');
        v_msg.addParam(p_idUsuario);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarUsuario;
  
    procedure buscarInformacoesProduto is
    begin
      select decode(p.fracionado, 'S', 1, 0)
        into v_isProdutoFracionado
        from produto p
       where p.idproduto = v_idproduto;
    end buscarInformacoesProduto;
  
    procedure buscarInformacoesEmbalagem is
    begin
      begin
        select e.idproduto, decode(e.ativo, 'S', 1, 0)
          into v_idProduto, v_isEmbalagemAtiva
          from embalagem e
         where e.barra = p_barra;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada embalagem correspondente para a barra ' ||
                             '{0} informada.');
          v_msg.addParam(p_barra);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end buscarInformacoesEmbalagem;
  
    procedure validarDadosPrdEmbalagem is
    begin
      if (v_isEmbalagemAtiva = 0) then
        v_msg := t_message('A embalagem encontrada para a barra ' ||
                           '{0} informada não está ativa.');
        v_msg.addParam(p_barra);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if ((v_isProdutoFracionado = 0) and (p_qtde <> round(p_qtde))) then
        v_msg := t_message('A configuração do produto não permite quantidade fracionada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarDadosPrdEmbalagem;
  
    procedure entrarQtde is
      v_jaExiste number;
    begin
      select count(1)
        into v_jaExiste
        from produtoexcedido pe
       where pe.idnotafiscal = p_idNotaFiscal
         and pe.idonda = p_idonda
         and pe.idproduto = v_idproduto
         and pe.barra = p_barra
         and pe.idlocal = p_idpacking
         and pe.idtarefa = nvl(p_codBarraTarefa, pe.idtarefa);
    
      if (v_jaExiste > 0) then
        update produtoexcedido pe
           set pe.qtde = pe.qtde + p_qtde
         where pe.idnotafiscal = p_idNotaFiscal
           and pe.idonda = p_idonda
           and pe.idproduto = v_idproduto
           and pe.barra = p_barra
           and pe.idlocal = p_idpacking
           and pe.idtarefa = nvl(p_codBarraTarefa, pe.idtarefa);
        return;
      end if;
    
      insert into produtoexcedido
        (id, idonda, idnotafiscal, idtarefa, idproduto, barra, qtde,
         idlocal, idusuario, datahora)
      values
        (seq_produtoexcedido.nextval, p_idonda, p_idnotafiscal,
         nvl(p_codBarraTarefa, 0), v_idproduto, p_barra, p_qtde, p_idpacking,
         p_idUsuario, sysdate);
    
    end entrarQtde;
  
  begin
    buscarInformacoesEmbalagem;
    buscarInformacoesProduto;
    validarDadosPrdEmbalagem;
    entrarQtde;
  end entrarQtdeExcedidaProduto;

  procedure definirPackingRetornoCorte
  (
    p_idPacking      in number,
    p_idRetornoCorte in number,
    p_idUsuario      in number
  ) is
    v_msg t_message;
  
    procedure validarUsuario is
      v_usuarioEncontrado number;
    begin
      select count(1)
        into v_usuarioEncontrado
        from usuario u
       where u.idusuario = p_idusuario
         and u.ativo = 'S';
    
      if (v_usuarioEncontrado = 0) then
        v_msg := t_message('Não foi informado usuário ativo para realizar a definição do local de packing ' ||
                           '{0} como local de retorno do corte físico {1}.');
        v_msg.addParam(p_idPacking);
        v_msg.addParam(p_idretornocorte);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarUsuario;
  
    procedure validarArmazem is
      v_idArmazemCorte   number;
      v_idArmazemPacking number;
    
    begin
      begin
        select rp.idarmazem
          into v_idArmazemCorte
          from retornocortepacking rc, romaneiopai rp
         where rc.id = p_idretornoCorte
           and rp.idromaneio = rc.idonda;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrado retorno de corte físico com id ' ||
                             '{0} informado.');
          v_msg.addParam(p_idretornocorte);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      begin
        select l.idarmazem
          into v_idArmazemPacking
          from packing p, local l
         where p.idendereco = p_idPacking
           and l.id = p.idendereco;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrado packing com id ' ||
                             '{0} informado.');
          v_msg.addParam(p_idpacking);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_idArmazemCorte <> v_idArmazemPacking) then
        v_msg := t_message('O armazém do corte físico informado diverge do armazém do packing informado.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarArmazem;
  
    procedure defPackingLocalRetornoCorte is
    begin
      update retornocortepacking rcp
         set rcp.idenderecopacking   = p_idPacking,
             rcp.idusuariodefpacking = p_idUsuario,
             rcp.datadefpacking      = sysdate
       where rcp.id = p_idRetornoCorte;
    end defPackingLocalRetornoCorte;
  
    procedure validarCortePendenteResolucao is
      v_qtdCortePendenteRes number;
    begin
      select count(1)
        into v_qtdCortePendenteRes
        from cortefisico c, cortefisiconf cnf, local lo,
             regiaoarmazenagem ro, retornocortepacking rcp
       where rcp.id = p_idretornocorte
         and c.status = 0
         and c.idonda = rcp.idonda
         and cnf.idcortefisico = c.id
         and cnf.qtdeseparacao <> cnf.qtdeutilizada
         and cnf.idnotafiscal = rcp.idnotafiscal
         and lo.id = c.idenderecofalta
         and ro.idregiao = lo.idregiao
         and ro.tipo = 6;
    
      if (v_qtdCortePendenteRes > 0) then
        v_msg := t_message('Corte Físico pendente de resolução');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarCortePendenteResolucao;
  begin
    validarUsuario;
    validarArmazem;
    validarCortePendenteResolucao;
    defPackingLocalRetornoCorte;
    null;
  end definirPackingRetornoCorte;

  function entrarCaixaSepCheckout
  (
    p_idPacking      in number,
    p_caixaSeparacao in caixaseparacao.barra%type,
    p_idUsuario      in number
  ) return number is
  
    v_idCaixaSeparacao number;
    v_msg              t_message;
    r_confcheckout     confcheckout%rowtype;
  
    procedure identificarCaixaSeparacao is
      r_caixaSeparacao caixaseparacao%rowtype;
      C_CAIXA_CHECKOUT constant number := 2;
    begin
      begin
        select *
          into r_caixaSeparacao
          from caixaseparacao c
         where barra = p_caixaSeparacao;
      exception
        when no_data_found then
          v_msg := t_message('Caixa informada não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (r_caixaSeparacao.Tipo <> C_CAIXA_CHECKOUT) then
        v_msg := t_message('Caixa informada não é do tipo Checkout.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_caixaSeparacao.Liberado = 1) then
        v_msg := t_message('Conferencia concluida, caixa informada está liberada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_idCaixaSeparacao := r_caixaSeparacao.Idcaixaseparacao;
    end;
  
    procedure validarConteudoCaixa is
      v_qtdeRestante number;
      v_idPacking    number;
    begin
      select count(idmovimentacao)
        into v_qtdeRestante
        from conteudocarrinho ca
       where ca.idcaixaseparacao = v_idCaixaSeparacao;
    
      if (v_qtdeRestante = 0) then
        v_msg := t_message('Caixa informada já foi totalmente separada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select m.idlocaldestino, m.idonda
        into v_idPacking, r_confcheckout.idonda
        from conteudocarrinho ca, movimentacao m
       where ca.idcaixaseparacao = v_idCaixaSeparacao
         and m.id = ca.idmovimentacao
         and rownum = 1;
    
      if (v_idPacking <> p_idPacking) then
        v_msg := t_message('Caixa informada não pertence a esse packing.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure validarConferenciaCaixa is
      v_permitemultusuario number := 0;
    begin
    
      begin
        select cf.permitirconferirmultiusuario
          into v_permitemultusuario
          from romaneiopai r, configuracaoonda cf
         where r.idromaneio = r_confcheckout.idonda
           and r.idconfiguracaoonda = cf.idconfiguracaoonda;
      exception
        when no_data_found then
          v_permitemultusuario := 0;
      end;
    
      begin
        select *
          into r_confcheckout
          from confcheckout
         where idpacking = p_idPacking
           and status = 0
           and idcaixaseparacao = v_idCaixaSeparacao
           and ((v_permitemultusuario = MULTI_USUARIO_CONF_CHECKOUT) or
               (v_permitemultusuario < MULTI_USUARIO_CONF_CHECKOUT and
               idusuario = p_idUsuario))
           and rownum = 1;
      exception
        when no_data_found then
          select seq_confcheckout.nextval
            into r_confcheckout.id
            from dual;
        
          r_confcheckout.idpacking        := p_idPacking;
          r_confcheckout.idcaixaseparacao := v_idCaixaSeparacao;
          r_confcheckout.status           := 0;
          r_confcheckout.idusuario        := p_idUsuario;
        
          insert into confcheckout
          values r_confcheckout;
      end;
    
      delete from confcheckout c
       where c.idpacking = p_idPacking
         and c.status = 0
         and c.idcaixaseparacao = v_idCaixaSeparacao
         and c.id <> r_confcheckout.id;
    
      if (r_confcheckout.idusuario <> p_idUsuario and
         v_permitemultusuario <> MULTI_USUARIO_CONF_CHECKOUT) then
        v_msg := t_message('Caixa informada está em conferencia por outro usuário.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end;
  
    procedure gravarHistoricoCaixaSeparacao is
      CONFERENCIA_CAIXA    number := 3;
      CONFERENCIA_CONTEUDO number := 2;
      v_idhistoricocaixa   number;
      v_historicoGravado   number;
    begin
      select count(1)
        into v_historicoGravado
        from historicoconteudocaixa h, movimentacao m
       where m.id = h.idmovimentacao
         and m.idonda = r_confcheckout.idonda
         and h.idcaixaseparacao = v_idCaixaSeparacao
         and h.tipohistorico = 2;
    
      if (v_historicoGravado <> 0) then
        return;
      end if;
    
      select seq_historicocaixaseparacao.nextval
        into v_idhistoricocaixa
        from dual;
    
      insert into historicocaixaseparacao
        (idhistoricocaixaseparacao, idcaixaseparacao, idusuariopacking,
         tipohistorico, dtconferencia, datahistorico)
        select v_idhistoricocaixa, cx.idcaixaseparacao, ct.conferente,
               CONFERENCIA_CAIXA tipohistorico, sysdate dtConferencia,
               sysdate dtHistorico
          from caixaseparacao cx,
               (select cc.idcaixaseparacao, p_idUsuario conferente
                   from conteudocarrinho cc, movimentacao m, romaneiopai rp,
                        local lo, regiaoarmazenagem ro, local ld,
                        regiaoarmazenagem rd
                  where m.id = cc.idmovimentacao
                    and rp.idromaneio = m.idonda
                    and rd.idregiao = ld.idregiao
                    and ld.id = m.idlocaldestino
                    and ld.tipo = 8
                    and ro.idregiao = lo.idregiao
                    and lo.id = m.idlocalorigem
                  group by cc.idcaixaseparacao, p_idUsuario) ct
         where ct.idcaixaseparacao(+) = cx.idcaixaseparacao
           and cx.idcaixaseparacao = v_idCaixaSeparacao;
    
      insert into historicoconteudocaixa
        (idhistoricoconteudocaixa, idhistoricocaixaseparacao,
         idcaixaseparacao, idmovimentacao, qtdeun, tipohistorico,
         datahistorico)
        select seq_historicoconteudocaixa.nextval, v_idhistoricocaixa,
               cc.idcaixaseparacao, m.id, m.quantidade, CONFERENCIA_CONTEUDO,
               sysdate
          from conteudocarrinho cc, movimentacao m,
               historicocaixaseparacao h
         where m.id = cc.idmovimentacao
           and h.idcaixaseparacao = cc.idcaixaseparacao
           and cc.idcaixaseparacao = v_idCaixaSeparacao
           and h.idhistoricocaixaseparacao = v_idhistoricocaixa;
    end;
  begin
    identificarCaixaSeparacao;
    validarConteudoCaixa;
    validarConferenciaCaixa;
    gravarHistoricoCaixaSeparacao;
  
    return r_confcheckout.id;
  end;

  procedure entrarProdutoSepCheckout
  (
    p_idConfCheckout in number,
    p_barra          in varchar2,
    p_idUsuario      in number,
    p_solicitaEmb    in number := 0
  ) is
    v_idconfpacking number;
    v_idarmazem     number;
    v_idPacking     number;
    v_idCaixa       number;
    v_identificador varchar(2000);
    v_msg           t_message;
  
    v_barra128 pk_utilities.t_barraGs1;
    v_barra    embalagem.barra%type;
  
    r_embalagemConf embalagem%rowtype;
  
    v_depositante    number;
    v_isBarraCode128 number;
  
    v_codigoProdutoCode128 number;
    v_barraProdutoCode128  varchar2(32);
    v_barraCaixaCode128    varchar2(32);
    v_QuantidadeCode128    number;
    v_LoteIndustriaCode128 varchar2(60);
    v_LoteAdicionalCode128 varchar2(60);
    v_VencimentoCode128    date;
    v_FabricacaoCode128    date;
    v_PesoCode128          number;
    v_PesoLiquidoCode128   number;
    v_idOnda               romaneiopai.idromaneio%type;
  
    procedure identificarProduto is
    
      procedure carregarDepositante is
      begin
        begin
          select distinct dep.identidade
            into v_depositante
            from confcheckout ch, romaneiopai rp, nfromaneio nfr,
                 notafiscal nf, depositante dep
           where ch.id = p_idConfCheckout
             and ch.idonda = rp.idromaneio
             and nfr.idromaneio = rp.idromaneio
             and nfr.idnotafiscal = nf.idnotafiscal
             and nf.iddepositante = dep.identidade
             and rownum = 1;
        exception
          when no_data_found then
            v_depositante := null;
        end;
      end carregarDepositante;
    
    begin
    
      v_barra := p_barra;
    
      carregarDepositante;
    
      v_isBarraCode128 := pk_utilities.extrairCODE128(p_barra, v_depositante,
                                                      null,
                                                      v_codigoProdutoCode128,
                                                      v_barraProdutoCode128,
                                                      v_barraCaixaCode128,
                                                      v_QuantidadeCode128,
                                                      v_LoteIndustriaCode128,
                                                      v_LoteAdicionalCode128,
                                                      v_VencimentoCode128,
                                                      v_FabricacaoCode128,
                                                      v_PesoCode128,
                                                      v_PesoLiquidoCode128);
    
      if v_isBarraCode128 = 0 then
        v_barra128 := pk_utilities.extrairBarraGS1128(p_barra);
      end if;
    
      if v_isBarraCode128 = 1 then
        if v_barraProdutoCode128 is not null then
          v_barra := v_barraProdutoCode128;
        else
          v_barra := v_barraCaixaCode128;
        end if;
      else
        if (v_barra128.barraEmbalagem is not null) then
          v_barra := v_barra128.barraEmbalagem;
        end if;
      end if;
    
      begin
        select e.*
          into r_embalagemConf
          from embalagem e
         where e.barra = v_barra;
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada nenhuma embalagem para a barra informada.' ||
                             chr(13) || ' Barra: {0}');
          v_msg.addParam(p_barra);
          raise_application_error(-20103, v_msg.formatMessage);
      end;
    end;
  
    procedure identificarConferencia is
    begin
      begin
        select l.idarmazem, c.idpacking, c.idcaixaseparacao
          into v_idarmazem, v_idPacking, v_idCaixa
          from confcheckout c, local l
         where c.id = p_idConfCheckout
           and l.id = c.idpacking
           and status = 0;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao conferir produto, conferencia checkout não encontrada');
          raise_application_error(-20103, v_msg.formatMessage);
      end;
    end;
  
    procedure identificarProxNotafiscal is
      v_idMovimentacaoCaixa      number;
      v_idMovimentacaoPrioridade number;
      v_idDepositante            number;
      v_idNotafiscalCaixa        number;
      v_idNotafiscalPrioridade   number;
      v_idSaidanfCaixa           number;
      v_idSaidanfPrioridade      number;
      v_idonda                   number;
      v_multiUsuario             number;
    
      procedure trocarMovimentacoes is
      begin
        select idNotafiscal
          into v_idNotafiscalPrioridade
          from movimentacao
         where id = v_idMovimentacaoPrioridade;
      
        select c.idonda
          into v_idonda
          from confcheckout c
         where c.id = p_idConfCheckout;
      
        -- troca movimentacao
        update movimentacao
           set idnotafiscal = v_idNotafiscalPrioridade
         where id = v_idMovimentacaoCaixa
           and idonda = v_idonda;
      
        if sql%rowcount = 0 then
          raise_application_error(-20000,
                                  'Não foi possível alterar a prioridade das movimentações para esta conferência.');
        end if;
      
        update movimentacao
           set idnotafiscal = v_idNotafiscalCaixa
         where id = v_idMovimentacaoPrioridade
           and idonda = v_idonda;
      
        if sql%rowcount = 0 then
          raise_application_error(-20000,
                                  'Não foi possível alterar a prioridade das movimentações para esta conferência.');
        end if;
      end;
    
      procedure trocarSaidaNf is
        v_idSaidanfCaixa      number;
        v_idSaidanfPrioridade number;
      begin
        select s.idsaidapornf
          into v_idSaidanfCaixa
          from saidapornf s
         where s.idnotafiscal = v_idNotafiscalCaixa;
      
        select s.idsaidapornf
          into v_idSaidanfPrioridade
          from saidapornf s
         where s.idnotafiscal = v_idNotafiscalPrioridade;
      
        /* troca as notas fiscais
        unificado update de troca de nota fiscal devido a criação da unique
        constraint UK_SAIDAPORNF_IDNOTAFISCAL
        */
        update saidapornf s
           set s.idnotafiscal = (case
                                  when s.idsaidapornf = v_idSaidanfCaixa then
                                   v_idNotafiscalPrioridade
                                  else
                                   v_idNotafiscalCaixa
                                end)
         where s.idsaidapornf in (v_idSaidanfCaixa, v_idSaidanfPrioridade);
      
        if (sql%rowcount <> 2) then
          v_msg := t_message('Não foi possível alterar a prioridade da Nota Fiscal id:' ||
                             '{0} com a Nota Fiscal id: {1}' ||
                             ' na conferência do Checkout Express.' ||
                             chr(13) || 'Operação Cancelada.');
          v_msg.addParam(v_idNotafiscalPrioridade);
          v_msg.addParam(v_idNotafiscalCaixa);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end;
    begin
    
      begin
        select idmovimentacao, iddepositante, idnotafiscal,
               permitirconferirmultiusuario
          into v_idMovimentacaoCaixa, v_idDepositante, v_idNotafiscalCaixa,
               v_multiUsuario
          from (select idmovimentacao, l.iddepositante, m.idnotafiscal,
                        co.permitirconferirmultiusuario
                   from conteudocarrinho cx, movimentacao m, confcheckout cc,
                        lote l, romaneiopai rp, configuracaoonda co
                  where cc.id = p_idConfCheckout
                    and l.idproduto = r_embalagemConf.idproduto
                    and cc.status = 0
                    and cc.idcaixaseparacao = cx.idcaixaseparacao
                    and cx.idmovimentacao = m.id
                    and l.idlote = m.idlote
                    and m.idonda = cc.idonda
                    and rp.idromaneio = m.idonda
                    and co.idconfiguracaoonda = rp.idconfiguracaoonda
                  order by m.idnotafiscal)
         where rownum = 1;
      exception
        when no_data_found then
          v_msg := t_message('O produto informado não foi encontrado na caixa sendo conferida.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      v_idMovimentacaoPrioridade := pk_prioridadeCheckoutExpress.getMovimentacaoPrioritaria(v_idCaixa,
                                                                                            r_embalagemConf.idproduto,
                                                                                            v_idDepositante);
    
      v_identificador := v_idNotafiscalCaixa;
    
      if ((v_idMovimentacaoPrioridade <> v_idMovimentacaoCaixa) and
         (v_multiUsuario = 0)) then
        trocarMovimentacoes;
        trocarSaidaNf;
      
        v_identificador := v_idNotafiscalPrioridade;
      end if;
    
      select nr.idromaneio
        into v_idonda
        from nfromaneio nr
       where nr.idnotafiscal = v_identificador;
    
    end;
  
    procedure executarPacking is
      C_GERAR_VOLUME_CAIXA_FECHADA constant number := 22;
      C_GERAR_VOLUME_CHECKOUT      constant number := 23;
    
      v_possuicontagens       number;
      v_resultado_conferencia number;
    begin
      entrarIdentificadorPacking(v_idArmazem, v_identificador, v_idPacking,
                                 p_idusuario, 1);
    
      if (pk_tipopedido.pontoAlertaLiberado(0, v_identificador, v_idonda,
                                            v_idPacking) > 0) then
        return;
      end if;
    
      select idconfpacking
        into v_idconfpacking
        from gtt_identificacaopacking;
    
      select count(idproduto)
        into v_possuicontagens
        from produtoconfpacking
       where idconfpacking = v_idconfpacking;
    
      if (v_possuicontagens > 0) then
        if (definirCaixaVolAutoCheckout(v_idconfpacking)) then
          v_resultado_conferencia := C_GERAR_VOLUME_CAIXA_FECHADA;
        else
          v_resultado_conferencia := C_GERAR_VOLUME_CHECKOUT;
        end if;
      
        insert into gtt_produtoconferencia
          select g.iddepositante, p.idproduto, pp.codigointerno, pp.descr,
                 e.descrreduzido, 0, 1, 1, 0, 1, 1, 0, pp.pesavel, 0, 0, 1,
                 0, v_resultado_conferencia, 0, 0, 'Selecionar caixa volume',
                 0, '', 0, 1, g.idconfpacking, d.razaosocial, null, p_barra,
                 0
            from gtt_identificacaopacking g, produtoconfpacking p,
                 produto pp, embalagem e, entidade d
           where g.idconfpacking = p.idconfpacking
             and pp.idproduto = p.idproduto
             and e.idproduto = pp.idproduto
             and e.barra = p.barra
             and d.identidade = g.iddepositante
             and p.idconfpacking = v_idconfpacking;
      
        return;
      end if;
    
      entrarBarraOuLoteConferencia(v_idconfpacking, p_barra, 1, p_idusuario,
                                   1, p_solicitaEmb);
    end executarPacking;
  
  begin
    identificarConferencia;
    identificarProduto;
    identificarProxNotafiscal;
    executarPacking;
  end;

  procedure liberarCaixaSeparacao(p_idCaixaSeparacao in number) is
    v_qtdeconteudocarrinho number;
    CAIXA_LIBERADA constant number := 1;
  begin
    select count(1)
      into v_qtdeconteudocarrinho
      from conteudocarrinho cc
     where cc.idcaixaseparacao = p_idCaixaSeparacao;
  
    if v_qtdeconteudocarrinho <> 0 then
      return;
    end if;
  
    update caixaseparacao c
       set c.liberado     = CAIXA_LIBERADA,
           c.codigotarefa = null
     where c.idcaixaseparacao = p_idCaixaSeparacao;
  
    update confcheckout c
       set status = 1
     where c.idcaixaseparacao = p_idCaixaSeparacao;
  end;

  function gerarVolumeCheckout
  (
    p_idConfCheckout in number,
    p_idConfPacking  in number,
    p_idTipoCaixa    in number,
    p_idusuario      in number
  ) return number is
    v_idVolumeRomaneio number;
    v_idCaixaSeparacao number;
  
    procedure calcularRankUnitario is
    begin
      begin
        insert into rankcheckout r
        values
          (seq_rankcheckout.nextval, p_idusuario, trunc(sysdate), 1, 0);
      exception
        when DUP_VAL_ON_INDEX then
          update rankcheckout r
             set r.qtde = r.qtde + 1
           where r.idusuario = p_idusuario
             and data = trunc(sysdate)
             and r.tipo = 0;
      end;
    end;
  
    procedure calcularRankCaixas is
      v_qtdeRestante number;
    begin
      select count(*)
        into v_qtdeRestante
        from conteudocarrinho c, confcheckout co
       where co.idcaixaseparacao = c.idcaixaseparacao
         and co.id = p_idConfCheckout
         and co.status = 0;
    
      if (v_qtdeRestante <> 0) then
        return;
      end if;
    
      begin
        insert into rankcheckout r
        values
          (seq_rankcheckout.nextval, p_idusuario, trunc(sysdate), 1, 1);
      exception
        when DUP_VAL_ON_INDEX then
          update rankcheckout r
             set r.qtde = r.qtde + 1
           where r.idusuario = p_idusuario
             and data = trunc(sysdate)
             and r.tipo = 1;
      end;
    end;
  
    procedure removerMovimentacaoDaCaixa is
      v_idconteudoCarrinho number;
    begin
      select cx.id, cc.idcaixaseparacao
        into v_idconteudoCarrinho, v_idCaixaSeparacao
        from conteudovolume co, volumeromaneio v, conteudocarrinho cx,
             movimentacao m, confcheckout cc
       where v.idvolumeromaneio = v_idVolumeRomaneio
         and cc.id = p_idConfCheckout
         and cc.idcaixaseparacao = cx.idcaixaseparacao
         and v.idvolumeromaneio = co.idvolumeromaneio
         and cx.idmovimentacao = m.id
         and m.idnotafiscal = v.idnotafiscal;
    
      delete from conteudocarrinho
       where id = v_idconteudoCarrinho;
    end;
  
    procedure finalizaConferencia is
      v_qtdeRestante number;
    begin
      select count(*)
        into v_qtdeRestante
        from conteudocarrinho c, confcheckout co
       where co.idcaixaseparacao = c.idcaixaseparacao
         and co.id = p_idConfCheckout
         and co.status = 0;
    
      if (v_qtdeRestante <> 0) then
        return;
      end if;
    
      update confcheckout
         set status = 1
       where id = p_idConfCheckout;
    end;
  
    procedure validaCaixaSemConteudo is
    
      v_tarefa     varchar2(10);
      v_codinterno romaneiopai.codigointerno%type;
    
    begin
    
      begin
        select rp.codigointerno, lpad(idromaneio, 10, '0')
          into v_codinterno, v_tarefa
          from romaneiopai rp, confcheckout co
         where co.id = p_idConfCheckout
           and rp.idromaneio = co.idonda;
      end;
    
      for r_caixa in (select cp.idcaixaseparacao
                        from caixaseparacao cp
                       where cp.tipo = p_idTipoCaixa
                         and (cp.codigotarefa = v_codinterno or
                             substr(cp.codigotarefa, 1, 10) = v_tarefa)
                         and cp.liberado = 0
                         and not exists
                       (select 1
                                from conteudocarrinho cc
                               where cc.idcaixaseparacao =
                                     cp.idcaixaseparacao))
      loop
        liberarCaixaSeparacao(r_caixa.idcaixaseparacao);
      end loop;
    
    end;
  
    procedure geradoTodosVolDaOnda is
      v_qtdeRestante number;
    begin
    
      select nvl(sum(qtdemovimentada), 0)
        into v_qtdeRestante
        from movimentacao m, confcheckout co, local l
       where co.id = p_idConfCheckout
         and m.idonda = co.idonda
         and m.qtdemovimentada - m.qtdeemvolume > 0
         and m.idvolumeromaneio is null
         and l.id = m.idlocalorigem
         and l.idregiao not in
             (select nvl(cf.idregiaoretornoestoque, 0)
                from configuracaoonda cf, romaneiopai rp
               where rp.idromaneio = m.idonda
                 and rp.idconfiguracaoonda = cf.idconfiguracaoonda);
    
      if v_qtdeRestante = 0 then
        validaCaixaSemConteudo;
      end if;
    end geradoTodosVolDaOnda;
  
  begin
    v_idVolumeRomaneio := gerarVolume(p_idConfPacking, p_idTipoCaixa,
                                      p_idusuario);
  
    removerMovimentacaoDaCaixa;
    calcularRankUnitario;
    calcularRankCaixas;
    finalizaConferencia;
    liberarCaixaSeparacao(v_idCaixaSeparacao);
    geradoTodosVolDaOnda;
  
    return v_idVolumeRomaneio;
  end;

  procedure gravarHistCaixaSeparacaoCancel
  (
    p_idNotaFiscal  in number,
    p_idOnda        in number,
    p_tipohistorico in historicocaixaseparacao.tipohistorico%type
  ) is
  
    NAO_EXISTE_HISTORICO constant number := 0;
  
    C_ORIGEM_CANCELAR_ONDA number;
    C_ORIGEM_RETIRAR_NOTA  number;
    v_idhistoricocaixa     number;
    v_exitemovimentacao    number;
    v_idusuariopacking     number;
    v_dtconferencia        historicocaixaseparacao.dtconferencia%type;
  begin
    if p_tipohistorico = 1 then
      C_ORIGEM_CANCELAR_ONDA := 1;
    else
      C_ORIGEM_RETIRAR_NOTA := 2;
    end if;
  
    for c_caixa in (select v.idcaixaseparacao,
                           nvl(C_ORIGEM_CANCELAR_ONDA, C_ORIGEM_RETIRAR_NOTA) tipohistorico,
                           (select count(1) qtd
                               from caixaseparacao cx, movimentacao m,
                                    (select cc.id idconteudo,
                                             cc.idcaixaseparacao,
                                             cc.idmovimentacao
                                        from conteudocarrinho cc
                                      union all
                                      select null idconteudo, hc.idcaixaseparacao,
                                             m.id idmovimentacao
                                        from historicocaixaseparacao hc,
                                             historicoconteudocaixa hcc,
                                             movimentacao m
                                       where hcc.idhistoricocaixaseparacao =
                                             hc.idhistoricocaixaseparacao
                                         and m.id = hcc.idmovimentacao
                                         and hc.tipohistorico = 3
                                         and not exists (select 1
                                                from conteudocarrinho cc
                                               where cc.idmovimentacao = m.id)
                                         and not exists
                                       (select 1
                                                from historicoconteudocaixa hcc
                                               where hcc.tipohistorico = 1
                                                 and hcc.idmovimentacao = m.id)) ct
                              where ct.idcaixaseparacao = cx.idcaixaseparacao
                                and m.id = ct.idmovimentacao
                                and m.idOnda = p_idOnda
                                and m.idnotafiscal =
                                    decode(C_ORIGEM_RETIRAR_NOTA, 2,
                                           p_idNotaFiscal, m.idnotafiscal)
                                and cx.idcaixaseparacao = v.idcaixaseparacao) qtdehistconteudocaixa
                      from (select cc.idcaixaseparacao, m.idonda
                               from movimentacao m, conteudocarrinho cc
                              where cc.idmovimentacao = m.id
                              group by cc.idcaixaseparacao, m.idonda
                             union all
                             select hc.idcaixaseparacao, m.idonda
                               from historicocaixaseparacao hc,
                                    historicoconteudocaixa hcc, movimentacao m
                              where hc.idhistoricocaixaseparacao =
                                    hcc.idhistoricocaixaseparacao
                                and m.id = hcc.idmovimentacao
                                and hc.tipohistorico = 3
                                and not exists
                              (select 1
                                       from conteudocarrinho cc
                                      where cc.idcaixaseparacao =
                                            hc.idcaixaseparacao
                                        and cc.idmovimentacao = m.id)
                              group by hc.idcaixaseparacao, m.idonda) v
                     where v.idonda = p_idOnda
                     group by v.idcaixaseparacao)
    loop
    
      select count(1)
        into v_exitemovimentacao
        from historicocaixaseparacao hc, historicoconteudocaixa hcc,
             movimentacao m
       where hc.idhistoricocaixaseparacao = hcc.idhistoricocaixaseparacao
         and hcc.idmovimentacao = m.id
         and m.idonda = p_idOnda
         and hc.idcaixaseparacao = c_caixa.idcaixaseparacao
         and hc.tipohistorico =
             nvl(C_ORIGEM_CANCELAR_ONDA, C_ORIGEM_RETIRAR_NOTA);
    
      if v_exitemovimentacao = NAO_EXISTE_HISTORICO then
        select seq_historicocaixaseparacao.nextval
          into v_idhistoricocaixa
          from dual;
      
        begin
          select hc.idusuariopacking, hc.dtconferencia
            into v_idusuariopacking, v_dtconferencia
            from historicocaixaseparacao hc, historicoconteudocaixa hcc,
                 movimentacao m, confcheckout ch
           where hc.idcaixaseparacao = c_caixa.idcaixaseparacao
             and hcc.idhistoricocaixaseparacao =
                 hc.idhistoricocaixaseparacao
             and m.id = hcc.idmovimentacao
             and ch.idonda = m.idonda
             and ch.idcaixaseparacao = hc.idcaixaseparacao
             and ch.idonda = p_idOnda
           group by hc.idusuariopacking, hc.dtconferencia;
        exception
          when no_data_found then
            v_idusuariopacking := null;
            v_dtconferencia    := null;
        end;
      
        if (c_caixa.qtdehistconteudocaixa <> 0) then
          insert into historicocaixaseparacao
            (idhistoricocaixaseparacao, idcaixaseparacao, idusuariopacking,
             tipohistorico, dtconferencia, datahistorico)
          values
            (v_idhistoricocaixa, c_caixa.idcaixaseparacao,
             v_idusuariopacking, c_caixa.tipohistorico, v_dtconferencia,
             sysdate);
        end if;
      
      else
        select min(hc.idhistoricocaixaseparacao)
          into v_idhistoricocaixa
          from historicocaixaseparacao hc, historicoconteudocaixa hcc,
               movimentacao m
         where hc.idhistoricocaixaseparacao = hcc.idhistoricocaixaseparacao
           and hcc.idmovimentacao = m.id
           and m.idonda = p_idOnda
           and hc.idcaixaseparacao = c_caixa.idcaixaseparacao
           and hc.tipohistorico =
               nvl(C_ORIGEM_CANCELAR_ONDA, C_ORIGEM_RETIRAR_NOTA);
      end if;
    
      for c_produtocaixa in (select ct.idconteudo, cx.idcaixaseparacao,
                                    m.id idmovimentacao, m.quantidade,
                                    decode(nvl(C_ORIGEM_CANCELAR_ONDA,
                                                C_ORIGEM_RETIRAR_NOTA), 1, 0, 1) tipohistorico
                               from caixaseparacao cx, movimentacao m,
                                    (select cc.id idconteudo,
                                             cc.idcaixaseparacao,
                                             cc.idmovimentacao
                                        from conteudocarrinho cc
                                      union all
                                      select null idconteudo,
                                             hc.idcaixaseparacao,
                                             m.id idmovimentacao
                                        from historicocaixaseparacao hc,
                                             historicoconteudocaixa hcc,
                                             movimentacao m
                                       where hcc.idhistoricocaixaseparacao =
                                             hc.idhistoricocaixaseparacao
                                         and m.id = hcc.idmovimentacao
                                         and hc.tipohistorico = 3
                                         and not exists (select 1
                                                from conteudocarrinho cc
                                               where cc.idmovimentacao = m.id)
                                         and not exists
                                       (select 1
                                                from historicoconteudocaixa hcc
                                               where hcc.tipohistorico = 1
                                                 and hcc.idmovimentacao = m.id)) ct
                              where ct.idcaixaseparacao =
                                    cx.idcaixaseparacao
                                and m.id = ct.idmovimentacao
                                and m.idOnda = p_idOnda
                                and m.idnotafiscal =
                                    decode(C_ORIGEM_RETIRAR_NOTA, 2,
                                           p_idNotaFiscal, m.idnotafiscal)
                                and cx.idcaixaseparacao =
                                    c_caixa.idcaixaseparacao)
      loop
        insert into historicoconteudocaixa
          (idhistoricoconteudocaixa, idhistoricocaixaseparacao,
           idcaixaseparacao, idmovimentacao, qtdeun, tipohistorico,
           datahistorico)
        values
          (seq_historicoconteudocaixa.nextval, v_idhistoricocaixa,
           c_produtocaixa.idcaixaseparacao, c_produtocaixa.idmovimentacao,
           c_produtocaixa.quantidade, c_produtocaixa.tipohistorico, sysdate);
      
        if (c_produtocaixa.tipohistorico <> 2) then
          delete from conteudocarrinho cc
           where cc.id = c_produtocaixa.idconteudo
             and cc.idmovimentacao = c_produtocaixa.idmovimentacao;
        end if;
      
        liberarCaixaSeparacao(c_produtocaixa.idcaixaseparacao);
      
      end loop;
    end loop;
  end;

  procedure definirQuantidadeVolumes
  (
    p_idConfPacking in number,
    p_qtdeVolumes   in number,
    p_idUsuario     in number
  ) is
    v_idnotafiscal             number;
    v_qtdeVolumesGerados       number;
    v_msg                      t_message;
    v_idOnda                   number;
    v_isGerarVolumeSemConteudo number;
  begin
    select cp.idnotafiscal, cp.idonda
      into v_idnotafiscal, v_idOnda
      from confpacking cp
     where cp.id = p_idConfPacking;
  
    if (p_qtdeVolumes <= 0) then
      v_msg := t_message('Quantidade invalida!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(idvolumeromaneio)
      into v_qtdeVolumesGerados
      from volumeromaneio
     where idnotafiscal = v_idnotafiscal;
  
    if (v_qtdeVolumesGerados > 0) then
      v_msg := t_message('A quantidade de volumes nao pode ser modificada porque já existem volumes gerados.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select co.gerarvolumesemconteudo
      into v_isGerarVolumeSemConteudo
      from configuracaoonda co, romaneiopai rp
     where rp.idromaneio = v_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (v_isGerarVolumeSemConteudo > 0) then
      update notafiscal nf
         set nf.quantidade = p_qtdeVolumes
       where nf.idnotafiscal = v_idnotafiscal;
    else
      update nfromaneio n
         set n.novaqtdevolumes       = p_qtdeVolumes,
             n.usuarioaltqtdevolumes = p_idUsuario,
             n.dataaltqtdevolumes    = sysdate
       where idnotafiscal = v_idnotafiscal;
    end if;
  end;

  function getEstadoContagemPacking
  (
    p_tipoRetorno  number,
    p_pesavel      number,
    p_qtdeContada  number,
    p_qtdeEmVolume number,
    p_qtdemin      number,
    p_qtdemax      number,
    p_qtdetotal    number
  ) return number is
  begin
    /*estado contagem do packing*/
    if (p_tipoRetorno = 0) then
      if (p_pesavel = 1 and (p_qtdeContada + p_qtdeEmVolume) >= p_qtdemin and
         (p_qtdeContada + p_qtdeEmVolume) <= p_qtdemax and
         p_qtdeContada >= 0) then
        return 1;
      elsif (p_pesavel = 0 and
            (p_qtdeContada + p_qtdeEmVolume) = p_qtdetotal) then
        return 1;
      elsif (p_qtdeContada + p_qtdeEmVolume) > p_qtdemax then
        return 2;
      else
        return 0;
      end if;
    end if;
  
    /*status*/
    if (p_tipoRetorno = 1) then
      if (p_pesavel = 1 and (p_qtdeContada + p_qtdeEmVolume) >= p_qtdemin and
         (p_qtdeContada + p_qtdeEmVolume) <= p_qtdemax and
         p_qtdeContada >= 0) then
        return 1;
      elsif (p_pesavel = 0 and
            (p_qtdeContada + p_qtdeEmVolume) = p_qtdetotal) then
        return 1;
      else
        return 0;
      end if;
    end if;
  end getEstadoContagemPacking;

  procedure definirUsuarioConfPacking
  (
    p_idUsuario      number,
    p_idPacking      number,
    p_idOnda         number,
    p_idNotaFiscal   number,
    p_codBarraTarefa confpacking.codbarratarefa%type
  ) is
    v_tipoconferencia  number;
    v_confPorUmUsuario number;
    v_checkoutExpress  number;
    v_msg              t_message;
    r_confpacking      confpacking%rowtype;
  
    C_TIPO_POR_NF     constant number := 0;
    C_TIPO_POR_TAREFA constant number := 1;
  
    C_SIM constant number := 1;
  
    procedure definirConferente is
    
    begin
    
      -- Busca as movimentações e define o usuário selecionado como conferente  
    
      if v_tipoconferencia = C_TIPO_POR_TAREFA then
      
        for c_regTarefa in (select a.idenderecopacking, a.idnotafiscal,
                                   a.tarefa
                              from (select ld.id idenderecopacking,
                                            m.idnotafiscal,
                                            m.codbarratarefa tarefa,
                                            sum(m.quantidade) quantidade,
                                            sum(decode(m.status, 2,
                                                        m.quantidade, 4,
                                                        m.quantidade, 0)) qtdeseparada,
                                            sum(m.qtdeemvolume) qtdeemvolume,
                                            rp.processado
                                       from romaneiopai rp, v_tarefas_onda m,
                                            local ld, notafiscal nf, lote lt,
                                            configuracaoonda co
                                      where rp.tipo = 1
                                        and m.idonda = p_idOnda
                                        and m.etapa = 1 -- Etapa da movimentação do lote 
                                        and m.status <> 3 -- Cancelada
                                        and ld.id = m.idlocaldestino
                                        and ld.tipo = 8 -- Packing
                                        and nf.idnotafiscal = m.idnotafiscal
                                        and lt.idlote = m.idlote
                                        and co.idconfiguracaoonda =
                                            rp.idconfiguracaoonda
                                        and co.tipoconferenciapacking = 1
                                      group by ld.id, m.idnotafiscal, m.idonda,
                                               m.codbarratarefa, rp.processado) a
                             where a.processado = 'N'
                               and trunc((a.qtdeemvolume * 100) /
                                         a.quantidade) <> 100)
        loop
        
          insert into confpacking
            (id, idpacking, idnotafiscal, idusuario, idonda, status,
             codBarraTarefa)
          values
            (SEQ_CONFPACKING.NEXTVAL, c_regTarefa.idenderecopacking,
             c_regTarefa.idnotafiscal, p_idUsuario, p_idOnda,
             C_STATUS_EM_CONTAGEM, c_regTarefa.tarefa);
        
        end loop;
      
      elsif v_tipoconferencia = C_TIPO_POR_NF then
      
        for c_regNf in (select b.idenderecopacking, b.idnotafiscal, b.idonda,
                               b.idarmazem, b.processado, b.idromaneio
                          from (select a.idenderecopacking, a.idnotafiscal,
                                        a.idonda, a.idarmazem, a.processado,
                                        nvl((select sum(nvl(pc.qtde *
                                                             e.fatorconversao, 0)) qtdecontada
                                               from confpacking cp,
                                                    produtoconfpacking pc,
                                                    embalagem e,
                                                    volumeromaneio v
                                              where cp.idpacking =
                                                    a.idenderecopacking
                                                and cp.idnotafiscal =
                                                    a.idnotafiscal
                                                and cp.idonda = a.idonda
                                                and cp.status in
                                                    (C_STATUS_EM_CONTAGEM,
                                                     C_STATUS_VOLUME_MONTADO)
                                                and pc.idconfpacking = cp.id
                                                and pc.status = 1
                                                and e.idproduto = pc.idproduto
                                                and e.barra = pc.barra
                                                and v.idvolumeromaneio =
                                                    cp.idvolumeromaneio
                                                and v.statusvolume = 0), 0) qtdeconpacking,
                                        a.quantidade qtdetotal, a.idromaneio
                                   from (select ld.id idenderecopacking,
                                                 m.idnotafiscal, m.idonda,
                                                 ld.idarmazem, rp.processado,
                                                 sum(m.quantidade) quantidade,
                                                 rp.idromaneio
                                            from romaneiopai rp, movimentacao m,
                                                 local ld, notafiscal nf, lote lt,
                                                 configuracaoonda co
                                           where rp.tipo = 1
                                             and m.idonda = rp.idromaneio
                                             and m.etapa = 1
                                             and m.status <>
                                                 STATUS_MOV_CANCELADO
                                             and ld.id = m.idlocaldestino
                                             and ld.tipo = 8
                                             and nf.idnotafiscal =
                                                 m.idnotafiscal
                                             and lt.idlote = m.idlote
                                             and co.idconfiguracaoonda =
                                                 rp.idconfiguracaoonda
                                           group by ld.id, m.idnotafiscal,
                                                    m.idonda, ld.idarmazem,
                                                    rp.processado, rp.idromaneio) a) b
                         where b.processado = 'N'
                           and trunc((b.qtdeconpacking * 100) / b.qtdetotal) <> 100
                           and b.idromaneio = p_idOnda)
        loop
        
          insert into confpacking
            (id, idpacking, idnotafiscal, idusuario, idonda, status,
             codBarraTarefa)
          values
            (seq_confpacking.nextval, c_regNf.idenderecopacking,
             c_regNf.idnotafiscal, p_idUsuario, p_idOnda,
             C_STATUS_EM_CONTAGEM, null);
        
        end loop;
      
      end if;
    
    end definirConferente;
  
    procedure cancelarConfAndamento is
    
    begin
      for c_confAberta in (select distinct cp.idpacking, cp.idnotafiscal,
                                           pc.idconfpacking, cp.idusuario,
                                           cp.codbarratarefa
                             from confpacking cp, produtoconfpacking pc
                            where cp.idonda = p_idOnda
                              and cp.status = C_STATUS_EM_CONTAGEM
                              and pc.idconfpacking = cp.id
                              and pc.status = 1)
      
      loop
        cancelarTodasAsContagens(c_confAberta.Idconfpacking,
                                 c_confAberta.idusuario);
      
        -- Para cada contagem em aberto, define o novo usuário selecionado como conferente
        insert into confpacking
          (id, idpacking, idnotafiscal, idusuario, idonda, status,
           codBarraTarefa)
        values
          (SEQ_CONFPACKING.NEXTVAL, c_confAberta.idpacking,
           c_confAberta.Idnotafiscal, p_idUsuario, p_idOnda,
           C_STATUS_EM_CONTAGEM, c_confAberta.Codbarratarefa);
      
      end loop;
    
    end cancelarConfAndamento;
  
  begin
    -- Obter Tipo de Conferência
    select co.tipoconferenciapacking, co.confporumusuario,
           co.conferenciaporcheckoutexpress
      into v_tipoconferencia, v_confPorUmUsuario, v_checkoutExpress
      from configuracaoonda co, romaneiopai rp
     where rp.idromaneio = p_idOnda
       and co.idconfiguracaoonda = rp.idconfiguracaoonda;
  
    if v_tipoconferencia = C_TIPO_POR_TAREFA
       and p_codBarraTarefa is null then
      v_msg := t_message('Esta onda possui configuração de conferência por tarefa.' ||
                         ' Selecione o botão EXIBIR TAREFAS e tente novamente.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Encontrar Conferência Iniciada
    begin
      if v_tipoconferencia = C_TIPO_POR_TAREFA then
        select distinct c.*
          into r_confpacking
          from v_packingtarefa v, confpacking c
         where v.idonda = p_idOnda
           and v.idnotafiscal = p_idNotaFiscal
           and v.idenderecopacking = p_idPacking
           and decode(p_codBarraTarefa, null, '1', v.tarefa) =
               nvl(p_codBarraTarefa, '1')
           and v.statuspacking < 100
           and c.idpacking = v.idenderecopacking
           and c.idonda = v.idonda
           and c.idnotafiscal = v.idnotafiscal
           and c.status = C_STATUS_EM_CONTAGEM
           and decode(p_codBarraTarefa, null, '1', c.codbarratarefa) =
               decode(p_codBarraTarefa, null, '1', v.tarefa);
      elsif v_tipoconferencia = C_TIPO_POR_NF then
        select distinct c.*
          into r_confpacking
          from v_packingnf v, confpacking c
         where v.idonda = p_idOnda
           and v.idnotafiscal = p_idNotaFiscal
           and v.idenderecopacking = p_idPacking
           and v.statuspacking < 100
           and c.idpacking = v.idenderecopacking
           and c.idonda = v.idonda
           and c.idnotafiscal = v.idnotafiscal
           and c.status = C_STATUS_EM_CONTAGEM;
      end if;
    
    exception
      when no_data_found then
        r_confpacking := null;
    end;
  
    if r_confpacking.id is null then
      -- Se não encontrar uma conferência, cria uma nova
      if (v_confPorUmUsuario = 1 and v_checkoutExpress = 0) then
        definirConferente;
      else
        insert into confpacking
          (id, idpacking, idnotafiscal, idusuario, idonda, status,
           codBarraTarefa)
        values
          (seq_confpacking.nextval, p_idPacking, p_idNotaFiscal,
           p_idUsuario, p_idOnda, C_STATUS_EM_CONTAGEM, p_codBarraTarefa);
      end if;
    else
      if (v_confPorUmUsuario = C_SIM and v_checkoutExpress = C_NAO) then
      
        -- Cancela as contegens que tem em andamento
        cancelarConfAndamento;
      
        -- Altera o usuário de conferência para a Onda
        update confpacking cp
           set cp.idusuario = p_idUsuario
         where cp.idonda = r_confpacking.idonda
           and cp.status = C_STATUS_EM_CONTAGEM;
      
      else
        -- Se encontrar uma conferência iniciada, atualiza o idUsuario
        update confpacking c
           set c.idusuario = p_idUsuario
         where c.idpacking = r_confpacking.idpacking
           and c.idonda = r_confpacking.idonda
           and c.idnotafiscal = r_confpacking.idnotafiscal
           and c.status = C_STATUS_EM_CONTAGEM
           and decode(p_codBarraTarefa, null, '1', c.codbarratarefa) =
               nvl(p_codBarraTarefa, '1');
      end if;
    end if;
  end definirUsuarioConfPacking;

  function buscaNotaRetornoArmazenagem(p_identificador in varchar2)
    return varchar2 is
    v_idnotafiscalretorno         varchar2(100);
    v_momentodispretornosimbolico number;
  begin
    begin
    
      select d.momentodispretornosimbolico
        into v_momentodispretornosimbolico
        from depositante d, notafiscal nf
       where 1 = 1
         and nf.idnotafiscal = p_identificador
         and nf.iddepositante = d.identidade;
    
      if (v_momentodispretornosimbolico <> 0) then
        return p_identificador;
      else
        select rs.idnotafiscalretorno
          into v_idnotafiscalretorno
          from retornosimbolico rs
         where rs.idnotafiscalvenda = p_identificador;
      
      end if;
    exception
      when no_data_found then
        v_idnotafiscalretorno := p_identificador;
      when others then
        v_idnotafiscalretorno := p_identificador;
    end;
  
    return v_idnotafiscalretorno;
  end;

  procedure finalizarAtivPacking
  (
    p_idNotaFiscal number,
    p_idUsuario    number
  ) is
    v_identificador  varchar2(200);
    v_qtde_atividade number;
  begin
  
    for c_nf_tarefa in (select nvl(ret.idnotafiscalvenda, m.idnotafiscal) identificador,
                               lpad(m.idonda, 10, '0') ||
                                lpad(m.identificador, 4, '0') codbarratarefa
                          from retornosimbolico ret, nfromaneio nfr,
                               movimentacao m
                         where (ret.idnotafiscalvenda = p_idNotaFiscal or
                               ret.idnotafiscalretorno = p_idNotaFiscal or
                               nfr.idnotafiscal = p_idNotaFiscal)
                           and nfr.idnotafiscal = ret.idnotafiscalretorno(+)
                           and m.idnotafiscal = nfr.idnotafiscal
                           and m.idonda = nfr.idromaneio
                           and m.status in
                               (STATUS_MOV_FINALIZADO, STATUS_MOV_CONCLUIDO)
                           and not exists
                         (select 1
                                  from movimentacao m1
                                 where m1.idonda = m.idonda
                                   and m1.idnotafiscal = m.idnotafiscal
                                   and m1.identificador = m.identificador
                                   and m.status not in (2, 4))
                         group by nvl(ret.idnotafiscalvenda, m.idnotafiscal),
                                  lpad(m.idonda, 10, '0') ||
                                   lpad(m.identificador, 4, '0'))
    loop
      v_identificador := c_nf_tarefa.identificador;
    
      if isConferenciaPorTarefa(c_nf_tarefa.identificador) then
        v_identificador := c_nf_tarefa.codbarratarefa;
      end if;
    
      select count(1)
        into v_qtde_atividade
        from atividade a
       where a.idoperacao = v_identificador;
    
      if (v_qtde_atividade = 0) then
        select count(1)
          into v_qtde_atividade
          from atividade a
         where a.idoperacao = to_number(v_identificador);
      end if;
    
      if (v_qtde_atividade > 0) then
        pk_convocacao.finalizaPackingColetor(p_idUsuario, v_identificador);
      end if;
    end loop;
  
  end finalizarAtivPacking;

  procedure regUsuarioImpCartaoPresente
  (
    p_idVolumeRomaneio in number,
    p_idUsuario        in number
  ) is
  
  begin
  
    for c_cartao in (select cp.idordemsepitem, cp.idconteudovolume
                       from volumeromaneio vr, conteudovolume cv,
                            cartaopresentevolume cp
                      where vr.idvolumeromaneio = p_idVolumeRomaneio
                        and cv.idvolumeromaneio = vr.idvolumeromaneio
                        and cp.idconteudovolume = cv.id)
    loop
      registrarImpOuReimpCartao(c_cartao.idordemsepitem,
                                c_cartao.idconteudovolume, p_idUsuario,
                                C_NAO);
    
    end loop;
  end regUsuarioImpCartaoPresente;

  procedure registrarImpOuReimpCartao
  (
    p_idOrdemSepItem   in number,
    p_idConteudoVolume in number,
    p_idUsuario        in number,
    p_reimpressao      in number
  ) is
    v_data date;
  begin
    -- garantir que a data e hora sejam exatamente iguais para as duas tabelas
    v_data := sysdate;
  
    if (p_reimpressao = C_NAO) then
    
      update embrulhopresentevolume ep
         set ep.idusuariocartaopresente = p_idUsuario,
             ep.dataimpcartaopresente   = v_data,
             ep.cartaopresenteimpresso  = C_SIM
       where ep.idordemsepitem = p_idOrdemSepItem
         and ep.idconteudovolume = p_idConteudoVolume;
    
      update cartaopresentevolume cp
         set cp.idusuariocartaopresente = p_idUsuario,
             cp.dataimpcartaopresente   = v_data,
             cp.cartaopresenteimpresso  = C_SIM
       where cp.idordemsepitem = p_idOrdemSepItem
         and cp.idconteudovolume = p_idConteudoVolume;
    
    else
    
      update embrulhopresentevolume ep
         set ep.idusuarioreimpcartaopresente = p_idUsuario,
             ep.datareimpcartaopresente      = v_data,
             ep.cartaopresenteimpresso       = C_SIM
       where ep.idordemsepitem = p_idOrdemSepItem
         and ep.idconteudovolume = p_idConteudoVolume;
    
      update cartaopresentevolume cp
         set cp.idusuarioreimpcartaopresente = p_idUsuario,
             cp.datareimpcartaopresente      = v_data,
             cp.cartaopresenteimpresso       = C_SIM
       where cp.idordemsepitem = p_idOrdemSepItem
         and cp.idconteudovolume = p_idConteudoVolume;
    
    end if;
  end registrarImpOuReimpCartao;

  function isReetiquetagemVolumes
  (
    p_idOnda       in number,
    p_idNotaFiscal in number
  ) return number is
    v_exibirTotVolEtiquetaVolume number;
    v_qtdeRestante               number;
    v_numeroProximoVolume        number;
    v_totalVolumesSNF            number;
  begin
    select co.exibirtotalvoletiquetavolume
      into v_exibirTotVolEtiquetaVolume
      from romaneiopai rp, configuracaoonda co
     where rp.idromaneio = p_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (v_exibirTotVolEtiquetaVolume > 0) then
      select sum(case
                    when v.qtdetotal - v.qtdeemvolume - v.qtdecontada < 0 then
                     0
                    else
                     v.qtdetotal - v.qtdeemvolume - v.qtdecontada
                  end) qtdeRestante
        into v_qtdeRestante
        from v_produtoconfpacking v
       where v.idonda = p_idOnda
         and v.idnotafiscal = p_idNotaFiscal;
    
      if (v_qtdeRestante = 0) then
        select nvl(max(vr.numero), 0) + 1
          into v_numeroProximoVolume
          from volumeromaneio vr
         where vr.idromaneio = p_idOnda
           and vr.idnotafiscal = p_idNotaFiscal
           and vr.statusvolume = 0;
      end if;
    
      select nvl(snf.totalvolumes, 0)
        into v_totalVolumesSNF
        from saidapornf snf
       where snf.idonda = p_idOnda
         and snf.idnotafiscal = p_idNotaFiscal;
    
      if (v_totalVolumesSNF <> 0)
         and (v_numeroProximoVolume <> v_totalVolumesSNF) then
        return 1;
      else
        return 0;
      end if;
    else
      return 0;
    end if;
  end;

  function isTotalVolumeNumVolume
  (
    p_idOnda       in number,
    p_idNotaFiscal in number
  ) return number is
    v_qtdevolumesgerados number;
    v_numerovolume       number;
  begin
  
    select qtdevolumesgerados, numerovolume
      into v_qtdevolumesgerados, v_numerovolume
      from (select count(1) qtdevolumesgerados
               from volumeromaneio v
              where v.idnotafiscal = p_idNotaFiscal
                and v.idromaneio = p_idOnda
                and v.statusvolume = 0) volgerados,
           (select max(vr.numero) numerovolume
               from volumeromaneio vr
              where vr.idromaneio = p_idOnda
                and vr.idnotafiscal = p_idNotaFiscal
                and vr.statusvolume = 0) numerovol;
  
    if (v_numerovolume > v_qtdevolumesgerados) then
      return v_numerovolume;
    end if;
  
    return 0;
  end;

  function verificarMensagemPresente
  (
    p_idnotafiscal     in number,
    p_idvolumeromaneio in number
  ) return number is
    v_temMensagemPresente number;
  begin
    select count(osi.mensagempresente)
      into v_temMensagemPresente
      from ordemseparacao os, ordemseparacaoitem osi, volumeromaneio vr
     where os.idordemseparacao = osi.idordemsep
       and osi.giftwrapid is not null
       and osi.mensagempresente is not null
       and os.idnotafiscal = p_idnotafiscal
       and os.idnotafiscal = vr.idnotafiscal
       and vr.statusvolume = 0
       and vr.idvolumeromaneio = p_idvolumeromaneio
       and exists
     (select 1
              from cartaopresentevolume cpv, conteudovolume cv
             where cpv.idconteudovolume = cv.id
               and cpv.idordemsepitem = osi.idordemsepitem
               and cv.idvolumeromaneio = vr.idvolumeromaneio);
  
    return v_temMensagemPresente;
  end;

  function verificarMensagemProduto
  (
    p_idnotafiscal     in number,
    p_idvolumeromaneio in number
  ) return number is
    v_temMensagemProduto number;
  begin
    select count(osi.mensagempresente)
      into v_temMensagemProduto
      from ordemseparacao os, ordemseparacaoitem osi, volumeromaneio vr
     where os.idordemseparacao = osi.idordemsep
       and osi.giftwrapid is null
       and osi.mensagempresente is not null
       and os.idnotafiscal = p_idnotafiscal
       and os.idnotafiscal = vr.idnotafiscal
       and vr.statusvolume = 0
       and vr.idvolumeromaneio = p_idvolumeromaneio
       and exists
     (select 1
              from cartaopresentevolume cpv, conteudovolume cv
             where cpv.idconteudovolume = cv.id
               and cpv.idordemsepitem = osi.idordemsepitem
               and cv.idvolumeromaneio = vr.idvolumeromaneio);
  
    return v_temMensagemProduto;
  end;

  function validarPackingSequencial(p_identificador varchar2) return number is
    v_idonda romaneiopai.idromaneio%type;
    v_msg    t_message;
  
    C_PACKING_SEQUENCIAL constant number := 1;
  
    procedure validarIdentificadorOnda is
    begin
      begin
        select r.idromaneio
          into v_idonda
          from romaneiopai r, configuracaoonda co
         where r.codigointerno = p_identificador
           and co.conferenciapackingsequencial = C_PACKING_SEQUENCIAL
           and co.idconfiguracaoonda = r.idconfiguracaoonda;
      exception
        when no_data_found then
          v_idonda := 0;
      end;
    end validarIdentificadorOnda;
  
    procedure validarIdentificadorTarefa is
    begin
      begin
        select v.idonda
          into v_idonda
          from v_tarefas_onda v, romaneiopai r, configuracaoonda co
         where v.codbarratarefa = p_identificador
           and co.conferenciapackingsequencial = C_PACKING_SEQUENCIAL
           and r.idromaneio = v.idonda
           and co.idconfiguracaoonda = r.idconfiguracaoonda
         group by v.idonda;
      exception
        when no_data_found then
          v_idonda := 0;
      end;
    end validarIdentificadorTarefa;
  
    procedure validarIdentificadorNotaFiscal is
    begin
      begin
        select rp.idromaneio
          into v_idonda
          from romaneiopai rp, nfromaneio nfr, configuracaoonda co
         where nfr.idnotafiscal = p_identificador
           and co.conferenciapackingsequencial = C_PACKING_SEQUENCIAL
           and nfr.idromaneio = rp.idromaneio
           and co.idconfiguracaoonda = rp.idconfiguracaoonda
         group by rp.idromaneio;
      exception
        when no_data_found then
          v_idonda := 0;
        when others then
          v_idonda := 0;
      end;
    end validarIdentificadorNotaFiscal;
  
  begin
    validarIdentificadorOnda;
  
    if (nvl(v_idonda, 0) > 0) then
      return v_idonda;
    end if;
  
    validarIdentificadorTarefa;
  
    if (nvl(v_idonda, 0) > 0) then
      v_msg := t_message('Para onda com configuração Packing Sequencial, deve-se informar o código interno da onda.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarIdentificadorNotaFiscal;
  
    if (nvl(v_idonda, 0) > 0) then
      v_msg := t_message('Para onda com configuração Packing Sequencial, deve-se informar o código interno da onda.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    return v_idonda;
  
  end validarPackingSequencial;

  procedure registrarTotVolSaidaPorNf
  (
    p_idOnda       in number,
    p_idNotaFiscal in number,
    p_idUsuario    in number default null,
    p_idSupervisor in number default null
  ) is
    v_exibirTotVolEtiquetaVol number;
    v_qtdeRestante            number;
    v_qtdeVolumes             number;
    v_totalVolumesAntes       number;
  begin
    select co.exibirtotalvoletiquetavolume
      into v_exibirTotVolEtiquetaVol
      from romaneiopai rp, configuracaoonda co
     where rp.idromaneio = p_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (v_exibirTotVolEtiquetaVol > 0) then
      select nvl(sum(qtdemovimentada), 0)
        into v_qtdeRestante
        from movimentacao m
       where m.idonda = p_idOnda
         and m.idnotafiscal = p_idNotaFiscal
         and m.qtdemovimentada - m.qtdeemvolume > 0
         and m.idvolumeromaneio is null;
    
      if (v_qtdeRestante > 0) then
        return;
      end if;
    
      select count(idvolumeromaneio)
        into v_qtdeVolumes
        from volumeromaneio v
       where v.idromaneio = p_idOnda
         and v.idnotafiscal = p_idNotaFiscal
         and v.statusvolume = 0;
    
      select snf.totalvolumes
        into v_totalVolumesAntes
        from saidapornf snf
       where snf.idonda = p_idOnda
         and snf.idnotafiscal = p_idNotaFiscal;
    
      update saidapornf snf
         set snf.totalvolumes = v_qtdeVolumes
       where snf.idonda = p_idOnda
         and snf.idnotafiscal = p_idNotaFiscal;
    
      if (p_idUsuario is not null)
         and (p_idSupervisor is not null) then
        pk_utilities.GeraLog(p_idUsuario,
                             'ALTERADO O TOTAL DE VOLUMES DA NOTA FISCAL ID: ' ||
                              p_idNotaFiscal || '. ANTES: ' ||
                              v_totalVolumesAntes || ' DEPOIS: ' ||
                              v_qtdeVolumes ||
                              '. AUTORIZADO PELO SUPERVISOR ID: ' ||
                              p_idSupervisor, p_idNotaFiscal, 'TV');
      end if;
    end if;
  end;

  procedure entrarBarraOuLoteConferenciacx
  (
    p_idconfpacking in number,
    p_barra         in varchar2,
    p_quantidade    in number,
    p_idusuario     in number,
    p_checkout      in number := 0,
    p_solicitaEmb   in number := 0,
    p_solicitaQtde  in number := 0,
    p_identificador in varchar2,
    p_idnota        in number
  ) is
  
    STATUS_MOV_AGUARDANDO constant number := 0;
    STATUS_MOV_EXECUTANDO constant number := 1;
    STATUS_MOV_FINALIZADO constant number := 2;
  
    v_volume        number;
    v_packing       number;
    v_idconfpacking number;
    v_armazem       number;
    v_geravolume    number;
    v_identificador varchar2(200);
  
  begin
    delete from gtt_produtoconferencia;
  
    begin
      select cp.idpacking, rp.idarmazem, de.gerarvolumesautomaticamente
        into v_packing, v_armazem, v_geravolume
        from confpacking cp, romaneiopai rp, notafiscal nf,
             configuracaoonda co, tipocaixavolume tcv, entidade d,
             depositante de
       where cp.id = p_idConfPacking
         and rp.idromaneio = cp.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and nf.idnotafiscal = nvl(p_idnota, nf.idnotafiscal)
         and nf.idnotafiscal = cp.idnotafiscal
         and tcv.idtipocaixavolume(+) = cp.idtipocaixa
         and d.identidade = nf.iddepositante
         and nf.iddepositante = de.identidade
            -- Onda de OS não confere manualmente
         and not exists (select 1
                from ordemservico os
               where os.idromaneio = rp.idromaneio)
         and exists
       (select 1
                from movimentacao m
               where m.status in
                     (STATUS_MOV_AGUARDANDO, STATUS_MOV_EXECUTANDO,
                      STATUS_MOV_FINALIZADO)
                 and m.idonda = cp.idonda
                 and m.idnotafiscal = cp.idnotafiscal
                 and m.idlocaldestino = cp.idpacking);
    exception
      when no_data_found then
        v_packing    := null;
        v_armazem    := null;
        v_geravolume := 0;
    end;
  
    v_identificador := p_identificador;
    v_idconfpacking := p_idconfpacking;
  
    if (v_packing is not null and v_armazem is not null) then
      for i in 1 .. p_quantidade
      loop
        pk_packing.entrarBarraOuLoteConferencia(v_idconfpacking, p_barra, 1,
                                                p_idusuario, p_checkout,
                                                p_solicitaEmb,
                                                p_solicitaQtde, 1);
        if (v_geravolume = 1) then
          v_volume := pk_packing.gerarVolume(v_idconfpacking, 0, p_idusuario,
                                             1);
        
          insert into gtt_aux
            (valor1, valor2)
          values
            (v_volume, 0);
        end if;
      
        if (i >= 1 and i < p_quantidade) then
          delete from gtt_identificacaopacking;
          pk_packing.entrarIdentificadorPacking(v_armazem, v_identificador,
                                                v_packing, p_idusuario,
                                                p_checkout);
        
          select gtt.idconfpacking
            into v_idconfpacking
            from gtt_identificacaopacking gtt;
        end if;
      end loop;
    
      if (v_geravolume = 0) then
        insert into gtt_aux
          (valor1, valor2)
        values
          (0, 0);
      end if;
    end if;
  end;

  function trocarLoteIndustria
  (
    p_idConfPacking in number,
    p_idusuario     in number
  ) return number is
    v_retorno number := 0;
  
    v_qtde        number;
    v_confpacking confpacking%rowtype;
    v_msg         t_message;
  
  begin
    select *
      into v_confpacking
      from confpacking c
     where c.id = p_idconfpacking;
  
    select sum(qtdecontada)
      into v_qtde
      from v_tarefaprodutoconfpacking
     where idnotafiscal = v_confpacking.idnotafiscal
       and idenderecopacking = v_confpacking.idpacking
       and idonda = v_confpacking.idonda
       and codbarratarefa =
           nvl(v_confpacking.codbarratarefa, codbarratarefa);
  
    if (v_qtde > 0) then
      v_msg := t_message('Para efetuar a troca de Lote Indústria é necessario gerar os volumes pendentes na contagem atual.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_confpacking in (select v.idonda, v.idnotafiscal, v.idproduto,
                                 nf.iddepositante, nf.idarmazem,
                                 v.idenderecopacking,
                                 v.descrlote loteindustria, e.barra,
                                 (v.qtdetotal - v.qtdecontada -
                                  v.qtdeemvolume) qtdTroca,
                                 lc.idregiao idRegiaoDestino, 0 buffer,
                                 null identificador, v.codbarratarefa tarefa
                            from v_tarefaprodconfpacklotevenci v, embalagem e,
                                 notafiscal nf, local lc, confpacking cp
                           where e.idproduto = v.idproduto
                             and e.barra =
                                 pk_produto.ret_codbarra_nao_precad(v.idproduto,
                                                                    1)
                             and v.idonda = v_confpacking.idonda
                             and v.idnotafiscal = v_confpacking.idnotafiscal
                             and cp.id = p_idconfpacking
                             and v.idnotafiscal = nf.idnotafiscal
                             and v.idenderecopacking = lc.id
                             and v.idonda = cp.idonda
                             and v.idnotafiscal = cp.idnotafiscal
                             and v.codbarratarefa = cp.codbarratarefa
                             and (v.qtdetotal - v.qtdecontada -
                                 v.qtdeemvolume) > 0)
    loop
    
      v_retorno := pk_trocalotesep.buscarLoteIndustriaParaTroca(c_confpacking.idonda,
                                                                c_confpacking.idnotafiscal,
                                                                c_confpacking.idproduto,
                                                                c_confpacking.iddepositante,
                                                                c_confpacking.idarmazem,
                                                                c_confpacking.idenderecopacking,
                                                                c_confpacking.loteindustria,
                                                                c_confpacking.barra,
                                                                c_confpacking.qtdtroca,
                                                                c_confpacking.idregiaodestino,
                                                                c_confpacking.buffer,
                                                                c_confpacking.identificador,
                                                                p_idusuario,
                                                                c_confpacking.tarefa,
                                                                1);
    
      if (v_retorno = 0) then
        rollback;
        exit;
      end if;
    
    end loop;
  
    return v_retorno;
  
  end trocarLoteIndustria;

  function getMomentoFaturamentoPedido
  (
    p_idOnda       number,
    p_idNotafiscal number
  ) return number is
    C_FATURAMENTOONDA_DESABILITADO constant number := 5;
    v_momentofaturamentopedido number;
  begin
    select c.momentofaturamentopedido
      into v_momentofaturamentopedido
      from configuracaoonda c, romaneiopai r
     where c.idconfiguracaoonda = r.idconfiguracaoonda
       and r.idromaneio = p_idOnda;
  
    if (v_momentofaturamentopedido = C_FATURAMENTOONDA_DESABILITADO) then
      select d.momentofaturamentopedido
        into v_momentofaturamentopedido
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and nf.idnotafiscal = p_idNotafiscal;
    end if;
  
    return v_momentofaturamentopedido;
  
  end getMomentoFaturamentoPedido;

  procedure coletaAutomaticaAposUltimoVol
  (
    p_idonda    in number,
    p_idusuario in number
  ) is
    v_listaIdNotafiscal pk_carga.tIdNotaFiscal;
    i                   integer;
  
    C_COLETA_AUTOMATICA constant number := 1;
  
    function isGeradoTodosVolDaOnda return boolean is
      v_qtdeRestante number;
    begin
      select nvl(sum(qtdemovimentada), 0)
        into v_qtdeRestante
        from movimentacao m
       where m.idonda = p_idonda
         and m.qtdemovimentada - m.qtdeemvolume > 0
         and m.idvolumeromaneio is null;
    
      return v_qtdeRestante = 0;
    end isGeradoTodosVolDaOnda;
  
    function getColetaAutomaticaOnda return boolean is
      v_coletaAutomatica number;
    begin
      begin
        select 1
          into v_coletaAutomatica
          from romaneiopai r, configuracaoonda co
         where r.idromaneio = p_idonda
           and co.coletaautomaticaaposgeracaovol = C_COLETA_AUTOMATICA
           and co.idconfiguracaoonda = r.idconfiguracaoonda;
      exception
        when no_data_found then
          v_coletaAutomatica := 0;
      end;
      return v_coletaAutomatica > 0;
    end getColetaAutomaticaOnda;
  
  begin
    if (not getColetaAutomaticaOnda) then
      return;
    end if;
  
    if (isGeradoTodosVolDaOnda) then
      i := 1;
      for r_nfs in (select nfr.idnotafiscal
                      from nfromaneio nfr
                     where nfr.idromaneio = p_idonda)
      loop
        v_listaIdNotafiscal(i) := r_nfs.idnotafiscal;
        i := i + 1;
      end loop;
      pk_carga.gerarColetaAutomatica(v_listaIdNotafiscal, p_idusuario,
                                     C_COLETA_AUTOMATICA, 'S');
    end if;
  end coletaAutomaticaAposUltimoVol;

  function isConteudoRestanteCxSeparacao
  (
    p_idpacking      in number,
    p_idconfpacking  in number,
    p_idonda         in number,
    p_idnotafiscal   in number,
    p_codbarratarefa in varchar2
  ) return number is
    v_qtderestante number;
  begin
    select case
              when sum(v.qtdetotal) - sum(v.qtdeemvolume) -
                   sum(v.qtdecontada) < 0 then
               0
              else
               sum(v.qtdetotal) - sum(v.qtdeemvolume) - sum(v.qtdecontada)
            end qtdeRestante
      into v_qtderestante
      from (select sum(m.quantidade) qtdetotal, 0 qtdecontada, 0 qtdeemvolume
               from movimentacao m, lote lt, produto p, romaneiopai rp
              where m.status in (0, 1, 2)
                and m.idnotafiscal = p_idnotafiscal
                and m.idonda = p_idonda
                and m.idlocaldestino = p_idpacking
                and lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0') =
                    p_codbarratarefa
                and lt.idlote = m.idlote
                and p.idproduto = lt.idproduto
                and rp.idromaneio = m.idonda
                and rp.statusonda in (2, 4)
             union all
             select 0 qtdetotal,
                    nvl(sum(pc.qtde * e.fatorconversao), 0) qtdecontada,
                    0 qtdeemvolume
               from confpacking c, produtoconfpacking pc, produto p,
                    embalagem e, romaneiopai rp, notafiscal n, nfromaneio nfr
              where pc.idconfpacking = c.id
                and pc.status = 1
                and p.idproduto = pc.idproduto
                and c.status = 0
                and c.id = p_idconfpacking
                and c.idnotafiscal = n.idnotafiscal
                and e.idproduto = pc.idproduto
                and e.barra = pc.barra
                and rp.idromaneio = c.idonda
                and rp.statusonda in (2, 4)
                and nfr.idromaneio = rp.idromaneio
                and nfr.idnotafiscal = n.idnotafiscal
             union all
             select 0 qtdetotal, 0 qtdecontada,
                    nvl(sum(cv.quantidade), 0) qtdeemvolume
               from movimentacao m, v_conteudovolume cv, romaneiopai rp
              where m.status in (0, 1, 2)
                and m.idnotafiscal = p_idnotafiscal
                and m.idonda = p_idonda
                and m.idlocalorigem = p_idpacking
                and lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0') =
                    p_codbarratarefa
                and cv.idvolumeromaneio = m.idvolumeromaneio
                and rp.idromaneio = m.idonda
                and rp.statusonda in (2, 4)) v;
  
    return v_qtderestante;
  end isConteudoRestanteCxSeparacao;

  procedure validarCaixaSelecionada
  (
    p_barraCaixa      in varchar2,
    r_tipoCaixaVolume in out tipocaixavolume%rowtype
  ) is
    v_msg t_message;
  begin
    if length(p_barraCaixa) > 32 then
      v_msg := t_message('O código de barras informado não pertence a uma caixa de volume, ' ||
                         'pois possui mais que 32 caracteres.' || chr(13) ||
                         'Barra Informada: {0}');
      v_msg.addParam(p_barraCaixa);
      raise_application_error(-20003, v_msg.formatMessage);
    end if;
  
    begin
      --Lock para impedir erros de concorrencias por operacoes simultaneas
      select tv.*
        into r_tipoCaixaVolume
        from tipocaixavolume tv
       where tv.barra = p_barraCaixa
         for update;
    exception
      when no_data_found then
        v_msg := t_message('Não foi encontrada caixa de volume cadastrada com o código de barras informado. ' ||
                           chr(13) || 'Barra Informada: {0}');
        v_msg.addParam(p_barraCaixa);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if r_tipoCaixaVolume.disponivel = 0 then
      v_msg := t_message('A caixa de volume selecionada não se encontra disponível.' ||
                         chr(13) || 'Barra Informada: {0}');
      v_msg.addParam(p_barraCaixa);
      raise_application_error(-20003, v_msg.formatMessage);
    end if;
  
    if r_tipoCaixaVolume.ativo = 0 then
      v_msg := t_message('A caixa de volume selecionada não se encontra ativa.' ||
                         chr(13) || 'Barra Informada: {0}');
      v_msg.addParam(p_barraCaixa);
      raise_application_error(-20003, v_msg.formatMessage);
    end if;
  end validarCaixaSelecionada;

  procedure confirmarCancelamentoProduto
  (
    p_idConfCheckout in number,
    p_idConfPacking  in number,
    p_idProduto      in number,
    p_idLocalRetorno in varchar2,
    p_idUsuario      in number
  ) is
    row_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(row_locked, -54);
    v_msg t_message;
  
    v_idArmazem number;
  
    v_confpacking            confpacking%rowtype;
    r_notafiscal             notafiscal%rowtype;
    v_idordemseparacao       number;
    v_idordemseparacaocancel number;
    v_messagecontrolnumber   number;
  
    procedure validarLocalRetorno is
      r_localretorno local%rowtype;
      v_vincSetor    number;
    begin
      begin
        select l.idarmazem
          into v_idArmazem
          from confcheckout ck, local l
         where ck.id = p_idConfCheckout
           and l.id = ck.idpacking
           and ck.status = 0;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, conferencia checkout não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      begin
        select lr.*
          into r_localretorno
          from local lr
         where lr.idarmazem = v_idArmazem
           and lr.idlocal = p_idLocalRetorno;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, local de retorno {0} não encontrado.');
          v_msg.addParam(p_idLocalRetorno);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (r_localretorno.ativo = 'N') then
        v_msg := t_message('Problema ao cancelar produto, local de retorno {0} não está ativo.');
        v_msg.addParam(p_idLocalRetorno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_localretorno.tipo not in (0, 1, 2)) then
        v_msg := t_message('Problema ao cancelar produto, local de retorno {0} deve ser picking ou pulmão.');
        v_msg.addParam(p_idLocalRetorno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_localretorno.idregiao is null) then
        v_msg := t_message('Problema ao cancelar produto, local de retorno {0} não possui região definida.');
        v_msg.addParam(p_idLocalRetorno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_localretorno.idsetor is null) then
        v_msg := t_message('Problema ao cancelar produto, local de retorno {0} não possui setor definido.');
        v_msg.addParam(p_idLocalRetorno);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      delete gtt_local;
    
      insert into gtt_local
        (idarmazem, idlocal)
      values
        (r_localretorno.idarmazem, r_localretorno.idlocal);
    end validarLocalRetorno;
  
    procedure retirarPedidoOnda is
    begin
      begin
        select *
          into v_confpacking
          from confpacking cp
         where cp.id = p_idConfPacking
           and cp.status = C_STATUS_EM_CONTAGEM
           for update nowait;
      exception
        when row_locked then
          v_msg := t_message('Já existe um cancelamento de produto sendo realizado para este packing. Favor tentar novamente a operação.');
          raise_application_error(-20000, v_msg.formatMessage);
        when no_data_found then
          v_msg := t_message('Conferência do packing não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      pk_onda_cancelar.removerNotaFiscalOnda(v_confpacking.idonda,
                                             v_confpacking.idnotafiscal,
                                             p_idUsuario);
    end retirarPedidoOnda;
  
    procedure cancelarNotaFiscal is
      v_erro_can varchar2(1000);
    begin
      begin
        select *
          into r_notafiscal
          from notafiscal
         where idnotafiscal = v_confpacking.idnotafiscal;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, nota fiscal id: {0} não encontrada.');
          v_msg.addParam(r_notafiscal.idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      pk_notafiscal.CancelaNF(r_notafiscal.idprenf, p_idUsuario,
                              'CANCELADO PELA TELA DE CHECKOUT EXPRESS QUANDO O PRODUTO FOI CANCELADO POR OC',
                              'N', 'N', v_erro_can);
    
      if (v_erro_can is not null) then
        v_msg := t_message('Não é possível cancelar O Produto Id: ' ||
                           '{0}.' || chr(13) ||
                           ' Nota Fiscal associada Id:{1}' ||
                           ' ocorreu um erro ao realizar o cancelamento da nota fiscal.' ||
                           chr(13) || 'Erro: {2}');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(r_notafiscal.idnotafiscal);
        v_msg.addParam(v_erro_can);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end cancelarNotaFiscal;
  
    procedure cancelarOF is
      v_tipoIntegracaoCancelamentoNf number;
      C_XML_MODELO_ASN constant number := 5;
      v_resultCode     varchar(2);
      v_resultCodeItem varchar(2);
      v_statusOs       ordemseparacao.status%type;
    begin
      begin
        select os.idordemseparacao, osc.id, osc.messagecontrolnumber,
               os.status
          into v_idordemseparacao, v_idordemseparacaocancel,
               v_messagecontrolnumber, v_statusOs
          from ordemseparacao os, ordemseparacaocancelamento osc
         where os.idnotafiscal = r_notafiscal.idnotafiscal
           and osc.idordemseparacao = os.idordemseparacao;
      exception
        when no_data_found then
          v_msg := t_message('Problema ao cancelar produto, ordem de separação não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_idOrdemSeparacao <> 0 and v_statusOs = 0) then
        pk_ordemseparacao.cancelaOrdemSeparacao(v_idordemseparacao,
                                                'CANCELADO PELA TELA DE CHECKOUT EXPRESS QUANDO O PRODUTO FOI CANCELADO POR OC',
                                                p_idUsuario, 1);      
      end if;
    end cancelarOF;
  
    procedure exportarOrderCancelResponse is
    begin
      update ordemseparacaocancelamentoitem osci
         set osci.status = 1
       where osci.idproduto = p_idProduto
         and osci.status = 0
         and osci.idordemseparacaocancelamento in
             (select osc.id
                from ordemseparacaocancelamento osc, ordemseparacao os
               where osc.poderecebercancelamentoitem = 1
                 and osc.messagecontrolnumber = v_messagecontrolnumber
                 and os.idordemseparacao = osc.idordemseparacao
                 and os.idordemseparacao = v_idOrdemSeparacao
                 and os.idnotafiscal = r_notafiscal.idnotafiscal
                 and os.status = 2);
    
      update ordemseparacaocancelamento osc
         set osc.poderecebercancelamentoitem = 0,
             osc.liberadaparaexportarocr     = 1
       where osc.id = v_idordemseparacaocancel
         and osc.messagecontrolnumber = v_messagecontrolnumber;
    
      pk_integracao.exportarOCR(v_idOrdemSeparacao, v_messagecontrolnumber);
    end exportarOrderCancelResponse;
  
  begin
    validarLocalRetorno;
    retirarPedidoOnda;
    cancelarNotaFiscal;
    cancelarOF;
    exportarOrderCancelResponse;
  
    update confcheckout
       set status = 1
     where id = p_idConfCheckout;
  
  end confirmarCancelamentoProduto;

end PK_PACKING;
/

