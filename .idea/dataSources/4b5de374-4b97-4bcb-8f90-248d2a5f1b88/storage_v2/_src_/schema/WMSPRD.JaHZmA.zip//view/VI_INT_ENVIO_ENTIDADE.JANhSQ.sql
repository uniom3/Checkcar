create view VI_INT_ENVIO_ENTIDADE as
select e.evento, e.codigointerno, e.razaosocial, e.fantasia, e.pessoa,
       e.cnpj, e.inscrestadual, e.cpf, e.rg, e.tipoentidade,
       e.inscricaosuframa, e.cnpjdepositante, e.cep, e.endereco, e.numero,
       e.bairro, e.cidade, e.estado, e.pais, e.complemento, e.telefone,
       e.codendereco, e.codigosorter, e.sigla, e.endentrega, e.endcobranca,
       e.ativo, id, e.idreplicacao,
       decode(e.estrangeiro, 0, 'N', 'S') estrangeiro, e.idestrangeiro
  from int_envio_entidade e
/

