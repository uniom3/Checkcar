create package body pk_recebimento is

  v_msg t_message;

  function isConferenciaAlocada(p_idlotenf number) return boolean is
    v_conferenciaAlocada number;
  begin
    begin
      select tr.conferenciaalocada
        into v_conferenciaAlocada
        from tiporecebimento tr
       where tr.idtiporecebimento =
             (select l.idtiporecebimento
                from lotenf l
               where l.idlotenf = p_idlotenf);
    exception
      when no_data_found then
        v_conferenciaAlocada := 0;
    end;
  
    return v_conferenciaAlocada = 1;
  end;

  function isGerarLotePorPalete(p_idlotenf number) return boolean is
    v_gerarloteporpalete number;
  begin
    begin
      select tr.gerarloteporpalete
        into v_gerarloteporpalete
        from tiporecebimento tr
       where tr.idtiporecebimento =
             (select l.idtiporecebimento
                from lotenf l
               where l.idlotenf = p_idlotenf);
    exception
      when no_data_found then
        v_gerarloteporpalete := 0;
    end;
  
    return v_gerarloteporpalete = 1;
  end;

  /*
  * Desfaz a OR, apagando todos os lotes e notas fiscais ref. a OR.
  * OR - processada nao pode ser desfeita
  */
  procedure Desfazer_or
  (
    p_lotenf   in number,
    p_usuario  in number,
    p_validaos in varchar2 := 'S'
  ) is
    r_lotenf       lotenf%rowtype;
    v_existeAgenda number;
    v_idmotivo     number;
    v_qtdelote     number;
  
    function isORCrossdocking(r_lotenf lotenf%rowtype) return boolean is
      v_ClassificacaoRecebimento char(1);
    begin
      select tr.classificacao
        into v_ClassificacaoRecebimento
        from tiporecebimento tr
       where tr.idtiporecebimento = r_lotenf.idtiporecebimento;
    
      return v_ClassificacaoRecebimento = 'B';
    end isORCrossdocking;
  
    function isTransferenciaTitularidade(r_lotenf lotenf%rowtype)
      return boolean is
      v_transfTitularidade number;
    begin
      select tr.transferenciatitularidade
        into v_transfTitularidade
        from tiporecebimento tr
       where tr.idtiporecebimento = r_lotenf.idtiporecebimento;
    
      return v_transfTitularidade = 1;
    end isTransferenciaTitularidade;
  
    procedure limparPreEtiquetaGenerica(p_idlotenf in number) is
    begin
      for c_infMatValor in (select i.idcontagem, i.idpreetiquetagenerica
                              from informacaomaterialvalor i
                             where i.idlotenf = p_idlotenf
                               and i.temporario = 1)
      loop
        update informacaomaterialvalor i
           set i.idpreetiquetagenerica = null
         where i.idcontagem = c_infMatValor.idcontagem;
      
        update preetiquetagenerica p
           set p.tipooperacao = null
         where p.id = c_infMatValor.idpreetiquetagenerica;
      
      end loop;
    end limparPreEtiquetaGenerica;
  
  begin
    -- Realizando lock para impossibilitar concorrência com a geração de lote e mapa
    select lnf.status
      into r_lotenf.status
      from lotenf lnf
     where lnf.idlotenf = p_lotenf
       for update;
  
    r_lotenf := CarregarOR(p_lotenf);
  
    if not isConferenciaAlocada(r_lotenf.idlotenf) then
      v_exclusao_or_conf_aloc := 'N';
      if (r_lotenf.status = 'P')
         and (IniciouBaixaMapaAlocacao(p_lotenf) = true) then
        -- OR Processada.
        v_msg := t_message('ORDEM DE RECEBIMENTO JÁ PROCESSADA. OPERACAO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      v_exclusao_or_conf_aloc := 'S';
    end if;
  
    if pk_recebimento.isOrdemServico(p_lotenf)
       and p_validaos = 'S' then
      v_msg := t_message('ORDEM DE RECEBIMENTO GERADA PELA ORDEM DE SERVIÇO NÃO PODE SER EXCLUÍDA. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (isTransferenciaTitularidade(r_lotenf)) then
      v_msg := t_message('ORDEM DE RECEBIMENTO GERADA PELA TRANSFERÊNCIA DE TITULARIDADE. OPERACAO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if v_exclusao_or_conf_aloc = 'S' then
      select count(1)
        into v_qtdelote
        from lotelocal ll, orlote ol
       where ll.idlote = ol.idlote
         and ol.idlotenf = p_lotenf;
    
      if v_qtdelote > 0 then
        estornarRecebimento(p_lotenf, p_usuario);
      end if;
    end if;
  
    limparPreEtiquetaGenerica(p_lotenf);
    excluiDocDivergenciaEntrada(p_lotenf, p_usuario, 'EXCLUSÃO');
  
    -- Exclui as informações específicas e o checklist da OR se houver.
    delete from informacaomaterialvalor
     where idlotenf = p_lotenf;
  
    delete from importarinfoespecifica ie
     where ie.idlotenf = p_lotenf;
  
    delete from checklistmaterialvalor
     where idlotenf = p_lotenf;
  
    -- Exclui montagem de material
    delete from montagem
     where idlotenf = p_lotenf;
  
    delete from compmontagem
     where idlotenf = p_lotenf;
  
    -- Caso exista agendamento para a OR o mesmo também será cancelado.
    select count(*)
      into v_existeAgenda
      from dual
     where exists (select idlotenf
              from lotenf lnf, agendatransporte a
             where lnf.idlotenf = p_lotenf
               and lnf.idagendarecebimento = a.idagenda
               and a.status not in (4, 5)
               and lnf.idagendarecebimento is not null);
  
    if v_existeAgenda > 0 then
      begin
        select m.idmotivo
          into v_idmotivo
          from motivo m
         where m.ativo = 1
           and m.utzcancelaagendatransp = 1
           and m.interno = 1
           and rownum = 1;
      exception
        when no_data_found then
          begin
            select m.idmotivo
              into v_idmotivo
              from motivo m
             where m.ativo = 1
               and m.utzcancelaagendatransp = 1
               and rownum = 1;
          exception
            when no_data_found then
              v_msg := t_message('NÃO EXISTE MOTIVO CADASTRADO E ATIVO PARA CANCELAMENTO DE AGENDA DE TRANSPORTE. REALIZE O CADASTRO.');
              raise_application_error(-20000, v_msg.formatMessage);
          end;
      end;
    
      update agendatransporte ag
         set ag.idusuariocancelamento = p_usuario,
             ag.dtcancelamento        = sysdate,
             ag.status                = 5,
             ag.idmotivocancelamento  = v_idmotivo
       where ag.idagenda = r_lotenf.idagendarecebimento;
    
    end if;
  
    -- apaga os lotes da or
    pk_lote.apagarloteor(p_lotenf, p_usuario);
  
    delete from logalocacaoproduto
     where idlotenf = p_lotenf;
  
    delete from logalocacao
     where idlotenf = p_lotenf;
  
    -- seta a OR para nao liberada
    update lotenf
       set flaglibnf = 1
     where idlotenf = p_lotenf;
  
    -- apaga conferencia
    delete from ocorrencia
     where idlotenf = p_lotenf;
  
    pk_confentrada.excluirResumoConferenciaNF(p_lotenf);
  
    delete from conferenciaentradadetprep
     where idlotenf = p_lotenf;
  
    delete from conferenciaentradadetlote
     where idlotenf = p_lotenf;
  
    delete from conferenciaentradadet
     where idlotenf = p_lotenf;
  
    delete from conferenciaentrada
     where idlotenf = p_lotenf;
  
    -- apaga O.R.
    delete from danoor
     where idlotenf = p_lotenf;
  
    delete from sumprodlote
     where idlotenf = p_lotenf;
  
    for c_nf in (select idnotafiscal, idnotafiscalvinculada
                   from notafiscal
                  where idlotenf = p_lotenf)
    loop
      pk_notafiscal.RetirarNfOr(c_nf.idnotafiscal, p_lotenf, p_usuario);
      pk_recebimento_backlist.ajsuteBackupBacklist(c_nf.idnotafiscal, 1);
      if c_nf.idnotafiscalvinculada is not null then
        if (isORCrossdocking(r_lotenf)) then
          update notafiscal nf
             set nf.crossdocking = 'N'
           where nf.idnotafiscal = c_nf.idnotafiscalvinculada;
        end if;
      
        delete from nfimpressao
         where idprenf in
               (select idprenf
                  from notafiscal
                 where idnotafiscal = c_nf.idnotafiscal)
           and not exists (select 1
                  from backlist b, nfdet nd
                 where nd.idnfdet = b.idnfdet
                   and nd.nf = c_nf.idnotafiscal);
      end if;
    end loop;
  
    delete from checklistalocacao
     where idlotenf = p_lotenf;
  
    delete from notafiscal
     where idlotenf = (select idlotenf
                         from ordemservico o
                        where idlotenf = p_lotenf
                          and o.tiposervico = c_desmontagem_kit);
  
    update ordemservico
       set idlotenf = null
     where idlotenf = p_lotenf
       and tiposervico = 'D';
  
    delete from volumeconfentrada
     where idlotenf = p_lotenf;
  
    delete from tipocaixalotenf
     where idlotenf = p_lotenf;
  
    delete from produtoamostra p
     where p.idamostrarecebimento in
           (select a.idamostra
              from amostrarecebimento a
             where a.idlotenf = p_lotenf);
  
    delete from amostrarecebimento a
     where a.idlotenf = p_lotenf;
  
    if (isORCrossdocking(r_lotenf)) then
      update contentorrecebimento cr
         set cr.idlotenf = null,
             cr.idlote   = null,
             cr.situacao = 0
       where cr.idlotenf = r_lotenf.idlotenf;
    end if;
  
    delete from informacaomaterialvalor i
     where i.idlotenf = p_lotenf;
  
    delete from lotenf
     where idlotenf = p_lotenf;
  
    pk_integracao.estornarIntegracaoOR(p_lotenf);
  
    -- grava log de seguranca.
    pk_utilities.GeraLog(p_usuario, 'Desfez O.R.: ' || p_lotenf, p_lotenf,
                         'OR');
  end;

  procedure validarGeracaoContagem(p_idlotenf in number) is
    v_qtde                   number;
    v_precadastro_cg         configuracao.validarprecadastro%type;
    v_geraLotePorConferencia number;
  begin
    select count(idnotafiscal)
      into v_qtde
      from notafiscal
     where idlotenf = p_idlotenf;
  
    if v_qtde = 0 then
      v_msg := t_message('NÃO EXISTE NOTA FISCAL VINCULADA A ORDEM DE RECEBIMENTO. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_qtde
      from notafiscal nf
     where nf.idlotenf = p_idlotenf
       and nf.crossdocking = 'S';
  
    if v_qtde > 0 then
      v_msg := t_message('NÃO É PERMITIDO GERAR CONFERÊNCIA PARA OR DE CROSDOCKING. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(pd.idproduto)
      into v_qtde
      from notafiscal nf, nfdet nd, produtodepositante pd,
           informacaomatdep im
     where nf.idlotenf = p_idlotenf
       and nd.nf = nf.idnotafiscal
       and pd.identidade = nf.iddepositante
       and pd.idproduto = nd.idproduto
       and pd.rastrearinfoespecifica <> 2
       and im.identidade = pd.identidade
       and im.idproduto = pd.idproduto
       and nf.idinventario is null;
  
    if v_qtde > 0 then
      v_msg := t_message('A LIBERAÇÃO DA CONFERÊNCIA NÃO É PERMITIDA.' ||
                         chr(13) ||
                         'EXISTEM PRODUTOS COM INFORMAÇÃO ESPECÍFICA CADASTRADOS PARA ESSA ORDEM DE RECEBIMENTO.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(nd.idproduto)
      into v_qtde
      from notafiscal nf, nfdet nd, produtodepositante pd
     where nf.idlotenf = p_idlotenf
       and nd.nf = nf.idnotafiscal
       and pd.identidade = nf.iddepositante
       and pd.idproduto = nd.idproduto
       and nvl(pd.generico, 'N') = 'S';
  
    if v_qtde > 0 then
      v_msg := t_message('A LIBERAÇÃO DA CONFERÊNCIA NÃO É PERMITIDA.' ||
                         chr(13) ||
                         'EXISTEM PRODUTOS GENÉRICOS CADASTRADOS PARA ESSA ORDEM DE RECEBIMENTO.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(pd.idproduto)
      into v_qtde
      from notafiscal nf, nfdet nd, produtodepositante pd
     where nf.idlotenf = p_idlotenf
       and nd.nf = nf.idnotafiscal
       and pd.identidade = nf.iddepositante
       and pd.idproduto = nd.idproduto
       and nvl(pd.multivolume, 'N') = 'S';
  
    if v_qtde > 0 then
      v_msg := t_message('A LIBERAÇÃO DA CONFERÊNCIA NÃO É PERMITIDA.' ||
                         chr(13) ||
                         'EXISTEM PRODUTOS COM MULTI-VOLUMES CADASTRADOS PARA ESSA ORDEM DE RECEBIMENTO.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(s.idlotenf)
      into v_qtde
      from sumprodlote s, produto p, embalagem e
     where p.idproduto = s.idproduto
       and e.idproduto = s.idproduto
       and e.barra = s.barra
       and (e.precadastro = 'S' or p.precadastro = 'S')
       and s.idlotenf = p_idlotenf;
  
    select cg.validarprecadastro
      into v_precadastro_cg
      from configuracao cg;
  
    select tr.gerarloteporpalete
      into v_geraLotePorConferencia
      from lotenf ln, tiporecebimento tr
     where tr.idtiporecebimento = ln.idtiporecebimento
       and ln.idlotenf = p_idlotenf;
  
    if (v_qtde > 0 and v_precadastro_cg = 1) then
      v_msg := t_message('A LIBERAÇÃO DA CONFERÊNCIA NÃO É PERMITIDA.' ||
                         chr(13) ||
                         'ALGUM PRODUTO OU EMBALAGEM ESTÁ MARCADO COMO PRE CADASTRO E A CONFIGURAÇÃO GERAL DO SISTEMA VALIDA O PRE CADASTRO NA CONFERENCIA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (v_qtde > 0 and v_geraLotePorConferencia = 1) then
      v_msg := t_message('A LIBERAÇÃO DA CONFERÊNCIA NÃO É PERMITIDA.' ||
                         chr(13) ||
                         'ALGUM PRODUTO OU EMBALAGEM ESTÁ MARCADO COMO PRÉ CADASTRO E A ORDEM DE RECEBIMENTO ESTÁ PARAMETRIZADA PARA GERAR LOTE POR CONFERÊNCIA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  -- rotina responsavel por gerar e liberar a contagem da OR
  procedure gerarContagem
  (
    p_lotenf  in number,
    p_usuario in number
  ) is
  
    type t_conf is record(
      tiporecebimento         char(1),
      recebimentosegredado    number,
      idconferencia           number,
      gerarLotePorConferencia number);
  
    v_idcontagem number;
    r_conf       t_conf;
  
    function isOROS return boolean is
      v_idOS number;
    begin
      select os.idordemservico
        into v_idOS
        from ordemservico os
       where os.idlotenf = p_LoteNf
         and os.idosmae is null
         and os.tiposervico in ('I', 'E', 'D', 'J');
      if (v_idOS > 0) then
        return true;
      end if;
    exception
      when others then
        return false;
    end isOROS;
  
    procedure carregarDados is
    begin
    
      select tr.classificacao, a.confsegregadarecebimento,
             nvl(max(ce.idconferenciaentrada), 0) + 1 idconferencia,
             tr.gerarloteporpalete
        into r_conf.tiporecebimento, r_conf.recebimentosegredado,
             r_conf.idconferencia, r_conf.gerarLotePorConferencia
        from lotenf ln, tiporecebimento tr, armazem a, conferenciaentrada ce
       where ce.idlotenf(+) = ln.idlotenf
         and a.idarmazem = ln.idarmazem
         and tr.idtiporecebimento = ln.idtiporecebimento
         and ln.idlotenf = p_lotenf
       group by tr.classificacao, a.confsegregadarecebimento,
                tr.gerarloteporpalete;
    
    end carregarDados;
  
    procedure validacoes is
    begin
      validarOrdemServico(p_lotenf);
    
      validarGeracaoContagem(p_lotenf);
    
      if (isConferenciaAlocada(p_lotenf)) then
        v_msg := t_message('Ação não pode ser executada pois a OR é do Tipo de Recebimento de Conferência Alocada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validacoes;
  
    procedure criarContagemTotalBacklist is
    begin
      for c_confent in (select n.idproduto,
                               pk_produto.ret_codbarra_nao_precad(n.idproduto,
                                                                   1) barra,
                               nf.estado,
                               sum(decode(estado, 'N',
                                           bl.qtde * e.fatorconversao, 0)) qtdenormal,
                               sum(decode(estado, 'D',
                                           bl.qtde * e.fatorconversao, 0)) qtdedanificado,
                               sum(decode(estado, 'T',
                                           bl.qtde * e.fatorconversao, 0)) qtdevencido,
                               bl.loteindustria, bl.dtfabricacao,
                               bl.vencimento
                          from notafiscal nf, nfdet n, embalagem e,
                               produtodepositante pd, backlist bl
                         where nf.idlotenf = p_lotenf
                           and n.nf = nf.idnotafiscal
                           and e.idproduto = n.idproduto
                           and e.barra = n.barra
                           and pd.identidade = nf.iddepositante
                           and pd.idproduto = n.idproduto
                           and bl.idnfdet = n.idnfdet
                           and pd.naocriticabacklist = 0
                         group by nf.idlotenf, n.idproduto,
                                  pk_produto.ret_codbarra_nao_precad(n.idproduto,
                                                                      1),
                                  nf.estado, bl.loteindustria,
                                  bl.dtfabricacao, bl.vencimento)
      loop
        if (c_confent.qtdenormal > 0) then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtdenormal
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'N', 1,
                                                  c_confent.vencimento,
                                                  c_confent.loteindustria,
                                                  c_nao, 0, v_idcontagem, 1,
                                                  null, null, null,
                                                  c_confent.dtfabricacao);
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'N',
                                                c_confent.qtdenormal,
                                                c_confent.vencimento,
                                                c_confent.loteindustria,
                                                c_nao, 0, v_idcontagem, 1,
                                                null, null, null,
                                                c_confent.dtfabricacao);
          end if;
        end if;
      
        if c_confent.qtdedanificado > 0 then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtdedanificado
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'D', 1,
                                                  c_confent.vencimento,
                                                  c_confent.loteindustria,
                                                  c_nao, 0, v_idcontagem, 1,
                                                  null, null, null,
                                                  c_confent.dtfabricacao);
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'D',
                                                c_confent.qtdedanificado,
                                                c_confent.vencimento,
                                                c_confent.loteindustria,
                                                c_nao, 0, v_idcontagem, 1,
                                                null, null, null,
                                                c_confent.dtfabricacao);
          end if;
        end if;
      
        if c_confent.qtdevencido > 0 then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtdevencido
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'T', 1,
                                                  c_confent.vencimento,
                                                  c_confent.loteindustria,
                                                  c_nao, 0, v_idcontagem, 1,
                                                  null, null, null,
                                                  c_confent.dtfabricacao);
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'T',
                                                c_confent.qtdevencido,
                                                c_confent.vencimento,
                                                c_confent.loteindustria,
                                                c_nao, 0, v_idcontagem, 1,
                                                null, null, null,
                                                c_confent.dtfabricacao);
          end if;
        end if;
      end loop;
    end criarContagemTotalBacklist;
  
    procedure criarContagemTotal is
    begin
      -- gera a conferencia baseado nos itens enviados.
      insert into conferenciaentrada
        (idconferenciaentrada, idlotenf, data, idusuario)
      values
        (r_conf.idconferencia, p_lotenf, sysdate, p_usuario);
    
      criarContagemTotalBacklist;
    
      for c_confent in (select s.idproduto, s.barra,
                               (s.qtde -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'N'), 0)) qtde,
                               (s.qtdeavari -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'D'), 0)) qtdeavari,
                               (s.qtdevenc -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'T'), 0)) qtdevenc,
                               p.itemadicional
                          from sumprodlote s, produto p
                         where p.idproduto = s.idproduto
                           and s.idlotenf = p_lotenf)
      loop
        if c_confent.qtde > 0 then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtde
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'N', 1,
                                                  null, null, c_nao, 0,
                                                  v_idcontagem, 1,
                                                  c_confent.itemadicional,
                                                  null, null, null, null,
                                                  'S');
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'N',
                                                c_confent.qtde, null, null,
                                                c_nao, 0, v_idcontagem, 1,
                                                c_confent.itemadicional,
                                                null, null, null, null, 'S');
          end if;
        end if;
      
        if c_confent.qtdeavari > 0 then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtde
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'D', 1,
                                                  null, null, c_nao, 0,
                                                  v_idcontagem, 1,
                                                  c_confent.itemadicional,
                                                  null, null, null, null,
                                                  'S');
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'D',
                                                c_confent.qtdeavari, null,
                                                null, c_nao, 0, v_idcontagem,
                                                1, c_confent.itemadicional,
                                                null, null, null, null, 'S');
          end if;
        end if;
      
        if c_confent.qtdevenc > 0 then
          if (r_conf.tiporecebimento = 'E')
             and (r_conf.recebimentosegredado = 1) then
            for i in 1 .. c_confent.qtde
            loop
              pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                  r_conf.idconferencia,
                                                  c_confent.idproduto,
                                                  c_confent.barra, 'T', 1,
                                                  null, null, c_nao, 0,
                                                  v_idcontagem, 1,
                                                  c_confent.itemadicional,
                                                  null, null, null, null,
                                                  'S');
            end loop;
          else
            pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                                r_conf.idconferencia,
                                                c_confent.idproduto,
                                                c_confent.barra, 'T',
                                                c_confent.qtdevenc, null,
                                                null, c_nao, 0, v_idcontagem,
                                                1, c_confent.itemadicional,
                                                null, null, null, null, 'S');
          end if;
        end if;
      end loop;
    
      -- informa que a conf. foi gerada automatica.
      update conferenciaentradadet
         set automatico = 'S'
       where idconferenciaentrada = r_conf.idconferencia
         and idlotenf = p_lotenf;
    
      -- gera as ocorrencias;
      pk_confentrada.p_gera_ocorrencia(p_lotenf, r_conf.idconferencia,
                                       p_usuario, c_nao);
    
      update conferenciaentrada
         set finalizada = 'S',
             idusuario  = p_usuario,
             data       = sysdate
       where idlotenf = p_lotenf
         and idconferenciaentrada = r_conf.idconferencia;
    
    end criarContagemTotal;
  
    procedure marcarConferenciaAutomatica is
    begin
      update conferenciaentradadet
         set automatico = 'S'
       where idconferenciaentrada = r_conf.idconferencia
         and idcontagem = v_idcontagem
         and idlotenf = p_lotenf;
    end marcarConferenciaAutomatica;
  
    procedure criarContagemRestanteBacklist is
    begin
      for r_confent in (select n.idproduto,
                               pk_produto.ret_codbarra_nao_precad(n.idproduto,
                                                                   1) barra,
                               (sum(decode(estado, 'N',
                                            bl.qtde * e.fatorconversao, 0)) -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = nf.idlotenf
                                        and cd.idproduto = n.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'N'
                                        and cd.descrlote = bl.loteindustria
                                        and cd.datavencto = bl.vencimento
                                        and cd.datafabricacao =
                                            bl.dtfabricacao), 0)) qtdenormal,
                               (sum(decode(estado, 'D',
                                            bl.qtde * e.fatorconversao, 0)) -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = nf.idlotenf
                                        and cd.idproduto = n.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'D'
                                        and cd.descrlote = bl.loteindustria
                                        and cd.datavencto = bl.vencimento
                                        and cd.datafabricacao =
                                            bl.dtfabricacao), 0)) qtdedanificado,
                               (sum(decode(estado, 'T',
                                            bl.qtde * e.fatorconversao, 0)) -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = nf.idlotenf
                                        and cd.idproduto = n.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'T'
                                        and cd.descrlote = bl.loteindustria
                                        and cd.datavencto = bl.vencimento
                                        and cd.datafabricacao =
                                            bl.dtfabricacao), 0)) qtdevencido,
                               bl.loteindustria, bl.dtfabricacao,
                               bl.vencimento
                          from notafiscal nf, nfdet n, embalagem e,
                               produtodepositante pd, backlist bl
                         where nf.idlotenf = p_lotenf
                           and n.nf = nf.idnotafiscal
                           and e.idproduto = n.idproduto
                           and e.barra = n.barra
                           and pd.identidade = nf.iddepositante
                           and pd.idproduto = n.idproduto
                           and bl.idnfdet = n.idnfdet
                           and pd.naocriticabacklist = 0
                         group by nf.idlotenf, n.idproduto,
                                  pk_produto.ret_codbarra_nao_precad(n.idproduto,
                                                                      1),
                                  bl.loteindustria, bl.dtfabricacao,
                                  bl.vencimento)
      loop
        if r_confent.qtdenormal > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'N',
                                              r_confent.qtdenormal,
                                              r_confent.vencimento,
                                              r_confent.loteindustria, 'N',
                                              0, v_idcontagem, 1, null, null,
                                              null, r_confent.dtfabricacao);
        
          marcarConferenciaAutomatica;
        end if;
      
        if r_confent.qtdedanificado > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'D',
                                              r_confent.qtdedanificado,
                                              r_confent.vencimento,
                                              r_confent.loteindustria, 'N',
                                              0, v_idcontagem, 1, null, null,
                                              null, r_confent.dtfabricacao);
        
          marcarConferenciaAutomatica;
        end if;
      
        if r_confent.qtdevencido > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'T',
                                              r_confent.qtdevencido,
                                              r_confent.vencimento,
                                              r_confent.loteindustria, 'N',
                                              0, v_idcontagem, 1, null, null,
                                              null, r_confent.dtfabricacao);
        
          marcarConferenciaAutomatica;
        end if;
      end loop;
    end criarContagemRestanteBacklist;
  
    procedure criarContagemRestante is
    begin
      begin
        select ce.idconferenciaentrada
          into r_conf.idconferencia
          from conferenciaentrada ce
         where ce.idlotenf = p_lotenf;
      exception
        when no_data_found then
          insert into conferenciaentrada
            (idconferenciaentrada, idlotenf, data, idusuario)
          values
            (r_conf.idconferencia, p_lotenf, sysdate, p_usuario);
      end;
    
      criarContagemRestanteBacklist;
    
      for r_confent in (select s.idproduto, s.barra,
                               (s.qtde -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'N'), 0)) qtdeNormalRest,
                               (s.qtdeavari -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'D'), 0)) qtdeRestAvaria,
                               (s.qtdevenc -
                                nvl((select sum(cd.qtde * e.fatorconversao)
                                       from conferenciaentradadet cd,
                                            embalagem e
                                      where cd.idlotenf = s.idlotenf
                                        and cd.idproduto = s.idproduto
                                        and cd.ignorada = 'N'
                                        and cd.idproduto = e.idproduto
                                        and cd.barra = e.barra
                                        and cd.estado = 'T'), 0)) qtdeRestVenc,
                               p.itemadicional
                          from sumprodlote s, produto p
                         where p.idproduto = s.idproduto
                           and s.idlotenf = p_lotenf)
      loop
        if r_confent.qtdeNormalRest > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'N',
                                              r_confent.qtdeNormalRest, null,
                                              null, 'N', 0, v_idcontagem, 1,
                                              r_confent.itemadicional, null,
                                              null, null, null, 'S');
        
          marcarConferenciaAutomatica;
        end if;
      
        if r_confent.qtdeRestAvaria > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'D',
                                              r_confent.qtdeRestAvaria, null,
                                              null, 'N', 0, v_idcontagem, 1,
                                              r_confent.itemadicional, null,
                                              null, null, null, 'S');
        
          marcarConferenciaAutomatica;
        end if;
      
        if r_confent.qtdeRestVenc > 0 then
          pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                              r_conf.idconferencia,
                                              r_confent.idproduto,
                                              r_confent.barra, 'T',
                                              r_confent.qtdeRestVenc, null,
                                              null, 'N', 0, v_idcontagem, 1,
                                              r_confent.itemadicional, null,
                                              null, null, null, 'S');
        
          marcarConferenciaAutomatica;
        end if;
      end loop;
    
      pk_confentrada.finalizarConferenciaOR(p_lotenf, p_usuario);
    
    end criarContagemRestante;
  
    procedure criarContagemOS is
    begin
      -- gera a conferencia baseado nos itens separados.
      insert into conferenciaentrada
        (idconferenciaentrada, idlotenf, data, idusuario)
      values
        (r_conf.idconferencia, p_lotenf, sysdate, p_usuario);
    
      for c_itens in (select esp.idlotenf, esp.idproduto, esp.loteindustria,
                             esp.dtvenc, esp.qtdesperada, esp.qtdconferida
                        from (select x.idlotenf, x.idproduto, x.loteindustria,
                                      x.dtvenc, sum(quantidade) qtdEsperada,
                                      0 qtdConferida
                                 from (select distinct os.idlotenf,
                                                        mv.idlote idloteKit,
                                                        mv.idlote idloteKit,
                                                        k.idproduto,
                                                        (select max(lt.descr)
                                                            from lote lt,
                                                                 complotekit cpk
                                                           where cpk.idlotekit =
                                                                 mv.idlote
                                                             and lt.idlote =
                                                                 cpk.idlotecomponente
                                                             and lt.idproduto =
                                                                 k.idproduto) loteindustria,
                                                        (select max(lt.dtvenc)
                                                            from lote lt,
                                                                 complotekit cpk
                                                           where cpk.idlotekit =
                                                                 mv.idlote
                                                             and lt.idlote =
                                                                 cpk.idlotecomponente
                                                             and lt.idproduto =
                                                                 k.idproduto) dtvenc,
                                                        (mv.quantidade *
                                                         (k.qtde *
                                                         e.fatorconversao)) quantidade
                                          from movimentacao mv, lote ltk,
                                               kitproduto k, embalagem e,
                                               ordemservico os
                                         where mv.idonda = os.idromaneio
                                           and os.idlotenf = p_lotenf
                                           and os.idosmae is null
                                           and mv.etapa = 1
                                           and mv.idlote = ltk.idlote
                                           and ltk.idproduto = k.idprodutokit
                                           and k.barra = e.barra
                                           and os.tiposervico in ('J', 'D')
                                           and (exists
                                                (select 1
                                                   from origemlote orl,
                                                        notafiscal nf,
                                                        ordemservico os
                                                  where orl.idnotafiscal =
                                                        nf.idnotafiscal
                                                    and nf.idlotenf = os.idlotenf
                                                    and os.idosmae is null
                                                    and os.tiposervico in
                                                        ('K', 'I')
                                                    and orl.idlote = mv.idlote) or
                                                (not exists
                                                 (select 1
                                                    from origemlote orl
                                                   where orl.idlote = mv.idlote) and
                                                 exists
                                                 (select 1
                                                    from origemlote orl,
                                                         notafiscal nf,
                                                         ordemservico os
                                                   where orl.idnotafiscal =
                                                         nf.idnotafiscal
                                                     and nf.idlotenf = os.idlotenf
                                                     and os.idosmae is null
                                                     and os.tiposervico in
                                                         ('K', 'I')
                                                     and orl.idlote =
                                                         pk_lote.getIdLoteAnterior(mv.idlote))))
                                        
                                        union all
                                        
                                        select distinct os.idlotenf, cp.idlotekit,
                                                        cp.idlotekit,
                                                        ltc.idproduto,
                                                        ltc.descr loteindustria,
                                                        (select max(lt.dtvenc)
                                                            from lote lt
                                                           where lt.idproduto =
                                                                 ltc.idproduto
                                                             and lt.dtvenc =
                                                                 ltc.dtvenc
                                                             and lt.descr =
                                                                 ltc.descr) dtvenc,
                                                        (mv.quantidade *
                                                         nvl((select rcl.qtdeunit
                                                                from receitaestojamentolote rcl
                                                               where rcl.idlote =
                                                                     cp.idlotekit
                                                                 and rcl.idprodutocomp =
                                                                     ltc.idproduto
                                                                 and rcl.idos =
                                                                     (select max(r1.idos)
                                                                        from receitaestojamentolote r1
                                                                       where r1.idlote =
                                                                             rcl.idlote
                                                                         and r1.idprodutocomp =
                                                                             rcl.idprodutocomp)),
                                                              1)) qtuantidade
                                          from movimentacao mv, complotekit cp,
                                               lote ltc, ordemservico os
                                         where mv.idlote = cp.idlotekit
                                           and cp.idlotecomponente = ltc.idlote
                                           and mv.idonda = os.idromaneio
                                           and os.idlotenf = p_lotenf
                                           and os.idosmae is null
                                           and os.tiposervico in ('J', 'D')
                                           and nvl(ltc.descr, 'NI') =
                                               (select max(nvl(lta.descr, 'NI'))
                                                  from lote lta, complotekit cpa
                                                 where lta.idlote =
                                                       cpa.idlotecomponente
                                                   and cpa.idlotekit =
                                                       cp.idlotekit
                                                   and lta.idproduto =
                                                       ltc.idproduto)
                                           and (exists
                                                (select 1
                                                   from origemlote orl,
                                                        notafiscal nf,
                                                        ordemservico os
                                                  where orl.idnotafiscal =
                                                        nf.idnotafiscal
                                                    and nf.idlotenf = os.idlotenf
                                                    and os.idosmae is null
                                                    and os.tiposervico in
                                                        ('E', 'J', 'D')
                                                    and orl.idlote = mv.idlote) or
                                                (not exists
                                                 (select 1
                                                    from origemlote orl
                                                   where orl.idlote = mv.idlote) and
                                                 exists
                                                 (select 1
                                                    from origemlote orl,
                                                         notafiscal nf,
                                                         ordemservico os
                                                   where orl.idnotafiscal =
                                                         nf.idnotafiscal
                                                     and nf.idlotenf = os.idlotenf
                                                     and os.idosmae is null
                                                     and os.tiposervico in
                                                         ('E', 'J', 'D')
                                                     and orl.idlote =
                                                         pk_lote.getIdLoteAnterior(mv.idlote))))
                                        
                                        union all
                                        select y.idlotenf, y.idlotekit,
                                               y.idlotekit, y.idproduto,
                                               y.loteindustria, y.dtvenc,
                                               sum(y.qtuantidade) as qtuantidade
                                          from (select distinct mv.idlote,
                                                                 os.idlotenf,
                                                                 cp.idlotekit,
                                                                 ltc.idproduto,
                                                                 ltc.descr loteindustria,
                                                                 (select max(lt.dtvenc)
                                                                     from lote lt
                                                                    where lt.idproduto =
                                                                          ltc.idproduto
                                                                      and lt.dtvenc =
                                                                          ltc.dtvenc
                                                                      and lt.descr =
                                                                          ltc.descr) dtvenc,
                                                                 (mv.quantidade *
                                                                  nvl((select rcl.qtdeunit
                                                                         from receitaestojamentolote rcl
                                                                        where rcl.idlote =
                                                                              cp.idlotekit
                                                                          and rcl.idprodutocomp =
                                                                              ltc.idproduto
                                                                          and rcl.idos =
                                                                              (select max(r1.idos)
                                                                                 from receitaestojamentolote r1
                                                                                where r1.idlote =
                                                                                      rcl.idlote
                                                                                  and r1.idprodutocomp =
                                                                                      rcl.idprodutocomp)),
                                                                       1)) qtuantidade
                                                   from movimentacao mv,
                                                        complotekit cp, lote ltc,
                                                        ordemservico os
                                                  where cp.idlotekit =
                                                        pk_lote.getIdLoteAnterior(mv.idlote)
                                                    and cp.idlotecomponente =
                                                        ltc.idlote
                                                    and mv.idonda = os.idromaneio
                                                    and os.idlotenf = p_lotenf
                                                    and os.idosmae is null
                                                    and os.tiposervico in
                                                        ('J', 'D')
                                                    and not exists
                                                  (select 1
                                                           from complotekit ck
                                                          where ck.idlotekit =
                                                                mv.idlote)
                                                    and (exists
                                                         (select 1
                                                            from origemlote orl,
                                                                 notafiscal nf,
                                                                 ordemservico os
                                                           where orl.idnotafiscal =
                                                                 nf.idnotafiscal
                                                             and nf.idlotenf =
                                                                 os.idlotenf
                                                             and os.idosmae is null
                                                             and os.tiposervico in
                                                                 ('E', 'J', 'D')
                                                             and orl.idlote =
                                                                 mv.idlote) or
                                                         (not exists (select 1
                                                                        from origemlote orl
                                                                       where orl.idlote =
                                                                             mv.idlote) and
                                                          exists
                                                          (select 1
                                                             from origemlote orl,
                                                                  notafiscal nf,
                                                                  ordemservico os
                                                            where orl.idnotafiscal =
                                                                  nf.idnotafiscal
                                                              and nf.idlotenf =
                                                                  os.idlotenf
                                                              and os.idosmae is null
                                                              and os.tiposervico in
                                                                  ('E', 'J', 'D')
                                                              and orl.idlote =
                                                                  pk_lote.getIdLoteAnterior(mv.idlote))))) y
                                         group by y.idlotenf, y.idlotekit,
                                                  y.idproduto, y.loteindustria,
                                                  y.dtvenc) x
                                where exists
                                (select 1
                                         from ordemservico os
                                        where os.idosmae is null
                                          and os.tiposervico in ('J', 'D', 'E')
                                          and os.idlotenf = x.idlotenf)
                                group by x.idlotenf, x.idproduto,
                                         x.loteindustria, x.dtvenc
                               
                               union all
                               
                               select os.idlotenf, p.idproduto,
                                      pk_lote.gerarloteIndPorOS(os.idordemservico) loteindustria,
                                      (select min(lt.dtvenc)
                                          from movimentacao m, lote lt
                                         where m.idonda = os.idromaneio
                                           and m.idlote = lt.idlote) dtvenc,
                                      os.qtde, 0 qtdConferida
                                 from ordemservico os, produto p
                                where os.idlotenf = p_lotenf
                                  and os.idproduto = p.idproduto
                                  and os.tiposervico in ('E', 'I')
                                  and os.idosmae is null
                                order by idlotenf, idproduto, loteindustria,
                                         dtvenc) esp)
      loop
        pk_confentrada.p_gravar_conferencia(p_usuario, p_lotenf,
                                            r_conf.idconferencia,
                                            c_itens.idproduto,
                                            pk_produto.RetornarCodBarraMenorFator(c_itens.idproduto),
                                            'N', c_itens.qtdesperada,
                                            c_itens.dtvenc,
                                            c_itens.loteindustria, 'N', 0,
                                            v_idcontagem, 1, null, null,
                                            null, null, null, 'S');
      end loop;
    
      -- informa que a conf. foi gerada automatica.
      update conferenciaentradadet
         set automatico = 'S'
       where idconferenciaentrada = r_conf.idconferencia
         and idlotenf = p_lotenf;
    
      -- gera as ocorrencias;
      pk_confentrada.p_gera_ocorrencia(p_lotenf, r_conf.idconferencia,
                                       p_usuario, c_nao);
    end criarContagemOS;
  
  begin
  
    carregarDados;
  
    validacoes;
  
    Atualizar_Produtos_OR(p_lotenf, 'N');
  
    if (isOROS) then
      criarContagemOS;
    else
      if (r_conf.gerarLotePorConferencia = 1) then
        criarContagemRestante;
      else
        criarContagemTotal;
      end if;
    end if;
    pk_utilities.GeraLog(p_usuario,
                         'LIBEROU CONFERENCIA PARA A OR ' || p_lotenf,
                         p_lotenf, 'OR');
  end gerarContagem;

  /*Rotina que atualiza a tabela Sumprodlote da OR*/
  procedure Atualizar_Produtos_OR
  (
    p_lotenf in number,
    p_commit in string
  ) is
  
    /*Atenção
    O select abaixo deve ser basear em uma regra de negócio importante 
    relacionada a conferencia de entrada:
    Em casos de recontagem somente é necessário recontar o produto / estado da OR,
    ou seja, a última conferencia considerada é para o produto e estado da OR.
    Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
    e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias 
    são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
    produto no estado Normal novamente.*/
    cursor c_prodgen
    (
      p_or          in number,
      p_produto     in number,
      p_depositante in number,
      p_estado      in lote.estado%type
    ) is
      select c.idproduto, c.qtdeconf, nvl(sl.qtde, 0) qtde,
             c.qtdeconf - nvl(sl.qtde, 0) dif
        from (select cd.idproduto, sum(cd.qtde) qtdeconf
                 from conferenciaentradadet cd,
                      (select ced.idlotenf, ced.idproduto, ced.estado,
                               max(ced.idconferenciaentrada) idconferenciaentrada
                          from conferenciaentradadet ced
                         where nvl(ced.ignorada, 'N') = 'N'
                           and ced.idlotenf = p_or
                         group by ced.idlotenf, ced.idproduto, ced.estado) ml,
                      produtodepositante pd
                where cd.idlotenf = p_or
                  and ml.idlotenf = cd.idlotenf
                  and ml.idproduto = cd.idproduto
                  and ml.idconferenciaentrada = cd.idconferenciaentrada
                  and ml.estado = cd.estado
                  and pd.idproduto = cd.idproduto
                  and pd.idprodutogenerico = p_produto
                  and pd.identidadegenerico = p_depositante
                group by cd.idproduto) c,
             (select sl.idproduto,
                      sum(decode(p_estado, 'N', sl.qtde, 'D', sl.qtdeavari,
                                  'T', sl.qtdevenc)) qtde
                 from sumprodlote sl
                where sl.idlotenf = p_or
                group by sl.idproduto) sl
       where sl.idproduto(+) = c.idproduto
         and c.qtdeconf - nvl(sl.qtde, 0) > 0;
  
    v_qtdeprodutogen number;
    v_lotenf         lotenf%rowtype;
    r_prodgen        c_prodgen%rowtype;
    v_qtde           number;
  begin
    v_lotenf := CarregarOR(p_lotenf);
  
    if (v_lotenf.status = 'N')
       and ((v_lotenf.flaglibnf <> 2) or (v_lotenf.recontagem = 'S')) then
      -- apaga o sumprodlote
      delete from sumprodlote
       where idlotenf = p_lotenf;
      -- gera o sumprodlote novamente.
      -- Efetuando a checagem se existem produtos genéricos na nota
      -- e efetuando o rateio das quantidades na SUMPRODLOTE
      v_qtdeprodutogen := 0;
      for c_produtogen in (select nf.iddepositante, n.idproduto, estado,
                                  sum(n.qtde * e.fatorconversao) qtdegennf
                             from notafiscal nf, nfdet n, produto p,
                                  embalagem e, produtodepositante pd
                            where nf.idlotenf = p_lotenf
                              and n.nf = nf.idnotafiscal
                              and p.idproduto = n.idproduto
                              and p.kitexpexplodida = 'N'
                              and e.idproduto = n.idproduto
                              and e.barra = n.barra
                              and pd.identidade = nf.iddepositante
                              and pd.idproduto = n.idproduto
                              and pd.generico = 'S'
                            group by nf.iddepositante, n.idproduto, estado,
                                     nvl(pd.generico, 'N')
                           union
                           select nf.iddepositante, kp.idproduto, estado,
                                  sum(n.qtde * kp.qtde * e.fatorconversao) qtdegennf
                             from notafiscal nf, nfdet n, produto p,
                                  embalagem e, produtodepositante pd,
                                  kitproduto kp
                            where nf.idlotenf = p_lotenf
                              and n.nf = nf.idnotafiscal
                              and p.idproduto = n.idproduto
                              and p.kitexpexplodida = 'S'
                              and kp.idprodutokit = p.idproduto
                              and e.idproduto = kp.idproduto
                              and e.barra = kp.barra
                              and pd.identidade = nf.iddepositante
                              and pd.idproduto = n.idproduto
                              and pd.generico = 'S'
                            group by nf.iddepositante, kp.idproduto, estado,
                                     nvl(pd.generico, 'N'))
      loop
        v_qtdeprodutogen := c_produtogen.qtdegennf;
      
        if c_prodgen%isopen then
          close c_prodgen;
        end if;
        open c_prodgen(p_lotenf, c_produtogen.idproduto,
                       c_produtogen.iddepositante, c_produtogen.estado);
        fetch c_prodgen
          into r_prodgen;
        while (v_qtdeprodutogen > 0)
              and (c_prodgen%found)
        loop
          if nvl(r_prodgen.dif, 0) > v_qtdeprodutogen then
            v_qtde := v_qtdeprodutogen;
          else
            v_qtde := r_prodgen.dif;
          end if;
        
          begin
            insert into sumprodlote
              (idlotenf, idproduto, barra, qtde, qtdeavari, qtdevenc,
               qtdconf, qtdedev, qtdeausente, qtdelib)
            values
              (p_lotenf, r_prodgen.idproduto,
               pk_produto.ret_codbarra(r_prodgen.idproduto, 1),
               decode(c_produtogen.estado, 'N', v_qtde, 0),
               decode(c_produtogen.estado, 'D', v_qtde, 0),
               decode(c_produtogen.estado, 'T', v_qtde, 0), 0, 0, 0, 0);
          exception
            when dup_val_on_index then
              update sumprodlote
                 set qtde      = qtde +
                                 decode(c_produtogen.estado, 'N', v_qtde, 0),
                     qtdeavari = qtdeavari +
                                 decode(c_produtogen.estado, 'D', v_qtde, 0),
                     qtdevenc  = qtdevenc +
                                 decode(c_produtogen.estado, 'T', v_qtde, 0)
               where idlotenf = p_lotenf
                 and idproduto = r_prodgen.idproduto;
          end;
          v_qtdeprodutogen := v_qtdeprodutogen - v_qtde;
          fetch c_prodgen
            into r_prodgen;
        end loop;
      
        close c_prodgen;
      
        -- Verificando se sobrou quantidade na nota fiscal do produto generico
        -- que não teve uma correspondência em produto específico
      
        if v_qtdeprodutogen > 0 then
          begin
            insert into sumprodlote
              (idlotenf, idproduto, barra, qtde, qtdeavari, qtdevenc,
               qtdconf, qtdedev, qtdeausente, qtdelib)
            values
              (p_lotenf, c_produtogen.idproduto,
               pk_produto.ret_codbarra(c_produtogen.idproduto, 1),
               decode(c_produtogen.estado, 'N', v_qtdeprodutogen, 0),
               decode(c_produtogen.estado, 'D', v_qtdeprodutogen, 0),
               decode(c_produtogen.estado, 'T', v_qtdeprodutogen, 0), 0, 0,
               0, 0);
          exception
            when dup_val_on_index then
              update sumprodlote
                 set qtde      = qtde + decode(c_produtogen.estado, 'N',
                                               v_qtdeprodutogen, 0),
                     qtdeavari = qtdeavari +
                                 decode(c_produtogen.estado, 'D',
                                        v_qtdeprodutogen, 0),
                     qtdevenc  = qtdevenc +
                                 decode(c_produtogen.estado, 'T',
                                        v_qtdeprodutogen, 0)
               where idlotenf = p_lotenf
                 and idproduto = r_prodgen.idproduto;
          end;
        
        end if;
      end loop;
    
      -- Inserindo produtos especificos na SUMPRODLOTE
      for c_sp in (select nf.idlotenf, n.idproduto,
                          pk_produto.ret_codbarra_nao_precad(n.idproduto, 1) barra,
                          sum(decode(estado, 'N', n.qtde * e.fatorconversao,
                                      0)) normal,
                          sum(decode(estado, 'D', n.qtde * e.fatorconversao,
                                      0)) danificado,
                          sum(decode(estado, 'T', n.qtde * e.fatorconversao,
                                      0)) truncado
                     from notafiscal nf, nfdet n, produto p, embalagem e,
                          produtodepositante pd
                    where nf.idlotenf = p_lotenf
                      and n.nf = nf.idnotafiscal
                      and p.idproduto = n.idproduto
                      and p.kitexpexplodida = 'N'
                      and e.idproduto = n.idproduto
                      and e.barra = n.barra
                      and pd.identidade = nf.iddepositante
                      and pd.idproduto = n.idproduto
                      and nvl(pd.generico, 'N') = c_nao
                    group by nf.idlotenf, n.idproduto,
                             pk_produto.ret_codbarra_nao_precad(n.idproduto,
                                                                 1)
                   union
                   select nf.idlotenf, kp.idproduto,
                          pk_produto.ret_codbarra_nao_precad(kp.idproduto, 1) barra,
                          sum(decode(estado, 'N',
                                      (n.qtde * kp.qtde * e.fatorconversao), 0)) normal,
                          sum(decode(estado, 'D',
                                      (n.qtde * kp.qtde * e.fatorconversao), 0)) danificado,
                          sum(decode(estado, 'T',
                                      (n.qtde * kp.qtde * e.fatorconversao), 0)) truncado
                     from notafiscal nf, nfdet n, produto p, embalagem e,
                          produtodepositante pd, kitproduto kp
                    where nf.idlotenf = p_lotenf
                      and n.nf = nf.idnotafiscal
                      and p.idproduto = n.idproduto
                      and p.kitexpexplodida = 'S'
                      and kp.idprodutokit = p.idproduto
                      and e.idproduto = kp.idproduto
                      and e.barra = kp.barra
                      and pd.identidade = nf.iddepositante
                      and pd.idproduto = n.idproduto
                      and nvl(pd.generico, 'N') = c_nao
                    group by nf.idlotenf, kp.idproduto,
                             pk_produto.ret_codbarra_nao_precad(kp.idproduto,
                                                                 1))
      loop
        begin
          insert into sumprodlote
            (idlotenf, idproduto, barra, qtde, qtdeavari, qtdevenc, qtdconf,
             qtdedev, qtdeausente, qtdelib)
          values
            (c_sp.idlotenf, c_sp.idproduto, c_sp.barra, c_sp.normal,
             c_sp.danificado, c_sp.truncado, 0, 0, 0, 0);
        exception
          when dup_val_on_index then
            update sumprodlote
               set qtde      = qtde + c_sp.normal,
                   qtdeavari = qtdeavari + c_sp.danificado,
                   qtdevenc  = qtdevenc + c_sp.truncado
             where idlotenf = c_sp.idlotenf
               and idproduto = c_sp.idproduto
               and barra = c_sp.barra;
        end;
      end loop;
    
      if (p_commit = c_sim) then
        commit;
      end if;
    elsif v_lotenf.status = 'P' then
      v_msg := t_message('OR ja processada.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    elsif v_lotenf.flaglibnf = 2 then
      v_msg := t_message('OR liberada na conferencia.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    else
      v_msg := t_message('OR Nao encontada.' || chr(13) ||
                         'Operacao cancelada.');
      raise_application_error(-20100, v_msg.formatMessage);
    end if;
  end;

  /*
   * Cadastra endereco de picking em funcao da OR
  */
  procedure gerar_picking
  (
    p_lotenf  in number,
    p_usuario in number,
    p_lado    in string := '%',
    p_inicio  in string := '00000000',
    p_fim     in string := 'ZZZZZZZZ'
  ) is
  
    -- Tipo Picking
    C_MISTO    constant number := 0;
    C_UNIDADES constant number := 1;
    C_CAIXAS   constant number := 2;
  
    C_PRODDEP_MISTO constant number := 0;
  
    cursor c_prod_pk(p_lotenf in number) is
      select rownum, sp.idlotenf, sp.idproduto, p.codigointerno codprod,
             p.descr produto, e.razaosocial depositante,
             ln.identidade iddepositante, pd.tipopicking
        from sumprodlote sp, lotenf ln, entidade e, depositante d, produto p,
             produtodepositante pd
       where p.idproduto = sp.idproduto
         and d.usapicking = 'S'
         and d.identidade = e.identidade
         and e.identidade = ln.identidade
         and ln.idlotenf = sp.idlotenf
         and sp.idlotenf = p_lotenf
         and pd.identidade = d.identidade
         and pd.idproduto = p.idproduto;
  
    cursor c_pick
    (
      p_depositante in number,
      p_idproduto   in number,
      p_lado        string,
      p_inicio      string,
      p_fim         string,
      p_tipopicking number
    ) is
      select l.idarmazem, l.idlocal, s.tipopermitirpickingsetor
        from setor s, local l
       where (l.idarmazem, l.idlocal) not in
             (select idarmazem, idlocal
                from produtolocal pl
               where pl.identidade = p_depositante)
         and l.picking = 'S'
         and nvl(l.ativo, 'N') = 'S'
         and nvl(l.buffer, 'N') = 'N'
         and l.idsetor = s.idsetor
         and s.tipopermitirpickingsetor = p_tipopicking
         and (s.idsetor, l.idarmazem) in
             (select sd.idsetor, lnf.idarmazem
                from setordepositante sd, setorrecebimento sr,
                     setorproduto sp, lotenf lnf
               where sd.iddepositante = p_depositante
                 and lnf.idlotenf = p_lotenf
                 and sp.idproduto = p_idproduto
                 and sd.idsetor = sr.idsetor
                 and sr.idtiporecebimento = lnf.idtiporecebimento
                 and sp.idsetor = sd.idsetor)
         and decode(mod(l.predio, 2), 1, 'I', 'P') like
             nvl(p_lado, decode(mod(l.predio, 2), 1, 'I', 'P'))
         and l.idlocal between nvl(p_inicio, l.idlocal) and
             nvl(p_fim, l.idlocal)
       order by l.idlocal;
  
    r_prod_pk      c_prod_pk%rowtype;
    r_pick         c_pick%rowtype;
    v_count_prodpk number;
    v_count_prod   number;
  
    type t_dadosproduto is record(
      codprod varchar2(60),
      produto varchar2(120));
  
    r_dadosproduto t_dadosproduto;
  
    procedure carregaInformacoesProduto(p_idproduto number) is
    begin
      select codigointerno, descr
        into r_dadosproduto.codprod, r_dadosproduto.produto
        from produto
       where idproduto = p_idproduto;
    end carregaInformacoesProduto;
  
    function isProdutoSemPicking
    (
      p_lotenf        in number,
      p_iddepositante number,
      p_idproduto     number
    ) return boolean is
      v_PickingCadastrado number;
    begin
      select count(1)
        into v_PickingCadastrado
        from sumprodlote sp, lotenf ln, depositante d, produto p
       where p.idproduto = sp.idproduto
         and d.usapicking = 'S'
         and d.identidade = ln.identidade
         and (sp.idproduto, ln.idarmazem) not in
             (select distinct idproduto, idarmazem
                from produtolocal pl
               where pl.identidade = ln.identidade)
         and ln.idlotenf = sp.idlotenf
         and ln.idlotenf = p_lotenf
         and d.identidade = p_iddepositante
         and p.idproduto = p_idproduto;
    
      return v_PickingCadastrado = 1;
    end;
  
  begin
  
    if isConferenciaAlocada(p_lotenf) then
      v_msg := t_message('Ação não pode ser executada pois a OR é do Tipo de Recebimento de Conferência Alocada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- verifica se existe produto sem picking para ser atualizado.
    v_count_prodpk := 0;
    v_count_prod   := 0;
  
    if c_prod_pk%isopen then
      close c_prod_pk;
    end if;
  
    open c_prod_pk(p_lotenf);
  
    fetch c_prod_pk
      into r_prod_pk;
  
    -- verifica o total de registros retornados.
    while c_prod_pk%found
    loop
      v_count_prodpk := v_count_prodpk + 1;
      fetch c_prod_pk
        into r_prod_pk;
    end loop;
  
    close c_prod_pk;
    open c_prod_pk(p_lotenf);
    fetch c_prod_pk
      into r_prod_pk;
  
    if c_prod_pk%notfound then
      return;
    end if;
  
    while c_prod_pk%found
    loop
    
      -- pega os pickings disponiveis dentro do setor do depositante para o tipo de recebimento da OR.
      if c_pick%isopen then
        close c_pick;
      end if;
    
      carregaInformacoesProduto(r_prod_pk.idproduto);
    
      if (isProdutoSemPicking(p_lotenf, r_prod_pk.iddepositante,
                              r_prod_pk.idproduto)) then
      
        if (r_prod_pk.tipopicking = C_PRODDEP_MISTO) then
          open c_pick(r_prod_pk.iddepositante, r_prod_pk.idproduto, p_lado,
                      p_inicio, p_fim, C_MISTO);
          fetch c_pick
            into r_pick;
        
          if c_pick%notfound then
            v_msg := t_message('DEPOSITANTE NAO TEM ENDERECO DE PICKING DISPONIVEL DEFINIDO PARA O SETOR DO PRODUTO {0}-{1}.');
            v_msg.addParam(r_dadosproduto.codprod);
            v_msg.addParam(r_dadosproduto.produto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          while c_pick%found
          loop
            v_count_prod := v_count_prod + 1;
            fetch c_pick
              into r_pick;
          end loop;
          close c_pick;
        
          if v_count_prod <= v_count_prodpk then
            v_msg := t_message('QTDE DE PICKINGS DISPONIVEIS INSUFICIENTES PARA OS PRODUTOS DA OR: {0}');
            v_msg.addParam(p_lotenf);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          open c_pick(r_prod_pk.iddepositante, r_prod_pk.idproduto, p_lado,
                      p_inicio, p_fim, C_MISTO);
          fetch c_pick
            into r_pick;
        
          -- Insere o endereco de picking do setor 0 - Misto 
          pk_armazem.criarPickingProduto(r_pick.idarmazem, r_pick.idlocal,
                                         r_prod_pk.iddepositante,
                                         r_prod_pk.idproduto);
        
          pk_utilities.GeraLog(p_usuario,
                               'CADASTROU O PICKING AUTOMATICO A PARTIR DA OR: ' ||
                                P_LOTENF || ' PARA O PRODUTO: ' ||
                                R_PROD_PK.CODPROD || '-' ||
                                R_PROD_PK.PRODUTO || ' E DEP.:' ||
                                R_PROD_PK.DEPOSITANTE, P_LOTENF, 'CA');
        
        else
        
          -- Endereco de Picking com Setor do Tipo Unidades                      
          open c_pick(r_prod_pk.iddepositante, r_prod_pk.idproduto, p_lado,
                      p_inicio, p_fim, C_UNIDADES);
          fetch c_pick
            into r_pick;
        
          if c_pick%notfound then
            v_msg := t_message('DEPOSITANTE NAO TEM ENDERECO DE PICKING COM SETOR UNIDADES DISPONIVEL DEFINIDO PARA O SETOR DO PRODUTO {0}-{1}.');
            v_msg.addParam(r_dadosproduto.codprod);
            v_msg.addParam(r_dadosproduto.produto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          -- insere o endereco de picking do setor 1 - Unidades
          pk_armazem.criarPickingProduto(r_pick.idarmazem, r_pick.idlocal,
                                         r_prod_pk.iddepositante,
                                         r_prod_pk.idproduto);
        
          pk_utilities.GeraLog(p_usuario,
                               'CADASTROU O PICKING AUTOMATICO A PARTIR DA OR: ' ||
                                P_LOTENF || ' PARA O PRODUTO: ' ||
                                R_PROD_PK.CODPROD || '-' ||
                                R_PROD_PK.PRODUTO || ' E DEP.:' ||
                                R_PROD_PK.DEPOSITANTE, P_LOTENF, 'CA');
        
          -- Endereco de Picking com Setor do Tipo Caixas
          close c_pick;
          open c_pick(r_prod_pk.iddepositante, r_prod_pk.idproduto, p_lado,
                      p_inicio, p_fim, C_CAIXAS);
          fetch c_pick
            into r_pick;
        
          if c_pick%notfound then
            v_msg := t_message('DEPOSITANTE NAO TEM ENDERECO DE PICKING COM SETOR CAIXAS DISPONIVEL DEFINIDO PARA O SETOR DO PRODUTO {0}-{1}.');
            v_msg.addParam(r_dadosproduto.codprod);
            v_msg.addParam(r_dadosproduto.produto);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
          -- insere o endereco de picking do setor do Tipo 2-Caixas
          pk_armazem.criarPickingProduto(r_pick.idarmazem, r_pick.idlocal,
                                         r_prod_pk.iddepositante,
                                         r_prod_pk.idproduto);
        
          pk_utilities.GeraLog(p_usuario,
                               'CADASTROU O PICKING AUTOMATICO A PARTIR DA OR: ' ||
                                P_LOTENF || ' PARA O PRODUTO: ' ||
                                R_PROD_PK.CODPROD || '-' ||
                                R_PROD_PK.PRODUTO || ' E DEP.:' ||
                                R_PROD_PK.DEPOSITANTE, P_LOTENF, 'CA');
        
        end if;
      
      end if;
    
      -- proximos registros (Produto)
      fetch c_prod_pk
        into r_prod_pk;
    
    end loop;
  
  end;

  procedure liberarORcomDivergencia
  (
    p_idlotenf  in number,
    p_idusuario in number,
    p_idmotivo  in number,
    p_mensagem  out varchar2
  ) is
  
    type t_or is record(
      liberarordiverp            number,
      utilizaOPA                 depositante.utilizaopa%type,
      utilizaBacklist            depositante.utzbacklist%type,
      fracionarLote              depositante.fracionarlote%type,
      possuiOrdemTransferencia   number,
      flaglibnf                  number,
      possuiNotaVinculada        number,
      possuiNotaCrossdocking     number,
      possuiOrdemServico         number,
      possuiProdutoKitExplodido  number,
      possuiContagemKitExplodido number,
      possuiAlgumaContagem       number,
      classificacao              tiporecebimento.classificacao%type,
      descricaomotivo            motivo.descr%type,
      gerarloteporpalete         number,
      geraralocacaoporpalete     number,
      conferenciaalocada         number,
      integrarErpSenior          depositante.integrarerpsenior%type,
      gerarpedidoimportacaotdn   depositante.gerarpedidoimportacaotdn%type);
  
    r_or            t_or;
    v_mensagem_info varchar2(4000);
  
    procedure carregarDados is
    begin
    
      select d.liberarordiverp, d.utilizaOPA, d.utzbacklist, d.fracionarlote,
             lnf.flaglibnf, tr.classificacao, tr.gerarloteporpalete,
             tr.geraralocacaoporpalete, tr.conferenciaalocada,
             -- nota de ordem transferencia
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal nf
                        where nf.idlotenf = lnf.idlotenf
                          and nf.ordemtransferencia = 1)) possuiordemtransferencia,
             -- possui alguma nota vinculada
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal
                        where idlotenf = lnf.idlotenf)) possuiNotaVinculada,
             -- nota de crossdocking
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal nf
                        where nf.idlotenf = lnf.idlotenf
                          and nf.crossdocking = 'S')) possuiNotaCrossdocking,
             -- ordem de serviço
             (select count(*)
                 from dual
                where exists (select 1
                         from ordemservico
                        where idlotenf = lnf.idlotenf)) possuiOrdemServico,
             -- produto pertencente a nota fiscal de kit de expedição explodida
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal nf, nfdet nd, produto p
                        where nf.idlotenf = lnf.idlotenf
                          and nd.nf = nf.idnotafiscal
                          and p.idproduto = nd.idproduto
                          and p.kitexpexplodida = 'S')) possuiProdutoKitExplodido,
             -- produto de kit de expedição explodida contado fora da nota fiscal
             -- Atenção
             -- O select abaixo deve ser basear em uma regra de negócio importante
             -- relacionada a conferencia de entrada:
             -- Em casos de recontagem somente é necessário recontar o produto / estado da OR,
             -- ou seja, a última conferencia considerada é para o produto e estado da OR.
             -- Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
             -- e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias
             -- são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
             -- produto no estado Normal novamente.
             (select count(*)
                 from dual
                where exists
                (select 1
                         from conferenciaentradadet c, produto p,
                              (select cd.idlotenf, cd.idproduto, cd.estado,
                                       max(cd.idconferenciaentrada) idconferenciaentrada
                                  from conferenciaentradadet cd
                                 where nvl(cd.ignorada, 'N') = 'N'
                                 group by cd.idlotenf, cd.idproduto, cd.estado) cm
                        where c.idlotenf = lnf.idlotenf
                          and nvl(c.ignorada, 'N') = 'N'
                          and p.idproduto = c.idproduto
                          and p.kitexpexplodida = 'S'
                          and cm.idlotenf = c.idlotenf
                          and cm.idconferenciaentrada = c.idconferenciaentrada
                          and cm.idproduto = c.idproduto
                          and cm.estado = c.estado)) possuiContagemKitExplodido,
             -- possui contagem registrada
             (select count(*)
                 from dual
                where exists (select 1
                         from conferenciaentradadet d
                        where idlotenf = lnf.idlotenf
                          and d.ignorada = 'N')) possuiAlgumaContagem,
             d.integrarerpsenior, d.gerarpedidoimportacaotdn
        into r_or.liberarordiverp, r_or.utilizaOPA, r_or.utilizaBacklist,
             r_or.fracionarLote, r_or.flaglibnf, r_or.classificacao,
             r_or.gerarloteporpalete, r_or.geraralocacaoporpalete,
             r_or.conferenciaalocada, r_or.possuiOrdemTransferencia,
             r_or.possuiNotaVinculada, r_or.possuiNotaCrossdocking,
             r_or.possuiOrdemServico, r_or.possuiProdutoKitExplodido,
             r_or.possuiContagemKitExplodido, r_or.possuiAlgumaContagem,
             r_or.integrarErpSenior, r_or.gerarpedidoimportacaotdn
        from lotenf lnf, depositante d, tiporecebimento tr
       where lnf.idlotenf = p_idlotenf
         and d.identidade = lnf.identidade
         and tr.idtiporecebimento = lnf.idtiporecebimento;
    
      select m.descr
        into r_or.descricaomotivo
        from motivo m
       where m.idmotivo = p_idmotivo;
    
    end carregarDados;
  
    procedure validacoes is
    
      function validarSobraNaConferencia return boolean is
        v_contouAMais number;
      begin
        /*Atenção
        O select abaixo deve ser basear em uma regra de negócio importante 
        relacionada a conferencia de entrada:
        Em casos de recontagem somente é necessário recontar o produto / estado da OR,
        ou seja, a última conferencia considerada é para o produto e estado da OR.
        Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
        e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias 
        são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
        produto no estado Normal novamente.*/
        select count(*)
          into v_contouAMais
          from dual
         where exists
         (select 1
                  from (select a.idproduto, sum(a.qtdenf) qtdenf,
                                sum(a.qtdeconf) qtdeconf
                           from (select nd.idproduto,
                                         sum(nd.qtde * e.fatorconversao) qtdenf,
                                         0 qtdeconf
                                    from notafiscal nf, nfdet nd, embalagem e
                                   where nf.idlotenf = p_idlotenf
                                     and nd.nf = nf.idnotafiscal
                                     and e.idproduto = nd.idproduto
                                     and e.barra = nd.barra
                                   group by nd.idproduto
                                  union all
                                  select cd.idproduto, 0 qtdenf,
                                         sum(cd.qtde * e.fatorconversao) qtdeconf
                                    from (select cd.idlotenf, cd.idproduto,
                                                  cd.estado,
                                                  max(cd.idconferenciaentrada) idconferenciaentrada
                                             from conferenciaentradadet cd
                                            where cd.idlotenf = p_idlotenf
                                              and nvl(cd.ignorada, 'N') = 'N'
                                            group by cd.idlotenf, cd.idproduto,
                                                     cd.estado) conf,
                                         conferenciaentradadet cd, embalagem e
                                   where cd.idlotenf = conf.idlotenf
                                     and cd.idproduto = conf.idproduto
                                     and cd.idconferenciaentrada =
                                         conf.idconferenciaentrada
                                     and cd.estado = conf.estado
                                     and e.barra = cd.barra
                                     and e.idproduto = cd.idproduto
                                     and nvl(cd.ignorada, 'N') = 'N'
                                   group by cd.idproduto) a
                          group by a.idproduto
                         having sum(a.qtdeconf) > sum(a.qtdenf)));
      
        return v_contouAMais > 0;
      
      end validarSobraNaConferencia;
    
      procedure restricoesFluxoOrdemCompra is
      begin
        if (r_or.utilizaOPA = 0) then
          return;
        end if;
      
        if (validarSobraNaConferencia) then
          v_msg := t_message('A ORDEM DE RECEBIMENTO POSSUI O DEPOSITANTE CONFIGURADO PARA UTILIZAR ORDEM DE COMPRA. LIBERAÇÃO COM CONTAGEM MAIOR DO QUE SOLICITADO EM NOTA FISCAL NÃO PERMITIDA.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        --Verifica se foi conferida alguma informação especifica que não esta na OPA (Neste caso OR não pode ser liberada)
        for i in (select inf.valor recebido
                    from informacaomaterialvalor inf,
                         (select ion.idlotenf, io.infoespecifica, io.idproduto
                             from itemopanfdet ion, itemordemcompra io
                            where ion.idlotenf = p_idlotenf
                              and io.iditemordemcompra = ion.iditemordemcompra
                              and io.infoespecifica is not null) opadet,
                         conferenciaentradadet ced
                   where opadet.idlotenf(+) = inf.idlotenf
                     and opadet.infoespecifica(+) = inf.valor
                     and inf.valor is not null
                     and opadet.infoespecifica is null
                     and ced.idcontagem = inf.idcontagem
                     and ced.idconferenciaentrada = inf.idconferenciaentrada
                     and decode(nvl(ced.ignorada, 'N'), 'N', 1, 0) = 1
                     and inf.idlotenf = p_idlotenf)
        
        loop
          v_mensagem_info := v_mensagem_info || chr(13) || i.recebido;
        end loop;
      
        if (v_mensagem_info is not null) then
          v_msg := t_message('As informações específicas abaixo não estão presentes na Ordem de Compra:{0}');
          v_msg.addParam(v_mensagem_info);
          raise_application_error(-20000, v_msg.formatMessage);
        
        end if;
      
        --Verifica se faltou conferir alguma informação presente na OR (Neste caso a OR pode ser liberada com divergencia)
        for i in (select opadet.infoespecifica nao_recebido
                    from (select ion.idlotenf, io.infoespecifica, io.idproduto
                             from itemopanfdet ion, itemordemcompra io
                            where ion.idlotenf = p_idlotenf
                              and io.iditemordemcompra = ion.iditemordemcompra
                              and io.infoespecifica is not null) opadet
                    left join informacaomaterialvalor inf
                      on opadet.idlotenf = inf.idlotenf
                     and opadet.infoespecifica = inf.valor
                   where opadet.infoespecifica is not null
                     and opadet.idlotenf = p_idlotenf
                     and inf.valor is null)
        
        loop
          v_mensagem_info := v_mensagem_info || chr(13) || i.nao_recebido;
        end loop;
      
        if (v_mensagem_info is not null) then
          v_msg := t_message('As informações específicas abaixo não foram recebidas: {0}');
          v_msg.addParam(v_mensagem_info);
          v_mensagem_info := v_msg.formatMessage;
        end if;
      
      end restricoesFluxoOrdemCompra;
    
      procedure restricoesFluxoOrdemTransf is
      
        v_qtdeItemFora number;
        v_idsProdutos  varchar2(4000);
        v_msgParcial   varchar2(4000);
        v_msg          t_message;
        v_maxConf      conferenciaentradadet.idconferenciaentrada%type;
      
      begin
        if (r_or.possuiOrdemTransferencia = 0) then
          return;
        end if;
      
        if (r_or.gerarpedidoimportacaotdn = 0) then
        
          if (validarSobraNaConferencia) then
            v_msg := t_message('A or não pode ser liberada com sobra, pois possui nota(s) fiscal(s) de Ordem de Transferência');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        else
        
          v_qtdeItemFora := 0;
          v_msgParcial   := null;
        
          select max(ced.idconferenciaentrada)
            into v_maxConf
            from conferenciaentradadet ced
           where ced.idlotenf = p_idlotenf;
        
          for c_Item in (select ced.*
                           from lotenf lnf, notafiscal nf,
                                conferenciaentradadet ced
                          where lnf.idlotenf = p_idlotenf
                            and lnf.idlotenf = nf.idlotenf
                            and lnf.idlotenf = ced.idlotenf
                            and ced.ignorada = 'N'
                            and ced.idconferenciaentrada = v_maxConf
                            and not exists
                          (select 1
                                   from nfdet nd
                                  where nf.idnotafiscal = nd.nf
                                    and ced.idproduto = nd.idproduto))
          loop
            v_qtdeItemFora := v_qtdeItemFora + 1;
          
            v_idsProdutos := v_idsProdutos || c_Item.Idproduto || ', ';
          
          end loop;
        
          if (v_qtdeItemFora = 1) then
            v_msgParcial := 'O produto ID: ' || v_idsProdutos ||
                            ' não existe na Ordem de Transferêcia(TDN) e está presente na conferência';
          elsif (v_qtdeItemFora > 1) then
            v_msgParcial := 'Os produtos ID' || '''' || 's: ' ||
                            v_idsProdutos ||
                            ' não existem na Ordem de Transferêcia(TDN) e estão presentes na conferência';
          end if;
        
          if (v_msgParcial is not null) then
            v_msg := t_message(v_msgParcial);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        end if;
      
      end restricoesFluxoOrdemTransf;
    
      procedure restricoesBacklist is
        C_NAO_COLETA_DATAS  constant number := 0;
        C_COLETA_VENCIMENTO constant number := 1;
        C_COLETA_FABRICACAO constant number := 2;
      
        v_qtde number;
      
        function existeDivergenciaNegativa return boolean is
          v_qtdNeg number := 0;
        begin
          select count(*)
            into v_qtdNeg
            from vt_backlistor v
           where v.h$idlotenf = p_idlotenf
             and v.diferenca < 0;
        
          return(v_qtdNeg > 0);
        
        end existeDivergenciaNegativa;
      
      begin
        if (r_or.utilizaBacklist = 0) then
          return;
        end if;
      
        select count(*)
          into v_qtde
          from dual
         where exists
         (select 1
                  from (select nd.idproduto, b.loteindustria,
                                b.qtde * e.fatorconversao qtdebacklist,
                                0 qtdeconf,
                                decode(pd.coletadtavenclote, C_NAO_COLETA_DATAS,
                                        null, C_COLETA_VENCIMENTO, null,
                                        b.dtfabricacao) datafabricacao,
                                decode(pd.coletadtavenclote, C_NAO_COLETA_DATAS,
                                        null, C_COLETA_FABRICACAO, null,
                                        b.vencimento) datavencimento
                           from notafiscal nf, nfdet nd, backlist b,
                                embalagem e, produtodepositante pd
                          where nf.idlotenf = p_idlotenf
                            and nd.nf = nf.idnotafiscal
                            and b.idnfdet = nd.idnfdet
                            and e.barra = nd.barra
                            and e.idproduto = nd.idproduto
                            and pd.idproduto = nd.idproduto
                            and pd.identidade = nf.iddepositante
                         union all
                         select cd.idproduto, cd.descrlote, 0,
                                sum(cd.qtde) qtdeconf,
                                decode(pd.coletadtavenclote, C_NAO_COLETA_DATAS,
                                        null, C_COLETA_VENCIMENTO, null,
                                        cd.datafabricacao) datafabricacao,
                                decode(pd.coletadtavenclote, C_NAO_COLETA_DATAS,
                                        null, C_COLETA_FABRICACAO, null,
                                        cd.datavencto) datavencimento
                           from (select *
                                    from (select c.idlotenf, c.idproduto, c.qtde,
                                                  c.descrlote, c.datafabricacao,
                                                  c.datavencto
                                             from ocorrencia o,
                                                  conferenciaentradadet c
                                            where c.idlotenf = o.idlotenf
                                              and o.idlotenf = p_idlotenf
                                              and o.status = '11'
                                              and c.idconferenciaentrada =
                                                  o.idconferenciaentrada
                                              and c.ignorada = 'N'
                                              and c.status = 'N'
                                              and c.descrlote is not null
                                            order by c.idconferenciaentrada desc)
                                   where rownum = 1) cd, produtodepositante pd,
                                lotenf lnf
                          where lnf.idlotenf = cd.idlotenf
                            and pd.idproduto = cd.idproduto
                            and lnf.identidade = pd.identidade
                          group by cd.idproduto, cd.descrlote,
                                   decode(pd.coletadtavenclote,
                                           C_NAO_COLETA_DATAS, null,
                                           C_COLETA_VENCIMENTO, null,
                                           cd.datafabricacao),
                                   decode(pd.coletadtavenclote,
                                           C_NAO_COLETA_DATAS, null,
                                           C_COLETA_FABRICACAO, null,
                                           cd.datavencto)) b
                 group by b.idproduto, b.loteindustria, b.datafabricacao,
                          b.datavencimento
                having sum(b.qtdebacklist) < sum(b.qtdeconf));
      
        if (v_qtde > 0 and r_or.fracionarLote = 0) then
          v_msg := t_message('Existem items de backlist com contagem a mais');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (existeDivergenciaNegativa) then
          v_msg := t_message('Existem itens de backlist com divergência negativa');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end restricoesBacklist;
    
      procedure restricoesAutRecebimento is
        v_qtdSemNumero number := 0;
      begin
        select count(*)
          into v_qtdSemNumero
          from conferenciaentradadet ced
         where ced.idlotenf = p_idlotenf
           and ced.ignorada = 'N'
           and exists
         (select 1
                  from ocorrencia o
                 where o.idlotenf = ced.idlotenf
                   and o.idproduto = ced.idproduto
                   and o.idconferenciaentrada = ced.idconferenciaentrada
                   and o.status = '02')
           and not exists (select 1
                  from nfdetimpressao ndi, nfimpressao ni,
                       notafiscal nf, nfdet nd
                 where ndi.idprenf = ni.idprenf
                   and ni.idprenf = nf.idprenf
                   and ni.origemintegracao = 3
                   and ndi.idnfdet = nd.idnfdet
                   and nf.idlotenf = ced.idlotenf
                   and ndi.numeroordemcompra is not null
                   and nd.idproduto = ced.idproduto)
           and exists (select 1
                  from notafiscal nf, nfimpressao ni
                 where nf.idprenf = ni.idprenf
                   and ni.origemintegracao = 3
                   and ced.idlotenf = nf.idlotenf);
      
        if (v_qtdSemNumero > 0) then
          v_msg := t_message('Não é permitido liberar OR com divergências quando houver conferência de itens que não pertencem a nota.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end restricoesAutRecebimento;
    
      function validarProdutosInexistentes return boolean is
        v_inexistentes number;
      begin
        select count(*)
          into v_inexistentes
          from conferenciaentradadet c
         where c.idlotenf = p_idlotenf
           and nvl(c.ignorada, 'N') = 'N'
           and not exists (select 1
                  from notafiscal nf, nfdet nd
                 where nf.idnotafiscal = nd.nf
                   and nf.idlotenf = c.idlotenf
                   and c.idproduto = nd.idproduto);
        return v_inexistentes > 0;
      END validarProdutosInexistentes;
    
      procedure restricoesErpSenior is
      begin
        if (r_or.integrarErpSenior = 1 and
           (validarSobraNaConferencia or validarProdutosInexistentes)) then
          v_msg := t_message('A ORDEM DE RECEBIMENTO POSSUI O DEPOSITANTE CONFIGURADO PARA UTILIZAR INTEGRAÇÃO ERP SENIOR. LIBERAÇÃO COM CONTAGEM MAIOR DO QUE SOLICITADO E/OU PRODUTO INEXISTENTE CONFORME NOTA FISCAL NÃO PERMITIDA.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end restricoesErpSenior;
    
    begin
    
      restricoesFluxoOrdemCompra;
      restricoesFluxoOrdemTransf;
      restricoesBacklist;
      restricoesErpSenior;
      restricoesAutRecebimento;
    
      if (r_or.flaglibnf = 2) then
        v_msg := t_message('A ORDEM DE RECEBIMENTO JÁ ESTÁ COM A CONFERÊNCIA FINALIZADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_or.possuiNotaVinculada = 0) then
        v_msg := t_message('NÃO EXISTE NOTA FISCAL VINCULADA A ORDEM DE RECEBIMENTO. OPERAÇÃO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.possuiNotaCrossdocking = 1 then
        v_msg := t_message('NÃO É PERMITIDO LIBERAR OR DE CROSDOCKING COM DIVERGÊNCIAS. OPERAÇÃO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.possuiOrdemServico = 1 then
        v_msg := t_message('ORDEM DE RECEBIMENTO QUE FOI GERADA POR UMA ORDEM DE SERVIÇO, NÃO PODE SER LIBERADA COM DIVERGÊNCIA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.possuiProdutoKitExplodido = 1 then
        v_msg := t_message('EXISTE PRODUTO DE KIT DE EXPEDIÇÃO EXPLODIDA EM NOTA FISCAL VINCULADA NA ORDEM DE RECEBIMENTO.' ||
                           chr(13) ||
                           'NÃO É PERMITIDO LIBERAR COM DIVERGÊNCIA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.possuiContagemKitExplodido = 1 then
        v_msg := t_message('EXISTE PRODUTO DE KIT DE EXPEDIÇÃO EXPLODIDA NA CONFERÊNCIA DA ORDEM DE RECEBIMENTO.' ||
                           chr(13) ||
                           'NÃO É PERMITIDO LIBERAR COM DIVERGÊNCIA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.possuiAlgumaContagem = 0 then
        v_msg := t_message('NÃO EXISTE CONTAGEM PARA SER LIBERADA COM DIVERGÊNCIA. OPERAÇÃO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if r_or.classificacao in ('D', 'T')
         and not VerificaPermissaoUsuario(p_idlotenf, p_idusuario) then
        v_msg := t_message('USUÁRIO NÃO TEM NÍVEL DE PERMISSÃO PARA LIBERAR A DIVERGÊNCIA DESTA ORDEM DE RECEBIMENTO. CONTATE UM SUPERVISOR.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validacoes;
  
    procedure solicitarLibDivERP is
    begin
      update lotenf
         set statuslibdiverp = 1
       where idlotenf = p_idlotenf;
    
      pk_integracao.ExportarORBanco(p_idlotenf);
      v_msg := t_message('SOLICITAÇÃO DE LIBERAÇÃO DA CONFERÊNCIA EXPORTADA AO ERP.' ||
                         chr(13) ||
                         'APÓS O RECEBIMENTO DA AUTORIZAÇÃO A ORDEM DE RECEBIMENTO SERÁ LIBERADA.' ||
                         chr(13) || '{0}');
      v_msg.addParam(v_mensagem_info);
      p_mensagem := v_msg.formatMessage;
    end solicitarLibDivERP;
  
    procedure fluxoGeracaoLoteNaConferencia is
    begin
      if (r_or.gerarloteporpalete = 0) then
        return;
      end if;
    
      if (pk_confentrada.isExisteContagemPendente(p_idlotenf)) then
        v_msg := t_message('EXISTEM CONFERÊNCIAS PENDENTES DE FINALIZAÇÃO. OR : {0}');
        v_msg.addParam(p_idlotenf);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_or.geraralocacaoporpalete = 1) then
        pk_confentrada.finalizarORloteNaConferencia(p_idlotenf, p_idusuario);
      end if;
    
    end fluxoGeracaoLoteNaConferencia;
  
    procedure fluxoConferenciaAlocada is
      v_mgsContratoLote historicomudancacontratolote.mensagem%type;
    begin
    
      if (r_or.conferenciaalocada = 0) then
        return;
      end if;
    
      --Se for conferencia alocada libera os lotes que foram bloqueados e processa a OR      
      -- É realizado nesse momento o vínculo na origem lote e realizada a cobertura dos lotes conferidos e alocados
      pk_confentrada.gerarOrigemLoteConfAloc(p_idlotenf);
    
      if (pk_confentrada.liberaLoteConfAlocada(p_idlotenf)) then
        update lote l
           set l.liberado             = 'S',
               l.databloqueio         = null,
               l.idusuariobloqueio    = null,
               l.motivobloqueio       = null,
               l.idmotivobloqueio     = null,
               l.datadesbloqueio      = sysdate,
               l.idusuariodesbloqueio = p_idusuario,
               l.motivodesbloqueio    = r_or.descricaomotivo,
               l.idmotivodesbloqueio  = p_idmotivo
         where l.idlote in (select idlote
                              from orlote
                             where idlotenf = p_idlotenf);
      end if;
    
      update lotenf
         set cadloteaut               = c_sim,
             datageracaolote          = sysdate,
             idusuariogeracaolote     = p_idusuario,
             status                   = 'P',
             mapaaloc                 = 'S',
             datageracaomapaaloc      = sysdate,
             idusuariogeracaomapaaloc = p_idusuario,
             faltamalocar             = 0
       where idlotenf = p_idlotenf;
    
      pk_notafiscal.GerarNfRetornoOR(p_idlotenf);
      pk_gmb.GerarNFRemessaArmNaoICMS(p_idusuario, p_idlotenf);
    
      update notafiscal
         set statusnf = 'P'
       where idlotenf = p_idlotenf;
    
      pk_integracao.exportarORAposAlocacao(p_idlotenf);
      pk_integracao.expRetornoRecebimentoCE(p_idlotenf);
    
      for c_histContratoLote in (select o.idlote, cl.idcontrato,
                                        cl.prazotroca, cl.status
                                   from contratolote cl, orlote o
                                  where o.idlotenf = p_idlotenf
                                    and cl.idlote = o.idlote)
      loop
        if c_histContratoLote.Idcontrato is null then
          v_mgsContratoLote := 'INCLUÍDO REGISTRO PARA VINCULAR CONTRATO AO LOTE ID: ' ||
                               c_histContratoLote.Idlote ||
                               ' EM FUNÇÃO DA ORDEM DE RECEBIMENTO ID: ' ||
                               p_idlotenf;
        else
          v_mgsContratoLote := 'VINCULADO O LOTE ID: ' ||
                               c_histContratoLote.Idlote ||
                               ' AO CONTRATO ID: ' ||
                               c_histContratoLote.Idcontrato ||
                               ' EM FUNÇÃO DA ORDEM DE RECEBIMENTO ID: ' ||
                               p_idlotenf;
        end if;
        pk_contrato.historicoMudancaContratoLote(c_histContratoLote.Idcontrato,
                                                 c_histContratoLote.Idlote,
                                                 c_histContratoLote.Prazotroca,
                                                 p_idusuario, 1,
                                                 v_mgsContratoLote,
                                                 c_histContratoLote.Status);
      end loop;
    
    end fluxoConferenciaAlocada;
  
  begin
  
    carregarDados;
  
    validacoes;
  
    if r_or.liberarordiverp = 1 then
      solicitarLibDivERP;
      return;
    end if;
  
    Libera_Conf_Div(p_idlotenf, p_idusuario, r_or.descricaomotivo,
                    p_idmotivo);
  
    pk_confentrada.InsereResumoConferenciaNF(p_idlotenf, p_idUsuario);
  
    fluxoGeracaoLoteNaConferencia;
  
    fluxoConferenciaAlocada;
  
    v_msg := t_message('CONFERÊNCIA LIBERADA COM SUCESSO.' || chr(13) ||
                       '{0}');
    v_msg.addParam(v_mensagem_info);
    p_mensagem := v_msg.formatMessage;
  
  end liberarORcomDivergencia;

  procedure Libera_Conf_Div
  (
    p_or             in number,
    p_usuario        in number,
    p_motivolibdiv   in varchar2,
    p_idmotivolibdiv in number
  ) is
  begin
    for c in (select max(c.idconferenciaentrada) idconferenciaentrada
                from conferenciaentrada c
               where c.idlotenf = p_or)
    loop
      pk_confentrada.p_gera_ocorrencia(p_or, c.idconferenciaentrada,
                                       p_usuario, c_nao);
    end loop;
  
    update conferenciaentradadet
       set status = 'N'
     where idlotenf = p_or
       and idlote is null;
  
    /*Atenção
    O select abaixo deve ser basear em uma regra de negócio importante 
    relacionada a conferencia de entrada:
    Em casos de recontagem somente é necessário recontar o produto / estado da OR,
    ou seja, a última conferencia considerada é para o produto e estado da OR.
    Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
    e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias 
    são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
    produto no estado Normal novamente.*/
    update conferenciaentradadet
       set status = 'S'
     where (idlotenf, idconferenciaentrada, idproduto, estado) in
           (select c.idlotenf, max(c.idconferenciaentrada), c.idproduto,
                   c.estado
              from conferenciaentradadet c
             where c.idlotenf = p_or
               and nvl(c.ignorada, 'N') = 'N'
             group by c.idlotenf, c.idproduto, c.estado)
       and idlote is null;
  
    /*Atenção
    O select abaixo deve ser basear em uma regra de negócio importante 
    relacionada a conferencia de entrada:
    Em casos de recontagem somente é necessário recontar o produto / estado da OR,
    ou seja, a última conferencia considerada é para o produto e estado da OR.
    Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
    e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias 
    são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
    produto no estado Normal novamente.*/
    -- Inserindo produtos que vieram a mais na contagem
    insert into sumprodlote
      (idlotenf, idproduto, barra, qtde)
      select distinct p_or, conf.idproduto, conf.barra, 0
        from (select c.idlotenf, c.idproduto, c.estado,
                      pk_produto.ret_codbarra_nao_precad(c.idproduto, 1) barra,
                      max(c.idconferenciaentrada) idconferenciaentrada
                 from conferenciaentradadet c
                where c.idlotenf = p_or
                  and c.status = 'S'
                  and nvl(c.ignorada, 'N') = 'N'
                group by c.idlotenf, c.idproduto, c.estado,
                         pk_produto.ret_codbarra_nao_precad(c.idproduto, 1)) conf
       where not exists (select 1
                from sumprodlote s
               where s.idlotenf = p_or
                 and s.idproduto = conf.idproduto
                 and s.barra = conf.barra);
  
    update conferenciaentrada
       set finalizada = 'S'
     where (idlotenf, idconferenciaentrada) =
           (select c.idlotenf, max(c.idconferenciaentrada)
              from conferenciaentradadet c
             where c.idlotenf = p_or
               and nvl(c.ignorada, 'N') = 'N'
             group by c.idlotenf);
  
    if (pk_recebimento.isConferenciaAlocada(p_or)) then
      for c_conf in (select c.idproduto,
                            pk_produto.ret_codbarra_nao_precad(c.idproduto, 1) barra,
                            sum(c.qtde * e.fatorconversao) qtde
                       from conferenciaentradadet c, embalagem e
                      where e.barra = c.barra
                        and e.idproduto = c.idproduto
                        and nvl(c.ignorada, 'N') = 'N'
                        and c.status = 'S'
                        and c.idlotenf = p_or
                      group by c.idproduto,
                               pk_produto.ret_codbarra_nao_precad(c.idproduto,
                                                                   1))
      loop
        update sumprodlote
           set qtdelib = c_conf.qtde,
               qtdconf = c_conf.qtde
         where idlotenf = p_or
           and idproduto = c_conf.idproduto
           and barra = c_conf.barra;
      end loop;
    else
      /*Atenção
      O select abaixo deve ser basear em uma regra de negócio importante 
      relacionada a conferencia de entrada:
      Em casos de recontagem somente é necessário recontar o produto / estado da OR,
      ou seja, a última conferencia considerada é para o produto e estado da OR.
      Dessa forma, um produto pode ter sido conferido no estado Normal na conferencia 1
      e conferido somente no estado Danificado na conferencia 2, onde as duas conferencias 
      são válidas e consideradas para a geração de lotes, não sendo necessário recontar o
      produto no estado Normal novamente.*/
      for c_conf in (select c.idproduto,
                            pk_produto.ret_codbarra_nao_precad(c.idproduto, 1) barra,
                            sum(c.qtde * e.fatorconversao) qtde
                       from conferenciaentradadet c, embalagem e,
                            (select cd.idlotenf, cd.idproduto, cd.estado,
                                     max(cd.idconferenciaentrada) idconferenciaentrada
                                from conferenciaentradadet cd
                               where nvl(cd.ignorada, 'N') = 'N'
                               group by cd.idlotenf, cd.idproduto, cd.estado) cm
                      where e.barra = c.barra
                        and e.idproduto = c.idproduto
                        and cm.idproduto = c.idproduto
                        and cm.idconferenciaentrada = c.idconferenciaentrada
                        and cm.idlotenf = c.idlotenf
                        and cm.estado = c.estado
                        and nvl(c.ignorada, 'N') = 'N'
                        and c.status = 'S'
                        and c.idlotenf = p_or
                      group by c.idproduto,
                               pk_produto.ret_codbarra_nao_precad(c.idproduto,
                                                                   1))
      loop
        update sumprodlote
           set qtdelib = c_conf.qtde,
               qtdconf = c_conf.qtde
         where idlotenf = p_or
           and idproduto = c_conf.idproduto
           and barra = c_conf.barra;
      end loop;
    end if;
  
    update lotenf
       set cadloteliberado = 'S',
           flaglibnf       = 2,
           dataliberacao   = sysdate,
           idusuariolib    = p_usuario,
           motivolibdiv    = p_motivolibdiv,
           idmotivolibdiv  = p_idmotivolibdiv
     where idlotenf = p_or;
  
    -- Excluindo os documentos de divergência de conferência.
    excluiDocDivergenciaEntrada(p_or, p_usuario, 'RECONTAGEM');
  
    -- Gerando os documentos de devolucao e complemento
    geraDocDivergencia(p_or);
  
    pk_integracao.exportarORAposConferencia(p_or);
  
    -- gera log
    pk_utilities.GeraLog(p_usuario,
                         'LIBEROU CONFERENCIA COM DIVERGENCIA PARA A OR ' || p_or,
                         p_or, 'OR');
  end;

  /*Retorna o valor do produto na mesma OR e em notas que não sejam de AGCOB*/
  function retValorUnit
  (
    p_idlotenf  number,
    p_idproduto number
  ) return number is
    v_vlrUnit number;
  begin
    /*Verifica o valor do produto na mesma OR e 
    em todas as notas que não sejam de AGCOB*/
    select nvl((sum(nd.total) / sum(nd.qtdeatendida * e.fatorconversao)), 0)
      into v_vlrUnit
      from nfdet nd, notafiscal nf, embalagem e
     where nf.idnotafiscal = nd.nf
       and e.idproduto = nd.idproduto
       and e.barra = nd.barra
       and nf.sequencia <> 'AGCOB'
       and nf.idlotenf = p_idlotenf
       and nd.idproduto = p_idproduto;
    return v_vlrUnit;
  end;

  /*
   * Rotina para conferir as quantidades recebidas e gerar os documentos de divergência 
  */
  procedure geraDocDivergencia(p_idlotenf in lotenf.idlotenf%type) is
    v_idEntArmazem number;
    v_idArmazem    number;
  
    procedure carregarDadosIniciais is
    begin
      -- identifica a unidade que esta operando
      select a.identidade, a.idarmazem
        into v_idEntArmazem, v_idarmazem
        from lotenf l, armazem a
       where l.idlotenf = p_idlotenf
         and a.idarmazem = l.idarmazem;
    end;
  
    procedure gerarDocDivSaida is
      v_idoperacao    number;
      v_idnfdevolucao number;
      v_temRastro     number;
      v_idseq         number;
    
      r_nf              notafiscal%rowtype;
      r_dadosadicionais dadosadicionaisnf%rowtype;
      r_nfdet           nfdet%rowtype;
      r_backlist        backlist%rowtype;
    begin
      -- Gerando as notas de devolucao
      for c_notasDev in (select distinct nf.idnotafiscal, nf.iddepositante,
                                         nf.codigointerno, nf.sequencia,
                                         nf.idprenf
                           from resumoconferencianf rc, notafiscal nf
                          where nf.idnotafiscal = rc.idnotafiscal
                            and rc.idlotenf = p_idlotenf
                            and rc.qtdenf > (rc.qtdenormal + rc.qtdetruncada +
                                rc.qtdedanificada))
      loop
        -- Retorna o tipo de operacao de nota fiscal de devolucao
        if v_idoperacao is null then
          v_idoperacao := pk_notafiscal.retornaroperacao(c_notasDev.iddepositante,
                                                         v_idEntArmazem,
                                                         c_saida, c_devolucao);
        end if;
      
        if v_idoperacao is null then
          v_msg := t_message('Operacao(CFOP) de devolução nao cadastrada');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        --Inserindo Cabeçalho da NF
        r_nf.idoperacao    := v_idoperacao;
        r_nf.iddepositante := c_notasDev.iddepositante;
        r_nf.ident_entrega := c_notasDev.iddepositante;
        r_nf.remetente     := v_idEntArmazem;
        r_nf.destinatario  := c_notasDev.iddepositante;
        r_nf.dataemissao   := sysdate;
        r_nf.movestoque    := 'N';
        r_nf.digitada      := 'N';
        r_nf.impresso      := 'N';
        r_nf.tipo          := 'S';
        r_nf.statusnf      := 'N';
        r_nf.sequencia     := 'DEV';
        r_nf.serieagcob    := c_notasDev.sequencia;
        r_nf.idarmazem     := v_idarmazem;
        r_nf.totalprodutos := 0;
        r_nf.totalgeral    := 0;
        v_idnfdevolucao    := pk_notafiscal.insere_cabecalho_nf(r_nf);
      
        -- Referenciando a nota fiscal de devolução à nota fiscal de entrada
        insert into notafiscaldevolucao
          (idnfentrada, idnfdevolucao)
        values
          (c_notasDev.idnotafiscal, v_idnfdevolucao);
      
        -- Inserindo mensagem de retorno
        r_dadosadicionais.idnotafiscal    := v_idnfdevolucao;
        r_dadosadicionais.mensagemretorno := 'Devolução de mercadoria referente à nota fiscal número: ' ||
                                             to_char(c_notasDev.codigointerno) ||
                                             ' Série: ' ||
                                             c_notasDev.sequencia ||
                                             ' e OR: ' || p_idlotenf;
        pk_notafiscal.InserirDadosAdicionaisNF(r_dadosadicionais);
      
        v_idseq := 1;
      
        for c_itensDev in (select rc.idproduto, rc.idnfdet idnfdetref,
                                  round(nd.precounitliquido /
                                         e.fatorconversao, 4) precounitliq,
                                  sum(rc.qtdenf -
                                       (rc.qtdenormal + rc.qtdetruncada +
                                       rc.qtdedanificada)) qtde,
                                  nd.barra barraref, nd.valoricms,
                                  nd.aliqicms, nd.baseicms, nd.total,
                                  nd.precounitbruto, tp.medicamento,
                                  nvl(p.precomaximoconsumidor, 0) precomaximoconsumidor
                             from resumoconferencianf rc, nfdet nd,
                                  embalagem e, produto p, tipoproduto tp
                            where rc.idlotenf = p_idLoteNF
                              and rc.idnotafiscal = c_notasDev.idnotafiscal
                              and nd.idnfdet = rc.idnfdet
                              and e.barra = nd.barra
                              and e.idproduto = nd.idproduto
                              and p.idproduto = nd.idproduto
                              and tp.idtipo = p.idtipo
                            group by rc.idproduto, rc.idnfdet,
                                     nd.precounitliquido, e.fatorconversao,
                                     nd.barra, nd.valoricms, nd.aliqicms,
                                     nd.baseicms, nd.total, nd.precounitbruto,
                                     tp.medicamento, p.precomaximoconsumidor
                           having sum(rc.qtdenf - (rc.qtdenormal + rc.qtdetruncada + rc.qtdedanificada)) > 0)
        loop
          -- Inserindo os itens na nota fiscal
          r_nfdet.idnfdet          := null;
          r_nfdet.nf               := v_idnfdevolucao;
          r_nfdet.barra            := pk_Produto.RetornarCodBarraMenorFator(c_itensDev.idproduto);
          r_nfdet.idproduto        := c_itensDev.idproduto;
          r_nfdet.precounitliquido := c_itensDev.precounitliq;
          r_nfdet.total            := (c_itensDev.precounitliq *
                                      c_itensDev.qtde);
          r_nfdet.qtde             := c_itensDev.qtde;
          r_nfdet.idnotafiscalref  := c_notasDev.idnotafiscal;
          r_nfdet.idnfdetref       := c_itensDev.idnfdetref;
          r_nfdet.barraref         := c_itensDev.barraref;
          r_nfdet.idprodutoref     := c_itensDev.idproduto;
        
          if r_nfdet.precounitliquido = 0 then
            r_nfdet.valordefinido := 'N';
          else
            r_nfdet.valordefinido := 'S';
          end if;
        
          if (nvl(c_itensDev.Aliqicms, 0) > 0 and
             nvl(c_itensDev.Valoricms, 0) > 0) then
            r_nfdet.baseicms  := (c_itensDev.Baseicms / c_itensDev.total) *
                                 (c_itensDev.Qtde *
                                 c_itensDev.Precounitbruto);
            r_nfdet.aliqicms  := c_itensDev.aliqicms;
            r_nfdet.valoricms := r_nfdet.baseicms *
                                 (c_itensDev.aliqicms / 100);
          end if;
        
          pk_notafiscal.insere_detalhe_nf(r_nfdet);
        
          if (c_itensDev.Medicamento = 1) then
            select count(*)
              into v_temRastro
              from nfdetrastro n
             where n.idnfdet = c_itensDev.Idnfdetref;
          
            if (v_temRastro = 0) then
              begin
                select b.*
                  into r_backlist
                  from backlist b
                 where b.idnfdet = c_itensDev.Idnfdetref;
              
                insert into nfdetrastro
                  (id, idnfdet, idprenf, idseq, nlote, qlote, dfab, dval,
                   vpmc)
                values
                  (seq_nfdetrastro.nextval, c_itensDev.Idnfdetref,
                   c_notasDev.Idprenf, v_idseq, r_backlist.loteindustria,
                   c_itensDev.qtde, r_backlist.dtfabricacao,
                   r_backlist.vencimento, c_itensDev.Precomaximoconsumidor);
              
                v_idseq := v_idseq + 1;
              exception
                when no_Data_found then
                  r_backlist := null;
              end;
            end if;
          end if;
        end loop;
      
        -- Totalizando as notas geradas
        -- Inserindo a nota fiscal de impressao
        pk_notafiscal.p_totaliza_nf(v_idnfdevolucao, c_nao);
        pk_notafiscal.p_gerar_nfimpressao(v_idnfdevolucao, c_nao);
      
        update notafiscal nf
           set nf.statusnf           = c_processada,
               nf.estoqueverificado  = 'S',
               nf.statusroteirizacao = 2
         where nf.idnotafiscal = v_idnfdevolucao;
      
        update nfimpressao ni
           set situacaoimpressao = 'I'
         where exists
         (select 1
                  from notafiscal n, operacao o
                 where o.tipooper not in (c_remessa_armazenagem, c_GMB)
                   and o.idoperacao = n.idoperacao
                   and n.idnotafiscal = v_idnfdevolucao
                   and n.idprenf = ni.idprenf);
      end loop;
    end;
  
    procedure gerarDocDivEntrada is
      v_idnfagcob number;
    
      r_nf    notafiscal%rowtype;
      r_nfdet nfdet%rowtype;
    begin
      -- gerando informacoes para composicao das nfs de agcob
      delete from gtt_nfdivergencia;
    
      for c_prodaguardando in (select r.idnfdet, r.idproduto, r.qtde,
                                      retValorUnit(p_idlotenf, r.idproduto) vlrUnit
                                 from (select rc.idnfdet, rc.idproduto,
                                               sum(rc.qtdenormal +
                                                    rc.qtdetruncada +
                                                    rc.qtdedanificada -
                                                    rc.qtdenf) qtde
                                          from resumoconferencianf rc
                                         where idlotenf = p_idlotenf
                                           and rc.qtdenf < (rc.qtdenormal +
                                               rc.qtdetruncada +
                                               rc.qtdedanificada)
                                         group by rc.idnfdet, rc.idproduto) r)
      loop
        if c_prodaguardando.idnfdet is not null then
          -- insert para adicionar na gtt os produtos com nf
          insert into gtt_nfdivergencia
            (idnotafiscal, codigointerno, sequencia, iddepositante,
             idproduto, qtde, precounit, numeroordemcompra)
            select n.idnotafiscal, n.codigointerno, n.sequencia,
                   n.iddepositante, n.idproduto, n.qtde, n.vlrUnit,
                   n.numeroordemcompra
              from (select nf.idnotafiscal, nf.codigointerno, nf.sequencia,
                            nf.iddepositante, nd.idproduto,
                            c_prodaguardando.qtde, c_prodaguardando.vlrUnit,
                            nd.numeroordemcompra
                       from notafiscal nf, nfdet nd, embalagem e
                      where nd.idnfdet = c_prodaguardando.idnfdet
                        and nd.nf = nf.idnotafiscal
                        and nd.idproduto = c_prodaguardando.idproduto
                        and e.barra = nd.barra
                        and e.idproduto = nd.idproduto
                      order by nd.numeroordemcompra) n
             where rownum = 1;
        else
          -- insert para adicionar na gtt os produtos sem nf
          insert into gtt_nfdivergencia
            (idnotafiscal, codigointerno, sequencia, iddepositante,
             idproduto, qtde, precounit, numeroordemcompra)
            select n.idnotafiscal, n.codigointerno, n.sequencia,
                   n.iddepositante, c_prodaguardando.idproduto,
                   c_prodaguardando.qtde, c_prodaguardando.vlrUnit,
                   n.numeroordemcompra
              from (select nf.idnotafiscal, nf.codigointerno, nf.sequencia,
                            nf.iddepositante, nd.numeroordemcompra
                       from notafiscal nf, nfdet nd
                      where nf.idlotenf = p_idlotenf
                        and nd.nf = nf.idnotafiscal
                      order by (case
                                  when nd.idproduto =
                                       c_prodaguardando.idproduto then
                                   0
                                  else
                                   1
                                end), nd.numeroordemcompra) n
             where rownum = 1;
        end if;
      end loop;
    
      -- Identificando os produtos que devem aguardar cobertura 
      for c_nfcobertura in (select distinct nf.codigointerno numnf,
                                            nd.idnotafiscal, nd.codigointerno,
                                            nd.sequencia, nd.iddepositante,
                                            nf.ident_entrega, nf.remetente,
                                            nf.destinatario, nf.dataemissao,
                                            nf.idcontrato,
                                            nf.numpedidofornecedor
                              from gtt_nfdivergencia nd, notafiscal nf
                             where nf.idnotafiscal = nd.idnotafiscal
                             order by nd.idnotafiscal)
      loop
        r_nf.idoperacao          := null;
        r_nf.sequencia           := 'AGCOB';
        r_nf.serieagcob          := c_nfcobertura.sequencia;
        r_nf.statusnf            := 'N';
        r_nf.codigointerno       := c_nfcobertura.numnf;
        r_nf.numpedidofornecedor := c_nfcobertura.numpedidofornecedor;
        r_nf.iddepositante       := c_nfcobertura.iddepositante;
        r_nf.ident_entrega       := c_nfcobertura.ident_entrega;
        r_nf.remetente           := c_nfcobertura.remetente;
        r_nf.destinatario        := c_nfcobertura.destinatario;
        r_nf.dataemissao         := c_nfcobertura.dataemissao;
        r_nf.idlotenf            := p_idlotenf;
        r_nf.dataemissao         := sysdate;
        r_nf.movestoque          := 'N';
        r_nf.digitada            := 'N';
        r_nf.impresso            := 'N';
        r_nf.tipo                := 'E';
        r_nf.idarmazem           := v_idarmazem;
        r_nf.idcontrato          := c_nfcobertura.idcontrato;
        v_idnfagcob              := pk_notafiscal.insere_cabecalho_nf(r_nf);
      
        for c_itenscob in (select g.idproduto, g.qtde, g.precounit,
                                  g.numeroordemcompra
                             from gtt_nfdivergencia g
                            where g.idnotafiscal =
                                  c_nfcobertura.idnotafiscal)
        loop
          -- Inserindo os itens na nota fiscal
          r_nfdet.idnfdet          := null;
          r_nfdet.nf               := v_idnfagcob;
          r_nfdet.barra            := pk_produto.retornarcodbarramenorfator(c_itenscob.idproduto);
          r_nfdet.idproduto        := c_itenscob.idproduto;
          r_nfdet.precounitliquido := c_itenscob.precounit;
          r_nfdet.total            := (c_itenscob.precounit *
                                      c_itenscob.qtde);
          r_nfdet.qtde             := c_itenscob.qtde;
          if r_nfdet.precounitliquido = 0 then
            r_nfdet.valordefinido := 'N';
          else
            r_nfdet.valordefinido := 'S';
          end if;
        
          r_nfdet.numeroordemcompra := c_itenscob.numeroordemcompra;
        
          pk_notafiscal.insere_detalhe_nf(r_nfdet);
        end loop;
      
        pk_notafiscal.p_totaliza_nf(v_idnfagcob, c_nao);
        pk_notafiscal.p_gerar_nfimpressao(v_idnfagcob, c_nao);
      
        update notafiscal
           set statusnf = 'P',
               impresso = 'S'
         where idnotafiscal = v_idnfagcob;
      
        update nfimpressao n
           set situacaoimpressao = 'I'
         where exists (select 1
                  from notafiscal nf
                 where nf.idnotafiscal = v_idnfagcob
                   and nf.idprenf = n.idprenf);
      
      end loop;
    end;
  begin
    carregarDadosIniciais;
    gerarDocDivSaida;
    gerarDocDivEntrada;
  end geraDocDivergencia;

  function cadastrar_OR(p_lotenf in lotenf%rowtype) return number is
    v_lotenf number;
  begin
    select seq_lotenfiscal.nextval
      into v_lotenf
      from dual;
  
    insert into lotenf
      (idlotenf, idtiporecebimento, descr, data, status, escaneado,
       digitado, mapaaloc, cadloteliberado, flaglibnf, cadloteaut, idusuario,
       idarmazem, iddoca, identidade, recontagem, idagendarecebimento,
       idremetente, idtransportadora, modal, placa, volumesagrupamento,
       observacao, motorista)
    values
      (v_lotenf, p_lotenf.idtiporecebimento, p_lotenf.descr, sysdate,
       nvl(p_lotenf.status, 'N'), 'N', 'N', 'N', 'N',
       nvl(p_lotenf.flaglibnf, 1), 'N', p_lotenf.idusuario,
       p_lotenf.idarmazem, p_lotenf.iddoca, p_lotenf.identidade,
       nvl(p_lotenf.recontagem, 'S'), p_lotenf.idagendarecebimento,
       p_lotenf.idremetente, p_lotenf.idtransportadora,
       nvl(p_lotenf.modal, 0), p_lotenf.placa,
       nvl(p_lotenf.volumesagrupamento, 'N'), p_lotenf.observacao,
       p_lotenf.motorista);
    return v_lotenf;
  end;

  /*
   * Verifica se ja foi iniciado o processo de alocacao dos lotes
  */
  function IniciouBaixaMapaAlocacao(p_lotenf in number) return boolean is
    cursor c_mapa(p_lotenf in number) is
      select distinct ma.status
        from orlote ol, mapaalocacao ma
       where ma.status = 'F'
         and ma.idlote = ol.idlote
         and ol.idlotenf = p_lotenf;
  
    r_mapa c_mapa%rowtype;
  begin
    if c_mapa%isopen then
      close c_mapa;
    end if;
    open c_mapa(p_lotenf);
    fetch c_mapa
      into r_mapa;
    if c_mapa%found then
      return true;
    else
      return false;
    end if;
  end;

  /*
   * Carrega as informacoes da OR
  */
  function CarregarOR(p_lotenf in number) return lotenf%rowtype is
    cursor c_lotenf(p_lotenf in number) is
      select l.idlotenf, l.idusuario, l.idportaria, l.idarmazem, l.iddoca,
             l.idclassificacao, l.idtiporecebimento, l.idusuariolib, l.placa,
             l.idtransportadora, l.motorista, l.descr, l.data,
             l.dataliberacao, l.status, l.escaneado, l.digitado,
             l.recontagem, l.formado, l.regeitado, l.mapaaloc,
             l.cadloteliberado, l.flaglibnf, l.erp, l.cadloteaut,
             l.observacao, l.identidade, l.faltamalocar,
             l.idagendarecebimento
        from lotenf l
       where l.idlotenf = p_lotenf;
  
    r_lotenf c_lotenf%rowtype;
    v_lotenf lotenf%rowtype;
  begin
    if c_lotenf%isopen then
      close c_lotenf;
    end if;
    open c_lotenf(p_lotenf);
    fetch c_lotenf
      into r_lotenf;
    if c_lotenf%found then
      v_lotenf.idlotenf            := r_lotenf.idlotenf;
      v_lotenf.idusuario           := r_lotenf.idusuario;
      v_lotenf.idportaria          := r_lotenf.idportaria;
      v_lotenf.idarmazem           := r_lotenf.idarmazem;
      v_lotenf.iddoca              := r_lotenf.iddoca;
      v_lotenf.idclassificacao     := r_lotenf.idclassificacao;
      v_lotenf.idtiporecebimento   := r_lotenf.idtiporecebimento;
      v_lotenf.idusuariolib        := r_lotenf.idusuariolib;
      v_lotenf.placa               := r_lotenf.placa;
      v_lotenf.idtransportadora    := r_lotenf.idtransportadora;
      v_lotenf.motorista           := r_lotenf.motorista;
      v_lotenf.descr               := r_lotenf.descr;
      v_lotenf.data                := r_lotenf.data;
      v_lotenf.dataliberacao       := r_lotenf.dataliberacao;
      v_lotenf.status              := r_lotenf.status;
      v_lotenf.escaneado           := r_lotenf.escaneado;
      v_lotenf.digitado            := r_lotenf.digitado;
      v_lotenf.recontagem          := r_lotenf.recontagem;
      v_lotenf.formado             := r_lotenf.formado;
      v_lotenf.regeitado           := r_lotenf.regeitado;
      v_lotenf.mapaaloc            := r_lotenf.mapaaloc;
      v_lotenf.cadloteliberado     := r_lotenf.cadloteliberado;
      v_lotenf.flaglibnf           := r_lotenf.flaglibnf;
      v_lotenf.erp                 := r_lotenf.erp;
      v_lotenf.cadloteaut          := r_lotenf.cadloteaut;
      v_lotenf.observacao          := r_lotenf.observacao;
      v_lotenf.identidade          := r_lotenf.identidade;
      v_lotenf.faltamalocar        := r_lotenf.faltamalocar;
      v_lotenf.idagendarecebimento := r_lotenf.idagendarecebimento;
      close c_lotenf;
      return v_lotenf;
    else
      close c_lotenf;
      return null;
    end if;
  end;

  /*
   * Retorna os Remetentes da OR
  */
  function Ret_Remetentes_OR
  (
    p_lotenf  in number,
    p_produto in number
  ) return varchar2 is
    cursor c_ent
    (
      p_lotenf  in number,
      p_produto in number
    ) is
      select distinct e.razaosocial
        from notafiscal nf, nfdet nfd, entidade e
       where nf.idlotenf = p_lotenf
         and e.identidade = nf.remetente
         and nfd.nf = nf.idnotafiscal
         and nfd.idproduto = p_produto;
  
    r_ent c_ent%rowtype;
    S     varchar2(10000);
  begin
    if c_ent%isopen then
      close c_ent;
    end if;
    open c_ent(p_lotenf, p_produto);
    fetch c_ent
      into r_ent;
    if c_ent%found then
      while c_ent%found
      loop
        if S is null then
          S := r_ent.razaosocial;
        else
          S := S || ',' || r_ent.razaosocial;
        end if;
        fetch c_ent
          into r_ent;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
   * Retorna os Destinatarios da OR
  */
  function Ret_Destinatarios_OR
  (
    p_lotenf  in number,
    p_produto in number
  ) return varchar2 is
    cursor c_ent
    (
      p_lotenf  in number,
      p_produto in number
    ) is
      select distinct e.razaosocial
        from notafiscal nf, nfdet nfd, entidade e
       where nf.idlotenf = p_lotenf
         and e.identidade = nf.destinatario
         and nfd.nf = nf.idnotafiscal
         and nfd.idproduto = p_produto;
  
    r_ent c_ent%rowtype;
    S     varchar2(10000);
  begin
    if c_ent%isopen then
      close c_ent;
    end if;
    open c_ent(p_lotenf, p_produto);
    fetch c_ent
      into r_ent;
    if c_ent%found then
      while c_ent%found
      loop
        if S is null then
          S := r_ent.razaosocial;
        else
          S := S || ',' || r_ent.razaosocial;
        end if;
        fetch c_ent
          into r_ent;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
   * Retorna as Notas Fiscais da OR
  */
  function Ret_NF_OR
  (
    p_lotenf  in number,
    p_produto in number := -1
  ) return varchar2 is
    cursor c_nf
    (
      p_lotenf  in number,
      p_produto in number
    ) is
      select distinct codigointerno
        from notafiscal nf, nfdet nfd
       where nf.idlotenf = p_lotenf
         and nfd.nf = nf.idnotafiscal
         and nfd.idproduto = p_produto;
  
    cursor c_nfor(p_lotenf in number) is
      select distinct codigointerno
        from notafiscal nf, nfdet nfd
       where nf.idlotenf = p_lotenf
         and nfd.nf = nf.idnotafiscal;
  
    r_nf c_nf%rowtype;
    S    varchar2(10000);
  begin
    if p_produto = -1 then
      if c_nfor%isopen then
        close c_nfor;
      end if;
      open c_nfor(p_lotenf);
      fetch c_nfor
        into r_nf;
      if c_nfor%found then
        while c_nfor%found
        loop
          if S is null then
            S := r_nf.codigointerno;
          else
            S := S || ',' || r_nf.codigointerno;
          end if;
          fetch c_nfor
            into r_nf;
        end loop;
        return S;
      else
        return '';
      end if;
    else
      if c_nf%isopen then
        close c_nf;
      end if;
      open c_nf(p_lotenf, p_produto);
      fetch c_nf
        into r_nf;
      if c_nf%found then
        while c_nf%found
        loop
          if S is null then
            S := r_nf.codigointerno;
          else
            S := S || ',' || r_nf.codigointerno;
          end if;
          fetch c_nf
            into r_nf;
        end loop;
        return S;
      else
        return '';
      end if;
    end if;
  end;

  procedure Criar_OR_VincularNF
  (
    p_idnotafiscal in number,
    p_idusuario    in number,
    p_tituloor     in varchar2,
    p_idlotenf     out number,
    p_commit       in string
  ) is
    cursor c_tiporec is
      select t.idtiporecebimento, t.classificacao
        from tiporecebimento t
       where t.classificacao = 'R';
  
    cursor c_nf(p_notafiscal in number) is
      select nf.iddepositante, d.controlaareaespera
        from notafiscal nf, depositante d
       where d.identidade = nf.iddepositante
         and idnotafiscal = p_notafiscal;
  
    cursor c_arm(p_idnotafiscal in number) is
      select rp.idarmazem, rp.iddoca, o.*
        from ocorrenciaentrega o, notafiscalcarga nfc,
             (select idnotafiscal, max(idromaneio) idromaneio
                 from nfromaneio
                group by idnotafiscal) nfr, romaneiopai rp
       where rp.idromaneio = nfr.idromaneio
         and nfr.idnotafiscal = nfc.idnotafiscal
         and nfc.idcarga = o.idcarga
         and nfc.idnotafiscal = o.idnotafiscal
         and o.finalizado = 'N'
         and o.idnotafiscal = p_idnotafiscal;
  
    --Processo 82050: Ao retirar NF do Romaneio verificar parâmetro do Depositante, se controla área de espera e controla área de espera na retirada de NF
    /*    cursor c_retnf(p_idnotafiscal in number) is
    select rp.idarmazem, rp.iddoca
      from nfromaneio nfr, romaneiopai rp
     where rp.idromaneio = nfr.idromaneio
       and nfr.idnotafiscal = p_idnotafiscal
       and nfr.idromaneio in
           (select max(idromaneio)
              from nfromaneio
             where idnotafiscal = nfr.idnotafiscal);*/
  
    r_tiporec c_tiporec%rowtype;
    r_lotenf  lotenf%rowtype;
    r_arm     c_arm%rowtype;
    --r_retnf              c_retnf%rowtype;
    v_lotenf             number;
    v_depositante        number;
    v_mapaaloc           char(1);
    v_controlaareaespera char(1);
    v_msg_erro           varchar2(1000);
    v_doca               doca%rowtype;
  begin
  
    -- pega o tipo de recebimento
    if c_tiporec%isopen then
      close c_tiporec;
    end if;
    open c_tiporec;
    fetch c_tiporec
      into r_tiporec;
    if c_tiporec%notfound then
      v_msg := t_message('NAO FOI LOCALIZADO TIPO DE RECEBIMENTO DE REENTREGA PARA A OR.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- pega armazem e doca
    if c_arm%isopen then
      close c_arm;
    end if;
    open c_arm(p_idnotafiscal);
    fetch c_arm
      into r_arm;
  
    /*if c_retnf%isopen then
      close c_retnf;
    end if;
    open c_retnf(p_idnotafiscal);
    fetch c_retnf
      into r_retnf;*/
  
    if r_arm.idarmazem is null then
      v_msg := t_message('NAO FOI LOCALIZADO ARMAZEM PARA A OR.');
      raise_application_error(-20000, v_msg.formatMessage);
    elsif r_arm.iddoca is null then
      v_doca       := pk_armazem.pegardocapadrao(r_arm.idarmazem);
      r_arm.iddoca := v_doca.iddoca;
    end if;
  
    -- pega depositante da nota fiscal
    if c_nf%isopen then
      close c_nf;
    end if;
    open c_nf(p_idnotafiscal);
    fetch c_nf
      into v_depositante, v_controlaareaespera;
  
    -- cadastra a OR
    r_lotenf.idtiporecebimento := r_tiporec.idtiporecebimento;
    r_lotenf.descr             := p_tituloor;
    r_lotenf.data              := sysdate;
    r_lotenf.idusuario         := p_idusuario;
    r_lotenf.idarmazem         := r_arm.idarmazem;
    r_lotenf.iddoca            := r_arm.iddoca;
    r_lotenf.identidade        := v_depositante;
    r_lotenf.recontagem        := 'S';
    v_lotenf                   := pk_recebimento.cadastrar_OR(r_lotenf);
  
    -- Cria nf de entrada
    pk_notafiscal.p_gerarNFEntrada(p_idnotafiscal, 'N');
  
    -- Vincula nf a OR
    update notafiscal nf
       set idlotenf = v_lotenf
     where idnotafiscalvinculada = p_idnotafiscal
       and tipo = 'E'
       and idlotenf is null;
  
    p_idlotenf := v_lotenf;
  
    pk_recebimento.Atualizar_Produtos_OR(v_lotenf, 'N');
  
    if (v_controlaareaespera = 'N') then
      -- gera a OR e aloca os materiais
      GerarContagem(v_lotenf, p_idusuario);
    
      pk_lote.gerar_lote(v_lotenf, p_idusuario);
    
      pk_alocacao.planejarArmazenagem(v_lotenf, p_idusuario);
    
      select l.mapaaloc
        into v_mapaaloc
        from lotenf l
       where l.idlotenf = v_lotenf;
    
      if v_mapaaloc = 'S' then
      
        for c_mapa in (select mp.idalocacao
                         from orlote ol, mapaalocacao mp
                        where mp.idlote = ol.idlote
                          and ol.idlotenf = v_lotenf)
        loop
          pk_alocacao.alocar_mapaalocacao(c_mapa.idalocacao, p_idusuario,
                                          'N');
        end loop;
      
        pk_notafiscal.GerarSeparacaoEspecifica(p_idnotafiscal,
                                               v_depositante, 'S', 'S');
      else
        for c_prod_setor in (select nd.idproduto
                               from nfdet nd, notafiscal nf, lotenf ln
                              where nf.idnotafiscal = nd.nf
                                and ln.idlotenf = nf.idlotenf
                                and ln.idlotenf = p_idlotenf
                                and not exists
                              (select 1
                                       from setorproduto sp,
                                            setorrecebimento sr,
                                            tiporecebimento tr
                                      where sr.idsetor = sp.idsetor
                                        and tr.idtiporecebimento =
                                            sr.idtiporecebimento
                                        and tr.classificacao = 'R'
                                        and sp.idproduto = nd.idproduto))
        loop
          if v_msg_erro is null then
            v_msg_erro := c_prod_setor.idproduto;
          else
            v_msg_erro := v_msg_erro || ', ' || c_prod_setor.idproduto;
          end if;
        end loop;
        if v_msg_erro is null then
          v_msg := t_message('OCORREU ERRO AO GERAR A ALOCAÇÃO DOS PRODUTO PARA REENTREGA.' ||
                             CHR(13) ||
                             'VERIFICAR LOCAIS DO SETOR DE REENTREGA. OPERACAO CANCELADA.');
          raise_application_error(-20000, v_msg.formatMessage);
        else
          v_msg := t_message('O(S) PRODUTO(S) DE ID: {0}' ||
                             ' NÃO SE ENCONTRAM VINCULADOS A UM SETOR DE REENTREGA. OPERACAO CANCELADA.');
          v_msg.addParam(v_msg_erro);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end if;
  
    if p_commit = 'S' then
      commit;
    end if;
  end;

  /*
   * Verifica se todos os valores da OR foram informados
  */
  function ChecaValoresOR(p_idlotenf in lotenf.idlotenf%type) return number is
    v_qtdevalores number;
  begin
    select count(*)
      into v_qtdevalores
      from notafiscal dm, nfdet nfd, produto p, embalagem e
     where dm.idlotenf = p_idlotenf
       and nfd.nf = dm.idnotafiscal
       and p.idproduto = nfd.idproduto
       and e.idproduto = nfd.idproduto
       and e.barra = nfd.barra
       and nvl(nfd.valordefinido, 'N') = 'N';
  
    if v_qtdevalores > 0 then
      update lotenf
         set valordefinido = 'N'
       where idlotenf = p_idlotenf;
    else
      update lotenf
         set valordefinido = 'S'
       where idlotenf = p_idlotenf;
    end if;
    return v_qtdevalores;
  end;

  /*
  Rotina criada para verificar se algum produto da OR 
  controla informação específica com rastramento ENTRADA e SAIDA
  e encontra-se sendo inventariado
  */
  procedure verificaORProdInfEspEmInv
  (
    p_idOR in number,
    p_tipo in number
  ) is
    RASTREABLIBILIDA_ENTRADA_SAIDA constant number := 1;
    ESTORNAROR                     constant number := 0;
    GERARLOTES                     constant number := 1;
  
    v_mensagem      varchar2(4000);
    v_mensagemRaise varchar2(4000);
    v_inventarios   varchar2(4000);
    v_qtdeProd      number;
  begin
    v_qtdeProd := 0;
  
    for c_prodOr in (select l.idproduto, p.codigointerno codprod,
                            p.descr produto, pd.identidade
                       from orlote ol, lote l, produtodepositante pd,
                            produto p
                      where ol.idlotenf = p_idOR
                        and l.idlote = ol.idlote
                        and pd.idproduto = l.idproduto
                        and pd.identidade = l.iddepositante
                        and p.idproduto = l.idproduto
                        and pd.rastrearinfoespecifica =
                            RASTREABLIBILIDA_ENTRADA_SAIDA
                        and exists
                      (select 1
                               from informacaomatdep id
                              where id.identidade = pd.identidade
                                and id.idproduto = pd.idproduto)
                      group by l.idproduto, p.codigointerno, p.descr,
                               pd.identidade)
    loop
      v_inventarios := pk_inventario_planejado.retInvEmAndamentoComProd(c_prodOR.idproduto,
                                                                        c_prodOR.identidade);
    
      if v_inventarios is not null then
        v_qtdeProd := v_qtdeProd + 1;
      
        if v_mensagem is null then
          v_msg := t_message('Produto: {0}, Código: {1}, id: {2}' ||
                             ', Inventário(s): {3}');
          v_msg.addParam(c_prodOr.produto);
          v_msg.addParam(c_prodOr.Codprod);
          v_msg.addParam(c_prodOr.Idproduto);
          v_msg.addParam(v_inventarios);
          v_mensagem := v_msg.formatMessage;
        
        else
          v_msg := t_message('{0}' || chr(13) || 'Produto: {1},' ||
                             ' Código: {2}, id: {3}, Inventário(s): {4}');
          v_msg.addParam(v_mensagem);
          v_msg.addParam(c_prodOr.Produto);
          v_msg.addParam(c_prodOr.Codprod);
          v_msg.addParam(c_prodOr.Idproduto);
          v_msg.addParam(v_inventarios);
          v_mensagem := v_msg.formatMessage;
        end if;
      end if;
    end loop;
  
    if v_qtdeProd > 0 then
      v_mensagemRaise := case
                           when p_tipo = ESTORNAROR then
                            'Estorno de OR não permitido. '
                           when p_tipo = GERARLOTES then
                            'Geração de lotes não permitida. '
                           else
                            'Operação não permitida. '
                         end || case
                           when v_qtdeProd = 1 then
                            'O produto'
                           else
                            'Os produtos'
                         end || ' abaixo ' || case
                           when v_qtdeProd = 1 then
                            'controla'
                           else
                            'controlam'
                         end ||
                         ' informação específica com o tipo de rastreabilidade "Entrada e Saída"' ||
                         ' e ' || case
                           when v_qtdeProd = 1 then
                            'está'
                           else
                            'estão'
                         end || ' sendo ' || case
                           when v_qtdeProd = 1 then
                            'inventariado.'
                           else
                            'inventariados.'
                         end;
    
      v_msg           := t_message(v_mensagemRaise);
      v_mensagemRaise := v_msg.formatMessage || chr(13) || v_mensagem;
      raise_application_error(-20000, v_mensagemRaise);
    end if;
  end;

  /*
   * Rotina responsável por estornar a alocação e as movimentações de entrada 
     mesmo que a OR tenha gerado estoque.
  */
  procedure estornarRecebimento
  (
    p_idOR      in lotenf.idlotenf%type,
    p_idUsuario in number
  ) is
  
    type t_estRecebimento is record(
      mapaaloc                  lotenf.mapaaloc%type,
      faltamalocar              lotenf.faltamalocar%type,
      status                    lotenf.status%type,
      classificacao             tiporecebimento.classificacao%type,
      transferenciatitularidade tiporecebimento.transferenciatitularidade%type,
      gerarloteporconferencia   tiporecebimento.gerarloteporpalete%type,
      orDeInventario            number,
      orLoteInventario          number,
      orPossuiOPA               number,
      possuiMovimetacao         number);
  
    r_estRecebimento t_estRecebimento;
  
    RAISE_FLUXO_CROSSDOCKING exception;
  
    procedure carregarDados is
    begin
    
      select l.mapaaloc, l.faltamalocar, l.status, tr.classificacao,
             tr.transferenciatitularidade, tr.gerarloteporpalete,
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal
                        where idinventario is not null
                          and idlotenf = l.idlotenf)) orDeInventario,
             (select count(*)
                 from dual
                where exists (select 1
                         from orlote ol, lote lo, invest i
                        where ol.idlotenf = l.idlotenf
                          and lo.idlote = ol.idlote
                          and i.idlote = lo.idlote)) orLoteInventario,
             (select count(*)
                 from dual
                where exists (select 1
                         from notafiscal nf, nfdet nd, itemopanfdet i
                        where nf.idlotenf = l.idlotenf
                          and nd.nf = nf.idnotafiscal
                          and i.idnfdet = nd.idnfdet)) orPossuiOPA
        into r_estRecebimento.mapaaloc, r_estRecebimento.faltamalocar,
             r_estRecebimento.status, r_estRecebimento.classificacao,
             r_estRecebimento.transferenciatitularidade,
             r_estRecebimento.gerarloteporconferencia,
             r_estRecebimento.orDeInventario,
             r_estRecebimento.orLoteInventario, r_estRecebimento.orPossuiOPA
        from lotenf l, tiporecebimento tr
       where l.idlotenf = p_idOR
         and tr.idtiporecebimento = l.idtiporecebimento;
    
    end carregarDados;
  
    procedure realizarLockDaOR is
    begin
      -- Realizando lock para impossibilitar concorrência entre a exclusão de lotes e estorno de OR
      select lnf.status
        into r_estRecebimento.status
        from lotenf lnf
       where lnf.idlotenf = p_idOR
         for update;
    
    end realizarLockDaOR;
  
    procedure validacoes is
    
      function isPossuiMovimetacao return boolean is
        v_possuiMovimetacao number;
      begin
        select count(*)
          into v_possuiMovimetacao
          from dual
         where exists
         (select 1
                  from (select l.idlote,
                                sum(l.qtdeentrada * e.fatorconversao) qtdeentrada
                           from orlote ol, lote l, embalagem e, mapaalocacao m
                          where ol.idlotenf = p_idOR
                            and l.idlote = ol.idlote
                            and e.idproduto = l.idproduto
                            and e.barra = l.barra
                            and l.tipolote != 'P'
                            and m.idlote = l.idlote
                            and m.status = 'F'
                          group by l.idlote) ent,
                       (select v.lote idlote, sum(v.disp) disp
                           from orlote ol, lote l, v_estoquelocallote v
                          where ol.idlotenf = p_idOR
                            and l.idlote = ol.idlote
                            and v.lote = l.idlote
                          group by v.lote) est
                 where est.idlote(+) = ent.idlote
                   and nvl(est.disp, 0) <> ent.qtdeentrada);
      
        return v_possuiMovimetacao = 1;
      end isPossuiMovimetacao;
    
      function isTemMovOnda return boolean is
        v_temMovOnda number;
      begin
        select count(*)
          into v_temMovOnda
          from dual
         where exists (select 1
                  from orlote ol, movimentacao m
                 where m.idlote = ol.idlote
                   and ol.idlotenf = p_idOR
                   and m.status <> 3);
      
        return v_temMovOnda > 0;
      end;
    
      function ispossuiOScomOnda return boolean is
        v_temOS number;
      begin
        select count(*)
          into v_temOS
          from dual
         where exists (select 1
                  from ordemservico os, romaneiopai rp
                 where os.idlotenf = p_idOR
                   and rp.idromaneio = os.idromaneio
                   and rp.tipo = 1);
      
        return v_temOS > 0;
      end ispossuiOScomOnda;
    
      procedure verificarImpactoSepEspecifica is
        v_NfsAfetadas  varchar2(4000);
        v_Lotes        varchar2(4000);
        v_msgValidacao t_message;
      begin
        delete from gtt_aux;
        insert into gtt_aux
          (valor1)
          select sep.id
            from separacaoespecifica sep
           where exists (select 1
                    from notafiscal nf
                   where nf.tipo = 'S'
                     and nf.statusnf in ('N', 'C', 'I', 'B')
                     and sep.idnotafiscal = nf.idnotafiscal)
             and exists (select 1
                    from orlote ol, lote lt
                   where ol.idlotenf = p_idOr
                     and lt.idlote = ol.idlote
                     and lt.tipolote = 'L'
                     and lt.idpalet is null
                     and lt.idlote = sep.idlote
                  union
                  select 1
                    from orlote ol, lote lp, lote lt
                   where ol.idlotenf = p_idOr
                     and lp.idlote = ol.idlote
                     and lp.tipolote = 'P'
                     and lt.idpalet = lp.idlote
                     and lt.tipolote = 'L'
                     and lt.idlote = sep.idlote);
      
        if ((sql%rowcount) > 0) then
        
          select stragg(sep.idlote)
            into v_Lotes
            from gtt_aux g, separacaoespecifica sep
           where sep.id = g.valor1;
        
          select stragg(nf.codigointerno)
            into v_NfsAfetadas
            from notafiscal nf
           where nf.idnotafiscal in
                 (select sep.idnotafiscal
                    from gtt_aux g, separacaoespecifica sep
                   where sep.id = g.valor1);
        
          v_msgValidacao := t_message('A Ordem de Recebimento Id: {0} não pode ser estornada em função da(s) Nota/Pedido(s): {1} possuir Separação Específica do(s) seguinte(s) lote(s) {2}.' ||
                                      chr(13) ||
                                      'Para executar este estorno avalie as Separações Específicas indicadas.');
          v_msgValidacao.addParam(p_idOr);
          v_msgValidacao.addParam(v_NfsAfetadas);
          v_msgValidacao.addParam(v_Lotes);
          raise_application_error(-20000, v_msgValidacao.formatMessage);
        end if;
      exception
        when no_data_found then
          return;
      end verificarImpactoSepEspecifica;
    
    begin
    
      if (r_estRecebimento.mapaaloc = 'N' and
         nvl(v_exclusao_or_conf_aloc, 'N') = 'N') then
        v_msg := t_message('A Ordem de Recebimento {0} não possui todos os mapas de alocação gerados. Operação não permitida.');
        v_msg.addParam(p_idOR);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_exclusao_or_conf_aloc = 'N'
         and isConferenciaAlocada(p_idOR) then
        v_msg := t_message('Ação não pode ser executada pois a OR é do Tipo de Recebimento de Conferência Alocada.');
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      if (r_estRecebimento.ORDeInventario = 1) then
        v_msg := t_message('OR DE INVENTÁRIO NÃO PODE SER ESTORNADA. OPERACAO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_estRecebimento.OrPossuiOPA = 1) then
        v_msg := t_message('OR POSSUI UMA OU MAIS NOTAS VINCULADAS A UMA ORDEM DE COMPRA. NÃO PODE SER ESTORNADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_estrecebimento.transferenciatitularidade = 1) then
        v_msg := t_message('ORDEM DE RECEBIMENTO GERADA PELA TRANSFERÊNCIA DE TITULARIDADE. NÃO PODE SER ESTORNADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_estrecebimento.classificacao = 'B') then
        raise RAISE_FLUXO_CROSSDOCKING;
      end if;
    
      if (isTemMovOnda) then
        v_msg := t_message('A Ordem de Recebimento possui lotes que já foram utilizados em onda de separação. ' ||
                           'Operação Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_estRecebimento.orLoteInventario = 1) then
        v_msg := t_message('A Ordem de Recebimento possui lotes que já foram utilizados em invetário. ' ||
                           'Operação Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if not (r_estRecebimento.status = 'P' or v_exclusao_or_conf_aloc = 'S' or
          r_estRecebimento.gerarloteporconferencia = 1) then
        v_msg := t_message('SOMENTE OR PROCESSADA PODE SER ESTORNADA. OPERACAO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (ispossuiMovimetacao) then
        v_msg := t_message('LOTES PRESENTES NA OR POSSUEM MOVIMENTACAO INTERNA OU FORAM EXPEDIDOS. OPERACAO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      verificarImpactoSepEspecifica;
    
      -- Validar se a OR possui produto com informação especifica com rastreabilidade ENTRADA E SAIDA e
      -- se existe inventário, JÁ LIBERADO E NÃO ATUALIZADO, com contagem ou planejamento deste produto
      verificaORProdInfEspEmInv(p_idOR, 0);
    
      --Rotina de estorno de OR de OS não está preparada para retornar o estoque expedido,
      --o qual, quando expedido por onda é processado no momento da alocação
      if (ispossuiOScomOnda) then
        v_msg := t_message('Não é permitido o estorno de OR de Ordem de Serviço com expedição por Onda. Operação Cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validacoes;
  
    procedure estornarAlocacaoCrossdocking is
    
      type t_estCrossdocking is record(
        idarmazem         number,
        idlocalalocacao   local.idlocal%type,
        idromaneio        number,
        idendereco        number,
        idcarga           number,
        idnotafiscalsaida number);
    
      r_estCrossdocking t_estCrossdocking;
    
      procedure carregarDados is
      begin
        select dc.idendereco, nfr.idromaneio, l.idlocal, l.idarmazem,
               nfc.idcarga, nfs.idnotafiscal
          into r_estCrossdocking.idendereco, r_estCrossdocking.idromaneio,
               r_estCrossdocking.idlocalalocacao,
               r_estCrossdocking.idarmazem, r_estCrossdocking.idcarga,
               r_estCrossdocking.idnotafiscalsaida
          from lotenf lnf, notafiscal nfe, notafiscal nfs, doca dc,
               nfromaneio nfr, local l, notafiscalcarga nfc
         where lnf.idlotenf = p_idor
           and nfe.idlotenf = lnf.idlotenf
           and nfs.idnotafiscal = nfe.idnotafiscalvinculada
           and dc.iddoca = lnf.iddoca
           and nfr.idnotafiscal = nfs.idnotafiscal
           and l.id = dc.idendereco
           and nfc.idnotafiscal(+) = nfr.idnotafiscal;
      
      end carregarDados;
    
      -- Refactored procedure estornarEstoqueCrossdocking 
      procedure estornarEstoqueCrossdocking is
      begin
        for c in (select ll.idarmazem, ll.idlocal, ll.idlote, ll.estoque,
                         nvl(l.idencomenda, 0) encomenda, lo.tipo tipoLocal,
                         lo.buffer localBuffer, lt.idproduto,
                         lt.iddepositante
                    from orlote ol, lotelocal ll, lote l, local lo, lote lt
                   where ol.idlotenf = p_idor
                     and ll.idlote = ol.idlote
                     and l.idlote = ol.idlote
                     and ll.estoque > 0
                     and lo.idlocal = ll.idlocal
                     and lo.idarmazem = ll.idarmazem
                     and lt.idlote = ll.idlote)
        loop
          -- é dado o update antes para registrar o log na historico estoque
          pk_estoque.retirar_estoque(c.idarmazem, c.idlocal, c.idlote,
                                     c.estoque, p_idusuario,
                                     'ESTOQUE RETIRADO EM FUNÇÃO DO ESTORNO DA OR DE CROSSDOCKING: ' ||
                                      p_idor);
        
          if ((c.Tipolocal = 0) AND (c.localbuffer = 'N')) then
            pk_picking_dinamico.addGttPickingDinamico(c.idproduto,
                                                      c.iddepositante,
                                                      c.idlocal, c.idarmazem,
                                                      0);
          end if;
        
          delete from lotelocal
           where idarmazem = c.idarmazem
             and idlote = c.idlote;
        
          delete from historicoestoque
           where idarmazem = c.idarmazem
             and idlote = c.idlote;
        end loop;
      
        pk_picking_dinamico.deletar_picking_dinamico;
      
      end estornarEstoqueCrossdocking;
    
      procedure atualizarStatus is
      begin
        update lote l
           set l.situacao          = 'R',
               l.dtalocacao        = null,
               l.idusuarioalocacao = null,
               l.qtdealocada       = 0
         where exists (select 1
                  from orlote
                 where idlotenf = p_idOR
                   and idlote = l.idlote);
      
        update mapaalocacao m
           set m.status            = 'P',
               m.dataalocacao      = null,
               m.idusuarioalocacao = null,
               m.alocado           = 0,
               m.idlocal           = r_estCrossdocking.idlocalalocacao,
               m.idarmazem         = r_estCrossdocking.idarmazem
         where exists (select 1
                  from orlote
                 where idlotenf = p_idor
                   and idlote = m.idlote);
      
        --voltando status onda  
        update romaneiopai rp
           set rp.statusonda           = 0,
               rp.liberado             = 'N',
               rp.pesagemliberada      = 'N',
               rp.separado             = 'N',
               rp.faturado             = 'N',
               rp.idusuariolibpesagem  = null,
               rp.idusuarioseparacao   = null,
               rp.idusuarioconferencia = null,
               rp.dataliberacao        = null,
               rp.dataliberacaoonda    = null,
               rp.dtpesagemliberada    = null,
               rp.datainicioseparacao  = null,
               rp.datafinalseparacao   = null
         where rp.idromaneio = r_estCrossdocking.idromaneio;
      
        --formacao da onda quais valores serão setados na movimentacao
        update movimentacao m
           set m.qtdemovimentada = 0,
               m.quantidade      = 0,
               m.qtdeemvolume    = 0,
               m.qtdeconferida   = 0,
               m.idlocalorigem   = r_estCrossdocking.idendereco,
               m.idlocaldestino  = r_estCrossdocking.idendereco,
               m.status          = 0,
               m.etapa           = 1
         where m.idonda = r_estCrossdocking.idromaneio;
      
        -- Alterar o status da OR para Pendente
        update lotenf
           set status           = 'N',
               mapaaloc         = 'N',
               dtinicioalocacao = null,
               dtfimalocacao    = null,
               faltamalocar     = -1
         where idlotenf = p_idOR;
      
        -- Remover idVolumeRomaneio do Contentor Recebimento  
        update contentorrecebimento cr
           set cr.idvolumeromaneio = null
         where cr.idlotenf = p_idor;
      
        -- Remover notafiscalcarga
        if r_estCrossdocking.idcarga is not null then
          delete notafiscalcarga nfc
           where nfc.idcarga = r_estCrossdocking.idcarga
             and nfc.idnotafiscal = r_estCrossdocking.idnotafiscalsaida;
        end if;
      end atualizarStatus;
    
    begin
    
      carregarDados;
    
      estornarEstoqueCrossdocking;
    
      atualizarStatus;
    
    end estornarAlocacaoCrossdocking;
  
    procedure fluxoGeraLoteNaConferencia is
    begin
    
      if (r_estRecebimento.gerarloteporconferencia = 0) then
        return;
      end if;
    
      insert into gtt_mapaalocacao_or
        (idlotenf, idusuario, depositante, idlote, codproduto, produto,
         qtde, embalagem, fatorconversao, idlocalformatado, tipolocal, setor,
         idalocacao)
        select p_idOR, p_idUsuario, dep.razaosocial depositante, lt.idlote,
               p.codigointerno codproduto, p.descr produto,
               nvl(ma.qtde, 0) qtde, emb.descrreduzido embalagem,
               emb.fatorconversao, l.idlocalformatado idlocal,
               decode(l.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                       'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5,
                       'AUDITORIA', 6, 'RUA EXPEDICAO', 7, 'STAGE', 8,
                       'PACKING') tipolocal, s.descr setor, ma.idalocacao
          from orlote ol, lote lt, mapaalocacao ma, entidade dep, produto p,
               produtodepositante pd, embalagem emb, local l, setor s
         where ol.idlotenf = p_idOR
           and lt.idlote = ol.idlote
           and ma.idlote = lt.idlote
           and ma.status = 'F'
           and dep.identidade = lt.iddepositante
           and pd.idproduto = lt.idproduto
           and pd.identidade = lt.iddepositante
           and emb.idproduto = p.idproduto
           and emb.barra = lt.barra
           and l.idlocal = ma.idlocal
           and l.idarmazem = ma.idarmazem
           and s.idsetor = l.idsetor;
    
    end fluxoGeraLoteNaConferencia;
  
    procedure alocarMapasFaltantes is
    begin
    
      for c_mapa_pend in (select m.idalocacao
                            from lotenf l, orlote ol, tiporecebimento tr,
                                 mapaalocacao m
                           where l.idlotenf = p_idor
                             and ol.idlotenf = l.idlotenf
                             and tr.idtiporecebimento = l.idtiporecebimento
                             and tr.classificacao <> 'M'
                             and m.idlote = ol.idlote
                             and m.status not in ('F', 'X'))
      loop
        update mapaalocacao
           set status = 'M'
         where idalocacao = c_mapa_pend.idalocacao;
      
        pk_alocacao.alocar_mapaalocacao(c_mapa_pend.idalocacao, p_idUsuario);
      end loop;
    
    end alocarMapasFaltantes;
  
    procedure estornarRemanejamento is
    begin
      for c_rem in (select ent.idlote, lr.idremanejamento
                      from (select l.idlote,
                                    l.qtdeentrada * e.fatorconversao qtdeentrada
                               from orlote ol, lote l, embalagem e
                              where ol.idlotenf = p_idOR
                                and l.idlote = ol.idlote
                                and e.idproduto = l.idproduto
                                and e.barra = l.barra
                              order by l.idlote, l.idproduto) ent,
                           (select idlote, idremanejamento
                               from loteremanejamento lr) lr
                     where lr.idlote = ent.idlote)
      loop
        update loteremanejamento
           set estorno = 1
         where idremanejamento = c_rem.idremanejamento
           and idlote = c_rem.idlote;
      
        delete from loteremanejamento
         where idremanejamento = c_rem.idremanejamento
           and idlote = c_rem.idlote;
      
        delete from remanejamentoromaneio rr
         where not exists (select 1
                  from romaneiopai rp
                 where rp.idromaneio = rr.idromaneio
                   and rp.statusonda <> 5)
           and rr.idremanejamento = c_rem.idremanejamento;
      
        update remanejamento
           set estorno = 1
         where not exists (select 1
                  from loteremanejamento lr
                 where lr.idremanejamento = c_rem.idremanejamento)
           and idremanejamento = c_rem.idremanejamento;
      
        delete from remanejamento
         where not exists (select 1
                  from loteremanejamento lr
                 where lr.idremanejamento = c_rem.idremanejamento)
           and idremanejamento = c_rem.idremanejamento;
      end loop;
    end estornarRemanejamento;
  
    procedure retirarLotedoEstoque is
    begin
      -- retira os lotes do estoque
      for c in (select ll.idarmazem, ll.idlocal, ll.idlote, ll.estoque,
                       nvl(l.idencomenda, 0) encomenda, lo.tipo tipoLocal,
                       lo.buffer localBuffer, lt.idproduto, lt.iddepositante
                  from orlote ol, lotelocal ll, lote l, local lo, lote lt
                 where ol.idlotenf = p_idor
                   and ll.idlote = ol.idlote
                   and l.idlote = ol.idlote
                   and ll.estoque > 0
                   and lo.idlocal = ll.idlocal
                   and lo.idarmazem = ll.idarmazem
                   and lt.idlote = ll.idlote)
      loop
        -- é dado o update antes para registrar o log na historico estoque
        pk_estoque.retirar_estoque(c.idarmazem, c.idlocal, c.idlote,
                                   c.estoque, p_idUsuario,
                                   'ESTOQUE RETIRADO EM FUNÇÃO DO ESTORNO DA OR: ' ||
                                    p_idOR, 'N');
      
        if ((c.tipoLocal = 0) and (c.localBuffer = 'N')) then
          pk_picking_dinamico.addGttPickingDinamico(c.idproduto,
                                                    c.iddepositante,
                                                    c.idlocal, c.idarmazem,
                                                    0);
        end if;
      
        delete from lotelocal
         where idarmazem = c.idarmazem
           and idlote = c.idlote
           and idlocal = c.idlocal;
      
        delete from historicoestoque
         where idarmazem = c.idarmazem
           and idlote = c.idlote;
      
        update encomenda e
           set e.qtdealocada = e.qtdealocada - c.estoque
         where e.id = c.encomenda;
      end loop;
    
      if not pk_recebimento.isConferenciaAlocada(p_idor) then
        pk_picking_dinamico.deletar_picking_dinamico;
      end if;
    
      delete from lotelocal ll
       where (ll.estoque + ll.adicionar + ll.pendencia) = 0
         and ll.idlote in (select ol.idlote
                             from orlote ol
                            where ol.idlotenf = p_idor);
    
      update lote l
         set l.situacao          = 'R',
             l.qtdealocada       = 0,
             l.dtalocacao        = null,
             l.idusuarioalocacao = null
       where exists (select 1
                from orlote
               where idlotenf = p_idOR
                 and idlote = l.idlote);
    
      delete mapaalocacao m
       where exists (select 1
                from orlote
               where idlotenf = p_idOR
                 and idlote = m.idlote);
    end retirarLotedoEstoque;
  
    procedure atualizarStatusParaPendente is
    begin
    
      update lotenf
         set status           = 'N',
             mapaaloc         = 'N',
             dtinicioalocacao = null,
             dtfimalocacao    = null,
             faltamalocar     = -1
       where idlotenf = p_idOR;
    
      for c_nf in (select nf.idprenf
                     from notafiscal nf
                    where nf.idlotenf = p_idOR
                      and nvl(nf.sequencia, '0') <> 'AGCOB'
                      and not exists
                    (select 1
                             from nfimpressao nfi
                            where nfi.idprenf = nf.idprenf
                              and nfi.origemintegracao = 3
                              and nvl(nfi.statusinboundasn, 0) = 1))
      loop
        update notafiscal nf
           set nf.statusnf = 'C'
         where nf.idprenf = c_nf.idprenf;
      
        update nfimpressao nfi
           set nfi.status = 'N'
         where nfi.idprenf = c_nf.idprenf;
      end loop;
    end atualizarStatusParaPendente;
  
    procedure estornarOrdemServico is
      C_SITUACAO_LIB_ALOC   constant char(1) := 'B';
      C_SITUACAO_EM_ALOC    constant char(1) := 'O';
      C_SITUACAO_FINALIZADO constant char(1) := 'F';
    begin
      for c_ordem in (select o.idordemservico
                        from ordemservico o
                       where o.idlotenf = p_idOR)
      loop
        update ordemservico o
           set o.situacao = 'T'
         where o.idordemservico = c_ordem.idordemservico
           and o.situacao in (C_SITUACAO_LIB_ALOC, C_SITUACAO_EM_ALOC,
                              C_SITUACAO_FINALIZADO);
      end loop;
    end estornarOrdemServico;
  
    procedure estornarDetLoteConferencia is
    begin
    
      if (r_estRecebimento.gerarloteporconferencia = 0) then
        return;
      end if;
    
      delete from origemlotedetalhado o
       where exists (select 1
                from orlote ol
               where ol.idlotenf = p_idOR
                 and o.idlote = ol.idlote);
    
      delete from origemlote o
       where exists (select 1
                from orlote ol
               where ol.idlotenf = p_idOR
                 and o.idlote = ol.idlote);
    
      delete from coberturalotedispnf
       where idlotenf = p_idOR;
    
      delete from coberturalote co
       where co.idlotenf = p_idOR;
    end estornarDetLoteConferencia;
  
    procedure estornarOrdemTransferencia is
    begin
      for c_result in (select distinct ot.idordemtransferencia, ot.status
                         from tdnitemnfdet td, ordemtransferenciaitem oti,
                              ordemtransferencia ot
                        where td.idordemtransferenciaitem =
                              oti.idordemtransferenciaitem
                          and ot.idordemtransferencia =
                              oti.idordemtransferencia
                          and td.idlotenf = p_idOR)
      loop
        if (c_result.status = 1) then
          v_msg := t_message('NÃO É POSSÍVEL ESTORNAR ORDEM DE RECEBIMENTO COM UMA OU MAIS ORDEM DE TRANSFERÊNCIA FINALIZADA.');
          raise_application_error(-20100, v_msg.formatMessage);
        end if;
      end loop;
    
      update tdnitemnfdet td
         set td.qtdealocada = null,
             td.idlotenf    = null
       where td.idlotenf = p_idOR;
    end estornarOrdemTransferencia;
  
    procedure expEstornoMudSetor is
      v_integrarerpsenior         depositante.integrarerpsenior%type;
      v_integrardepositoerpsenior depositante.integrardepositoerpsenior%type;
    begin
      select d.integrarerpsenior, d.integrardepositoerpsenior
        into v_integrarerpsenior, v_integrardepositoerpsenior
        from depositante d, lotenf lnf
       where d.identidade = lnf.identidade
         and lnf.idlotenf = p_idOR;
    
      if ((v_integrarerpsenior = 1) and (v_integrardepositoerpsenior = 1)) then
        pk_integracao.expMudEstornoAlocacao(p_idOR);
      end if;
    end expEstornoMudSetor;
  begin
  
    carregarDados;
  
    realizarLockDaOR;
  
    begin
      validacoes;
    exception
      when RAISE_FLUXO_CROSSDOCKING then
        estornarAlocacaoCrossdocking;
        return;
    end;
  
    fluxoGeraLoteNaConferencia;
  
    pk_gmb.excluirNFRemessaGMB(p_idOR, p_idusuario);
  
    -- Verifica se possui pendência de alocação e caso possuir, aloca os mapas faltantes
    if (r_estRecebimento.Faltamalocar > 0) then
      alocarMapasFaltantes;
    end if;
  
    estornarRemanejamento;
    expEstornoMudSetor;
  
    pk_kardex.retirarEntrada(p_idOR);
  
    retirarLotedoEstoque;
  
    atualizarStatusParaPendente;
  
    pk_integracao.estornarIntegracaoOR(p_idOR);
  
    estornarOrdemServico;
  
    estornarDetLoteConferencia;
  
    estornarOrdemTransferencia;
  
    pk_utilities.GeraLog(p_idusuario,
                         'ESTORNOU A OR ID: ' || p_idOR || ', USUARIO ID: ' ||
                          p_idUsuario, p_idOR, 'OR');
  
  end estornarRecebimento;

  /* 
   * Procedure que exclui os documentos gerados pela divergência na conferência 
  */
  procedure excluiDocDivergenciaEntrada
  (
    p_idlotenf  in lotenf.idlotenf%type,
    p_idusuario in number,
    p_mensagem  in varchar2
  ) is
    idNotaFiscal notafiscal.idnotafiscal%type;
    p_erro_can   varchar2(1000);
  
    procedure cancelarRetSimbolico
    (
      p_idlotenf  in lotenf.idlotenf%type,
      p_idusuario in number
    ) is
      p_erro_can varchar2(1000);
    begin
      for c in (select nfrs.idnotafiscal, nfrs.codigointerno, nfi.situacaonfe,
                       nfrs.tiponf, nfrs.impresso, nfi.idprenf, nfrs.statusnf,
                       nfrs.retmovtoarmazenagem
                  from notafiscal nfrs, retornosimbolico r,
                       notafiscaldevolucao nd, notafiscal nf, nfimpressao nfi
                 where r.idnotafiscalretorno = nfrs.idnotafiscal
                   and nd.idnfdevolucao = r.idnotafiscalvenda
                   and nf.idnotafiscal = nd.idnfentrada
                   and nfi.idprenf = nfrs.idprenf
                   and nf.idlotenf = p_idlotenf)
      loop
        delete from retornosimbolico rs
         where rs.idnotafiscalretorno = c.idnotafiscal;
        delete from coberturanotafiscal cn
         where cn.idnotafiscalretorno = c.idnotafiscal;
        delete from paletseparacaonf
         where idnotafiscal = c.idnotafiscal;
      
        if ((c.tiponf <> 'E') and (c.impresso = 'S')) then
          pk_notafiscal.CancelaNF(c.idprenf, p_idusuario,
                                  'CANCELADO EM FUNCAO DE EXCLUSÃO DA O.R.: ' ||
                                   p_idlotenf, 'N', 'S', p_erro_can);
          if p_erro_can is not null then
            v_msg := t_message(p_erro_can);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        elsif ((c.tiponf = 'E') and (c.situacaonfe not in (6, 10))) then
          v_msg := t_message('A OR SOMENTE PODE SER EXCLUÍDA APÓS O CANCELAMENTO DE SUAS NOTAS FISCAIS DE RETORNO DE ARMAZENAGEM.' ||
                             chr(13) || 'OPERACAO CANCELADA.');
          raise_application_error(-20100, v_msg.formatMessage);
        elsif c.statusnf <> 'X' then
          delete from nfimpressao
           where idprenf = c.idprenf;
          pk_utilities.GeraLog(p_idusuario,
                               'EXCLUIU A NOTA FISCAL NUM: ' ||
                                c.codigointerno || ' ID: ' || c.idnotafiscal ||
                                ' PRENF:' || c.idprenf ||
                                'EM FUNCAO DA EXCLUSÃO DA OR: ' ||
                                p_idlotenf, c.idnotafiscal, 'NF');
        end if;
      
        if c.retmovtoarmazenagem = 'N' then
          pk_integracao.exportaNFArmazenagem(c.idnotafiscal);
        end if;
      end loop;
    end;
  begin
    -- Localizando se existe nota fiscal de devolução.
    for c_nfdevolucao in (select idnfdevolucao, nfd.idprenf,
                                 nvl(nfd.impresso, 'N') impresso, nf.idlotenf,
                                 nf.codigointerno
                            from notafiscaldevolucao nd, notafiscal nf,
                                 notafiscal nfd
                           where nd.idnfentrada = nf.idnotafiscal
                             and nf.idlotenf = p_idlotenf
                             and nfd.idnotafiscal = nd.idnfdevolucao)
    loop
      cancelarRetSimbolico(p_idlotenf, p_idusuario);
    
      delete notafiscaldevolucao
       where idnfdevolucao = c_nfdevolucao.idnfdevolucao;
      if c_nfdevolucao.impresso = 'N' then
        delete nfdet
         where nf = c_nfdevolucao.idnfdevolucao;
        delete dadosadicionaisnf
         where idnotafiscal = c_nfdevolucao.idnfdevolucao;
        delete notafiscal
         where idnotafiscal = c_nfdevolucao.idnfdevolucao;
        delete from nfimpressao
         where idprenf = c_nfdevolucao.idprenf;
      
        pk_utilities.GeraLog(p_idusuario,
                             'EXCLUIU A NOTA FISCAL NUM: ' ||
                              c_nfdevolucao.codigointerno || ' ID: ' ||
                              c_nfdevolucao.idnfdevolucao || ' PRENF:' ||
                              c_nfdevolucao.idprenf || ' EM FUNCAO DA ' ||
                              nvl(p_mensagem, 'MUDANÇA DE MATERIAL CONFERIDO') ||
                              ' DA OR: ' || p_idlotenf,
                             c_nfdevolucao.idnfdevolucao, 'NF');
      else
        if c_nfdevolucao.idlotenf is not null then
          update notafiscal
             set idlotenf = null
           where idnotafiscal = c_nfdevolucao.idnfdevolucao;
        end if;
        pk_notafiscal.CancelaNF(c_nfdevolucao.idprenf, p_idusuario,
                                'CANCELADO EM FUNCAO DA ' ||
                                 nvl(p_mensagem,
                                     'MUDANÇA DE MATERIAL CONFERIDO') ||
                                 ' DA OR: ' || p_idlotenf, 'N', 'S',
                                p_erro_can);
      
        if p_erro_can is not null then
          v_msg := t_message(p_erro_can);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end loop;
  
    -- Localizando se existe nota fiscal aguardando cobertura. 
    for c_nfaguardandocob in (select distinct idnotafiscal, idprenf
                                from notafiscal
                               where idlotenf = p_idlotenf
                                 and sequencia = 'AGCOB')
    loop
      delete origemlotedetalhado
       where idnotafiscal = c_nfaguardandocob.idnotafiscal;
      delete origemlote
       where idnotafiscal = c_nfaguardandocob.idnotafiscal;
      delete coberturalotedispnf
       where idnotafiscalcobertura = c_nfaguardandocob.idnotafiscal;
      delete coberturalote
       where idnotafiscal = c_nfaguardandocob.idnotafiscal;
      delete nfdet
       where nf = c_nfaguardandocob.idnotafiscal;
      delete dadosadicionaisnf
       where idnotafiscal = c_nfaguardandocob.idnotafiscal;
      delete notafiscal
       where idnotafiscal = c_nfaguardandocob.idnotafiscal;
      delete from nfimpressao
       where idprenf = c_nfaguardandocob.idprenf;
    end loop;
  end;

  /*
   * Rotina que Gera as etiquetas para nf
  */
  procedure GerarEtiquetaNF(p_idlotenf in number) is
    v_qtde number;
  begin
    -- apaga os registros
    --  delete from gtt_etiqor;
  
    for c_etiqueta in (select l.data, l.qtdenf, l.quantidadevolume,
                              l.volumesagrupamento, e.fantasia,
                              t.classificacao
                         from lotenf l, entidade e, tiporecebimento t
                        where l.idlotenf = p_idlotenf
                          and e.identidade = l.identidade
                          and t.idtiporecebimento = l.idtiporecebimento)
    loop
      v_qtde := 1;
      -- insere a qtde de NF da OR para imprimir as etiquetas
      while (v_qtde <= c_etiqueta.qtdenf)
      loop
        insert into gtt_etiqor
          (idlotenf, data, barra, tipo, registro, qtde, fantasia)
        values
          (p_idlotenf, c_etiqueta.data, lpad(p_idlotenf, 7, '0'), 1, v_qtde,
           c_etiqueta.qtdenf, c_etiqueta.fantasia);
      
        v_qtde := v_qtde + 1;
      end loop;
    
      -- insere a qtde de NF da OR para imprimir as etiquetas
      if (c_etiqueta.classificacao in ('D', 'T'))
         and (c_etiqueta.volumesagrupamento = 'S') then
      
        -- and ((r_etq.classificacao = 'D') or (r_etq.classificacao = 'T')) then 
        v_qtde := 1;
      
        while (v_qtde <= c_etiqueta.quantidadevolume)
        loop
        
          insert into gtt_etiqor
            (idlotenf, data, barra, tipo, registro, qtde, fantasia)
          values
            (p_idlotenf, c_etiqueta.data,
             lpad(p_idlotenf, 6, '0') || lpad(v_qtde, 4, '0'), 2, v_qtde,
             c_etiqueta.quantidadevolume, c_etiqueta.fantasia);
        
          v_qtde := v_qtde + 1;
        end loop;
      end if;
    end loop;
  end;

  /*
   * Funcao que retorna os estados dos lotes da or
  */
  function Ret_EstadoLoteOR
  (
    p_idloteNF      in number,
    p_ignorarestado in char
  ) return varchar2 is
    v_result varchar2(256);
  begin
    v_result := null;
    for c_estado in (select distinct ol.idlotenf,
                                     decode(l.estado, 'D', 'DANIFICADO', 'T',
                                             'TRUNCADO', 'BOM') estado
                       from orlote ol, lote l
                      where l.estado <> p_ignorarestado
                        and l.idlote = ol.idlote
                        and ol.idlotenf = p_idlotenf)
    loop
      if v_result is null then
        v_result := c_estado.estado;
      else
        v_result := v_result || ', ' || c_estado.estado;
      end if;
    end loop;
    return v_result;
  end;

  /*
   * Geracao automatica a partir da OR de enderecos de picking por Familia
  */
  procedure GerarPKORFamilia
  (
    p_lotenf    in number,
    p_idusuario in number
  ) is
  
    cursor c_picking
    (
      p_familia     in number,
      p_qtdepicking in number
    ) is
      select idarmazem, idlocal, qtde
        from (select l.idarmazem, l.idlocal, count(p.idproduto) qtde
                 from local l, produtolocal p
                where p.idarmazem(+) = l.idarmazem
                  and p.idlocal(+) = l.idlocal
                  and l.picking = 'S'
                  and l.ativo = 'S'
                  and nvl(l.buffer, 'N') = 'N'
                  and l.idfamilia = p_familia
                group by l.idarmazem, l.idlocal) a
       where a.qtde = p_qtdepicking
       order by idarmazem, idlocal;
  
    r_picking     c_picking%rowtype;
    v_qtdepicking number;
  begin
    for c_prod_pk in (select rownum, sp.idlotenf, sp.idproduto,
                             p.codigointerno codprod, p.descr produto,
                             e.razaosocial depositante,
                             ln.identidade iddepositante, p.idfamilia,
                             f.razaosocial familia, d.pickingmultiplo
                        from sumprodlote sp, lotenf ln, entidade e,
                             depositante d, produto p, entidade f
                       where f.identidade = p.idfamilia
                         and p.idproduto = sp.idproduto
                         and d.usapicking = 'S'
                         and d.identidade = e.identidade
                         and e.identidade = ln.identidade
                         and (sp.idproduto, ln.idarmazem) not in
                             (select distinct idproduto, idarmazem
                                from produtolocal pl
                               where pl.identidade = ln.identidade)
                         and ln.idlotenf = sp.idlotenf
                         and sp.idlotenf = p_lotenf)
    loop
      if c_prod_pk.pickingmultiplo = 'N' then
        v_qtdepicking := 0;
      else
        select nvl(min(count(p.idproduto)), 0) qtde
          into v_qtdepicking
          from local l, produtolocal p
         where p.idarmazem(+) = l.idarmazem
           and p.idlocal(+) = l.idlocal
           and l.picking = 'S'
           and l.ativo = 'S'
           and nvl(l.buffer, 'N') = 'N'
           and l.idfamilia = c_prod_pk.idfamilia
         group by l.idarmazem, l.idlocal;
      end if;
      open c_picking(c_prod_pk.idfamilia, v_qtdepicking);
      fetch c_picking
        into r_picking;
      if c_picking%found then
        pk_armazem.criarPickingProduto(r_picking.idarmazem,
                                       r_picking.idlocal,
                                       c_prod_pk.iddepositante,
                                       c_prod_pk.idproduto);
      
        pk_utilities.GeraLog(p_idusuario,
                             'CADASTROU O PICKING AUTOMATICO A PARTIR DA OR: ' ||
                              p_lotenf || ' PARA O PRODUTO: ' ||
                              c_prod_pk.codprod || '-' || c_prod_pk.produto ||
                              ' E DEP.:' || c_prod_pk.depositante, p_lotenf,
                             'CA');
      else
        v_msg := t_message('DEPOSITANTE NAO TEM ENDERECO DE PICKING DISPONIVEL DEFINIDO PARA O PRODUTO ' ||
                           '{0} - {1} E FAMILIA {2} .');
        v_msg.addParam(c_prod_pk.codprod);
        v_msg.addParam(c_prod_pk.produto);
        v_msg.addParam(c_prod_pk.familia);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end loop;
    close c_picking;
  end;

  /*
   * Retorna os Remetentes da OR
  */
  function Ret_Rem_OR(p_lotenf in number) return varchar2 is
    cursor c_ent(p_lotenf in number) is
      select distinct e.razaosocial
        from notafiscal nf, nfdet nfd, entidade e
       where nf.idlotenf = p_lotenf
         and e.identidade = nf.remetente
         and nfd.nf = nf.idnotafiscal;
  
    r_ent c_ent%rowtype;
    S     varchar2(10000);
  begin
    if c_ent%isopen then
      close c_ent;
    end if;
    open c_ent(p_lotenf);
    fetch c_ent
      into r_ent;
    if c_ent%found then
      while c_ent%found
      loop
        if S is null then
          S := r_ent.razaosocial;
        else
          S := S || ',' || r_ent.razaosocial;
        end if;
        fetch c_ent
          into r_ent;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
   * Retorna os Destinatarios da OR 
  */
  function Ret_Dest_OR(p_lotenf in number) return varchar2 is
    cursor c_ent(p_lotenf in number) is
      select distinct e.razaosocial
        from notafiscal nf, nfdet nfd, entidade e
       where nf.idlotenf = p_lotenf
         and e.identidade = nf.destinatario
         and nfd.nf = nf.idnotafiscal;
  
    r_ent c_ent%rowtype;
    S     varchar2(10000);
  begin
    if c_ent%isopen then
      close c_ent;
    end if;
    open c_ent(p_lotenf);
    fetch c_ent
      into r_ent;
    if c_ent%found then
      while c_ent%found
      loop
        if S is null then
          S := r_ent.razaosocial;
        else
          S := S || ',' || r_ent.razaosocial;
        end if;
        fetch c_ent
          into r_ent;
      end loop;
      return S;
    else
      return '';
    end if;
  end;

  /*
  * Verifica se o usuário possui permissão para liberar a OR com divergencia
  */
  function VerificaPermissaoUsuario
  (
    p_idlotenf  in number,
    p_idusuario in number
  ) return boolean is
    v_porcdivergencia number;
    v_limitemax       number;
    v_limitemin       number;
    v_qtdenf          number;
    v_qtdeconferida   number;
  begin
    select nvl(nu.porcentdivergencia, 0)
      into v_porcdivergencia
      from nivelusuario nu, usuario u
     where u.nivel = nu.nivel
       and u.idusuario = p_idusuario;
  
    if (v_porcdivergencia >= 100) then
      return true;
    end if;
  
    select sum(qtde + qtdeavari + qtdevenc) qtdenf, sum(qtdconf) qtdeconf
      into v_qtdenf, v_qtdeconferida
      from sumprodlote
     where idlotenf = p_idlotenf;
  
    v_limitemax := v_qtdenf * (1 + (v_porcdivergencia / 100)); --Limite da quant maxima que usuário pode liberar
    v_limitemin := v_qtdenf * (1 - (v_porcdivergencia / 100)); --Limite da quant minima que usuário pode liberar
  
    if (v_qtdeconferida >= v_limitemin)
       and (v_qtdeconferida <= v_limitemax) then
      return true;
    else
      return false;
    end if;
  end;

  /*
   * Geracao de picking automatica a partir da OR por setor
  */
  procedure GerarPKSetor
  (
    p_idlotenf  in number,
    p_idsetor   in number,
    p_idusuario in number
  ) is
    cursor c_picking
    (
      p_idarmazem  in number,
      p_setor      in number,
      p_multiplopk in char
    ) is
      select idarmazem, idlocal, qtde
        from (select l.idarmazem, l.idlocal, count(p.idproduto) qtde
                 from local l, produtolocal p
                where p.idarmazem(+) = l.idarmazem
                  and p.idlocal(+) = l.idlocal
                  and l.picking = 'S'
                  and l.ativo = 'S'
                  and nvl(l.buffer, 'N') = 'N'
                  and l.idsetor = p_setor
                  and l.idarmazem = p_idarmazem
                group by l.idarmazem, l.idlocal) a
       where a.qtde = decode(p_multiplopk, 'N', 0,
                             (select nvl(min(count(p.idproduto)), 0) qtde
                                 from local l, produtolocal p
                                where p.idarmazem(+) = l.idarmazem
                                  and p.idlocal(+) = l.idlocal
                                  and l.picking = 'S'
                                  and l.ativo = 'S'
                                  and nvl(l.buffer, 'N') = 'N'
                                  and l.idsetor = p_setor
                                  and l.idarmazem = p_idarmazem
                                group by l.idarmazem, l.idlocal))
       order by idarmazem, idlocal;
  
    r_picking c_picking%rowtype;
  begin
  
    for c_prod in (select rownum, sp.idlotenf, sp.idproduto,
                          p.codigointerno codprod, p.descr produto,
                          e.razaosocial depositante,
                          ln.identidade iddepositante, ln.idarmazem,
                          d.pickingmultiplo
                     from sumprodlote sp, lotenf ln, entidade e,
                          depositante d, produto p
                    where p.idproduto = sp.idproduto
                      and d.usapicking = 'S'
                      and d.identidade = e.identidade
                      and e.identidade = ln.identidade
                      and ln.idlotenf = sp.idlotenf
                      and sp.idlotenf = p_idlotenf
                      and not exists
                    (select 1
                             from produtolocal pl
                            where pl.identidade = ln.identidade
                              and pl.idproduto = sp.idproduto
                              and pl.idarmazem = ln.idarmazem))
    loop
      if c_picking%isopen then
        close c_picking;
      end if;
      open c_picking(c_prod.idarmazem, p_idsetor, c_prod.pickingmultiplo);
      fetch c_picking
        into r_picking;
      if c_picking%found then
        pk_armazem.criarPickingProduto(r_picking.idarmazem,
                                       r_picking.idlocal,
                                       c_prod.iddepositante,
                                       c_prod.idproduto);
      
        pk_utilities.GeraLog(p_idusuario,
                             'CADASTROU O PICKING AUTOMATICO A PARTIR DA OR: ' ||
                              p_idlotenf || ' PARA O PRODUTO: ' ||
                              c_prod.codprod || '-' || c_prod.produto ||
                              ' E DEP.:' || c_prod.depositante, p_idlotenf,
                             'CA');
      else
        v_msg := t_message('O SETOR DE ID: {0}' ||
                           ' NAO TEM ENDERECO DE PICKING SUFICIENTE PARA OS PRODUTOS DA OR: ' ||
                           '{1}.');
        v_msg.addParam(p_idsetor);
        v_msg.addParam(p_idlotenf);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end loop;
    if c_picking%isopen then
      close c_picking;
    end if;
  end;

  procedure addNotaFiscalOR
  (
    p_idlotenf     in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    type t_resumoexecucao is table of gtt_resumoexecucao%rowtype;
  
    GRUPO_NF_VINCULADA_OUTRA_OR  constant varchar2(100) := 'Nota fiscal já vinculada em outra Ordem de Recebimento';
    GRUPO_NF_JA_VINCULADA        constant varchar2(100) := 'Nota fiscal já vinculada na Ordem de Recebimento';
    GRUPO_NF_SEM_ITENS           constant varchar2(100) := 'Nota fiscal sem item';
    GRUPO_NF_COM_DIVERGENCIA     constant varchar2(100) := 'Nota fiscal com divergência';
    GRUPO_NF_TRANSF_TITULARIDADE constant varchar2(100) := 'Nota fiscal vinculada em uma Transferência de Titularidade';
    GRUPO_PRODUTODEPOSITANTE     constant varchar2(100) := 'Produto não vinculado ao depositante';
    GRUPO_CFOP_INVALIDO          constant varchar2(100) := 'CFOP inválido';
    GRUPO_ICMS                   constant varchar2(100) := 'ICMS';
    GRUPO_SUCESSO                constant varchar2(100) := 'Nota fiscal vinculada com sucesso';
    GRUPO_ITEM_OPA               constant varchar2(100) := 'Itens Vinculados a Ordem de Compra';
    GRUPO_BACKLIST_NAO_VALIDADO  constant varchar2(100) := 'Backlist da nota fiscal não validado';
    GRUPO_KIT_RASTREAVEL         constant varchar2(100) := 'Nota fiscal possui Kits com rastreabilidade';
    GRUPO_PROD_PRECADASTRO_TDN   constant varchar2(100) := 'Produto com pré cadastro ativo presente em Ordem de Tranferência';
  
    TIPORESUMO_ERRO    constant number := 1;
    TIPORESUMO_ALERTA  constant number := 2;
    TIPORESUMO_SUCESSO constant number := 0;
    TIPORESUMO_INFO    constant number := 3;
  
    TIPO_BACKLIST_NAO constant number := 0;
    BACKLIST_VALIDADO constant number := 2;
  
    resumo_exception exception;
    r_lotenf              lotenf%rowtype;
    r_notafiscal          notafiscal%rowtype;
    r_resumoexecucao      gtt_resumoexecucao%rowtype;
    l_resumoexecucao      t_resumoexecucao;
    v_interromperexecucao boolean := false;
    v_isNfOrigemTdn       number;
  
    procedure addResumoExecucao
    (
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
    begin
      select seq_gtt_resumoexecucao.nextval
        into r_resumoexecucao.idresumoexecucao
        from dual;
    
      l_resumoexecucao.extend;
      l_resumoexecucao(l_resumoexecucao.count) := r_resumoexecucao;
    
      v_msg := t_message('Total ');
      dbms_output.put_line(v_msg.formatMessage || l_resumoexecucao.count);
    end addResumoExecucao;
  
    procedure validarStatusOR(r_lotenf in lotenf%rowtype) is
    begin
      if (r_lotenf.status = 'P') then
        v_msg := t_message('Ordem de recebimento já processada. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_lotenf.flaglibnf = 2) then
        v_msg := t_message('Ordem de recebimento liberada na conferência. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarStatusOR;
  
    procedure validarNotaFiscal
    (
      r_lotenf              in out lotenf%rowtype,
      r_notafiscal          in out notafiscal%rowtype,
      l_resumoexecucao      in out t_resumoexecucao,
      r_resumoexecucao      in out gtt_resumoexecucao%rowtype,
      p_interromperexecucao in out boolean
    ) is
      v_possuiitens                number;
      v_possuiitenskitsrastreavel  number;
      v_permitedivergencias        char(1);
      v_utilizaOPA                 depositante.utilizaopa%type;
      v_idNfdet                    nfdet.idnfdet%type;
      v_qtdeNfDet                  nfdet.qtde%type;
      v_ErrBuscaOrdemCompra        boolean;
      v_transfTitularidade         number;
      v_possuiNotasTipoDif         number;
      v_permiteRemArmazComDesconto number;
    begin
      if (r_notafiscal.tipo = 'S') then
        begin
          select nf.idlotenf
            into r_notafiscal.idlotenf
            from notafiscal nf
           where nf.idnotafiscalvinculada = r_notafiscal.idnotafiscal;
        exception
          when no_data_found then
            r_notafiscal.idlotenf := r_notafiscal.idlotenf;
        end;
      end if;
    
      if (r_notafiscal.idlotenf is not null) then
        if (r_notafiscal.idlotenf = r_lotenf.idlotenf) then
          r_resumoexecucao.grupo := GRUPO_NF_JA_VINCULADA;
        
          v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1})' ||
                             ' já esta vinculada nesta ordem de recebimento.');
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
        
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_INFO;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
          p_interromperexecucao := true;
          return;
        end if;
      
        r_resumoexecucao.grupo := GRUPO_NF_VINCULADA_OUTRA_OR;
      
        v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1})' ||
                           ' já esta vinculada em outra ordem de recebimento (OR: {2}).');
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
        v_msg.addParam(r_notafiscal.idlotenf);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        p_interromperexecucao := true;
        return;
      end if;
    
      select count(*)
        into v_possuiitens
        from nfdet nd
       where nd.nf = r_notafiscal.idnotafiscal;
    
      if (v_possuiitens = 0) then
        r_resumoexecucao.grupo := GRUPO_NF_SEM_ITENS;
      
        v_msg := t_message('A nota fiscal {0}' ||
                           ' (idnotafiscal: {1}) não possui nenhum item cadastrado.');
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        return;
      end if;
      -- valida produto kit rastreavel
    
      select sum(x.contagem) contagem
        into v_possuiitenskitsrastreavel
        from (select count(*) contagem
                 from nfdet nd, kitproduto kp, produtodepositante pd
                where nd.nf = r_notafiscal.idnotafiscal
                  and kp.idprodutokit = nd.idproduto
                  and kp.estojo = 1
                  and pd.identidade = r_notafiscal.iddepositante
                  and pd.idproduto = nd.idproduto
                  and pd.bloqueiakitrastreavel = 1
               union all
               select count(*) contagem
                 from nfdet nd, kitproduto kp, produtodepositante pd
                where nd.nf = r_notafiscal.idnotafiscal
                  and kp.idprodutokit = nd.idproduto
                  and pd.identidade = r_notafiscal.iddepositante
                  and pd.idproduto = nd.idproduto
                  and pd.bloqueiakitrastreavel = 1
                  and exists
                (select 1
                         from kitproduto kit
                        where kit.idprodutokit = kp.idproduto)
               union all
               select count(*) contagem
                 from nfdet nd, produtodepositante pd
                where nd.nf = r_notafiscal.idnotafiscal
                  and pd.identidade = r_notafiscal.iddepositante
                  and pd.idproduto = nd.idproduto
                  and pd.bloqueiakitrastreavel = 1
                  and exists
                (select 1
                         from origemLote ol, notafiscal nf, lote lt,
                              ordemservico os
                        where nf.idarmazem = r_notafiscal.idarmazem
                          and nf.iddepositante = r_notafiscal.iddepositante
                          and nf.idnotafiscal = ol.idnotafiscal
                          and lt.idlote = ol.idlote
                          and lt.idproduto = nd.idproduto
                          and os.idlotenf = nf.idlotenf
                          and os.tiposervico = 'I')
               union all
               select count(*) contagem
                 from nfdet nd, produtodepositante pd
                where nd.nf = r_notafiscal.idnotafiscal
                  and pd.identidade = r_notafiscal.iddepositante
                  and pd.idproduto = nd.idproduto
                  and pd.bloqueiakitrastreavel = 1
                  and exists
                (select *
                         from origemLote ol, notafiscal nf, lote lt,
                              ordemservico os, receitaestojamento re
                        where nf.idarmazem = r_notafiscal.idarmazem
                          and nf.iddepositante = r_notafiscal.iddepositante
                          and nf.idnotafiscal = ol.idnotafiscal
                          and lt.idlote = ol.idlote
                          and lt.idproduto = nd.idproduto
                          and os.idlotenf = nf.idlotenf
                          and os.tiposervico = 'E'
                          and os.idordemservico = re.idos
                          and exists
                        (select 1
                                 from kitproduto kpro
                                where kpro.idprodutokit = re.idproduto))
               union
               select count(*)
                 from nfdet nd, backlist bk
                where nd.nf = r_notafiscal.idnotafiscal
                  and bk.idnfdet = nd.idnfdet
                  and exists
                (select 1
                         from lotelocal ll, lote lt, receitaestojamentolote re,
                              ordemservico os
                        where lt.iddepositante = r_notafiscal.iddepositante
                          and lt.idarmazem = r_notafiscal.idarmazem
                          and lt.descr = bk.loteindustria
                          and lt.idlote = ll.idlote
                          and ll.estoque > 0
                          and re.idlote = lt.idlote
                          and os.idordemservico = re.idos
                          and os.tiposervico = 'E')
               union all
               select count(*)
                 from nfdet nd, backlist bk
                where nd.nf = r_notafiscal.idnotafiscal
                  and bk.idnfdet = nd.idnfdet
                  and exists
                (select 1
                         from lotelocal ll, lote lt, orlote ol, ordemservico os
                        where lt.iddepositante = r_notafiscal.iddepositante
                          and lt.idarmazem = r_notafiscal.idarmazem
                          and lt.descr = bk.loteindustria
                          and lt.idlote = ll.idlote
                          and ll.estoque > 0
                          and ol.idlote = lt.idlote
                          and os.idlotenf = ol.idlotenf
                          and os.tiposervico = 'I')) x;
    
      if (v_possuiitenskitsrastreavel > 0) then
        r_resumoexecucao.grupo := GRUPO_KIT_RASTREAVEL;
      
        v_msg := t_message('A nota fiscal {0}' ||
                           ' (idnotafiscal: {1}) possui produto de kit rastreavel ou produto(s) marcado para ser unicamente rastreavel, impedindo vínculo.');
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        return;
      end if;
    
      select d.liberarnfdivergencias
        into v_permitedivergencias
        from depositante d
       where d.identidade = r_lotenf.identidade;
    
      if (pk_notafiscal.isDivergenciaNotaFiscal(r_notafiscal.idprenf, 0) =
         pk_notafiscal.C_POSSUI_DIVERGENCIA_VALOR) then
        if (v_permitedivergencias = 'S') then
          r_resumoexecucao.grupo := GRUPO_NF_COM_DIVERGENCIA;
        
          v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1})' ||
                             ' esta com diferenca de valores.');
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
        
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_ALERTA;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        else
          r_resumoexecucao.grupo := GRUPO_NF_COM_DIVERGENCIA;
        
          v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1})' ||
                             ' esta com diferenca de valores.' ||
                             ' O depositante esta configurado para não permitir diferença de valores.');
        
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
        
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        end if;
      end if;
    
      select d.utilizaopa, d.permremarmcomdesc
        into v_utilizaOPA, v_permiteRemArmazComDesconto
        from depositante d
       where d.identidade = r_notafiscal.iddepositante;
    
      if (v_utilizaOPA = 1) then
        for nf_items in (select nfd.idnfdet,
                                (nfd.qtde * e.fatorconversao) qtde
                           from nfdet nfd, embalagem e, notafiscal nf
                          where nfd.nf = r_notafiscal.idnotafiscal
                            and e.idproduto = nfd.idproduto
                            and e.barra = nfd.barra
                            and nf.idnotafiscal = nfd.nf
                            and nf.ordemtransferencia = 0)
        loop
          v_ErrBuscaOrdemCompra := false;
          begin
            select op.idnfdet, sum(qtde) qtde
              into v_idNfdet, v_qtdeNfDet
              from itemopanfdet op
             where op.idnfdet = nf_items.idnfdet
             group by op.idnfdet;
          exception
            when no_data_found then
              v_ErrBuscaOrdemCompra := True;
          end;
        
          if ((v_ErrBuscaOrdemCompra) OR (nf_items.qtde <> v_qtdeNfDet)) then
            p_interromperexecucao  := true;
            r_resumoexecucao.grupo := GRUPO_ITEM_OPA;
          
            v_msg := t_message('A nota fiscal {0}' ||
                               ' (idnotafiscal: {1})' ||
                               ' possui divergências em relação a quantidade de itens vinculados à ordem de compra.');
            v_msg.addParam(r_notafiscal.codigointerno);
            v_msg.addParam(r_notafiscal.idnotafiscal);
          
            r_resumoexecucao.descricao := v_msg.formatMessage;
            r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
            addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
          end if;
        end loop;
      
      end if;
    
      select count(*)
        into v_transfTitularidade
        from transferenciatitularidade tt
       where tt.idnotafiscalentrada = r_notafiscal.idnotafiscal;
    
      if (v_transfTitularidade > 0) then
        p_interromperexecucao  := true;
        r_resumoexecucao.grupo := GRUPO_NF_TRANSF_TITULARIDADE;
      
        v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1})' ||
                           ' está vinculada a uma transferência de titularidade.');
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
      end if;
    
      select count(1)
        into v_possuiNotasTipoDif
        from notafiscal nf
       where nf.idlotenf = r_lotenf.idlotenf
         and nf.tipoentrada <> r_notafiscal.tipoentrada;
    
      if (v_possuiNotasTipoDif > 0) then
        v_msg := t_message('A nota fiscal {0} (idnotafiscal: {1}) não pôde ser vinculada pois, a Ordem de Recebimento já possui Notas Fiscais vinculadas com o Tipo de Entrega diferente de "{2}".');
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
        v_msg.addParam(case when r_notafiscal.tipoentrada = 0 then
                       'Nota Fiscal' else 'Transferência' end);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
      end if;
    
      if (v_permiteRemArmazComDesconto = 0 and
         (nvl(r_notafiscal.valortotaldescontos, 0) +
         nvl(r_notafiscal.valordesconto, 0) > 0)) then
        for c_valida in (select 1 tipoOper
                           from operacao op
                          where op.idoperacao = r_notafiscal.idoperacao
                            and nvl(op.tipooper, 'NDF') = 'RA')
        loop
          -- Remessa de Armazenagem
          v_msg := t_message('A Nota Fiscal {0} [idNotaFsical: {1}] não pode ser vinculada pois, <br> o Depositante está parametrizado para não permitir o vínculo de Nota de Remessa de Armazenagem com desconto em OR.');
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        
        end loop;
      end if;
    
    end validarNotaFiscal;
  
    procedure validarProdutoDepositante
    (
      r_notafiscal     in out notafiscal%rowtype,
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
    begin
      for c_produto in (select p.idproduto, p.codigointerno, p.descr,
                               d.razaosocial, d.identidade
                          from notafiscal nf, nfdet nd, produto p, entidade d
                         where nf.idnotafiscal = r_notafiscal.idnotafiscal
                           and nd.nf = nf.idnotafiscal
                           and p.idproduto = nd.idproduto
                           and d.identidade = nf.iddepositante
                           and not exists
                         (select 1
                                  from produtodepositante pd
                                 where pd.idproduto = nd.idproduto
                                   and pd.identidade = nf.iddepositante))
      loop
        r_resumoexecucao.grupo := GRUPO_PRODUTODEPOSITANTE;
      
        v_msg := t_message('O produto {0} (codigo interno: ' ||
                           '{1}, idProduto: {2}' ||
                           ') não possui vinculo o depositante ' ||
                           '{3} (idDepositante: {4}).' ||
                           ' Esta nota fiscal (numero: {5}' ||
                           ', idNotaFiscal: {6}' ||
                           ') não pode ser vinculada.');
        v_msg.addParam(c_produto.descr);
        v_msg.addParam(c_produto.codigointerno);
        v_msg.addParam(c_produto.idproduto);
        v_msg.addParam(c_produto.razaosocial);
        v_msg.addParam(c_produto.identidade);
        v_msg.addParam(r_notafiscal.codigointerno);
        v_msg.addParam(r_notafiscal.idnotafiscal);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
      end loop;
    end;
  
    procedure validarCadatroDeProdutos
    (
      r_notafiscal     in out notafiscal%rowtype,
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
    
      v_prodPresenteNoTDN    number;
      v_gerarPedidoImportTDN number;
    
    begin
      for c_produto in (select p.idproduto, p.codigointerno, p.descr,
                               p.precadastro
                          from notafiscal nf, nfdet nd, produto p
                         where nf.idnotafiscal = r_notafiscal.idnotafiscal
                           and nf.idnotafiscal = nd.nf
                           and nd.idproduto = p.idproduto)
      loop
      
        select count(1)
          into v_prodPresenteNoTDN
          from ordemtransferenciaitem oti, ordemtransferencia ot
         where oti.idproduto = c_produto.idproduto
           and oti.idordemtransferencia = ot.idordemtransferencia
           and ot.status = 0; -- Pendente
      
        if (v_prodPresenteNoTDN > 0) then
        
          select d.gerarpedidoimportacaotdn
            into v_gerarPedidoImportTDN
            from depositante d
           where d.identidade = r_notafiscal.iddepositante;
        
          if (v_gerarPedidoImportTDN > 0 and c_produto.precadastro = 'S') then
            r_resumoexecucao.grupo := GRUPO_PROD_PRECADASTRO_TDN;
          
            v_msg := t_message('O produto {0} (codigo interno: ' ||
                               '{1}, idProduto: {2}' ||
                               ') está com pré cadastro ativado.' ||
                               ' Esta nota fiscal (numero: {3}' ||
                               ', idNotaFiscal: {4}' ||
                               ') não pode ser vinculada.');
            v_msg.addParam(c_produto.descr);
            v_msg.addParam(c_produto.codigointerno);
            v_msg.addParam(c_produto.idproduto);
            v_msg.addParam(r_notafiscal.codigointerno);
            v_msg.addParam(r_notafiscal.idnotafiscal);
          
            r_resumoexecucao.descricao := v_msg.formatMessage;
            r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
            addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
          end if;
        
        end if;
      
      end loop;
    
    end validarCadatroDeProdutos;
  
    procedure validarCFOP
    (
      r_lotenf         in out lotenf%rowtype,
      r_notafiscal     in out notafiscal%rowtype,
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
      v_existeCFOPvinculado number;
      v_cfopvalido          number;
    begin
      select count(*)
        into v_existeCFOPvinculado
        from cfoptiporecebimento cf
       where cf.idtiporecebimento = r_lotenf.idtiporecebimento;
    
      if (v_existeCFOPvinculado > 0) then
        select count(*)
          into v_cfopvalido
          from cfoptiporecebimento cf
         where cf.idoperacao = r_notafiscal.idoperacao
           and cf.idtiporecebimento = r_lotenf.idtiporecebimento;
      
        if (v_cfopvalido = 0) then
          r_resumoexecucao.grupo := GRUPO_CFOP_INVALIDO;
        
          v_msg := t_message('O CFOP {0}' ||
                             ' não esta vinculado para o tipo de recebimento da OR.' ||
                             ' Esta nota fiscal (numero: {1}' ||
                             ', idNotaFiscal: {2}' ||
                             ') não pode ser vinculada.');
          v_msg.addParam(r_notafiscal.idoperacao);
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
        
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        end if;
      end if;
    
    end;
  
    procedure ValidarRegime
    (
      r_lotenf         in out lotenf%rowtype,
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
      v_possuinfvinculada number;
      r_entidade          entidade%rowtype;
      r_regime            regime%rowtype;
    begin
      select count(*)
        into v_possuinfvinculada
        from notafiscal nf
       where nf.idlotenf = r_lotenf.idlotenf;
    
      if (v_possuinfvinculada > 0) then
        select r.*
          into r_regime
          from depositante d, regime r
         where d.identidade = r_lotenf.identidade
           and r.idregime = d.idregime;
      
        if (r_regime.classificacao = 'A' and
           r_regime.contribuinteicms = 'N') then
          select e.*
            into r_entidade
            from entidade e
           where e.identidade = r_lotenf.identidade;
        
          r_resumoexecucao.grupo := GRUPO_ICMS;
        
          v_msg := t_message('O depositante {0} (idDepositante: {1}' ||
                             ') não é contribuinte de ICMS.' ||
                             ' Não é permitido vincular mais de uma nota fiscal por Ordem de Recebimento.');
          v_msg.addParam(r_entidade.razaosocial);
          v_msg.addParam(r_entidade.identidade);
        
          r_resumoexecucao.descricao := v_msg.formatMessage;
          r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
          addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
        end if;
      end if;
    end;
  
    procedure validarBacklist
    (
      r_notafiscal     in out notafiscal%rowtype,
      l_resumoexecucao in out t_resumoexecucao,
      r_resumoexecucao in out gtt_resumoexecucao%rowtype
    ) is
    
      v_produtos varchar2(500);
    
      function isBackListValidado
      (
        p_idNotaFiscal in number,
        p_produtos     in out varchar2
      ) return boolean is
        v_utzbacklist number;
      begin
        select count(nfd.idnfdet),
               substr(stragg(nfd.idproduto), 0, 490) produtos
          into v_utzbacklist, p_produtos
          from notafiscal nf, nfdet nfd, depositante d,
               produtodepositante pd
         where nf.idnotafiscal = p_idNotaFiscal
           and nf.idnotafiscal = nfd.nf
           and nf.iddepositante = d.identidade
           and nf.iddepositante = pd.identidade
           and nfd.idproduto = pd.idproduto
           and d.utzbacklist > TIPO_BACKLIST_NAO
           and decode(pd.coletaloteindust, 'S', 1, 0) = 1
           and nf.backlistvalidado < BACKLIST_VALIDADO;
        return v_utzbacklist = 0;
      end;
    
    begin
      if not (isBackListValidado(r_notafiscal.idnotafiscal, v_produtos)) then
        r_resumoexecucao.grupo := GRUPO_BACKLIST_NAO_VALIDADO;
      
        v_msg := t_message('A Nota Fiscal de id: {0}' ||
                           ' não foi vínculada, pois o Backlist da Nota Fiscal não foi validado. ' ||
                           'Verificar o Cadastro de Backlist para os produtos ID: ' ||
                           '{1} e realizar a validação.');
        v_msg.addParam(r_notafiscal.idnotafiscal);
        v_msg.addParam(v_produtos);
      
        r_resumoexecucao.descricao := v_msg.formatMessage;
        r_resumoexecucao.tipo      := TIPORESUMO_ERRO;
        addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
      end if;
    end;
  
    procedure validarNFSaidaCrossdocking
    (
      p_lotenf in notafiscal.idlotenf%type,
      r_lotenf in out lotenf%rowtype
    ) is
      v_notaVinculada   number;
      r_tiporecebimento tiporecebimento%rowtype;
    begin
    
      select *
        into r_tiporecebimento
        from tiporecebimento tr
       where tr.idtiporecebimento = r_lotenf.idtiporecebimento;
    
      if (r_tiporecebimento.classificacao in ('X', 'A', 'M', 'Z', 'B')) then
      
        select count(*)
          into v_notaVinculada
          from notafiscal nf
         where nf.idlotenf = p_lotenf;
      
        if (v_notaVinculada > 0) then
        
          v_msg := t_message('Ordem de recebimento já possui nota fiscal vinculada. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
        
        end if;
      end if;
    end;
  
    procedure gerarNFEntrada
    (
      r_lotenf     in out lotenf%rowtype,
      r_notafiscal in out notafiscal%rowtype
    ) is
      r_tiporecebimento tiporecebimento%rowtype;
    begin
      if (r_notafiscal.tipo <> 'S') then
        return;
      end if;
    
      select *
        into r_tiporecebimento
        from tiporecebimento tr
       where tr.idtiporecebimento = r_lotenf.idtiporecebimento;
    
      if (r_tiporecebimento.classificacao in ('X', 'A', 'M', 'Z', 'B')) then
        update notafiscal
           set crossdocking = 'S'
         where idnotafiscal = r_notafiscal.idnotafiscal;
      end if;
    
      pk_notafiscal.p_gerarNFEntrada(r_notafiscal.idnotafiscal, 'N');
    end;
  
    procedure validaLoteIndDuplBacklist
    (
      p_idlotenf            in number,
      p_idNotaFiscal        in number,
      l_resumoexecucao      in out t_resumoexecucao,
      r_resumoexecucao      in out gtt_resumoexecucao%rowtype,
      p_interromperexecucao in out boolean
    ) is
      C_SIM constant number := 1;
      C_NAO constant number := 0;
    
      v_nfComLoteIndDupli number := 0;
      v_orComLoteIndDupli number := 0;
      GRUPO_NF_LT_IND_DUPLICADO constant varchar2(100) := 'Lote Indústria Duplicado.';
      v_depFracionaLote number := C_SIM;
    begin
      select d.fracionarlote
        into v_depFracionaLote
        from lotenf lnf, depositante d
       where lnf.idlotenf = p_idlotenf
         and d.identidade = lnf.identidade;
    
      if (isConferenciaAlocada(p_idlotenf) or v_depFracionaLote = C_NAO) then
        begin
          for c_lotesDuplicadosNf in (select distinct b.loteindustria
                                        from nfdet nd, backlist b
                                       where nd.nf = p_idNotaFiscal
                                         and b.idnfdet = nd.idnfdet
                                         and exists
                                       (select 1
                                                from nfdet nfd, backlist bc
                                               where nfd.nf = nd.nf
                                                 and nfd.idnfdet <>
                                                     nd.idnfdet
                                                 and nfd.nf = nd.nf
                                                 and bc.idnfdet = nfd.idnfdet
                                                 and bc.loteindustria =
                                                     b.loteindustria))
          loop
            r_resumoexecucao.grupo := GRUPO_NF_LT_IND_DUPLICADO;
          
            v_msg := t_message('Lote Indústria [{0}] duplicado na Nota Fiscal (' ||
                               '{1}). Favor verificar e corrigir o BackList.');
            v_msg.addParam(c_lotesDuplicadosNf.Loteindustria);
            v_msg.addParam(p_idNotaFiscal);
          
            r_resumoexecucao.descricao := v_msg.formatMessage;
            r_resumoexecucao.tipo      := pk_gttresumoexecucao.TIPO_ERRO;
          
            addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
          
            v_nfComLoteIndDupli := 1;
          end loop;
        end;
      
        if (v_nfComLoteIndDupli > 0) then
          p_interromperexecucao := true;
        else
          begin
            for c_lotesDuplicadosOr in (select b.loteindustria
                                          from nfdet nd, backlist b
                                         where nd.nf = p_idNotaFiscal
                                           and b.idnfdet = nd.idnfdet
                                           and exists
                                         (select 1
                                                  from notafiscal nf,
                                                       nfdet nfd, backlist bc
                                                 where nf.idlotenf =
                                                       p_idlotenf
                                                   and nfd.nf =
                                                       nf.idnotafiscal
                                                   and bc.idnfdet =
                                                       nfd.idnfdet
                                                   and bc.loteindustria =
                                                       b.loteindustria))
            loop
              r_resumoexecucao.grupo := GRUPO_NF_LT_IND_DUPLICADO;
            
              v_msg := t_message('Lote Indústria [{0}]' ||
                                 ' se encontra presente em uma das notas já vinculadas à OR ' ||
                                 '({1}), portanto a Nota Fiscal ({2})' ||
                                 ' não pode ser vinculada!');
              v_msg.addParam(c_lotesDuplicadosOr.Loteindustria);
              v_msg.addParam(p_idlotenf);
              v_msg.addParam(p_idNotaFiscal);
            
              r_resumoexecucao.descricao := v_msg.formatMessage;
              r_resumoexecucao.tipo      := pk_gttresumoexecucao.TIPO_ERRO;
            
              addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
            
              v_nfComLoteIndDupli := 1;
            end loop;
          end;
        
          if (v_orComLoteIndDupli > 0) then
            p_interromperexecucao := true;
          end if;
        end if;
      end if;
    end validaLoteIndDuplBacklist;
  
    procedure validaTipoEntradaNotaFiscal
    (
      p_idlotenf     in number,
      p_idnotafiscal in number
    ) is
      v_tipoEntradaVinculo number;
      v_tipoEntrada        number;
    begin
      begin
        select distinct nf.tipoentrada
          into v_tipoEntradaVinculo
          from notafiscal nf
         where nf.idlotenf = p_idlotenf;
      exception
        when no_data_found then
          v_tipoEntradaVinculo := null;
      end;
    
      begin
        select nf.tipoentrada
          into v_tipoentrada
          from notafiscal nf
         where nf.idnotafiscal = p_idnotafiscal;
      exception
        when no_data_found then
          v_tipoentrada := null;
      end;
    
      if v_tipoEntradaVinculo is not null then
        if v_tipoEntradaVinculo = v_tipoentrada then
          if v_tipoentrada = 1 then
            v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois não permite vincular mais de uma nota de transferência na mesma OR.');
            v_msg.addParam(p_idnotafiscal);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois não permite vincular notas à OR com o Tipo de Entrada diferente.');
          v_msg.addParam(p_idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validaTipoEntradaNotaFiscal;
  
    procedure validaContratoNotaFiscal
    (
      p_idlotenf   in number,
      p_notafiscal in notafiscal%rowtype
    ) is
      v_qtdNf                   number;
      v_idcontrato              notafiscal.idcontrato%type;
      v_idcontratoSemNF         notafiscal.idcontrato%type;
      v_obrigacontradonfentrada number;
    begin
      select count(1)
        into v_qtdNf
        from notafiscal nf
       where 1 = 1
         and nf.idlotenf = p_idlotenf;
    
      select count(1)
        into v_idcontratoSemNF
        from notafiscal nf
       where 1 = 1
         and nf.idlotenf = p_idlotenf
         and nf.idcontrato is null;
    
      if (v_qtdNf > 0) then
        begin
          select nvl(nf.idcontrato, 0)
            into v_idcontrato
            from notafiscal nf
           where nf.idlotenf = p_idlotenf
             and nvl(nf.idcontrato, 0) > 0
           group by nf.idcontrato;
        exception
          when no_data_found then
            v_idcontrato := 0;
        end;
      
        if (v_idcontrato > 0) then
          if (nvl(v_idcontrato, 0) <> nvl(p_notafiscal.idcontrato, 0)) then
            v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois a mesma possui um contrato diferente da(s)
                             nota(s) fiscal(is) relacionada(s) na OR.');
            v_msg.addParam(p_idnotafiscal);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          if (v_idcontratoSemNF > 0 and p_notafiscal.idcontrato is not null) then
            v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois ja existe uma nota fiscal vinculada sem
                             contrato na OR.');
            v_msg.addParam(p_idnotafiscal);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end if;
    
      select d.obrigarcontratonfentrada
        into v_obrigacontradonfentrada
        from depositante d
       where d.identidade = p_notafiscal.iddepositante;
    
      if (v_obrigacontradonfentrada = 1 and
         ((p_notafiscal.idcontrato is null) or
         (not pk_contrato.isContratoVigente(p_notafiscal.idcontrato,
                                              p_notafiscal.iddepositante,
                                              p_notafiscal.idarmazem)))) then
        v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois, o depositante obriga que a nota fiscal de entrada possua contrato vigente vinculado.');
        v_msg.addParam(p_idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validaContratoNotaFiscal;
  
    procedure validaNfTpRecebGerarLoteConf
    (
      p_idlotenf     in number,
      p_idNotaFiscal in number
    ) is
      v_qtde number;
      C_TP_RAST_APENAS_CONF_SAIDA constant number := 2;
    begin
      if (isGerarLotePorPalete(p_idlotenf)) then
        if p_idNotaFiscal is not null then
          select count(*)
            into v_qtde
            from notafiscal n, nfdet d, produtodepositante pd
           where n.idnotafiscal = p_idNotaFiscal
             and n.idnotafiscal = d.nf
             and d.idproduto = pd.idproduto
             and n.iddepositante = pd.identidade
             and pd.rastrearinfoespecifica <> C_TP_RAST_APENAS_CONF_SAIDA
             and exists (select 1
                    from informacaomatdep inf
                   where inf.idproduto = pd.idproduto
                     and inf.identidade = pd.identidade);
        
          if v_qtde > 0 then
            v_msg := t_message('Não é permitido vincular notas fiscais que possuam itens que coletam informação específica ' ||
                               'e tenham rastreabilidade diferente de "Coletar Somente na Conf. de Saída" para ' ||
                               'OR do Tipo de Recebimento "Gerar Lote por Conferência"');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end if;
    end validaNfTpRecebGerarLoteConf;
  
    procedure validarNfOrdemDeCompraTransf
    (
      p_idlotenf     in number,
      p_idnotafiscal in number
    ) is
      C_ORDEM_TRANSFERENCIA constant number := 1;
    
      function orPossuiNFVinculada return boolean is
        v_result number;
      begin
        select count(*)
          into v_result
          from notafiscal nf
         where nf.idlotenf = p_idlotenf;
        return v_result > 0;
      end orPossuiNFVinculada;
    
      function origemNfs return boolean is
        v_result number;
      begin
        select count(*)
          into v_result
          from notafiscal nf
         where nf.ordemtransferencia = C_ORDEM_TRANSFERENCIA
           and nf.idlotenf = p_idlotenf;
        return v_result > 0;
      end origemNfs;
    
      function nfAdicionada return boolean is
        v_result number;
      begin
        select count(*)
          into v_result
          from notafiscal nf
         where nf.ordemtransferencia = C_ORDEM_TRANSFERENCIA
           and nf.idnotafiscal = p_idnotafiscal;
        return v_result = 0;
      end nfAdicionada;
    
    begin
      if (orPossuiNFVinculada) then
      
        if (origemNfs) then
          if (nfAdicionada) then
            v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois a mesma não é uma Ordem de Transferência.');
            v_msg.addParam(p_idnotafiscal);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        else
          if (not nfAdicionada) then
            v_msg := t_message('Não pode ser vinculada a nota fiscal {0}, pois existem nota(s) fiscal(s) na or que não são Ordem de Transferência .');
            v_msg.addParam(p_idnotafiscal);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end if;
    end validarNfOrdemDeCompraTransf;
  
    procedure validarQtdeNfCompativelComOt(p_idnotafiscal in number) is
      v_idnfdet                    number;
      v_qtdeNfDet                  number;
      v_ErrBuscaOrdemTransferencia boolean;
    begin
      for nf_itens in (select nfd.idnfdet, (nfd.qtde * e.fatorconversao) qtde
                         from nfdet nfd, embalagem e, notafiscal nf
                        where nfd.nf = p_idnotafiscal
                          and e.idproduto = nfd.idproduto
                          and e.barra = nfd.barra
                          and nf.idnotafiscal = nfd.nf
                          and nf.ordemtransferencia = 1)
      loop
        v_ErrBuscaOrdemTransferencia := false;
        begin
          select t.idnfdet, sum(t.qtde)
            into v_idnfdet, v_qtdeNfDet
            from tdnitemnfdet t
           where t.idnfdet = nf_itens.idnfdet
           group by t.idnfdet;
        exception
          when no_data_found then
            v_ErrBuscaOrdemTransferencia := True;
        end;
      
        if ((v_ErrBuscaOrdemTransferencia) OR
           (nf_itens.qtde <> v_qtdeNfDet)) then
        
          v_msg := t_message('A nota fiscal {0}' || ' (idnotafiscal: {1})' ||
                             ' possui divergências em relação a quantidade de itens vinculados à ordem de transferencia.');
          v_msg.addParam(r_notafiscal.codigointerno);
          v_msg.addParam(r_notafiscal.idnotafiscal);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    end validarQtdeNfCompativelComOt;
  
    procedure validaOrigemIntegracaoNF
    (
      p_idNotaFiscal  in number,
      p_idOr          in number,
      p_idDepositante in number
    ) is
    
      v_origemNf                     number;
      v_depUtzAutorizacaoRecebimento number;
    
      C_ORIGEM_INBOUND constant number := 3;
      C_NAO            constant number := 0;
    
    begin
    
      begin
        select nvl(nfi.origemintegracao, 0)
          into v_origemNf
          from nfimpressao nfi, notafiscal nf
         where nfi.idprenf = nf.idprenf
           and nf.idnotafiscal = p_idnotafiscal;
      exception
        when no_data_found then
          v_origemNf := null;
      end;
    
      select d.utilizaAutorizacaoRecebimento
        into v_depUtzAutorizacaoRecebimento
        from depositante d
       where d.identidade = p_idDepositante;
    
      if (v_origemNf = C_ORIGEM_INBOUND and
         v_depUtzAutorizacaoRecebimento = C_NAO) then
        v_msg := t_message('A Nota Fiscal id:{0} não pode ser vinculada a OR id:{1} pois o Depositante id:{2} não trabalha com Autorização de Recebimento.');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(p_idOr);
        v_msg.addParam(p_idDepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validaOrigemIntegracaoNF;
  
    procedure validarNFAutRecebimento
    (
      r_lotenf     in out lotenf%rowtype,
      r_notafiscal in out notafiscal%rowtype
    ) is
      v_controle    number := 0;
      v_controleInb number := 0;
      v_origem      number;
    begin
    
      select nvl(nfi.origemintegracao, 0),
             (select count(*)
                 from notafiscal nf
                where nf.idlotenf = r_lotenf.idlotenf
                  and nf.idnotafiscal <> r_notafiscal.idnotafiscal),
             (select count(*)
                 from notafiscal nf, nfimpressao nfi
                where nf.idlotenf = r_lotenf.idlotenf
                  and nf.idprenf = nfi.idprenf
                  and nfi.origemintegracao = 3
                  and nf.idnotafiscal <> r_notafiscal.idnotafiscal)
        into v_origem, v_controle, v_controleInb
        from notafiscal nf, nfimpressao nfi
       where nf.idprenf = nfi.idprenf
         and nf.idnotafiscal = r_notafiscal.idnotafiscal;
    
      if (v_origem = 3 and v_controle > 0)
         or (v_origem <> 3 and v_controleInb > 0) then
        v_msg := t_message('Não é permitido vincular mais de uma NF em uma mesma OR quando a origem for de INBOUND.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end validarNFAutRecebimento;
  
  begin
    select *
      into r_lotenf
      from lotenf
     where idlotenf = p_idlotenf;
  
    select *
      into r_notafiscal
      from notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal
       for update;
  
    l_resumoexecucao := t_resumoexecucao();
  
    savepoint s_addNotaFiscalOR;
  
    begin
    
      -- Validar se a Nota foi cadastrada na importação do ASN (Inbound)
      validaOrigemIntegracaoNF(r_notafiscal.idnotafiscal, r_lotenf.idlotenf,
                               r_notafiscal.iddepositante);
    
      -- Validar tipo de entrada da nota fiscal  
      validaTipoEntradaNotaFiscal(r_lotenf.idlotenf,
                                  r_notafiscal.idnotafiscal);
    
      -- Validar se a nota fiscal possui contrato
      validaContratoNotaFiscal(r_lotenf.idlotenf, r_notafiscal);
    
      -- Validar se a Nota Fiscal pode ser incluida na OR quando
      -- esta for do Tipo de Recebimento de Conferência Alocada
      select count(1)
        into v_isNfOrigemTdn
        from notafiscal nf, nfdet nd, tdnitemnfdet tnd
       where nf.idnotafiscal = r_notafiscal.idnotafiscal
         and nf.idnotafiscal = nd.nf
         and nd.idnfdet = tnd.idnfdet;
    
      if (v_isNfOrigemTdn = C_NAO_NUMBER) then
        validaNfTpRecebConfeAlocada(r_lotenf.idlotenf, c_inclusao_nfOr,
                                    r_notafiscal.idnotafiscal);
      end if;
    
      validaLoteIndDuplBacklist(r_lotenf.idlotenf,
                                r_notafiscal.idnotafiscal, l_resumoexecucao,
                                r_resumoexecucao, v_interromperexecucao);
    
      validaNfTpRecebGerarLoteConf(r_lotenf.idlotenf,
                                   r_notafiscal.idnotafiscal);
    
      if (v_interromperexecucao) then
        raise resumo_exception;
      end if;
    
      validarNFSaidaCrossdocking(p_idlotenf, r_lotenf);
    
      validarStatusOR(r_lotenf);
    
      validarNotaFiscal(r_lotenf, r_notafiscal, l_resumoexecucao,
                        r_resumoexecucao, v_interromperexecucao);
    
      if (v_interromperexecucao) then
        raise resumo_exception;
      end if;
    
      validarProdutoDepositante(r_notafiscal, l_resumoexecucao,
                                r_resumoexecucao);
    
      validarCadatroDeProdutos(r_notafiscal, l_resumoexecucao,
                               r_resumoexecucao);
    
      validarCFOP(r_lotenf, r_notafiscal, l_resumoexecucao,
                  r_resumoexecucao);
    
      validarRegime(r_lotenf, l_resumoexecucao, r_resumoexecucao);
    
      validarBacklist(r_notafiscal, l_resumoexecucao, r_resumoexecucao);
    
      validarNfOrdemDeCompraTransf(p_idlotenf, p_idnotafiscal);
    
      validarQtdeNfCompativelComOt(p_idnotafiscal);
    
      validarNFAutRecebimento(r_lotenf, r_notafiscal);
    
      if (l_resumoexecucao.count > 0) then
        for i in l_resumoexecucao.first .. l_resumoexecucao.last
        loop
          r_resumoexecucao := l_resumoexecucao(i);
          if r_resumoexecucao.tipo = TIPORESUMO_ERRO then
            raise resumo_exception;
          end if;
        end loop;
      end if;
    
      update notafiscal nf
         set nf.usuario  = nvl(nf.usuario, p_idusuario),
             nf.idlotenf = r_lotenf.idlotenf
       where nf.idnotafiscal = r_notafiscal.idnotafiscal;
    
      update lotenf
         set qtdenf =
             (select count(1)
                from notafiscal
               where idlotenf = r_lotenf.idlotenf)
       where idlotenf = r_lotenf.idlotenf;
    
      gerarNFEntrada(r_lotenf, r_notafiscal);
    
      pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
    
      r_resumoexecucao.grupo := GRUPO_SUCESSO;
    
      v_msg := t_message('A nota fiscal (numero: {0}' ||
                         ', idNotaFiscal: {1})' ||
                         ' foi vinculada na Ordem de Recebimento.');
      v_msg.addParam(r_notafiscal.codigointerno);
      v_msg.addParam(r_notafiscal.idnotafiscal);
    
      r_resumoexecucao.descricao := v_msg.formatMessage;
      r_resumoexecucao.tipo      := TIPORESUMO_SUCESSO;
      addResumoExecucao(l_resumoexecucao, r_resumoexecucao);
    
      update itemopanfdet ion
         set ion.idlotenf = p_idlotenf
       where ion.idnfdet in (select nfd.idnfdet
                               from nfdet nfd
                              where nfd.nf = p_idnotafiscal);
    
      forall i in 1 .. l_resumoexecucao.count
        insert into gtt_resumoexecucao
        values l_resumoexecucao
          (i);
    
      pk_recebimento_backlist.ajsuteBackupBacklist(r_notafiscal.idnotafiscal,
                                                   0); --o para inserir no backup do backlist 
    
    exception
      when resumo_exception then
        dbms_output.put_line('Total ' || l_resumoexecucao.count);
      
        rollback to s_addNotaFiscalOR;
      
        forall i in 1 .. l_resumoexecucao.count
          insert into gtt_resumoexecucao
          values l_resumoexecucao
            (i);
    end;
  end;

  procedure removeNotaFiscalOR
  (
    p_idlotenf     in number,
    p_idnotafiscal in number,
    p_idusuario    in number
  ) is
    r_lotenf              lotenf%rowtype;
    r_notafiscal          notafiscal%rowtype;
    v_qtdeItensDevolucao  number;
    v_classificacao       tiporecebimento.classificacao%type;
    v_cancelNfOrigInbound boolean;
    v_msgErro             varchar2(4000);
  
    function isInboundCancelado return boolean is
      v_statusinboundasn number;
      C_CANCELADO constant number := 1;
    begin
      select nfi.statusinboundasn
        into v_statusinboundasn
        from nfimpressao nfi
       where idprenf = r_notafiscal.idprenf;
      return v_statusinboundasn = C_CANCELADO;
    end isInboundCancelado;
  
  begin
    select *
      into r_lotenf
      from lotenf
     where idlotenf = p_idlotenf;
  
    validaNfTpRecebConfeAlocada(r_lotenf.idlotenf, c_retirada_nfOr, null);
  
    select *
      into r_notafiscal
      from notafiscal nf
     where nf.idnotafiscal = p_idnotafiscal
       for update;
  
    pk_recebimento_backlist.restaurarBackup(p_idLoteNf, p_idnotaFiscal);
    pk_recebimento_backlist.ajsuteBackupBacklist(r_notafiscal.idnotafiscal,
                                                 1); --o para inserir no backup do backlist 
  
    update notafiscal
       set idlotenf = null
     where idnotafiscal = r_notafiscal.idnotafiscal;
  
    update lotenf
       set qtdenf =
           (select count(1)
              from notafiscal
             where idlotenf = p_idlotenf)
     where idlotenf = p_idlotenf;
  
    update itemopanfdet i
       set i.idlotenf = null
     where i.idlotenf = p_idlotenf
       and i.idnfdet in (select idnfdet
                           from nfdet
                          where nf = p_idnotafiscal);
  
    if (r_notafiscal.idnotafiscalvinculada is not null and
       r_notafiscal.digitada = 'N') then
      delete from nfimpressao
       where idprenf = r_notafiscal.idprenf;
    
      v_qtdeItensDevolucao := pk_notafiscal.qtdeitensdispdevolucao(r_notafiscal.idnotafiscalvinculada);
    
      select t.classificacao
        into v_classificacao
        from lotenf l, tiporecebimento t
       where l.idlotenf = p_idlotenf
         and t.idtiporecebimento = l.idtiporecebimento;
    
      update notafiscal
         set devolucaototal = decode(tipo, 'S',
                                     decode(v_qtdeitensdevolucao, 0, 1, 0),
                                     devolucaototal),
             crossdocking   = decode(v_classificacao, 'B', 'N', crossdocking)
       where idnotafiscal = r_notafiscal.idnotafiscalvinculada;
    end if;
  
    pk_recebimento.Atualizar_Produtos_OR(r_lotenf.idlotenf, 'N');
  
    pk_recebimento_backlist.ajsuteBackupBacklist(r_notafiscal.idnotafiscal,
                                                 1); --o para inserir no backup do backlist   
  
    -- valida se o Inbound (Autorização de Recebimento) foi cancelado.
    v_cancelNfOrigInbound := isInboundCancelado;
  
    if v_cancelNfOrigInbound then
      -- Se cancelado a NF deve ser cancelada automaticamente.
      pk_notafiscal.CancelaNF(r_notafiscal.idprenf, p_idusuario,
                              'Cancelamento automático por desvincular NF com Inbound Cancelado de uma OR',
                              'S', 'N', v_msgErro);
    
      if (v_msgErro is not null) then
        raise_application_error(-20000, v_msgErro);
      end if;
    end if;
  
  end removeNotaFiscalOR;

  function isLivroFiscalFechado(p_idlotenf in number) return boolean is
  begin
    for c_nf in (select distinct lnf.idarmazem,
                                 trunc(n.dataemissao) dataemissao
                   from lotenf lnf, notafiscal n, operacao o
                  where lnf.idlotenf = p_idlotenf
                    and n.idlotenf = lnf.idlotenf
                    and o.idoperacao = n.idoperacao
                    and o.tipooper = 'RA')
    loop
      if (pk_livrofiscal.livroFiscalFechadoNaData(c_nf.idarmazem,
                                                  c_nf.dataemissao, 2) = 1) then
        return true;
      end if;
    end loop;
  
    return false;
  end;

  procedure geraEtqContentoraRecebimento
  (
    p_idarmazem           in number,
    p_qtdecontentora      in number,
    p_idusuariogeracao    in number,
    p_idusuarioutilizacao in number
  ) is
    v_idcontentora number;
    NAO_UTILIZADA constant number := 0;
  begin
    delete from gtt_selecao;
  
    for i in 1 .. p_qtdecontentora
    loop
      select seq_contentorrecebimento.nextval
        into v_idcontentora
        from dual;
    
      insert into contentorrecebimento
        (idcontentorrecebimento, situacao, datageracao, idusuariogeracao,
         datautilizacao, idusuarioutilizacao, idlotenf, idarmazem, barra,
         dataimpressao)
      values
        (v_idcontentora, NAO_UTILIZADA, sysdate, p_idusuariogeracao,
         sysdate, p_idusuarioutilizacao, null, p_idarmazem,
         'CRE' || TO_CHAR(SYSDATE, 'YYYY') || lpad(v_idcontentora, 10, '0'),
         sysdate);
    
      insert into gtt_selecao
      values
        (v_idcontentora);
    end loop;
  end;

  procedure cancelarEtqContentoraReceb(p_idusuario in number) is
    UTILIZADA constant number := 1;
    CANCELADA constant number := 2;
  begin
    for c_contentoras in (select cr.idcontentorrecebimento, cr.situacao
                            from contentorrecebimento cr, gtt_selecao g
                           where g.idselecionado = cr.idcontentorrecebimento)
    loop
      if c_contentoras.situacao = UTILIZADA then
        v_msg := t_message('A ETIQUETA CONTENTORA DE RECEBIMENTO ID: {0}' ||
                           ' NÃO PODE SER CANCELA POIS JÁ FOI UTILIZADA.');
        v_msg.addParam(c_contentoras.idcontentorrecebimento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (c_contentoras.situacao <> CANCELADA) then
        update contentorrecebimento c
           set c.situacao = CANCELADA
         where c.idcontentorrecebimento =
               c_contentoras.idcontentorrecebimento;
      
        pk_utilities.GeraLog(p_idusuario,
                             'CANCELOU A ETIQUETA CONTENTORA DE RECEBIMENTO: ' ||
                              ' ID: ' ||
                              c_contentoras.idcontentorrecebimento,
                             c_contentoras.idcontentorrecebimento, 'EQ');
      end if;
    end loop;
  
  end;

  function getNrosBarraContentora(p_barraComLetras in varchar2)
    return varchar2 is
  
    v_barraSemLetrasAno varchar2(10);
  
  begin
    if (p_barraComLetras is not null) then
      v_barraSemLetrasAno := SUBSTR(p_barraComLetras, 8,
                                    LENGTH(p_barraComLetras));
      return v_barraSemLetrasAno;
    else
      return '';
    end if;
  end;

  procedure gerarImpInformacaoEspecifica
  (
    p_idlotenf       in number,
    p_idproduto      in number,
    p_identidade     in number,
    p_idinfomaterial in number,
    p_altera         in number,
    p_idinfoespec    in number,
    p_valor          in CLOB
  ) is
    v_importarinfoespecifica number;
    v_valorunico             char(1);
    v_geradolote             char(1);
    v_valores                pk_utilities.t_array;
  begin
    begin
      select tr.importarinfoespecifica, lnf.cadloteaut
        into v_importarinfoespecifica, v_geradolote
        from tiporecebimento tr, lotenf lnf
       where lnf.idlotenf = p_idlotenf
         and lnf.idtiporecebimento = tr.idtiporecebimento;
    exception
      when no_data_found then
        v_msg := t_message('A OR: {0} NÃO FOI ENCONTRADA. OPERACAO CANCELADA.');
        v_msg.addParam(p_idlotenf);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_importarinfoespecifica = 0) then
      v_msg := t_message('O TIPO DE RECEBIMENTO DA OR: {0}' ||
                         ' NÃO PERMITE IMPORTAR INFORMAÇÃO ESPECÍFICA. OPERACAO CANCELADA.');
      v_msg.addParam(p_idlotenf);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (v_geradolote = 'S') then
      v_msg := t_message('OS LOTES DA OR: {0} JÁ FORAM GERADOS. OPERACAO CANCELADA.');
      v_msg.addParam(p_idlotenf);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select ip.valorunico
      into v_valorunico
      from informacaomatdep ip
     where ip.identidade = p_identidade
       and ip.idproduto = p_idproduto
       and ip.idinfomaterial = p_idinfomaterial;
  
    v_valores := pk_utilities.split_array(p_valor);
  
    if (v_valores is null) then
      return;
    end if;
  
    delete from gtt_selecaotexto;
    if (v_valorunico = 'S') then
      forall i in 1 .. v_valores.count
        insert into gtt_selecaotexto
          (textoselecionado)
        values
          (trim(v_valores(i)));
    
      for c_valorExistente in (select textoselecionado
                                 from gtt_selecaotexto
                                group by textoselecionado
                               having count(*) > 1)
      loop
        if (c_valorExistente.textoselecionado is not null) then
          v_msg := t_message('O VALOR ({0}) FOI REPETIDO NESTA IMPORTAÇÃO. A INFORMAÇÃO DO MATERIAL FOI CONFIGURADA PARA SER ÚNICA NA IMPORTAÇÃO. VERIFIQUE E TENTE NOVAMENTE. OPERACAO CANCELADA.');
          v_msg.addParam(c_valorExistente.Textoselecionado);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    end if;
  
    if (p_altera = 1) then
      update importarinfoespecifica i
         set i.idinfomaterial = p_idinfomaterial,
             i.valor          = p_valor
       where i.id = p_idinfoespec;
    end if;
  
    if (p_altera = 0) then
      insert into importarinfoespecifica
        (id, idlotenf, idproduto, identidade, idinfomaterial, valor)
      values
        (seq_importarinfoespecifica.nextval, p_idlotenf, p_idproduto,
         p_identidade, p_idinfomaterial, p_valor);
    end if;
  
  end;

  procedure validarORCrossdocking
  (
    p_idDepositante     in number,
    p_IdTipoRecebimento in number
  ) is
    TR_CROSSDOCKING constant char(1) := 'B';
    v_regimeClassificacao char(1);
    v_regimeContICMS      char(1);
    v_classificacao       char(1);
  begin
  
    select tr.classificacao
      into v_classificacao
      from tiporecebimento tr
     where tr.idtiporecebimento = p_IdTipoRecebimento;
  
    if (v_classificacao = TR_CROSSDOCKING) then
      select r.classificacao, r.contribuinteicms
        into v_regimeClassificacao, v_regimeContICMS
        from depositante d, regime r
       where d.identidade = p_idDepositante
         and r.idregime = d.idregime;
    end if;
  end;

  procedure addNfdetOPA
  (
    p_idusuario         in number,
    p_idnfdet           in number,
    p_iditemordemcompra in number,
    p_qtde              in number
  ) is
    type t_item is record(
      qtdeassociada          number,
      qtdedisponivelopa      number,
      qtdedisponivelnf       number,
      statusordemcompra      number,
      codigoordemcompra      ordemcompra.codigoordemcompra%type,
      idlotenf               number,
      idnotafiscal           number,
      idprodutoopa           number,
      idprodutonf            number,
      produtofracionado      char(1),
      iddepositantenf        number,
      iddepositanteopa       number,
      idordemcompra          number,
      idarmazem              number,
      origem                 number,
      rastrearinfoespecifica number,
      infoespecifica         itemordemcompra.infoespecifica%type);
  
    r_item               t_item;
    v_itemopanfdet       number;
    v_qtde               number;
    v_ordemTransferencia number;
  
    procedure validar(r_item in out t_item) is
      ORDEM_ABERTA constant number := 0;
      v_totalInfo number;
      ORIGEM_PRONOVIAS      constant number := 1;
      RASTREAMENTO_COMPLETO constant number := 0;
    begin
      if (r_item.qtdeassociada <= 0) then
        v_msg := t_message('A qtde informada deve ser maior que zero.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                           'QTDE ASSOCIADA: {1}');
        v_msg.addParam(r_item.codigoordemcompra);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.statusordemcompra <> ORDEM_ABERTA) then
        v_msg := t_message('A ordem de compra deve possuir o status EM ABERTO.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}');
        v_msg.addParam(r_item.codigoordemcompra);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdedisponivelopa < r_item.qtdeassociada) then
        v_msg := t_message('Não há quantidade disponivel no item da ordem de compra para associar ao item da nota fiscal.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                           'QTDEDISPONIVEL: {1}' || chr(13) ||
                           'QTDE ASSOCIADA: {2}');
        v_msg.addParam(r_item.codigoordemcompra);
        v_msg.addParam(r_item.qtdedisponivelopa);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.idlotenf is not null) then
        v_msg := t_message('A nota fiscal já esta vinculada a uma ordem de recebimento.' ||
                           chr(13) || 'ORDEM DE RECEBIMENTO: {0}' ||
                           chr(13) || 'NOTA FISCAL ID: {1}');
        v_msg.addParam(r_item.idlotenf);
        v_msg.addParam(r_item.idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdedisponivelnf < r_item.qtdeassociada) then
        v_msg := t_message('A qtde restante para associar os itens não confere com a quantidade informada.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                           'QTDERESTANTE NF: {1}' || chr(13) ||
                           'QTDE INFORMADA: {2}');
        v_msg.addParam(r_item.codigoordemcompra);
        v_msg.addParam(r_item.qtdedisponivelnf);
        v_msg.addParam(r_item.qtdeassociada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.idprodutoopa <> r_item.idprodutonf) then
        v_msg := t_message('O produto informado para o item da ordem compra não é o mesmo do item da nota fiscal.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                           'IDPRODUTO ORDEM DE COMRA: {1}' || chr(13) ||
                           'IDPRODUTO NOTA FISCAL: {2}');
        v_msg.addParam(r_item.codigoordemcompra);
        v_msg.addParam(r_item.idprodutoopa);
        v_msg.addParam(r_item.idprodutonf);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.qtdeassociada <> trunc(r_item.qtdeassociada) and
         r_item.produtofracionado = 'N') then
        v_msg := t_message('Não é permitido informar quantidade fracionada para produto que não foi configurado como FRACIONADO.' ||
                           chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                           'IDPRODUTO: {1}');
        v_msg.addParam(r_item.codigoordemcompra);
        v_msg.addParam(r_item.idprodutoopa);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_item.iddepositanteopa is not null) then
        if (r_item.iddepositantenf <> r_item.iddepositanteopa) then
          v_msg := t_message('O depositante informado para o item da ordem compra não é o mesmo do item da nota fiscal.' ||
                             chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                             'IDDEPOSITANTE ORDEM DE COMRA: {1}' || chr(13) ||
                             'IDDEPOSITANTE NOTA FISCAL: {2}');
          v_msg.addParam(r_item.codigoordemcompra);
          v_msg.addParam(r_item.iddepositanteopa);
          v_msg.addParam(r_item.iddepositantenf);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if (r_item.origem = ORIGEM_PRONOVIAS and
         r_item.infoespecifica is not null) then
      
        select count(*) total
          into v_totalInfo
          from informacaomatdep
         where idproduto = r_item.idprodutoopa
           and identidade = r_item.iddepositanteopa;
      
        if (v_totalInfo = 0) then
          v_msg := t_message('Não existe informação específica cadastrada para o produto.' ||
                             chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                             'IDPRODUTO: {1}' || chr(13) ||
                             'IDDEPOSITANTE: {2}');
          v_msg.addParam(r_item.codigoordemcompra);
          v_msg.addParam(r_item.idprodutoopa);
          v_msg.addParam(r_item.iddepositanteopa);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (v_totalInfo > 1) then
          v_msg := t_message('Existe mais de uma informação específica cadastrada para o produto.' ||
                             chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                             'IDPRODUTO: {1}' || chr(13) ||
                             'IDDEPOSITANTE: {2}');
          v_msg.addParam(r_item.codigoordemcompra);
          v_msg.addParam(r_item.idprodutoopa);
          v_msg.addParam(r_item.iddepositanteopa);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_item.rastrearinfoespecifica <> RASTREAMENTO_COMPLETO) then
          v_msg := t_message('O controle informação específica é diferente de Coletar no Recebimento e Rastrear na Movimentação.' ||
                             chr(13) || 'ORDEM DE COMPRA: {0}' || chr(13) ||
                             'IDPRODUTO: {1}' || chr(13) ||
                             'IDDEPOSITANTE: {2}');
          v_msg.addParam(r_item.codigoordemcompra);
          v_msg.addParam(r_item.idprodutoopa);
          v_msg.addParam(r_item.iddepositanteopa);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end validar;
  
  begin
    r_item.qtdeassociada := p_qtde;
  
    select a.qtdedisponivelopa, a.status, a.codigoordemcompra, pd.idproduto,
           a.fracionado, a.iddepositante, a.idordemcompra, a.idarmazem,
           a.origem, pd.rastrearinfoespecifica, a.infoespecifica
      into r_item.qtdedisponivelopa, r_item.statusordemcompra,
           r_item.codigoordemcompra, r_item.idprodutoopa,
           r_item.produtofracionado, r_item.iddepositanteopa,
           r_item.idordemcompra, r_item.idarmazem, r_item.origem,
           r_item.rastrearinfoespecifica, r_item.infoespecifica
      from (select (i.qtdesolicitada - i.qtderecebida) qtdedisponivelopa,
                    o.status, o.codigoordemcompra, p.idproduto, p.fracionado,
                    o.iddepositante, o.idordemcompra, o.idarmazem, o.origem,
                    i.infoespecifica
               from itemordemcompra i, ordemcompra o, produto p
              where i.iditemordemcompra = p_iditemordemcompra
                and o.idordemcompra = i.idordemcompra
                and p.idproduto = i.idproduto) a, produtodepositante pd
     where pd.identidade(+) = a.iddepositante
       and pd.idproduto(+) = a.idproduto;
  
    if r_item.idprodutoopa is null then
      select idproduto
        into r_item.idprodutoopa
        from itemordemcompra
       where iditemordemcompra = p_iditemordemcompra;
    
      v_msg := t_message('O produto não está vinculado ao depositante' ||
                         chr(13) || 'IDDEPOSITANTE: {0}' || chr(13) ||
                         'IDPRODUTO: {1}');
      v_msg.addParam(r_item.iddepositanteopa);
      v_msg.addParam(r_item.idprodutoopa);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select (nd.qtde * e.fatorconversao) -
            nvl((select sum(ion.qtde)
                  from itemopanfdet ion
                 where ion.idnfdet = nd.idnfdet
                   and ion.iditemordemcompra <> p_iditemordemcompra), 0),
           nf.idlotenf, nf.idnotafiscal, nd.idproduto, nf.iddepositante,
           nf.ordemtransferencia
      into r_item.qtdedisponivelnf, r_item.idlotenf, r_item.idnotafiscal,
           r_item.idprodutonf, r_item.iddepositantenf, v_ordemTransferencia
      from nfdet nd, embalagem e, notafiscal nf
     where nd.idnfdet = p_idnfdet
       and e.idproduto = nd.idproduto
       and e.barra = nd.barra
       and nf.idnotafiscal = nd.nf;
  
    if (v_ordemTransferencia <> 0) then
      v_msg := t_message('Não é possível vincular nota pertencente a ' ||
                         'Ordem de Transferência em uma Ordem de Compra');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validar(r_item);
  
    update notafiscal
       set idarmazem = r_item.idarmazem
     where idnotafiscal = r_item.idnotafiscal
       and idarmazem is null;
  
    begin
      select i.iditemopanfdet
        into v_itemopanfdet
        from itemopanfdet i
       where i.idnfdet = p_idnfdet
         and i.iditemordemcompra = p_iditemordemcompra;
    exception
      when no_data_found then
        v_itemopanfdet := 0;
    end;
  
    if (v_itemopanfdet = 0) then
      insert into itemopanfdet
        (iditemopanfdet, iditemordemcompra, idnfdet, qtde, idusuariocriacao,
         datacriacao, idlotenf)
      values
        (seq_itemopanfdet.nextval, p_iditemordemcompra, p_idnfdet, p_qtde,
         p_idusuario, sysdate, r_item.idlotenf);
    else
      select qtde
        into v_qtde
        from itemopanfdet
       where iditemopanfdet = v_itemopanfdet;
    
      update itemopanfdet i
         set qtde               = v_qtde + p_qtde,
             idusuarioalteracao = p_idusuario,
             dataalteracao      = sysdate
       where iditemopanfdet = v_itemopanfdet;
    end if;
  
    -- Adiciona qtde do item da nfe do item da opa 
    update itemordemcompra
       set qtderecebida =
           (qtderecebida + p_qtde)
     where iditemordemcompra = p_iditemordemcompra;
  
    if (r_item.iddepositanteopa is null) then
      update ordemcompra o
         set o.iddepositante = r_item.iddepositantenf
       where o.idordemcompra = r_item.idordemcompra;
    end if;
  end;

  procedure removeNfdetOPA
  (
    p_idusuario         in number,
    p_idnfdet           in number,
    p_iditemordemcompra in number
  ) is
    v_idlotenf     number;
    v_codInternoNF number;
  begin
    begin
      select nf.idlotenf, nf.codigointerno
        into v_idlotenf, v_codInternoNF
        from itemopanfdet i, nfdet nd, notafiscal nf
       where i.idnfdet = p_idnfdet
         and i.iditemordemcompra = p_iditemordemcompra
         and nd.idnfdet = i.idnfdet
         and nf.idnotafiscal = nd.nf;
    exception
      when no_data_found then
        v_msg := t_message('O item associado não foi encontrado. Atualize a tela e tente novamente.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_idlotenf is not null) then
      v_msg := t_message('A nota fiscal com código interno {0}' ||
                         ' já esta vinculada a uma ordem de recebimento. Não é permitido alteração.' ||
                         chr(13) || 'ORDEM DE RECEBIMENTO: {1}');
      v_msg.addParam(v_codInternoNF);
      v_msg.addParam(v_idlotenf);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Retira qtde do item da nfe do item da opa 
    update itemordemcompra
       set qtderecebida = nvl((qtderecebida -
                              (select idet.qtde
                                  from itemopanfdet idet
                                 where idet.idnfdet = p_idnfdet
                                   and idet.iditemordemcompra =
                                       p_iditemordemcompra)), 0)
     where iditemordemcompra = p_iditemordemcompra;
  
    delete itemopanfdet
     where idnfdet = p_idnfdet
       and iditemordemcompra = p_iditemordemcompra;
  
  end;

  procedure removeVariasNFsOPA(p_idusuario in number) is
  begin
    for cNfs in (select i.iditemordemcompra, i.idnfdet
                   from gtt_selecao g, nfdet nfd, itemopanfdet i
                  where nfd.nf = g.idselecionado
                    and i.idnfdet = nfd.idnfdet)
    loop
      removeNfdetOPA(p_idusuario, Cnfs.Idnfdet, Cnfs.Iditemordemcompra);
    end loop;
  end;

  procedure vincularTipoRecebOperacao
  (
    p_idTipoRecebimento in number,
    p_idOperacao        in number
  ) is
  begin
  
    insert into cfoptiporecebimento
      (idtiporecebimento, idoperacao)
    values
      (p_idTipoRecebimento, p_idOperacao);
  
  exception
    when others then
      v_msg := t_message('OCORREU UM ERRO AO TENTAR VINCULAR A OPERAÇÃO: ' ||
                         '{0} AO TIPO DE RECEBIMENTO: {1}');
      v_msg.addParam(p_idOperacao);
      v_msg.addParam(p_idTipoRecebimento);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  procedure desvincularTipoRecebOperacao
  (
    p_idTipoRecebimento in number,
    p_idOperacao        in number
  ) is
  begin
  
    delete from cfoptiporecebimento
     where idtiporecebimento = p_idTipoRecebimento
       and idoperacao = p_idOperacao;
  
  exception
    when others then
      v_msg := t_message('OCORREU UM ERRO AO TENTAR DESVINCULAR A OPERAÇÃO: ' ||
                         '{0} DO TIPO DE RECEBIMENTO: {1}');
      v_msg.addParam(p_idOperacao);
      v_msg.addParam(p_idTipoRecebimento);
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  procedure validarRemetente
  (
    p_idLoteNf      in number,
    p_idDepositante in number,
    p_idRemetente   in number
  ) is
    v_obrigaremetenteor char(1);
    v_remetenteInativo  int;
  begin
    select max(d.obrigaremetenteor)
      into v_obrigaremetenteor
      from depositante d
     where d.identidade = p_idDepositante;
  
    if v_obrigaremetenteor = 'S'
       and p_idRemetente is null then
      v_msg := t_message('O depositante está configurado para obrigar remetente na OR e o mesmo não foi informado.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select max(1)
      into v_remetenteInativo
      from entidade a
     where a.identidade = p_idRemetente
       and a.ativo = 'N';
  
    if v_remetenteInativo = 1
       and p_idLoteNf is null then
      v_msg := t_message('O remetente informado está inativo.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end;

  procedure gerarcaixavolume
  (
    p_idlotenf          in number,
    p_idtipocaixavolume in number,
    p_qtde              in number,
    p_idtipocaixalotenf in number,
    p_altera            in number,
    p_idusuario         in number
    
  ) is
    v_situacaoor               number;
    v_tipocaixadev             number;
    v_idtiporecebimento        number;
    v_descrcaixa               tipocaixavolume.descr%type;
    v_idtipocaixalotenf        number;
    v_classificacaorecebimento varchar2(1);
  
    procedure novacaixavolume
    (
      p_idlotenf          in number,
      p_idtipocaixavolume in number,
      p_qtde              in number,
      p_idtipocaixalotenf in number,
      p_idusuario         in number
    ) is
    begin
    
      if p_altera = 1 then
        update tipocaixalotenf t
           set t.idtipocaixavolume = p_idtipocaixavolume,
               t.qtde              = p_qtde,
               t.data              = sysdate,
               t.idusuario         = p_idusuario
         where t.idtipocaixalotenf = p_idtipocaixalotenf;
      
      elsif p_altera = 0 then
      
        select seq_tipocaixalotenf.nextval
          into v_idtipocaixalotenf
          from dual;
      
        insert into tipocaixalotenf
          (idlotenf, idtipocaixavolume, qtde, idtipocaixalotenf, data,
           idusuario)
        values
          (p_idlotenf, p_idtipocaixavolume, p_qtde, v_idtipocaixalotenf,
           sysdate, p_idusuario);
      end if;
    
    exception
    
      when dup_val_on_index then
        select descr
          into v_descrcaixa
          from tipocaixavolume tcv
         where tcv.idtipocaixavolume = p_idtipocaixavolume;
        v_msg := t_message('A CAIXA: {0} JÁ ESTÁ ASSOCIADA A ESTA OR.');
        v_msg.addParam(v_descrcaixa);
        raise_application_error(-20000, v_msg.formatMessage);
      
      when others then
        v_msg := t_message('NÃO FOI POSSÍVEL ASSOCIAR A CAIXA NESSA OR. ' ||
                           '{0} - {1}');
        v_msg.addParam(sqlcode);
        v_msg.addParam(sqlerrm);
        raise_application_error(-20000, v_msg.formatMessage);
      
    end;
  
  begin
    if isConferenciaAlocada(p_idlotenf) then
      v_msg := t_message('Ação não pode ser executada pois a OR é do Tipo de Recebimento de Conferência Alocada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_situacaoor
      from dual
     where exists
     (select 1
              from lotenf l
             where l.idlotenf = p_idlotenf
               and (l.dtinicioalocacao is not null or l.mapaaloc = c_sim));
  
    select tr.tipocaixadevolucao, l.idtiporecebimento, tr.classificacao
      into v_tipocaixadev, v_idtiporecebimento, v_classificacaorecebimento
      from lotenf l, tiporecebimento tr
     where l.idtiporecebimento = tr.idtiporecebimento
       and l.idlotenf = p_idlotenf;
  
    if v_situacaoor = 1 then
      v_msg := t_message('NÃO É POSSÍVEL SALVAR. VERIFIQUE SE UM MAPA DE ALOCAÇÃO FOI GERADO OU SE JÁ EXISTEM LOTES GERADOS.');
      raise_application_error(-20000, v_msg.formatMessage);
    elsif v_classificacaorecebimento not in ('D', 'T') then
      v_msg := t_message('NÃO É POSSÍVEL SALVAR. O TIPO DE RECEBIMENTO {0}' ||
                         ' NÃO ESTÁ CLASSIFICADO COMO DEVOLUÇÃO PARCIAL OU TOTAL.');
      v_msg.addParam(v_idtiporecebimento);
      raise_application_error(-20000, v_msg.formatMessage);
    elsif v_tipocaixadev = 0 then
      v_msg := t_message('NÃO É POSSÍVEL SALVAR. O PARÂMETRO PARA ESCOLHER TIPO DE CAIXA PARA DEVOLUÇÃO DE PRODUTOS, DO TIPO DE RECEBIMENTO ' ||
                         '{0} NÃO ESTÁ ACIONADO.');
      v_msg.addParam(v_idtiporecebimento);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    novacaixavolume(p_idlotenf, p_idtipocaixavolume, p_qtde,
                    p_idtipocaixalotenf, p_idusuario);
  
  end;

  function retornarAutorizacaoItem(p_idnotafiscal in number) return number is
    v_itensNF              number;
    v_ItensAssociados      number;
    v_tipoRecebimentoNfTDN number;
    C_NAO_AUTORIZADO          constant number := 0;
    C_AUTORIZADO              constant number := 1;
    C_PARCIALMENTE_AUTORIZADO constant number := 2;
  
    procedure carregarDados is
    begin
    
      select nf.ordemtransferencia,
             nvl(sum((nfd.qtde * e.fatorconversao)), 0) itensNF
        into v_tipoRecebimentoNfTDN, v_itensNF
        from notafiscal nf, nfdet nfd, embalagem e
       where nf.idnotafiscal = p_idnotafiscal
         and nfd.nf(+) = nf.idnotafiscal
         and e.idproduto = nfd.idproduto
         and e.barra = nfd.barra
       group by nf.ordemtransferencia;
    
    end carregarDados;
  
    procedure fluxoOPAItensAssociados is
    begin
    
      if (v_tipoRecebimentoNfTDN = 1) then
        return;
      end if;
    
      begin
        select nvl(sum(i.qtde), 0)
          into v_ItensAssociados
          from itemopanfdet i, nfdet nd
         where nd.nf = p_idnotafiscal
           and i.idnfdet = nd.idnfdet;
      exception
        when no_data_found then
          v_ItensAssociados := 0;
      end;
    end fluxoOPAItensAssociados;
  
    procedure fluxoTDNItensAssociados is
    begin
    
      if (v_tipoRecebimentoNfTDN = 0) then
        return;
      end if;
    
      begin
        select nvl(sum(i.qtde), 0)
          into v_ItensAssociados
          from tdnitemnfdet i, nfdet nd
         where nd.nf = p_idnotafiscal
           and i.idnfdet = nd.idnfdet;
      exception
        when no_data_found then
          v_ItensAssociados := 0;
      end;
    end fluxoTDNItensAssociados;
  
  begin
  
    carregarDados;
  
    fluxoOPAItensAssociados;
  
    fluxoTDNItensAssociados;
  
    if (v_ItensAssociados = 0) then
      return C_NAO_AUTORIZADO;
    end if;
  
    if (v_ItensAssociados = v_itensNF) then
      return C_AUTORIZADO;
    end if;
  
    return C_PARCIALMENTE_AUTORIZADO;
  
  end retornarAutorizacaoItem;

  procedure validarOrdemServico(p_idlotenf number) is
    v_oskit number;
  begin
    select count(1)
      into v_oskit
      from dual
     where exists (select 1
              from ordemservico os, romaneiopai rp
             where os.idlotenf = p_idlotenf
               and os.situacao not in ('D', 'T')
               and rp.idromaneio = os.idromaneio
               and rp.tipo = 0
               and os.tiposervico = 'D'
            union
            select 1
              from ordemservico os, romaneiopai rp
             where os.idlotenf = p_idlotenf
               and rp.idromaneio = os.idromaneio
               and rp.tipo = 1
               and os.tiposervico = 'D'
               and rp.liberado = 'N');
  
    if (v_oskit > 0) then
      v_msg := t_message('Separação de saida e conferência de saida não foram executadas para a Ordem de Serviço de idLoteNF: {0}.' ||
                         chr(13) || ' Operação Cancelada.');
      v_msg.addParam(p_idlotenf);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end validarOrdemServico;

  procedure validaNfTpRecebConfeAlocada
  (
    p_idlotenf     in number,
    p_operacao     in number,
    p_idNotaFiscal in number
  ) is
  
    v_statusOr                number;
    v_tipoConfAlocada         number;
    v_qtde_prodindustria      number;
    v_qtde_naoCriticaBackList number;
    C_OR_PEND_CONFERENCIA   constant number := 0;
    C_OR_CONF_EM_ANDAMENTO  constant number := 1;
    C_TP_RECEB_CONF_ALOCADA constant number := 1;
  
  begin
  
    select tr.conferenciaalocada,
           decode(lnf.status, 'P', 3,
                   decode(lnf.flaglibnf, 0, 0, 1, 1, 2, 2)) status
      into v_tipoConfAlocada, v_statusOr
      from lotenf lnf, tiporecebimento tr
     where lnf.idlotenf = p_idlotenf
       and tr.idtiporecebimento = lnf.idtiporecebimento;
  
    if (v_tipoConfAlocada = C_TP_RECEB_CONF_ALOCADA) then
      if (p_operacao = c_inclusao_nfOr) then
        if not ((v_statusOr = C_OR_PEND_CONFERENCIA) or
            (v_statusOr = C_OR_CONF_EM_ANDAMENTO)) then
          v_msg := t_message('Não é permitido o vínculo de NF quando o Tipo de Recebimento for de "Conferencia Alocada"' ||
                             chr(13) ||
                             'e o status da OR for diferente de "PENDENTE DE CONFERÊNCIA" ou "CONFERÊNCIA EM ANDAMENTO".');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      else
        if (v_statusOr <> C_OR_PEND_CONFERENCIA) then
          v_msg := t_message('Não é permitido o desvínculo de NF quando o Tipo de Recebimento for de "Conferencia Alocada"' ||
                             'e o status da OR for diferente de "PENDENTE DE CONFERÊNCIA".');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if p_idNotaFiscal is not null then
        select count(*)
          into v_qtde_prodindustria
          from notafiscal n, nfdet d, produtodepositante pd
         where n.idnotafiscal = p_idNotaFiscal
           and n.idnotafiscal = d.nf
           and d.idproduto = pd.idproduto
           and n.iddepositante = pd.identidade
           and pd.coletaloteindust = 'N';
      
        if v_qtde_prodindustria > 0 then
          v_msg := t_message('Não é permitido o vínculo de NF quando o Tipo de Recebimento for de "Conferencia Alocada"' ||
                             chr(13) ||
                             'sem que todos os produtos da NF estejam parametrizados para coletar lote industria".');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if p_idNotaFiscal is not null then
        select count(*)
          into v_qtde_naoCriticaBackList
          from notafiscal n, nfdet d, produtodepositante pd
         where n.idnotafiscal = p_idNotaFiscal
           and n.idnotafiscal = d.nf
           and d.idproduto = pd.idproduto
           and n.iddepositante = pd.identidade
           and pd.naocriticabacklist = 1;
      
        if v_qtde_naoCriticaBackList > 0 then
          v_msg := t_message('Não é permitido o vínculo de NF quando o Tipo de Recebimento for de "Conferencia Alocada"' ||
                             chr(13) ||
                             'sem que todos os produtos da NF estejam parametrizados para participar da crítica de BackList".');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
    end if;
  
  end validaNfTpRecebConfeAlocada;

  procedure validarTipoRecebimento
  (
    p_iddepositante     in number,
    p_idtiporecebimento in number
  ) is
    v_conferenciaAlocada number;
    v_validaDepositante  number;
  begin
    begin
      select tc.conferenciaalocada
        into v_conferenciaAlocada
        from tiporecebimento tc
       where tc.idtiporecebimento = p_idtiporecebimento
         and tc.conferenciaalocada = 1;
    exception
      when no_data_found then
        v_conferenciaAlocada := 0;
    end;
  
    if (v_conferenciaAlocada = 1) then
      begin
        select 1
          into v_validaDepositante
          from depositante dep
         where dep.utzbacklist <> 0
           and dep.volumesagrupamento = 'S'
           and dep.identidade = p_iddepositante;
      exception
        when no_data_found then
          v_validaDepositante := 0;
      end;
    
      if (v_validaDepositante = 1) then
        v_msg := t_message('Somente depositantes que utilizam BackList e ' ||
                           'que não utilizam Volume Agrupamento podem ' ||
                           'fazer uso de Tipo de Recebimento marcado ' ||
                           'como Conferencia Alocada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
  end validarTipoRecebimento;

  function getMaxLoteIndustriaNfdetImp
  (
    p_idlotenf  number,
    p_idproduto number
  ) return varchar2 is
    v_codigoindustria nfdetimpressao.codigoindustria%type;
  begin
    select max(ndi.codigoindustria)
      into v_codigoindustria
      from notafiscal nf, nfdet nd, nfdetimpressao ndi
     where nd.nf = nf.idnotafiscal
       and ndi.idnfdet = nd.idnfdet
       and nd.idproduto = p_idproduto
       and nf.idlotenf = p_idlotenf;
  
    return v_codigoindustria;
  end getMaxLoteIndustriaNfdetImp;

  function isOrdemServico(p_lotenf in number) return boolean is
    v_qtde number;
  begin
    select count(1)
      into v_qtde
      from ordemservico
     where idlotenf = p_lotenf;
  
    return v_qtde > 0;
  end isOrdemServico;

end pk_recebimento;
/

