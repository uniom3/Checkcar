create view V_PRODUTIVIDADECOLETANF as
select pn.data, pn.operador, sum(qtdenfs) qtdenfs
  from (select trunc(nfr.dataconferencia) data, u.nomeusuario operador,
                count(nfr.idnotafiscal) qtdenfs
           from nfromaneio nfr, notafiscalcarga nfc, carga ca, usuario u
          where nfr.conferido = 'S'
            and u.idusuario = nfr.idusuarioconferencia
            and ca.idcarga = nfc.idcarga
            and nfc.idnotafiscal = nfr.idnotafiscal
          group by trunc(nfr.dataconferencia), u.nomeusuario) pn
 group by pn.data, pn.operador
 order by pn.data, pn.operador
/

