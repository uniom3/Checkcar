create view VT_IMPORTARINFOESPECIFICA as
select i.informacao, 
       case
          when length(ie.valor) > 4000 then
           substr(dbms_lob.substr(ie.valor, 4000, 1), 1, 3997) || '...'
          else
           dbms_lob.substr(ie.valor, 4000, 1)
        end valor, ie.id h$id, ie.idlotenf h$idlotenf,
       ie.idproduto h$idproduto, ie.identidade h$iddepositante,
       ie.idinfomaterial h$idinfomaterial
  from importarinfoespecifica ie, informacaomaterial i
 where i.idinfomaterial = ie.idinfomaterial
 order by i.sequencia
/

