create package body PK_TROCALOTESEP is

  TROCA_ANDAMENTO constant number := 0;
  TROCA_REALIZADA constant number := 1;
  TROCA_CANCELADA constant number := 2;

  DETALHE_TROCA_ATIVO  constant number := 1;
  DETALHE_TROCA_ALERTA constant number := 2;

  ACAO_MOV_CANCELADA constant number := 0;
  ACAO_MOV_CRIADA    constant number := 1;

  procedure trocarQtdeAtendidaNF
  (
    p_idnotafiscal in number,
    p_idproduto    in number,
    p_qtdeunit     in number
  ) is
    v_qtdePorProdutoUN number;
  
    procedure validacoes is
      v_fatorMaiorQueUm number;
      v_usaTolerancia   number;
      v_msg             t_message;
    begin
      if (p_qtdeunit <= 0) then
        v_msg := t_message('A quantidade deverá ser maior que zero.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_fatorMaiorQueUm
        from dual
       where exists (select 1
                from nfdet nd, embalagem e, produto p
               where nd.nf = p_idnotafiscal
                 and nd.idproduto = p_idproduto
                 and e.barra = nd.barra
                 and e.idproduto = nd.idproduto
                 and e.idproduto = p.idproduto
                 and e.fatorconversao > 1);
    
      if (v_fatorMaiorQueUm > 0) then
        v_msg := t_message('Você não pode trocar lote separação para pedidos que possuem o mesmo produto com fator de conversão maior que 1: Notafiscal: {0}, idProduto: {1}');
        v_msg.addParam(p_idnotafiscal);
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_usaTolerancia
        from dual
       where exists (select 1
                from notafiscal nf, depositante d
               where nf.idnotafiscal = p_idnotafiscal
                 and d.identidade = nf.iddepositante
                 and d.fracionarlote = 0
                 and nf.tiponf = 'P');
    
      if (v_usatolerancia = 0) then
        v_msg := t_message('Não é permitido alterar a quantidade atendida da nota fiscal para um depositante que não trabalha com tolerância.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validacoes;
  
    procedure addQtdeAtendida(p_qtdeAdicionar number) is
      v_idnfdet          number;
      v_idnfdetimpressao number;
    begin
      select nd.idnfdet
        into v_idnfdet
        from nfdet nd
       where nd.nf = p_idnotafiscal
         and nd.idproduto = p_idproduto
         and rownum = 1;
    
      update nfdet nd
         set nd.qtdeatendida       = nd.qtdeatendida + p_qtdeAdicionar,
             nd.atendidotolerancia = 1
       where nd.idnfdet = v_idnfdet;
    
      select nd.idnfdeti
        into v_idnfdetimpressao
        from nfdetimpressao nd
       where nd.idnfdet = v_idnfdet
         and rownum = 1;
    
      update nfdetimpressao nd
         set nd.qtdeatendida = nd.qtdeatendida + p_qtdeAdicionar
       where nd.idnfdet = v_idnfdetimpressao;
    
    end addQtdeAtendida;
  
    procedure removeQtdeAtendida(p_qtdeRemover in number) is
      cursor c_nd is
        select nd.idnfdet, nd.qtdeatendida, e.fatorconversao
          from nfdet nd, embalagem e
         where nd.nf = p_idnotafiscal
           and nd.idproduto = p_idproduto
           and e.barra = nd.barra
           and e.idproduto = nd.idproduto
         order by nd.qtde desc;
    
      v_qtderemover  number;
      v_qtde         number;
      v_qtdesubtrair number;
    
      procedure atualizarNfDetImpressao
      (
        p_idnfdet      in number,
        p_qtdesubtrair in number
      ) is
        cursor c_ndi(p_idnfdet number) is
          select ndi.idnfdeti, ndi.qtdeatendida
            from nfdetimpressao ndi
           where ndi.idnfdet = p_idnfdet;
      
        v_qtderemoverIMP  number;
        v_qtdesubtrairIMP number;
        v_qtdeIMP         number;
      begin
        v_qtderemoverIMP := p_qtdesubtrair;
      
        for r_ndi in c_ndi(p_idnfdet)
        loop
          v_qtdeIMP := v_qtderemoverIMP;
        
          if (v_qtdeIMP > r_ndi.qtdeatendida) then
            v_qtdesubtrairIMP := r_ndi.qtdeatendida;
          else
            v_qtdesubtrairIMP := v_qtdeIMP;
          end if;
        
          v_qtderemoverIMP := v_qtderemoverIMP - v_qtdesubtrairIMP;
        
          update nfdetimpressao ndi
             set ndi.qtdeatendida = ndi.qtdeatendida - v_qtdesubtrairIMP
           where ndi.idnfdeti = r_ndi.idnfdeti;
        end loop;
      end atualizarNfDetImpressao;
    
    begin
      v_qtderemover := p_qtdeRemover;
    
      for r_nd in c_nd
      loop
        v_qtde := trunc(v_qtderemover / r_nd.fatorconversao);
      
        if (v_qtde > r_nd.qtdeatendida) then
          v_qtdesubtrair := r_nd.qtdeatendida;
        else
          v_qtdesubtrair := v_qtde;
        end if;
      
        v_qtderemover := v_qtderemover -
                         (v_qtdesubtrair * r_nd.fatorconversao);
      
        update nfdet nd
           set nd.qtdeatendida       = nd.qtdeatendida - v_qtdesubtrair,
               nd.atendidotolerancia = 1
         where nd.idnfdet = r_nd.idnfdet;
      
        atualizarNfDetImpressao(r_nd.idnfdet, v_qtdesubtrair);
      end loop;
    
    end;
  begin
    validacoes;
  
    select sum(nd.qtdeatendida * e.fatorconversao)
      into v_qtdePorProdutoUN
      from nfdet nd, embalagem e
     where nd.nf = p_idnotafiscal
       and nd.idproduto = p_idproduto
       and e.barra = nd.barra
       and e.idproduto = nd.idproduto;
  
    if (p_qtdeunit > v_qtdePorProdutoUN) then
      addQtdeAtendida(p_qtdeunit - v_qtdePorProdutoUN);
    else
      removeQtdeAtendida(v_qtdePorProdutoUN - p_qtdeunit);
    end if;
  
  end trocarQtdeAtendidaNF;

  function trocarLoteIndustriaSep
  (
    p_idTroca         in number,
    p_idRegiaoDestino in number,
    p_bufferDestino   in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_tarefa          in varchar2 := null
  ) return number is
  
    TROCALOTE_ERRO    constant number := 0;
    TROCALOTE_SUCESSO constant number := 1;
  
    r_trocalote          trocarloteseponda%rowtype;
    v_statusonda         number;
    v_qtdeRetiradaMov    number;
    v_qtdeTotalTroca     number;
    v_totalmov           number;
    v_totalitem          number;
    v_estoqueJaUsado     boolean;
    v_idLocalDestino     number;
    v_idconfiguracaoonda number;
    v_tolerancia         depositante.percentualtolerancia%type;
    v_fracionarLote      number;
  
    v_msg t_message;
  
    procedure getTrocaLoteIndustria is
    begin
      begin
        select tl.*
          into r_trocalote
          from trocarloteseponda tl
         where tl.id = p_idTroca;
      exception
        when no_data_found then
          v_msg := t_message('Troca de Lote Indústria não encontrada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (r_trocalote.status = TROCA_REALIZADA) then
        v_msg := t_message('Troca de Lote Indústria está FINALIZADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_trocalote.status = TROCA_CANCELADA) then
        v_msg := t_message('Troca de Lote Indústria está CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end getTrocaLoteIndustria;
  
    procedure validarDadosParaTroca is
      v_permitealterarlote   number;
      v_tiponf               notafiscal.tiponf%type;
      v_enviadofaturamento   notafiscal.enviadofaturamento%type;
      v_percentualtolerancia number;
      v_margemMenor          number;
      v_margemMaior          number;
      v_qtdeKitProduto       number;
    begin
      select permitiralterarqtdeseparacao, percentualtolerancia
        into v_permitealterarlote, v_percentualtolerancia
        from depositante
       where identidade = r_trocalote.iddepositante;
    
      if (v_permitealterarlote = 0) then
        v_msg := t_message('O Depositante Id: {0} não está configurado para permitir alterar qtde em separação.');
        v_msg.addParam(r_trocalote.iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select nf.tiponf, nf.enviadofaturamento
        into v_tiponf, v_enviadofaturamento
        from notafiscal nf
       where nf.idnotafiscal = r_trocalote.idnotafiscal;
    
      if (v_tiponf <> 'P') then
        v_msg := t_message('O Documento Id: {0} não é pedido. A Qtde não pode ser alterada.');
        v_msg.addParam(r_trocalote.idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_tiponf = 'P' and v_enviadofaturamento = 'S') then
        v_msg := t_message('A separação atual envolve um pedido que já foi enviado para faturamento.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select sum(tld.qtdedisponivel)
        into v_qtdeTotalTroca
        from trocarlotesepondadet tld, trocarloteseponda tl
       where tl.id = p_idTroca
         and tl.status = TROCA_ANDAMENTO
         and tl.id = tld.idtrocalote
         and tld.status = DETALHE_TROCA_ATIVO;
    
      if (v_qtdeTotalTroca = 0) then
        v_msg := t_message('Não existem lote(s) industria(s) separado(s) para realizar a troca.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- valida se o produto esta presente em um kit e bloqueia devido a troca de lote nao suportar troca de kit
      select count(*)
        into v_qtdeKitProduto
        from nfromaneio nfr, nfdet nd, embalagem ecd,
             (select k.idprodutokit, k.idproduto, ke.barra,
                      (k.qtde * ke.fatorconversao) qtde, ke.altura, ke.largura,
                      ke.comprimento, ke.pesobruto
                 from kitproduto k, embalagem ke
                where k.idproduto = ke.idproduto
                  and k.barra = ke.barra) k
       where nfr.idromaneio = r_trocalote.idonda
         and nfr.idnotafiscal = r_trocalote.idnotafiscal
         and nd.nf = nfr.idnotafiscal
         and ecd.barra = nd.barra
         and ecd.idproduto = nd.idproduto
         and nd.idproduto = r_trocalote.idproduto
         and k.idproduto = nd.idproduto;
    
      if (v_qtdeKitProduto > 0) then
        v_msg := t_message('Este produto esta presente em um kit na notafiscal e não pode ser cortado.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_margemMenor := ((r_trocalote.qtdeseparar / 100) *
                       v_percentualtolerancia - r_trocalote.qtdeseparar) * -1;
    
      v_margemMaior := (r_trocalote.qtdeseparar / 100) *
                       v_percentualtolerancia + r_trocalote.qtdeseparar;
    
      if (v_qtdeTotalTroca < v_margemMenor or
         v_qtdeTotalTroca > v_margemMaior) then
        v_msg := t_message('A qtde total separada dos lotes industrias está fora da margem de tolerância de {0} % definida no depositante id: {1}');
        v_msg.addParam(v_percentualtolerancia);
        v_msg.addParam(r_trocalote.iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select d.fracionarlote
        into v_fracionarLote
        from notafiscal nf, depositante d
       where nf.idnotafiscal = r_trocalote.idnotafiscal
         and nf.iddepositante = d.identidade;
    
    end validarDadosParaTroca;
  
    procedure cancelarMovLoteIndustriaAtual is
    begin
      v_qtdeRetiradaMov := 0;
      -- Cancelar movimentações do lote industria pré-estabelicido em separação antes da troca
      for c_movloteind in (select m.id,
                                  round(m.qtdemovimentada - m.qtdeconferida,
                                         6) qtderestante, m.idlote,
                                  lo.idarmazem, lo.idlocal, m.idlocaldestino
                             from v_tarefas_onda m, local lo, local ld,
                                  lote lt, embalagem e
                            where m.idonda = r_trocalote.idonda
                              and m.status in (0, 1)
                              and m.qtdeconferida <> m.qtdemovimentada
                              and m.idlocalorigem =
                                  r_trocalote.idlocalorigem
                              and lo.id = m.idlocalorigem
                              and ld.id = m.idlocaldestino
                              and ld.idregiao = p_idRegiaoDestino
                              and decode(ld.buffer, 'N', 0, 1) =
                                  p_bufferDestino
                              and lt.idlote = m.idlote
                              and e.idproduto = lt.idproduto
                              and e.barra = lt.barra
                              and e.idproduto = r_trocalote.idproduto
                              and nvl(lt.descr, m.idlote) =
                                  r_trocalote.loteindustria
                              and m.codbarratarefa =
                                  nvl(p_tarefa, m.codbarratarefa)
                              and m.idnotafiscal = r_trocalote.idnotafiscal
                              and m.identificador = p_identificador)
      loop
        pk_estoque.retirar_pendencia(c_movloteind.idarmazem,
                                     c_movloteind.idlocal,
                                     c_movloteind.idlote,
                                     c_movloteind.qtderestante, p_idusuario,
                                     'RETIRADA PENDENCIA PARA MOVIMENTACAO LOTE INDUSTRIA POR MOTIVO DE TROCA DE LOTE SEPARAÇÃO. LOTE INDUSTRIA:' ||
                                      r_trocalote.loteindustria ||
                                      ', ONDA ID: ' || r_trocalote.idonda ||
                                      ', MOVIMENTAÇÃO ID: ' ||
                                      c_movloteind.id);
      
        v_qtdeRetiradaMov := v_qtdeRetiradaMov + c_movloteind.qtderestante;
      
        update movimentacao m
           set m.status = 3
         where m.id = c_movloteind.id;
      
        insert into movafetadatrocalotesep
          (id, idtrocalote, idmovimentacao, acao)
        values
          (seq_movafetadatrocalotesep.nextval, r_trocalote.id,
           c_movloteind.id, ACAO_MOV_CANCELADA);
      
        v_idLocalDestino := c_movloteind.idlocaldestino;
      
        exit when v_fracionarLote = 0;
      end loop;
    end cancelarMovLoteIndustriaAtual;
  
    -- Refactored procedure criarMovNovoLoteIndustria
    procedure criarMovNovoLoteIndustria is
      r_movNovaSeparada     movimentacao%rowtype;
      v_idgrupomovimentacao number;
    begin
      -- Criar novas movimentações para os novos lotes separados para troca
      for c_lotetroca in (select tld.idlote, tl.idarmazem, lo.idlocal,
                                 sum(tld.qtdedisponivel) qtdedisponivel
                            from trocarlotesepondadet tld,
                                 trocarloteseponda tl, local lo
                           where tl.id = r_trocalote.id
                             and lo.id = tl.idlocalorigem
                             and tl.status = TROCA_ANDAMENTO
                             and tl.id = tld.idtrocalote
                             and tld.status = DETALHE_TROCA_ATIVO
                           group by tld.idlote, tl.idarmazem, lo.idlocal)
      loop
        pk_estoque.incluir_pendencia(c_lotetroca.idarmazem,
                                     c_lotetroca.idlocal, c_lotetroca.idlote,
                                     c_lotetroca.qtdedisponivel, p_idusuario,
                                     'ADICIONADO PENDENCIA PARA NOVA MOVIMENTACAO CRIADA POR MOTIVO DE TROCA DE LOTE INDÚSTRIA NA SEPARAÇÃO. IDTROCALOTE:' ||
                                      r_trocalote.id || ', ONDA ID: ' ||
                                      r_trocalote.idonda);
      
        r_movNovaSeparada.id              := null;
        r_movNovaSeparada.idlocalorigem   := r_trocalote.idlocalorigem;
        r_movNovaSeparada.idlocaldestino  := v_idLocalDestino;
        r_movNovaSeparada.quantidade      := c_lotetroca.qtdedisponivel;
        r_movNovaSeparada.etapa           := 1;
        r_movNovaSeparada.idlote          := c_lotetroca.idlote;
        r_movNovaSeparada.status          := 1;
        r_movNovaSeparada.idonda          := r_trocalote.idonda;
        r_movNovaSeparada.qtdemovimentada := c_lotetroca.qtdedisponivel;
        r_movNovaSeparada.idnotafiscal    := r_trocalote.idnotafiscal;
        r_movNovaSeparada.datainicio      := sysdate;
        r_movNovaSeparada.idusuario       := p_idusuario;
        r_movNovaSeparada.qtdeconferida   := c_lotetroca.qtdedisponivel;
        r_movNovaSeparada.identificador   := p_identificador;
        r_movNovaSeparada.tiposeparacao   := 2;
        r_movNovaSeparada.ordem           := 1;
      
        v_idgrupomovimentacao := pk_onda.inserirMovimentacao(r_movNovaSeparada,
                                                             v_idgrupomovimentacao);
      
        insert into movafetadatrocalotesep
          (id, idtrocalote, idmovimentacao, acao)
        values
          (seq_movafetadatrocalotesep.nextval, r_trocalote.id,
           v_idgrupomovimentacao, ACAO_MOV_CRIADA);
      end loop;
    end criarMovNovoLoteIndustria;
  
    procedure alterarQtdeItemPedido is
      v_novaqtde number;
    begin
      select sum(nd.qtdeatendida * e.fatorconversao)
        into v_novaqtde
        from nfdet nd, embalagem e
       where nd.nf = r_trocalote.idnotafiscal
         and nd.idproduto = r_trocalote.idproduto
         and e.idproduto = nd.idproduto
         and e.barra = nd.barra;
    
      v_novaqtde := v_novaqtde + v_qtdeTotalTroca - v_qtdeRetiradaMov;
    
      trocarQtdeAtendidaNF(r_trocalote.idnotafiscal, r_trocalote.idproduto,
                           v_novaqtde);
    
    end alterarQtdeItemPedido;
  
    -- verifica os enderecos dos lotes que serão trocados. Caso endereço diferente da separacao atual é feito o remanejamento.
    procedure gerarRemanejamento is
      v_idlocaldestinorem number;
      v_idarmazem         number;
      v_idonda            number;
      v_mensagem          varchar2(1000);
      v_idremanejamento   number;
    
      r_loteunico pk_lote.t_loteunico;
    begin
      -- Carrega idlocaldestino e idarmazem para o remanejamento
      select l.id, t.idarmazem, t.idonda
        into v_idlocaldestinorem, v_idarmazem, v_idonda
        from trocarloteseponda t, local l
       where t.idlocalorigem = l.id
         and t.status = TROCA_ANDAMENTO
         and t.id = p_idTroca;
    
      -- Carrega informações dos lotes escolhidos para troca
      for c_lotetroca in (select distinct td.idlote, ll.idlocal, lt.idproduto,
                                          lt.estado, lt.descr loteindustria,
                                          lt.dtvenc dtvencimento,
                                          pd.loteuniconoendereco,
                                          lt.iddepositante,
                                          ll.estoque - ll.pendencia +
                                           ll.adicionar disponivel
                            from trocarlotesepondadet td, lotelocal ll,
                                 lote lt, produtodepositante pd
                           where td.idlote = ll.idlote
                             and ll.idlote = lt.idlote
                             and pd.identidade = lt.iddepositante
                             and pd.idproduto = lt.idproduto
                             and lt.idarmazem = v_idarmazem
                             and td.status = DETALHE_TROCA_ATIVO
                             and td.idtrocalote = p_idTroca
                             and ll.idendereco <> v_idlocaldestinorem
                             and td.idlocalorigem <> v_idlocaldestinorem
                             and (ll.estoque - ll.pendencia + ll.adicionar) > 0
                           order by td.idlote)
      loop
      
        r_loteunico.idProduto           := c_lotetroca.idproduto;
        r_loteunico.estado              := c_lotetroca.estado;
        r_loteunico.loteindustria       := c_lotetroca.loteindustria;
        r_loteunico.dtvencimento        := c_lotetroca.dtvencimento;
        r_loteunico.loteuniconoendereco := c_lotetroca.loteuniconoendereco;
        r_loteunico.iddepositante       := c_lotetroca.iddepositante;
      
        -- Validação de compatibilidade para o endereço que o lote será remanejado.
        if not pk_lote.isLocalPodeReceberLoteUnico(r_loteunico, v_idarmazem,
                                                   v_idlocaldestinorem,
                                                   v_mensagem) then
          if v_mensagem is not null then
            v_msg := t_message('ERRO NO LOTE INDÚSTRIA: {0}. LOTE NÃO PERTENCE AO ENDEREÇO ATUAL DE SEPARAÇÃO. ERRO NA VALIDAÇÃO DO REMANEJAMENTO: {1}');
            v_msg.addParam(r_loteunico.loteindustria);
            v_msg.addParam(v_mensagem);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      
        -- Cria o remanejamento
        select seq_remanejamento.nextval
          into v_idremanejamento
          from dual;
      
        insert into remanejamento
          (idremanejamento, idarmazemorigem, idlocalorigem,
           idarmazemdestino, idlocaldestino, datahora, idusuariotela, status,
           cadmanual, idromaneio, descrpalet, planejado)
        values
          (v_idremanejamento, v_idarmazem, c_lotetroca.idlocal, v_idarmazem,
           (select idlocal
               from local
              where id = v_idlocaldestinorem), sysdate, p_idusuario, 'A',
           'N', v_idonda,
           'TROCA LOTE SEPARACAO ONDA: IDONDA: ' || v_idonda ||
            ' IDTROCA: ' || p_idTroca || ' LOTE INDUSTRIA: ' ||
            c_lotetroca.loteindustria, 'N');
      
        -- Vincula o lote no remanejamento com todas qtde disponivel, pois se o parametro 'Permitir Alterar Qtde na Separação' estiver ativo o parametro 'Fracionar o Lote' é desabilitado'
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde)
        values
          (v_idremanejamento, c_lotetroca.idlote, c_lotetroca.disponivel,
           'N', 'S');
      
        -- Finaliza o planejamento
        update remanejamento
           set planejado = 'S'
         where idremanejamento = v_idremanejamento;
      
        -- Executa o remanejamento
        pk_Remanejamento.finalizarRemanejamento(v_idremanejamento,
                                                p_idusuario);
      end loop;
    
    end gerarRemanejamento;
  
  begin
    getTrocaLoteIndustria;
    validarDadosParaTroca;
  
    v_estoqueJaUsado := false;
    --Verifica se ainda tem qtde suficiente em estoque para realizar a troca
    for c_estusado in (select tld.id iddetalhetroca
                         from trocarlotesepondadet tld, trocarloteseponda tl,
                              local lo, lotelocal ll
                        where tl.id = r_trocalote.id
                          and lo.id = tld.idlocalorigem
                          and tl.status = TROCA_ANDAMENTO
                          and tl.id = tld.idtrocalote
                          and tld.status = DETALHE_TROCA_ATIVO
                          and ll.idarmazem = lo.idarmazem
                          and ll.idlocal = lo.idlocal
                          and ll.idlote = tld.idlote
                          and (ll.estoque - ll.pendencia + ll.adicionar) <
                              tld.qtdedisponivel
                          for update)
    loop
      v_estoqueJaUsado := true;
    
      update trocarlotesepondadet
         set status = DETALHE_TROCA_ALERTA
       where id = c_estusado.iddetalhetroca;
    end loop;
  
    if (v_estoqueJaUsado) then
      return TROCALOTE_ERRO;
    end if;
  
    -- Gera remanejamento para troca de endereco diferente
    gerarRemanejamento;
  
    select r.statusonda, r.idconfiguracaoonda
      into v_statusonda, v_idconfiguracaoonda
      from romaneiopai r
     where r.idromaneio = r_trocalote.idonda;
  
    -- caso a onda esteja apenas liberada, ela será marcada como em execução
    if (v_statusonda = 2) then
      update romaneiopai r
         set r.statusonda = 4
       where r.idromaneio = r_trocalote.idonda;
    end if;
  
    cancelarMovLoteIndustriaAtual;
    criarMovNovoLoteIndustria;
    alterarQtdeItemPedido;
  
    pk_onda.getTotalMovTotalNF(r_trocalote.idonda, v_totalmov, v_totalitem);
  
    select d.percentualtolerancia
      into v_tolerancia
      from depositante d
     where d.identidade = r_trocalote.iddepositante;
  
    if v_tolerancia is not null
       and v_tolerancia > 0 then
      if not (v_totalmov between (v_totalitem * (1 - (v_tolerancia / 100))) and
          (v_totalitem * (1 + (v_tolerancia / 100)))) then
        v_msg := t_message('A quantidade total em notas fiscais não confere com a quantidade total em movimentações da onda');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      if (v_totalmov <> v_totalitem) then
        v_msg := t_message('A quantidade total em notas fiscais não confere com a quantidade total em movimentações da onda');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    update trocarloteseponda
       set status          = TROCA_REALIZADA,
           datafinalizacao = sysdate
     where id = r_trocalote.id;
  
    pk_romaneio.preencherInfSeparacao(r_trocalote.idonda,
                                      v_idconfiguracaoonda);
  
    pk_utilities.GeraLog(p_idusuario,
                         'Troca Lote Separação id: ' || r_trocalote.id ||
                          ' Realizada.', r_trocalote.idonda, 'TL');
  
    return TROCALOTE_SUCESSO;
  end;

  function buscarLoteIndustriaParaTroca
  (
    p_idOnda          in number,
    p_idNotaFiscal    in number,
    p_idProduto       in number,
    p_idDepositante   in number,
    p_idArmazem       in number,
    p_idLocalOrigem   in number,
    p_loteIndustria   in varchar2,
    p_barraSeparacao  in varchar2,
    p_qtdeTroca       in number,
    p_idRegiaoDestino in number,
    p_bufferDestino   in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_tarefa          in varchar2 := null,
    p_origemPacking   in number := 0
  ) return number is
  
    TROCALOTE_ERRO    constant number := 0;
    TROCALOTE_SUCESSO constant number := 1;
  
    TIPO_TROCA_AUTOMATICA constant number := 1;
  
    RAISE_ERRO_TROCA_LOTE exception;
  
    v_resultadoTroca number;
    v_qtdeTrocaUnit  number;
  
    v_configuracaoonda configuracaoonda%rowtype;
    v_tipolocal        number;
    v_idTroca          number;
    v_totalmov         number;
    v_totalitem        number;
  
    v_msg t_message;
  
    v_teveCorte        number;
    v_fatorconversao   embalagem.fatorconversao%type;
    v_fluxoUsaPicking  boolean;
  
    procedure validarTrocaAutomatica is
      TIPO_ONDA_CARGA               constant number := 1;
      POR_LOTE_QUANDO_CONTROLA_LOTE constant number := 3;
    
      v_permitetrocaloteindseparacao number;
      v_permitetrocaloteindconfpack  number;
      v_coletaloteindustria          produtodepositante.coletaloteindust%type;
    begin
      select d.permitetrocaloteindseparacao,
             d.permitetrocaloteindconfpacking
        into v_permitetrocaloteindseparacao, v_permitetrocaloteindconfpack
        from depositante d
       where d.identidade = p_idDepositante;
    
      if (v_permitetrocaloteindseparacao = 0) then
        v_msg := t_message('O Depositante Id: {0} não permite troca lote indústria durante a separação.');
        v_msg.addParam(p_idDepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select lo.tipo
        into v_tipolocal
        from local lo
       where lo.id = p_idLocalOrigem;
    
      if (v_tipolocal = 8) then
        if (v_permitetrocaloteindconfpack = 0) then
          v_msg := t_message('O Depositante Id: {0} n?o permite troca lote ind?stria durante a confer?ncia de packing.');
          v_msg.addParam(p_idDepositante);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      else
        if (v_permitetrocaloteindseparacao = 0) then
          v_msg := t_message('O Depositante Id: {0} n?o permite troca lote ind?stria durante a separa??o.');
          v_msg.addParam(p_idDepositante);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      if (v_configuracaoonda.tipoonda = TIPO_ONDA_CARGA) then
        v_msg := t_message('Não é permitido realizar a troca quando o tipo de expedição da configuração da onda é POR CARGA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (pk_onda.validarFluxo('Pulmão > Picking > Colmeia%', p_idOnda)) then
        v_msg := t_message('Não é permitido realizar a troca quando a configuração da onda utiliza o fluxo de colmeia.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_configuracaoonda.tipoprocessoseparacao <>
         POR_LOTE_QUANDO_CONTROLA_LOTE) then
        v_msg := t_message('O processo de separação da configuração da onda não é Por Lote - Quando Controla Lote Indústria.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select pd.coletaloteindust
        into v_coletaloteindustria
        from produtodepositante pd
       where pd.idproduto = p_idProduto
         and pd.identidade = p_idDepositante;
    
      if (v_coletaloteindustria = 'N') then
        v_msg := t_message('O Produto Id {0} para o Depositante Id: {1} não está configurado para coletar lote indústria.');
        v_msg.addParam(p_idProduto);
        v_msg.addParam(p_idDepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarTrocaAutomatica;
  
    procedure carregarEmbalagem is
    begin
      select e.fatorconversao
        into v_fatorconversao
        from embalagem e
       where e.barra = p_barraSeparacao;
    
      v_qtdeTrocaUnit := p_qtdeTroca * v_fatorconversao;
    end carregarEmbalagem;
  
    procedure addTrocaLoteIndustriaAut is
    begin
      select seq_trocarloteseponda.nextval
        into v_idTroca
        from dual;
    
      insert into trocarloteseponda
        (id, idonda, idnotafiscal, idproduto, iddepositante, idlocalorigem,
         idarmazem, idusuario, dataseparacao, loteindustria, qtdeseparar,
         status, tipo)
      values
        (v_idTroca, p_idOnda, p_idNotaFiscal, p_idProduto, p_idDepositante,
         p_idLocalOrigem, p_idArmazem, p_idusuario, sysdate, p_loteIndustria,
         v_qtdeTrocaUnit, TROCA_ANDAMENTO, TIPO_TROCA_AUTOMATICA);
    end addTrocaLoteIndustriaAut;
  
    procedure cortarMovLoteIndustriaAtual is
      v_qtdeEncontrada    number;
      v_qtdeSeparacao     number;
      v_qtdeMaxEncontrada number;
    begin
      select (sum(m.quantidade - m.qtdeemvolume) - v_qtdeTrocaUnit) qtdeencontrada,
             (sum(m.quantidade - m.qtdeemvolume)) qtdeseparacao
        into v_qtdeEncontrada, v_qtdeSeparacao
        from v_tarefas_onda m, local lo, local ld, lote lt, embalagem e
       where m.idonda = p_idOnda
         and m.status in (0, 1, 2)
         and m.quantidade <> m.qtdeemvolume
         and m.idlocalorigem =
             decode(p_origemPacking, 1, m.idlocalorigem, p_idLocalOrigem)
         and m.idlocaldestino =
             decode(p_origemPacking, 1, p_idLocalOrigem, m.idlocaldestino)
         and lo.id = m.idlocalorigem
         and ld.id = m.idlocaldestino
         and ld.idregiao = p_idRegiaoDestino
         and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
         and lt.idlote = m.idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and e.idproduto = p_idProduto
         and nvl(lt.descr, m.idlote) = p_loteIndustria
         and m.codbarratarefa = nvl(p_tarefa, m.codbarratarefa)
         and m.idnotafiscal = p_idNotaFiscal;
    
      pk_cortefisico.registrarCorteFisicoTroca(p_idusuario,
                                               p_barraSeparacao,
                                               v_qtdeEncontrada /
                                                v_fatorconversao, null,
                                               p_idOnda, p_idProduto,
                                               p_idLocalOrigem,
                                               p_idRegiaoDestino,
                                               p_bufferDestino,
                                               p_identificador,
                                               p_idNotaFiscal,
                                               v_qtdeSeparacao,
                                               v_qtdeMaxEncontrada,
                                               p_loteIndustria, v_idTroca,
                                               p_tarefa);
    
      if (v_qtdeMaxEncontrada > 0) then
        v_msg := t_message('A quantidade ({0} UN) que permaneceu em separação não pode ser utilizada, pois não é múltipla da quantidade presente no pedido.');
        v_msg.addParam(v_qtdeEncontrada);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      insert into movafetadatrocalotesep
        (id, idtrocalote, idmovimentacao, acao)
        select seq_movafetadatrocalotesep.nextval, v_idTroca,
               rec.idmovimentacaoafetada, ACAO_MOV_CANCELADA
          from resestoquecortefisiconf rec, cortefisiconf cnf,
               cortefisico cf
         where cf.tipocorte = 1
           and cf.idonda = p_idOnda
           and cf.idproduto = p_idProduto
           and cf.idenderecofalta = p_idLocalOrigem
           and cf.identificador = p_identificador
           and cf.identificadorpacking = p_idNotaFiscal
           and cf.codbarratarefa = nvl(p_tarefa, cf.codbarratarefa)
           and cf.status = 0
           and cf.idtrocalote = v_idTroca
           and cf.id = cnf.idcortefisico
           and cnf.id = rec.idcortefisiconf;
    
    end cortarMovLoteIndustriaAtual;
  
    procedure inserirGttProdutoOnda is
    begin
      insert into gtt_produtoonda
        (id, idonda, idarmazem, idnotafiscal, tiponf, iddepositante,
         idproduto, estado, idtransportadora, quantidade, quantidadeAtendida,
         idnfdet, altura, largura, comprimento, peso, permiteFracionarLote,
         percentualtolerancia, permitealterarqtdsep, usashelflife,
         controleshelflife, valorshelflife, coletadtavenclote, prazovalidade,
         naoatendepedproddtacritica, prazocritico, idtipopedido,
         situacaolote, pickingdinamico, loteuniconoendereco,
         utzRegraPersonalizadaExpedProd, regraPersonalizadaExpedProd,
         prioridadeSelecaoEstoque, tipopicking, separarlotescompletos,
         codLinhaPTL, utzIntDepErpSenior, codsetorestoque)
        select seq_gtt_produtoonda.nextval, p_idOnda, p.idarmazem,
               p.idnotafiscal, p.tiponf, p.iddepositante, p.idproduto,
               p.estado, p.transportadoranotafiscal, p.qtde, 0, p.idnfdet,
               p.altura, p.largura, p.comprimento, p.peso,
               p.permitefracionarlote, p.percentualtolerancia,
               p.permitiralterarqtdeseparacao, p.usashelflife,
               decode(nvl(pdest.controleshelflife, 0), 0,
                       p.controleshelflife, pdest.controleshelflife) controleshelflife,
               decode(nvl(pdest.controleshelflife, 0), 0,
                       nvl(p.valorshelflife, 0), nvl(pdest.valorshelflife, 0)) valorshelflife,
               p.coletadtavenclote, p.prazovalidade,
               p.naoatendepedproddtacritica, p.prazocritico,
               nvl(p.idtipopedido, 0) idtipopedido,
               nvl(p.situacaolote, 0) situacaolote, p.pickingdinamico,
               p.loteuniconoendereco, p.utzRegraPersonalizadaExpedProd,
               p.regraPersonalizadaExpedProd, p.prioridadeSelecaoEstoque,
               p.tipopicking, p.separarlotescompletos, p.codLinhaPTL,
               p.utzIntDepErpSenior, p.codsetorestoque
          from (select kk.idnotafiscal, kk.tiponf, kk.iddepositante,
                        kk.idproduto, kk.estado, kk.transportadoranotafiscal,
                        sum(kk.qtde) qtde, kk.idarmazem,
                        (case
                           when ((v_configuracaoonda.faturamentoporpalete = 1 and
                                v_configuracaoonda.faturamentoporpalete = 1) or
                                v_configuracaoonda.exclusivopicktolight = 1) then
                            kk.idnfdet
                           else
                            null
                         end) idnfdet, nvl(sum(kk.altura), 0) altura,
                        sum(kk.largura) largura,
                        nvl(sum(kk.comprimento), 0) comprimento,
                        nvl(sum(kk.peso), 0) peso, kk.permiteFracionarLote,
                        kk.percentualtolerancia,
                        kk.permitiralterarqtdeseparacao, kk.usashelflife,
                        kk.controleshelflife, kk.valorshelflife,
                        kk.coletadtavenclote, kk.prazovalidade,
                        kk.naoatendepedproddtacritica, kk.prazocritico,
                        kk.idtipopedido, kk.situacaolote, kk.pickingdinamico,
                        kk.loteuniconoendereco,
                        kk.utzRegraPersonalizadaExpedProd,
                        kk.regraPersonalizadaExpedProd,
                        kk.prioridadeSelecaoEstoque, kk.tipopicking,
                        kk.destinatario, kk.separarlotescompletos,
                        kk.codLinhaPTL, kk.utzIntDepErpSenior,
                        kk.codsetorestoque
                   from (select nf.idnotafiscal, nf.tiponf, nf.iddepositante,
                                 nvl(k.idproduto, nd.idproduto) idproduto,
                                 nvl(cp.estadomat, nf.estado) estado,
                                 nf.transportadoranotafiscal,
                                 nvl(k.qtde * v_qtdeTrocaUnit, (v_qtdeTrocaUnit)) qtde,
                                 nf.idarmazem, nd.idnfdet,
                                 nvl(nvl(k.altura, e.altura), 0) altura,
                                 nvl(nvl(k.largura, e.largura), 0) largura,
                                 nvl(nvl(k.comprimento, e.comprimento), 0) comprimento,
                                 nvl(nvl(k.pesobruto, e.pesobruto), 0) peso,
                                 nvl(d.fracionarlote, 1) permiteFracionarLote,
                                 decode(nf.tiponf, 'P',
                                         nvl(d.percentualtolerancia, 0), 0) percentualtolerancia,
                                 nvl(d.permitiralterarqtdeseparacao, 0) permitiralterarqtdeseparacao,
                                 d.usashelflife, dest.controleshelflife,
                                 dest.valorshelflife,
                                 nvl((select pd.coletadtavenclote
                                        from produtodepositante pd
                                       where pd.idproduto =
                                             nvl(k.idproduto, nd.idproduto)
                                         and pd.identidade = nf.iddepositante), 0) coletadtavenclote,
                                 pr.prazovalidade, d.naoatendepedproddtacritica,
                                 pr.prazocritico, cp.idtipopedido,
                                 cp.situacaolote, pd.pickingdinamico,
                                 pd.loteuniconoendereco,
                                 d.utzRegraPersonalizadaExpedProd,
                                 pd.regraPersonalizadaExpedProd,
                                 d.prioridadeselecaoestoque, pd.tipopicking,
                                 nf.destinatario, d.separarlotescompletos,
                                 decode(nf.picktolight, 1, nd.tipoptl, null) codLinhaPTL,
                                 decode(d.integrarerpsenior, 0, 0,
                                         d.integrardepositoerpsenior) utzIntDepErpSenior,
                                 nd.codsetor codsetorestoque
                            from nfromaneio nfr, notafiscal nf, nfdet nd,
                                 embalagem e, depositante d,
                                 (select k.idprodutokit, k.idproduto, ke.barra,
                                          (k.qtde * ke.fatorconversao) qtde,
                                          ke.altura, ke.largura, ke.comprimento,
                                          ke.pesobruto
                                     from kitproduto k, embalagem ke, produto p
                                    where k.idproduto = ke.idproduto
                                      and k.barra = ke.barra
                                      and p.idproduto = k.idprodutokit
                                      and p.kitexpexplodida = 'S') k, produto pr,
                                 entidade dest, classificacaotipopedido cp,
                                 produtodepositante pd
                           where nfr.idromaneio = p_idOnda
                             and nf.idnotafiscal = nfr.idnotafiscal
                             and nd.nf = nf.idnotafiscal
                             and e.idproduto = nd.idproduto
                             and e.barra = nd.barra
                             and d.identidade = nf.iddepositante
                             and k.idprodutokit(+) = nd.idproduto
                             and dest.identidade = nf.destinatario
                             and pr.idproduto = nd.idproduto
                             and cp.idtipopedido(+) = nf.idtipopedido
                             and pd.identidade = nf.iddepositante
                             and pd.idproduto = nd.idproduto
                             and pd.identidade = p_idDepositante
                             and pd.idproduto = p_idProduto) kk
                  group by kk.idnotafiscal, kk.tiponf, kk.iddepositante,
                           kk.idproduto, kk.estado,
                           kk.transportadoranotafiscal, kk.idarmazem,
                           (case
                              when ((v_configuracaoonda.faturamentoporpalete = 1 and
                                   v_configuracaoonda.faturamentoporpalete = 1) or
                                   v_configuracaoonda.exclusivopicktolight = 1) then
                               kk.idnfdet
                              else
                               null
                            end), kk.permiteFracionarLote,
                           kk.percentualtolerancia,
                           kk.permitiralterarqtdeseparacao, kk.usashelflife,
                           kk.controleshelflife, kk.valorshelflife,
                           kk.coletadtavenclote, kk.prazovalidade,
                           kk.naoatendepedproddtacritica, kk.prazocritico,
                           kk.idtipopedido, kk.situacaolote,
                           kk.pickingdinamico, kk.loteuniconoendereco,
                           kk.utzRegraPersonalizadaExpedProd,
                           kk.regraPersonalizadaExpedProd,
                           kk.prioridadeSelecaoEstoque, kk.tipopicking,
                           kk.destinatario, kk.separarlotescompletos,
                           kk.codLinhaPTL, kk.utzIntDepErpSenior,
                           kk.codsetorestoque) p, produtodestinatario pdest
         where pdest.idproduto(+) = p.idproduto
           and pdest.identidade(+) = p.destinatario;
    end inserirGttProdutoOnda;
  
    procedure encontrarNovosLotes is
      ESTOQUE_PULMAO                constant number := 0;
      ESTOQUE_PICKING               constant number := 1;
      ESTOQUE_PULMAO_PICKING_JUNTOS constant number := 8;
      C_CONFONDA_PICKTOLIGHT_NAO    constant number := 0;
      C_CONFONDA_FEFO_FIFO_JUNTOS   constant number := 1;
      v_usaEstoquePulmao  boolean;
      v_usaEstoquePicking boolean;
    begin
      insert into gtt_propriedade
        (propriedade, valor1)
      values
        ('TROCA_LOTE', v_idTroca);
    
      v_usaEstoquePulmao  := pk_onda.validarFluxo('%pulm_o > packing%',
                                                  p_idonda);
      v_usaEstoquePicking := pk_onda.validarFluxo('%picking > packing%',
                                                  p_idonda);
    
      v_fluxoUsaPicking := pk_onda.validarFluxo('%picking%', p_idonda);
      if (v_configuracaoonda.aplicarfefofifo = C_CONFONDA_FEFO_FIFO_JUNTOS) then
        pk_onda.usarEstoqueOnda(p_idusuario, p_idOnda, v_configuracaoonda,
                                ESTOQUE_PULMAO_PICKING_JUNTOS, 0, v_fluxoUsaPicking);
      
      else
        if (v_usaEstoquePulmao) then
          pk_onda.usarEstoqueOnda(p_idusuario, p_idOnda, v_configuracaoonda,
                                  ESTOQUE_PULMAO, 0, v_fluxoUsaPicking);
        end if;
      
        if (v_usaEstoquePicking) then
          pk_onda.usarEstoqueOnda(p_idusuario, p_idonda, v_configuracaoonda,
                                  ESTOQUE_PICKING, 0, v_fluxoUsaPicking);
        end if;
      end if;
    
      if (v_configuracaoonda.exclusivopicktolight =
         C_CONFONDA_PICKTOLIGHT_NAO and
         (not pk_onda.isOndaCheckoutExpress(p_idOnda))) then
        pk_onda.usarLotesRegioesDiferentes(p_idOnda);
      end if;
    end encontrarNovosLotes;
  
    procedure definirTarefaSeparacao is
      GRUPO_PROD_FRACIONADO constant number := -1;
      GRUPO_SEM_FAT_PALETE  constant number := 0;
    
      v_idRegiaoOrigem number;
    begin
    
      if (v_tipolocal <> 8) then
        -- Quando os lotes encontrados pertencerem a mesma região de armzenagem
        -- do lote indústria trocado será adicionado a mesma tarefa de separação do mesmo
        select lo.idregiao
          into v_idRegiaoOrigem
          from local lo
         where lo.id = p_idLocalOrigem;
      
        update gtt_loteutilizadoonda g
           set g.idpalete = p_identificador
         where g.idonda = p_idOnda
           and g.idpedidopai = p_idNotaFiscal
           and g.idproduto = p_idProduto
           and g.idregiao = v_idRegiaoOrigem;
      else
        v_idRegiaoOrigem := 0;
        if (p_tarefa is not null) then
          update gtt_loteutilizadoonda g
             set g.idpalete = p_identificador
           where g.idonda = p_idOnda
             and g.idpedidopai = p_idNotaFiscal
             and g.idproduto = p_idProduto;
        end if;
      end if;
    
      if (v_configuracaoonda.utilizapaletepadrao = 1) then
        -- Tentar adicionar os lotes encontrados em uma outra tarefa que está em outra região de armazenagem
        for c_palete in (select g.idproduto, g.idregiao,
                                sum(g.pesoutilizado) pesoutilizado,
                                sum(g.cubagemutilizada) cubagemutilizada
                           from gtt_loteutilizadoonda g
                          where g.idonda = p_idOnda
                            and g.idpedidopai = p_idNotaFiscal
                            and g.idproduto = p_idProduto
                            and g.idpalete is null
                            and g.idregiao <> v_idRegiaoOrigem
                            and g.gruporegiaomultipla = 0
                            and g.grupo > 0
                          group by g.idproduto, g.idregiao
                         union all
                         select g.idproduto, g.idregiao,
                                sum(g.pesoutilizado) pesoutilizado,
                                sum(g.cubagemutilizada) cubagemutilizada
                           from gtt_loteutilizadoonda g
                          where g.idonda = p_idOnda
                            and g.idpedidopai = p_idNotaFiscal
                            and g.idproduto = p_idProduto
                            and g.idpalete is null
                            and g.idregiao <> v_idRegiaoOrigem
                            and g.gruporegiaomultipla = 0
                            and g.grupo in
                                (GRUPO_SEM_FAT_PALETE, GRUPO_PROD_FRACIONADO)
                          group by g.idproduto, g.idregiao)
        loop
          for c_tarefa in (select m.identificador,
                                  sum(m.qtdemovimentada / e.fatorconversao *
                                       e.pesobruto) pesotarefa,
                                  sum(m.qtdemovimentada / e.fatorconversao *
                                       e.altura * e.largura * e.comprimento) cubagemtarefa
                             from v_tarefas_onda m, local lo, lote lt,
                                  embalagem e
                            where m.idonda = p_idOnda
                              and m.idnotafiscal = p_idNotaFiscal
                              and e.idproduto = lt.idproduto
                              and e.barra = lt.barra
                              and lt.idlote = m.idlote
                              and lo.id = m.idlocalorigem
                              and lo.idregiao = c_palete.idregiao
                              and m.status = 0
                            group by m.identificador)
          loop
            if (c_tarefa.pesotarefa >= c_palete.pesoutilizado and
               c_tarefa.cubagemtarefa >= c_palete.cubagemutilizada) then
              update gtt_loteutilizadoonda g
                 set g.idpalete = c_tarefa.identificador
               where g.idonda = p_idOnda
                 and g.idpedidopai = p_idNotaFiscal
                 and g.idproduto = c_palete.idproduto
                 and g.idregiao = c_palete.idregiao;
            end if;
          end loop;
        end loop;
      
        -- Será definida uma nova tarefa para os lotes que não entraram na tarefa da mesma região de armazenagem
        -- e também não foi possível adicionar em uma tarefa não iniciada em outra região de armazenagem
        pk_onda.definirPalete(v_configuracaoonda, p_idOnda);
      end if;
    end definirTarefaSeparacao;
  
    procedure criarMovNovosLotes is
      r_movimentacao   movimentacao%rowtype;
      v_localPacking   number;
      v_idmovimentacao number;
    begin
      pk_triggers_control.disableTrigger('T_INSEREMOVIMENTACAO');
      select distinct m.idlocaldestino
        into v_localPacking
        from v_tarefas_onda m, local lo, local ld, lote lt, embalagem e
       where m.idonda = p_idOnda
         and m.status = 3
         and m.quantidade <> m.qtdeemvolume
         and m.idlocalorigem =
             decode(p_origemPacking, 1, m.idlocalorigem, p_idLocalOrigem)
         and m.idlocaldestino =
             decode(p_origemPacking, 1, p_idLocalOrigem, m.idlocaldestino)
         and lo.id = m.idlocalorigem
         and ld.id = m.idlocaldestino
         and ld.idregiao = p_idRegiaoDestino
         and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
         and lt.idlote = m.idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and e.idproduto = p_idProduto
         and nvl(lt.descr, m.idlote) = p_loteIndustria
         and m.codbarratarefa = nvl(p_tarefa, m.codbarratarefa)
         and m.idnotafiscal = p_idNotaFiscal
      --and m.identificador = p_identificador
      ;
    
      for c_lote in (select nvl(g.idsubpedido, g.idpedidopai) idnotafiscal,
                            g.idpalete, g.idarmazem, g.idlocal, g.idlote,
                            lo.id idenderecoorigem, g.id idOrdemEstoque,
                            sum(g.qtde) qtde, g.idnfdet
                       from gtt_loteutilizadoonda g, local lo
                      where lo.id = g.idendereco
                        and g.idonda = p_idOnda
                      group by nvl(g.idsubpedido, g.idpedidopai), g.idpalete,
                               g.idarmazem, g.idlocal, g.idlote, lo.id, g.id,
                               g.idnfdet
                      order by nvl(g.idsubpedido, g.idpedidopai), g.idpalete,
                               g.idarmazem, g.idlocal, g.idlote, lo.id,
                               g.idnfdet)
      loop
        pk_estoque.incluir_pendencia(c_lote.idarmazem, c_lote.idlocal,
                                     c_lote.idlote, c_lote.qtde, p_idusuario,
                                     'ADICIONADO PENDENCIA PARA NOVA MOVIMENTACAO CRIADA POR MOTIVO DE TROCA DE LOTE INDÚSTRIA NA SEPARAÇÃO. IDTROCALOTE:' ||
                                      v_idTroca || ', ONDA ID: ' ||
                                      v_idTroca);
      
        r_movimentacao.ordem := 1;
      
        pk_onda.preencherMovimentacao(r_movimentacao, c_lote.idnotafiscal,
                                      p_idOnda, c_lote.idlote, c_lote.qtde,
                                      c_lote.qtde, c_lote.idpalete, 1,
                                      c_lote.idenderecoorigem,
                                      v_localPacking, 1,
                                      c_lote.idOrdemEstoque, c_lote.idnfdet);
      
        v_idmovimentacao := pk_onda.inserirMovimentacao(r_movimentacao);
      
        insert into movafetadatrocalotesep
          (id, idtrocalote, idmovimentacao, acao)
        values
          (seq_movafetadatrocalotesep.nextval, v_idTroca, v_idmovimentacao,
           ACAO_MOV_CRIADA);
      end loop;
      pk_triggers_control.enableTrigger('T_INSEREMOVIMENTACAO');
    end criarMovNovosLotes;
  
    procedure addDetalheTroca is
    begin
      for c_lote in (select g.idlote, lt.descr, sum(g.qtde) qtde,
                            lo.id idenderecoorigem
                       from gtt_loteutilizadoonda g, local lo, lote lt
                      where lo.id = g.idendereco
                        and g.idonda = p_idonda
                        and lt.idlote = g.idlote
                      group by g.idlote, lt.descr, lo.id
                      order by g.idlote, lt.descr, lo.id)
      loop
        insert into trocarlotesepondadet
          (id, idtrocalote, idlote, loteindustria, qtdedisponivel, data,
           status, idlocalorigem)
        values
          (seq_trocarlotesepondadet.nextval, v_idTroca, c_lote.idlote,
           c_lote.descr, c_lote.qtde, sysdate, DETALHE_TROCA_ATIVO,
           c_lote.idenderecoorigem);
      end loop;
    end addDetalheTroca;
  
  begin
    pk_locks.executeLock(p_idarmazem, 0);
  
    savepoint SV_TROCA_LOTE;
  
    begin
      pk_onda.getConfiguracaoOnda(p_idonda, v_configuracaoonda);
    
      validarTrocaAutomatica;
    
      carregarEmbalagem;
    
      addTrocaLoteIndustriaAut;
    
      cortarMovLoteIndustriaAtual;
    
      delete from gtt_produtoonda;
    
      delete from gtt_loteutilizadoonda;
    
      inserirGttProdutoOnda;
    
      encontrarNovosLotes;
    
      definirTarefaSeparacao;
    
      v_teveCorte := pk_onda.gerarCorte(p_idOnda);
      if (v_teveCorte = 1) then
        raise RAISE_ERRO_TROCA_LOTE;
      end if;
    
      criarMovNovosLotes;
    
      pk_onda.getTotalMovTotalNF(p_idOnda, v_totalmov, v_totalitem);
    
      if (v_totalmov <> v_totalitem) then
        v_msg := t_message('A quantidade total em notas fiscais não confere com a quantidade total em movimentações da onda.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      addDetalheTroca;
    
      update trocarloteseponda
         set status          = TROCA_REALIZADA,
             datafinalizacao = sysdate
       where id = v_idTroca;
    
      v_resultadoTroca := TROCALOTE_SUCESSO;
    exception
      when RAISE_ERRO_TROCA_LOTE then
        rollback to SV_TROCA_LOTE;
        v_resultadoTroca := TROCALOTE_ERRO;
    end;
  
    if (v_resultadoTroca = TROCALOTE_SUCESSO) then
      pk_romaneio.preencherInfSeparacao(p_idOnda,
                                        v_configuracaoonda.idconfiguracaoonda);
      pk_triggers_control.disableTrigger('T_ROMANEIO_SEPARACAO');
    
      update romaneiopai r
         set r.statusonda = 4,
             r.separado   = 'N'
       where r.idromaneio = p_idOnda;
    
      pk_triggers_control.enableTrigger('T_ROMANEIO_SEPARACAO');
    
      if (v_tipolocal = 8) then
      
        update saidapornf snf
           set snf.qtdeseparada      = snf.qtdeseparada - v_qtdeTrocaUnit,
               snf.separacaoiniciada = snf.separacaoiniciada -
                                       v_qtdeTrocaUnit
         where snf.idonda = p_idOnda
           and snf.idnotafiscal = p_idNotaFiscal;
      
      end if;
    
      pk_utilities.GeraLog(p_idusuario,
                           'Troca Lote Separação Automática id: ' ||
                            v_idTroca || ' Realizada.', p_idOnda, 'TL');
    
    end if;
  
    return v_resultadoTroca;
  end;
end;
/

