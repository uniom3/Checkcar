create view VB_COBERTURALOTE as
select lt.idlote h$tableid, p.idproduto, p.codigointerno codproduto,
       p.descr produto, lt.idlote, lt.barra, lt.descr loteindustria,
       (old.qtde - nvl(gcob.qtd, 0) -
        (select sum(nvl(cob.qtdecoberto, 0))
            from coberturalote cob
           where old.idlote = cob.idlote(+)
             and old.idnfdet = cob.idnfdetentrada(+))) qtdependentecobertura,
       lt.loteadicional,
       (select stragg(im.informacao || ': ' || il.valor)
           from informacaolote il, informacaomaterial im
          where il.idlote = lt.idlote
            and im.idinfomaterial = il.idinfomaterial) infoespecifica,
       ol.idlotenf h$idlotenf
  from gtt_selecao g, notafiscal nf, orlote ol, lote lt, produto p,
       origemlotedetalhado old, gtt_coberturalote_qtd_utz gcob
 where nf.idnotafiscal = g.idselecionado
   and ol.idlotenf = nf.idlotenf
   and ol.idlote = lt.idlote
   and p.idproduto = lt.idproduto
   and nf.idnotafiscal = old.idnotafiscal
   and lt.idlote = old.idlote
   and old.idlote = gcob.idlote(+)
   and (old.qtde - nvl(gcob.qtd, 0) -
       nvl((select sum(nvl(cob.qtdecoberto, 0))
              from coberturalote cob
             where old.idlote = cob.idlote(+)
               and old.idnfdet = cob.idnfdetentrada(+)), 0)) > 0
/

