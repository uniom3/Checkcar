create view VI_INT_ENVIO_AM_ILN_ITEM as
select agrupador id, itemtype, itemid, quantity, itemlocation
  from int_envio_am_iln_item
 order by itemid, itemlocation
/

