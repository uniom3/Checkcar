create view VT_PARTILHAALIQUOTAICMS as
select p.ano, p.aliquotauforigem alquforigem,
       p.aliquotaufdestino alqufdestino,
       p.idpartilhaaliquotaicms h$idpartilhaaliquotaicms
  from partilhaaliquotaicms p
/

