create view V_FATURA_RESUMO as
select initcap("Categoria") as "Categoria", initcap("Servico") as "Servico",
       sum("Qtde") as "Qtde", sum("Valor Bruto") as "Valor Bruto",
       sum("Desconto") as "Desconto",
       sum("Valor Liquido") as "Valor Liquido", "Fatura"
  from (select initcap(cs.descricao) as "Categoria",
                initcap(nvl(c.descrservico, s.descricao)) as "Servico",
                sum(fr.qtde) as "Qtde",
                sum(trunc(fr.valor, 2)) as "Valor Bruto",
                sum(fr.desconto) as "Desconto",
                sum(trunc(fr.valorliquido, 2)) as "Valor Liquido",
                fr.idfatura as "Fatura"
           from faturaresumo fr, contratocobranca c, servico s,
                categoriaservico cs, contrato con, fatura fat
          where fr.idcobranca = c.id
            and c.idservico = s.id
            and s.idcategoriaservico = cs.id
            and fr.idfatura = fat.id
            and con.id = fat.idcontrato
          group by cs.descricao, nvl(c.descrservico, s.descricao), fr.idfatura
         union
         select initcap('SERVIÇO AVULSO') as "Categoria",
                initcap(s.descricao) as "Servico", sum(fr.qtde) as "Qtde",
                sum(trunc(fr.valor, 2)) as "Valor Bruto",
                sum(fr.desconto) as "Desconto",
                sum(trunc(fr.valorliquido, 2)) as "Valor Liquido",
                fr.idfatura as "Fatura"
           from faturaresumo fr, servicoavulso s
          where s.id = fr.idservicoavulso
          group by initcap('SERVIÇO AVULSO'), s.descricao, fr.idfatura
         union
         select initcap(ca.descricao) as "Categoria",
                initcap(nvl(cc.descrservico, s.descricao)) as "Servico",
                0 as "Qtde", 0 as "Valor Bruto", 0 as "Desconto",
                0 as "Valor Liquido", fat.id as "Fatura"
           from fatura fat, contratocobranca cc, servico s,
                categoriaservico ca
          where cc.idcontrato = fat.idcontrato
            and s.id = cc.idservico
            and ca.id = s.idcategoriaservico)
 group by "Categoria", "Servico", "Fatura"
/

