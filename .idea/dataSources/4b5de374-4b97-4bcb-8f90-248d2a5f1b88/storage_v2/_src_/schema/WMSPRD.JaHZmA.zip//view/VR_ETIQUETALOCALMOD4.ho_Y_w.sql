create view VR_ETIQUETALOCALMOD4 as
select a.descr armazem, l.idlocal, l.bloco, l.rua, l.predio, l.andar,
       l.apartamento, l.idlocalformatado idlocalformatado
  from gtt_selecao g, local l, armazem a
 where l.id = g.idselecionado
   and l.idarmazem = a.idarmazem
 order by l.idlocal

/

