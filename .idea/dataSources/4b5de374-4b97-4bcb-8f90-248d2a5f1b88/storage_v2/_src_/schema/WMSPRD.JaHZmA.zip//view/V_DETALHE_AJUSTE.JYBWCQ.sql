create view V_DETALHE_AJUSTE as
select a.idajustemovto id,
       trunc(nvl(a.datadocumento, nf.datacadastro)) datamov, nf.remetente, nf.destinatario,
       a.identidade,
       to_char(trunc(nvl(a.datadocumento, nf.datacadastro)), 'mm/yyyy') mesmov,
       to_char(nf.codigointerno) numnf,
       to_char(to_date(to_char(trunc(nvl(a.datadocumento, nf.datacadastro)), 'mm/yyyy'), 'mm/yyyy'), 'Month "de" yyyy') mes,
       'AJUSTE' classificacao, nd.idproduto,
       decode(nf.tipo, 'E', 'ENTRADA', 'SAIDA') TipoMov, nf.tipo,
       nd.qtdeatendida totalprod, nd.totalpeso totalpeso, nd.totalvolume,
       1 totalnf
  from notafiscal nf,
       (select n.nf, n.idproduto, 
                sum(nvl((e.pesobruto * n.qtdeatendida) / 1000, 0)) totalpeso,
                sum(n.qtdeatendida * e.fatorconversao) qtdeatendida,
                sum(round((e.altura * e.largura * e.comprimento *
                           n.qtdeatendida) / 1000000000, 3)) totalvolume
           from nfdet n, embalagem e
          where n.idproduto = e.idproduto
            and n.barra = e.barra
          group by n.nf, n.idproduto) nd, ajustemovto a
 where nf.idnotafiscal = nd.nf
   and nf.idajustemovto = a.idajustemovto
   and nf.sequencia like '%AJUSTE%'
   and nf.statusnf = 'P'
/

