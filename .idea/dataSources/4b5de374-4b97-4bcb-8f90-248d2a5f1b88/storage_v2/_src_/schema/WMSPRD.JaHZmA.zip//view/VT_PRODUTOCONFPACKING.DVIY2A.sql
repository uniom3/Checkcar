create view VT_PRODUTOCONFPACKING as
select pk_packing.getEstadoContagemPacking(0, v.pesavel, v.qtdeContada,
                                            v.qtdeEmVolume, v.qtdemin,
                                            v.qtdemax, v.qtdetotal) h$ESTADOCONTAGEMPACKING,
       pk_packing.getEstadoContagemPacking(1, v.pesavel, v.qtdeContada,
                                            v.qtdeEmVolume, v.qtdemin,
                                            v.qtdemax, v.qtdetotal) h$status,
       v.barralegivel barraIlegivel, v.codigoInterno,
       v.descricao descrProduto, v.qtdeContada QTDCONTADAPACKING,
       case
          when v.qtdetotal - v.qtdeemvolume - v.qtdecontada < 0 then
           0
          else
           v.qtdetotal - v.qtdeemvolume - v.qtdecontada
        end qtdeRestante, v.qtdeEmVolume, v.qtdeseparada, v.qtdetotal,
       v.pesavel, decode(v.pesavel, 1, to_char(v.qtdemin), ' ') totalMin,
       decode(v.pesavel, 1, to_char(v.qtdemax), ' ') totalMax,
       v.idproduto h$idProduto, v.idnotafiscal h$idnotafiscal,
       v.idenderecopacking h$idPacking, v.idonda h$idOnda,
       v.qtdeContada h$qtdeContada, e.barra h$barraUnitaria,
       (select count(1)
           from imagem_produto i
          where i.idproduto = v.idproduto) h$possuiImagem,
       v.fracionado h$fracionado, v.qtdetolerancia h$qtdetolerancia,
       v.idnotafiscal || v.idenderecopacking || v.idonda || v.idProduto h$tableId, v.h$data
  from v_produtoconfpacking v, embalagem e
 where e.idproduto = v.idproduto
   and e.barra = pk_produto.ret_codbarra_nao_precad(v.idproduto, 1)
/

