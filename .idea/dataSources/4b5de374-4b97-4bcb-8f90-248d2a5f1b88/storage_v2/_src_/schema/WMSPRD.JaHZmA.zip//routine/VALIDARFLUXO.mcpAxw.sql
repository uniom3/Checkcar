create function validarFluxo
(
  p_descr  varchar,
  p_idonda number
) return varchar2 is
  v_sequencia      varchar(1000);
  v_sequenciaAtual number;
  v_qtdeseq        number;
begin
  v_sequenciaAtual := 1;
  for c_sequencia in (select s.ordem ordemsequencia, e.descricao, se.ordem
                        from romaneiopai rp, configuracaoonda c,
                             fluxooperacao f, sequenciaoperacao s,
                             sequenciaetapa se, etapa e
                       where rp.idromaneio = p_idonda
                         and c.idconfiguracaoonda = rp.idconfiguracaoonda
                         and f.id = c.idfluxo
                         and s.idfluxo = f.id
                         and se.idsequencia = s.id
                         and e.id = se.idetapa
                       order by s.ordem, se.ordem)
  loop
    if (v_sequenciaAtual <> c_sequencia.ordemsequencia) then
      select count(1)
        into v_qtdeseq
        from dual
       where lower(v_sequencia) like p_descr;

      if (v_qtdeseq > 0) then
        return 'TRUE';
      end if;

      v_sequenciaAtual := c_sequencia.ordemsequencia;
      v_sequencia      := '';
    end if;

    if (v_sequencia is null) then
      v_sequencia := c_sequencia.descricao;
    else
      v_sequencia := v_sequencia || ' > ' || c_sequencia.descricao;
    end if;
  end loop;

  if (v_sequencia is not NULL) then
    select count(1)
      into v_qtdeseq
      from dual
     where lower(v_sequencia) like lower(p_descr);

    if (v_qtdeseq > 0) then
      return 'TRUE';
    end if;
  end if;

  return 'FALSE';
end validarFluxo;
/

