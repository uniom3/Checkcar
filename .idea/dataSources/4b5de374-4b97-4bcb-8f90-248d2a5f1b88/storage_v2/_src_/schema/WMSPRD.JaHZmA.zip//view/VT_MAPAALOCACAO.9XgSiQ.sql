create view VT_MAPAALOCACAO as
select m.idlotenf, m.idalocacao, m.idlote, m.idlocal, m.tipolocal, m.setor,
       m.depositante, m.codproduto, m.produto,
       decode(m.classificacao, 'C', 'COMPRA', 'D', 'DEVOLUCAO PARCIAL', 'T',
               'DEVOLUCAO TOTAL', 'R', 'REENTREGA', 'I', 'OPERACOES INTERNAS',
               'E', 'ENCOMENDA', 'B', 'CROSSDOCKING') tiporecebimento,
       m.tiporecebimento descrtiporecebimento, m.codreferencia,
       m.descr descrmapa, m.estadolote estado, m.qtde,
       m.descrreduzido embalagem, m.fatorconversao, m.normapalet norma,
       m.lote loteindustria, m.data dtgeracaomapaalocacao,
       m.usuario usuariogeroumapa, m.dtvenc dtvencimento,
       m.numerovolume nrovolume, m.barra,
       pk_lote.retinformacoesespecifica(m.idlote) informacaoespecifica,
       m.dataposicionamento dtposicionado,
       m.usuarioposicionamento usuarioposicionado, m.dataalocacao dtalocacao,
       m.usuarioalocacao usuarioalocacao, m.coddep coddepositante,
       m.idproduto, m.peso, m.cubagem, m.classificacao h$classificacao,
       m.idarmazem h$idarmazem, m.status h$status,
       m.idlocalformatado f$IDLOCAL, m.ordem h$ordem,
       m.iddepositante h$iddepositante,
       m.exigesenhamudancaalocacao h$exigesenhamudancaalocacao,
       m.qtdesaldoexigesenha h$qtdesaldoexigesenha,
       m.etiquetaimpressa h$etiquetaimpressa, m.h$previsualizarimplotes
  from v_mapaalocacao m
 where m.classificacao <> 'M'
/

