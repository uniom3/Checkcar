create TYPE T_LIST_MESSAGE_PARAM AS OBJECT
  (
    lista T_VA_MESSAGE_PARAM,
    constructor function T_LIST_MESSAGE_PARAM return self as result,
    MEMBER procedure addParam
    (
      p_value in varchar2
    ),
    
    MEMBER procedure addParam
    (
      p_value in number
    ),
    
    MEMBER procedure addParam
    (
      p_value in date
    )
  );

/

