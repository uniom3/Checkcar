create view VT_CODRASTTRANSDEP as
select crtd.codigorastreio,
       decode(crtd.status, 0, 'Não Utilizado', 1, 'Utilizado', 2,
               'Cancelado') status,
       crtd.idcodrasttransdep h$idcodrasttransdep,
       crtd.idconftranspdep h$idconftranspdep, crtd.status h$status,
       ctd.idservicotransportadora
  from codrasttransdep crtd, confTranspDepositante ctd
 where crtd.idconftranspdep = ctd.idconftranspdep
/

