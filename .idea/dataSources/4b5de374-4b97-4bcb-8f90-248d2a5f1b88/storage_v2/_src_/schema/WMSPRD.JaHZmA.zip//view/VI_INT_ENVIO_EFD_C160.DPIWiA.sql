create view VI_INT_ENVIO_EFD_C160 as
select distinct 'C160' reg, ' ' cod_part, ' ' veic_id,
                rtrim(to_char(sum(trunc(nfi.qtde)), 'FM990D99'),
                       to_char(0, 'D')) qtd_vol,
                rtrim(to_char(sum(nf.pesobruto), 'FM990D99'),
                       to_char(0, 'D')) peso_brt,
                rtrim(to_char(sum(nf.pesoliquido), 'FM990D99'),
                       to_char(0, 'D')) peso_liq, ' ' uf_id, nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento
  from notafiscal nf, nfimpressao nfi, entidade trans, depositante dp,
       regime re, operacao o, nfremarmazenagem nr
 where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
       nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
   and o.idoperacao = nf.idoperacao
   and trans.identidade = nf.transportadoranotafiscal
   and nfi.idprenf = nf.idprenf
   and decode(nf.statusnf, 'P', 1, 0) = 1
   and decode(nf.retornoreentrega, 'N', 1, 0) = 1
   and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and decode(re.classificacao, 'A', 1, 0) = 1
   and o.idoperacao = nf.idoperacao
   and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
   and nr.idnfremessa(+) = nf.idnotafiscal
 group by 'C160', ' ', ' ', ' ', nf.idarmazem,
          trunc(nvl(nr.datacobertura, nf.datacadastro))
/

