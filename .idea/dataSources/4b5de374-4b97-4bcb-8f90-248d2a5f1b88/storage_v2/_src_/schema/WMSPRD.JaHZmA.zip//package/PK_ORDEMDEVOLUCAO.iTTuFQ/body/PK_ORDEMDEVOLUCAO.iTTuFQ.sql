create package body pk_ordemdevolucao is

  function estadoSetorOrdemDevolucao(p_idOrdemDevolucao number)
    return varchar2 is
    v_estadoOrdemDevolucao char(1);
    v_qtde                 number;
    v_itemlocation         itemordemdevolucao.itemlocation%type;
    v_msg                  t_message;
  begin
    begin
      select distinct decode(ts.normal, 'N', C_ESTADO_DANIFICADO,
                              C_ESTADO_NORMAL)
        into v_estadoOrdemDevolucao
        from setor s, tiposetor ts
       where 1 = 1
         and ts.idtiposetor = s.idtiposetor
         and upper(s.codigointegracao) in
             (select distinct upper(io.itemlocation)
                from itemordemdevolucao io
               where io.idordemdevolucao = p_idOrdemDevolucao);
    exception
      when no_data_found then
        v_msg := t_message('Conferencia não pode ser habilitada.' ||
                           chr(13) ||
                           'O campo itemlocation da ordem de devolução {0}' ||
                           ' não foi encontrado no campo CÓDIGO DE INTEGRAÇÃO do cadastro de SETOR.' ||
                           chr(13) || 'Operação cancelada.');
        v_msg.addParam(p_idOrdemDevolucao);
        raise_application_error(-20000, v_msg.formatMessage);
      when too_many_rows then
        v_msg := t_message('Conferencia não pode ser habilitada.' ||
                           chr(13) ||
                           'O campo itemlocation da ordem de devolução {0}' ||
                           ' foi encontrado várias vezes no campo CÓDIGO DE INTEGRAÇÃO do cadastro de SETOR.' ||
                           chr(13) || 'Operação cancelada.');
        v_msg.addParam(p_idOrdemDevolucao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    return v_estadoOrdemDevolucao;
  
  end estadoSetorOrdemDevolucao;

  procedure cancelarOrdemDevolucao
  (
    p_idOrdemDevolucao    in number,
    p_idOrdemDevolucaoPai in number,
    p_idMotivo            in number,
    p_idUsuario           in number
  ) is
    v_status   number;
    v_prodConf number;
    v_msg      t_message;
  
    function isDepositanteExportaRTI(p_idOrdemDevolucaoPai number)
      return boolean is
      v_DepositanteExportaRTI number;
    begin
      begin
        select nvl(d.exportsolicfaturaretfornecxrti, 0)
          into v_DepositanteExportaRTI
          from depositante d
         where d.identidade =
               (select odp.iddepositante
                  from ordemdevolucaopai odp
                 where odp.id = p_idOrdemDevolucaoPai);
      
      exception
        when no_data_found then
          v_DepositanteExportaRTI := 0;
      end;
    
      return v_DepositanteExportaRTI > 0;
    
    end isDepositanteExportaRTI;
  
  begin
    select od.status
      into v_status
      from ordemdevolucao od
     where od.id = p_idOrdemDevolucao
       and od.idordemdevolucaopai = p_idOrdemDevolucaoPai;
  
    select nvl(sum(lr.qtde), 0)
      into v_prodConf
      from itemordemdevolucao iod, ordemdevolucaoremanejamento odr,
           loteremanejamento lr
     where 1 = 1
       and odr.iditemordemdevolucao = iod.id
       and lr.idremanejamento = odr.idremanejamento
       and iod.idordemdevolucao = p_idOrdemDevolucao;
  
    if not ((v_status = C_STATUS_ORDEM_PENDENTE) or
        (v_status = C_STATUS_ORDEM_REMANEJ_CONC and v_prodConf = 0) and
        v_status <> C_STATUS_ORDEM_CANCELADO) then
      v_msg := t_message('A Ordem de Devolução: {0}' ||
                         ' não pode ser cancelada pois seu status não está como Pendente!');
      v_msg.addParam(p_idOrdemDevolucao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update ordemdevolucao
       set status                = C_STATUS_ORDEM_CANCELADO,
           idmotivoocorrencia    = p_idMotivo,
           idusuariocancelamento = p_idUsuario
     where id = p_idOrdemDevolucao
       and idordemdevolucaopai = p_idOrdemDevolucaoPai;
  
    pk_integracao.exportarPRNOrdemDevolCanc(p_idOrdemDevolucao);
  
  end;

  procedure gerarRemanejamentos
  (
    p_idOrdemDevolucao    in number,
    p_idOrdemDevolucaoPai in number,
    p_idusuario           in number
  ) is
    v_msg t_message;
  
    cursor c_local_origem
    (
      p_idarmazem     in number,
      p_iddepositante in number,
      p_idproduto     in number,
      p_itemlocation  in varchar2
    ) is
      select lo.idarmazem, lo.idlocal, lt.idlote,
             nvl((ll.estoque - ll.pendencia + ll.adicionar), 0) disponivel
        from lotelocal ll, lote lt, local lo, setor s, regiaoarmazenagem ra
       where ll.estoque - ll.pendencia + ll.adicionar > 0
         and lt.idlote = ll.idlote
         and lt.iddepositante = p_iddepositante
         and lt.idproduto = p_idproduto
         and lo.idarmazem = p_idarmazem
         and lo.idlocal = ll.idlocal
         and lo.idarmazem = ll.idarmazem
         and lo.ativo = 'S'
         and s.idsetor = lo.idsetor
         and s.devolucaofornecedor = 0
         and s.expedicao = 'S'
         and lt.liberado = 'S'
         and ra.idregiao = lo.idregiao
         and s.codigointegracao = p_itemlocation
         and not exists
       (select 1
                from configuracaoonda co
               where co.idregiaoretornoestoque = ra.idregiao)
         and not exists (select 1
                from configuracaoonda co
               where co.idregiaopruadopulmao = ra.idregiao)
         and not exists (select 1
                from configuracaoonda co
               where co.idregiaopruadopicking = ra.idregiao)
         and not exists
       (select 1
                from pickingpicktolightonda p, produtolocal pc
               where pc.idprodutolocal = p.id
                 and pc.idarmazem = lo.idarmazem
                 and pc.idlocal = lo.idlocal)
         and not exists
       (select 1
                from setorrecebimento sr, tiporecebimento tr
               where tr.classificacao = 'E'
                 and tr.idtiporecebimento = sr.idtiporecebimento
                 and sr.idsetor = s.idsetor)
         and exists (select 1
                from setorproduto sp
               where sp.idsetor = s.idsetor
                 and sp.idproduto = lt.idproduto)
         and exists
       (select 1
                from setordepositante sd
               where sd.idsetor = s.idsetor
                 and sd.iddepositante = lt.iddepositante)
       order by lo.bloco, lo.rua, lo.predio, lo.andar, lo.apartamento;
    r_local_origem c_local_origem%rowtype;
  
    cursor c_local_destino
    (
      p_idarmazem     in number,
      p_iddepositante in number
    ) is
      select l.idlocal
        from (select distinct a.*
                 from (select l.idarmazem, s.idsetor, l.idlocal,
                               stragg(sp.idproduto) over(PARTITION BY l.idarmazem, s.idsetor, l.idlocal ORDER BY sp.idproduto RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) produtos
                          from local l, setor s, tiposetor ts, setorproduto sp
                         where s.idtiposetor = ts.idtiposetor
                           and s.idsetor = sp.idsetor
                           and l.ativo = 'S'
                           and l.tipo < 3
                           and l.buffer = 'N'
                           and l.idsetor = s.idsetor
                           and s.devolucaofornecedor = 1
                           and sp.idproduto in
                               (select idproduto
                                  from itemordemdevolucao
                                 where idordemdevolucao = p_idOrdemDevolucao)
                         group by l.idarmazem, s.idsetor, l.idlocal,
                                  sp.idproduto) a) l, setordepositante sd
       where sd.idsetor = l.idsetor
         and sd.iddepositante = p_iddepositante
         and l.idarmazem = p_idarmazem
         and l.produtos =
             (select stragg(a.idproduto)
                from (select distinct idproduto
                         from itemordemdevolucao
                        where idordemdevolucao = p_idOrdemDevolucao
                        order by idproduto) a)
         and l.idlocal not in
             (select l.idlocal
                from local l, remanejamento r, loteremanejamento lr,
                     ordemdevolucaoremanejamento odr, lote lo, lotelocal ll,
                     setor s, itemordemdevolucao iod, ordemdevolucao od
               where r.idremanejamento = lr.idremanejamento
                 and r.idremanejamento = odr.idremanejamento
                 and odr.iditemordemdevolucao = iod.id
                 and iod.idordemdevolucao = od.id
                 and od.id <> p_idOrdemDevolucao
                 and lr.idlote = lo.idlote
                 and lo.idlote = ll.idlote
                 and ll.idlocal = l.idlocal
                 and l.idsetor = s.idsetor
                 and s.devolucaofornecedor = 1
                 and (ll.estoque - ll.pendencia + ll.adicionar) > 0
               group by l.idlocal)
         and rownum = 1;
    r_local_destino c_local_destino%rowtype;
  
    r_od_pai            ordemdevolucaopai%rowtype;
    r_od                ordemdevolucao%rowtype;
    v_qtde_disponivel   number;
    r_lote              lote%rowtype;
    v_idremanejamento   number;
    v_idlocaldestino    varchar2(25);
    v_existe_um_estoque varchar2(1) := 'N';
    v_qtde_inv          number;
    v_inventarios       varchar2(4000);
  
    procedure realizaRemanejamento
    (
      p_idarmazem            in number,
      p_iddepositante        in number,
      p_iditemordemdevolucao in number,
      p_idproduto            in number,
      p_idlocalorigem        in varchar2,
      p_idloteorigem         in number,
      p_quantidade           in number
    ) is
    
      cursor c_existe_lote_remanejamento
      (
        p_idremanejamento in number,
        p_idlote          in number
      ) is
        select 1
          from loteremanejamento l
         where l.idremanejamento = p_idremanejamento
           and l.idlote = p_idlote;
      r_existe_lote_remanejamento c_existe_lote_remanejamento%rowtype;
    
      v_complementar            varchar2(200);
      v_existeItemRemanejamento number;
    
    begin
    
      v_idremanejamento := pk_remanejamento.cadastrar_remanejamento(p_idarmazem,
                                                                    p_idarmazem,
                                                                    p_idlocalorigem,
                                                                    v_idlocaldestino,
                                                                    1, null,
                                                                    'REMANEJAMENTO CRIADO - ORDEM DE DEVOLUÇÃO',
                                                                    C_NAO,
                                                                    C_SIM);
    
      select count(*)
        into v_existeItemRemanejamento
        from ordemdevolucaoremanejamento
       where iditemordemdevolucao = p_iditemordemdevolucao
         and idremanejamento = v_idremanejamento;
    
      if v_existeItemRemanejamento = 0 then
        insert into ordemdevolucaoremanejamento
          (iditemordemdevolucao, idremanejamento)
        values
          (p_iditemordemdevolucao, v_idremanejamento);
      end if;
    
      open c_existe_lote_remanejamento(v_idremanejamento, p_idloteorigem);
      fetch c_existe_lote_remanejamento
        into r_existe_lote_remanejamento;
    
      if c_existe_lote_remanejamento%found then
      
        update loteremanejamento
           set qtde =
               (qtde + p_quantidade)
         where idremanejamento = v_idremanejamento
           and idlote = p_idloteorigem;
      
      else
      
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde,
           diferenca)
        values
          (v_idremanejamento, p_idloteorigem, p_quantidade, C_NAO, C_SIM, 0);
      
      end if;
      close c_existe_lote_remanejamento;
    
      pk_estoque.incluir_estoque(p_idarmazem, p_idlocalorigem,
                                 p_idloteorigem, 0, p_idusuario,
                                 'LOTE GERADO INTERNAMENTE', c_nao);
    
      v_complementar := 'AUMENTADO ADICIONAR EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                        v_idremanejamento;
      pk_estoque.incluir_adicionar(p_idarmazem, v_idlocaldestino,
                                   p_idloteorigem, p_quantidade, p_idusuario,
                                   v_complementar);
    
      v_complementar := 'AUMENTADO PENDENCIA EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                        v_idremanejamento;
    
      pk_estoque.incluir_pendencia(p_idarmazem, p_idlocalorigem,
                                   p_idloteorigem, p_quantidade, p_idusuario,
                                   v_complementar);
    
    end realizaRemanejamento;
  
    procedure validarRemanejamentosGerados is
    begin
      for c in (select iod.idproduto,
                       nvl(sum(iod.quantidaderemocao), 0) quantidade,
                       sum(nvl(pk_ordemdevolucao.getQtdeProdConferidaLote(odr.idremanejamento,
                                                                           iod.idproduto,
                                                                           lr.idlote),
                                0)) qtdeConferida
                  from itemordemdevolucao iod,
                       ordemdevolucaoremanejamento odr, loteremanejamento lr
                 where 1 = 1
                   and odr.iditemordemdevolucao = iod.id
                   and lr.idremanejamento = odr.idremanejamento
                   and iod.idordemdevolucao = p_idOrdemDevolucao
                 group by iod.idproduto, iod.quantidaderemocao)
      loop
        if (c.qtdeConferida > c.quantidade) then
          v_msg := t_message('O PRODUTO ID: {0} POSSUI QUANTIDADE CONFERIDA({1})' ||
                             ' MAIOR QUE A QUANTIDADE SOLICITADA({2})' ||
                             ' NO VENDOR RETURN({3}).' || chr(13) ||
                             'OPERAÇÃO CANCELADA.');
          v_msg.addParam(c.idproduto);
          v_msg.addParam(c.qtdeConferida);
          v_msg.addParam(c.quantidade);
          v_msg.addParam(p_idOrdemDevolucao);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
    
      for c in (select sum(lr.qtde) qtderem, sum(i.quantidaderemocao) qtdedev,
                       l.idproduto, i.idordemdevolucao
                  from ordemdevolucaoremanejamento orr, itemordemdevolucao i,
                       loteremanejamento lr, lote l
                 where 1 = 1
                   and i.id = orr.iditemordemdevolucao
                   and lr.idremanejamento = orr.idremanejamento
                   and lr.idlote = l.idlote
                   and i.idproduto = l.idproduto
                   and i.idordemdevolucao = p_idOrdemDevolucao
                 group by l.idproduto, i.idordemdevolucao
                having sum(lr.qtde) > sum(i.quantidaderemocao)
                 order by i.idordemdevolucao)
      loop
        v_msg := t_message('O PRODUTO ID: {0} POSSUI QUANTIDADE REMANEJADA({1})' ||
                           ' MAIOR QUE A QUANTIDADE SOLICITADA({2})' ||
                           ' NO VENDOR RETURN({3}).' || chr(13) ||
                           'OPERAÇÃO CANCELADA.');
        v_msg.addParam(c.idproduto);
        v_msg.addParam(c.qtderem);
        v_msg.addParam(c.qtdedev);
        v_msg.addParam(p_idOrdemDevolucao);
        raise_application_error(-20000, v_msg.formatMessage);
      end loop;
    end validarRemanejamentosGerados;
  
  begin
  
    begin
      select odp.*
        into r_od_pai
        from ordemdevolucaopai odp
       where odp.id = p_idOrdemDevolucaoPai
         for update;
    exception
      when no_data_found then
        v_msg := t_message('ORDEM DE DEVOLUÇÂO PAI NÃO ENCONTRADA ({0}).');
        v_msg.addParam(p_idOrdemDevolucaoPai);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    begin
      select od.*
        into r_od
        from ordemdevolucao od
       where od.id = p_idOrdemDevolucao;
    exception
      when no_data_found then
        v_msg := t_message('ORDEM DE DEVOLUÇÂO NÃO ENCONTRADA ({0}).');
        v_msg.addParam(p_idOrdemDevolucao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (r_od.status <> C_STATUS_ORDEM_PENDENTE) then
      v_msg := t_message('A ORDEM DE DEVOLUÇÃO DEVE ESTAR NO STATUS PENDENTE PARA GERAR REMANEJAMENTOS.');
      v_msg.addParam(p_idOrdemDevolucao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    open c_local_destino(r_od_pai.idarmazem, r_od_pai.iddepositante);
    fetch c_local_destino
      into r_local_destino;
  
    if c_local_destino%found then
      v_idlocaldestino := r_local_destino.idlocal;
    else
      close c_local_destino;
      v_msg := t_message('NENHUM LOCAL DE DESTINO ENCONTRADO PARA OS PRODUTOS DA ORDEM DE DEVOLUCAO ({0})' ||
                         ', DEPOSITANTE ({1}), ARMAZEM ({2}).');
      v_msg.addParam(p_idOrdemDevolucao);
      v_msg.addParam(r_od_pai.iddepositante);
      v_msg.addParam(r_od_pai.idarmazem);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
    close c_local_destino;
  
    for c_item in (select *
                     from itemordemdevolucao
                    where idordemdevolucaopai = p_idOrdemDevolucaoPai
                      and idordemdevolucao = p_idOrdemDevolucao)
    loop
    
      v_qtde_disponivel := nvl(c_item.quantidaderemocao, 0);
    
      if c_local_origem%isopen then
        close c_local_origem;
      end if;
    
      open c_local_origem(r_od_pai.idarmazem, r_od_pai.iddepositante,
                          c_item.idproduto, c_item.itemlocation);
      fetch c_local_origem
        into r_local_origem;
    
      if c_local_origem%found then
        while (c_local_origem%found)
        loop
          v_existe_um_estoque := 'S';
          if r_local_origem.disponivel >= v_qtde_disponivel then
            realizaRemanejamento(r_od_pai.idarmazem, r_od_pai.iddepositante,
                                 c_item.id, c_item.idproduto,
                                 r_local_origem.idlocal,
                                 r_local_origem.idlote, v_qtde_disponivel);
          
            v_qtde_disponivel := 0;
            exit;
          else
            realizaRemanejamento(r_od_pai.idarmazem, r_od_pai.iddepositante,
                                 c_item.id, c_item.idproduto,
                                 r_local_origem.idlocal,
                                 r_local_origem.idlote,
                                 r_local_origem.disponivel);
            v_qtde_disponivel := (v_qtde_disponivel -
                                 r_local_origem.disponivel);
          end if;
          fetch c_local_origem
            into r_local_origem;
        end loop;
        close c_local_origem;
      end if;
    
      if (v_qtde_disponivel > 0) then
        select nvl(sum(a.qtde), 0), stragg(a.idinventario)
          into v_qtde_inv, v_inventarios
          from (select nvl(sum(ll.estoque - ll.pendencia + ll.adicionar), 0) qtde,
                        ei.idinventario
                   from lotelocal ll, lote lt, local lo, setor s,
                        escopoinventario ei, inventario i
                  where ll.estoque - ll.pendencia + ll.adicionar > 0
                    and lt.idlote = ll.idlote
                    and lt.iddepositante = r_od_pai.iddepositante
                    and lt.idproduto = c_item.idproduto
                    and lo.idarmazem = r_od_pai.idarmazem
                    and lo.idlocal = ll.idlocal
                    and lo.idarmazem = ll.idarmazem
                    and ei.idarmazem = lo.idarmazem
                    and ei.idlocal = lo.idlocal
                    and ei.idinventario = i.idinventario
                    and i.situacao not in ('F', 'X')
                    and lo.ativo = 'N'
                    and lo.origembloqueio = 2
                    and s.idsetor = lo.idsetor
                    and s.devolucaofornecedor = 0
                    and s.expedicao = 'S'
                    and s.codigointegracao = c_item.itemlocation
                  group by ei.idinventario) a;
      
        --se ainda possuir quantidade para remanejar, precisa verificar se tem algum inventário bloquenado endereços que possuem
        --o produto e que atenda a quantidade restante
        if (v_qtde_inv > 0 AND (v_qtde_inv >= v_qtde_inv)) then
          v_msg := t_message('OS REMANEJAMENTOS NÃO PUDERAM SER CRIADOS DEVIDO A EXISTIR ESTOQUE NECESSÁRIO PARA O MESMO BLOQUEADO PELO(S) INVENTÁRIO(S): {0}. OPERAÇÃO CANCELADA.');
          v_msg.addParam(v_inventarios);
          raise_application_error(-20000, v_msg.formatMessage);
        elsif (v_qtde_inv > 0) then
          v_msg := t_message('NÃO FOI ENCONTRADO ESTOQUE SUFICIENTE PARA A GERAÇÃO DOS REMANEJAMENTOS. OPERAÇÃO CANCELADA.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
    end loop;
  
    if v_existe_um_estoque = 'N' then
      v_msg := t_message('NENHUM REMANEJAMENTO GERADO PARA OS PRODUTOS DA ORDEM DE DEVOLUCAO ({0}), ' ||
                         'DEPOSITANTE ({1}), ARMAZEM ({2}). PELO MENOS UM PRODUTO DEVE SER ENCONTRADO COM ESTOQUE.');
      v_msg.addParam(p_idOrdemDevolucao);
      v_msg.addParam(r_od_pai.iddepositante);
      v_msg.addParam(r_od_pai.idarmazem);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarRemanejamentosGerados;
  
    -- Atualiza o status para Aguardando Remanejamento
    update ordemdevolucao
       set status = C_STATUS_ORDEM_AG_REMANEJ
     where id = p_idOrdemDevolucao
       and idordemdevolucaopai = p_idOrdemDevolucaoPai;
  end;

  procedure habilitarConferencia
  (
    p_idOrdemDevolucao    in number,
    p_idOrdemDevolucaoPai in number,
    p_idusuario           in number
  ) is
    v_mensagemErro varchar2(4000);
    v_msg          t_message;
  
    cursor c_nota_nao_liberada is
      select g.descricao
        from gtt_resumoexecucao g
       where grupo <> 'Liberado com sucesso'
         and rownum = 1;
    r_nota_nao_liberada c_nota_nao_liberada%rowtype;
  
    cursor c_local_separacao(p_idonda in number) is
      select lo.idregiao as idregiaoorigem, ro.descr as origem,
             decode(nvl(lo.buffer, 'N'), 'S', 1, 0) as bufferorigem,
             ro.tipo as tiporegiaoorigem, ld.idregiao as idregiaodestino,
             rd.descr as destino,
             decode(nvl(ld.buffer, 'N'), 'S', 1, 0) as bufferdestino,
             rd.tipo as tiporegiaodestino, m.datapausa as datapausa,
             sum(case
                    when m.status in (1) then
                     1
                    else
                     0
                  end) as iniciada,
             count(distinct m.idlocalorigem) as quantidade,
             min(m.id) as ordem
        from movimentacao m, local lo, local ld, regiaoarmazenagem ro,
             regiaoarmazenagem rd
       where m.idlocalorigem = lo.id
         and m.idlocaldestino = ld.id
         and lo.idregiao = ro.idregiao
         and ld.idregiao = rd.idregiao
         and m.idonda = p_idonda
         and m.status <> 3
       group by lo.idregiao, ro.descr, lo.buffer, ro.tipo, ld.idregiao,
                rd.descr, ld.buffer, rd.tipo, m.datapausa;
    r_local_separacao c_local_separacao%rowtype;
  
    r_od_pai         ordemdevolucaopai%rowtype;
    r_od             ordemdevolucao%rowtype;
    r_nf             notafiscal%rowtype;
    r_nfdet          nfdet%rowtype;
    v_idnfdevolucao  number;
    v_qtde_item      number;
    v_id_conf_onda   number;
    v_idoperacao     number;
    v_mensagem       varchar2(1000);
    v_resultado_onda number;
    v_idonda         number;
    v_retorno_sep    number;
    v_destinatario   number;
  
    C_ORIGEM_FORMACAO_EXPEDICAO constant number := 0;
  
    v_qtdeConferida        number := 0;
    v_idMotivoCancelamento motivo.idmotivo%type;
  
    function getCodInternoLivre(p_codigoControleTransmissao in number)
      return number is
      v_novoCodInterno number;
      v_codJaUtilizado number;
    
    begin
    
      select count(1)
        into v_codJaUtilizado
        from notafiscal nf
       where nf.codigointerno = p_codigoControleTransmissao;
    
      if (v_codJaUtilizado = 0) then
        v_novoCodInterno := p_codigoControleTransmissao;
      else
      
        v_novoCodInterno := getCodInternoLivre(p_codigoControleTransmissao + 1);
      
      end if;
    
      return v_novoCodInterno;
    
    end getCodInternoLivre;
  
  begin
  
    begin
      select odp.*
        into r_od_pai
        from ordemdevolucaopai odp
       where odp.id = p_idOrdemDevolucaoPai
         for update;
    exception
      when no_data_found then
        v_msg := t_message('ORDEM DE DEVOLUÇÂO PAI NÃO ENCONTRADA ({0}).');
        v_msg.addParam(p_idOrdemDevolucaoPai);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    begin
      select od.*
        into r_od
        from ordemdevolucao od
       where od.id = p_idOrdemDevolucao;
    exception
      when no_data_found then
        v_msg := t_message('ORDEM DE DEVOLUÇÂO NÃO ENCONTRADA ({0}).');
        v_msg.addParam(p_idOrdemDevolucao);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    begin
      select e.identidade
        into v_destinatario
        from entidade e
       where 1 = 1
         and e.ativo = 'S'
         and e.codigointerno = r_od.partyid;
    exception
      when no_data_found then
        v_msg := t_message('CÓDIGO INTERNO DO DESTINATARIO - {0} NÃO LOCALIZADO');
        v_msg.addParam(r_od.partyid);
        raise_application_error(-20000, v_msg.formatMessage);
      when too_many_rows then
        v_msg := t_message('FOI ENCONTRADO MAIS DE UM DESTINATÁRIO ATIVO COM O CÓDIGO INTERNO - {0}');
        v_msg.addParam(r_od.partyid);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    begin
    
      v_idoperacao := pk_notafiscal.RetornarOperacao(r_od_pai.iddepositante,
                                                     r_od_pai.iddepositante,
                                                     'S', null);
    
    exception
      when no_data_found then
        v_msg := t_message('NENHUMA OPERAÇÃO ENCONTRADA PARA SER UTILIZADA NA ORDEM DE DEVOLUÇÃO.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    --Inserindo Cabeçalho da NF
    r_nf.iddepositante     := r_od_pai.iddepositante;
    r_nf.ident_entrega     := v_destinatario;
    r_nf.destinatario      := v_destinatario;
    r_nf.remetente         := r_od_pai.iddepositante;
    r_nf.destinatario      := v_destinatario;
    r_nf.dataemissao       := sysdate;
    r_nf.movestoque        := 'S';
    r_nf.digitada          := 'N';
    r_nf.impresso          := 'N';
    r_nf.tipo              := 'S';
    r_nf.statusnf          := 'N';
    r_nf.tiponf            := 'P';
    r_nf.estoqueverificado := 'S';
    r_nf.idarmazem         := r_od_pai.idarmazem;
  
    r_nf.codigointerno := getCodInternoLivre(r_od_pai.codigocontroletransmissao);
  
    if (upper(r_od.returntype) in ('OVERSTOCK')) then
      r_nf.estado := 'N';
    else
      r_nf.estado := estadoSetorOrdemDevolucao(p_idOrdemDevolucao);
    end if;
  
    v_idnfdevolucao := pk_notafiscal.insere_cabecalho_nf(r_nf);
  
    update notafiscal
       set numpedidofornecedor      = r_od.codigointerno,
           devolucaofornecedor      = 1,
           transportadoranotafiscal = r_od.transportadora,
           idoperacao               = v_idoperacao,
           idservicotransportadora  = r_od.idservicotransportadora
     where idnotafiscal = v_idnfdevolucao;
  
    for c_item in (select iod.id, iod.idproduto,
                          sum(nvl(pk_ordemdevolucao.getQtdeProdConferidaLote(odr.idremanejamento,
                                                                              iod.idproduto,
                                                                              lr.idlote),
                                   0)) qtdeConferida, iod.idordemdevolucaopai,
                          iod.idordemdevolucao
                     from itemOrdemDevolucao iod,
                          ordemdevolucaoremanejamento odr, remanejamento r,
                          loteremanejamento lr, lote l
                    where iod.id = odr.iditemordemdevolucao(+)
                      and odr.idremanejamento = r.idremanejamento(+)
                      and r.idremanejamento = lr.idremanejamento(+)
                      and lr.idlote = l.idlote(+)
                      and l.idproduto = iod.idproduto
                      and iod.idordemdevolucaopai = p_idOrdemDevolucaoPai
                      and iod.idordemdevolucao = p_idOrdemDevolucao
                    group by iod.id, iod.idproduto, iod.idordemdevolucaopai,
                             iod.idordemdevolucao)
    
    loop
      r_nfdet := null;
    
      -- Inserindo os itens na nota fiscal
      r_nfdet.idnfdet       := null;
      r_nfdet.nf            := v_idnfdevolucao;
      r_nfdet.barra         := pk_produto.retornarcodbarramenorfator(c_item.idproduto);
      r_nfdet.idproduto     := c_item.idproduto;
      r_nfdet.qtde          := c_item.qtdeconferida;
      r_nfdet.valordefinido := 'N';
    
      if (nvl(c_item.qtdeconferida, 0) > 0) then
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      end if;
    
      v_qtdeConferida := v_qtdeConferida + nvl(c_item.qtdeconferida, 0);
    
    end loop;
  
    pk_notafiscal.p_totaliza_nf(v_idnfdevolucao, c_nao);
    pk_notafiscal.p_gerar_nfimpressao(v_idnfdevolucao, c_nao);
  
    if (v_qtdeConferida > 0) then
    
      update nfimpressao n
         set n.situacaoimpressao = 'A'
       where exists (select 1
                from notafiscal nf
               where nf.idnotafiscal = v_idnfdevolucao
                 and nf.idprenf = n.idprenf);
    
      select nf.*
        into r_nf
        from notafiscal nf
       where nf.idnotafiscal = v_idnfdevolucao;
    
      delete from gtt_selecaoliberacao;
      insert into gtt_selecaoliberacao
        (idselecionado)
      values
        (v_idnfdevolucao);
    
      pk_notafiscal.liberarNFExpedicao(p_idusuario, r_od_pai.idarmazem);
    
      open c_nota_nao_liberada;
      fetch c_nota_nao_liberada
        into r_nota_nao_liberada;
    
      if c_nota_nao_liberada%found then
        close c_nota_nao_liberada;
        v_msg := t_message('Erro ao liberar Nota para Expedição: {0}');
        v_msg.addParam(r_nota_nao_liberada.descricao);
        raise_application_error(-20000, v_msg.formatMessage);
      else
        close c_nota_nao_liberada;
      
        select confondaretornofornecedores
          into v_id_conf_onda
          from depositante
         where identidade = r_od_pai.iddepositante;
      
        if v_id_conf_onda is null then
          v_msg := t_message('Configuração de Onda padrão (Ordem Devolução) não encontrada para o Depositante: {0}');
          v_msg.addParam(r_od_pai.iddepositante);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        insert into gtt_propriedade
          (propriedade, valor1, valor2)
        values
          ('NOTA_FISCAL', v_idnfdevolucao, null);
      
        insert into gtt_propriedade
          select 'DESTINO_SAIDA' PROPRIEDADE, r_od.transportadora VALOR1,
                 l.id VALOR2
            from local l
           where l.idarmazem = r_od_pai.idarmazem
             and l.idlocal = r_od.idlocaldoca;
      
        v_resultado_onda := pk_onda.formarOnda(v_idonda, r_od_pai.idarmazem,
                                               v_id_conf_onda,
                                               'ONDA ORDEM DEVOLUÇÃO - ' ||
                                                r_od.id || ' / NF - ' ||
                                                v_idnfdevolucao, p_idusuario,
                                               C_ORIGEM_FORMACAO_EXPEDICAO);
      
        if v_resultado_onda = RESULTADO_ONDA_FORMADA then
        
          update romaneiopai
             set statusonda = 2
           where idromaneio = v_idonda;
        
          open c_local_separacao(v_idonda);
          fetch c_local_separacao
            into r_local_separacao;
        
          if c_local_separacao%found then
            close c_local_separacao;
          
            v_retorno_sep := pk_seponda.separacaoManual(v_idonda, 0,
                                                        p_idusuario,
                                                        v_idnfdevolucao,
                                                        r_local_separacao.bufferorigem,
                                                        r_local_separacao.idregiaoorigem,
                                                        r_local_separacao.bufferdestino,
                                                        r_local_separacao.idregiaodestino,
                                                        0, 0, null,
                                                        v_mensagem);
          
            if v_retorno_sep = C_ORIGEM_CONCLUIDO then
            
              v_retorno_sep := pk_seponda.separacaoManual(v_idonda, 0,
                                                          p_idusuario,
                                                          v_idnfdevolucao,
                                                          r_local_separacao.bufferorigem,
                                                          r_local_separacao.idregiaoorigem,
                                                          r_local_separacao.bufferdestino,
                                                          r_local_separacao.idregiaodestino,
                                                          0, 0, null,
                                                          v_mensagem);
            
              if v_retorno_sep <> C_DESTINO_CONCLUIDO then
                v_msg := t_message('Erro ao gerar a Separação - Retorno Separação: {0}');
                v_msg.addParam(v_retorno_sep);
                raise_application_error(-20000, v_msg.formatMessage);
              end if;
            
            end if;
          
          else
            close c_local_separacao;
            v_msg := t_message('Local de Separação não encontrado para a Onda Gerada');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        elsif v_resultado_onda = RESULTADO_ERRO_FORMACAO then
          select e.detalhe
            into v_mensagemErro
            from ERROGERACAOONDA e
           where e.idonda = v_idonda
             and rownum = 1
           order by e.id desc;
        
          v_msg := t_message(v_mensagemErro);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      -- Atualiza o status para Aguardando Conferência
      update ordemdevolucao
         set status       = C_STATUS_ORDEM_AG_CONFERENCIA,
             idnotafiscal = v_idnfdevolucao
       where id = p_idOrdemDevolucao
         and idordemdevolucaopai = p_idOrdemDevolucaoPai;
    else
      begin
        select m.idmotivo
          into v_idMotivoCancelamento
          from motivo m
         where m.utzdevolucaofornecedor = 1
           and rownum = 1;
      exception
        when no_data_found then
          v_msg := t_message('Motivo de devolução de fornecedor não encontrado.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      pk_function_control.disableFunction('ExportarCancelamento');
    
      delete from nfimpressao nfi
       where 1 = 1
         and exists (select 1
                from notafiscal nf
               where nf.idprenf = nfi.idprenf
                 and nf.idnotafiscal = v_idnfdevolucao);
    
      pk_function_control.enableFunction('ExportarCancelamento');
    
      cancelarOrdemDevolucao(p_idOrdemDevolucao, p_idOrdemDevolucaoPai,
                             v_idMotivoCancelamento, p_idusuario);
    end if;
  
  end;

  procedure finalizarRemanejamento(p_idRemanejamento in number) is
    v_ordem_devolucao        number;
    v_qtderem_nao_finalizado number;
  begin
    begin
    
      select i.idordemdevolucao
        into v_ordem_devolucao
        from ordemdevolucaoremanejamento o, itemordemdevolucao i
       where o.iditemordemdevolucao = i.id
         and o.idremanejamento = p_idremanejamento
       group by i.idordemdevolucao;
    
      select count(*)
        into v_qtderem_nao_finalizado
        from itemordemdevolucao iod, ordemdevolucao od,
             ordemdevolucaoremanejamento odr, remanejamento r
       where iod.idordemdevolucao = od.id
         and iod.id = odr.iditemordemdevolucao
         and odr.idremanejamento = r.idremanejamento
         and od.id = v_ordem_devolucao
         and r.status <> 'F';
    
      if v_qtderem_nao_finalizado = 0 then
        update ordemdevolucao
           set status = C_STATUS_ORDEM_REMANEJ_CONC
         where id = v_ordem_devolucao;
      end if;
    
    exception
      when no_data_found then
        null;
    end;
  end;

  function getQtdeProdConferida
  (
    p_idRemanejamento number,
    p_idProduto       number,
    p_conferido       varchar2
  ) return number is
    v_qtde number;
  begin
  
    select nvl(sum(lr.qtde), 0)
      into v_qtde
      from loteremanejamento lr, lote l
     where lr.idlote = l.idlote
       and l.idproduto = p_idProduto
       and lr.idremanejamento = p_idRemanejamento
       and lr.conferido = p_conferido;
  
    return v_qtde;
  end;

  function getQtdeProdConferidaLote
  (
    p_idRemanejamento number,
    p_idProduto       number,
    p_idlote          number
  ) return number is
    v_qtde number;
  begin
  
    select nvl(lr.qtde, 0)
      into v_qtde
      from loteremanejamento lr, lote l
     where lr.idlote = l.idlote
       and l.idproduto = p_idProduto
       and lr.idremanejamento = p_idRemanejamento
       and l.idlote = p_idlote;
  
    return v_qtde;
  end;

  procedure vincularTransportadora
  (
    p_idOrdemDevolucao     in number,
    p_idTransportadora     in number,
    p_idServTransportadora in number,
    p_idLocalDoca          varchar2
  ) is
  begin
    update ordemdevolucao
       set transportadora          = p_idTransportadora,
           idservicotransportadora = p_idServTransportadora,
           idlocaldoca             = p_idLocalDoca
     where id = p_idOrdemDevolucao;
  end;

  procedure finalizaConferencia(p_idOnda in number) is
  
    cursor c_onda_ordem_devolucao is
      select od.id, odp.iddepositante, d.exportaconfretornoforn,
             d.exportsolicfaturaretfornecxrti,
             d.exportsolicfaturaretoforneauto
        from romaneiopai rp, nfromaneio nr, notafiscal nf, ordemdevolucao od,
             ordemdevolucaopai odp, depositante d
       where rp.idromaneio = nr.idromaneio
         and nr.idnotafiscal = nf.idnotafiscal
         and nf.numpedidofornecedor = od.codigointerno
         and od.idordemdevolucaopai = odp.id
         and odp.iddepositante = d.identidade
         and rp.liberado = 'S'
         and rp.idromaneio = p_idOnda;
    r_onda_ordem_devolucao c_onda_ordem_devolucao%rowtype;
  
  begin
  
    open c_onda_ordem_devolucao;
    fetch c_onda_ordem_devolucao
      into r_onda_ordem_devolucao;
  
    if c_onda_ordem_devolucao%found then
    
      if r_onda_ordem_devolucao.exportaconfretornoforn = 1 then
      
        update ordemdevolucao
           set status = C_STATUS_ORDEM_AG_FATURAMENTO
         where id = r_onda_ordem_devolucao.id;
      
        if (r_onda_ordem_devolucao.exportsolicfaturaretfornecxrti =
           C_SIM_NUMBER) then
          if (r_onda_ordem_devolucao.exportsolicfaturaretoforneauto =
             C_SIM_NUMBER) then
            pk_integracao.exportarRTI(p_idOnda);
          end if;
        else
          pk_integracao.exportarPRN(p_idOnda);
        end if;
      
      else
      
        update ordemdevolucao
           set status = C_STATUS_ORDEM_FINALIZADO
         where id = r_onda_ordem_devolucao.id;
      
      end if;
    end if;
    close c_onda_ordem_devolucao;
  end;

  procedure excluirOrdemDevolucao
  (
    p_idOrdemDevolucao    in number,
    p_idOrdemDevolucaoPai in number,
    p_idUsuario           in number
  ) is
    v_status number;
    v_msg    t_message;
  begin
  
    select o.status
      into v_status
      from ordemdevolucao o
     where o.id = p_idOrdemDevolucao;
  
    if v_status <> 0 then
      v_msg := t_message('Não é possível excluir a Ordem de Devolução id: {0}.' ||
                         ' A Ordem de Devolução deve estar no Status PENDENTE para ser excluida.');
      v_msg.addParam(p_idOrdemDevolucao);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from itemordemdevolucao io
     where io.idordemdevolucao = p_idOrdemDevolucao;
    delete from ordemDevolucao o
     where o.id = p_idOrdemDevolucao;
    delete from ordemDevolucaoPai op
     where op.id = p_idOrdemDevolucaoPai;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'A Ordem de Devolução ' || p_idOrdemDevolucao ||
                          ' foi excluida.', p_idOrdemDevolucao, 'OD');
  
  end;

  procedure atualizarEnvioRTI(p_idOnda in number) is
  
  begin
  
    for c_ordemAtz in (select od.id
                         from nfromaneio nfr, notafiscal nf,
                              ordemdevolucao od
                        where nfr.idromaneio = p_idOnda
                          and nf.idnotafiscal = nfr.idnotafiscal
                          and od.idnotafiscal = nf.idnotafiscal)
    loop
      update ordemdevolucao
         set exportouRTI = 1
       where id = c_ordemAtz.Id;
    end loop;
  
  end atualizarEnvioRTI;

  procedure faturarPedidoManual
  (
    p_idprenf        in number,
    p_codigointerno  in number,
    p_serie          in varchar2,
    p_chaveacessonfe in varchar2,
    p_idusuario      in number
  ) is
    v_idordemdevolucao number;
    v_existeErro       number;
  begin
    pk_notafiscal.faturarPedido(p_idprenf, p_codigointerno, p_serie,
                                p_chaveacessonfe, null, null, p_idusuario,
                                'M');
  
    select count(1)
      into v_existeErro
      from gtt_resumoexecucao g
     where g.tipo <> 0;
  
    if (v_existeErro = 0) then
    
      begin
        select od.id
          into v_idordemdevolucao
          from notafiscal nf, ordemdevolucao od
         where nf.idprenf = p_idprenf
           and od.idnotafiscal = nf.idnotafiscal;
      
      exception
        when others then
          v_idordemdevolucao := 0;
      end;
    
      if v_idordemdevolucao <> 0 then
        update ordemdevolucao od
           set od.status = 2
         where od.id = v_idordemdevolucao;
      
        update nfimpressao nfi
           set nfi.situacaonfe = 3
         where nfi.idprenf = p_idprenf;
      end if;
    end if;
  end;

end;
/

