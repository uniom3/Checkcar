create view VR_CONFERENCIAENTRADADETAIL as
select c.depositante, c.cnpj, c.cpf, inscrestadual, c.notafiscal, c.serie,
       c.dataemissao, c.cfop, c.baseicms, c.icms, c.totalnf, c.idnotafiscal,
       c.idarmazem, c.iddepositante, c.armazem, c.cnpjarmazem,
       c.armazeminscr, c.isag, stragg(c.codigointernoCompra) notascompra,
       c.numor, c.dataor, c.tipooper,
       nvl(i.codigoitem, i2.codigoitem) codigoitem,
       nvl(i.descricaoitem, i2.descricaoitem) descricaoitem,
       nvl(i.lotefornecedor, i2.lotefornecedor) lotefornecedor,
       nvl(i.datavencimentolote, i2.datavencimentolote) datavencimentolote,
       nvl(i.qtdeunidaderecebida, i2.qtdeunidaderecebida) qtdeunidaderecebida,
       nvl(i.padraocaixaunrecebida, i2.padraocaixaunrecebida) padraocaixaunrecebida,
       nvl(i.padraopaletsistema, i2.padraopaletsistema) padraopaletsistema,
       nvl(i.padraopaleteunrecebida, i2.padraopaleteunrecebida) padraopaleteunrecebida,
       null ordemcompra, null dataordemcompra
  from vt_conferenciaentrada c, v_conferenciaentradaitem i,
       v_conferenciaentradaitem i2
 where i.idnotafiscal(+) = c.idnotafiscal
   and i2.idnotafiscal(+) = c.idnotafiscalCompra
 group by c.depositante, c.cnpj, c.cpf, inscrestadual, c.notafiscal, c.serie,
          c.dataemissao, c.cfop, c.baseicms, c.icms, c.totalnf,
          c.idnotafiscal, c.idarmazem, c.iddepositante, c.armazem,
          c.cnpjarmazem, c.armazeminscr, c.isag, c.numor, c.dataor,
          c.tipooper, nvl(i.codigoitem, i2.codigoitem),
          nvl(i.descricaoitem, i2.descricaoitem),
          nvl(i.lotefornecedor, i2.lotefornecedor),
          nvl(i.datavencimentolote, i2.datavencimentolote),
          nvl(i.qtdeunidaderecebida, i2.qtdeunidaderecebida),
          nvl(i.padraocaixaunrecebida, i2.padraocaixaunrecebida),
          nvl(i.padraopaletsistema, i2.padraopaletsistema),
          nvl(i.padraopaleteunrecebida, i2.padraopaleteunrecebida)
/

