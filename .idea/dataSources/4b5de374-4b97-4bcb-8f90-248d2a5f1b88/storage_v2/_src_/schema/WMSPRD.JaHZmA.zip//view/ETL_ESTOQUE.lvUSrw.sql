create view ETL_ESTOQUE as
select est.idlote, est.idlote idlotemsg, est.idarmazem idarmazemmsg, est.idarmazem, est.codarmazem, est.descrarmazem,
       est.iddepositante, est.coddepositante, est.descrdepositante,
       est.idproduto, est.codproduto, est.descrproduto, est.estadoestoque,
       est.qtdeestoque
  from (select lt.idlote, ll.idarmazem, a.codigointerno codArmazem,
                a.descr descrArmazem, lt.iddepositante,
                ed.codigointerno codDepositante,
                ed.razaosocial descrDepositante, lt.idproduto,
                p.codigointerno codProduto, p.descr descrProduto,
                decode(lt.estado, 'N', 'BOM',
                        decode(lt.estado, 'D', 'DANIFICADO',
                                decode(lt.estado, 'T', 'VENCIDO_TRUNCADO'))) estadoEstoque,
                sum((ll.estoque + ll.adicionar) - ll.pendencia) qtdeEstoque,
                stragg(lt2.idlote)
           from lote lt, lote lt2, lotelocal ll, depositante d, entidade ed,
                produto p, armazem a
          where lt2.idproduto = lt.idproduto
            and lt2.iddepositante = lt.iddepositante
            and ll.idlote = lt2.idlote
            and lt2.estado = lt.estado
            and d.identidade = lt.iddepositante
            and ed.identidade = d.identidade
            and p.idproduto = lt.idproduto
            and a.idarmazem = ll.idarmazem
          group by lt.idlote, ll.idarmazem, a.codigointerno, a.descr,
                   lt.iddepositante, ed.codigointerno, ed.razaosocial,
                   lt.idproduto, p.codigointerno, p.descr, lt.estado) est
/

