create view VT_LOTEVOLUMES as
select ll.idpalet h$idpalet, ll.idlote volume, ll.dtentrada "Entrou Em", ll.qtdeentrada "Qtde Entrada",
       en.razaosocial "Depositante", pl.codigointerno "Código do Produto", el.barra "Barra", pl.descr "Produto",
       ol.idlotenf "Ordem de Recebimento", 
       decode(ll.estado, 'N', 'BOM', 'T', 'TRUNCADO', 'D', 'DANIFICADO') "Estado",
       ll.dtalocacao "Alocado Em", ll.idarmazem
  from lote ll, orlote ol, entidade en, produto pl, embalagem el
 where ol.idlote = ll.idlote
   and en.identidade = ll.iddepositante
   and pl.idproduto = ll.idproduto
   and el.idproduto = ll.idproduto
   and el.barra = ll.barra
   and ll.tipolote = 'V'
/

