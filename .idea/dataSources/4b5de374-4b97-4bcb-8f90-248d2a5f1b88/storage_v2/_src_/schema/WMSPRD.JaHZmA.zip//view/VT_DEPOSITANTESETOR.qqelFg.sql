create view VT_DEPOSITANTESETOR as
select decode(sd.idsetor, null, 0, 1) marcado, s.descr setor, s.ativo,
       s.idsetor, s.identidade iddepositante
  from (select s.idsetor, s.descr, e.identidade, e.ativo
           from setor s, depositante d, entidade e
          where e.identidade = d.identidade) s, setordepositante sd
 where sd.iddepositante(+) = s.identidade
   and sd.idsetor(+) = s.idsetor
/

