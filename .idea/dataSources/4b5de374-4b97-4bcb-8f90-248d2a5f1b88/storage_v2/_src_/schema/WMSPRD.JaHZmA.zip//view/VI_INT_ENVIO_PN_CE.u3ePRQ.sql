create view VI_INT_ENVIO_PN_CE as
select agrupador id, filetype, packingnumber, receivingtype, receivingnumber,
       sku, lotnumber,  LPAD(trunc(quantity), 9, '0') || LPAD((MOD(quantity, 1) * 1000), 3, '0') quantity, locationtype, rejectedtype
  from int_envio_pn_ce

/

