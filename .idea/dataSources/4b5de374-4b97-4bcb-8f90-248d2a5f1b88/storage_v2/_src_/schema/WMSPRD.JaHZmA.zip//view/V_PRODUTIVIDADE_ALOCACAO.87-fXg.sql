create view V_PRODUTIVIDADE_ALOCACAO as
select data, anomes, idusuario, usuario, nomeusuario, atividade, depositante,
       setor, regiao, pk_utilities.retornarTempo(tempogasto) tempogasto,
       qtdeitens, qtdeunidades, round(qtdevolumes, 6) qtdevolumes,
       round(pesokg, 4) pesokg, qtdeatividade
  from (select a.data, a.anomes, a.idusuario, a.usuario, a.nomeusuario,
                a.atividade, a.depositante, a.setor, a.regiao,
                sum(a.tempogasto) tempogasto, sum(a.qtdeitens) qtdeitens,
                sum(a.qtdeunidades) qtdeunidades,
                sum(a.qtdevolumes) qtdevolumes, sum(a.pesokg) pesokg,
                sum(a.qtdeatividade) qtdeatividade
           from (select ol.idlotenf, trunc(m.dataalocacao) data,
                         to_char(m.dataalocacao, 'yyyy/mm') anomes, m.idusuario,
                         u.nomeusuario usuario,
                         u.nomeusuariocompleto nomeusuario, 'ALOCAÇÃO' atividade,
                         edep.razaosocial depositante, s.descr setor,
                         r.descr regiao, min(m.dataalocacao) horainicio,
                         max(m.dataalocacao) horafim,
                         (max(m.dataalocacao) - min(m.dataalocacao)) * 86400 tempogasto,
                         count(distinct l.idproduto) qtdeitens,
                         sum(l.qtdeentrada * e.fatorconversao) qtdeunidades,
                         sum((l.qtdeentrada * e.fatorconversao) /
                              pk_produto.getFatorEmbCompra(l.idproduto)) qtdevolumes,
                         sum(l.qtdeentrada * e.pesobruto) / 1000 pesokg,
                         count(distinct m.idalocacao) qtdeatividade
                    from orlote ol, mapaalocacao m, usuario u, lote l,
                         embalagem e, local lo, setor s, regiaoarmazenagem r,
                         entidade edep
                   where m.idlote = ol.idlote
                     and decode(m.status, 'F', 1, 0) = 1
                     and m.alocado = 1
                     and u.idusuario = m.idusuarioalocacao
                     and l.idlote = m.idlote
                     and e.idproduto = l.idproduto
                     and e.barra = l.barra
                     and lo.idarmazem = m.idarmazem
                     and lo.idlocal = m.idlocal
                     and s.idsetor(+) = lo.idsetor
                     and r.idregiao(+) = lo.idregiao
                     and edep.identidade(+) = l.iddepositante
                   group by ol.idlotenf, trunc(m.dataalocacao),
                            to_char(m.dataalocacao, 'yyyy/mm'), m.idusuario,
                            u.nomeusuario, u.nomeusuariocompleto, s.descr,
                            r.descr, edep.razaosocial) a
          group by a.data, a.anomes, a.idusuario, a.usuario, a.nomeusuario,
                   a.atividade, a.setor, a.regiao, a.depositante)
 order by data, nomeusuario
/

