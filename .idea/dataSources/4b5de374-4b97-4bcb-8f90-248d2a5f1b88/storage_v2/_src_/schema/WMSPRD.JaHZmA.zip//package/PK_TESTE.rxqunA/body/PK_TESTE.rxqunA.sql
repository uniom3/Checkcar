create package body pk_teste is
procedure criarNotaFiscal is
  r_configIntegracao               configuracaointegracao%rowtype;
  v_parametrizado                  number;
  v_depositanteConfig              entidade.identidade%type;
  v_numPedido                      notafiscal.numpedidofornecedor%type;
  v_cnpjDepositante                varchar2(30);
  v_cnpjDestinatarioEntrega        varchar2(30);
  v_cnpjEmitente                   varchar2(30);
  r_transferencia                  ordemtransferencia%rowtype;
  v_razaoSocialDestinatarioEntrega entidade.razaosocial%type;
  v_codigoInterno                  entidade.codigointerno%type;
  v_logradouroDest                 endereco.logradouro%type;
  v_bairroDest                             bairro.descr%type;
  v_cepDest                                endereco.cep%type;
  v_cidadeDest     cidade.descr%type;
  v_ufDest         bairro.uf%type;
  v_numItens number;
begin
  select count(1)
    into v_parametrizado
    from depositante dep
   where dep.identidade = r_transferencia.iddepositante
     and dep.utilizaordemtransferencia = 1
     and dep.gerarpedidoimportacaotdn = 1;

  if (v_parametrizado = 0) then
    return;
  end if;

  --  r_configIntegracao := pk_integracao.getConfiguracaoIntegracao(r_transferencia.iddepositante, r_transferencia.idarmazem);

  -- O Número da nota fiscal será o número do TDN enviado no XML;
  v_numPedido := r_transferencia.numeroordemtransferencia;

  -- O Depositante da nota fiscal o depositante da configuração de integração;
  select ent.cgc
    into v_cnpjDepositante
    from entidade ent
   where ent.identidade = r_configIntegracao.Identidade;

  -- O Emitente da nota fiscal será o fornecedor enviado no XML;
  select ent.cgc
    into v_cnpjEmitente
    from entidade ent
   where ent.identidade = r_transferencia.idremetente;

  --  O Destinatário e Entrega da nota fiscal será o armazém da configuração de integração;
  select ent.cgc, ent.razaosocial, ent.codigointerno
    into v_cnpjDestinatarioEntrega, v_razaoSocialDestinatarioEntrega,
         v_codigoInterno
    from entidade ent
   where ent.identidade = r_configIntegracao.Idarmazem;

   select endereco.logradouro, bairro.descr, endereco.cep, cidade.descr, bairro.uf
     into v_logradouroDest, v_bairroDest  ,           v_cepDest     ,           v_cidadeDest  ,           v_ufDest           
     from ( select * 
              from endereco end
             where end.identidade = r_configIntegracao.Idarmazem
            order by end.enderecofiscal desc) endereco, bairro, cidade
   where bairro.idcidade = endereco.idcidade
    and cidade.idcidade = bairro.idcidade
    and rownum = 1;

    select count(1)
      into v_numItens
      from ordemtransferenciaitem ot
     where ot.idordemtransferencia = r_transferencia.idordemtransferencia;

  /*
  Deverá realizar o vínculo entre o item do pedido gerado e o item da ordem de transferência caso o parâmetro "Associa NF à Ordem de Transferência automaticamente" existente estiver ativo após cadastrar a nota fiscal a partir do TDN.
  */

  insert into int_pedido
  (numpedido, cnpj_depositante, codigointerno, cnpj_emitente, tipo,
   descroper, data_emissao, pessoa_dest, codigo_dest, nome_dest, cnpj_dest,
   endereco_dest, bairro_dest, cep_dest, cidade_dest, estado_dest,
   vlrprodutos, vlrtotal, ciffob, pesoliquido, num_itens, tiponf,
   cnpj_entrega)
values
  (v_numPedido, pk_entidade.formatCNPJCPF(v_cnpjDepositante), v_numPedido,
   pk_entidade.formatCNPJCPF(v_cnpjEmitente), 'E',
   'Pedido criado a partir do TDN ' ||
    r_transferencia.numeroordemtransferencia,
   nvl(to_char(to_date(r_transferencia.dataintegracao, 'rrrrMMdd'),
                'dd/mm/rrrr'), sysdate), 'J', v_codigoInterno,
   v_razaoSocialDestinatarioEntrega,
   pk_entidade.formatCNPJCPF(v_cnpjDestinatarioEntrega), v_logradouroDest,
   v_bairroDest, v_cepDest, v_cidadeDest, v_ufDest, 0, 0, '1', 0, v_numItens,
   'N', pk_entidade.formatCNPJCPF(v_cnpjDestinatarioEntrega));


end criarNotaFiscal;

end pk_teste;
/

