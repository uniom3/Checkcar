create view V_ENTIDADE as
select e.identidade, e.razaosocial, e.pessoa, e.fantasia, e.codigointerno,
       decode(e.pessoa, 'J', e.cgc, e.cic) cnpj, e.inscrestadual,
       e.inscrmunicipal, v.tipologr, v.logradouro, v.numero, v.complemento,
       v.bairro, v.cep, v.cidade, v.uf,
       pk_entidade.f_ret_telefone(e.identidade) telefone,
       v.endereco endereco_concat, e.datacadastro, e.dataultatualizacao,
       v.complendereco, v.codmunicipio, e.codigosorter, e.sigla,
       v.codendereco
  from entidade e, v_endereco v
 where v.identidade(+) = e.identidade
   and v.idendereco(+) = pk_entidade.f_ret_idendereco(e.identidade)
/

