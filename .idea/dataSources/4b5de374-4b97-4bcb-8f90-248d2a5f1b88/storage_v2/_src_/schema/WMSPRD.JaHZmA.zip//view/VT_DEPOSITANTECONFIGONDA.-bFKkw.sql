create view VT_DEPOSITANTECONFIGONDA as
select identidade, depositante, cgc, cic, inscrestadual, pessoa
  from vb_depositante
/

