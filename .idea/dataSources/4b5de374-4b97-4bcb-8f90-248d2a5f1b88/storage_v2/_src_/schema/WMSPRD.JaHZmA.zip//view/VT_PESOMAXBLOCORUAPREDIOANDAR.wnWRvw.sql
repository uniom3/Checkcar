create view VT_PESOMAXBLOCORUAPREDIOANDAR as
select pmba.id h$id, pmba.idarmazem h$idarmazem, pmba.bloco, pmba.rua,
       pmba.predio, pmba.andar, pmba.pesomaximo
  from pesomaxblruapredioandar pmba
 order by pmba.bloco, pmba.rua, pmba.predio, pmba.andar
/

