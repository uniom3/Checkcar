create view VT_ITEMORDEMSEPARACAO as
select osi.idordemsepitem, pro.idproduto, pro.codigointerno codigoproduto,
       pro.codreferencia, pro.descr produto, tip.descr tipo,
       sti.descr subtipo, fam.razaosocial familia, osi.qtdeitem,
       osi.itemtype,
       decode(osi.mensagempresente, 'null', null, osi.mensagempresente) mensagempresente,
       osi.itemid, ose.idordemseparacao, osi.customerorderitemid,
       osi.customerorderitemdetailid, nfi.codigointerno notafiscal,
       CASE
          WHEN osi.giftwrapid = 'null' THEN
           0
          WHEN osi.giftwrapid is null THEN
           0
          ELSE
           1
        END giftwrapid, osi.position posicaoenvio, osi.valinfoespecifica
  from ordemseparacao ose, ordemseparacaoitem osi, produto pro,
       notafiscal nfi, tipoproduto tip, subtipoproduto sti, entidade fam
 where ose.idordemseparacao = osi.idordemsep
   and osi.idproduto = pro.idproduto
   and ose.idnotafiscal = nfi.idnotafiscal(+)
   and tip.idtipo = pro.idtipo
   and sti.idtipo = pro.idtipo
   and sti.idsubtipo = pro.idsubtipo
   and fam.identidade = pro.idfamilia
   and osi.idordemsep in (select idselecionado
                            from gtt_selecao)
 order by ose.idordemseparacao, osi.sequencia
/

