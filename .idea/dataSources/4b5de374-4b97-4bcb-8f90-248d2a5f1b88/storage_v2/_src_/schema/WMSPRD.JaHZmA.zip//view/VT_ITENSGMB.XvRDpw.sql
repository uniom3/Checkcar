create view VT_ITENSGMB as
select h$tableid, notafiscal numero, codproduto, produto, barra, qtde,
       qtdeatendida, qtdefaturada, embalagem, fatorconversao, valorunitbruto,
       percentualdesconto, valorunitliquido, valortotalbruto, valordesconto,
       valortotalliquido, apresentacao, classificacaofiscal, csticms, bcicms,
       icms, aliqicms, ipi, aliqipi, idproduto, idnfdet, idnotafiscal id,
       numeroordemcompra, margemtolerancia
  from vt_itensnotafiscal
/

