create package pk_separacaoespecifica is

  C_SEP_ESPEC_ENTERPRISE constant number := 0;
  C_SEP_ESPEC_COLETOR    constant number := 1;
  C_SEP_ESPEC_WMSWEB     constant number := 2;

  procedure vincularSeparacaoEspecifica
  (
    p_idarmazem      in number,
    p_idlocal        in local.idlocal%type,
    p_idlote         in number,
    p_idnotafiscal   in number,
    p_qtde           in number,
    p_idUsuario      in number,
    p_fonteSeparacao in number := C_SEP_ESPEC_ENTERPRISE,
    p_cadManual      in char := 'S'
  );

  procedure desvincularSeparacaoEspecifica
  (
    p_idarmazem            in number,
    p_idlocal              in local.idlocal%type,
    p_idlote               in number,
    p_idnotafiscal         in number,
    p_idUsuario            in number,
    p_validarOriginario    in number := 1,
    p_cancelamentoexclusao in number := 0
  );

  /*
   * Rotina responsavel por gerar a separacao especifica dos lotes 
   * na importacao do produto sem tipo material
  */
  procedure GerarSepEspecificaImportacao
  (
    p_idusuario     in number,
    p_barra         in varchar2,
    p_serie         in varchar2,
    p_idprenf       in number,
    p_idnfdet       in number,
    p_dval          in date,
    p_qtde          in number,
    p_idnfdetrastro in number := null
  );

  /*
   * Rotina responsavel por gerar a separacao especifica dos lotes 
   * na importacao do produto é enviado o id do lote
  */
  procedure GerarSepEspecificaImpIDLote(p_prenfdet in t_prenfdet);

  procedure vincLoteIndSepEspecifica
  (
    p_idusuario      in number,
    p_idnfdet        in number,
    p_loteindustria  in varchar2,
    p_qtde           in out number,
    p_dataVencimento in date := null,
    p_idnfcobertura  in coberturalotedispnf.idnotafiscalcobertura%type := null,
    p_idLote         in number := null,
    p_fonteSeparacao in number := C_SEP_ESPEC_ENTERPRISE
  );

  procedure desvincLoteIndSepEspecifica
  (
    p_idusuario            in number,
    p_idnfdet              in number,
    p_loteindustria        in varchar2,
    p_cancelamentoexclusao in number := 0
  );

  procedure validarNFparaSepEspecifica(p_idnotafiscal in number);

  /*
   * Rotina responsavel por gerar a separacao especifica dos lotes 
   * na importacao do produto com tipo de material
  */
  procedure GerarSepEspecificaImpTipo
  (
    p_idusuario      in number,
    p_barra          in varchar,
    p_valorInfoEspec in varchar2,
    p_idprenf        in number,
    p_tipomaterial   in number,
    p_qtde           in number,
    p_cadManual      in char := 'S'
  );

  function isNotaComRastro(p_idnotafiscal in number) return number;
  function isNotaComRastroLoteIndustria(p_idnfdet in number) return number;

  procedure ajustaSepEspecifica
  (
    p_idNotaFiscal number,
    p_idlote       number
  );

  procedure desvincLoteIndSepEspecificaCob
  (
    p_idusuario            in number,
    p_idnfdet              in number,
    p_loteindustria        in varchar2,
    p_idnfcobertura        in number,
    p_cancelamentoexclusao in number := 0
  );

  procedure vincLoteIndSepPedWeb
  (
    p_idusuario      in number,
    p_idnfdet        in number,
    p_loteindustria  in varchar2,
    p_qtde           in out number,
    p_dataVencimento in date := null,
    p_idLote         in number := null
  );

  procedure desvincPorNF
  (
    p_idnotafiscal         in number,
    p_idusuario            in number,
    p_cancelamentoexclusao in number := 0
  );

  procedure desvincPorLote
  (
    p_idLote               in number,
    p_idusuario            in number,
    p_cancelamentoexclusao in number := 0
  );
end pk_separacaoespecifica;
/

