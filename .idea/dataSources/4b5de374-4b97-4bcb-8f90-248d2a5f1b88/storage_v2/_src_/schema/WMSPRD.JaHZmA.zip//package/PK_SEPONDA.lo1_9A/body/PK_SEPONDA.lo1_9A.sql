create package body PK_SEPONDA is

  SEPARACAO_SEM_REAB constant number := 0;
  SEPARACAO_COM_REAB constant number := 1;

  -- Retorna se a separação manual deve separar a origem 
  function isSepararOrigem
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_idusuario            in number,
    p_mensagem             in out varchar2,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
  ) return boolean is
    v_isInicio    number;
    v_idusuario   number;
    v_nomeUsuario usuario.nomeusuario%type;
    v_msg         t_message;
  begin
  
    for c in (select distinct m.idlocalorigem idEnderecoOrigem, m.idlote
                from movimentacao m, local lo, local ld, lotelocal ll
               where m.idonda = p_idonda
                 and m.identificador = p_identificador
                 and m.idnotafiscal =
                     decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
                 and m.status in (0, 1)
                 and round(m.qtdemovimentada, 6) <>
                     round(m.qtdeconferida, 6)
                 and lo.id = m.idlocalorigem
                 and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                 and lo.idregiao = p_idRegiaoOrigem
                 and ld.id = m.idlocaldestino
                 and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                 and ld.idregiao = p_idRegiaoDestino
                 and ll.idlote = m.idlote
                 and ll.idendereco = m.idlocalorigem
                 and m.qtdemovimentada > ll.estoque)
    loop
      validaReabPendente(p_idOnda, c.idlote, c.idEnderecoOrigem);
    end loop;
  
    begin
      select nvl(count(*), 0), m.idusuario, u.nomeusuario
        into v_isInicio, v_idusuario, v_nomeUsuario
        from movimentacao m, local lo, local ld, usuario u
       where m.idonda = p_idonda
         and m.identificador = p_identificador
         and m.idnotafiscal =
             decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
         and m.status in (0, 1)
         and round(m.qtdemovimentada, 6) <> round(m.qtdeconferida, 6)
         and lo.id = m.idlocalorigem
         and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
         and lo.idregiao = p_idRegiaoOrigem
         and lo.bufferesteira = p_bufferEsteiraOrigem
         and ld.id = m.idlocaldestino
         and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
         and ld.idregiao = p_idRegiaoDestino
         and u.idusuario(+) = m.idusuario
         and ld.bufferesteira = p_bufferEsteiraDestino
       group by m.idusuario, u.nomeusuario
      union all
      select nvl(count(*), 0), r.idusuarioinicio, '' nomeusuario
        from remanejamento r, remanejamentoromaneio rr, local lo, local ld,
             regiaoarmazenagem rd
       where rr.idremanejamento = r.idremanejamento
         and rr.idromaneio = p_idonda
         and r.idlocalorigem = lo.idlocal
         and r.idlocaldestino = ld.idlocal
         and r.status in ('A')
         and decode(lo.buffer, 'N', 0, 1) = p_bufferOrigem
         and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
         and rd.idregiao = ld.idregiao
         and r.planejado = 'S'
         and rd.tipo in (0)
         and lo.idregiao = p_idRegiaoOrigem
         and lo.bufferesteira = p_bufferEsteiraOrigem
         and ld.idregiao = p_idRegiaoDestino
         and ld.bufferesteira = p_bufferEsteiraDestino
      
       group by r.idusuarioinicio;
    
      if (v_idusuario <> p_idusuario) then
        p_mensagem := 'Esta separação ja foi iniciada pelo usuario ' ||
                      v_nomeUsuario || ' (id ' || v_idusuario ||
                      '). Operação cancelada.';
        return false;
      end if;
    
    exception
      when no_data_found then
        v_isInicio := 0;
      when others then
        v_msg := t_message('A separação desta região possui mais de um usuário vinculado. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_isInicio > 0) then
      return true;
    else
      return false;
    end if;
  
  end isSepararOrigem;

  -- Retorna se dever separar o destino 
  function isSepararDestino
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_idusuario            in number,
    p_mensagem             in out varchar2,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
    
  ) return boolean is
    v_isFim               number;
    v_idusuario           number;
    v_nomeUsuario         usuario.nomeusuario%type;
    v_msg                 t_message;
    v_qtdeReabastecimento number;
  begin
    begin
      for c in (select distinct m.idlocalorigem idenderecoorigem, m.idlote
                  from movimentacao m, local lo, local ld, lotelocal ll
                 where m.idonda = p_idonda
                   and m.identificador = p_identificador
                   and m.idnotafiscal =
                       decode(p_idNotaFiscal, 0, m.idnotafiscal,
                              p_idnotaFiscal)
                   and m.status = 1
                   and round(m.qtdemovimentada, 6) =
                       round(m.qtdeconferida, 6)
                   and lo.id = m.idlocalorigem
                   and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                   and lo.idregiao = p_idRegiaoOrigem
                   and ld.id = m.idlocaldestino
                   and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                   and ld.idregiao = p_idRegiaoDestino
                   and m.datatermino is null
                   and ll.idlote = m.idlote
                   and ll.idendereco = m.idlocalorigem
                   and ll.estoque < m.qtdemovimentada
                union all
                select distinct lo.id idEnderecoOrigem, lr.idlote
                  from remanejamento r, remanejamentoromaneio rr, local lo,
                       local ld, regiaoarmazenagem rd, loteremanejamento lr
                 where rr.idremanejamento = r.idremanejamento
                   and rr.idromaneio = p_idonda
                   and r.idlocalorigem = lo.idlocal
                   and r.idlocaldestino = ld.idlocal
                   and r.status in ('A', 'G', 'Z')
                   and decode(lo.buffer, 'N', 0, 1) = p_bufferOrigem
                   and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
                   and rd.idregiao = ld.idregiao
                   and r.planejado = 'S'
                   and rd.tipo in (0, 1)
                   and lo.idregiao = p_idRegiaoOrigem
                   and ld.idregiao = p_idRegiaoDestino
                   and lr.idremanejamento = r.idremanejamento)
      loop
        validaReabPendente(p_idOnda, c.idlote, c.idEnderecoOrigem);
      end loop;
    
      select nvl(count(*), 0), m.idusuario, u.nomeusuario
        into v_isFim, v_idusuario, v_nomeUsuario
        from movimentacao m, local lo, local ld, usuario u
       where m.idonda = p_idonda
         and m.identificador = p_identificador
         and m.idnotafiscal =
             decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
         and m.status = 1
         and round(m.qtdemovimentada, 6) = round(m.qtdeconferida, 6)
         and lo.id = m.idlocalorigem
         and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
         and lo.idregiao = p_idRegiaoOrigem
         and lo.bufferesteira = p_bufferEsteiraOrigem
         and ld.id = m.idlocaldestino
         and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
         and ld.idregiao = p_idRegiaoDestino
         and ld.bufferesteira = p_bufferEsteiraDestino
         and m.datatermino is null
         and u.idusuario = m.idusuario
       group by m.idusuario, u.nomeusuario
      union all
      select nvl(count(*), 0), r.idusuarioinicio, '' nomeusuario
        from remanejamento r, remanejamentoromaneio rr, local lo, local ld,
             regiaoarmazenagem rd
       where rr.idremanejamento = r.idremanejamento
         and rr.idromaneio = p_idonda
         and r.idlocalorigem = lo.idlocal
         and r.idlocaldestino = ld.idlocal
         and r.status in ('A', 'G', 'Z')
         and decode(lo.buffer, 'N', 0, 1) = p_bufferOrigem
         and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
         and rd.idregiao = ld.idregiao
         and r.planejado = 'S'
         and rd.tipo in (0, 1)
         and lo.idregiao = p_idRegiaoOrigem
         and lo.bufferesteira = p_bufferEsteiraOrigem
         and ld.idregiao = p_idRegiaoDestino
         and ld.bufferesteira = p_bufferEsteiraDestino
       group by r.idusuarioinicio;
    
      if (v_idusuario <> p_idusuario) then
        p_mensagem := 'Esta separação ja foi iniciada pelo usuario ' ||
                      v_nomeUsuario || ' (id ' || v_idusuario ||
                      '). Operação cancelada.';
      end if;
    exception
      when no_data_found then
        v_isFim := 0;
      when others then
      
        select count(*)
          into v_qtdeReabastecimento
          from remanejamento r, remanejamentoromaneio rr, local lo, local ld,
               regiaoarmazenagem rd
         where rr.idremanejamento = r.idremanejamento
           and rr.idromaneio = p_idonda
           and r.idlocalorigem = lo.idlocal
           and r.idlocaldestino = ld.idlocal
           and r.status in ('A', 'G', 'Z')
           and decode(lo.buffer, 'N', 0, 1) = p_bufferOrigem
           and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
           and rd.idregiao = ld.idregiao
           and r.planejado = 'S'
           and rd.tipo in (0, 1)
           and lo.idregiao = p_idRegiaoOrigem
           and lo.bufferesteira = p_bufferEsteiraOrigem
           and ld.idregiao = p_idRegiaoDestino
           and ld.bufferesteira = p_bufferEsteiraDestino;
      
        if (v_qtdeReabastecimento > 0) then
          v_msg := t_message('Existe reabastecimento pendente para a onda id: {0}. Operação cancelada.');
          v_msg.addParam(p_idonda);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        v_msg := t_message('A separação desta região possui mais de um usuário vinculado. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    if (v_isFim > 0) then
      return true;
    else
      return false;
    end if;
  end isSepararDestino;

  function getReabPendentePorLocal
  (
    p_idonda          in number,
    p_identificador   in number,
    p_idnotafiscal    in number,
    p_idendereco      in number,
    p_idregiaoorigem  in number,
    p_bufferorigem    in number,
    p_idregiaodestino in number,
    p_bufferdestino   in number
  ) return number is
  begin
    for c_reab in (select distinct lt.idlote
                     from movimentacao v, lotelocal ll, lote lt, local lo,
                          local ld
                    where 1 = 1
                      and v.idonda = p_idonda
                      and v.identificador = p_identificador
                      and v.idlocalorigem = p_idendereco
                      and v.status = 0
                      and v.idnotafiscal =
                          nvl(p_idnotafiscal, v.idnotafiscal)
                      and lt.idlote = v.idlote
                      and ll.idendereco = v.idlocalorigem
                      and ll.idlote = lt.idlote
                      and ll.estoque < v.qtdemovimentada
                      and lo.id = v.idlocalorigem
                      and ld.id = v.idlocaldestino
                      and lo.idregiao = p_idregiaoorigem
                      and decode(lo.buffer, 'S', 1, 0) = p_bufferorigem
                      and ld.idregiao = p_idregiaodestino
                      and decode(ld.buffer, 'S', 1, 0) = p_bufferdestino
                    order by v.idlocalorigem)
    loop
      validaReabPendente(p_idOnda, c_reab.idlote, p_idendereco);
    end loop;
  
    if (sql%rowcount > 0) then
      return SEPARACAO_COM_REAB;
    else
      return SEPARACAO_SEM_REAB;
    end if;
  
  end;

  -- Alimenta a gtt_reabpendente caso o estoque a ser movido dependa de alguma operação de remanejamento ou onda 
  procedure validaReabPendente
  (
    p_idOnda     in number,
    p_idlote     in number,
    p_idEndereco in number
  ) is
  begin
    insert into gtt_reabpendente
      select lt.idproduto, l.id idendereco, r.idremanejamento, 0 idonda,
             0 idmovimentacao
        from loteremanejamento lr, remanejamento r, lote lt, local l
       where lr.idlote = p_idlote
         and lr.idremanejamento = r.idremanejamento
         and r.status <> 'F'
         and lr.idlote = lt.idlote
         and l.idarmazem = r.idarmazemdestino
         and l.idlocal = r.idlocaldestino
         and l.id = p_idEndereco;
  
    insert into gtt_reabpendente
      select lt.idproduto, p_idEndereco idendereco, 0 idremanejamento,
             m.idonda idonda, m.id idmovimentacao
        from movimentacao m, lote lt
       where m.idlocaldestino = p_idEndereco
         and m.status in (0, 1)
         and m.idlote = p_idlote
         and m.idonda <> p_idonda
         and lt.idlote = m.idlote;
  
  end validaReabPendente;

  function isCheckOutExpress
  (
    p_idOnda          in number,
    p_idRegiaoDestino in number
  ) return boolean is
    v_tipodestino            regiaoarmazenagem.tipo%type;
    v_confporcheckoutexpress number;
  begin
    select r.tipo
      into v_tipodestino
      from regiaoarmazenagem r
     where r.idregiao = p_idRegiaoDestino;
  
    select co.conferenciaporcheckoutexpress
      into v_confporcheckoutexpress
      from configuracaoonda co, romaneiopai rp
     where rp.idromaneio = p_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (v_tipodestino = 6 and v_confporcheckoutexpress = 1) then
      return true;
    else
      return false;
    end if;
  end;

  -- Refactored procedure validarCaixaSeparacao 
  procedure validarCaixaSeparacao
  (
    p_idCaixaSeparacao in number,
    p_mensagem         in out varchar2,
    v_caixaseparacao   in out caixaseparacao%rowtype
  ) is
  begin
    if (p_idCaixaSeparacao is null or p_idCaixaSeparacao = 0) then
      p_mensagem := 'A separação desta região é para CheckOut Express, portanto um caixa de separação deve ser informada .';
      return;
    end if;
  
    begin
      select *
        into v_caixaseparacao
        from caixaseparacao cs
       where cs.tipo = 2
         and cs.idcaixaseparacao = p_idCaixaSeparacao;
    exception
      when no_data_found then
        p_mensagem := 'Caixa de Separação não encontrada. Operação Cancelada.';
        return;
    end;
  end validarCaixaSeparacao;

  -- Refactored procedure validarCaixaIniciada 
  procedure validarCaixaIniciada
  (
    p_idOnda           in number,
    p_identificador    in number,
    p_bufferOrigem     in number,
    p_idRegiaoOrigem   in number,
    p_bufferDestino    in number,
    p_idRegiaoDestino  in number,
    p_idCaixaSeparacao in number,
    p_mensagem         in out varchar2,
    p_idcaixa          in out number
  ) is
    v_descrcaixa caixaseparacao.descricao%type;
  begin
    begin
      select cs.idcaixaseparacao, cs.descricao
        into p_idcaixa, v_descrcaixa
        from caixaseparacao cs
       where cs.tipo = 2
         and cs.liberado = 0
         and exists
       (select 1
                from conteudocarrinho c, movimentacao m, local lo, local ld,
                     regiaoarmazenagem ro, regiaoarmazenagem rd
               where m.id = c.idmovimentacao
                 and m.status in (0, 1)
                 and lo.id = m.idlocalorigem
                 and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                 and ld.id = m.idlocaldestino
                 and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                 and ro.idregiao = lo.idregiao
                 and rd.idregiao = ld.idregiao
                 and m.idonda = p_idOnda
                 and ro.idregiao = p_idRegiaoOrigem
                 and rd.idregiao = p_idRegiaoDestino
                 and m.identificador = p_identificador
                 and c.idcaixaseparacao = cs.idcaixaseparacao
                 and c.carrinhocheio = 'N');
    
      if (p_idcaixa <> p_idCaixaSeparacao) then
        p_mensagem := 'Esta separação ja foi iniciada com a caixa separação ' ||
                      v_descrcaixa || ' (id ' || p_idcaixa ||
                      '). Operação cancelada.';
        return;
      end if;
    exception
      when no_data_found then
        p_idcaixa := null;
    end;
  end validarCaixaIniciada;

  procedure verificarSeparacaoRem
  (
    p_idRegiaoOrigem       in number,
    p_idRegiaoDestino      in number,
    p_idOnda               in number,
    p_idUsuario            in number,
    p_tipoSeparacao        in number,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
  ) is
    C_ORIGEM constant number := 0;
  begin
  
    -- Este for realiza origem ou destino do remanejamento
    -- quando o fluxo estiver sendo realizado pela tela
    -- Separação Manual baseado na p_tipoSeparacao
    for r_rem in (select r.idremanejamento
                    from remanejamento r, remanejamentoromaneio rr, local lo,
                         local ld, setor s
                   where rr.idremanejamento = r.idremanejamento
                     and rr.idromaneio = p_idOnda
                     and (((p_tipoSeparacao = 0) and (r.status = 'A')) or
                         ((p_tipoSeparacao = 1) and
                         ((r.status = 'G') or (r.status = 'Z'))))
                     and r.planejado = 'S'
                     and s.idsetor = ld.idsetor
                     and s.codintegracaoesteira is not null
                     and lo.idarmazem = r.idarmazemorigem
                     and lo.idlocal = r.idlocalorigem
                     and lo.idregiao = p_idRegiaoOrigem
                     and lo.bufferesteira = p_bufferEsteiraOrigem
                     and lo.buffer = 'S'
                     and ld.idarmazem = r.idarmazemdestino
                     and ld.idlocal = r.idlocaldestino
                     and ld.idregiao = p_idRegiaoDestino
                     and ld.bufferesteira = p_bufferEsteiraDestino)
    loop
    
      if (p_tipoSeparacao = C_ORIGEM) then
        update loteremanejamento lre
           set conferido = 'S'
         where lre.idremanejamento = r_rem.idremanejamento;
      
        update remanejamento r
           set r.status          = 'G',
               r.idusuarioinicio = p_idUsuario,
               r.horafimorigem   = sysdate
         where r.idremanejamento = r_rem.idremanejamento;
      else
        pk_remanejamento.finalizarRemanejamento(r_rem.idremanejamento,
                                                p_idUsuario);
      end if;
    end loop;
  
    -- Este for realiza origem e destino do remanejamento
    -- de uma vez, quando os dados de destino da movimentacao
    -- condizem com os dados de origem do remanejamento
    for r_rem in (select distinct r.idremanejamento
                    from remanejamento r, remanejamentoromaneio rr, local lo,
                         local ld, setor s
                   where rr.idremanejamento = r.idremanejamento
                     and rr.idromaneio = p_idonda
                     and ((p_tipoSeparacao = 3) and (r.status = 'A'))
                     and r.planejado = 'S'
                     and s.idsetor = ld.idsetor
                     and s.codintegracaoesteira is not null
                     and lo.idarmazem = r.idarmazemorigem
                     and lo.idlocal = r.idlocalorigem
                     and lo.idregiao = p_idRegiaoDestino
                     and lo.bufferesteira = p_bufferEsteiraDestino
                     and lo.buffer = 'S')
    loop
      update loteremanejamento lre
         set conferido = 'S'
       where lre.idremanejamento = r_rem.idremanejamento;
    
      update remanejamento r
         set r.status          = 'G',
             r.idusuarioinicio = p_idUsuario,
             r.horafimorigem   = sysdate
       where r.idremanejamento = r_rem.idremanejamento;
    
      pk_remanejamento.finalizarRemanejamento(r_rem.idremanejamento,
                                              p_idUsuario);
    
    end loop;
  end verificarSeparacaoRem;

  -- Executa a separação da Origem 
  procedure separarOrigem
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_idCaixaSeparacao     in number,
    p_reabPendente         in out number,
    p_mensagem             in out varchar2,
    p_bufferesteiraorigem  in number,
    p_bufferesteiradestino in number
  ) is
    v_qtdeMovPendente number;
    v_idcaixa         number;
    v_caixaseparacao  caixaseparacao%rowtype;
  
  begin
    select nvl(count(*), 0)
      into v_qtdeMovPendente
      from movimentacao m
     where m.idonda = p_idonda
       and m.id not in
           (select m.id
              from movimentacao m, local lo, local ld
             where m.idonda = p_idonda
               and m.identificador = p_identificador
               and m.idnotafiscal =
                   decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
               and m.status in (0, 1)
               and round(m.qtdemovimentada, 6) <> round(m.qtdeconferida, 6)
               and lo.id = m.idlocalorigem
               and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
               and lo.idregiao = p_idRegiaoOrigem
               and ld.id = m.idlocaldestino
               and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
               and lo.bufferesteira = p_bufferesteiraorigem
               and ld.bufferesteira = p_bufferesteiradestino
               and ld.idregiao = p_idRegiaoDestino)
       and m.idlocaldestino in
           (select distinct lo.id
              from movimentacao m, local lo, local ld
             where m.idonda = p_idonda
               and m.identificador = p_identificador
               and m.idnotafiscal =
                   decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
               and m.status in (0, 1)
               and round(m.qtdemovimentada, 6) <> round(m.qtdeconferida, 6)
               and lo.id = m.idlocalorigem
               and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
               and lo.idregiao = p_idRegiaoOrigem
               and ld.id = m.idlocaldestino
               and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
               and lo.bufferesteira = p_bufferesteiraorigem
               and ld.bufferesteira = p_bufferesteiradestino
               and ld.idregiao = p_idRegiaoDestino)
       and m.status in (0, 1);
  
    if v_qtdeMovPendente > 0 then
      p_mensagem := 'Para executar esta separação é necessário executar primeiro as separações de etapa anterior.';
      return;
    end if;
  
    select nvl(count(*), 0)
      into p_reabPendente
      from gtt_reabpendente;
  
    if (p_reabPendente = 0) then
      if (isCheckOutExpress(p_idOnda, p_idRegiaoDestino)) then
      
        validarCaixaSeparacao(p_idCaixaSeparacao, p_mensagem,
                              v_caixaseparacao);
      
        validarCaixaIniciada(p_idOnda, p_identificador, p_bufferOrigem,
                             p_idRegiaoOrigem, p_bufferDestino,
                             p_idRegiaoDestino, p_idCaixaSeparacao,
                             p_mensagem, v_idcaixa);
      
        if (v_idcaixa is null) then
          if (v_caixaseparacao.liberado = 0) then
            p_mensagem := 'A Caixa de Separação ' ||
                          v_caixaseparacao.descricao || ' (id ' ||
                          v_caixaseparacao.idcaixaseparacao ||
                          ') não está liberada para uso. Operação cancelada.';
            return;
          end if;
        
          update caixaseparacao cx
             set cx.liberado     = 0,
                 cx.codigotarefa = p_idOnda
           where cx.idcaixaseparacao = v_caixaseparacao.idcaixaseparacao;
        end if;
      
        insert into conteudocarrinho
          (id, idmovimentacao, idusuario, qtde, idcaixaseparacao,
           carrinhocheio)
          select seq_conteudocarrinho.nextval, m.id, p_idUsuario,
                 m.qtdemovimentada - m.qtdeconferida,
                 v_caixaseparacao.idcaixaseparacao, 'N'
            from movimentacao m, local lo, local ld
           where m.idonda = p_idOnda
             and m.identificador = p_identificador
             and m.status in (0, 1)
             and round(m.qtdemovimentada, 6) <> round(m.qtdeconferida, 6)
             and lo.id = m.idlocalorigem
             and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
             and lo.idregiao = p_idRegiaoOrigem
             and ld.id = m.idlocaldestino
             and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
             and ld.idregiao = p_idRegiaoDestino;
      end if;
    
      update movimentacao m1
         set m1.status        = 1,
             m1.idusuario     = p_idUsuario,
             m1.qtdeconferida = round(m1.qtdemovimentada, 6),
             m1.datainicio    = decode(m1.datainicio, null, sysdate,
                                       m1.datainicio), --se a data de inicio ja foi gravada, é mantida
             m1.tiposeparacao = decode(m1.tiposeparacao, 0, 1,
                                       m1.tiposeparacao) --se o tipo de separação ja foi gravado, é mantido
       where exists
       (select 1
                from movimentacao m, local lo, local ld
               where m.idonda = p_idonda
                 and m.identificador = p_identificador
                 and m.idnotafiscal =
                     decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
                 and m.status in (0, 1)
                 and round(m.qtdemovimentada, 6) <>
                     round(m.qtdeconferida, 6)
                 and lo.id = m.idlocalorigem
                 and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                 and lo.idregiao = p_idRegiaoOrigem
                 and ld.id = m.idlocaldestino
                 and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                 and ld.idregiao = p_idRegiaoDestino
                 and lo.bufferesteira = p_bufferesteiraorigem
                 and ld.bufferesteira = p_bufferesteiradestino
                 and m.idlote is not null
                 and m.id = m1.id);
    
      update romaneiopai r
         set r.statusonda = 4 -- Onda em execução
       where r.idromaneio = p_idOnda;
    end if;
  
    verificarSeparacaoRem(p_idRegiaoOrigem, p_idRegiaoDestino, p_idOnda,
                          p_idusuario, 0, p_bufferOrigem, p_bufferDestino);
  
  end;

  -- Refactored procedure separarDestino 
  procedure separarDestino
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_validaSepDestino     in boolean,
    p_idCaixaSeparacao     in number,
    p_reabPendente         in out number,
    p_mensagem             in out varchar2,
    p_bufferEsteiraOrigem  in number,
    p_bufferEsteiraDestino in number
  ) is
    v_isSepararDestino    boolean;
    v_tipodestino         regiaoarmazenagem.tipo%type;
    v_textoLocalSeparacao varchar2(100);
    v_idcaixa             number;
    v_caixaseparacao      caixaseparacao%rowtype;
  begin
    if (p_validaSepDestino) then
      v_isSepararDestino := isSepararDestino(p_idOnda, p_identificador,
                                             p_idnotaFiscal, p_bufferOrigem,
                                             p_idRegiaoOrigem,
                                             p_bufferDestino,
                                             p_idRegiaoDestino, p_idusuario,
                                             p_mensagem,
                                             p_bufferEsteiraOrigem,
                                             p_bufferEsteiraDestino);
    
      if (p_mensagem is not null) then
        return;
      end if;
    
      if (not v_isSepararDestino) then
        p_mensagem := 'Nenhuma movimentação pendente de separação.';
        return;
      end if;
    else
      v_isSepararDestino := true;
    end if;
  
    if (v_isSepararDestino) then
      select nvl(count(*), 0)
        into p_reabPendente
        from gtt_reabpendente;
    
      if (p_reabPendente = 0) then
      
        select r.tipo
          into v_tipodestino
          from regiaoarmazenagem r
         where r.idregiao = p_idRegiaoDestino;
      
        if (p_bufferDestino = 0 and v_tipodestino = 2) then
          update movimentacao m
             set m.datatermino = sysdate,
                 m.idusuario   = p_idusuario
           where m.id in
                 (select m.id
                    from movimentacao m, local lo, local ld
                   where m.idonda = p_idonda
                     and m.identificador = p_identificador
                     and m.idnotafiscal =
                         decode(p_idNotaFiscal, 0, m.idnotafiscal,
                                p_idnotaFiscal)
                     and m.status = 1
                     and round(m.qtdemovimentada, 6) =
                         round(m.qtdeconferida, 6)
                     and lo.id = m.idlocalorigem
                     and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                     and lo.idregiao = p_idRegiaoOrigem
                     and ld.id = m.idlocaldestino
                     and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                     and ld.idregiao = p_idRegiaoDestino
                     and m.datatermino is null);
        else
          select decode(p_bufferOrigem, 1, 'BUFFER DE ', '') ||
                  decode(r.tipo, 0, 'PICKING', 1, 'PULMAO', 2, 'COLMEIA', 3,
                         'DOCA', 4, 'AUDITORIA', 5, 'STAGE', 6, 'PACKING', 7,
                         'SERVICO', 'N/D')
            into v_textoLocalSeparacao
            from regiaoarmazenagem r
           where r.idregiao = p_idRegiaoOrigem;
        
          select v_textoLocalSeparacao || ' PARA ' ||
                  decode(p_bufferDestino, 1, 'BUFFER DE ', '') ||
                  decode(r.tipo, 0, 'PICKING', 1, 'PULMAO', 2, 'COLMEIA', 3,
                         'DOCA', 4, 'AUDITORIA', 5, 'STAGE', 6, 'PACKING', 7,
                         'SERVICO', 'N/D') ||
                  decode(p_identificador, 0, '',
                         '(IDENTIFICADOR ' || p_identificador || ')')
            into v_textoLocalSeparacao
            from regiaoarmazenagem r
           where r.idregiao = p_idRegiaoDestino;
        
          -- travando registros para evitar concorrência com separação do coletor
          update movimentacao m1
             set m1.id = m1.id
           where exists
           (select 1
                    from movimentacao m, local lo, local ld,
                         regiaoarmazenagem r
                   where m.idonda = p_idonda
                     and m.identificador = p_identificador
                     and m.idnotafiscal =
                         decode(p_idNotaFiscal, 0, m.idnotafiscal,
                                p_idnotaFiscal)
                     and m.status = 1
                     and round(m.qtdemovimentada, 6) =
                         round(m.qtdeconferida, 6)
                     and lo.id = m.idlocalorigem
                     and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                     and lo.idregiao = p_idRegiaoOrigem
                     and ld.id = m.idlocaldestino
                     and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                     and ld.idregiao = p_idRegiaoDestino
                     and m.datatermino is null
                     and r.idregiao = ld.idregiao
                     and m1.id = m.id);
        
          delete from gtt_picking_dinamico;
        
          for c in (select lo.idarmazem, lo.idlocal origem,
                           lo.tipo tipoOrigem, m.idlote, ld.idlocal destino,
                           ld.tipo tipodestino,
                           round(sum(m.qtdemovimentada), 6) qtdemovimentada,
                           round(sum((m.qtdemovimentada - m.quantidade)), 6) qtdeadicionar,
                           lt.idproduto, lt.iddepositante,
                           ld.buffer destinobuffer, s.codintegracaoesteira,
                           ld.bufferesteira, m.id
                      from movimentacao m, local lo, local ld,
                           regiaoarmazenagem r, lote lt, setor s
                     where m.idonda = p_idonda
                       and m.identificador = p_identificador
                       and m.idnotafiscal =
                           decode(p_idNotaFiscal, 0, m.idnotafiscal,
                                  p_idnotaFiscal)
                       and m.status = 1
                       and round(m.qtdemovimentada, 6) =
                           round(m.qtdeconferida, 6)
                       and lo.id = m.idlocalorigem
                       and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                       and lo.idregiao = p_idRegiaoOrigem
                       and ld.id = m.idlocaldestino
                       and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                       and ld.idregiao = p_idRegiaoDestino
                       and m.datatermino is null
                       and r.idregiao = ld.idregiao
                       and lt.idlote = m.idlote
                       and s.idsetor(+) = ld.idsetor
                       and lo.bufferesteira = p_bufferEsteiraOrigem
                       and ld.bufferesteira = p_bufferEsteiraDestino
                     group by lo.idarmazem, lo.idlocal, lo.tipo, m.idlote,
                              ld.idlocal, ld.tipo, lt.idproduto,
                              lt.iddepositante, ld.buffer,
                              s.codintegracaoesteira, ld.bufferesteira, m.id
                     order by lo.idarmazem, lo.idlocal, m.idlote)
          loop
            pk_estoque.retirar_pendencia(c.idarmazem, c.origem, c.idlote,
                                         c.qtdemovimentada, p_idusuario,
                                         'SEPARAÇÃO EXECUTADA, REMOVIDO PENDENCIA PARA SEPARAÇÃO DE ' ||
                                          v_textoLocalSeparacao ||
                                          ', IDMOVIMENTACAO:' || c.id ||
                                          ', IDONDA:' || p_idonda);
            pk_estoque.retirar_estoque(c.idarmazem, c.origem, c.idlote,
                                       c.qtdemovimentada, p_idusuario,
                                       'SEPARAÇÃO EXECUTADA, RETIRADO ESTOQUE PARA SEPARAÇÃO DE ' ||
                                        v_textoLocalSeparacao ||
                                        ', IDMOVIMENTACAO: ' || c.id ||
                                        ', IDONDA:' || p_idonda, 'N');
          
            if ((c.tipoOrigem = 0) AND (p_bufferOrigem = 0)) then
              pk_picking_dinamico.addGttPickingDinamico(c.idProduto,
                                                        c.iddepositante,
                                                        c.origem,
                                                        c.idarmazem, 0);
            end if;
          
            pk_picking_dinamico.addGttPickingDinamico(c.idProduto,
                                                      c.iddepositante,
                                                      c.destino, c.idarmazem,
                                                      1);
          
            pk_estoque.incluir_estoque(c.idarmazem, c.destino, c.idlote,
                                       c.qtdemovimentada, p_idusuario,
                                       'SEPARAÇÃO EXECUTADA, ADICIONADO ESTOQUE PARA SEPARAÇÃO DE ' ||
                                        v_textoLocalSeparacao ||
                                        ', IDMOVIMENTACAO: ' || c.id ||
                                        ', IDONDA:' || p_idonda, 'N');
          
            if (c.destinobuffer = 'S' and c.bufferesteira = 1 and
               c.qtdeadicionar > 0) then
              pk_estoque.retirar_adicionar(c.idarmazem, c.destino, c.idlote,
                                           c.qtdemovimentada, p_idusuario,
                                           'SEPARAÇÃO EXECUTADA, RETIRADO ADICIONAR PARA SEPARAÇÃO DE ' ||
                                            v_textoLocalSeparacao ||
                                            ', IDMOVIMENTACAO: ' || c.id ||
                                            ', IDONDA:' || p_idonda);
            else
              pk_estoque.incluir_pendencia(c.idarmazem, c.destino, c.idlote,
                                           c.qtdemovimentada, p_idusuario,
                                           'SEPARAÇÃO EXECUTADA, ADICIONADO PENDENCIA PARA SEPARAÇÃO DE ' ||
                                            v_textoLocalSeparacao ||
                                            ', IDMOVIMENTACAO: ' || c.id ||
                                            ', IDONDA:' || p_idonda);
            end if;
          
            if (c.tipodestino = 0 and p_bufferDestino = 0 and
               c.qtdeadicionar > 0) then
              pk_estoque.retirar_pendencia(c.idarmazem, c.destino, c.idlote,
                                           c.qtdeadicionar, p_idusuario,
                                           'SEPARAÇÃO EXECUTADA, REMOVIDO PENDENCIA PARA SEPARAÇÃO DE ' ||
                                            v_textoLocalSeparacao ||
                                            ', IDMOVIMENTACAO: ' || c.id ||
                                            ', IDONDA:' || p_idonda);
            
              pk_estoque.retirar_adicionar(c.idarmazem, c.destino, c.idlote,
                                           c.qtdeadicionar, p_idusuario,
                                           'SEPARAÇÃO EXECUTADA, RETIRADO ADICIONAR PARA SEPARAÇÃO DE ' ||
                                            v_textoLocalSeparacao ||
                                            ', IDMOVIMENTACAO: ' || c.id ||
                                            ', IDONDA:' || p_idOnda);
            end if;
          end loop;
        
          pk_picking_dinamico.deletar_picking_dinamico;
          pk_picking_dinamico.inserir_picking_dinamico;
        
          if (isCheckOutExpress(p_idOnda, p_idRegiaoDestino)) then
          
            validarCaixaSeparacao(p_idCaixaSeparacao, p_mensagem,
                                  v_caixaseparacao);
          
            validarCaixaIniciada(p_idOnda, p_identificador, p_bufferOrigem,
                                 p_idRegiaoOrigem, p_bufferDestino,
                                 p_idRegiaoDestino, p_idCaixaSeparacao,
                                 p_mensagem, v_idcaixa);
          
            update conteudocarrinho
               set carrinhocheio = 'S'
             where id in
                   (select c.id
                      from conteudocarrinho c, movimentacao m, local lo,
                           local ld, regiaoarmazenagem ro,
                           regiaoarmazenagem rd
                     where m.id = c.idmovimentacao
                       and lo.id = m.idlocalorigem
                       and m.status = 1
                       and round(m.qtdemovimentada, 6) =
                           round(m.qtdeconferida, 6)
                       and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                       and ld.id = m.idlocaldestino
                       and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                       and ro.idregiao = lo.idregiao
                       and rd.idregiao = ld.idregiao
                       and m.idonda = p_idOnda
                       and ro.idregiao = p_idRegiaoOrigem
                       and rd.idregiao = p_idRegiaoDestino
                       and m.identificador = p_identificador
                       and c.idusuario = p_idusuario)
               and idcaixaseparacao = v_caixaseparacao.idcaixaseparacao;
          end if;
        
          update movimentacao m1
             set m1.status        = 2,
                 m1.idusuario     = p_idusuario,
                 m1.datatermino   = sysdate,
                 m1.tiposeparacao = 1
           where exists
           (select 1
                    from movimentacao m, local lo, local ld,
                         regiaoarmazenagem r
                   where m.idonda = p_idonda
                     and m.identificador = p_identificador
                     and m.idnotafiscal =
                         decode(p_idNotaFiscal, 0, m.idnotafiscal,
                                p_idnotaFiscal)
                     and m.status = 1
                     and round(m.qtdemovimentada, 6) =
                         round(m.qtdeconferida, 6)
                     and lo.id = m.idlocalorigem
                     and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
                     and lo.idregiao = p_idRegiaoOrigem
                     and ld.id = m.idlocaldestino
                     and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
                     and ld.idregiao = p_idRegiaoDestino
                     and m.datatermino is null
                     and r.idregiao = ld.idregiao
                     and lo.bufferesteira = p_bufferEsteiraOrigem
                     and ld.bufferesteira = p_bufferEsteiraDestino
                     and m1.id = m.id);
        end if;
      
        pk_convocacao.finalizaseparacaoonda(p_idusuario, p_idOnda);
      end if;
    end if;
  
    -- Valida e executa Destino do remanejamento se vier da tela Separação Manual
    -- p_tipoSeparacao = 1
    verificarSeparacaoRem(p_idRegiaoOrigem, p_idRegiaoDestino, p_idOnda,
                          p_idusuario, 1, p_bufferEsteiraOrigem,
                          p_bufferEsteiraDestino);
  
    -- Valida e executa Origem e destino do remanejamento se vier da 
    -- tela Acompanhamento Saida por NF
    -- p_tipoSeparacao = 3
    verificarSeparacaoRem(p_idRegiaoOrigem, p_idRegiaoDestino, p_idOnda,
                          p_idusuario, 3, p_bufferEsteiraOrigem,
                          p_bufferEsteiraDestino);
  
    moverEstoqueOS(p_idOnda, p_idusuario);
  end separarDestino;

  procedure finalizarRemanejamentoOrigem
  (
    p_idRemanejamento number,
    p_idUsuario       number
  ) is
  
  begin
    update remanejamento r
       set r.status          = 'G',
           r.idusuarioinicio = p_idUsuario,
           r.horafimorigem   = sysdate
     where r.idremanejamento = p_idRemanejamento;
  end;

  function isSepUnicoUsuario(p_idOnda in number) return boolean is
    v_sepondaporusuario number;
  begin
    select co.sepondaporusuario
      into v_sepondaporusuario
      from configuracaoonda co, romaneiopai rp
     where rp.idromaneio = p_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (v_sepondaporusuario = 1) then
      return true;
    else
      return false;
    end if;
  end;

  function isOndaCarga(p_idOnda in number) return boolean is
    tipoonda number;
  begin
    select co.tipoonda
      into tipoonda
      from configuracaoonda co, romaneiopai rp
     where rp.idromaneio = p_idOnda
       and rp.idconfiguracaoonda = co.idconfiguracaoonda;
  
    if (tipoonda = 1) then
      return true;
    else
      return false;
    end if;
  end;

  procedure validarSeparacaoUnicoUsuario
  (
    p_idOnda    in number,
    p_idusuario in number,
    p_mensagem  in out varchar2
  ) is
    v_naoAtribuido number;
    v_idusuario    number;
    v_nomeUsuario  usuario.nomeusuario%type;
  begin
    if (isSepUnicoUsuario(p_idOnda) and not (isOndaCarga(p_idOnda))) then
    
      select count(*)
        into v_naoAtribuido
        from movimentacao m
       where m.idonda = p_idOnda
         and m.status in (0, 1)
         and m.idusuario is null;
    
      if (v_naoAtribuido > 0) then
        trocarUsuarioSepOndaUSR(p_idOnda, p_idusuario, p_idusuario);
      else
        begin
          select distinct u.idusuario, u.nomeusuario
            into v_idusuario, v_nomeUsuario
            from movimentacao m, usuario u
           where m.idonda = p_idOnda
             and m.status in (0, 1)
             and m.idusuario is not null
             and u.idusuario = m.idusuario;
        exception
          when no_data_found then
            v_idusuario := p_idusuario;
            p_mensagem  := 'Nenhuma movimentação pendente de separação.';
        end;
      
        if (v_idusuario <> p_idusuario) then
          p_mensagem := 'A onda está configurada para utilizar separação por apenas um usuário, e já foi iniciada pelo usuario ' ||
                        v_nomeUsuario || ' (id ' || v_idusuario ||
                        '). Operação cancelada.';
        end if;
      end if;
    end if;
  end validarSeparacaoUnicoUsuario;

  /*
  * Rotina responsavel por realizar a separação manual
  */
  function separacaoManual
  (
    p_idOnda               in number,
    p_identificador        in number,
    p_idusuario            in number,
    p_idnotaFiscal         in number,
    p_bufferOrigem         in number,
    p_idRegiaoOrigem       in number,
    p_bufferDestino        in number,
    p_idRegiaoDestino      in number,
    p_bufferEsteiraOrigem  in number default null,
    p_bufferEsteiraDestino in number default null,
    p_idCaixaSeparacao     in number,
    p_mensagem             in out varchar2
  ) return number is
    C_MENSAGEM CONSTANT number := 3;
  
    v_isSepararOrigem   boolean;
    v_reabPendente      number;
    v_tipoRegiaoDestino number;
    v_msg               t_message;
  
  begin
    select r.tipo
      into v_tipoRegiaoDestino
      from regiaoarmazenagem r
     where r.idregiao = p_idRegiaoDestino;
  
    if v_tipoRegiaoDestino = 3
       and p_bufferDestino = 0 then
      v_msg := t_message('Não existe separação com destino de Doca, ' ||
                         'selecione outro Tipo de Separação.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarSeparacaoUnicoUsuario(p_idOnda, p_idusuario, p_mensagem);
  
    if (p_mensagem is not null) then
      return C_MENSAGEM;
    end if;
  
    pk_utilities.GeraLog(p_idusuario,
                         'Iniciada rotina de Separação Manual para o identificador: ' ||
                          p_identificador || ' / idOnda: ' || p_idOnda ||
                          ' / IdNotaFiscal: ' || p_idnotaFiscal ||
                          ' / idRegiaoOrigem: ' || p_idRegiaoOrigem ||
                          ' / bufferOrigem: ' || p_bufferOrigem ||
                          ' / idRegiaoDestino: ' || p_idRegiaoDestino ||
                          ' / bufferDestino: ' || p_bufferDestino, p_idOnda,
                         'SO');
  
    -- Realizando lock nas movimentações envolvidas com a separação
    update movimentacao m
       set m.id = m.id
     where m.idonda = p_idonda
       and m.identificador = p_identificador
       and m.idnotafiscal =
           decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
       and exists
     (select 1
              from local lo
             where lo.id = m.idlocalorigem
               and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
               and lo.idregiao = p_idRegiaoOrigem)
       and exists
     (select 1
              from local ld
             where ld.id = m.idlocaldestino
               and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
               and ld.idregiao = p_idRegiaoDestino);
  
    v_isSepararOrigem := isSepararOrigem(p_idOnda, p_identificador,
                                         p_idnotaFiscal, p_bufferOrigem,
                                         p_idRegiaoOrigem, p_bufferDestino,
                                         p_idRegiaoDestino, p_idusuario,
                                         p_mensagem, p_bufferEsteiraOrigem,
                                         p_bufferEsteiraDestino);
  
    if (p_mensagem is not null) then
      return C_MENSAGEM;
    end if;
  
    if (v_isSepararOrigem) then
      separarOrigem(p_idOnda, p_identificador, p_idusuario, p_idnotaFiscal,
                    p_bufferOrigem, p_idRegiaoOrigem, p_bufferDestino,
                    p_idRegiaoDestino, p_idCaixaSeparacao, v_reabPendente,
                    p_mensagem, p_bufferEsteiraOrigem,
                    p_bufferEsteiraDestino);
    
      pk_utilities.GeraLog(p_idusuario,
                           'Separação Manual Iniciada para o identificador: ' ||
                            p_identificador || ' / idOnda: ' || p_idOnda ||
                            ' / IdNotaFiscal: ' || p_idnotaFiscal ||
                            ' / idRegiaoOrigem: ' || p_idRegiaoOrigem ||
                            ' / bufferOrigem: ' || p_bufferOrigem ||
                            ' / idRegiaoDestino: ' || p_idRegiaoDestino ||
                            ' / bufferDestino: ' || p_bufferDestino,
                           p_idOnda, 'SO');
    
      if (p_mensagem is not null) then
        return C_MENSAGEM;
      end if;
    
      if (v_reabPendente > 0) then
        return C_REABASTECIMENTO_PENDENTE;
      end if;
    
      return C_ORIGEM_CONCLUIDO;
    else
      separarDestino(p_idOnda, p_identificador, p_idusuario, p_idnotaFiscal,
                     p_bufferOrigem, p_idRegiaoOrigem, p_bufferDestino,
                     p_idRegiaoDestino, true, p_idCaixaSeparacao,
                     v_reabPendente, p_mensagem, p_bufferEsteiraOrigem,
                     p_bufferEsteiraDestino);
    
      pk_utilities.GeraLog(p_idusuario,
                           'Separação Manual Finalizada para o identificador: ' ||
                            p_identificador || ' / idOnda: ' || p_idOnda ||
                            ' / IdNotaFiscal: ' || p_idnotaFiscal ||
                            ' / idRegiaoOrigem: ' || p_idRegiaoOrigem ||
                            ' / bufferOrigem: ' || p_bufferOrigem ||
                            ' / idRegiaoDestino: ' || p_idRegiaoDestino ||
                            ' / bufferDestino: ' || p_bufferDestino,
                           p_idOnda, 'SO');
    
      if (p_mensagem is not null) then
        return C_MENSAGEM;
      end if;
    
      if (v_reabPendente > 0) then
        return C_REABASTECIMENTO_PENDENTE;
      end if;
    
      if (p_bufferEsteiraDestino = 1) then
        for rem in (select idremanejamento
                      from remanejamento
                     where idromaneio = p_idOnda
                       and planejado = 'S'
                       and status <> 'F')
        loop
          pk_remanejamento.integrarEsteira(rem.idremanejamento, p_idusuario);
        end loop;
      end if;
    
      inserirAtividadePackingColetor(0, p_idOnda);
    
      return C_DESTINO_CONCLUIDO;
    end if;
  end;

  -- Refactored procedure separarDestino 
  procedure pausarSeparacao
  (
    p_idOnda          in number,
    p_identificador   in number,
    p_idusuario       in number,
    p_idnotaFiscal    in number,
    p_bufferOrigem    in number,
    p_idRegiaoOrigem  in number,
    p_bufferDestino   in number,
    p_idRegiaoDestino in number
  ) is
    v_isPausado number;
    v_idUsuario number;
    v_msg       t_message;
  begin
    select decode(m.datapausa, null, 0, 1), m.idusuario
      into v_isPausado, v_idUsuario
      from movimentacao m, local lo, local ld, regiaoarmazenagem r
     where m.idonda = p_idonda
       and m.identificador = p_identificador
       and m.idnotafiscal =
           decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
       and m.status = 1
       and round(m.qtdemovimentada, 6) = round(m.qtdeconferida, 6)
       and lo.id = m.idlocalorigem
       and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
       and lo.idregiao = p_idRegiaoOrigem
       and ld.id = m.idlocaldestino
       and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
       and ld.idregiao = p_idRegiaoDestino
       and r.idregiao = ld.idregiao
       and rownum = 1;
  
    if (v_idUsuario <> p_idusuario) then
      v_msg := t_message('Apenas o usuario que esta separando esta regiao pode pausa-la');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update movimentacao m1
       set m1.tempopausa = decode(v_isPausado, 0, m1.tempopausa,
                                  floor((sysdate - m1.datapausa) * 24 * 60 * 60) +
                                   nvl(m1.tempopausa, 0)),
           m1.datapausa  = to_date(decode(v_isPausado, 1, null,
                                          to_char(sysdate,
                                                   'dd/mm/yyyy hh24:mi:ss')),
                                   'dd/mm/yyyy hh24:mi:ss')
     where exists
     (select 1
              from movimentacao m, local lo, local ld, regiaoarmazenagem r
             where m.idonda = p_idonda
               and m.identificador = p_identificador
               and m.idnotafiscal =
                   decode(p_idNotaFiscal, 0, m.idnotafiscal, p_idnotaFiscal)
               and m.status = 1
               and round(m.qtdemovimentada, 6) = round(m.qtdeconferida, 6)
               and lo.id = m.idlocalorigem
               and decode(lo.buffer, 'S', 1, 0) = p_bufferOrigem
               and lo.idregiao = p_idRegiaoOrigem
               and ld.id = m.idlocaldestino
               and decode(ld.buffer, 'S', 1, 0) = p_bufferDestino
               and ld.idregiao = p_idRegiaoDestino
               and r.idregiao = ld.idregiao
               and m1.id = m.id);
  end;

  function finalizarSepOnda
  (
    p_idusuario       number,
    p_idonda          number,
    p_idregiaoorigem  number,
    p_bufferorigem    number,
    p_idregiaodestino number,
    p_bufferdestino   number,
    p_identificador   number,
    p_idnotafiscal    number
  ) return number is
    type t_separacao is record(
      idusuario       number,
      idonda          number,
      idregiaoorigem  number,
      bufferorigem    number,
      idregiaodestino number,
      bufferdestino   number,
      identificador   number,
      idnotafiscal    number);
  
    row_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(row_locked, -54);
    r_separacao t_separacao;
  
    type t_reabastecimentos is table of gtt_reabpendente%rowtype;
  
    r_tmp_reabastecimentos t_reabastecimentos;
    r_reabastecimentos     t_reabastecimentos;
    C_STATUSMOV_ANDAMENTO constant number := 1;
    v_statusmovimentacao    number;
    v_totalcorretohistorico number;
    v_estoquemovido         boolean;
    v_idconfiguracaoonda    number;
    v_msg                   t_message;
  
    cursor c_movimentacoes(r_separacao t_separacao) is
      select m.id idmovimentacao, m.idlote, m.qtdemovimentada, lo.idarmazem,
             lo.idlocal idlocalorigem, lo.tipo tipoLocalOrigem,
             lo.buffer origemBuffer, ld.idlocal idlocaldestino,
             ld.tipo tipoLocalDestino, ld.buffer destinoBuffer, m.quantidade,
             ld.picking destinopicking, lo.id idenderecoorigem, lt.idproduto,
             lt.iddepositante
        from movimentacao m, local lo, local ld, lote lt, romaneiopai rp,
             configuracaoonda co
       where m.idonda = r_separacao.idonda
         and m.idusuario =
             decode(co.seppkporestacao, 0, r_separacao.idusuario, 1,
                    m.idusuario)
         and m.status = 1
         and m.identificador =
             nvl(r_separacao.identificador, m.identificador)
         and m.idnotafiscal = nvl(r_separacao.idnotafiscal, m.idnotafiscal)
         and round(m.qtdemovimentada, 6) = round(m.qtdeconferida, 6)
         and lo.id = m.idlocalorigem
         and decode(lo.buffer, 'S', 1, 0) =
             nvl(r_separacao.bufferorigem, decode(lo.buffer, 'S', 1, 0))
         and lo.idregiao = nvl(r_separacao.idregiaoorigem, lo.idregiao)
         and ld.id = m.idlocaldestino
         and decode(ld.buffer, 'S', 1, 0) = r_separacao.bufferdestino
         and ld.idregiao = r_separacao.idregiaodestino
         and lt.idlote = m.idlote
         and rp.idromaneio = m.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
       order by lo.idarmazem, lo.idlocal, m.idlote;
  
    r_movimentacoes          c_movimentacoes%rowtype;
    v_qtdeRetirarDoPicking   number;
    v_reabPendenteEncontrado number;
  
    procedure validarOnda
    (
      r_separacao          in t_separacao,
      p_idconfiguracaoonda in out number
    ) is
      C_STATUSONDA_CANCELADA   constant number := 5;
      C_STATUSONDA_FINALIZADA  constant number := 3;
      C_STATUSONDA_LIBERADA    constant number := 2;
      C_STATUSONDA_EM_EXECUCAO constant number := 4;
    
      r_onda romaneiopai%rowtype;
    begin
      select r.*
        into r_onda
        from romaneiopai r
       where r.idromaneio = r_separacao.idonda
         for update;
    
      if (r_onda.statusonda = C_STATUSONDA_CANCELADA) then
        v_msg := t_message('A onda {0} (id: {1}) esta cancelada.');
        v_msg.addParam(r_onda.codigointerno);
        v_msg.addParam(r_onda.idromaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_onda.statusonda = C_STATUSONDA_FINALIZADA) then
        v_msg := t_message('A onda {0} (id: {1}) esta finalizada.');
        v_msg.addParam(r_onda.codigointerno);
        v_msg.addParam(r_onda.idromaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if not ((r_onda.statusonda = C_STATUSONDA_LIBERADA) or
          (r_onda.statusonda = C_STATUSONDA_EM_EXECUCAO)) then
        v_msg := t_message('A onda {0} (id: {1}) não esta liberada para separação.');
        v_msg.addParam(r_onda.codigointerno);
        v_msg.addParam(r_onda.idromaneio);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      p_idconfiguracaoonda := r_onda.idconfiguracaoonda;
    end validarOnda;
  begin
    r_separacao.idusuario := p_idusuario;
    r_separacao.idonda    := p_idonda;
  
    if (p_idregiaoorigem <> 0) then
      r_separacao.idregiaoorigem := p_idregiaoorigem;
    end if;
  
    if (p_bufferorigem in (0, 1)) then
      r_separacao.bufferorigem := p_bufferorigem;
    end if;
  
    r_separacao.idregiaodestino := p_idregiaodestino;
    r_separacao.bufferdestino   := p_bufferdestino;
  
    if (p_identificador <> 0) then
      r_separacao.identificador := p_identificador;
    end if;
  
    if (p_idnotafiscal <> 0) then
      r_separacao.idnotafiscal := p_idnotafiscal;
    end if;
  
    validarOnda(r_separacao, v_idconfiguracaoonda);
  
    open c_movimentacoes(r_separacao);
    fetch c_movimentacoes
      into r_movimentacoes;
  
    if (c_movimentacoes%notfound) then
      close c_movimentacoes;
    
      v_msg := t_message('Nenhuma movimentação separada pendente de entrega. Local de separação atual: ' ||
                         'idonda={0}, idusuario={1}, idregiaoorigem={2}' ||
                         ', bufferorigem={3}, idregiaodestino={4}, bufferdestino={5}' ||
                         ', idnotafiscal={6}, identificador={7}');
      v_msg.addParam(r_separacao.idonda);
      v_msg.addParam(r_separacao.idusuario);
      v_msg.addParam(r_separacao.idregiaoorigem);
      v_msg.addParam(r_separacao.bufferorigem);
      v_msg.addParam(r_separacao.idregiaodestino);
      v_msg.addParam(r_separacao.bufferdestino);
      v_msg.addParam(r_separacao.idnotafiscal);
      v_msg.addParam(r_separacao.identificador);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    delete from gtt_reabpendente;
    delete from gtt_picking_dinamico;
    r_reabastecimentos := t_reabastecimentos();
    savepoint movimentarEstoque;
  
    while (c_movimentacoes%found)
    loop
      begin
        select m.status
          into v_statusmovimentacao
          from movimentacao m
         where m.id = r_movimentacoes.idmovimentacao
           for update nowait;
      exception
        when row_locked then
          v_msg := t_message('Essa entrega de produtos no packing já está sendo processada. Operação cancelada.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (v_statusmovimentacao <> C_STATUSMOV_ANDAMENTO) then
        v_msg := t_message('Movimentação não possui status EM ANDAMENTO. Operação cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_totalcorretohistorico := 4;
    
      pk_picking_dinamico.addGttPickingDinamico(r_movimentacoes.idproduto,
                                                r_movimentacoes.iddepositante,
                                                r_movimentacoes.idlocaldestino,
                                                r_movimentacoes.idarmazem, 1);
    
      pk_estoque.incluir_estoque(r_movimentacoes.idarmazem,
                                 r_movimentacoes.idlocaldestino,
                                 r_movimentacoes.idlote,
                                 r_movimentacoes.qtdemovimentada,
                                 r_separacao.idusuario,
                                 'MOVIMENTACAO EXECUTADA VIA COLETOR, ADICIONADO ESTOQUE PARA MOVIMENTACAO: ' ||
                                  r_movimentacoes.idmovimentacao ||
                                  ' DA ONDA ID: ' || r_separacao.idonda, 'N',
                                 r_movimentacoes.idmovimentacao);
    
      pk_estoque.incluir_pendencia(r_movimentacoes.idarmazem,
                                   r_movimentacoes.idlocaldestino,
                                   r_movimentacoes.idlote,
                                   r_movimentacoes.qtdemovimentada,
                                   r_separacao.idusuario,
                                   'MOVIMENTACAO EXECUTADA VIA COLETOR, ADICIONADO PENDENCIA PARA MOVIMENTACAO: ' ||
                                    r_movimentacoes.idmovimentacao ||
                                    ' DA ONDA ID: ' || r_separacao.idonda,
                                   r_movimentacoes.idmovimentacao);
    
      v_qtdeRetirarDoPicking := r_movimentacoes.qtdemovimentada -
                                r_movimentacoes.quantidade;
      if (r_movimentacoes.destinopicking = 'S' and
         r_separacao.bufferdestino = 0 and v_qtdeRetirarDoPicking > 0) then
        v_totalcorretohistorico := 6;
      
        pk_estoque.retirar_pendencia(r_movimentacoes.idarmazem,
                                     r_movimentacoes.idlocaldestino,
                                     r_movimentacoes.idlote,
                                     v_qtdeRetirarDoPicking,
                                     r_separacao.idusuario,
                                     'MOVIMENTACAO EXECUTADA VIA COLETOR, REMOVIDO PENDENCIA PARA MOVIMENTACAO: ' ||
                                      r_movimentacoes.idmovimentacao ||
                                      ' DA ONDA ID: ' || r_separacao.idonda,
                                     r_movimentacoes.idmovimentacao);
        pk_estoque.retirar_adicionar(r_movimentacoes.idarmazem,
                                     r_movimentacoes.idlocaldestino,
                                     r_movimentacoes.idlote,
                                     v_qtdeRetirarDoPicking,
                                     r_separacao.idusuario,
                                     'MOVIMENTACAO EXECUTADA VIA COLETOR, RETIRADO ADICIONAR PARA MOVIMENTACAO: ' ||
                                      r_movimentacoes.idmovimentacao ||
                                      ' DA ONDA ID: ' || r_separacao.idonda,
                                     r_movimentacoes.idmovimentacao);
      end if;
    
      pk_estoque.retirar_pendencia(r_movimentacoes.idarmazem,
                                   r_movimentacoes.idlocalorigem,
                                   r_movimentacoes.idlote,
                                   r_movimentacoes.qtdemovimentada,
                                   r_separacao.idusuario,
                                   'MOVIMENTACAO EXECUTADA VIA COLETOR, REMOVIDO PENDENCIA PARA MOVIMENTACAO: ' ||
                                    r_movimentacoes.idmovimentacao ||
                                    ' DA ONDA ID: ' || r_separacao.idonda,
                                   r_movimentacoes.idmovimentacao);
    
      v_estoquemovido := false;
    
      begin
        pk_estoque.retirar_estoque(r_movimentacoes.idarmazem,
                                   r_movimentacoes.idlocalorigem,
                                   r_movimentacoes.idlote,
                                   r_movimentacoes.qtdemovimentada,
                                   r_separacao.idusuario,
                                   'MOVIMENTACAO EXECUTADA VIA COLETOR, RETIRADO ESTOQUE PARA MOVIMENTACAO: ' ||
                                    r_movimentacoes.idmovimentacao ||
                                    ' DA ONDA ID: ' || r_separacao.idonda,
                                   'N', r_movimentacoes.idmovimentacao);
      
        if ((r_movimentacoes.tipolocalorigem = 0) and
           (r_movimentacoes.origembuffer = 'N')) then
          pk_picking_dinamico.addGttPickingDinamico(r_movimentacoes.idproduto,
                                                    r_movimentacoes.iddepositante,
                                                    r_movimentacoes.idlocalorigem,
                                                    r_movimentacoes.idarmazem,
                                                    0);
        end if;
        v_estoquemovido := true;
      exception
        when others then
          v_reabPendenteEncontrado := r_reabastecimentos.count;
        
          select lt.idproduto, l.id idendereco, r.idremanejamento, 0 idonda,
                 0 idmovimentacao
            bulk collect
            into r_tmp_reabastecimentos
            from loteremanejamento lr, remanejamento r, lote lt, local l
           where lr.idlote = r_movimentacoes.idlote
             and lr.idremanejamento = r.idremanejamento
             and r.status <> 'F'
             and lr.idlote = lt.idlote
             and l.idarmazem = r.idarmazemdestino
             and l.idlocal = r.idlocaldestino
             and l.idarmazem = r_movimentacoes.idarmazem
             and l.idlocal = r_movimentacoes.idlocalorigem;
        
          r_reabastecimentos.extend(r_tmp_reabastecimentos.count);
          for i in 1 .. r_tmp_reabastecimentos.count
          loop
            r_reabastecimentos(r_reabastecimentos.count) := r_tmp_reabastecimentos(i);
          end loop;
        
          select lt.idproduto, r_movimentacoes.idlocalorigem idendereco,
                 0 idremanejamento, m.idonda idonda, m.id idmovimentacao
            bulk collect
            into r_tmp_reabastecimentos
            from movimentacao m, local ld, lote lt
           where m.status in (0, 1)
             and m.idlote = r_movimentacoes.idlote
             and m.idonda <> r_separacao.idonda
             and lt.idlote = m.idlote
             and ld.id = m.idlocaldestino
             and ld.idarmazem = r_movimentacoes.idarmazem
             and ld.idlocal = r_movimentacoes.idlocalorigem;
        
          r_reabastecimentos.extend(r_tmp_reabastecimentos.count);
          for i in 1 .. r_tmp_reabastecimentos.count
          loop
            r_reabastecimentos(r_reabastecimentos.count) := r_tmp_reabastecimentos(i);
          end loop;
        
          if (v_reabPendenteEncontrado = r_reabastecimentos.count) then
            v_msg := t_message('Não foi possivel mover o lote {0} no local {1}. Nenhum reabastecimento foi encontrado.');
            v_msg.addParam(r_movimentacoes.idlote);
            v_msg.addParam(r_movimentacoes.idlocalorigem);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
      end;
    
      if (v_estoquemovido) then
        update movimentacao m
           set m.status        = 2,
               m.datatermino   = sysdate,
               m.idusuario     = r_separacao.idusuario,
               m.tiposeparacao = 2
         where m.id = r_movimentacoes.idmovimentacao;
      end if;
    
      fetch c_movimentacoes
        into r_movimentacoes;
    end loop;
  
    pk_picking_dinamico.deletar_picking_dinamico;
    pk_picking_dinamico.inserir_picking_dinamico;
  
    close c_movimentacoes;
  
    -- pk_onda.criarMapaSeparacaoOnda(r_separacao.idonda, v_idconfiguracaoonda);
    -- pk_onda.criarMapaSeparacaoOndaPedido(r_separacao.idonda, v_idconfiguracaoonda);
  
    moverEstoqueOS(p_idOnda, p_idusuario);
  
    if (r_reabastecimentos.count > 0) then
      rollback to movimentarEstoque;
    
      forall i in 1 .. r_reabastecimentos.count
        insert into gtt_reabpendente
        values r_reabastecimentos
          (i);
    
      return SEPARACAO_COM_REAB;
    end if;
  
    return SEPARACAO_SEM_REAB;
  end;

  function agruparTarefaSeparacao
  (
    p_idusuario in number,
    p_idonda    in number
  ) return number is
    type t_tarefa is record(
      idonda         number,
      identificador  number,
      idlocaldestino number,
      idnotafiscal   number,
      idpedidopai    number);
  
    r_novaTarefa     t_tarefa;
    v_log            varchar2(4000);
    v_barraTarefa    v_tarefas_onda.codbarratarefa%type;
    r_usuario        usuario%rowtype;
    v_qtdeSaidaPorNf number;
    v_totalnf        number;
    v_totalmov       number;
    v_msg            t_message;
  
    procedure validarAgruparTarefa(p_idonda in number) is
      v_movEncontrada     number;
      v_sepJaIniciada     number;
      v_movDestNaoPacking number;
      v_sepNFdiferentes   number;
      v_packingDif        number;
    begin
      select count(*)
        into v_movEncontrada
        from movimentacao m, gtt_selecao g
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status in (0, 1, 2);
    
      if (v_movEncontrada = 0) then
        v_msg := t_message('NENHUMA MOVIMENTÇÃO ENCONTRADA PARA A ONDA COM ID {0}');
        v_msg.addParam(p_idonda);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_sepJaIniciada
        from movimentacao m, gtt_selecao g
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status <> 0;
    
      if (v_sepJaIniciada > 0) then
        v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS QUE NÃO POSSUEM SEPARAÇÃO INICIADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_movDestNaoPacking
        from movimentacao m, gtt_selecao g, local l
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status = 0
         and l.id = m.idlocaldestino
         and l.tipo <> 8;
    
      if (v_movDestNaoPacking > 0) then
        v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS COM DESTINO PACKING.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(distinct nvl(nf.idpedidopai, nf.idnotafiscal))
        into v_sepNFdiferentes
        from movimentacao m, gtt_selecao g, notafiscal nf
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status = 0
         and nf.idnotafiscal = m.idnotafiscal;
    
      if (v_sepNFdiferentes > 1) then
        v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS DO MESMO PEDIDO/NOTA FISCAL');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(distinct m.idlocaldestino)
        into v_packingDif
        from movimentacao m, gtt_selecao g
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status = 0;
    
      if (v_packingDif > 1) then
        v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS COM O MESMO LOCAL DE DESTINO');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarAgruparTarefa;
  
    procedure getCodBarraTarefa
    (
      p_idonda        in number,
      p_identificador in number,
      v_barraTarefa   in out v_tarefas_onda.codbarratarefa%type
    ) is
    begin
      select v.codbarratarefa
        into v_barraTarefa
        from v_tarefas_onda v
       where v.identificador = p_identificador
         and v.idonda = p_idonda
         and v.status = 0
         and rownum = 1;
    end getCodBarraTarefa;
  
    procedure getNovaTarefa
    (
      p_idonda     in number,
      r_novaTarefa in out t_tarefa
    ) is
    begin
      r_novaTarefa.idonda := p_idonda;
    
      select min(m.identificador)
        into r_novaTarefa.identificador
        from movimentacao m, gtt_selecao g
       where m.idonda = p_idonda
         and g.idselecionado = m.identificador
         and m.status = 0;
    
      select distinct m.idlocaldestino, nf.idnotafiscal, nf.idpedidopai
        into r_novaTarefa.idlocaldestino, r_novaTarefa.idnotafiscal,
             r_novaTarefa.idpedidopai
        from movimentacao m, notafiscal nf
       where m.idonda = p_idonda
         and m.identificador = r_novaTarefa.identificador
         and m.status = 0
         and nf.idnotafiscal = m.idnotafiscal;
    end getNovaTarefa;
  
    procedure agruparSubPedido
    (
      p_idusuario     in number,
      p_idonda        in number,
      r_novaTarefa    in out t_tarefa,
      p_identificador in number
    ) is
      r_nf      notafiscal%rowtype;
      r_item    nfdet%rowtype;
      v_erro    varchar2(4000);
      v_idnfdet number;
    
      procedure getSubPedido
      (
        p_idonda        in number,
        r_novaTarefa    in out t_tarefa,
        r_nf            in out notafiscal%rowtype,
        p_identificador in number
      ) is
      begin
        select distinct nf.*
          into r_nf
          from movimentacao m, notafiscal nf
         where m.idonda = p_idonda
           and m.identificador = p_identificador
           and m.status = 0
           and nf.idnotafiscal = m.idnotafiscal;
      
        if (r_nf.idnotafiscal = r_novaTarefa.idnotafiscal) then
          return;
        end if;
      
        if (r_novaTarefa.idpedidopai <> r_nf.idpedidopai) then
          v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS DE PEDIDOS GERADOS A PARTIR DO MESMO PEDIDO PRINCIPAL.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_nf.enviadofaturamento = 'S') then
          v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS DE PEDIDOS NÃO ENVIADOS PARA FATURAMENTO: (PEDIDO {0})');
          v_msg.addParam(r_nf.numpedidofornecedor);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if (r_nf.tiponf <> 'P') then
          v_msg := t_message('SOMENTE É PERMITIDO AGRUPAR TAREFAS DE PEDIDOS NÃO FATURADOS.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end getSubPedido;
    begin
      getSubPedido(p_idonda, r_novaTarefa, r_nf, p_identificador);
      if (r_nf.idnotafiscal = r_novaTarefa.idnotafiscal) then
        return;
      end if;
    
      for r_item in (select *
                       from nfdet nd
                      where nd.nf = r_nf.idnotafiscal)
      loop
        begin
          select nf.idnfdet
            into v_idnfdet
            from nfdet nf
           where nf = r_novaTarefa.idnotafiscal
             and barra = r_item.barra
             and idproduto = r_item.idproduto;
        
          update nfdet
             set qtde         = nvl(qtde, 0) + r_item.qtde,
                 qtdeatendida = nvl(qtdeatendida, 0) + r_item.qtdeatendida,
                 total        = nvl(total, 0) + (precounitliquido * qtde),
                 totalliquido = nvl(totalliquido, 0) +
                                (precounitliquido * qtde)
           where idnfdet = v_idnfdet;
        exception
          when no_data_found then
            r_item.idnfdet := null;
            r_item.nf      := r_novaTarefa.idnotafiscal;
            pk_notafiscal.insere_detalhe_nf(r_item);
        end;
      end loop;
    
      pk_notafiscal.p_totalliza_nfdet(r_novaTarefa.idnotafiscal);
      pk_notafiscal.p_gerar_nfimpressao(r_novaTarefa.idnotafiscal);
    
      delete from nfromaneio nfr
       where nfr.idromaneio = r_novaTarefa.idonda
         and nfr.idnotafiscal = r_nf.idnotafiscal;
    
      delete from saidapornf s
       where s.idonda = p_idonda
         and s.idnotafiscal = r_nf.idnotafiscal;
    
      pk_notafiscal.CancelaNF(r_nf.idprenf, p_idusuario,
                              'TAREFA DE SEPARAÇÃO DA ONDA AGRUPADA. NOVO PEDIDO IDNOTAFISCAL: ' ||
                               r_novaTarefa.idnotafiscal, 'N', 'N', v_erro);
    
      if v_erro is not null then
        raise_application_error(-20000, v_erro);
      end if;
    end agruparSubPedido;
  begin
    validarAgruparTarefa(p_idonda);
  
    getNovaTarefa(p_idonda, r_novaTarefa);
  
    v_log := 'As seguintes tarefas de separação da onda (idOnda: ' ||
             p_idonda || ') foram agrupadas: ';
    for c_identificadores in (select idselecionado identificador
                                from gtt_selecao g)
    loop
      agruparSubPedido(p_idusuario, p_idonda, r_novaTarefa,
                       c_identificadores.identificador);
    
      getCodBarraTarefa(p_idonda, c_identificadores.identificador,
                        v_barraTarefa);
    
      update movimentacao m
         set m.identificador  = r_novaTarefa.identificador,
             m.idlocaldestino = r_novaTarefa.idlocaldestino,
             m.idnotafiscal   = r_novaTarefa.idnotafiscal
       where m.idonda = p_idonda
         and m.identificador = c_identificadores.identificador
         and m.status = 0;
    
      v_log := v_log || '(' || v_barraTarefa || ')';
    end loop;
  
    pk_onda.getTotalMovTotalNF(r_novaTarefa.idonda, v_totalmov, v_totalnf);
    if (v_totalmov <> v_totalnf) then
      v_msg := t_message('A QUANTIADE TOTAL EM NOTAS FISCAIS NÃO CONFERE COM A QUANTIDADE TOTAL EM MOVIMENTAÇÕES. OPERAÇÕES CANCELADAS.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select sum(m.quantidade) total
      into v_qtdeSaidaPorNf
      from movimentacao m
     where m.idonda = p_idonda
       and m.etapa = 1
       and m.status in (0, 1, 2, 4)
       and m.idnotafiscal = r_novaTarefa.idnotafiscal;
  
    update saidapornf s
       set s.totalseparar  = v_qtdeSaidaPorNf,
           s.totalconferir = v_qtdeSaidaPorNf,
           s.totalpesar    = v_qtdeSaidaPorNf
     where s.idnotafiscal = r_novaTarefa.idnotafiscal
       and s.idonda = p_idonda;
  
    getCodBarraTarefa(p_idonda, r_novaTarefa.identificador, v_barraTarefa);
  
    select *
      into r_usuario
      from usuario u
     where u.idusuario = p_idusuario;
  
    v_log := v_log || '. A tarefa ' || v_barraTarefa ||
             ' será utilizada para separação. ' || 'Usuário ' ||
             r_usuario.nomeusuario || ' (idUsuario: ' || p_idusuario || ')';
  
    pk_utilities.GeraLog(p_idusuario, v_log, p_idonda, 'AT');
  
    return r_novaTarefa.identificador;
  end;

  procedure trocarUsuarioSepOndaID
  (
    p_idOnda             in number,
    p_identificador      in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  ) is
    v_msg             t_message;
    v_seppkporestacao number;
  
    procedure trocarUsuarioIdentificador is
    begin
      update movimentacao m
         set m.idusuario = p_idNovoUsuaro
       where m.idonda = p_idOnda
         and m.identificador = p_identificador
         and m.status in (0, 1);
    
      if (sql%rowcount = 0) then
        update separacaoporcarga s
           set s.idusuario = p_idNovoUsuaro
         where s.idonda = p_idOnda
           and s.tarefa = p_identificador
           and s.status in (0, 1);
        if (sql%rowcount = 0) then
          v_msg := t_message('Nenhuma movimentação encontrada para definir usuario de separação da onda por identificador.' ||
                             chr(13) || 'Idonda: {0}' || chr(13) ||
                             'Identificador: {1}' || chr(13) ||
                             'IdNovoUdsuario: {2}');
          v_msg.addParam(p_idOnda);
          v_msg.addParam(p_identificador);
          v_msg.addParam(p_idNovoUsuaro);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
      pk_utilities.GeraLog(p_idUsuarioAlteracao,
                           'DEFINIDO USUARIO PARA SEPARAÇÃO DA ONDA POR IDENTIFICADOR. ' ||
                            CHR(13) || 'IDONDA: ' || p_idOnda || CHR(13) ||
                            'IDENTIFICADOR: ' || p_identificador || CHR(13) ||
                            'USUARIO: ' || p_idNovoUsuaro, p_idOnda, 'SO');
    end trocarUsuarioIdentificador;
  
    procedure trocarUsuarioSepEstacao is
      v_idEstacaoAndamento number;
    begin
      begin
        select idestacao
          into v_idEstacaoAndamento
          from (select m.idonda, rp.codigointerno, el.idestacao, e.ordem,
                        m.identificador,
                        (case
                           when (m.status = 0 and m.idusuario is null) then
                            1
                           when m.qtdeconferida = m.quantidade then
                            2
                           else
                            4
                         end) status
                   from romaneiopai rp, movimentacao m, estacaolocal el,
                        estacao e
                  where m.idonda = rp.idromaneio
                    and el.idendereco = m.idlocalorigem
                    and e.id = el.idestacao
                    and decode(rp.processado, 'N', 0, 1) = 0
                    and rp.statusonda in (2, 4)
                    and m.idonda = p_idOnda
                    and m.identificador = p_identificador
                  group by m.idonda, rp.codigointerno, el.idestacao, e.ordem,
                           m.identificador,
                           (case
                              when (m.status = 0 and m.idusuario is null) then
                               1
                              when m.qtdeconferida = m.quantidade then
                               2
                              else
                               4
                            end))
         group by idonda, codigointerno, idestacao, ordem, identificador
        having sum(status) > 2;
      exception
        when no_data_found then
          v_msg := t_message('Não foi possível realizar a troca de usuário, pois é obrigatório ' ||
                             'que exista estação com separação em andamento para o identificador' ||
                             ' selecionado quando a onda está configurada para Separação por Estação.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      update movimentacao m
         set m.idusuario = p_idNovoUsuaro
       where m.idonda = p_idOnda
         and m.identificador = p_identificador
         and m.status in (0, 1)
         and exists
       (select 1
                from local lo, estacaolocal el
               where lo.id = m.idlocalorigem
                 and el.idendereco = lo.id
                 and el.idestacao = v_idEstacaoAndamento);
    
      pk_utilities.GeraLog(p_idUsuarioAlteracao,
                           'DEFINIDO USUARIO PARA SEPARAÇÃO DA ONDA POR IDENTIFICADOR. ' ||
                            CHR(13) || 'IDONDA: ' || p_idOnda || CHR(13) ||
                            'IDENTIFICADOR: ' || p_identificador || CHR(13) ||
                            'USUARIO: ' || p_idNovoUsuaro || CHR(13) ||
                            'IDESTACAO: ' || v_idEstacaoAndamento, p_idOnda,
                           'SO');
    end trocarUsuarioSepEstacao;
  begin
    select co.seppkporestacao
      into v_seppkporestacao
      from romaneiopai rp, configuracaoonda co
     where co.idconfiguracaoonda = rp.idconfiguracaoonda
       and rp.idromaneio = p_idOnda;
  
    if v_seppkporestacao = 0 then
      trocarUsuarioIdentificador;
    elsif v_seppkporestacao = 1 then
      trocarUsuarioSepEstacao;
    end if;
  end;

  procedure trocarUsuarioSepOndaUSR
  (
    p_idOnda             in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  ) is
    v_msg t_message;
  begin
    update movimentacao m
       set m.idusuario = p_idNovoUsuaro
     where m.idonda = p_idOnda
       and m.status in (0, 1);
  
    if (sql%rowcount = 0) then
      update separacaoporcarga s
         set s.idusuario = p_idNovoUsuaro
       where s.idonda = p_idOnda
         and s.status in (0, 1);
      if (sql%rowcount = 0) then
        v_msg := t_message('Nenhuma movimentação encontrada para definir usuário único de separação da onda.' ||
                           chr(13) || 'Idonda: {0}' || chr(13) ||
                           'IdNovoUdsuario: {1}');
        v_msg.addParam(p_idOnda);
        v_msg.addParam(p_idNovoUsuaro);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  
    pk_utilities.GeraLog(p_idUsuarioAlteracao,
                         'DEFINIDO USUARIO ÚNICO PARA SEPARAÇÃO DA ONDA. ' ||
                          CHR(13) || 'IDONDA: ' || p_idOnda || CHR(13) ||
                          'USUARIO: ' || p_idNovoUsuaro, p_idOnda, 'SO');
  end trocarUsuarioSepOndaUSR;

  procedure trocarUsuarioSepOndaNF
  (
    p_idOnda             in number,
    p_idnotafiscal       in number,
    p_idregiaoorigem     in number,
    p_idregiaodestino    in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  ) is
    v_msg t_message;
  begin
    update movimentacao m
       set m.idusuario = p_idNovoUsuaro
     where m.idonda = p_idOnda
       and m.idnotafiscal = p_idnotafiscal
       and m.status in (0, 1)
       and exists (select 1
              from local lo
             where lo.id = m.idlocalorigem
               and lo.idregiao = p_idregiaoorigem)
       and exists (select 1
              from local ld
             where ld.id = m.idlocaldestino
               and ld.idregiao = p_idregiaodestino);
  
    if (sql%rowcount = 0) then
      v_msg := t_message('Nenhuma movimentação encontrada para definir usuario de separação da onda por nota fiscal.' ||
                         chr(13) || 'Idonda: {0}' || chr(13) ||
                         'IdNotaFiscal: {1}' || chr(13) ||
                         'IdRegiaoOrigem: {2}' || chr(13) ||
                         'IdRegiaoDestino: {3}' || chr(13) ||
                         'IdNovoUdsuario: {4}');
      v_msg.addParam(p_idOnda);
      v_msg.addParam(p_idnotafiscal);
      v_msg.addParam(p_idregiaodestino);
      v_msg.addParam(p_idregiaodestino);
      v_msg.addParam(p_idNovoUsuaro);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_utilities.GeraLog(p_idUsuarioAlteracao,
                         'DEFINIDO USUARIO PARA SEPARAÇÃO DA ONDA POR NOTA FISCAL. ' ||
                          CHR(13) || 'IDONDA: ' || p_idOnda || CHR(13) ||
                          'IDNOTAFISCAL: ' || p_idnotafiscal || CHR(13) ||
                          'IDREGIAOORIGEM: ' || p_idregiaoorigem || CHR(13) ||
                          'IDREGIAODESTINO: ' || p_idregiaodestino ||
                          CHR(13) || 'USUARIO: ' || p_idNovoUsuaro, p_idOnda,
                         'SO');
  end;

  procedure retirarUsuarioSepOndaNF
  (
    p_idOnda             in number,
    p_idnotafiscal       in number,
    p_idregiaoorigem     in number,
    p_idregiaodestino    in number,
    p_idNovoUsuaro       in number,
    p_idUsuarioAlteracao in number
  ) is
    v_msg t_message;
  begin
    update movimentacao m
       set m.idusuario = null
     where m.idonda = p_idOnda
       and m.idnotafiscal = p_idnotafiscal
       and m.status in (0, 1)
       and exists (select 1
              from local lo
             where lo.id = m.idlocalorigem
               and lo.idregiao = p_idregiaoorigem)
       and exists (select 1
              from local ld
             where ld.id = m.idlocaldestino
               and ld.idregiao = p_idregiaodestino);
  
    if (sql%rowcount = 0) then
      v_msg := t_message('Nenhuma movimentação encontrada para retirar o usuario de separação da onda por nota fiscal.' ||
                         chr(13) || 'Idonda: {0}' || chr(13) ||
                         'IdNotaFiscal: {1}' || chr(13) ||
                         'IdRegiaoOrigem: {2}' || chr(13) ||
                         'IdRegiaoDestino: {3}' || chr(13) ||
                         'IdNovoUdsuario: {4}');
      v_msg.addParam(p_idOnda);
      v_msg.addParam(p_idnotafiscal);
      v_msg.addParam(p_idregiaodestino);
      v_msg.addParam(p_idregiaodestino);
      v_msg.addParam(p_idNovoUsuaro);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_utilities.GeraLog(p_idUsuarioAlteracao,
                         'RETIRADO USUARIO PARA SEPARAÇÃO DA ONDA POR NOTA FISCAL. ' ||
                          CHR(13) || 'IDONDA: ' || p_idOnda || CHR(13) ||
                          'IDNOTAFISCAL: ' || p_idnotafiscal || CHR(13) ||
                          'IDREGIAOORIGEM: ' || p_idregiaoorigem || CHR(13) ||
                          'IDREGIAODESTINO: ' || p_idregiaodestino ||
                          CHR(13) || 'USUARIO: ' || p_idNovoUsuaro, p_idOnda,
                         'SO');
  end;

  function getCountMovDasEtapasAnterior
  (
    p_idOnda          number,
    p_isBufferOrigem  number,
    p_tipoOrigem      number,
    p_isBufferDestino number,
    p_tipoDestino     number
  ) return number is
    v_count number;
  begin
    select count(1)
      into v_count
      from dual
     where exists (select 1
              from movimentacao m, local lo, local ld,
                   regiaoarmazenagem ro, regiaoarmazenagem rd
             where m.idonda = p_idOnda
               and lo.id = m.idlocalorigem
               and lo.idregiao = ro.idregiao
               and decode(lo.buffer, 'N', 0, 1) = p_isBufferOrigem
               and ro.tipo = p_tipoOrigem
               and ld.id = m.idlocaldestino
               and ld.idregiao = rd.idregiao
               and decode(ld.buffer, 'N', 0, 1) = p_isBufferDestino
               and rd.tipo = p_tipoDestino
               and m.id in (select m.id
                              from movimentacao mv, grupomovimentacao g
                             where mv.id = g.idgrupo
                               and g.idmovimentacao = m.id
                               and mv.etapa < m.etapa
                               and mv.status in (0, 1)));
  
    return v_count;
  
  end getCountMovDasEtapasAnterior;

  procedure finalizarEntregaParcial
  (
    p_idOnda          in number,
    p_idRegiaoDestino in number,
    p_idLocalOrigem   in number,
    p_bufferDestino   in number,
    p_codBarraTarefa  in varchar2,
    p_identificador   in number,
    p_idUsuario       in number,
    p_idProduto       in number
  ) is
    v_existeMovPend number;
    v_msg           t_message;
  
    procedure moverEstoque(p_idmov in number) is
      v_idArmazem       number;
      v_idLocalOrigem   local.idlocal%type;
      v_idLocalDestino  local.idlocal%type;
      v_idlote          number;
      v_idusuario       number;
      v_idonda          number;
      v_qtdemovimentada number;
      v_qtdeUtilzada    number;
      v_qtdeSeparada    number;
      v_qtdeRetAdic     number;
    begin
      select lo.idarmazem, lo.idlocal, ld.idlocal, m.idlote,
             m.qtdemovimentada, m.quantidade, m.qtdeconferida, m.idusuario,
             m.idonda
        into v_idArmazem, v_idLocalOrigem, v_idLocalDestino, v_idlote,
             v_qtdemovimentada, v_qtdeUtilzada, v_qtdeSeparada, v_idusuario,
             v_idonda
        from movimentacao m, local lo, local ld
       where m.id = p_idmov
         and lo.id = m.idlocalorigem
         and ld.id = m.idlocaldestino;
    
      pk_estoque.incluir_estoque(v_idArmazem, v_idLocalDestino, v_idlote,
                                 v_qtdemovimentada, v_idusuario,
                                 'MOVIMENTACAO EXECUTADA, ADICIONADO ESTOQUE PARA MOVIMENTACAO:' ||
                                  p_idmov || ', DA ONDA ID:' || v_idonda,
                                 'N', p_idmov);
    
      if (v_qtdeSeparada > 0) then
      
        pk_estoque.incluir_pendencia(v_idArmazem, v_idLocalDestino,
                                     v_idlote, v_qtdeSeparada, v_idusuario,
                                     'MOVIMENTACAO EXECUTADA, ADICIONADO PENDENCIA PARA MOVIMENTACAO:' ||
                                      p_idmov || ', DA ONDA ID:' || v_idonda,
                                     p_idmov);
      end if;
    
      v_qtdeRetAdic := v_qtdemovimentada - v_qtdeUtilzada;
      if (v_qtdeRetAdic > 0) then
        pk_estoque.retirar_pendencia(v_idArmazem, v_idLocalDestino,
                                     v_idlote, v_qtdeRetAdic, v_idusuario,
                                     'MOVIMENTACAO EXECUTADA, RETIRADO PENDENCIA PARA MOVIMENTACAO:' ||
                                      p_idmov || ', DA ONDA ID:' || v_idonda,
                                     p_idmov);
      
        pk_estoque.retirar_adicionar(v_idArmazem, v_idLocalDestino,
                                     v_idlote, v_qtdeRetAdic, v_idusuario,
                                     'MOVIMENTACAO EXECUTADA, ADICIONADO PENDENCIA PARA MOVIMENTACAO:' ||
                                      p_idmov || ', DA ONDA ID:' || v_idonda,
                                     p_idmov);
      end if;
    
      pk_estoque.retirar_pendencia(v_idArmazem, v_idLocalOrigem, v_idlote,
                                   v_qtdemovimentada, v_idusuario,
                                   'MOVIMENTACAO EXECUTADA, RETIRADO PENDENCIA PARA MOVIMENTACAO:' ||
                                    p_idmov || ', DA ONDA ID:' || v_idonda,
                                   p_idmov);
    
      pk_estoque.retirar_estoque(v_idArmazem, v_idLocalOrigem, v_idlote,
                                 v_qtdemovimentada, v_idusuario,
                                 'MOVIMENTACAO EXECUTADA, RETIRADO ESTOQUE PARA MOVIMENTACAO:' ||
                                  p_idmov || ', DA ONDA ID:' || v_idonda,
                                 'N', p_idmov);
    
    end moverEstoque;
  
    -- Refactored procedure baixarMovimentacaoParcial 
    procedure baixarMovimentacaoParcial(p_idMovParcial in number) is
      r_movNovaSeparada     movimentacao%rowtype;
      v_idmovimentacaogrupo number;
      v_qtdemov             number;
      r_movAtualAtualizada  movimentacao%rowtype;
      r_movNovaASeparar     movimentacao%rowtype;
      v_qtdeutilizada       number;
    begin
      select m.*
        into r_movAtualAtualizada
        from movimentacao m
       where m.id = p_idMovParcial;
    
      r_movNovaSeparada                 := r_movAtualAtualizada;
      r_movNovaSeparada.qtdemovimentada := r_movAtualAtualizada.qtdeconferida;
    
      if (r_movAtualAtualizada.quantidade >=
         r_movAtualAtualizada.qtdeconferida) then
        r_movNovaSeparada.quantidade := r_movAtualAtualizada.qtdeconferida;
      end if;
    
      r_movNovaSeparada.qtdeconferida := r_movAtualAtualizada.qtdeconferida;
      v_idmovimentacaogrupo           := pk_onda.inserirMovimentacao(r_movNovaSeparada,
                                                                     v_idmovimentacaogrupo);
    
      moverEstoque(v_idmovimentacaogrupo);
    
      update movimentacao
         set status        = 2,
             datatermino   = sysdate,
             idusuario     = p_idUsuario,
             tiposeparacao = 2
       where id = v_idmovimentacaogrupo;
    
      v_qtdemov := r_movAtualAtualizada.qtdemovimentada -
                   r_movAtualAtualizada.qtdeconferida;
      if (v_qtdemov <= 0) then
        v_msg := t_message('A quantidade calculada para entrega parcial é inválida.' ||
                           chr(13) || 'IDMOVIMENTACAO: {0}' || chr(13) ||
                           'IDNOTAFISCAL: {1}');
        v_msg.addParam(r_movAtualAtualizada.Id);
        v_msg.addParam(r_movAtualAtualizada.Idnotafiscal);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      r_movNovaASeparar                 := r_movAtualAtualizada;
      r_movNovaASeparar.qtdemovimentada := v_qtdemov;
    
      v_qtdeutilizada := r_movAtualAtualizada.quantidade -
                         r_movAtualAtualizada.qtdeconferida;
    
      if (v_qtdeutilizada < 0) then
        r_movNovaASeparar.quantidade := 0;
      else
        r_movNovaASeparar.quantidade := v_qtdeutilizada;
      end if;
    
      r_movNovaASeparar.qtdeconferida := 0;
      r_movNovaASeparar.status        := 0;
      r_movNovaASeparar.datainicio    := null;
      r_movNovaASeparar.tiposeparacao := 0;
      v_idmovimentacaogrupo           := pk_onda.inserirMovimentacao(r_movNovaASeparar,
                                                                     v_idmovimentacaogrupo);
    
      update movimentacao m
         set m.status             = 3,
             m.motivocancelamento = 'ENTREGA PARCIAL DE PRODUTOS'
       where m.id = p_idMovParcial;
    end baixarMovimentacaoParcial;
  begin
    select count(*)
      into v_existeMovPend
      from v_tarefas_onda m, local ld, lote lt
     where m.idonda = p_idOnda
       and m.status = 1
       and ld.idregiao = p_idRegiaoDestino
       and m.idlocalorigem = p_idLocalOrigem
       and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
       and ld.id = m.idlocaldestino
       and m.codbarratarefa =
           decode(p_codBarraTarefa, null, m.codbarratarefa, p_codBarraTarefa)
       and m.identificador =
           decode(p_identificador, 0, m.identificador, p_identificador)
       and lt.idlote = m.idlote
       and lt.idproduto = decode(p_idProduto, 0, lt.idproduto, p_idProduto);
  
    if (v_existeMovPend = 0) then
      v_msg := t_message('Nenhuma movimentação separada pendente de entrega. Local de separação atual: ' ||
                         'idonda={0}, idusuario={1}, idlocalorigem=' ||
                         '{2}, idregiaodestino={3}, bufferdestino=' ||
                         '{4}, codbarratarefa={5}, identificador={6}');
      v_msg.addParam(p_idOnda);
      v_msg.addParam(p_idusuario);
      v_msg.addParam(p_idLocalOrigem);
      v_msg.addParam(p_idRegiaoDestino);
      v_msg.addParam(p_bufferDestino);
      v_msg.addParam(p_codBarraTarefa);
      v_msg.addParam(p_identificador);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_movpend in (select m.*
                        from v_tarefas_onda m, local ld, lote lt
                       where m.idonda = p_idOnda
                         and m.status = 1
                         and ld.idregiao = p_idRegiaoDestino
                         and m.idlocalorigem = p_idLocalOrigem
                         and decode(ld.buffer, 'N', 0, 1) = p_bufferDestino
                         and ld.id = m.idlocaldestino
                         and m.codbarratarefa =
                             decode(p_codBarraTarefa, null, m.codbarratarefa,
                                    p_codBarraTarefa)
                         and m.identificador =
                             decode(p_identificador, 0, m.identificador,
                                    p_identificador)
                         and lt.idlote = m.idlote
                         and lt.idproduto =
                             decode(p_idProduto, 0, lt.idproduto, p_idProduto)
                       order by m.qtdemovimentada)
    loop
      if (c_movpend.qtdemovimentada = c_movpend.qtdeconferida) then
        moverEstoque(c_movpend.id);
      
        update movimentacao
           set status        = 2,
               datatermino   = sysdate,
               idusuario     = p_idUsuario,
               tiposeparacao = 2
         where id = c_movpend.id;
      else
        baixarMovimentacaoParcial(c_movpend.id);
      end if;
    end loop;
  end;

  procedure inserirSeparacaoBufferColmeia
  (
    p_idOnda           in number,
    p_idLocalOrigem    in number,
    p_barra            in varchar2,
    p_qtdeSeparada     in number,
    p_idCaixaSeparacao in number,
    p_idUsuario        in number,
    p_Identificador    in number,
    p_codTarefa        in varchar2
  ) is
    v_codigoInterno  produto.codigointerno%type;
    v_descrProduto   produto.descr%type;
    v_fatorConversao number;
    v_idproduto      number;
    v_msg            t_message;
    procedure validarBarraInformada is
    begin
      begin
        select e.fatorconversao, p.idproduto, p.codigointerno, p.descr
          into v_fatorConversao, v_idproduto, v_codigoInterno,
               v_descrProduto
          from movimentacao m, lote lt, embalagem e, produto p,
               caixaseparacao cx, colmeia co, escaninho es
         where m.idonda = p_idonda
           and m.idlocalorigem = p_idLocalOrigem
           and es.idendereco = m.idlocaldestino
           and co.idcolmeia = es.idcolmeia
           and cx.idcolmeia = co.idcolmeia
           and cx.idcaixaseparacao = p_idcaixaSeparacao
           and lt.idlote = m.idlote
           and p.idproduto = lt.idproduto
           and e.idproduto = p.idproduto
           and e.barra = p_barra
         group by e.fatorconversao, p.idproduto, p.codigointerno, p.descr;
      exception
        when no_data_found then
          v_msg := t_message('Não encontrado nenhum produto com barra correspondente à {0}');
          v_msg.addParam(p_barra);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end validarBarraInformada;
  
    procedure validarMovimentacaoPendente is
      v_qtdRestante number;
      v_corColmeia  colmeia.cor%type;
    begin
      begin
        select (sum(m.qtdemovimentada) - sum(m.qtdeconferida))
          into v_qtdRestante
          from movimentacao m, lote lt, caixaseparacao cx, colmeia co,
               escaninho es
         where m.idonda = p_idOnda
           and m.status in (0, 1)
           and m.idlocalorigem = p_idlocalorigem
           and es.idendereco = m.idlocaldestino
           and co.idcolmeia = es.idcolmeia
           and cx.idcolmeia = co.idcolmeia
           and cx.idcaixaseparacao = p_idCaixaSeparacao
           and lt.idlote = m.idlote
           and lt.idproduto = v_idproduto
         group by lt.idlote, lt.idproduto;
        if (v_qtdRestante < (p_qtdeSeparada * v_fatorConversao)) then
          select co.cor
            into v_corColmeia
            from caixaseparacao cx, colmeia co
           where cx.idcaixaseparacao = p_idCaixaSeparacao
             and co.idcolmeia = cx.idcolmeia;
          v_msg := t_message('Não existe quantidade suficiente de separação pendente do buffer com destino à colmeia ' ||
                             '{0} para o produto {1}-{2}' || chr(13) ||
                             '. Qtde. Solicitada {3}');
          v_msg.addParam(v_corColmeia);
          v_msg.addParam(v_codigoInterno);
          v_msg.addParam(v_descrProduto);
          v_msg.addParam(p_qtdeSeparada * v_fatorConversao);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      exception
        when no_data_found then
          select co.cor
            into v_corColmeia
            from caixaseparacao cx, colmeia co
           where cx.idcaixaseparacao = p_idCaixaSeparacao
             and co.idcolmeia = cx.idcolmeia;
          v_msg := t_message('Não existe separação pendente do buffer com destino à colmeia ' ||
                             '{0} para o produto {1}-{2}.');
          v_msg.addParam(v_corColmeia);
          v_msg.addParam(v_codigoInterno);
          v_msg.addParam(v_descrProduto);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
    end validarMovimentacaoPendente;
  
    procedure validarCaixaEmUso is
      v_isCaixaLiberada      number;
      v_isCaixaUsadaOutraSep number;
      v_barraCaixa           caixaseparacao.barra%type;
      v_corCaixa             caixaseparacao.cor%type;
    begin
      select cx.liberado
        into v_isCaixaLiberada
        from caixaseparacao cx
       where cx.idcaixaseparacao = p_idcaixaSeparacao;
    
      if (v_isCaixaLiberada = 0) then
        select count(1)
          into v_isCaixaUsadaOutraSep
          from SepBufferColmeia seb
         where seb.idonda = p_idonda
           and (seb.idlocalorigem <> p_idlocalOrigem)
           and seb.idcaixaseparacao = p_idcaixaseparacao
           and seb.entreguenacolmeia = 0;
      
        if (v_isCaixaUsadaOutraSep > 0) then
          select cx.cor, cx.barra
            into v_corCaixa, v_barraCaixa
            from caixaseparacao cx
           where cx.idcaixaseparacao = p_idCaixaSeparacao;
        
          v_msg := t_message('A Caixa de Separação {0}-{1} não está liberada para uso.');
          v_msg.addParam(v_corCaixa);
          v_msg.addParam(v_barraCaixa);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    
    end validarCaixaEmUso;
  
    procedure distribuirQuantidades is
      cursor c_movimentacoes
      (
        p_idOndaEmExecucao in number,
        p_idlocorigem      in number,
        p_idCxSep          in number,
        p_idproduto        in number,
        p_identificador    in number,
        p_codTarefa        in varchar2
      ) is
        select t.id, t.idlocalOrigem, t.idlocalDestino, lt.idlote,
               lt.idproduto, t.qtdemovimentada, t.qtdeconferida,
               t.idnotafiscal, t.IDENTIFICADOR, t.codbarratarefa
          from v_tarefas_onda t, lote lt, caixaseparacao cx, colmeia co,
               escaninho es
         where t.idonda = p_idOndaEmExecucao
           and t.status in (0, 1)
           and decode(p_identificador, 0, 1, t.IDENTIFICADOR) =
               decode(p_identificador, 0, 1, p_identificador)
           and decode(p_codTarefa, null, 1, t.codbarratarefa) =
               decode(p_codTarefa, null, 1, p_codTarefa)
           and t.idlocalorigem = p_idlocorigem
           and es.idendereco = t.idlocaldestino
           and co.idcolmeia = es.idcolmeia
           and cx.idcolmeia = co.idcolmeia
           and cx.idcaixaseparacao = p_idCxSep
           and lt.idlote = t.idlote
           and lt.idproduto = p_idproduto;
    
      r_movimentacoes  c_movimentacoes%rowtype;
      v_qtdADistribuir number;
      v_qtdeUtzDaMov   number;
    begin
      v_qtdADistribuir := (P_qtdeSeparada * V_fatorConversao);
      open c_movimentacoes(p_idOnda, p_idlocalorigem, p_idCaixaSeparacao,
                           v_idproduto, p_identificador, p_codTarefa);
      fetch c_movimentacoes
        into r_movimentacoes;
    
      while (c_movimentacoes%found AND v_qtdADistribuir > 0)
      loop
        if ((r_movimentacoes.qtdemovimentada -
           r_movimentacoes.qtdeconferida) <= v_qtdADistribuir) then
          v_qtdeUtzDaMov := (r_movimentacoes.qtdemovimentada -
                            r_movimentacoes.qtdeconferida);
        else
          v_qtdeUtzDaMov := v_qtdADistribuir;
        end if;
      
        update movimentacao m
           set m.datainicio    = decode(m.datainicio, null, sysdate,
                                        m.datainicio),
               m.tiposeparacao = 2,
               m.status        = 1,
               m.qtdeconferida = m.qtdeconferida + v_qtdeUtzDaMov,
               m.idusuario     = p_idUsuario
         where m.id = r_movimentacoes.id;
      
        insert into SepBufferColmeia
          (Idcaixaseparacao, Idonda, IDNOTAFISCAL, Idlote, Idlocalorigem,
           Idlocaldestino, Qtdseparada, Dtseparacao, Idusuarioseparacao,
           identificadorSeparacao, codbarratarefa, barraseparacao)
        values
          (p_idCaixaSeparacao, p_idonda, r_movimentacoes.idnotafiscal,
           r_movimentacoes.idlote, r_movimentacoes.idlocalorigem,
           r_movimentacoes.idlocaldestino, v_qtdeUtzDaMov, sysdate,
           p_idusuario, r_movimentacoes.identificador,
           r_movimentacoes.codbarratarefa, p_barra);
      
        update caixaseparacao cx
           set cx.liberado     = 0,
               cx.codigotarefa = p_idonda
         where cx.idcaixaseparacao = p_idCaixaSeparacao;
      
        insert into conteudocarrinho
          (id, idmovimentacao, idusuario, qtde, carrinhocheio,
           idcaixaseparacao)
        values
          (seq_conteudocarrinho.nextval, r_movimentacoes.id, p_idusuario,
           v_qtdeUtzDaMov, 'N', p_idcaixaseparacao);
      
        v_qtdADistribuir := v_qtdADistribuir - v_qtdeUtzDaMov;
        fetch c_movimentacoes
          into r_movimentacoes;
      end loop;
    
      close c_movimentacoes;
    
      if (v_qtdADistribuir > 0) then
        v_msg := t_message('Não existe quantidade suficiente para atender a separação de {0}' ||
                           ' itens com fator de conversão {1} do produto {2}-{3}.');
        v_msg.addParam(P_qtdeSeparada);
        v_msg.addParam(V_fatorConversao);
        v_msg.addParam(v_codigoInterno);
        v_msg.addParam(v_descrProduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end distribuirQuantidades;
  begin
    validarBarraInformada;
    validarCaixaEmUso;
    validarMovimentacaoPendente;
    distribuirQuantidades;
  end inserirSeparacaoBufferColmeia;

  procedure entregarSeparacaoBufferColmeia
  (
    p_idOnda           in number,
    p_idRegiaoOrigem   in number,
    p_idCaixaSeparacao in number,
    p_idUsuario        in number,
    p_idColmeia        in number
  ) is
    v_msg t_message;
  
    procedure validarUsuario is
      v_IdUsuarioSeparacao   number;
      v_NomeUsuarioSeparacao usuario.nomeusuario%type;
      v_msg                  t_message;
    begin
      begin
        select u.idusuario, u.nomeusuario
          into v_IdUsuarioSeparacao, v_NomeUsuarioSeparacao
          from sepbuffercolmeia seb, usuario u, local lo
         where seb.entreguenacolmeia = 0
           and lo.id = seb.idlocalOrigem
           and lo.idregiao = p_idRegiaoOrigem
           and seb.idonda = p_idOnda
           and seb.idcaixaseparacao = p_idCaixaSeparacao
           and u.idusuario = seb.idusuarioseparacao
           and rownum = 1;
      
        if (v_IdUsuarioSeparacao <> p_idUsuario) then
          v_msg := t_message('Esta separação foi iniciada pelo usuário {0} e deverá ser entregue pelo mesmo.');
          v_msg.addParam(v_NomeUsuarioSeparacao);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      exception
        when no_data_found then
          v_msg := t_message('Não foi encontrada separação pendente para entrega.' ||
                             chr(13) || 'IdOnda: {0}' || chr(13) ||
                             'Id Região de Origem: {1}');
          v_msg.addParam(p_idonda);
          v_msg.addParam(p_idRegiaoOrigem);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end validarUsuario;
  
    procedure validarSeparacao is
      v_qtdeJaConferida number;
    begin
      select count(1)
        into v_qtdeJaConferida
        from sepbuffercolmeia seb, caixaseparacao cx, escaninho e,
             movimentacao m, local lo
       where seb.idonda = p_idonda
         and lo.id = seb.idlocalorigem
         and lo.idregiao = p_idRegiaoOrigem
         and seb.idusuarioseparacao = p_idUsuario
         and seb.idcaixaseparacao = p_idCaixaSeparacao
         and seb.entreguenacolmeia = 0
         and cx.idcaixaseparacao = seb.idcaixaseparacao
         and m.idonda = seb.idonda
         and m.idnotafiscal = seb.idnotafiscal
         and m.idusuario = seb.idusuarioseparacao
         and m.status = 1
         and e.idendereco = m.idlocaldestino
         and e.idcolmeia = cx.idcolmeia;
    
      if (v_qtdeJaConferida = 0) then
        v_msg := t_message('Não foi encontrada separação pendente para entrega.' ||
                           chr(13) || 'IdOnda: {0}' || chr(13) ||
                           'Id Região de Origem: {1}');
        v_msg.addParam(p_idonda);
        v_msg.addParam(p_idRegiaoOrigem);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarSeparacao;
  
    procedure validarColmeia is
      v_IsColmeiaValida number;
      v_barraCaixa      caixaseparacao.barra%type;
      v_corColmeia      colmeia.cor%type;
    begin
      select count(1)
        into v_IsColmeiaValida
        from movimentacao m, sepbuffercolmeia seb, escaninho e,
             caixaseparacao cx, local lo
       where m.idonda = p_idonda
         and m.status = 1
         and lo.id = m.idlocalorigem
         and lo.idregiao = p_idRegiaoOrigem
         and e.idendereco = m.idlocaldestino
         and seb.idonda = m.idonda
         and seb.idnotafiscal = m.idnotafiscal
         and seb.idusuarioseparacao = p_idusuario
         and seb.entreguenacolmeia = 0
         and seb.idcaixaseparacao = p_idCaixaSeparacao
         and cx.idcaixaseparacao = seb.idcaixaseparacao
         and e.idcolmeia = cx.idcolmeia
         and e.idcolmeia = p_idColmeia;
    
      if (v_IsColmeiaValida = 0) then
        select cx.barra, c.cor
          into v_barraCaixa, v_corColmeia
          from caixaseparacao cx, colmeia c
         where cx.idcaixaseparacao = p_idCaixaSeparacao
           and c.idcolmeia = cx.idcolmeia;
      
        v_msg := t_message('A colmeia informada não é válida para realizar a entrega da separação da caixa {0}-{1}.');
        v_msg.addParam(v_corColmeia);
        v_msg.addParam(v_barraCaixa);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarColmeia;
  
    procedure realizarEntrega is
    begin
      for r_entrega in (select distinct seb.idonda,
                                        ld.idregiao idRegiaoDestino,
                                        seb.idlocalorigem,
                                        decode(ld.buffer, 'N', 0, 1) bufferDestino,
                                        seb.identificadorseparacao,
                                        seb.codbarratarefa,
                                        seb.idusuarioseparacao, lt.idproduto,
                                        lt.idlote
                          from sepbuffercolmeia seb, movimentacao m, local ld,
                               lote lt
                         where seb.idonda = p_idonda
                           and seb.idusuarioseparacao = p_idusuario
                           and seb.idcaixaseparacao = p_idcaixaseparacao
                           and seb.entreguenacolmeia = 0
                           and m.idonda = seb.idonda
                           and m.idlote = seb.idlote
                           and m.idnotafiscal = seb.idnotafiscal
                           and m.idlocalorigem = seb.idlocalorigem
                           and m.idlocaldestino = seb.idlocaldestino
                           and ld.id = m.idlocaldestino
                           and lt.idlote = m.idlote)
      loop
      
        finalizarEntregaParcial(r_entrega.idonda, r_entrega.idRegiaoDestino,
                                r_entrega.idLocalOrigem,
                                r_entrega.bufferDestino,
                                r_entrega.codBarraTarefa,
                                r_entrega.identificadorseparacao,
                                r_entrega.Idusuarioseparacao,
                                r_entrega.idProduto);
      
        update sepbuffercolmeia seb
           set seb.entreguenacolmeia = 1,
               seb.dtentregacolmeia  = sysdate
         where seb.idonda = r_entrega.idonda
           and seb.idlote = r_entrega.idlote
           and seb.idlocalorigem = r_entrega.idlocalorigem;
      end loop;
    
    end realizarEntrega;
  begin
    validarUsuario;
    validarColmeia;
    validarSeparacao;
    realizarEntrega;
  end entregarSeparacaoBufferColmeia;

  procedure inserirAtividadePackingColetor
  (
    p_idArmazem    in number,
    p_idOnda       in number default null,
    p_idNotaFiscal in number default null
  ) is
    temAtividade number;
    temArmazem   number;
    v_msg        t_message;
  begin
    temArmazem := p_idArmazem;
  
    if p_idOnda is not null then
      begin
        select rp.idarmazem
          into temArmazem
          from romaneiopai rp
         where rp.idromaneio = p_idOnda;
      exception
        when no_data_found then
          v_msg := t_message('Não foi possível inserir atividade do packing no coletor. Não existe armazém vinculado para a onda: {0}');
          v_msg.addParam(p_idOnda);
          raise_application_error(-20000, v_msg.formatMessage);
        when too_many_rows then
          v_msg := t_message('Não foi possível inserir atividade do packing no coletor. Existe mais de um armazém para a onda: {0}');
          v_msg.addParam(p_idOnda);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end if;
  
    select count(*)
      into temAtividade
      from tipoatividadearmazem t
     where t.idarmazem = temArmazem
       and t.idtipoatividade = C_ATIVIDADE_PACKING_COLETOR;
  
    if temAtividade > 0 then
      pk_convocacao.insereAtividadeArmazem(C_ATIVIDADE_PACKING_COLETOR,
                                           temArmazem, p_idOnda,
                                           p_idNotaFiscal);
    end if;
  end inserirAtividadePackingColetor;

  function retornaTipoConfOnda(p_idOnda number) return number is
    v_tipoOnda number;
    v_msg      t_message;
  begin
    begin
      select co.tipoonda
        into v_tipoOnda
        from romaneiopai rp, configuracaoonda co
       where rp.idromaneio = p_idOnda
         and rp.idconfiguracaoonda = co.idconfiguracaoonda;
    exception
      when no_data_found then
        v_msg := t_message('Não existe configuração de onda cadastrada para a onda: (idOnda: {0})');
        v_msg.addParam(v_tipoOnda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    return v_tipoOnda;
  end retornaTipoConfOnda;

  procedure separacaoBoxOutStation is
    v_msg       t_message;
    v_existe    number;
    v_idusuario usuario.idusuario%type;
  
    cursor c_movimentacoes
    (
      p_caixa         in tipocaixavolume.barra%type,
      p_tarefa        in tarefacaixavolume.tarefa%type,
      p_codigoProduto in produto.codigointerno%type,
      p_localOrigem   in local.idlocal%type,
      p_quantidade    in number
    ) is(
      select m.*, p_quantidade quantidadeParaSeparar
        from v_tarefas_onda m, tarefacaixavolume t, tipocaixavolume cx,
             lote lt, produto p, local lo, romaneiopai rp,
             configuracaoonda co
       where pk_utilities.composicaoidentificacaoEnd(lo.idarmazem,
                                                     lo.idlocal,
                                                     rp.idconfiguracaoonda) =
             lpad(p_localOrigem,
                  decode((co.blocoqtdcaracter + co.ruaqtdcaracter +
                          co.predioqtdcaracter + co.andarqtdcaracter +
                          co.apartamentoqtdcaracter), 0, length(lo.idlocal),
                          (co.blocoqtdcaracter + co.ruaqtdcaracter +
                           co.predioqtdcaracter + co.andarqtdcaracter +
                           co.apartamentoqtdcaracter)), '0')
         and m.idonda = rp.idromaneio
         and rp.idconfiguracaoonda = co.idconfiguracaoonda
         and lo.id = m.idlocalorigem
         and p.codigointerno = p_codigoProduto
         and p.idproduto = lt.idproduto
         and lt.idlote = m.idlote
         and cx.barra = p_caixa
         and cx.retornavel = 1
         and cx.disponivel = 0
         and cx.emusosistematerceiro = 1
         and cx.idonda = m.idonda
         and cx.idtipocaixavolume = t.idtipocaixavolume
         and t.tarefa = p_tarefa
         and t.idonda = m.idonda
         and t.tarefa = m.codbarratarefa
         and m.status in (0, 1)
         and m.qtdemovimentada - nvl(m.qtdeconferida, 0) > 0);
  
    r_movimentacoes c_movimentacoes%rowtype;
  
    procedure distribuirQuantidadeSeparada is
      v_saldo number;
    begin
      v_saldo := null;
    
      while (c_movimentacoes%found)
      loop
        if (r_movimentacoes.quantidadeParaSeparar < 0) then
          v_msg := t_message('Quantidade solicitada para separação inválida.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        if ((r_movimentacoes.qtdemovimentada -
           r_movimentacoes.qtdeconferida) >
           nvl(v_saldo, r_movimentacoes.quantidadeParaSeparar)) then
          update movimentacao m
             set m.qtdeconferida = m.qtdeconferida +
                                   nvl(v_saldo,
                                       r_movimentacoes.quantidadeParaSeparar),
                 m.status        = 1,
                 m.idusuario     = v_idusuario,
                 m.datainicio    = sysdate
           where m.id = r_movimentacoes.id;
          return;
        end if;
      
        if ((r_movimentacoes.qtdemovimentada -
           r_movimentacoes.qtdeconferida) =
           nvl(v_saldo, r_movimentacoes.quantidadeParaSeparar)) then
          update movimentacao m
             set m.qtdeconferida = m.qtdeconferida +
                                   nvl(v_saldo,
                                       r_movimentacoes.quantidadeParaSeparar),
                 m.status        = 1,
                 m.idusuario     = v_idusuario,
                 m.datainicio    = sysdate
           where m.id = r_movimentacoes.id;
          return;
        end if;
      
        if ((r_movimentacoes.qtdemovimentada -
           r_movimentacoes.qtdeconferida) <
           nvl(v_saldo, r_movimentacoes.quantidadeParaSeparar)) then
          update movimentacao m
             set m.qtdeconferida = r_movimentacoes.qtdemovimentada,
                 m.status        = 1,
                 m.idusuario     = v_idusuario,
                 m.datainicio    = sysdate
           where m.id = r_movimentacoes.id;
        end if;
      
        v_saldo := nvl(v_saldo, r_movimentacoes.quantidadeParaSeparar) -
                   (r_movimentacoes.qtdemovimentada -
                    r_movimentacoes.qtdeconferida);
      
        fetch c_movimentacoes
          into r_movimentacoes;
      end loop;
    
      if (nvl(v_saldo, 0) > 0) then
        v_msg := t_message('Solicitada quantidade de separação, maior que a planejada.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end distribuirQuantidadeSeparada;
  
  begin
    select count(*)
      into v_existe
      from gtt_boxOutStation g;
  
    if (v_existe = 0) then
      v_msg := t_message('Não foram enviadas as informações referente ao processo box out station.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for r_gtt in (select *
                    from gtt_boxoutstation)
    loop
      if (c_movimentacoes%isopen) then
        close c_movimentacoes;
      end if;
    
      open c_movimentacoes(r_gtt.numcaixaplastica, r_gtt.numpicking,
                           r_gtt.codigosku, r_gtt.posicaoestoque,
                           r_gtt.quantidade);
      fetch c_movimentacoes
        into r_movimentacoes;
    
      if (c_movimentacoes%notfound) then
        v_msg := t_message('Movimentações não localizadas ou Quantidade excedida na iniciação da separação box out station.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      begin
        select u.idusuario
          into v_idusuario
          from usuario u
         where u.nomeusuario = upper(r_gtt.operador)
           and u.ativo = 'S';
      exception
        when no_data_found then
          v_msg := t_message('Usuário ' || r_gtt.operador ||
                             ' não encontrado ou não está ativo no WMS.');
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      distribuirQuantidadeSeparada;
    
      update romaneiopai r
         set r.statusonda = 4 -- Onda em execução
       where exists (select 1
                from tarefacaixavolume t
               where t.tarefa = r_gtt.numpicking
                 and t.idonda = r.idromaneio);
    end loop;
  end separacaoBoxOutStation;

  function separacaoBoxDestination
  (
    p_tarefa       tarefacaixavolume.tarefa%type,
    p_caixaVolume  Tipocaixavolume.barra%type,
    p_pontoPLC     pontoplc.pontoplc%type,
    p_mensagemErro in out varchar2
  ) return varchar2 is
  
    v_idonda               number;
    v_idTipocaixaVolume    number;
    v_resultSepOnda        number;
    v_msg                  t_message;
    v_mov                  number := 0;
    v_finalizaSeparacao    pontoplc.finalizaseparacao%type;
    v_desvioSeparacao      pontoplc.desvioseparacao%type;
    v_decidirDesvioEntrega pontoplc.decidirdesvioentrega%type;
    v_retornoPLC           pontoplc.pontoplc%type;
    v_retornoVazio         varchar2(5) := '';
    v_separacaoPkEstacao   configuracaoonda.seppkporestacao%type;
    v_entregaAutoPacking   configuracaoonda.entregaautopacking%type;
  
    SEPARACAO_COM_REAB constant number := 1;
  
    procedure carregarDados is
      v_existePLC number;
    begin
    
      begin
        select count(*)
          into v_existePLC
          from pontoplc plc
         where plc.pontoplc = p_pontoPLC;
      
        if (v_existePLC = 0) then
          v_msg := t_message('Ponto PLC : {0}, não encontrado no cadastro.');
          v_msg.addParam(p_pontoPLC);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        select cx.idonda, cx.idtipocaixavolume, plc.finalizaseparacao,
               plc.desvioseparacao, plc.decidirdesvioentrega,
               cnf.seppkporestacao, cnf.entregaautopacking
          into v_idonda, v_idTipocaixaVolume, v_finalizaSeparacao,
               v_desvioSeparacao, v_decidirDesvioEntrega,
               v_separacaoPkEstacao, v_entregaAutoPacking
          from tarefacaixavolume t, tipocaixavolume cx, romaneiopai r,
               configuracaoonda cnf, pontoplc plc
         where t.tarefa = p_tarefa
           and cx.barra = p_caixaVolume
           and plc.idconfiguracaoonda = cnf.idconfiguracaoonda
           and plc.pontoplc = p_pontoPLC
           and cx.idtipocaixavolume = t.idtipocaixavolume
           and r.idromaneio = cx.idonda
           and cnf.idconfiguracaoonda = r.idconfiguracaoonda;
      exception
        when no_data_found then
          v_msg := t_message('Não foi localizada expedição para a tarefa {0} e caixa {1} vinculada ao PLC {2} ');
          v_msg.addParam(p_tarefa);
          v_msg.addParam(p_caixaVolume);
          v_msg.addParam(p_pontoPLC);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    end carregarDados;
  
    procedure verificaCorteFisico is
    begin
      pk_cortefisico.registrarCorteFisicoCaixa(v_idonda,
                                               v_idTipocaixaVolume);
    end verificaCorteFisico;
  
    procedure finalizaSeparacao is
    begin
      for r_sep in (select v.idusuario, ro.idregiao idRegiaoOrigem,
                           decode(lo.buffer, 'S', 1, 0) bufferOrigem,
                           rd.idregiao idRegiaoDestino,
                           decode(ld.buffer, 'S', 1, 0) bufferDestino,
                           v.identificador, v.idnotafiscal,
                           ld.idlocal localDestino
                      from v_tarefas_onda v, local lo, local ld,
                           regiaoarmazenagem ro, regiaoarmazenagem rd
                     where v.idonda = v_idonda
                       and v.codbarratarefa = p_tarefa
                       and lo.id = v.idlocalorigem
                       and ld.id = v.idlocaldestino
                       and ro.idregiao = lo.idregiao
                       and rd.idregiao = ld.idregiao
                     group by v.idusuario, v.idonda, ro.idregiao,
                              decode(lo.buffer, 'S', 1, 0), rd.idregiao,
                              decode(ld.buffer, 'S', 1, 0), v.identificador,
                              v.idnotafiscal, ld.idlocal)
      loop
      
        v_resultSepOnda := pk_seponda.finalizarSepOnda(r_sep.idusuario,
                                                       v_idonda,
                                                       r_sep.idRegiaoOrigem,
                                                       r_sep.bufferOrigem,
                                                       r_sep.idRegiaoDestino,
                                                       r_sep.bufferDestino,
                                                       r_sep.identificador,
                                                       r_sep.idnotafiscal);
      
        if (v_resultSepOnda = SEPARACAO_COM_REAB) then
          v_msg := t_message('Necessita-se reabastecer os pickings antes de finalizar a separação.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
        v_mov := 1;
      
      end loop;
    
      if (v_mov = 0) then
        v_msg := t_message('Não existem movimentações pendentes para finalização.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_retornoPLC := v_desvioSeparacao;
    end finalizaSeparacao;
  
    procedure decidirDesvioEntrega is
    begin
      begin
        select distinct e.desvioesteiraptl
          into v_retornoPLC
          from v_tarefas_onda v, notafiscal nf, entidade e
         where v.codbarratarefa = p_tarefa
           and nf.idnotafiscal = v.idnotafiscal
           and e.identidade = nf.ident_entrega;
      exception
        when no_data_found then
          v_retornoPLC := v_retornoVazio;
      end;
    
    end decidirDesvioEntrega;
  
    function isTarefaSeparada return boolean is
      v_isTarefaSep number;
    begin
      begin
        select count(1)
          into v_isTarefaSep
          from dual
         where exists (select 1
                  from v_tarefas_onda m
                 where m.status in (0, 1, 2)
                   and m.qtdeconferida < m.qtdemovimentada
                   and m.idonda = v_idonda
                   and m.codbarratarefa = p_tarefa);
      exception
        when no_data_found then
          v_isTarefaSep := 0;
      end;
      return v_isTarefaSep = 0;
    end isTarefaSeparada;
  
    procedure conferirGerarVolumeAuto(p_idonda romaneiopai.idromaneio%type) is
      v_confereAuto configuracaoonda.gerarconferenciavolume%type;
    
      C_GERA_CONF_VOL constant number := 1;
      C_PTL           constant number := 1;
    begin
      begin
        select conf.gerarconferenciavolume
          into v_confereAuto
          from romaneiopai r, configuracaoonda conf
         where r.idromaneio = p_idonda
           and conf.exclusivopicktolight = 1
           and conf.tipointegracaoptl = 1
           and conf.idconfiguracaoonda = r.idconfiguracaoonda;
      exception
        when no_data_found then
          v_confereAuto := 0;
      end;
    
      if (v_confereAuto <> C_GERA_CONF_VOL) then
        return;
      end if;
    
      for r_nf in (select nfr.idromaneio, v.idnotafiscal, v.idusuario
                     from nfromaneio nfr, v_tarefas_onda v
                    where nfr.idromaneio = p_idonda
                      and v.idonda = nfr.idromaneio
                      and v.idnotafiscal = nfr.idnotafiscal
                      and v.codbarratarefa = p_tarefa
                      and not exists
                    (select 1
                             from volumeromaneio vr
                            where vr.idnotafiscal = v.idnotafiscal
                              and vr.idromaneio = v.idonda)
                    group by nfr.idromaneio, v.idnotafiscal, v.idusuario)
      loop
        pk_execucaomanual.conferirNotaFiscal(r_nf.idromaneio,
                                             r_nf.idnotafiscal,
                                             r_nf.idusuario, p_tarefa, C_PTL);
      end loop;
    end conferirGerarVolumeAuto;
  
    procedure conferirGerarVolumes is
    begin
      if (isTarefaSeparada) then
        conferirGerarVolumeAuto(v_idonda);
      end if;
    end conferirGerarVolumes;
  
  begin
  
    begin
    
      carregarDados;
    
      if (v_separacaoPkEstacao = 1)
         and (v_entregaAutoPacking = 1) then
        v_finalizaSeparacao := 1;
      end if;
    
      if (v_finalizaSeparacao = 1) then
        verificaCorteFisico;
      
        finalizaSeparacao;
      
        conferirGerarVolumes;
      
      end if;
    
      if (v_decidirDesvioEntrega = 1) then
        decidirDesvioEntrega;
      end if;
    
    exception
      when others then
        p_mensagemErro := sqlerrm;
        v_retornoPLC   := v_retornoVazio;
    end;
  
    return v_retornoPLC;
  
  end separacaoBoxDestination;

  /* function separacaoBoxDestination
  (
    p_tarefa      tarefacaixavolume.tarefa%type,
    p_caixaVolume Tipocaixavolume.barra%type
  ) return varchar2 is
  
    v_idonda                number;
    v_idTipocaixaVolume     number;
    v_resultSepOnda         number;
    v_msg                   t_message;
    v_mov                   number := 0;
    v_sep                   romaneiopai.separado%type;
    v_retornoBoxDestination configuracaoonda.retornoboxdestination%type;
  
    SEPARACAO_COM_REAB constant number := 1;
    ONDA_SEPARADA      constant char := 'S';
  
    procedure conferirGerarVolumeAuto(p_idonda romaneiopai.idromaneio%type) is
      v_confereAuto configuracaoonda.gerarconferenciavolume%type;
    
      C_GERA_CONF_VOL constant number := 1;
      C_PTL           constant number := 1;
    begin
      begin
        select conf.gerarconferenciavolume
          into v_confereAuto
          from romaneiopai r, configuracaoonda conf
         where r.idromaneio = p_idonda
           and conf.exclusivopicktolight = 1
           and conf.tipointegracaoptl = 1
           and conf.idconfiguracaoonda = r.idconfiguracaoonda;
      exception
        when no_data_found then
          v_confereAuto := 0;
      end;
    
      if (v_confereAuto <> C_GERA_CONF_VOL) then
        return;
      end if;
    
      for r_nf in (select nfr.idromaneio, v.idnotafiscal, v.idusuario
                     from nfromaneio nfr, v_tarefas_onda v
                    where nfr.idromaneio = p_idonda
                      and v.idonda = nfr.idromaneio
                      and v.idnotafiscal = nfr.idnotafiscal
                      and v.codbarratarefa = p_tarefa
                      and not exists
                    (select 1
                             from volumeromaneio vr
                            where vr.idnotafiscal = v.idnotafiscal
                              and vr.idromaneio = v.idonda)
                    group by nfr.idromaneio, v.idnotafiscal, v.idusuario)
      loop
        pk_execucaomanual.conferirNotaFiscal(r_nf.idromaneio,
                                             r_nf.idnotafiscal,
                                             r_nf.idusuario, p_tarefa, C_PTL);
      end loop;
    end conferirGerarVolumeAuto;
  
    function isTarefaSeparada return boolean is
      v_isTarefaSep number;
    begin
      begin
        select count(*)
          into v_isTarefaSep
          from dual
         where exists (select 1
                  from v_tarefas_onda m
                 where m.status in (0, 1, 2)
                   and m.qtdeconferida < m.qtdemovimentada
                   and m.idonda = v_idonda
                   and m.codbarratarefa = p_tarefa);
      exception
        when no_data_found then
          v_isTarefaSep := 0;
      end;
      return v_isTarefaSep = 0;
    end isTarefaSeparada;
  
  begin
    begin
      select cx.idonda, cx.idtipocaixavolume, cnf.retornoBoxDestination
        into v_idonda, v_idTipocaixaVolume, v_retornoBoxDestination
        from tarefacaixavolume t, tipocaixavolume cx, romaneiopai r,
             configuracaoonda cnf
       where t.tarefa = p_tarefa
         and cx.barra = p_caixaVolume
         and cx.idtipocaixavolume = t.idtipocaixavolume
         and r.idromaneio = cx.idonda
         and cnf.idconfiguracaoonda = r.idconfiguracaoonda;
    exception
      when no_data_found then
        v_idonda            := 0;
        v_idTipocaixaVolume := 0;
    end;
  
    if (v_idonda = 0) then
      v_msg := t_message('Não localizada expedição para a tarefa {0} e caixa {1}.');
      v_msg.addParam(p_tarefa);
      v_msg.addParam(p_caixaVolume);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_cortefisico.registrarCorteFisicoCaixa(v_idonda, v_idTipocaixaVolume);
  
    for r_sep in (select v.idusuario, ro.idregiao idRegiaoOrigem,
                         decode(lo.buffer, 'S', 1, 0) bufferOrigem,
                         rd.idregiao idRegiaoDestino,
                         decode(ld.buffer, 'S', 1, 0) bufferDestino,
                         v.identificador, v.idnotafiscal,
                         ld.idlocal localDestino
                    from v_tarefas_onda v, local lo, local ld,
                         regiaoarmazenagem ro, regiaoarmazenagem rd
                   where v.idonda = v_idonda
                     and v.codbarratarefa = p_tarefa
                     and lo.id = v.idlocalorigem
                     and ld.id = v.idlocaldestino
                     and ro.idregiao = lo.idregiao
                     and rd.idregiao = ld.idregiao
                   group by v.idusuario, v.idonda, ro.idregiao,
                            decode(lo.buffer, 'S', 1, 0), rd.idregiao,
                            decode(ld.buffer, 'S', 1, 0), v.identificador,
                            v.idnotafiscal, ld.idlocal)
    loop
    
      v_resultSepOnda := pk_seponda.finalizarSepOnda(r_sep.idusuario,
                                                     v_idonda,
                                                     r_sep.idRegiaoOrigem,
                                                     r_sep.bufferOrigem,
                                                     r_sep.idRegiaoDestino,
                                                     r_sep.bufferDestino,
                                                     r_sep.identificador,
                                                     r_sep.idnotafiscal);
    
      if (v_resultSepOnda = SEPARACAO_COM_REAB) then
        v_msg := t_message('Necessita-se reabastecer os pickings antes de finalizar a separação.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_mov := 1;
    
    end loop;
  
    if (v_mov = 0) then
      v_msg := t_message('Não existem movimentações pendentes para finalização.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (isTarefaSeparada) then
      conferirGerarVolumeAuto(v_idonda);
    end if;
  
    return v_retornoBoxDestination;
  
  end separacaoBoxDestination; */

  procedure moverEstoqueOS
  (
    p_idOnda    in number,
    p_idusuario in number
  ) is
    v_tipoMaquina    ordemservico.tiposervico%type;
    v_idarmazem      number;
    v_idordemservico number;
  
    function isOndaOSjaSeparada return boolean is
      v_total number;
    begin
      select count(*)
        into v_total
        from movimentacao m
       where m.idonda = p_idOnda
         and m.idlote is not null
         and m.status in (0, 1);
    
      return v_total = 0;
    end isOndaOSjaSeparada;
  
    procedure realizarConferenciaOS is
    begin
      for c_nf in (select s.idnotafiscal, '' codbarratarefa
                     from saidapornf s, romaneiopai rp, configuracaoonda co
                    where s.idonda = p_idOnda
                      and rp.idromaneio = s.idonda
                      and co.idconfiguracaoonda = rp.idconfiguracaoonda
                      and tipoconferenciapacking = 0
                   union
                   select t.idnotafiscal, t.codbarratarefa
                     from v_tarefas_onda t, romaneiopai rp,
                          configuracaoonda co
                    where t.idonda = p_idOnda
                      and rp.idromaneio = t.idonda
                      and co.idconfiguracaoonda = rp.idconfiguracaoonda
                      and tipoconferenciapacking = 1
                    group by t.idnotafiscal, t.codbarratarefa)
      loop
        pk_execucaomanual.conferirNotaFiscal(p_idOnda, c_nf.idNotaFiscal,
                                             p_idusuario,
                                             c_nf.codbarratarefa);
      
        pk_onda.atualizaStatusOnda(p_idOnda, c_nf.idNotaFiscal);
      end loop;
    end realizarConferenciaOS;
  
    procedure moverEstoqueLocalOS is
      v_idlocalMaquina local.idlocal%type;
    
      C_MONTKIT                 constant number := 14;
      C_DESMONTKIT              constant number := 15;
      C_MONTESTOJAMENTO         constant number := 16;
      C_DESMONTESTOJAMENTO      constant number := 17;
      C_MONTKIT_RASTREABILIDADE constant number := 20;
    begin
      --carrega o local do tipo de OS
      select idlocal
        into v_idlocalMaquina
        from local l
       where l.tipo =
             decode(v_tipoMaquina, 'K', C_MONTKIT, 'D', C_DESMONTKIT, 'E',
                    C_MONTESTOJAMENTO, 'J', C_DESMONTESTOJAMENTO, 'I',
                    C_MONTKIT_RASTREABILIDADE)
         and l.ativo = 'S'
         and l.idarmazem = v_idarmazem;
    
      for c_movimentacao in (select ld.idarmazem, ld.idlocal, m.idlote,
                                    m.quantidade, m.id
                               from movimentacao m, local ld
                              where m.idonda = p_idonda
                                and ld.id = m.idlocaldestino
                                and ld.tipo = 8
                                and m.idlote is not null
                                and m.etapa = 1
                                and m.status = 2)
      loop
        pk_estoque.retirar_pendencia(c_movimentacao.idarmazem,
                                     c_movimentacao.idlocal,
                                     c_movimentacao.idlote,
                                     c_movimentacao.quantidade, p_idusuario,
                                     'RETIRADO PENDENCIA REFERENTE A MOVIMENTAÇÃO DE ORDEM DE SERVIÇO. IDORDEMSERVICO: ' ||
                                      v_idordemservico ||
                                      ', IDMOVIMENTACAO: ' ||
                                      c_movimentacao.id || ', IDONDA: ' ||
                                      p_idonda);
      
        pk_estoque.retirar_estoque(c_movimentacao.idarmazem,
                                   c_movimentacao.idlocal,
                                   c_movimentacao.idlote,
                                   c_movimentacao.quantidade, p_idusuario,
                                   'RETIRADO ESTOQUE REFERENTE A MOVIMENTAÇÃO DE ORDEM DE SERVIÇO. IDORDEMSERVICO: ' ||
                                    v_idordemservico || ', IDMOVIMENTACAO: ' ||
                                    c_movimentacao.id || ', IDONDA: ' ||
                                    p_idonda, 'N');
      
        pk_estoque.incluir_estoque(c_movimentacao.idarmazem,
                                   v_idlocalMaquina, c_movimentacao.idlote,
                                   c_movimentacao.quantidade, p_idusuario,
                                   'INCLUIDO ESTOQUE REFERENTE A MOVIMENTAÇÃO DE ORDEM DE SERVIÇO. IDORDEMSERVICO: ' ||
                                    v_idordemservico || ', IDMOVIMENTACAO: ' ||
                                    c_movimentacao.id || ', IDONDA: ' ||
                                    p_idonda, 'N');
        pk_estoque.incluir_pendencia(c_movimentacao.idarmazem,
                                     v_idlocalMaquina, c_movimentacao.idlote,
                                     c_movimentacao.quantidade, p_idusuario,
                                     'INCLUIDO PENDENCIA REFERENTE A MOVIMENTAÇÃO DE ORDEM DE SERVIÇO. IDORDEMSERVICO: ' ||
                                      v_idordemservico ||
                                      ', IDMOVIMENTACAO: ' ||
                                      c_movimentacao.id || ', IDONDA: ' ||
                                      p_idonda);
      
      end loop;
    end moverEstoqueLocalOS;
  begin
    --verifica se a onda é de ordem de serviço e carrega o tipo do serviço e armazem
    begin
      select o.tiposervico, o.idarmazem, o.idordemservico
        into v_tipoMaquina, v_idarmazem, v_idordemservico
        from ordemservico o
       where o.idromaneio = p_idOnda;
    exception
      when no_data_found then
        return;
    end;
  
    if isOndaOSjaSeparada then
      --realiza conferencia
      realizarConferenciaOS;
    
      --move estoque para o local da OS
      moverEstoqueLocalOS;
    
      --atualiza a os para inicio da conferencia de entrada
      update ordemservico
         set situacao = 'T'
       where idromaneio = p_idOnda
         and tiposervico = 'D';
    end if;
  end moverEstoqueOS;

  procedure gerarVolumeEtiquetagem
  (
    p_idOnda             in number,
    p_idRegiaoOrigem     number,
    p_idRegiaoDestino    number,
    p_idLocalEtiquetagem number,
    p_identificador      number,
    p_idusuario          in number
  ) is
    v_msg               t_message;
    v_idvolumeromaneio  number;
    v_idTipoCaixa       number;
    v_idconteudo        number;
    v_etapa             number;
    v_idmovimentacao    number;
    v_localdestino      number;
    v_qtdeconteudo      number;
    v_qtdemovimentada   number;
    r_movimentacao      movimentacao%rowtype;
    v_alturavolume      number;
    v_larguravolume     number;
    v_comprimentovolume number;
    v_qtderestante      number;
    v_qtdeemvolume      number;
  
    procedure getTipoCaixaVolume(p_tipoCaixa in number) is
      C_PACOTE       CONSTANT number := 0;
      C_REUTILIZAVEL CONSTANT number := 1;
    begin
      if (p_tipoCaixa = C_PACOTE) then
        begin
          select idtipocaixavolume
            into v_idTipoCaixa
            from tipocaixavolume
           where tipo = 2
             and rownum = 1;
        exception
          when no_data_found then
            v_msg := t_message('Para gerar os volume separados é necessário possuir um tipo de caixa pacote cadastrado.');
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      elsif (p_tipoCaixa = C_REUTILIZAVEL) then
        begin
          select idtipocaixavolume
            into v_idTipoCaixa
            from tipocaixavolume
           where tipo = 3
             and rownum = 1;
        exception
          when no_data_found then
            v_msg := t_message('Para gerar um volume de caixa fechada é necessário possuir um tipo de caixa reutilizável cadastrado.');
            raise_application_error(-20000, v_msg.formatMessage);
        end;
      end if;
    end getTipoCaixaVolume;
  
    procedure addConteudoVolume
    (
      p_idvolumeromaneio in number,
      p_idmovimentacao   in number,
      p_idlote           number,
      p_qtde             number,
      p_idconteudo       in out number
    ) is
      v_idselecionado number;
    begin
      select nvl(count(*), 0)
        into v_idselecionado
        from gtt_selecao
       where idselecionado = p_idmovimentacao;
    
      if (v_idselecionado = 0) then
        insert into gtt_selecao
          (idselecionado)
        values
          (p_idmovimentacao);
      end if;
    
      -- atualiza a qtde em volume da movimentacao
      update movimentacao m
         set m.qtdeemvolume = round(m.qtdeemvolume + p_qtde, 6)
       where m.id = p_idmovimentacao;
    
      -- grava conteudo do volume
      begin
        select cv.id
          into p_idconteudo
          from conteudovolume cv
         where cv.idvolumeromaneio = p_idvolumeromaneio
           and cv.idlote = p_idlote
           and cv.idmovimentacao = p_idmovimentacao;
      exception
        when no_data_found then
          p_idconteudo := 0;
      end;
    
      if (p_idconteudo = 0) then
        select seq_conteudovolume.nextval
          into p_idconteudo
          from dual;
      
        insert into conteudovolume
          (id, quantidade, idlote, idvolumeromaneio, quantidadefracionada,
           idmovimentacao)
        values
          (p_idconteudo, p_qtde, p_idlote, p_idvolumeromaneio, p_qtde,
           p_idmovimentacao);
      else
        update conteudovolume cv
           set cv.quantidade           = cv.quantidade + p_qtde,
               cv.quantidadefracionada = cv.quantidadefracionada + p_qtde
         where cv.id = p_idconteudo;
      end if;
    end addConteudoVolume;
  
  begin
    for c_etiqcaixa in (select pep.id, pep.idpreetiquetagenerica, pep.idonda,
                               pep.idnotafiscal, pep.identificador,
                               pep.tipocaixavolume
                          from preetiquetapedido pep
                         where pep.idonda = p_idOnda
                           and pep.identificador = p_identificador
                           and pep.volumegerado = 0
                           and exists
                         (select 1
                                  from movimentacao m, local lo, local ld
                                 where m.idonda = pep.idonda
                                   and m.idnotafiscal = pep.idnotafiscal
                                   and m.identificador = pep.identificador
                                   and m.status = 2
                                   and m.qtdemovimentada - m.qtdeconferida = 0
                                   and lo.id = m.idlocalorigem
                                   and ld.id = m.idlocaldestino
                                   and lo.idregiao = p_idRegiaoOrigem
                                   and ld.idregiao = p_idRegiaoDestino
                                   and m.idlocaldestino =
                                       p_idLocalEtiquetagem
                                   and m.idusuario = p_idusuario)
                         order by pep.idonda, pep.idnotafiscal,
                                  pep.identificador)
    loop
      getTipoCaixaVolume(c_etiqcaixa.tipocaixavolume);
    
      pk_ordemseparacao.validaPedFatOrdemSep(c_etiqcaixa.idnotafiscal,
                                             pk_ordemseparacao.C_OF_BLOQUEIA_GERACAOVOLUME);
    
      v_idvolumeromaneio := pk_onda.criarVolume(c_etiqcaixa.idnotafiscal,
                                                c_etiqcaixa.idonda,
                                                p_idusuario, v_idTipoCaixa);
    
      /*Adicionado para rastreio do volume pela região de origem  e destino (Etiquetagem) */
      update volumeromaneio
         set idregiaoorigem  = p_idRegiaoOrigem,
             idregiaodestino = p_idRegiaoDestino,
             identificador   = p_identificador
       where idvolumeromaneio = v_idvolumeromaneio;
    
      v_qtdemovimentada := 0;
      for c_contcaixa in (select idproduto, sum(qtde) qtdecaixa
                            from preetiquetapedidodet
                           where idpreetiquetapedido = c_etiqcaixa.id
                           group by idproduto)
      loop
        delete from gtt_selecao;
        v_qtderestante := c_contcaixa.qtdecaixa;
      
        for c_mov in (select m.id, m.idlote,
                             (m.qtdeconferida - m.qtdeemvolume) qtde,
                             m.idlocaldestino
                        from movimentacao m, local lo, local ld, lote lt
                       where m.idonda = c_etiqcaixa.idonda
                         and m.idnotafiscal = c_etiqcaixa.idnotafiscal
                         and m.identificador = c_etiqcaixa.identificador
                         and m.status = 2
                         and m.qtdemovimentada - m.qtdeconferida = 0
                         and lo.id = m.idlocalorigem
                         and ld.id = m.idlocaldestino
                         and lo.idregiao = p_idRegiaoOrigem
                         and ld.idregiao = p_idRegiaoDestino
                         and m.idlocaldestino = p_idLocalEtiquetagem
                         and m.idusuario = p_idusuario
                         and m.qtdeemvolume < m.qtdeconferida
                         and lt.idlote = m.idlote
                         and lt.idproduto = c_contcaixa.idproduto)
        loop
          if (c_mov.qtde > v_qtderestante) then
            v_qtdeemvolume := v_qtderestante;
          else
            v_qtdeemvolume := c_mov.qtde;
          end if;
        
          v_qtderestante := v_qtderestante - v_qtdeemvolume;
        
          addConteudoVolume(v_idvolumeromaneio, c_mov.id, c_mov.idlote,
                            v_qtdeemvolume, v_idconteudo);
        
          pk_onda.associarCartPresenteContVol(c_etiqcaixa.idnotafiscal,
                                              c_contcaixa.idproduto,
                                              v_idconteudo);
          pk_onda.associarEmbPresenteContVol(c_etiqcaixa.idnotafiscal,
                                             c_contcaixa.idproduto,
                                             v_idconteudo);
        
          -- calcula a qtde total conferida
          v_qtdemovimentada := v_qtdemovimentada + v_qtdeemvolume;
        
          exit when v_qtderestante = 0;
        end loop;
      end loop;
    
      -- calcula a qtde total no conteudo
      select sum(c.quantidadefracionada)
        into v_qtdeconteudo
        from conteudovolume c
       where c.idvolumeromaneio = v_idvolumeromaneio;
    
      if (v_qtdemovimentada <> v_qtdeconteudo) then
        v_msg := t_message('Quantidade separada é diferente da quantidade a ser gerada em volume.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      -- busca destino para criar a nova movimentacao de volume
      select d.iddoca
        into v_localdestino
        from destinosaidaonda d
       where d.idonda = c_etiqcaixa.idonda
         and d.identidade =
             (select decode(a.agruparvolumesruaexpedicao, 1, nf.iddepositante,
                             nf.transportadoranotafiscal)
                from notafiscal nf, armazem a
               where nf.idnotafiscal = c_etiqcaixa.idnotafiscal
                 and a.idarmazem = nf.idarmazem);
    
      select sum(c.quantidade)
        into v_qtdemovimentada
        from conteudovolume c
       where c.idvolumeromaneio = v_idvolumeromaneio;
    
      -- seleciona a ultima etapa para a nova movimentacao
      select max(m.etapa + 1)
        into v_etapa
        from movimentacao m
       where m.idonda = c_etiqcaixa.idonda;
    
      -- configura os valores para a nova movimentação
      r_movimentacao.idlocalorigem    := p_idLocalEtiquetagem;
      r_movimentacao.idlocaldestino   := v_localdestino;
      r_movimentacao.idlote           := null;
      r_movimentacao.idvolumeromaneio := v_idvolumeromaneio;
      r_movimentacao.qtdemovimentada  := v_qtdemovimentada;
      r_movimentacao.quantidade       := v_qtdemovimentada;
      r_movimentacao.etapa            := v_etapa;
      r_movimentacao.idnotafiscal     := c_etiqcaixa.idnotafiscal;
      r_movimentacao.idonda           := c_etiqcaixa.idonda;
      r_movimentacao.qtdeconferida    := 0;
      v_idmovimentacao                := pk_onda.inserirMovimentacao(r_movimentacao);
    
      -- vincula as movimentações aos grupos necessários  
      for cm in (select idselecionado id
                   from gtt_selecao)
      loop
        insert into grupomovimentacao
          (idgrupo, idmovimentacao)
        values
          (cm.id, v_idmovimentacao);
      
        insert into grupomovimentacao
          (idgrupo, idmovimentacao)
        values
          (v_idmovimentacao, cm.id);
      end loop;
    
      delete from gtt_selecao;
    
      select sum((e.altura / e.fatorconversao) * c.quantidade) alturavolume,
             sum((e.largura / e.fatorconversao) * c.quantidade) larguravolume,
             sum((e.comprimento / e.fatorconversao) * c.quantidade) comprimentovolume
        into v_alturavolume, v_larguravolume, v_comprimentovolume
        from conteudovolume c, lote lt, embalagem e
       where c.idvolumeromaneio = v_idvolumeromaneio
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and lt.idlote = c.idlote;
    
      update volumeromaneio
         set alturacaixa           = v_alturavolume,
             larguracaixa          = v_larguravolume,
             comprimentocaixa      = v_comprimentovolume,
             idpreetiquetagenerica = c_etiqcaixa.idpreetiquetagenerica
       where idvolumeromaneio = v_idvolumeromaneio;
    
      pk_romaneio.AtualizaStatusAuditoria(c_etiqcaixa.idonda);
    
      pk_onda.liberarPesagemVolume(v_idvolumeromaneio, p_idusuario);
    
      pk_ordemdevolucao.finalizaConferencia(c_etiqcaixa.idonda);
    
      pk_packing.registrarTotVolSaidaPorNf(c_etiqcaixa.idonda,
                                           c_etiqcaixa.idnotafiscal,
                                           p_idusuario, p_idusuario);
    
      pk_packing.coletaAutomaticaAposUltimoVol(c_etiqcaixa.idonda,
                                               p_idusuario);
    
      -- finaliza a geração do volume para esta a pre-etiqueta do pedido separado
      update preetiquetapedido pep
         set pep.volumegerado = 1
       where pep.id = c_etiqcaixa.id;
    
      update preetiquetagenerica
         set tipooperacao = 0
       where id = c_etiqcaixa.idpreetiquetagenerica;
    end loop;
  end;

  /*Rotina responsável por marcar uma nota fiscal como Separação externa (PTL PBL)*/
  procedure marcarNFSepExterna
  (
    p_idNotaFiscal in number,
    p_idusuario    in number
  ) is
    r_notafiscal notafiscal%rowtype;
    v_msg        t_message;
  
    procedure carregarNF is
    begin
      select nf.*
        into r_notafiscal
        from notafiscal nf
       where nf.idnotafiscal = p_idNotaFiscal;
    end carregarNF;
  
    procedure validarNF is
      procedure isNfComSepEspecifica is
        v_ExistsSepEspecifica number := 0;
      begin
        select count(1)
          into v_ExistsSepEspecifica
          from separacaoespecifica s
         where s.idnotafiscal = r_notafiscal.idnotafiscal;
      
        if (v_ExistsSepEspecifica > 0) then
          v_msg := t_message('Não foi possível marcar a Nota Fiscal/Pedido {0} como Separação Externa pois o documento possui Separação Específica vinculada. Remova o vínculo de Lotes antes de prosseguir.');
          v_msg.addParam(r_notafiscal.codigointerno);
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end isNfComSepEspecifica;
    begin
      --Verifica Se não há Separação Específica antes de prosseguir
      isNfComSepEspecifica;
    
      --verifica se a nota fiscal não é de PTL
      if r_notafiscal.picktolight = 1 then
        v_msg := t_message('O pedido ou a nota fiscal selecionada já está definido como Separação Externa (PTL / PBL).');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal não está processada
      elsif r_notafiscal.statusnf = 'P' then
        v_msg := t_message('O pedido ou a nota fiscal selecionada já está processada.');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal não está cancelada
      elsif r_notafiscal.statusnf = 'X' then
        v_msg := t_message('O pedido ou a nota fiscal selecionada está cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal está pendente de liberação para expedição
      elsif r_notafiscal.statusroteirizacao <> 0 then
        v_msg := t_message('O pedido ou a nota fiscal não se encontra pendente de liberação para expedição.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarNF;
  
    procedure alterarSepExtNF is
    begin
      pk_triggers_control.disableTrigger('T_AFTER_NOTAFISCAL');
      pk_triggers_control.disableTrigger('T_ALTERAR_NF');
      pk_triggers_control.disableTrigger('T_BEFORE_NOTAFISCAL');
      update notafiscal nf
         set nf.picktolight = 1
       where nf.idprenf = r_notafiscal.idprenf;
      pk_triggers_control.enableTrigger('T_AFTER_NOTAFISCAL');
      pk_triggers_control.enableTrigger('T_ALTERAR_NF');
      pk_triggers_control.enableTrigger('T_BEFORE_NOTAFISCAL');
    
      pk_triggers_control.disableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.disableTrigger('T_INSERE_TIPOCARGA');
      update nfimpressao nfi
         set nfi.picktolight = 1
       where nfi.idprenf = r_notafiscal.idprenf;
      pk_triggers_control.enableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.enableTrigger('T_INSERE_TIPOCARGA');
    end alterarSepExtNF;
  begin
    carregarNF;
  
    validarNF;
  
    alterarSepExtNF;
  end marcarNFSepExterna;

  /*Rotina responsável por desmarcar uma nota fiscal como Separação externa (PTL PBL)*/
  procedure desmarcarNFSepExterna
  (
    p_idNotaFiscal in number,
    p_idusuario    in number
  ) is
    r_notafiscal notafiscal%rowtype;
    v_msg        t_message;
  
    procedure carregarNF is
    begin
      select nf.*
        into r_notafiscal
        from notafiscal nf
       where nf.idnotafiscal = p_idNotaFiscal;
    end carregarNF;
  
    procedure validarNF is
      v_valida number;
    begin
      --verifica se a nota fiscal é de PTL
      if r_notafiscal.picktolight = 0 then
        v_msg := t_message('O pedido ou a nota fiscal selecionada não está definido como Separação Externa (PTL / PBL).');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal não está processada
      elsif r_notafiscal.statusnf = 'P' then
        v_msg := t_message('O pedido ou a nota fiscal selecionada já está processada.');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal não está cancelada
      elsif r_notafiscal.statusnf = 'X' then
        v_msg := t_message('O pedido ou a nota fiscal selecionada está cancelada.');
        raise_application_error(-20000, v_msg.formatMessage);
        --verifica se a nota fiscal está pendente de liberação para expedição
      elsif r_notafiscal.statusroteirizacao <> 0 then
        v_msg := t_message('O pedido ou a nota fiscal não se encontra pendente de liberação para expedição.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      --verifica se existe algum item do pedido ou nota fiscal com um código
      --de linha de separação externa que não permite a desativação da separação externa
      select count(1)
        into v_valida
        from dual
       where exists (select 1
                from nfdet nd, linhasepexterna lse
               where nd.nf = p_idNotaFiscal
                 and lse.codintegracao = nd.tipoptl
                 and lse.permitedesmarcarnfsepext = 0);
    
      if v_valida = 1 then
        v_msg := t_message('O pedido ou a nota fiscal possui itens definidos para uma linha de ' ||
                           'separação externa que não permite a separação pelo WMS.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarNF;
  
    procedure alterarSepExtNF is
    begin
      pk_triggers_control.disableTrigger('T_AFTER_NOTAFISCAL');
      pk_triggers_control.disableTrigger('T_ALTERAR_NF');
      pk_triggers_control.disableTrigger('T_BEFORE_NOTAFISCAL');
      update notafiscal nf
         set nf.picktolight = 0
       where nf.idprenf = r_notafiscal.idprenf;
      pk_triggers_control.enableTrigger('T_AFTER_NOTAFISCAL');
      pk_triggers_control.enableTrigger('T_ALTERAR_NF');
      pk_triggers_control.enableTrigger('T_BEFORE_NOTAFISCAL');
    
      pk_triggers_control.disableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.disableTrigger('T_INSERE_TIPOCARGA');
      update nfimpressao nfi
         set nfi.picktolight = 0
       where nfi.idprenf = r_notafiscal.idprenf;
      pk_triggers_control.enableTrigger('T_BEFORE_NFIMPRESSAO');
      pk_triggers_control.enableTrigger('T_INSERE_TIPOCARGA');
    end alterarSepExtNF;
  begin
    carregarNF;
  
    validarNF;
  
    alterarSepExtNF;
  end desmarcarNFSepExterna;

  procedure entrarCaixaSepPorEstacao
  (
    p_barraCaixa     in varchar2,
    p_idUsuario      in number,
    p_idArmazem      in number,
    p_idRegiaoOrigem in number,
    p_idEstacao      in number := 0 /*Todas*/,
    p_barraTarefa    in out varchar2
  ) is
    v_msg t_message;
  
    procedure validarEstacaoIni is
      v_primeiraOrdem     number;
      v_idPrimeiraEstacao number;
      v_isPrimeiraEstacao number;
    begin
      --Rotina verifica se é a primeira estação da linha,
      --a qual permite fazer indução de caixas
      --na linha de separação (vincula caixa a tarefa)
    
      --se foi selecionada a opção "Todas Estações", terá o mesmo
      --comportamento de primeira estação
      if p_idEstacao = 0 then
        v_isPrimeiraEstacao := 1;
        return;
      end if;
    
      begin
        --busca primeira estação do armazem e região
        select min(e.ordem)
          into v_primeiraOrdem
          from estacao e
         where e.idregiao = p_idRegiaoOrigem
           and e.idarmazem = p_idArmazem;
      
        --carrega id da primeira estação
        select e.id
          into v_idPrimeiraEstacao
          from estacao e
         where e.idarmazem = p_idArmazem
           and e.idregiao = p_idRegiaoOrigem
           and e.ordem = v_primeiraOrdem;
      
        --verifica se a estação informada (logada) é a primeira
        if v_idPrimeiraEstacao = p_idEstacao then
          v_isPrimeiraEstacao := 1;
          return;
        else
          v_isPrimeiraEstacao := 0;
        end if;
      exception
        when no_data_found then
          v_msg := t_message('Não foram encontradas estações cadastradas para o armazém id: {0} e região id: {1}');
          v_msg.addParam(p_idArmazem);
          v_msg.addParam(p_idRegiaoOrigem);
          raise_application_error(-20003, v_msg.formatMessage);
      end;
    
      if v_isPrimeiraEstacao = 0 then
        v_msg := t_message('A caixa selecionada não encontra-se vinculada a uma tarefa ' ||
                           'e a estação selecionada não é a primeira da região, ' ||
                           'não sendo possível vincular a uma tarefa de separação.');
        v_msg.addParam(p_idArmazem);
        v_msg.addParam(p_idRegiaoOrigem);
        raise_application_error(-20003, v_msg.formatMessage);
      end if;
    end validarEstacaoIni;
  
    procedure validarPendSepAnterior is
      v_idEstacaoPendenteSeparacao number;
      v_descricaoEstacao           estacao.descricao%type;
    begin
      --Rotina verifica se existe separação
      --não concluída em estações anterioes  
    
      begin
        --busca a estação de menor ordem pendente de separação
        select idestacao, descricao
          into v_idEstacaoPendenteSeparacao, v_descricaoEstacao
          from (select e.id idestacao, e.descricao
                   from estacao e, estacaolocal el, movimentacao m
                  where e.idregiao = p_idRegiaoOrigem
                    and e.idarmazem = p_idArmazem
                    and el.idestacao = e.id
                    and m.idlocalorigem = el.idendereco
                    and lpad(m.idonda, 10, '0') ||
                        lpad(m.identificador, 4, '0') = p_barraTarefa
                    and m.status = 0
                    and e.ordem < (select e.ordem
                                     from estacao e
                                    where e.id = p_idestacao)
                  order by e.ordem)
         where rownum = 1;
      
        if (v_idEstacaoPendenteSeparacao <> p_idEstacao) then
          v_msg := t_message('A Estação: "{0}" encontra-se pendente de separação.');
          v_msg.addParam(v_descricaoEstacao);
          raise_application_error(-20003, v_msg.formatMessage);
        end if;
      exception
        when no_data_found then
          return;
      end;
    end validarPendSepAnterior;
  
    procedure validarCaixaJaVinc is
    begin
      --verifica se a caixa informada já está vinculada a uma tarefa pendente
      select tv.tarefa
        into p_barraTarefa
        from tarefacaixavolume tv, tipocaixavolume cx, romaneiopai rp,
             configuracaoonda co
       where cx.idtipocaixavolume = tv.idtipocaixavolume
         and cx.barra = p_barraCaixa
         and rp.idromaneio = tv.idonda
         and co.idconfiguracaoonda = rp.idconfiguracaoonda
         and co.seppkporestacao = 1
         and exists
       (select 1
                from movimentacao m
               where m.idonda = tv.idonda
                 and m.status in (0, 1, 2)
                 and (lpad(m.idonda, 10, '0') ||
                     lpad(m.identificador, 4, '0')) = tv.tarefa);
    exception
      when no_data_found then
        null;
    end validarCaixaJaVinc;
  
    procedure vincularCxTarefa is
      v_idOnda          number;
      r_tipoCaixaVolume tipocaixavolume%rowtype;
    
      procedure carregarOnda is
      begin
        select idonda
          into v_idOnda
          from (select t.idonda
                   from v_tarefas_onda t
                  where t.codbarratarefa = p_barraTarefa
                    and t.status <> 3
                  group by t.idonda);
      end carregarOnda;
    
      procedure validarTarefaSelecionada is
        v_qtdeCaixaVinc number;
        v_dummy         number;
      begin
        --bloqueando a região para garantir concorrência 
        --ao verificar se a tarefa foi utilizada por outra sessão
        select ra.idregiao
          into v_dummy
          from regiaoarmazenagem ra
         where ra.idregiao = p_idRegiaoOrigem
           for update;
      
        select count(1)
          into v_qtdeCaixaVinc
          from dual
         where exists (select 1
                  from tarefacaixavolume tcv
                 where tcv.tarefa = p_barraTarefa);
      
        if v_qtdeCaixaVinc > 0 then
          v_msg := t_message('A tarefa selecionada já encontra-se vinculada a uma caixa.' ||
                             chr(13) || 'Barra Informada: {0}');
          v_msg.addParam(p_barraTarefa);
          raise_application_error(-20003, v_msg.formatMessage);
        end if;
      end validarTarefaSelecionada;
    
      procedure inserirCaixaTarefa is
        v_idTarefaCaixaVolume number;
      begin
        select seq_tarefacaixavolume.nextval
          into v_idTarefaCaixaVolume
          from dual;
      
        insert into tarefacaixavolume
          (id, idonda, tarefa, idtipocaixavolume)
        values
          (v_idTarefaCaixaVolume, v_idonda, p_barraTarefa,
           r_tipoCaixaVolume.idTipoCaixaVolume);
      end inserirCaixaTarefa;
    
      procedure utilizarCaixaRetornavel is
      begin
        if r_tipoCaixaVolume.tipo <> 1 then
          return;
        end if;
      
        update tipocaixavolume
           set disponivel = 0,
               idonda     = v_idOnda
         where idtipocaixavolume = r_tipoCaixaVolume.idTipoCaixaVolume;
      end utilizarCaixaRetornavel;
    
      procedure gravarLog is
      begin
        pk_utilities.GeraLog(p_idUsuario,
                             'Caixa de Volume Barra: ' || p_barraCaixa ||
                              ' vinculada a Tarefa de Separação: ' ||
                              p_barraTarefa || '. IdOnda: ' || v_idOnda ||
                              ' / idRegiaoOrigem: ' || p_idRegiaoOrigem,
                             v_idOnda, 'SO');
      end gravarLog;
    begin
      carregarOnda;
    
      pk_packing.validarCaixaSelecionada(p_barraCaixa, r_tipoCaixaVolume);
    
      validarTarefaSelecionada;
    
      inserirCaixaTarefa;
    
      utilizarCaixaRetornavel;
    
      gravarLog;
    end vincularCxTarefa;
  
    procedure vincularCxTarefaDisp is
    
      procedure buscarTarefaDisp is
        v_dummy number;
        v_sql   varchar2(4000);
      
        procedure montarSqlTarefa is
          C_PRIORIDADE_ROTA         constant number := 0;
          C_PRIORIDADE_ENTREGA      constant number := 1;
          C_PRIORIDADE_DEPOSITANTE  constant number := 2;
          C_PRIORIDADE_DESTINATARIO constant number := 3;
          C_PRIORIDADE_DATALIBONDA  constant number := 4;
          C_PRIORIDADE_DATAGERONDA  constant number := 5;
          C_PRIORIDADE_ROTACLIENTE  constant number := 6;
        
          v_tabNFAdic  number;
          v_tabRCAdic  number;
          v_sqlCampos  varchar2(4000);
          v_sqlTabelas varchar2(4000);
          v_sqlRelac   varchar2(4000);
          v_sqlFiltros varchar2(4000);
          v_sqlAgrup   varchar2(4000);
        
          v_sqlCamposAdic  varchar2(4000);
          v_sqlTabelasAdic varchar2(4000);
          v_sqlRelacAdic   varchar2(4000);
          v_sqlAgrupAdic   varchar2(4000);
        
          v_sqlOrdem varchar2(4000);
        
          procedure iniciarParametros is
          begin
            v_tabNFAdic := 0;
            v_tabRCAdic := 0;
          end iniciarParametros;
        
          procedure montarBaseSql is
          begin
            /*sql campos base*/
            v_sqlCampos := 'select (lpad(m.idonda, 10, ''0'') || lpad(m.identificador, 4, ''0'')) tarefa,
                max(lo.idlocal) ultimoLocal';
          
            /*sql tabelas*/
            v_sqlTabelas := ' from movimentacao m, local lo, romaneiopai rp, configuracaoonda co';
          
            /*sql relacionamentos*/
            v_sqlRelac := ' where lo.id = m.idlocalorigem
            and rp.idromaneio = m.idonda
            and co.idconfiguracaoonda = rp.idconfiguracaoonda';
          
            /*sql filtros*/
            v_sqlFiltros := ' and m.status in (0, 1)
            and co.seppkporestacao = 1
            and rp.statusonda in (2, 4)
            and lo.idarmazem = :1
            and lo.idregiao = :2
            and pk_seponda.existeReabastecimentoPend(idonda, identificador) = 0
            and not exists
          (select 1
                   from tarefacaixavolume tv
                  where tv.tarefa = (lpad(m.idonda, 10, ''0'') ||
                        lpad(m.identificador, 4, ''0'')))';
          
            /*sql agrupamentos*/
            v_sqlAgrup := ' group by (lpad(m.idonda, 10, ''0'') || lpad(m.identificador, 4, ''0''))';
          end montarBaseSql;
        
          procedure inserirSqlNF is
          begin
            if v_tabNFAdic = 0 then
              v_tabNFAdic      := 1; --tabela NOTAFISCAL adicionada ao sql
              v_sqlTabelasAdic := v_sqlTabelasAdic || ', notafiscal nf';
              v_sqlRelacAdic   := v_sqlRelacAdic ||
                                  ' and nf.idnotafiscal = m.idnotafiscal';
            end if;
          end inserirSqlNF;
        
          procedure inserirSqlRC is
          begin
            if v_tabRCAdic = 0 then
              v_tabRCAdic      := 1; --tabela ROTACLIENTE adicionada ao sql
              v_sqlTabelasAdic := v_sqlTabelasAdic || ', rotacliente rc';
              v_sqlRelacAdic   := v_sqlRelacAdic ||
                                  ' and rc.identidade (+) = nf.ident_entrega';
            end if;
          end inserirSqlRC;
        
          procedure inserirSqlRota(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic || ', nrt.prioridade ordem' ||
                               p_idPrioridade;
          
            inserirSqlNF;
          
            inserirSqlRC;
          
            v_sqlTabelasAdic := v_sqlTabelasAdic ||
                                ', nivelprioridadeseparacao nrt';
            v_sqlRelacAdic   := v_sqlRelacAdic ||
                                ' and nrt.idprioridadeseparacao (+) = ' ||
                                p_idPrioridade ||
                                ' and nrt.idinformacao (+) = rc.idrota';
          
            v_sqlAgrupAdic := v_sqlAgrupAdic || ', nrt.prioridade';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlRota;
        
          procedure inserirSqlEntr(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic || ', nEnt.prioridade ordem' ||
                               p_idPrioridade;
          
            inserirSqlNF;
          
            v_sqlTabelasAdic := v_sqlTabelasAdic ||
                                ', nivelprioridadeseparacao nEnt';
            v_sqlRelacAdic   := v_sqlRelacAdic ||
                                ' and nrt.idprioridadeseparacao (+) = ' ||
                                p_idPrioridade ||
                                ' and nEnt.idinformacao (+) = nf.ident_entrega';
            v_sqlAgrupAdic   := v_sqlAgrupAdic || ', nEnt.prioridade';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlEntr;
        
          procedure inserirSqlDep(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic || ', nDep.prioridade ordem' ||
                               p_idPrioridade;
          
            inserirSqlNF;
          
            v_sqlTabelasAdic := v_sqlTabelasAdic ||
                                ', nivelprioridadeseparacao nDep';
            v_sqlRelacAdic   := v_sqlRelacAdic ||
                                ' and nrt.idprioridadeseparacao (+) = ' ||
                                p_idPrioridade ||
                                ' and nDep.idinformacao (+) = nf.iddepositante';
            v_sqlAgrupAdic   := v_sqlAgrupAdic || ', nDep.prioridade';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlDep;
        
          procedure inserirSqlDest(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic ||
                               ', nDest.prioridade ordem' || p_idPrioridade;
          
            inserirSqlNF;
          
            v_sqlTabelasAdic := v_sqlTabelasAdic ||
                                ', nivelprioridadeseparacao nDest';
            v_sqlRelacAdic   := v_sqlRelacAdic ||
                                ' and nrt.idprioridadeseparacao (+) = ' ||
                                p_idPrioridade ||
                                ' and nDest.idinformacao (+) = nf.destinatario';
            v_sqlAgrupAdic   := v_sqlAgrupAdic || ', nDest.prioridade';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlDest;
        
          procedure inserirSqlDtLibOnda(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic ||
                               ', rp.dataliberacaoonda ordem' ||
                               p_idPrioridade;
          
            v_sqlAgrupAdic := v_sqlAgrupAdic || ', rp.dataliberacaoonda';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlDtLibOnda;
        
          procedure inserirSqlDtGerOnda(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic || ', rp.datageracao ordem' ||
                               p_idPrioridade;
          
            v_sqlAgrupAdic := v_sqlAgrupAdic || ', rp.datageracao';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlDtGerOnda;
        
          procedure inserirSqlRotaCli(p_idPrioridade in number) is
          begin
            v_sqlCamposAdic := v_sqlCamposAdic || ', nrtc.prioridade ordem' ||
                               p_idPrioridade;
          
            inserirSqlNF;
          
            inserirSqlRC;
          
            v_sqlTabelasAdic := v_sqlTabelasAdic ||
                                ', nivelprioridadeseparacao nrtc';
            v_sqlRelacAdic   := v_sqlRelacAdic ||
                                ' and nrt.idprioridadeseparacao (+) = ' ||
                                p_idPrioridade ||
                                ' and nrtc.idinformacao (+) = rc.id';
          
            v_sqlAgrupAdic := v_sqlAgrupAdic || ', nrtc.prioridade';
          
            if v_sqlOrdem is null then
              v_sqlOrdem := 'ordem' || p_idPrioridade;
            else
              v_sqlOrdem := v_sqlOrdem || ', ordem' || p_idPrioridade;
            end if;
          end inserirSqlRotaCli;
        
        begin
          /*Parametros que controlam se já foi adicionado ao Sql as tabelas NOTAFISCAL (v_tabNFAdic) e ROTACLIENTE (v_tabRCAdic)*/
          iniciarParametros;
        
          /*Montar Sql Base de busca da tarefa*/
          montarBaseSql;
        
          --Tipo: 0 - Rota / 1 - Entrega(Loja) / 2 - Depositante / 3 - Destinatário / 4 - Data Liberação Onda / 5 - Data Formação Onda / 6 - Cliente na Rota.
          for c_Prioridade in (select p.tipo, p.id idPrioridade, p.prioridade
                                 from prioridadeseparacao p
                                where p.idarmazem = p_idArmazem
                                order by p.prioridade)
          loop
            if c_Prioridade.tipo = C_PRIORIDADE_ROTA then
              inserirSqlRota(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_ENTREGA then
              inserirSqlEntr(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_DEPOSITANTE then
              inserirSqlDep(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_DESTINATARIO then
              inserirSqlDest(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_DATALIBONDA then
              inserirSqlDtLibOnda(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_DATAGERONDA then
              inserirSqlDtGerOnda(c_Prioridade.idPrioridade);
            elsif c_Prioridade.tipo = C_PRIORIDADE_ROTACLIENTE then
              inserirSqlRotaCli(c_Prioridade.idPrioridade);
            end if;
          end loop;
        
          if v_sqlOrdem is null then
            v_sqlOrdem := 'ultimoLocal desc';
          else
            v_sqlOrdem := v_sqlOrdem || ', ultimoLocal desc';
          end if;
        
          v_sql := 'select tarefa from (' || v_sqlCampos || v_sqlCamposAdic ||
                   v_sqlTabelas || v_sqlTabelasAdic || v_sqlRelac ||
                   v_sqlRelacAdic || v_sqlFiltros || v_sqlAgrup ||
                   v_sqlAgrupAdic || ' order by ' || v_sqlOrdem ||
                   ') where rownum = 1';
        end montarSqlTarefa;
      
      begin
        --bloqueando a região para garantir concorrência 
        --ao verificar se a tarefa foi utilizada por outra sessão
        select ra.idregiao
          into v_dummy
          from regiaoarmazenagem ra
         where ra.idregiao = p_idRegiaoOrigem
           for update;
      
        --busca uma tarefa que esteja em onda liberada ou em execução
        --E que não tenha caixa vinculada
        --E que pertença ao armazem e região logada
        --ordenação dinamica e posteriormente
        --ordenação específica para preferenciar que as caixas com separação no fim da linha entrem primeiro
        --Tipo: 0 - Rota / 1 - Entrega(Loja) / 2 - Depositante / 3 - Destinatário / 4 - Data Liberação Onda / 5 - Data Formação Onda / 6 - Cliente na Rota.
        montarSqlTarefa;
      
        begin
          execute immediate v_sql
            into p_barraTarefa
            using p_idArmazem, p_idRegiaoOrigem;
        exception
          when others then
            v_msg := t_message('Não existem tarefas disponíveis para separação para a região selecionada.' ||
                               SQLERRM);
            raise_application_error(-20003, v_msg.formatMessage);
        end;
      end buscarTarefaDisp;
    begin
      validarEstacaoIni;
    
      buscarTarefaDisp;
    
      vincularCxTarefa;
    end vincularCxTarefaDisp;
  
    procedure vincularCxTarefaEspec is
    begin
      validarEstacaoIni;
    
      vincularCxTarefa;
    end vincularCxTarefaEspec;
  
    function tarefaJaEntregue return boolean is
      v_qtdePend     number;
      v_qtdeEntregue number;
    begin
      select count(1)
        into v_qtdePend
        from movimentacao m
       where m.status in (0, 1)
         and m.idlote is not null
         and (lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0')) =
             p_barraTarefa;
    
      select count(1)
        into v_qtdeEntregue
        from movimentacao m
       where m.status in (2, 4)
         and m.idlote is not null
         and m.datatermino is not null
         and (lpad(m.idonda, 10, '0') || lpad(m.identificador, 4, '0')) =
             p_barraTarefa;
    
      if v_qtdePend = 0
         and v_qtdeEntregue > 0 then
        return true;
      end if;
    
      return false;
    end tarefaJaEntregue;
  begin
    if p_barraTarefa is null then
      --se não foi informada tarefa para vinculo desde o início
      --verifica se ja esta associada a uma tarefa
      validarCaixaJaVinc;
    
      -- verifica se existe uma separação pendente para estação anterior
      -- da tarefa em questão
      validarPendSepAnterior;
    
      --se encontrou tarefa ja vinculada
      if p_barraTarefa is not null then
        --se separação já foi concluída e entregue no packing exibe mensagem  
        if tarefaJaEntregue then
          v_msg := t_message('Separação Concluída. Entregue os produtos no packing');
          raise_application_error(-20003, v_msg.formatMessage);
        end if;
        --retorna a tarefa pelo parametro out
        return;
      else
        --somente pode se for estação de indução (primeira)
        vincularCxTarefaDisp;
      end if;
    elsif p_barraTarefa is not null then
      -- se foi informada tarefa para vínculo desde o início
      vincularCxTarefaEspec;
    end if;
  end entrarCaixaSepPorEstacao;

  function proximaEstacao
  (
    p_idEstacao in number := 0 /*Todas*/,
    p_tarefa    in varchar2,
    p_idOnda    in number,
    p_idArmazem in number
  ) return varchar2 is
  
    v_idRegiao number;
    v_ordem    number;
    v_estacao  estacao.descricao%type;
  
  begin
    if p_idEstacao = 0 then
      return null;
    else
    
      begin
        select e.idregiao
          into v_idRegiao
          from estacao e
         where e.idarmazem = p_idArmazem
           and e.id = p_idEstacao;
      exception
        when no_data_found then
          return null;
      end;
    
      begin
        select ordem, descricao
          into v_ordem, v_estacao
          from (select e.ordem, e.descricao
                   from estacao e, estacaolocal el
                  where e.idregiao = v_idRegiao
                    and e.idarmazem = p_idArmazem
                    and el.idestacao = e.id
                    and el.idendereco in
                        (select m.idlocalorigem
                           from movimentacao m
                          where m.idonda = p_idOnda
                            and lpad(m.idonda, 10, '0') ||
                                lpad(m.identificador, 4, '0') = p_tarefa
                            and m.status = 0)
                  order by e.ordem)
         where rownum = 1;
      exception
        when no_data_found then
          return null;
      end;
    end if;
  
    return v_estacao;
  end;

  function retBarraCxSepEstTarefa
  (
    p_idonda in number,
    p_tarefa in varchar2
  ) return varchar2 is
    v_barraCxs varchar2(300);
  begin
    select substr(stragg(barra), 1, 300)
      into v_barraCxs
      from (select tv.barra
               from tarefacaixavolume tcv, tipocaixavolume tv
              where tcv.idonda = p_idonda
                and tcv.tarefa = p_tarefa
                and tv.idtipocaixavolume = tcv.idtipocaixavolume
              group by tv.barra);
  
    return v_barraCxs;
  end retBarraCxSepEstTarefa;

  procedure finalizarTodasMovDestPacking
  (
    p_idLocalDestino         number,
    p_ConfPorCheckoutExpress number,
    p_SeparacaoConsolidada   number,
    p_exibirAtividadeUnica   number,
    p_idDepositante          number,
    p_idusuario              number,
    p_idonda                 number,
    p_idregiaoorigem         number,
    p_bufferorigem           number,
    p_idregiaodestino        number,
    p_bufferdestino          number,
    p_identificador          number,
    p_idnotafiscal           number
  ) is
    v_msg             t_message;
    retorno_separacao number;
  
    procedure atualizaDestinoMovimentacao is
    begin
    
      update movimentacao
         set idlocaldestino = p_idLocalDestino
       where id in
             (select m.id
                from movimentacao m, local ld, regiaoarmazenagem ra
               where m.idonda = p_idonda
                    
                 and m.idnotafiscal =
                     decode(p_ConfPorCheckoutExpress, 0,
                            decode(p_SeparacaoConsolidada, 0, p_idnotafiscal,
                                    m.idnotafiscal), m.idnotafiscal)
                 and m.identificador = p_identificador
                 and m.status in (0, 1)
                 and ld.id = m.idlocaldestino
                 and ld.tipo = 8
                 and ra.idregiao = ld.idregiao
                 and ra.tipo = 6)
         and exists (select 1
                from local l
               where l.id = p_idLocalDestino
                 and l.ativo = 'S');
    
      if (sql%rowcount = 0) then
        v_msg := t_message('Não foi possivel utilizar o local de packing selecionado.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    
    end atualizaDestinoMovimentacao;
  
    procedure separacaoComReabastecimento is
      v_listaReabPendente varchar2(4000);
    begin
    
      select distinct stragg(decode(g.idremanejamento, null,
                                     'Onda ' || g.idonda ||
                                      ', Movimentacao id ' || g.idmovimentacao,
                                     'Reabastecimento id ' ||
                                      g.idremanejamento)) lista
        into v_listaReabPendente
        from gtt_reabpendente g;
    
      if (v_listaReabPendente is null) then
        v_msg := t_message('Estoque não encontrado no local de origem para dar baixa na separação do produto.');
        raise_application_error(-20100, v_msg.formatMessage);
      end if;
    
      v_msg := t_message('Não é possivel concluir a movimentação. Existe reabastecimento pendente: {0}. Operação cancelada.');
      v_msg.addParam(v_listaReabPendente);
      raise_application_error(-20000, v_msg.formatMessage);
    
    end separacaoComReabastecimento;
  
    procedure atualizarAtividadeSeponda is
    begin
      pk_convocacao.atualizarAtividadeSeparaoOnda(p_idonda,
                                                  p_idLocalDestino,
                                                  p_idDepositante,
                                                  p_idregiaoorigem);
    
    end atualizarAtividadeSeponda;
  begin
  
    atualizaDestinoMovimentacao;
  
    retorno_separacao := finalizarSepOnda(p_idusuario, p_idonda,
                                          p_idregiaoorigem, p_bufferorigem,
                                          p_idregiaodestino, p_bufferdestino,
                                          p_identificador, p_idnotafiscal);
  
    if (retorno_separacao = SEPARACAO_COM_REAB) then
      separacaoComReabastecimento;
    end if;
  
    if (p_exibirAtividadeUnica = 1) then
      atualizarAtividadeSeponda;
    end if;
  
  end finalizarTodasMovDestPacking;

  procedure gravarSeparacaoIniciada is
    v_qtdeSep      number;
    v_msg          t_message;
    v_idusuario    number;
    v_qtdeSeparada number;
    row_locked EXCEPTION;
    PRAGMA EXCEPTION_INIT(row_locked, -54);
  
    cursor c_mov is
      select m.id
        from movimentacao m
       where exists (select 1
                from gtt_sepiniciada g
               where g.idmovimentacao = m.id)
         for update nowait;
  
    r_mov c_mov%rowtype;
  begin
    select count(1)
      into v_qtdeSep
      from dual
     where exists (select 1
              from gtt_sepiniciada);
  
    if v_qtdeSep = 0 then
      v_msg := t_message('Movimentações não informadas para separação. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(1)
      into v_qtdeSep
      from dual
     where exists (select 1
              from gtt_sepiniciada g
             where not exists (select 1
                      from movimentacao m
                     where m.id = g.idmovimentacao));
  
    if v_qtdeSep > 0 then
      v_msg := t_message('Algumas movimentações não foram encontradas com o id informado para separação. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_triggers_control.disableTrigger('T_ALTERAMOVIMENTACAO');
    pk_triggers_control.disableTrigger('T_ALTERASAIDAPORNF');
  
    if (c_mov%isopen) then
      close c_mov;
    end if;
  
    begin
      open c_mov;
    exception
      when row_locked then
        v_msg := t_message('A separação já encontra-se em processamento. Favor tentar novamente.');
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    fetch c_mov
      into r_mov;
  
    if (c_mov%notfound) then
      v_msg := t_message('As movimentações informadas não foram encontradas. Operação cancelada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    while (c_mov%found)
    loop
      select max(g.idusuario), sum(g.qtdeseparada)
        into v_idusuario, v_qtdeSeparada
        from gtt_sepiniciada g
       where g.idmovimentacao = r_mov.id;
    
      update movimentacao m
         set m.status        = 1,
             m.datainicio    = sysdate,
             m.idusuario     = v_idusuario,
             m.tiposeparacao = 2,
             m.qtdeconferida = round((m.qtdeconferida + v_qtdeSeparada), 6)
       where id = r_mov.id;
    
      fetch c_mov
        into r_mov;
    end loop;
  
    for c_saidapornf in (select m.idonda, m.idnotafiscal,
                                sum(g.qtdeSeparada) qtdeSeparada
                           from gtt_sepiniciada g, movimentacao m
                          where m.id = g.idmovimentacao
                          group by m.idonda, m.idnotafiscal)
    loop
    
      update saidapornf s
         set s.separacaoiniciada = nvl(s.separacaoiniciada, 0) +
                                   c_saidapornf.qtdeSeparada
       where s.idonda = c_saidapornf.idonda
         and s.idnotafiscal = c_saidapornf.idnotafiscal;
    end loop;
  
    pk_triggers_control.enableTrigger('T_ALTERAMOVIMENTACAO');
    pk_triggers_control.enableTrigger('T_ALTERASAIDAPORNF');
  
    delete from gtt_sepiniciada;
  
    if (c_mov%isopen) then
      close c_mov;
    end if;
  end gravarSeparacaoIniciada;

  procedure gravarMovimentacoesAgrupadas
  (
    p_caixaGrupoIdColmeia        number,
    p_conPorCheckoutExpress      number,
    p_utzCaixaSepEtiquetagem     number,
    p_idLocalOrigem              number,
    p_idRegiaoOrigemArmazenagem  number,
    p_idRegiaoDestinoArmazenagem number,
    p_destinoBuffer              number,
    p_idProduto                  number,
    p_exibirAtividadeUnica       number,
    p_idDepositante              number,
    p_idNotafiscal               number,
    p_idOnda                     number,
    p_idPreEtiquetaPedido        number,
    p_permiteSeparacaoMultipla   number,
    p_identificadorSeparacao     number,
    p_tipoSeparacao              number,
    p_QtdeEmSeparacao            number,
    p_idusuario                  number,
    p_idCaixaGrupo               number,
    p_loteIndustria              lote.descr%type,
    p_codigoTarefa               varchar2
  ) is
  
    v_fracionarLote  number;
    v_statusOnda     number;
    v_cxSep_liberado number;
  
    PICKING_PARA_COLMEIA         constant number := 1;
    PULMAO_PARA_STAGE            constant number := 9;
    PICKING_PARA_STAGE           constant number := 10;
    C_STATUSONDA_LIBERADA        constant number := 2;
    C_STATUSONDA_EM_EXECUCAO     constant number := 4;
    C_NAO                        constant number := 0;
    C_SIM                        constant number := 1;
    C_TIPOSEPARACAO_PICK_COLMEIA constant number := 2;
  
    r_mov    rec_mov;
    c_cursor cursor_mov;
  
    procedure carregarDados is
    begin
      if (p_idNotafiscal > 0) then
        select d.fracionarlote
          into v_fracionarLote
          from notafiscal nf, depositante d
         where nf.idnotafiscal = p_idNotafiscal
           and nf.iddepositante = d.identidade;
      end if;
    
      select rp.statusOnda
        into v_statusOnda
        from romaneiopai rp
       where rp.idromaneio = p_idOnda;
    
      if p_idCaixaGrupo > 0 then
        select cp.liberado
          into v_cxSep_liberado
          from caixaseparacao cp
         where cp.idcaixaseparacao = p_idCaixaGrupo;
      end if;
    end;
  
    procedure openCursorMovimentacoes
    (
      p_cursor in out cursor_mov,
      p_mov    in out rec_mov
    ) is
      v_sqlExecutar       varchar2(13000);
      v_SqlBase           varchar2(4000);
      v_sqlLoteIndustria  varchar2(300);
      v_sqlCodigoTarefa   varchar2(300);
      v_SqlAtividadeUnica varchar2(4000);
      v_SqlNotaFiscal     varchar2(300);
      v_sqlIdentificador  varchar2(300);
      v_sqlRownum         varchar2(300);
      v_sqlOrderBy        varchar2(300);
    begin
      if (p_cursor%isopen) then
        close p_cursor;
      end if;
    
      if (p_caixaGrupoIdColmeia > 0 and
         p_tipoSeparacao = PICKING_PARA_COLMEIA) then
        v_SqlBase := '
      select m.id, round(m.qtdemovimentada - m.qtdeconferida,6) qtderestante, m.qtdeconferida
        from v_tarefas_onda m, local ld, lote lt, embalagem e, escaninho es
       where m.idonda = ' || p_idOnda || '
         and m.status in (0, 1)
         and m.qtdeconferida <> m.qtdemovimentada
         and m.idlocalorigem = ' || p_idLocalOrigem || '
         and ld.id = m.idlocaldestino
         and ld.idregiao = ' ||
                     p_idRegiaoDestinoArmazenagem || '
         and decode(ld.buffer, ''N'', 0, 1) = ' ||
                     p_destinoBuffer || '
         and lt.idlote = m.idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and e.idproduto = ' || p_idProduto || '
         and ld.id = es.idendereco
         and es.idcolmeia = ' || p_caixaGrupoIdColmeia;
      else
        if (p_caixaGrupoIdColmeia = 0 or p_conPorCheckoutExpress = 1 or
           p_utzCaixaSepEtiquetagem = 1) then
        
          v_SqlBase := '
      select m.id, round(m.qtdemovimentada - m.qtdeconferida,6) qtderestante,
             m.qtdeconferida
        from v_tarefas_onda m, local ld, lote lt, embalagem e
       where m.idonda = ' || p_idOnda || '
         and m.status in (0, 1)
         and m.qtdeconferida <> m.qtdemovimentada
         and m.idlocalorigem = ' || p_idLocalOrigem || '
         and ld.id = m.idlocaldestino
         and ld.idregiao = ' ||
                       p_idRegiaoDestinoArmazenagem || '
         and decode(ld.buffer, ''N'', 0, 1) = ' ||
                       p_destinoBuffer || '
         and lt.idlote = m.idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra
         and e.idproduto = ' || p_idProduto;
        end if;
      end if;
    
      if (p_loteIndustria is not null) then
        v_sqlLoteIndustria := ' and nvl(lt.descr, m.idlote)  = ''' ||
                              p_loteIndustria || '''';
      end if;
    
      if (p_exibirAtividadeUnica = 1 and p_idDepositante > 0) then
      
        v_SqlAtividadeUnica := ' and exists                                               
       (select 1                                                   
                from nfromaneio nfr, notafiscal nf, atividade atv 
               where nf.iddepositante = ' ||
                               p_idDepositante || '
                  and atv.status <> ''F''
                 and nfr.idromaneio = m.idonda
                 and nfr.idnotafiscal = m.idnotafiscal
                 and atv.idregiaoorigem = ' ||
                               p_idRegiaoOrigemArmazenagem || '
                 and atv.idregiaodestino = ' ||
                               p_idRegiaoDestinoArmazenagem || '
                 and nf.idnotafiscal = nfr.idnotafiscal
                 and atv.idnotafiscal = nf.idnotafiscal) ';
      end if;
    
      if (p_codigoTarefa is not null and p_idPreEtiquetaPedido = 0) then
        v_sqlCodigoTarefa := ' and m.codbarratarefa = ' || p_codigoTarefa;
      
      else
        if (p_idNotaFiscal > 0) then
          v_SqlNotaFiscal := ' and m.idnotafiscal =' || p_idNotaFiscal;
        end if;
      
        if (p_permiteSeparacaoMultipla = 1) then
          v_sqlIdentificador := ' and m.identificador =' ||
                                p_identificadorSeparacao;
        end if;
      end if;
    
      if (v_fracionarLote = 0 and p_idNotaFiscal > 0) then
        v_sqlRownum := ' and rownum = 1';
      end if;
    
      v_sqlOrderBy := ' order by e.fatorconversao desc, m.idlote';
    
      v_SqlExecutar := v_SqlBase || v_sqlLoteIndustria ||
                       v_SqlAtividadeUnica || v_sqlCodigoTarefa ||
                       v_SqlNotaFiscal || v_sqlIdentificador || v_sqlRownum ||
                       v_sqlOrderBy;
    
      open p_cursor for v_sqlExecutar;
    
      fetch p_cursor
        into p_mov;
    
    end openCursorMovimentacoes;
  
    procedure atualizarQtdesMov is
      v_qtdeRestante  number;
      v_qtdeUtilizada number;
      v_msg           t_message;
    
      procedure distribuiQtdes is
      begin
        if (r_mov.qtdeRestante < p_QtdeEmSeparacao) then
          v_qtdeUtilizada := r_mov.qtdeRestante;
        else
          v_qtdeUtilizada := v_qtdeRestante;
        end if;
      end distribuiQtdes;
    
      procedure validaQtde is
      begin
        if ((r_mov.qtdeconferida + v_qtdeUtilizada) <= 0) then
          v_msg := t_message('Ocorreu um erro na separação. Quantidade conferida não pode ser 0.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      
      end validaQtde;
    
      procedure insereGttSepIniciada is
      begin
        insert into gtt_sepiniciada
          (idmovimentacao, idusuario, qtdeseparada)
        values
          (r_mov.id, p_idusuario, v_qtdeUtilizada);
      end insereGttSepIniciada;
    
      procedure insereConteudoCarrinho is
      begin
        if ((p_tipoSeparacao in
           (PULMAO_PARA_STAGE, PICKING_PARA_STAGE, PICKING_PARA_COLMEIA) or
           p_conPorCheckoutExpress = 1 or p_utzCaixaSepEtiquetagem = 1) and
           v_qtdeUtilizada > 0) then
        
          insert into conteudocarrinho
            (id, idmovimentacao, idusuario, qtde, idcaixaseparacao,
             carrinhocheio)
          values
            (seq_conteudocarrinho.nextval, r_mov.id, p_idusuario,
             v_qtdeUtilizada,
             decode(p_idCaixaGrupo, 0, null, p_idCaixaGrupo), 'N');
        end if;
      end insereConteudoCarrinho;
    
      procedure inserePreEtiquetagem is
      begin
        if (p_idPreEtiquetaPedido > 0) then
        
          insert into preetiquetapedidodet
            (id, idpreetiquetapedido, idproduto, qtde)
          values
            (seq_preetiquetapedidodet.nextval, p_idPreEtiquetaPedido,
             p_idproduto, v_qtdeUtilizada);
        end if;
      
      end inserePreEtiquetagem;
    
    begin
      v_qtdeRestante := p_qtdeEmSeparacao;
    
      while (c_cursor%found and v_qtdeRestante > 0)
      loop
      
        distribuiQtdes;
      
        validaQtde;
      
        insereGttSepIniciada;
      
        insereConteudoCarrinho;
      
        inserePreEtiquetagem;
      
        v_qtdeRestante := v_qtdeRestante - v_qtdeUtilizada;
      
        fetch c_cursor
          into r_mov;
      
      end loop;
    
      gravarSeparacaoIniciada;
    
      close c_cursor;
    end atualizarQtdesMov;
  
    procedure reservarCaixaSep is
      v_codigoTarefa varchar2(400);
    begin
      v_codigoTarefa := p_codigoTarefa;
    
      if ((p_idCaixaGrupo > 0 and v_cxSep_liberado = C_SIM) and
         (p_tipoSeparacao = C_TIPOSEPARACAO_PICK_COLMEIA or
         p_conPorCheckoutExpress = 1 or p_utzCaixaSepEtiquetagem = 1)) then
      
        if (v_codigoTarefa is null and p_idonda is not null) then
          select rp.codigointerno
            into v_codigoTarefa
            from romaneiopai rp
           where 1 = 1
             and rp.idromaneio = p_idonda;
        end if;
      
        update caixaseparacao c
           set c.liberado     = C_NAO,
               c.codigotarefa = v_codigoTarefa
         where c.idcaixaseparacao = p_idCaixaGrupo;
      end if;
    end reservarCaixaSep;
  
    procedure iniciarExecOnda is
    begin
      if v_statusOnda = C_STATUSONDA_LIBERADA then
        update romaneiopai rp
           set rp.statusonda = C_STATUSONDA_EM_EXECUCAO
         where rp.idromaneio = p_idOnda;
      end if;
    end iniciarExecOnda;
  begin
    carregarDados;
  
    openCursorMovimentacoes(c_cursor, r_mov);
  
    atualizarQtdesMov;
  
    reservarCaixaSep;
  
    iniciarExecOnda;
  end;

  function existeReabastecimentoPend
  (
    p_idOnda        in number,
    p_identificador in number
  ) return number is
    v_configuracaoOnda number;
  begin
  
    select co.naopermsepcomreabastecpend
      into v_configuracaoOnda
      from romaneiopai p, configuracaoonda co
     where p.idromaneio = p_idOnda
       and co.idconfiguracaoonda = p.idconfiguracaoonda;
  
    if (v_configuracaoOnda = 0) then
      return 0;
    end if;
  
    for c in (select ((nvl(estoqueAtual.Quantidade, 0) -
                      nvl(estoqueEmMovimentacao.quantidade, 0)) -
                      estoquePreciso.quantidade) quantidadeNecessaria
                from (select m.idlocalorigem endereco, m.quantidade, lt.idlote
                         from movimentacao m, lote lt
                        where m.idonda = p_idOnda
                          and m.identificador = p_identificador
                          and m.idlote = lt.idlote
                          and m.status in (0, 1)) estoquePreciso,
                     (select m.idlocalorigem endereco,
                              sum(m.quantidade) quantidade, lt.idlote
                         from movimentacao m, lote lt, tarefacaixavolume tcv
                        where m.status in (0, 1)
                          and m.idlote = lt.idlote
                          and tcv.idonda = m.idonda
                          and tcv.tarefa = (lpad(m.idonda, 10, '0') ||
                              lpad(m.identificador, 4, '0'))
                        group by m.idlocalorigem, lt.idlote) estoqueEmMovimentacao,
                     (select ll.idendereco endereco, ll.estoque quantidade,
                              lt.idlote
                         from lotelocal ll, lote lt, local l
                        where lt.idlote = ll.idlote
                          and ll.idlocal = l.idlocal
                          and l.tipo = 0) estoqueAtual
              
               where estoqueAtual.endereco(+) = estoquePreciso.Endereco
                 and estoqueEmMovimentacao.endereco(+) =
                     estoquePreciso.endereco
                 and estoqueAtual.idlote(+) = estoquePreciso.idlote
                 and estoqueEmMovimentacao.idlote(+) = estoquePreciso.idlote)
    loop
      if (c.quantidadeNecessaria < 0) then
        return 1;
      
      end if;
    end loop;
    return 0;
  end;

end;
/

