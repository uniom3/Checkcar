create view VB_MARCA as
select idmarca, descr marca 
   from marca
where ativo = 'S'
/

