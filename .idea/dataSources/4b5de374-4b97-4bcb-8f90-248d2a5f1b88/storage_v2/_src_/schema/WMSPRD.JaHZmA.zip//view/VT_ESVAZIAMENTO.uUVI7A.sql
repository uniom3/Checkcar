create view VT_ESVAZIAMENTO as
select eh.idesvaziamentohopper, eh.idagrupador as agrupador,
       eh.iddepositante, e.razaosocial, eh.idconfintequip,
       ce.nome as nomemaquina, eh.numerohopper, eh.dtesvaziamento,
       eh.idproduto, p.descr, eh.codigointerno, eh.barra,
       eh.quantidadeunit as qtdeunitaria, eh.loteindustria, eh.dtvenc,
       decode(eh.situacao, 0, 'Erro', 'Processado') as situacao,
       eh.mensagemsituacao, eh.impresso, eh.usuarioimpressao as idusuario,
       decode(nvl(eh.usuarioimpressao, 0), 0, '',
               pk_usuario.getusuario(eh.usuarioimpressao)) as usuarioimpressao,
       eh.dtimpressao, eh.situacao as h$situacao, eh.idarmazem h$idarmazem
  from esvaziamentohopper eh, entidade e, produto p,
       configuracaointegracaoequip ce
 where eh.iddepositante = e.identidade
   and eh.idconfintequip = ce.idconfintequip
   and eh.idarmazem = ce.idarmazem
   and eh.iddepositante = ce.iddepositante
   and eh.idproduto = p.idproduto(+)
/

