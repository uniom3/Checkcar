create package body PK_OPERACAO is

  procedure adicionarOperacao
  (
    p_idUsuario         number,
    p_idOperacaoEntrada number,
    p_idOperacaoSaida   number
  ) is
    v_duplicidade number;
    v_msg         t_message;
  begin
  
    select count(*)
      into v_duplicidade
      from operacao op
     where op.idoperacao = p_idOperacaoSaida
       and exists
     (select 1
              from operacao opv, operacaoretorno opr
             where opr.idoperacaoentrada = p_idOperacaoEntrada
               and opr.idoperacaosaida = opv.idoperacao
               and opr.idoperacaosaida <> p_idOperacaoSaida
               and opv.idcfop = op.idcfop
               and opv.tipooper = op.tipooper
               and opv.classificacaocfop = op.classificacaocfop);
  
    if (v_duplicidade > 0) then
      v_msg := t_message('Já existe um CFOP vinculado que possui as informações CFOP, Classificação de CFOP e Tipo Operação igual ao CFOP a ser vinculado. Operação Cancelada!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    insert into operacaoretorno
      (id, idoperacaoentrada, idoperacaosaida)
    values
      (seq_operacaoretorno.nextval, p_idOperacaoEntrada, p_idOperacaoSaida);
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Tela: Vincular CFOP Retorno a CFOP Entrada - Vinculou o CFOP Entrada idOperacao:' ||
                          p_idOperacaoEntrada ||
                          'ao CFOP Retorno idOperacao: ' ||
                          p_idOperacaoSaida, p_idOperacaoEntrada, 'CA');
  
  end;

  procedure removerOperacao
  (
    p_idUsuario         number,
    p_idOperacaoEntrada number,
    p_idOperacaoSaida   number
  ) is
  begin
    delete from operacaoretorno
     where idoperacaoentrada = p_idOperacaoEntrada
       and idoperacaosaida = p_idOperacaoSaida;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Tela: Vincular CFOP Retorno a CFOP Entrada - Desvinculou o CFOP Entrada idOperacao:' ||
                          p_idOperacaoEntrada ||
                          'do CFOP Retorno idOperacao: ' ||
                          p_idOperacaoSaida, p_idOperacaoEntrada, 'CA');
  end;
  
  procedure adicionarMensagemCST
  (
    p_idUsuario         number,
    p_idOperacaoEntrada number,
    p_idOperacaoSaida   number
  ) is
    v_duplicidade number;
    v_msg         t_message;
  begin
  
    select count(*)
      into v_duplicidade
      from operacao op
     where op.idoperacao = p_idOperacaoSaida
       and exists
     (select 1
              from operacao opv, operacaoretorno opr
             where opr.idoperacaoentrada = p_idOperacaoEntrada
               and opr.idoperacaosaida = opv.idoperacao
               and opr.idoperacaosaida <> p_idOperacaoSaida
               and opv.idcfop = op.idcfop
               and opv.tipooper = op.tipooper
               and opv.classificacaocfop = op.classificacaocfop);
  
    if (v_duplicidade > 0) then
      v_msg := t_message('Já existe um CFOP vinculado que possui as informações CFOP, Classificação de CFOP e Tipo Operação igual ao CFOP a ser vinculado. Operação Cancelada!');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    insert into operacaoretorno
      (id, idoperacaoentrada, idoperacaosaida)
    values
      (seq_operacaoretorno.nextval, p_idOperacaoEntrada, p_idOperacaoSaida);
  
    pk_utilities.GeraLog(p_idUsuario,
                         'Tela: Vincular CFOP Retorno a CFOP Entrada - Vinculou o CFOP Entrada idOperacao:' ||
                          p_idOperacaoEntrada ||
                          'ao CFOP Retorno idOperacao: ' ||
                          p_idOperacaoSaida, p_idOperacaoEntrada, 'CA');
  
  end;
  
end PK_OPERACAO;
/

