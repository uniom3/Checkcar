create view VT_CONTATARTRANSPORTADORA as
select ct.idcontatotransportadora, ct.idcarga idcoleta, c.codigointerno nrocoleta,
       c.idtransportadora, ct.datasolicitacao dtsolicitacaocoleta, ct.nomecontato, ct.numcoleta nrocoletatransp,
       ct.idclassificacao, ct.dataprevista dtprevista, ct.obs observacao,
       t.razaosocial transportadora, t.cgc cnpjtransportadora,
       pk_entidade.f_ret_telefone(c.idtransportadora) telefone,
       t.contato contatotransp, cv.descr classificacao
  from carga c, contatotransportadora ct, entidade t,
       classificacaoveiculo cv
 where ct.idcarga = c.idcarga
   and t.identidade (+) = c.idtransportadora
   and cv.idclassificacao (+) = ct.idclassificacao
 order by ct.idcontatotransportadora desc
/

