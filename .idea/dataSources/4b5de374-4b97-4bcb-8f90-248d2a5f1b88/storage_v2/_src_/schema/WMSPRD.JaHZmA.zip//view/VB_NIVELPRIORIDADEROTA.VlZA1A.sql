create view VB_NIVELPRIORIDADEROTA as
select r.idrota, r.descr rota
  from rotas r
 where r.ativo = 'S'
/

