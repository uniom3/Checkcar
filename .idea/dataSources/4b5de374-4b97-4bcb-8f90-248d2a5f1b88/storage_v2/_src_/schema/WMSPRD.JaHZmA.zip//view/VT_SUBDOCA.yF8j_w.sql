create view VT_SUBDOCA as
select l.id, l.idLocal, 'Sub-Doca' tipo, l.idlocaldoca,
       decode(l.ativo, 'S', 1, 0) ativo, s.descr setor, r.descr regiao,
       l.idArmazem, l.Idlocalformatado, ll.idlocal h$idlocaldc,
       ll.id h$idlocaldoca
  from Local l, Local ll, Setor s, RegiaoArmazenagem r
 where l.tipo = 19
   and ll.id = l.idlocaldoca
   and l.idSetor = s.idsetor(+)
   and l.idregiao = r.idRegiao(+)
/

