create view VB_OPERACAOPADRAOPEDIDOSOTS as
select o.idcfop cfop, o.descr operacao, o.idoperacao
  from operacao o
 where o.tipooper not in ('RA', 'RS', 'RG', 'TA', 'TS', 'TG', 'RD', 'G')
   and o.tipo = 'S'
/

