create view VT_LISTAROCORRENCIA as
select m.codigo, m.descr, o.observacaomotivo, nf.codigointerno notafiscal,
       decode(nf.sequencia, 'K', 'W', nf.sequencia) serie,
       nf.numpedidofornecedor pedido, em.codigointerno codemitente,
       em.razaosocial emitente, e.codigointerno coddepositante,
       e.razaosocial depositante, dest.codigointerno coddestinatario,
       dest.razaosocial destinatario,
       (select count(*)
           from ocorrenciaarquivo oa
          where oa.idocordocsaida = o.idocordocsaida) QtdeAnexo,
       o.dtregistroocorrencia, ur.nomeusuario usuarioocorrencia,
       nf.idnotafiscal, o.idocordocsaida
  from ocorrenciadocumentosaida o, motivo m, notafiscal nf, entidade e,
       depositante d, usuario ur, entidade em, entidade dest
 where m.idmotivo = o.idmotivoocorrencia
   and nf.idnotafiscal = o.iddocumentosaida
   and d.identidade = e.identidade
   and nf.iddepositante = d.identidade
   and ur.idusuario = o.idusuario
   and em.identidade = nf.remetente
   and dest.identidade = nf.destinatario
/

