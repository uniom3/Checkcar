create package body pk_triagemonda is

  procedure marcarNotaComoLida
  (
    p_idNotaFiscal number,
    p_idOnda       number
  ) is
    v_separado number;
    v_msg      t_message;
  begin
    select count(1)
      into v_separado
      from romaneiopai rp
     where rp.idromaneio = p_idOnda
       and rp.separado = 'S';
  
    if (v_separado = 0) then
      v_msg := t_message('As notas não foram triadas pois a onda selecionada não está totalmente separada.');
    
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    update notafiscal nf
       set nf.lido = C_LIDO
     where nf.idnotafiscal = p_idNotaFiscal
       and nf.tiponf <> 'P'
       and exists (select 1
              from nfromaneio nfr, romaneiopai rp
             where nfr.idnotafiscal = nf.idnotafiscal
               and nfr.idromaneio = rp.idromaneio
               and rp.separado = 'S'
               and nfr.idromaneio = p_idOnda);
  
  end marcarNotaComoLida;

  procedure marcarOndaComoLida(p_idOnda number) is
  begin
    for c_result in (select nfr.idnotafiscal
                       from nfromaneio nfr
                      where nfr.idromaneio = p_idOnda)
    loop
      marcarNotaComoLida(c_result.idnotafiscal, p_idOnda);
    end loop;
  
  end marcarOndaComoLida;

end pk_triagemonda;
/

