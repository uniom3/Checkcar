create view VT_ACOMPANHAMENTOENTRADANF as
select nf.rowid h$tableid, nf.idnotafiscal, nf.idprenf,
       nf.codigointerno notafiscal, nf.sequencia serie, nf.chaveacessonfe,
       nf.datacadastro dtcadastronf, nfi.dataimportacao dtimportacao,
       lnf.idlotenf, t.descr tiporecebimento,
       decode(t.classificacao, 'C', 'COMPRA', 'D', 'DEVOLUCAO PARCIAL', 'T',
               'DEVOLUCAO TOTAL', 'R', 'REENTREGA', 'X',
               'CROSSDOCKING COM PICKING DINAMICO', 'A', 'CROSSDOCKING DIRETO',
               'M', 'CROSSDOCKING ALOCACAO MANUAL') classificacao,
       lnf.data dtcadastroor, lnf.dataliberacao dtconferencia,
       lnf.datageracaolote dtgeracaolote,
       lnf.datageracaomapaaloc dtgeracaomapaalocacao, lnf.dtinicioalocacao,
       lnf.dtfimalocacao,
       decode(lnf.faltamalocar, -1, null, lnf.faltamalocar) qtdemapapendente,
       decode(nvl(nf.reentrega, 'N'), 'N', 'NÃO', 'S', 'SIM') reentrega,
       dep.cgc cnpjdepositante, dep.razaosocial depositante,
       rem.cgc cnpjremetente, rem.razaosocial remetente,
       dest.cgc cnpjdestinatario, dest.razaosocial destinatario,
       entrega.razaosocial entrega, transp.razaosocial transportadora,
       cc.descricao centrocusto, nf.totalprodutos valorproduto,
       nf.totalgeral valortotal,
       (select sum(nfd.qtde * e.pesobruto)
           from nfdet nfd, embalagem e
          where e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
            and nfd.nf = nf.idnotafiscal) pesobruto,
       (select sum(nfd.qtde * e.pesoliquido)
           from nfdet nfd, embalagem e
          where e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
            and nfd.nf = nf.idnotafiscal) pesoliquido,
       (select sum(nfd.qtde * e.altura * e.largura * e.comprimento)
           from nfdet nfd, embalagem e
          where e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
            and nfd.nf = nf.idnotafiscal) volume,
       (select count(distinct nfd.idproduto)
           from nfdet nfd, embalagem e
          where e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
            and nfd.nf = nf.idnotafiscal) qtdeproduto,
       (select sum(nfd.qtde)
           from nfdet nfd, embalagem e
          where e.idproduto = nfd.idproduto
            and e.barra = nfd.barra
            and nfd.nf = nf.idnotafiscal) qtdepecas,
       lnf.idarmazem h$idarmazem, decode(lnf.status, 'P', 0, 1) h$status
  from notafiscal nf, nfimpressao nfi, lotenf lnf, tiporecebimento t,
       entidade dep, entidade rem, entidade dest, entidade entrega,
       entidade transp, centrocusto cc
 where nfi.idprenf = nf.idprenf
   and lnf.idlotenf = nf.idlotenf
   and t.idtiporecebimento = lnf.idtiporecebimento
   and dep.identidade = nf.iddepositante
   and entrega.identidade = nf.ident_entrega
   and dest.identidade = nf.destinatario
   and rem.identidade = nf.remetente
   and transp.identidade(+) = nf.transportadoranotafiscal
   and cc.idcentrocusto(+) = nf.idcentrocusto
/

