create view VT_ACOMPANHAMENTOSEPROMANEIO as
select rp.idromaneio, rp.codigointerno codromaneio, ps.idpalet, ps.ordem,
       ps.separado, ra.descr regiao, ps.idlocal, p.codigointerno codproduto,
       p.descr produto, sum(ps.qtdeunit) qtde,
       sum(ps.qtdeunit) qtdenaembalagem, e.descrreduzido embalagem,
       e.fatorconversao, ps.barra, ps.dtinicio, ps.dtfim dttermino,
       u.nomeusuario usuariosepacao,
       decode(l.tipolote, 'L', 'LOTE', 'V', 'VOLUME', 'P', 'PALLET') tipolote,
       ps.idproduto, lo.ordem h$ordem, lo.idlocalformatado f$idlocal
  from romaneiopai rp, paletseparacao ps, lote l, local lo,
       regiaoarmazenagem ra, produto p, embalagem e, usuario u
 where rp.tipo = 0
   and ps.idromaneio = rp.idromaneio
   and l.idlote = ps.idlote
   and lo.idarmazem = ps.idarmazem
   and lo.idlocal = ps.idlocal
   and ra.idregiao = lo.idregiao
   and p.idproduto = ps.idproduto
   and e.idproduto = ps.idproduto
   and e.barra = ps.barra
   and u.idusuario(+) = ps.idusuario
 group by rp.idromaneio, rp.codigointerno, ps.idpalet, ps.ordem, ps.separado,
          ra.descr, ps.idlocal, p.codigointerno, p.descr, e.descrreduzido,
          e.fatorconversao, ps.barra, ps.dtinicio, ps.dtfim, u.nomeusuario,
          decode(l.tipolote, 'L', 'LOTE', 'V', 'VOLUME', 'P', 'PALLET'),
          ps.idproduto, lo.ordem, lo.idlocalformatado
/

