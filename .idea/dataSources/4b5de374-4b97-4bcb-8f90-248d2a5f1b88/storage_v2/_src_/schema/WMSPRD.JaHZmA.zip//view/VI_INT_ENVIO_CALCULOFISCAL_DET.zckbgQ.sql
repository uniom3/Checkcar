create view VI_INT_ENVIO_CALCULOFISCAL_DET as
select idcalculofiscal id, numpedido, sequencia, cfop, idnotafiscal,
       cnpjunidade, idproduto, codproduto, produto, ncm, pesobruto,
       pesoliquido, qtde, precounitario, precototal, codigost, baseicms,
       valoricms, data, icmssubst, baseicmssubst, vlroutras, seq_itens,
       barra, frete, seguro, idreplicacao
  from int_envio_calculofiscal_det
/

