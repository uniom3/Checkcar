create view VT_IMPORTACAOINVENTARIO as
select l.idlogimpinventario, l.idinventario,
       to_char(l.data, 'dd/mm/rrrr hh24:mm:ss') as data, l.local, l.qtde,
       l.fator, (l.qtde * l.fator) qtdeunit, l.idproduto, p.codigointerno,
       p.descr produto,
       decode(l.status, 0, 'ERRO', 1, 'SUCESSO', 2, 'AVISO') status,
       decode(l.tipo, 0, 'PICKING NÃO ENCONTRADO PARA O PRODUTO', 1,
               'PRODUTO CONTADO EM PICKING DIFERENTE DO CADASTRADO', 2,
               'ENDERECO FORA DO ESCOPO DO INVENTÁRIO', 3,
               'PRODUTO NÃO VINCULADO AO DEPOSITANTE', 4, 'PRODUTO INATIVO', 5,
               'EMBALAGEM NAO CADASTRADA NO SISTEMA', 6,
               'ENDERECO DE PULMAO NO ESCOPO', 7, 'CAMPOS NULOS NO ARQUIVO', 8,
               'PRODUTOS/BARRA CONTADOS DUPLICADOS', 9,
               'QUANTIDADE NA CONTAGEM EM DECIMAL', 10,
               'LOCAL NÃO CADASTRADO NO SISTEMA', 11,
               'OBRIGATORIO LOTE INDUSTRIA PARA PRODUTO KIT/ESTOJO') tipo,
       l.complemento, l.barra
  from logimpinventario l, produto p
 where p.idproduto(+) = l.idproduto
/

