create view VT_DIVERGENCIAAUDITORIA as
select barra, produto,
       decode(excedida, 0,
               'Adicionar ' || (faltando - pa.H$quantidadeliberada) || ' UN',
               'Remover ' || (excedida - pa.H$quantidadeliberada) || ' UN') acao,
       (select nvl(sum(ll.estoque - ll.pendencia + ll.adicionar), 0) || ' UN'
           from lotelocal ll, lote lt, embalagem e, local l
          where ll.idarmazem = pa.h$idarmazem
            and lt.idlote = ll.idlote
            and lt.iddepositante = pa.h$iddepositante
            and e.barra = lt.barra
            and e.idproduto = lt.idproduto
            and e.barra = pa.barra
            and l.idlocal = ll.idlocal
            and l.idarmazem = ll.idarmazem
            and l.picking = 'S') qtdeNoPicking, excedida h$excedida,
       faltando h$faltando, H$IDAUDITORIAVOLUME, pa.h$tableid
  from vt_produtoauditado pa
 where pa.h$quantidadeliberada <> (pa.excedida + pa.faltando)

/

