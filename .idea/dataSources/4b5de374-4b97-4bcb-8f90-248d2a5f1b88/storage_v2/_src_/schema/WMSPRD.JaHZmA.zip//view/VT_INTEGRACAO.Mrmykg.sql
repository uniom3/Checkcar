create view VT_INTEGRACAO as
select i.rowid h$tableid, i.agrupador, i.tipo, i.status, cf.servicorest,
       i.operacao, i.idoperacao, i.data, i.datageracao, u.nomeusuario,
       i.arquivo, i.tipo h$tipo, i.status H$STATUS, i.mensagem, t.execucoes,
       t.id tarefa, (i.tamanhoarquivo / 1000000) tamanhoArquivo,
       i.idconfiguracaointegracao H$idConfiguracaoIntegracao,
       e.razaosocial deptransp, e.identidade iddeptransp
  from integracao i, usuario u, tsunamijob t, configuracaointegracao cf,
       entidade e
 where i.idusuario = u.idusuario(+)
   and i.idtsunamijob = t.id(+)
   and e.identidade(+) = cf.identidade
   and cf.id(+) = i.idconfiguracaointegracao
/

