create view VI_INT_ENVIO_EFD_0200 as
select distinct '0200' reg, nf.idarmazem,
                trunc(nvl(nr.datacobertura, nf.datacadastro)) dataprocessamento,
                p.codigointerno cod_item, trim(p.descr) descr_item,
                e.barra cod_barra, ' ' cod_ant_item,
                trim(nvl(e.descrreduzido, 'UN')) unid_inv, '02' tipo_item,
                nvl(p.ncm, ' ') cod_ncm, nvl(p.ex_tipi, ' ') ex_ipi,
                nvl(p.generoproduto, 87) cod_gen, '00.00' cod_lst,
                nvl(nd.aliqicms, 0) aliq_icms
  from notafiscal nf, nfdet nd, embalagem e, produto p, depositante dp,
       regime re, operacao o, nfremarmazenagem nr
 where (nvl(nf.sequencia, 'X') not like '%AJUSTE%' and
       nvl(nf.sequencia, 'X') not like '%INVENTARIO%')
   and nd.nf = nf.idnotafiscal
   and e.idproduto = nd.idproduto
   and e.barra = nd.barra
   and p.idproduto = e.idproduto
   and decode(nf.statusnf, 'P', 1, 0) = 1
   and decode(nf.retornoreentrega, 'N', 1, 0) = 1
   and decode(nvl(re.contribuinteicms, 'S'), 'S', 1, 0) = 1
   and dp.identidade = nf.iddepositante
   and re.idregime = dp.idregime
   and decode(re.classificacao, 'A', 1, 0) = 1
   and o.idoperacao = nf.idoperacao
   and decode(o.tipooper, 'RA', 1, 'RS', 1, 'TA', 1, 'TS', 1, 0) = 1
   and decode(nf.tipo, 'E', 1, 0) = 1
   and nr.idnfremessa(+) = nf.idnotafiscal
 group by '0200', nf.idarmazem,
          trunc(nvl(nr.datacobertura, nf.datacadastro)), p.codigointerno,
          trim(p.descr), e.barra, '', trim(nvl(e.descrreduzido, 'UN')), '02',
          p.ncm, p.ex_tipi, p.generoproduto, 0, nd.aliqicms
/

