create package pk_veiculo is

  /*
   * Retorna o Volume Total dos Palets do Veiculo.
  */
  function ret_vol_veiculo(p_placa in varchar2) return number;

  /*
   * retorna a qtde maxima de palets para o veiculo
  */
  function ret_nummaxpalet(p_placa in veiculo.placa%type) return number;

  /*
   * Funcao que retorna um veiculo padrao
  */
  function pegaveiculopadrao return varchar2;

  /*
   * Retorna a razao social do motorista para o veiculo informado
  */
  function pegar_motorista_veiculo(p_veiculo in varchar2) return varchar2;

  /*
   * Retorna o id do motorista para o veiculo informado
  */
  function pegar_idmotorista(p_veiculo in varchar2) return number;

  /*
   * Remove o veículo e o vínculo com o motorista
  */
  procedure removerVeiculo(p_placaVeiculo in varchar2);

  /*
   * Adiciona o vínculo entre o veículo e o motorista
  */
  procedure addMotoristaVeiculo
  (
    p_placaVeiculo in varchar2,
    p_idEntidade   in number
  );

  /*
   * Remove o vínculo entre o veículo e o motorista
  */
  procedure removeMotoristaVeiculo
  (
    p_placaVeiculo in varchar2,
    p_idEntidade   in number
  );

  /*
   * Remove a classificação do veículo
  */
  procedure removerClassificacaoVeiculo
  (
    p_idClassificacao in number,
    p_idUsuario       in number
  );

  /*
   * Remove o modelo do veículo
  */
  procedure removerModeloVeiculo
  (
    p_idModelo  in number,
    p_idUsuario in number
  );

  procedure removerVeiculoPalete
  (
    p_placa     in varchar2,
    p_idPalet   in number,
    p_idUsuario in number
  );

  procedure validarCadastroPalete
  (
    p_placa       in varchar2,
    p_altura      in number,
    p_largura     in number,
    p_comprimento in number,
    p_edicao      in number,
    p_idPalete    in number
  );
end pk_veiculo;
/

