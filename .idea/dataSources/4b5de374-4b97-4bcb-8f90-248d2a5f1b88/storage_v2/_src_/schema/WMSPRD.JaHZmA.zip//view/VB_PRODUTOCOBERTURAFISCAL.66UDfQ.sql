create view VB_PRODUTOCOBERTURAFISCAL as
select distinct p.idproduto h$tableid, p.codigointerno codproduto,
                p.idproduto, p.descr produto, tp.descr tipoproduto
  from v_cobertura_notafiscal cob, produto p, tipoproduto tp, gtt_selecao g
 where p.idproduto = cob.idproduto
   and tp.idtipo = p.idtipo
   and g.idselecionado = cob.idnotafiscal
/

