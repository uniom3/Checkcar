create view V_DETMOV_ENTRADA as
select ln.idlotenf id, trunc(ln.data) datamov, ln.identidade,
       to_char(trunc(ln.data),'mm/yyyy') mesmov,
       to_char(to_date(to_char(trunc(ln.data),'mm/yyyy'),'mm/yyyy'),'Month "de" yyyy') mes,
       tr.descr classificacao, l.idproduto, 'ENTRADA' TipoMov,
       sum(l.qtde * l.fatorconversao) totalprod, l.barra, l.fatorconversao, sum(l.qtde) qtde, l.descrreduzido embalagem,
       sum(nvl((e.pesobruto * l.qtde) / 1000, 0)) totalpeso,
       sum(round((e.altura * e.largura * e.comprimento * l.qtde) /
                  1000000000, 3)) totalvolume, totnf.totalnf,
       conf.qtde qtdeconf, sum(totnf.qtdenf) qtdenf
  from lotenf ln, tiporecebimento tr,
       (select c.idlotenf, c.idproduto, sum(c.qtde) qtde
           from conferenciaentradadet c
          where (idlotenf, idconferenciaentrada) in
                (select idlotenf, max(idconferenciaentrada)
                   from conferenciaentradadet
                  where idlotenf = c.idlotenf
                    and idproduto = c.idproduto
                  group by idlotenf)
          group by idlotenf, idproduto) conf,
       (select o.idlotenf, l.idlote, l.idproduto, l.barra, e.fatorconversao,
                e.descrreduzido, l.qtdeentrada qtde
           from lote l, embalagem e,
                (select distinct nf.idlotenf, ol.idlote
                    from notafiscal nf, origemlote ol
                   where ol.idnotafiscal = nf.idnotafiscal) o
          where o.idlote = l.idlote
            and e.idproduto = l.idproduto
            and e.barra = l.barra
            and l.tipolote = 'L') l, embalagem e,
       (select idlotenf, idproduto, count(distinct idnotafiscal) totalnf, sum(nfd.qtde) qtdenf
           from notafiscal nf, nfdet nfd
          where nfd.nf = nf.idnotafiscal
            and nf.idlotenf is not null
          group by idlotenf, idproduto) totnf
 where ln.flaglibnf = 2
   and ln.status = 'P'
   and tr.idtiporecebimento (+)= ln.idtiporecebimento
   and l.idlotenf = ln.idlotenf
   and e.idproduto = l.idproduto
   and e.barra = l.barra
   and totnf.idlotenf = ln.idlotenf
   and totnf.idproduto = l.idproduto
   and conf.idlotenf = ln.idlotenf
   and conf.idproduto = l.idproduto
 group by ln.idlotenf, trunc(ln.data), ln.identidade, tr.classificacao,
          tr.descr, l.idproduto, totnf.totalnf, l.barra, l.fatorconversao,
          l.descrreduzido, conf.qtde
/

