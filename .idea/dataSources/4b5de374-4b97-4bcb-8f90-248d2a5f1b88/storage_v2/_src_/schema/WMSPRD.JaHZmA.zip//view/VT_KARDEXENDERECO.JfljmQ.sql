create view VT_KARDEXENDERECO as
select h.idestoque h$tableid, h.dataestoque data, e.razaosocial depositante,
       h.idlocal,
       decode(lo.tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
               'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4, 'DOCA', 5, 'AUDITORIA', 6,
               'RUA EXPEDICAO', 7, 'STAGE', 8, 'PACKING', 9, 'SERVIÇO', 11,
               'MISTURA', 12, 'CLASSIFICAÇÃO', 13, 'RECLASSIFICAÇÂO', 14,
               'MONTAGEM DE KIT', 16, 'ESTOJAMENTO', 20,
               'MONTAGEM DE KIT COM RASTREABILIDADE') tipolocal, lo.buffer,
       l.idlote, p.codigointerno codproduto, p.descr produto,
       h.estoqueanterior, h.estoqueapos, h.pendanterior pendenciaanterior,
       h.pendapos pendenciaapos, h.adicionaranterior, h.adicionarapos,
       h.complementar, u.nomeusuario usuario, l.descr loteindustria,
       decode(l.estado, 'N', 'NORMAL', 'D', 'DANIFICADO', 'T',
               'VENCIDO/TRUNCADO') estado, p.idproduto, m.id idmovimentacao,
       m.idonda, h.idarmazem h$idarmazem, lo.ordem h$ordem,
       lo.idlocalformatado f$idlocal
  from historicoestoque h, local lo, produto p, lote l, entidade e,
       usuario u, movimentacao m
 where lo.idarmazem = h.idarmazem
   and lo.idlocal = h.idlocal
   and l.idlote = h.idlote
   and p.idproduto = h.idproduto
   and e.identidade = h.iddepositante
   and u.idusuario = h.idusuario
   and m.id(+) = h.idmovimentacao

 order by dataestoque
/

