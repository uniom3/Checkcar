create view VT_CONFERENCIAPORCARGA as
select pc.id, rp.codigointerno onda, pc.palete, pc.status, pc.datainicio,
       pc.datatermino, pc.idonda h$idonda, pc.id h$idpaleteconferencia,
       decode((select count(1)
                 from confexpedicaocarga c, ocorrenciaconfexpedicao o
                where c.idpaleteconferencia = pc.id
                  and o.idconfexpedicaocarga = c.id
                  and o.status in (2, 4)
                  and c.id =
                      (select max(id) ultima
                         from confexpedicaocarga
                        where idpaleteconferencia = c.idpaleteconferencia)), 0,
               0, 1) h$gerarcorte
  from paleteconferencia pc, romaneiopai rp
 where rp.idromaneio = pc.idonda
 order by rp.codigointerno, pc.palete
/

