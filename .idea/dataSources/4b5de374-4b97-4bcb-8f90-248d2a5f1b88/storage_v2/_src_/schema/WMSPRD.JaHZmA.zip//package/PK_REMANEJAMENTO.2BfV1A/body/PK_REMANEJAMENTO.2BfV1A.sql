create package body pk_remanejamento is

  C_MOV_COBERTURA       constant number := 0;
  C_MOV_CONTROLE_AVARIA constant number := 1;
  C_MOV_DIVIDIR_LOTE    constant number := 2;
  C_MOV_DESMONTAGEM_KIT constant number := 3;
  C_MOV_PROD_RECUPERADO constant number := 4;
  C_MOV_CADASTRO_LOTE   constant number := 5;

  type cursor_remanejamento is ref cursor;

  type t_localRemanejamento is record(
    idLocal              local.idlocal%type,
    tipoLocal            local.tipo%type,
    idarmazem            local.idarmazem%type,
    buffer               local.buffer%type,
    picking              local.picking%type,
    codIntegracaoEsteira setor.codintegracaoesteira%type,
    bufferEsteira        local.bufferesteira%type);

  procedure getRemAberto
  (
    c_remAberto      in out cursor_remanejamento,
    r_remAberto      in out remanejamento%rowtype,
    p_idarmazem      in number,
    p_idlocalorigem  in local.idlocal%type,
    p_idlocaldestino in local.idlocal%type
  ) is
  begin
    open c_remAberto for
      select r.*
        from remanejamento r
       where ((r.planejado = 'N') or (r.cadmanual = 'N'))
         and r.status = 'A'
         and r.idarmazemdestino = p_idarmazem
         and r.idlocaldestino = p_idlocaldestino
         and r.idarmazemorigem = p_idarmazem
         and r.idlocalorigem = p_idlocalorigem
         and not exists (select 1
                from loteremanejamento lr
               where lr.idremanejamento = r.idremanejamento
                 and ((nvl(lr.conferido, 'N') = 'S') or
                     (nvl(lr.impresso, 'N') = 'S')))
         and not exists
       (select 1
                from remanejamento re, local lo, local ld, setor sd
               where re.idremanejamento = r.idremanejamento
                 and re.idlocalorigem = lo.idlocal
                 and lo.picking = 'S'
                 and lo.buffer = 'S'
                 and lo.bufferesteira = 1
                 and re.idlocaldestino = ld.idlocal
                 and ld.picking = 'S'
                 and ld.buffer = 'N'
                 and ld.idsetor = sd.idsetor
                 and sd.codintegracaoesteira is not null)
       order by r.idremanejamento
         for update;
  
    fetch c_remAberto
      into r_remAberto;
  end;

  /*
  * Funcao que cadastra o remanejamento
  */
  function cadastrar_remanejamento
  (
    p_idarmazemorigem  in number,
    p_idarmazemdestino in number,
    p_idlocalorigem    in local.idlocal%type,
    p_idlocaldestino   in local.idlocal%type,
    p_idusuario        in number,
    p_idromaneio       in number,
    p_descr            in remanejamento.descrpalet%type,
    p_commit           in varchar2 := C_SIM,
    p_planejado        in varchar2 := C_NAO
  ) return number is
    c_remAberto       cursor_remanejamento;
    r_remaAberto      remanejamento%rowtype;
    v_idremanejamento number;
    v_descr           remanejamento.descrpalet%type;
    v_qtdelote        number;
    v_msg             t_message;
  begin
    -- conferir se o lote esta em OS nao finalizada
    begin
      select nvl(count(*), 0)
        into v_qtdelote
        from v_estoque_local ll, ordemlote ol, ordemservico os
       where ll.idlocal = p_idlocalorigem
         and ol.idlote = ll.idlote
         and os.idordemservico = ol.idordemservico
         and os.tiposervico = c_conserto
         and os.situacao <> 'P';
    exception
      when others then
        v_qtdelote := 0;
    end;
  
    if v_qtdelote > 0 then
      v_msg := t_message('EXISTE ORDEM DE SERVICO ABERTA PARA ESTES LOTES.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    v_descr := nvl(trim(p_descr), 'N/D');
  
    getRemAberto(c_remAberto, r_remaAberto, p_idarmazemorigem,
                 p_idlocalorigem, p_idlocaldestino);
    if (c_remAberto%found) then
      v_idremanejamento := r_remaAberto.idremanejamento;
    else
      select seq_remanejamento.nextval idremanejamento
        into v_idremanejamento
        from dual;
    
      insert into remanejamento
        (idremanejamento, idarmazemorigem, idlocalorigem, idarmazemdestino,
         idlocaldestino, datahora, idusuariotela, status, cadmanual,
         idromaneio, descrpalet, planejado)
      values
        (v_idremanejamento, p_idarmazemorigem, p_idlocalorigem,
         p_idarmazemdestino, p_idlocaldestino, sysdate, p_idusuario,
         c_aguardando, c_nao, p_idromaneio, v_descr, p_planejado);
    end if;
  
    close c_remAberto;
  
    if p_commit = c_sim then
      commit;
    end if;
  
    return v_idremanejamento;
  end;

  /*
   * Responsavel por trocar os lotes no remanejamento.
  */
  procedure alterar_remanejamento
  (
    p_idremanejamento in number,
    p_lote            in number,
    p_qtde            in number,
    p_usuario         in number
  ) is
    -- verifica se o lote pego ja esta no remanejamento
    cursor c_lote
    (
      p_remanejamento in number,
      p_conferido     in varchar2,
      p_lote          in varchar2
    ) is
      select l.idlote, lt.idproduto, lt.barra, lt.iddepositante, l.qtde
        from loteremanejamento l, lote lt
       where l.idremanejamento = p_remanejamento
         and l.conferido like p_conferido
         and l.idlote like p_lote
         and lt.idlote = l.idlote;
  
    cursor c_llocal
    (
      p_arm   in number,
      p_lo    in varchar2,
      p_lt    in number,
      p_idpro in number,
      p_bar   in varchar2,
      p_dep   in number
    ) is
      select l.idlote, l.disp estoque
        from v_estoque_local l, lote lt
       where l.idlote = p_lt
         and l.idarmazem = p_arm
         and l.idlocal = p_lo
         and lt.idproduto = p_idpro
         and lt.barra = p_bar
         and lt.iddepositante = p_dep
         and l.loteliberado = c_sim;
  
    r_lote      c_lote%rowtype;
    r_llocal    c_llocal%rowtype;
    v_idarm_ori local.idarmazem%type;
    v_idarm_des local.idarmazem%type;
    v_local_ori local.idlocal%type;
    v_local_des local.idlocal%type;
    -- v_roma_proc number;
    v_achou boolean;
    v_qtde  number;
    v_pend  number;
    v_dif   number;
    v_msg   t_message;
  begin
    -- localizo o lote que vai ser substituido.
    if c_lote%isopen then
      close c_lote;
    end if;
    open c_lote(p_idremanejamento, '%', p_lote);
    fetch c_lote
      into r_lote;
    if c_lote%notfound then
      close c_lote;
      open c_lote(p_idremanejamento, c_nao, '%');
      fetch c_lote
        into r_lote;
      v_achou := false;
    else
      v_achou := true;
    end if;
  
    if v_achou = false then
      -- localizo o remanejamento em andamento
      select r.idarmazemorigem, r.idlocalorigem, r.idarmazemdestino,
             r.idlocaldestino
        into v_idarm_ori, v_local_ori, v_idarm_des, v_local_des
        from remanejamento r
       where r.idremanejamento = p_idremanejamento;
      -- verifica se o lote selecionado e valido
      if c_llocal%isopen then
        close c_llocal;
      end if;
      open c_llocal(v_idarm_ori, v_local_ori, p_lote, r_lote.idproduto,
                    r_lote.barra, r_lote.iddepositante);
      fetch c_llocal
        into r_llocal;
      if ((c_llocal%found) and (nvl(r_llocal.estoque, 0) > 0)) then
        /* atualiza a pendencia do lote antigo, retirando a qtde que
        anteriormente foi colocada como pendencia... */
        pk_estoque.incluir_pendencia(v_idarm_ori, v_local_ori,
                                     r_lote.idlote, r_lote.qtde, p_usuario,
                                     'LOTE SUBSTITUIDO PELO LOTE N:' ||
                                      P_LOTE || ' DO REMANEJAMENTO N:' ||
                                      P_IDREMANEJAMENTO ||
                                      ' ATUALIZA A PENDENCIA DO LOTE ANTIGO');
        /* - atualiza a pendencia e o adicionar do endereco de destino ref.
          ao lote antigo.
        - seleciona a pendencia do lote antigo.*/
        select pendencia
          into v_qtde
          from v_estoque_local
         where idarmazem = v_idarm_des
           and idlocal = v_local_des
           and idlote = r_lote.idlote;
      
        pk_estoque.retirar_pendencia(v_idarm_des, v_local_des,
                                     r_lote.idlote, v_qtde, p_usuario,
                                     'LOTE SUBSTITUIDO PELO LOTE N:' ||
                                      P_LOTE || ' DO REMANEJAMENTO N:' ||
                                      P_IDREMANEJAMENTO ||
                                      '. ATUALIZA LOTE ANTIGO.');
      
        pk_estoque.retirar_adicionar(v_idarm_des, v_local_des,
                                     r_lote.idlote, r_lote.qtde, p_usuario,
                                     'LOTE SUBSTITUIDO PELO LOTE N:' ||
                                      P_LOTE || ' DO REMANEJAMENTO N:' ||
                                      P_IDREMANEJAMENTO ||
                                      '. ATUALIZA LOTE ANTIGO.');
      
        /* - atualiza a pendencia e o adicionar do novo lote para o endereco de origem,*/
        pk_estoque.incluir_pendencia(v_idarm_ori, v_local_ori, p_lote,
                                     p_qtde, p_usuario,
                                     'REMANEJAMENTO N. ' ||
                                      P_IDREMANEJAMENTO ||
                                      ' ATUALIZA A PENDENCIA E O ADICIONAR DO NOVO LOTE PARA O ENDERECO DE ORIGEM');
        /* - verifica se a pendencia do lote anterior e maior que a do novo lote
        - caso for, insere a qtde do lote novo */
        if (v_qtde > p_qtde) then
          -- grava como pendencia a qtde do lote novo.
          -- grava a diferenca para que seja adicionada no proximo lote.
          v_pend := p_qtde;
          v_dif  := v_qtde - p_qtde;
        else
          -- verifica se existe alguma pendencia de diferenca nos lotes anteriores.
          select nvl(sum(diferenca), 0)
            into v_dif
            from loteremanejamento
           where idremanejamento = p_idremanejamento
             and diferenca > 0;
          if (v_dif + v_qtde) < p_qtde then
            v_pend := v_qtde + v_dif;
            v_dif  := 0;
          else
            v_pend := v_qtde + (p_qtde - v_qtde);
            v_dif  := (v_dif + v_qtde) - v_pend;
          end if;
        end if;
        /* - atualiza a pendencia e o adicionar do novo lote para o endereco de destino,
        verifica se ja existe o lote no local, se nao existir ele cadastra. */
      
        pk_estoque.incluir_pendencia(v_idarm_des, v_local_des, p_lote,
                                     v_pend, p_usuario,
                                     'REMANEJAMENTO N. ' ||
                                      P_IDREMANEJAMENTO ||
                                      ' ATUALIZA A PENDENCIA E O ADICIONAR DO NOVO LOTE PARA O ENDERECO DE DESTINO');
      
        pk_estoque.incluir_adicionar(v_idarm_des, v_local_des, p_lote,
                                     p_qtde, p_usuario,
                                     'REMANEJAMENTO N. ' ||
                                      P_IDREMANEJAMENTO ||
                                      ' ATUALIZA A PENDENCIA E O ADICIONAR DO NOVO LOTE PARA O ENDERECO DE DESTINO');
      
        -- atualiza a tabela de lotes no remanejamento, trocando o lote antigo pelo lote novo.
        update loteremanejamento
           set idlote       = p_lote,
               qtde         = p_qtde,
               conferido    = c_sim,
               controlaqtde = c_nao,
               diferenca    = v_dif
         where idremanejamento = p_idremanejamento
           and idlote = r_lote.idlote;
        -- atualizando paletseparacao
        update paletseparacao
           set idlote = p_lote
         where idarmazem = v_idarm_des
           and idlocal = v_local_des
           and idlote = r_lote.idlote
           and idromaneio in (select idromaneio
                                from romaneiopai
                               where processado = c_nao);
      else
        v_msg := t_message('LOTE NAO ENCONTRADO NO ENDERECO DE ORIGEM, OU QUANTIDADE VINCULADA A OUTRO REMANEJAMENTO.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      -- lote encontra-se na tab. de lote remanejamento.
      update loteremanejamento
         set conferido = c_sim
       where idremanejamento = p_idremanejamento
         and idlote = p_lote;
    end if;
    commit;
  exception
    when no_data_found then
      v_msg := t_message('LOTE NAO ENCONTRADO PARA REMANEJAMENTO ESPECIFICADO.');
      raise_application_error(-20000, v_msg.formatMessage);
  end;

  /*
  * Gera os lotes para serem remanejados do picking para o pulmao
  */
  procedure Gerar_Lotes
  (
    p_remanejamento in number,
    p_idarmazem     in number,
    p_idlocal       in local.idlocal%type,
    p_lotes         in number,
    p_fator         in number,
    p_iduser        in number,
    p_idproduto     in produto.idproduto%type
  ) is
    cursor c_llocal is
      select v.idarmazem, v.idlocal, v.tipo, v.buffer, v.iddepositante,
             v.idlote, v.idproduto, v.estoque, v.pendencia, v.reservado,
             v.adicionar, v.disp, l.barra, l.estado, l.tipopalet,
             l.qtdedisponivel, l.descr descrlote, l.dtvenc, l.dtfabricacao,
             l.loteadicional
        from v_estoque_local v, lote l
       where v.idarmazem = p_idarmazem
         and v.idlocal = p_idlocal
         and v.idproduto = p_idproduto
         and l.idlote = v.idlote
         and (v.estoque + v.adicionar) - (v.pendencia + v.reservado) > 0
         and v.loteliberado = c_sim
       order by l.qtdedisponivel desc, v.dtalocacao;
  
    C_REMANJ_PK_PL constant number := 3;
  
    r             c_llocal%rowtype;
    v_idlote      number;
    v_i           number;
    v_qtdecoberta number;
    v_disp        number;
    v_lote        lote%rowtype;
    v_qtde        number;
    v_restante    number;
    v_msg         t_message;
  begin
    select sum(v.disp)
      into v_disp
      from v_estoque_local v
     where v.idarmazem = p_idarmazem
       and v.idlocal = p_idlocal
       and v.loteliberado = c_sim;
  
    if v_disp < p_lotes * p_fator then
      v_msg := t_message('Quantidade Nao Disponivel no endereco de picking.' ||
                         CHR(13) || 'Geracao de Lotes Cancelada.');
      raise_application_error(-20358, v_msg.formatMessage);
    else
      if c_llocal%isopen then
        close c_llocal;
      end if;
      open c_llocal;
      fetch c_llocal
        into r;
      if c_llocal%notfound then
        v_msg := t_message('Não existem lotes cadastrados para esse remanejamento.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      for v_i in 1 .. p_lotes
      loop
        select seq_lote.nextval
          into v_idlote
          from dual;
      
        -- preenchendo os dados para o lote
        v_lote.idproduto     := r.idproduto;
        v_lote.barra         := pk_produto.retornar_codbarra(r.idproduto, 1);
        v_lote.liberado      := c_sim;
        v_lote.qtdeentrada   := p_fator;
        v_lote.qtdemapaaloc  := p_fator;
        v_lote.idusuario     := p_iduser;
        v_lote.iddepositante := r.iddepositante;
        v_lote.descr         := r.descrlote;
        v_lote.dtvenc        := r.dtvenc;
        v_lote.dtalocacao    := sysdate;
        v_lote.dtentrada     := sysdate;
        v_lote.situacao      := c_liberado;
        v_lote.tipopalet     := r.tipopalet;
        v_lote.estado        := r.estado;
        v_lote.idarmazem     := p_idarmazem;
        v_lote.dtfabricacao  := r.dtfabricacao;
        v_lote.loteadicional := r.loteadicional;
      
        if (pk_lote.isLoteIndustriaComMaisDeUmVenc(r.iddepositante,
                                                   r.idproduto, r.descrlote,
                                                   r.dtvenc)) then
          raise_application_error(-20000,
                                  'Não é possível cadastrar lote do mesmo produto/depositante com o mesmo lote indústria e data de vencimento diferentes. Depositante:' ||
                                   r.iddepositante || '. Produto: ' ||
                                   r.idproduto || ' Lote Indústria: ' ||
                                   r.descrlote || ' Data Venc: ' || r.dtvenc);
        
        end if;
      
        v_idlote := pk_lote.cadastrar_lote(v_lote, null, 'N');
      
        pk_picking_dinamico.addGttPickingDinamico(v_lote.idproduto,
                                                  v_lote.iddepositante,
                                                  p_idlocal,
                                                  v_lote.idarmazem, 1);
      
        pk_estoque.incluir_estoque(p_idarmazem, p_idlocal, v_idlote,
                                   p_fator, p_iduser,
                                   'LOTE GERADO INTERNAMENTE', c_nao);
        v_restante := p_fator;
      
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde,
           diferenca)
        values
          (p_remanejamento, v_idlote, p_fator, c_nao, c_sim, 0);
      
        while (v_restante > 0)
              and (c_llocal%found)
        loop
          -- calcula a quantidade do lote que sera criado
          if r.disp > v_restante then
            v_qtde := v_restante;
          else
            v_qtde := r.disp;
          end if;
        
          -- calcula a quantidade disponivel coberta
          if (v_restante > r.qtdedisponivel) then
            v_qtdecoberta := r.qtdedisponivel;
          else
            v_qtdecoberta := v_restante;
          end if;
        
          if v_qtdecoberta > v_qtde then
            v_qtdecoberta := v_qtde;
          end if;
        
          -- insere o composicao do lote para rastreabilidade de cobertura
          pk_lote.inserirComposicaoLote(v_idlote, r.idlote, v_qtde,
                                        v_qtdecoberta, C_REMANJ_PK_PL,
                                        p_remanejamento);
        
          pk_lote.inserirComposicaoLoteKit(r.idlote, v_idlote, v_qtde);
        
          pk_lote.inserirBarraOriginal(v_idlote);
        
          -- adiciona quantidade disponivel para o lote formado no inventario
          update lote
             set qtdedisponivel = nvl(qtdedisponivel, 0) + v_qtdecoberta
           where idlote = v_idlote;
        
          -- retira quantidade disponivel do lote baixado no inventario
          update lote
             set qtdedisponivel = nvl(qtdedisponivel, 0) - v_qtdecoberta
           where idlote = r.idlote;
        
          pk_estoque.retirar_estoque(r.idarmazem, r.idlocal, r.idlote,
                                     v_qtde, p_iduser,
                                     'QUANTIDADE DISPONIVEL NO PICKING ZERADA.(rotina gerar lotes)',
                                     'N');
        
          if ((r.tipo = 0) AND (r.buffer = 'N')) then
            pk_picking_dinamico.addGttPickingDinamico(r.idproduto,
                                                      r.iddepositante,
                                                      r.idlocal, r.idarmazem,
                                                      0);
          end if;
        
          r.qtdedisponivel := r.qtdedisponivel - v_qtdecoberta;
          r.disp           := r.disp - v_qtde;
          v_restante       := v_restante - v_qtde;
        
          if r.disp <= 0 then
            fetch c_llocal
              into r;
          end if;
        end loop;
      
        pk_picking_dinamico.deletar_picking_dinamico;
      
        pk_lote.valorarLote(v_idlote);
      
        pk_lote.atualizaInfLote(v_idlote, C_MOV_CADASTRO_LOTE);
      
        if v_restante > 0 then
          v_msg := t_message('NAO FOI ENCONTRADO LOTE SUFICIENTE PARA FORMACAO. REMANEJAMENTO PK->PL.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end loop;
      pk_picking_dinamico.inserir_picking_dinamico;
    end if;
  end;

  procedure recalcula_paletseparacao
  (
    p_lote          in lote.idlote%type,
    p_remanejamento in remanejamento.idremanejamento%type,
    p_usuario       in usuario.idusuario%type
  ) is
    cursor c_local
    (
      p_idarmazem local.idarmazem%type,
      p_idlocal   in local.idlocal%type,
      p_lote      in lote.idlote%type,
      p_idproduto in number
    ) is
      select idlote, idarmazem, idlocal, l.disp
        from v_estoque_local l
       where l.idarmazem = p_idarmazem
         and l.idlocal = p_idlocal
         and l.idlote <> p_lote
         and l.loteliberado = c_sim
         and l.idproduto = p_idproduto
         and l.idlote not in (select idlote
                                from conferenciaentradadet c
                               where c.idlote is not null)
       order by disp desc;
  
    r_local     c_local%rowtype;
    v_qtde      number;
    v_idlocal   local.idlocal%type;
    v_idarmazem local.idarmazem%type;
    v_id        number;
  begin
    -- SELECIONA OS ROMANEIOS QUE ESTAVAO NECESSITANDO DA QTDE NAO REMANEJADA
    for c_paletsep in (select rp.idromaneio, ps.idarmazem, ps.idlocal,
                              ps.idlote, ps.qtdeunit qtde, ps.ordem,
                              l.idproduto, ps.idpalet, l.barra, ps.separado
                         from romaneiopai rp, palet pa, paletseparacao ps,
                              lote l, remanejamento r
                        where l.idlote = ps.idlote
                          and rp.erro = c_nao
                          and rp.gerado = c_sim
                          and rp.processado = c_nao
                          and ps.idlote = p_lote
                          and pa.idromaneio = rp.idromaneio
                          and ps.idromaneio = pa.idromaneio
                          and ps.idpalet = pa.idpalet
                          and ps.idlocal = r.idlocaldestino
                          and ps.idarmazem = r.idarmazemdestino
                          and r.idremanejamento = p_remanejamento
                          and rp.tipo = 0
                        order by ps.idarmazem, ps.idlocal, ps.idlote)
    loop
      -- busca os locais em remanejamento que podem suprir a qtde.
      if c_local%isopen then
        close c_local;
      end if;
      open c_local(c_paletsep.idarmazem, c_paletsep.idlocal, p_lote,
                   c_paletsep.idproduto);
      fetch c_local
        into r_local;
      v_qtde := c_paletsep.qtde;
      while ((c_local%found) and (v_qtde > 0))
      loop
        -- verifica se o lote atende a qtde do romaneio
        if v_qtde <= r_local.disp then
          -- o lote selecionado supri a qtde a ser trocada.
          update paletseparacao
             set idlote = r_local.idlote
           where idarmazem = c_paletsep.idarmazem
             and idlocal = c_paletsep.idlocal
             and idlote = c_paletsep.idlote;
        
          pk_estoque.retirar_pendencia(c_paletsep.idarmazem,
                                       c_paletsep.idlocal, c_paletsep.idlote,
                                       v_qtde, p_usuario,
                                       'SUBSTITUICAO DE LOTE REMANEJAMENTO N:' ||
                                        P_REMANEJAMENTO ||
                                        '. SUBTRAIDA A PENDENCIA DO LOTE E TRANSFERIDA A PENDENCIA DO LOTE :' ||
                                        P_LOTE);
        
          pk_estoque.incluir_pendencia(r_local.idarmazem, r_local.idlocal,
                                       r_local.idlote, v_qtde, p_usuario,
                                       'SUBSTITUICAO DE LOTE REMANEJAMENTO N:' ||
                                        P_REMANEJAMENTO ||
                                        '. ADICIONADA A PENDENCIA PROVENIENTE DO LOTE :' ||
                                        P_LOTE);
          v_qtde := 0;
        else
          --se a quantidade nao for suficiente
          insert into paletseparacao
            (idromaneio, idpalet, idarmazem, idlocal, idlote, idusuario,
             ordem, qtde, separado, qtdeunit)
          values
            (c_paletsep.idromaneio, c_paletsep.idpalet,
             c_paletsep.idarmazem, c_paletsep.idlocal, r_local.idlote,
             p_usuario, c_paletsep.ordem, r_local.disp, c_paletsep.separado,
             r_local.disp);
        
          pk_estoque.incluir_pendencia(r_local.idarmazem, r_local.idlocal,
                                       r_local.idlote, r_local.disp,
                                       p_usuario,
                                       'SUBSTITUICAO DE LOTE REMANEJAMENTO N:' ||
                                        P_REMANEJAMENTO ||
                                        '. ADICIONADA A PENDENCIA PROVENIENTE DO LOTE :' ||
                                        P_LOTE);
        
          update paletseparacao
             set qtde     = qtde - r_local.disp,
                 qtdeunit = qtdeunit - r_local.disp
           where idarmazem = c_paletsep.idarmazem
             and idlocal = c_paletsep.idlocal
             and idlote = c_paletsep.idlote;
        
          pk_estoque.retirar_pendencia(c_paletsep.idarmazem,
                                       c_paletsep.idlocal, c_paletsep.idlote,
                                       r_local.disp, p_usuario,
                                       'SUBSTITUICAO DE LOTE REMANEJAMENTO N:' ||
                                        P_REMANEJAMENTO ||
                                        '. SUBTRAIDA A PENDENCIA DO LOTE E TRANSFERIDA A PENDENCIA DO LOTE :' ||
                                        P_LOTE);
        
          v_qtde := v_qtde - r_local.disp;
        end if;
        fetch c_local
          into r_local;
      end loop;
      if v_qtde > 0 then
        select r.idlocalorigem, r.idarmazemorigem
          into v_idlocal, v_idarmazem
          from remanejamento r
         where r.idremanejamento = p_remanejamento;
      
        v_id := cadastrar_remanejamento(v_idarmazem, v_idarmazem, v_idlocal,
                                        c_paletsep.idlocal, p_usuario,
                                        c_paletsep.idromaneio,
                                        'REABASTECIMENTO PARA ROMANEIO: ' ||
                                         c_paletsep.idromaneio);
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, idromaneio)
        values
          (v_id, c_paletsep.idlote, v_qtde, c_nao, c_paletsep.idromaneio);
      
      end if;
    end loop;
  end;

  procedure reabastecerPorLastro
  (
    p_idarmazem     in number,
    p_iddepositante in number,
    p_idproduto     in number,
    p_idlocal       in local.idlocal%type,
    p_idusuario     in number
  ) is
  
    c_estlocal           cursor_estlocal;
    r_estlocal           rec_estlocal;
    v_id                 number;
    v_qtdeRemanejamento  number;
    v_qtdeConsumirLastro number;
    v_gerouRemanejamento number;
    r_loteunico          pk_lote.t_loteunico;
    v_enderecoCompativel boolean;
    v_idLocalPickNovo    local.idlocal%type;
    v_msgErro            varchar2(1000);
    v_enderPickUtilizar  local.idlocal%type;
    v_msg                t_message;
    v_msgDescr           t_message;
    v_planejado          char(1) := 'S';
    v_reabNaoPlanejado   number;
  
    procedure openCursorEstLocal
    (
      p_cursor                   in out cursor_estlocal,
      p_estlocal                 in out rec_estlocal,
      p_depositante              in number,
      p_produto                  in number,
      p_estado                   in lote.estado%type,
      p_armazem                  in number,
      p_tipopermitirpickingsetor in setor.tipopermitirpickingsetor%type
    ) is
      v_sql varchar2(5000);
    begin
      if (p_cursor%isopen) then
        close p_cursor;
      end if;
    
      if (p_tipopermitirpickingsetor = 0) then
      
        v_sql := 'select lt.idlote, lo.idlocal,
                         (ll.estoque - ll.pendencia + ll.adicionar) disp,
                         lt.descr loteindustria, lt.dtvenc
                    from lotelocal ll, local lo, lote lt, produtodepositante pd
                   where (ll.estoque - ll.pendencia + ll.adicionar) > 0
                     and lo.id = ll.idendereco
                     and lo.tipo in (1, 2)
                     and lo.ativo = ''S''
                     and lo.idarmazem = ' || p_armazem || '
                     and pd.idproduto = lt.idproduto
                     and pd.identidade = lt.iddepositante
                     and pd.tipopicking = ' ||
                 p_tipopermitirpickingsetor || '
                     and not exists (select 1
                            from setorrecebimento sr, tiporecebimento tr
                           where sr.idsetor = lo.idsetor
                             and tr.idtiporecebimento = sr.idtiporecebimento
                             and tr.classificacao = ''R'')
                     and lt.idlote = ll.idlote
                     and lt.liberado = ''S''
                     and lt.tipolote = ''L''
                     and lt.estado = ''' || p_estado || '''
                     and lt.idproduto = ' || p_produto || '
                     and lt.iddepositante = ' ||
                 p_depositante || '
                   order by nvl(lt.dtvenc, sysdate), lo.idlocal ';
      
      elsif (p_tipopermitirpickingsetor = 1) then
      
        v_sql := 'select lt.idlote, lo.idlocal,
                         (ll.estoque - ll.pendencia + ll.adicionar) disp,
                         lt.descr loteindustria, lt.dtvenc
                    from lotelocal ll, local lo, lote lt, produtodepositante pd, embalagem e
                   where (ll.estoque - ll.pendencia + ll.adicionar) > 0
                     and lo.id = ll.idendereco
                     and lo.tipo in (1, 2)
                     and lo.ativo = ''S''
                     and lo.idarmazem = ' || p_armazem || '
                     and pd.idproduto = lt.idproduto
                     and pd.identidade = lt.iddepositante
                     and pd.tipopicking = ' ||
                 p_tipopermitirpickingsetor || '
                     and lt.fatorconversao = 1
                     and e.idproduto = lt.idproduto
                     and e.barra = lt.barra
                     and e.caixafechada = ''N''
                     and not exists (select 1
                            from setorrecebimento sr, tiporecebimento tr
                           where sr.idsetor = lo.idsetor
                             and tr.idtiporecebimento = sr.idtiporecebimento
                             and tr.classificacao = ''R'')
                     and lt.idlote = ll.idlote
                     and lt.liberado = ''S''
                     and lt.tipolote = ''L''
                     and lt.estado = ''' || p_estado || '''
                     and lt.idproduto = ' || p_produto || '
                     and lt.iddepositante = ' ||
                 p_depositante || '
                   order by nvl(lt.dtvenc, sysdate), lo.idlocal ';
      
      end if;
    
      open p_cursor for v_sql;
    
      fetch p_cursor
        into p_estlocal;
    end;
  
  begin
  
    -- selecionando os enderecos que necessitam de reabastecimento
    for r_end in (select v.idarmazem, v.idlocal, v.estanteria, v.idproduto,
                         v.iddepositante, v.estadolote,
                         v.pontoreabastecimento,
                         nvl(v.limiteressuprimento, 0) pontoressuprimento,
                         v.fatorconversao, v.disponivelpk disponivel,
                         v.fracionado, pd.loteuniconoendereco,
                         (e.lastro * e.fatorconversao) qtdelastroun,
                         v.tipopermitirpickingsetor
                    from v_reabastecimento_planejado v, produtodepositante pd,
                         embalagem e
                   where v.idproduto = p_idproduto
                     and v.iddepositante = p_iddepositante
                     and v.idlocal = p_idlocal
                     and v.idarmazem = p_idarmazem
                     and pd.idproduto = p_idproduto
                     and pd.identidade = p_iddepositante
                     and e.idproduto = v.idproduto
                     and e.barra =
                         pk_produto.RetornarCodBarraMaiorFator(v.idproduto))
    
    loop
    
      v_enderPickUtilizar := r_end.idlocal;
    
      delete from gtt_selecao;
    
      v_qtdeRemanejamento := 0;
    
      v_qtdeConsumirLastro := r_end.qtdelastroun;
    
      openCursorEstLocal(c_estlocal, r_estlocal, r_end.iddepositante,
                         r_end.idproduto, r_end.estadolote, r_end.idarmazem,
                         r_end.tipopermitirpickingsetor);
    
      while (c_estlocal%found)
      loop
        /*      if (r_end.loteuniconoendereco = 1) then
        
          select count(1)
            into v_estoqueIncompativel
            from dual
           where exists
           (select 1
                    from lotelocal ll, lote lt
                   where ll.idarmazem = r_end.idarmazem
                     and ll.idlocal = r_end.idlocal
                     and ll.estoque + ll.adicionar > 0
                     and lt.idlote = ll.idlote
                     and lt.idproduto = r_end.idproduto
                     and lt.iddepositante = r_end.iddepositante
                     and (decode(lt.descr, r_estlocal.loteindustria, 1, 0) = 0 or
                         decode(lt.dtvenc, r_estlocal.dtvenc, 1, 0) = 0));
        
        end if;*/
      
        r_loteunico.idProduto           := r_end.idproduto;
        r_loteunico.estado              := r_end.estadolote;
        r_loteunico.loteindustria       := r_estlocal.loteindustria;
        r_loteunico.dtvencimento        := r_estlocal.dtvenc;
        r_loteunico.loteuniconoendereco := r_end.loteuniconoendereco;
        r_loteunico.iddepositante       := r_end.iddepositante;
      
        v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                    r_end.idarmazem,
                                                                    r_end.idlocal,
                                                                    v_msgErro);
      
        if not v_enderecoCompativel then
          v_idLocalPickNovo := null;
          for c_endPicking in (select idarmazem, idlocal
                                 from (select pl.idarmazem, pl.idlocal,
                                               0 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts,
                                               lotelocal ll, lote lt
                                         where pl.identidade =
                                               r_end.iddepositante
                                           and pl.idproduto = r_end.idproduto
                                           and pl.idarmazem = r_end.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               r_end.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and ll.idendereco = l.id
                                           and (ll.estoque + ll.adicionar) > 0
                                           and lt.idlote = ll.idlote
                                           and lt.idproduto = pl.idproduto
                                           and lt.iddepositante =
                                               pl.identidade
                                           and lt.descr =
                                               r_estlocal.loteindustria
                                           and lt.dtvenc = r_estlocal.dtvenc
                                        union
                                        select pl.idarmazem, pl.idlocal,
                                               1 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts
                                         where pl.identidade =
                                               r_end.iddepositante
                                           and pl.idproduto = r_end.idproduto
                                           and pl.idarmazem = r_end.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               r_end.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and not exists
                                         (select 1
                                                  from lotelocal ll
                                                 where ll.idendereco = l.id
                                                   and (ll.estoque +
                                                       ll.adicionar) > 0)
                                        union
                                        select pl.idarmazem, pl.idlocal,
                                               2 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts,
                                               lotelocal ll, lote lt
                                         where pl.identidade =
                                               r_end.iddepositante
                                           and pl.idproduto = r_end.idproduto
                                           and pl.idarmazem = r_end.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               r_end.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and ll.idendereco = l.id
                                           and (ll.estoque + ll.adicionar) > 0
                                           and lt.idlote = ll.idlote
                                           and lt.idproduto = pl.idproduto
                                           and lt.iddepositante =
                                               pl.identidade
                                           and (lt.descr <>
                                               r_estlocal.loteindustria or
                                               lt.dtvenc <> r_estlocal.dtvenc))
                                order by ordem)
          
          loop
          
            v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                        c_endPicking.Idarmazem,
                                                                        c_endPicking.Idlocal,
                                                                        v_msgErro);
          
            if (v_enderecoCompativel) then
              v_idLocalPickNovo   := c_endPicking.Idlocal;
              v_enderPickUtilizar := v_idLocalPickNovo;
            
              v_msg      := t_message('Reabastecimento Planejado');
              v_msgDescr := t_message('Local: {0}' ||
                                      ' não foi reabastecido por falta de estoque compatível. ' ||
                                      chr(13) ||
                                      'Reabastecimento planejado para o local: ' ||
                                      '{1}.');
              v_msgDescr.addParam(r_end.idlocal);
              v_msgDescr.addParam(v_enderPickUtilizar);
              pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                             v_msgDescr.formatMessage,
                                             pk_gttresumoexecucao.TIPO_ALERTA);
              exit;
            end if;
          
          end loop;
        
          if ((pk_onda.usaPickingDinamico(r_end.idproduto,
                                          r_end.iddepositante,
                                          r_end.idarmazem) = 1) and
             (v_idLocalPickNovo is null)) then
          
            v_idLocalPickNovo := pk_picking_dinamico.inserir_picking_dinamico_auto(r_end.idproduto,
                                                                                   r_end.iddepositante,
                                                                                   r_end.idarmazem,
                                                                                   0,
                                                                                   r_loteunico);
          
            if v_idLocalPickNovo is not null then
              v_enderPickUtilizar  := v_idLocalPickNovo;
              v_enderecoCompativel := true;
            
              v_msg      := t_message('Reabastecimento Planejado');
              v_msgDescr := t_message('Local: {0}' ||
                                      ' não foi reabastecido por falta de estoque compatível. ' ||
                                      chr(13) ||
                                      'Reabastecimento planejado para o local: ' ||
                                      '{1}.');
              v_msgDescr.addParam(r_end.idlocal);
              v_msgDescr.addParam(v_enderPickUtilizar);
              pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                             v_msgDescr.formatMessage,
                                             pk_gttresumoexecucao.TIPO_ALERTA);
            end if;
          
          end if;
        end if;
      
        if (v_enderecoCompativel) then
          v_qtdeRemanejamento := v_qtdeConsumirLastro;
        
          if v_qtdeRemanejamento > r_estlocal.disp then
            v_qtdeRemanejamento := r_estlocal.disp;
          end if;
        
          v_qtdeConsumirLastro := v_qtdeConsumirLastro -
                                  v_qtdeRemanejamento;
        
          v_id := cadastrar_remanejamento(r_end.idarmazem, r_end.idarmazem,
                                          r_estlocal.idlocal,
                                          v_enderPickUtilizar, p_idusuario,
                                          NULL,
                                          'REABASTECIMENTO POR DEMANDA PLANEJADA',
                                          'N', 'N');
        
          insert into gtt_selecao
          values
            (v_id);
        
          insert into loteremanejamento
            (idremanejamento, idlote, qtde, conferido)
          values
            (v_id, r_estlocal.idlote, v_qtdeRemanejamento, c_normal);
        
          exit when v_qtdeConsumirLastro = 0;
        
        end if;
        fetch c_estlocal
          into r_estlocal;
      end loop;
    
      select count(1)
        into v_gerouRemanejamento
        from gtt_selecao;
    
      if (v_gerouRemanejamento = 0) then
      
        if (v_qtdeConsumirLastro > 0) then
          v_msg      := t_message('Reabastecimento Planejado');
          v_msgDescr := t_message('Local: {0} não foi reabastecido por falta de estoque compatível. ' ||
                                  'Não foi possível cadastrar novo picking para o produto.');
          v_msgDescr.addParam(r_end.idlocal);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ALERTA);
        
        else
          v_msg      := t_message('Reabastecimento Planejado');
          v_msgDescr := t_message('Local: {0} não foi reabastecido por falta de estoque.');
          v_msgDescr.addParam(r_end.idlocal);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ALERTA);
        
        end if;
      
      end if;
    
    end loop;
  
    select a.gerareabnaoplanejado
      into v_reabNaoPlanejado
      from armazem a
     where a.idarmazem = p_idarmazem;
  
    if (v_reabNaoPlanejado = 1) then
      v_planejado := 'N';
    end if;
  
    update remanejamento
       set planejado = v_planejado
     where idremanejamento in (select idselecionado
                                 from gtt_selecao);
  
    for c in (select idselecionado
                from gtt_selecao)
    loop
      pk_remanejamento.regraRemanejamentoLoteUnico(c.idselecionado);
    end loop;
  
  end;

  procedure reabastecerPorEmbalagem
  (
    p_idarmazem     in number,
    p_iddepositante in number,
    p_idproduto     in number,
    p_idlocal       in local.idlocal%type,
    p_idusuario     in number
  ) is
  
    c_lote               cursor_lote;
    r_lote               rec_lote;
    v_ressuprimento      number;
    v_qtde               number;
    v_qtdelote           number;
    v_idremanejmanto     number;
    v_exit               boolean;
    v_estoque            number := 0;
    v_gerouRemanejamento number;
    r_loteunico          pk_lote.t_loteunico;
    v_enderecoCompativel boolean;
    v_idLocalPickNovo    local.idlocal%type;
    v_msgErro            varchar2(1000);
    v_enderPickUtilizar  local.idlocal%type;
    v_msg                t_message;
    v_msgDescr           t_message;
    v_planejado          char(1) := 'S';
    v_reabNaoPlanejado   number;
  
    procedure openCursorLote
    (
      p_cursor                   in out cursor_lote,
      p_lote                     in out rec_lote,
      p_depositante              number,
      p_produto                  number,
      p_estado                   lote.estado%type,
      p_armazem                  number,
      p_tipopermitirpickingsetor setor.tipopermitirpickingsetor%type
    ) is
      v_sql varchar2(5000);
    begin
      if (p_cursor%isopen) then
        close p_cursor;
      end if;
    
      if (p_tipopermitirpickingsetor = 0) then
      
        v_sql := 'select ll.idarmazem, ll.idlocal, ll.idlote,
                         ll.estoque - ll.pendencia + ll.adicionar disponivel,
                         nvl(lt.dtvenc, trunc(sysdate)) datavencimento, s.idsetor,
                         (case
                            when e.fatorconversao = 1 then
                             ec.fatorconversao
                            else
                             e.fatorconversao
                          end) fatorconversao, lt.descr loteindustria
                    from lotelocal ll, lote lt, local l, setor s, embalagem e, embalagem ec,
                         produtodepositante pd
                   where l.tipo in (1, 2)
                     and decode(l.ativo, ''S'', 1, 0) = 1
                     and decode(l.buffer, ''S'', 1, 0) = 0
                     and decode(lt.tipolote, ''L'', 1, 0) = 1
                     and decode(lt.liberado, ''S'', 1, 0) = 1
                     and decode(s.expedicao, ''S'', 1, 0) = 1
                     and lt.estado = ''' || p_estado || '''
                     and lt.idproduto = ' || p_produto || '
                     and lt.iddepositante = ' ||
                 p_depositante || '
                     and ll.idarmazem = ' || p_armazem || '
                     and s.idsetor = l.idsetor
                     and e.barra = lt.barra
                     and e.idproduto = lt.idproduto
                     and ec.barra = pk_produto.RetBarraMaiorFatorSemErro(lt.idproduto)
                     and ec.idproduto = lt.idproduto
                     and l.idlocal = ll.idlocal
                     and l.idarmazem = ll.idarmazem
                     and lt.idlote = ll.idlote
                     and ll.estoque - ll.pendencia + ll.adicionar > 0
                     and pd.idproduto = lt.idproduto
                     and pd.identidade = lt.iddepositante
                     and pd.tipopicking = ' ||
                 p_tipopermitirpickingsetor || '
                     and not exists (select 1
                            from setorrecebimento sr, tiporecebimento tr
                           where sr.idsetor = l.idsetor
                             and tr.idtiporecebimento = sr.idtiporecebimento
                             and tr.classificacao = ''R'')
                   order by nvl(lt.dtvenc, trunc(sysdate)), ll.idlote ';
      
      elsif (p_tipopermitirpickingsetor = 1) then
      
        v_sql := 'select ll.idarmazem, ll.idlocal, ll.idlote,
                         ll.estoque - ll.pendencia + ll.adicionar disponivel,
                         nvl(lt.dtvenc, trunc(sysdate)) datavencimento, s.idsetor,
                         (case
                            when e.fatorconversao = 1 then
                             ec.fatorconversao
                            else
                             e.fatorconversao
                          end) fatorconversao, lt.descr loteindustria
                    from lotelocal ll, lote lt, local l, setor s, embalagem e, embalagem ec,
                         produtodepositante pd
                   where l.tipo in (1, 2)
                     and decode(l.ativo, ''S'', 1, 0) = 1
                     and decode(l.buffer, ''S'', 1, 0) = 0
                     and decode(lt.tipolote, ''L'', 1, 0) = 1
                     and decode(lt.liberado, ''S'', 1, 0) = 1
                     and decode(s.expedicao, ''S'', 1, 0) = 1
                     and lt.estado = ''' || p_estado || '''
                     and lt.idproduto = ' || p_produto || '
                     and lt.iddepositante = ' ||
                 p_depositante || '
                     and ll.idarmazem = ' || p_armazem || '
                     and s.idsetor = l.idsetor
                     and e.barra = lt.barra
                     and e.idproduto = lt.idproduto
                     and e.fatorconversao = 1
                     and e.caixafechada = ''N''
                     and ec.barra = pk_produto.RetBarraMaiorFatorSemErro(lt.idproduto)
                     and ec.idproduto = lt.idproduto
                     and l.idlocal = ll.idlocal
                     and l.idarmazem = ll.idarmazem
                     and lt.idlote = ll.idlote
                     and ll.estoque - ll.pendencia + ll.adicionar > 0
                     and pd.idproduto = lt.idproduto
                     and pd.identidade = lt.iddepositante
                     and pd.tipopicking = ' ||
                 p_tipopermitirpickingsetor || '
                     and not exists (select 1
                            from setorrecebimento sr, tiporecebimento tr
                           where sr.idsetor = l.idsetor
                             and tr.idtiporecebimento = sr.idtiporecebimento
                             and tr.classificacao = ''R'')
                   order by nvl(lt.dtvenc, trunc(sysdate)), ll.idlote ';
      
      end if;
    
      open p_cursor for v_sql;
    
      fetch p_cursor
        into p_lote;
    end;
  
  begin
  
    for c_origem in (select v.idarmazem, v.idlocal, v.estanteria, v.idproduto,
                            v.iddepositante, v.estadolote,
                            v.pontoreabastecimento,
                            nvl(v.limiteressuprimento, 0) pontoressuprimento,
                            v.fatorconversao, v.disponivelpk disponivel,
                            v.fracionado, pd.loteuniconoendereco,
                            v.tipopermitirpickingsetor
                       from v_reabastecimento_planejado v,
                            produtodepositante pd
                      where v.idproduto = p_idproduto
                        and v.iddepositante = p_iddepositante
                        and v.idlocal = p_idlocal
                        and v.idarmazem = p_idarmazem
                        and pd.idproduto = p_idproduto
                        and pd.identidade = p_iddepositante)
    loop
    
      v_enderPickUtilizar := c_origem.idlocal;
    
      delete from gtt_selecao;
    
      v_ressuprimento := (c_origem.pontoressuprimento *
                         c_origem.fatorconversao) - c_origem.disponivel;
      v_qtde          := 0;
      v_exit          := false;
    
      openCursorLote(c_lote, r_lote, c_origem.iddepositante,
                     c_origem.idproduto, c_origem.estadolote,
                     c_origem.idarmazem, c_origem.tipopermitirpickingsetor);
    
      if (c_origem.pontoressuprimento = 0) then
        v_msg      := t_message('Reabastecimento Planejado');
        v_msgDescr := t_message('Local: {0}' ||
                                'O Local não será reabastecido pois o "Limite de Ressuprimento" no cadastro do produto deve ser configurado.');
        v_msgDescr.addParam(c_origem.idlocal);
        pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                       v_msgDescr.formatMessage,
                                       pk_gttresumoexecucao.TIPO_ALERTA);
        return;
      end if;
    
      while c_lote%found
            and (v_qtde <
            (c_origem.pontoressuprimento * c_origem.fatorconversao))
            and (not v_exit)
      loop
      
        if (c_origem.loteuniconoendereco = 1) then
          select count(*)
            into v_estoque
            from lotelocal ll
           where ll.idarmazem = c_origem.idarmazem
             and ll.idlocal = c_origem.idlocal
             and ll.estoque + ll.adicionar > 0;
        
          if (v_estoque > 0) then
            select decode(count(*), 0, 1, 0)
              into v_estoque
              from lotelocal ll, lote lt
             where ll.idarmazem = c_origem.idarmazem
               and ll.idlocal = c_origem.idlocal
               and ll.estoque + ll.adicionar > 0
               and lt.idlote = ll.idlote
               and lt.idproduto = c_origem.idproduto
               and lt.iddepositante = c_origem.iddepositante
               and nvl(lt.descr, '-1') = nvl(r_lote.loteindustria, '-1')
               and nvl(lt.dtvenc, sysdate) =
                   nvl(r_lote.datavencimento, sysdate);
          end if;
        end if;
      
        if v_estoque > 0 then
        
          v_idLocalPickNovo := null;
        
          r_loteunico.idProduto           := c_origem.idproduto;
          r_loteunico.estado              := c_origem.estadolote;
          r_loteunico.loteindustria       := r_lote.loteindustria;
          r_loteunico.dtvencimento        := r_lote.datavencimento;
          r_loteunico.loteuniconoendereco := c_origem.loteuniconoendereco;
          r_loteunico.iddepositante       := c_origem.iddepositante;
        
          for c_endPicking in (select idarmazem, idlocal
                                 from (select pl.idarmazem, pl.idlocal,
                                               0 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts,
                                               lotelocal ll, lote lt
                                         where pl.identidade =
                                               c_origem.iddepositante
                                           and pl.idproduto =
                                               c_origem.idproduto
                                           and pl.idarmazem =
                                               c_origem.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               c_origem.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and ll.idendereco = l.id
                                           and (ll.estoque + ll.adicionar) > 0
                                           and lt.idlote = ll.idlote
                                           and lt.idproduto = pl.idproduto
                                           and lt.iddepositante =
                                               pl.identidade
                                           and lt.descr = r_lote.loteindustria
                                           and lt.dtvenc =
                                               r_lote.datavencimento
                                        union
                                        select pl.idarmazem, pl.idlocal,
                                               1 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts
                                         where pl.identidade =
                                               c_origem.iddepositante
                                           and pl.idproduto =
                                               c_origem.idproduto
                                           and pl.idarmazem =
                                               c_origem.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               c_origem.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and not exists
                                         (select 1
                                                  from lotelocal ll
                                                 where ll.idendereco = l.id
                                                   and (ll.estoque +
                                                       ll.adicionar) > 0)
                                        union
                                        select pl.idarmazem, pl.idlocal,
                                               2 ordem
                                          from produtolocal pl, local l,
                                               setor s, tiposetor ts,
                                               lotelocal ll, lote lt
                                         where pl.identidade =
                                               c_origem.iddepositante
                                           and pl.idproduto =
                                               c_origem.idproduto
                                           and pl.idarmazem =
                                               c_origem.idarmazem
                                           and l.idlocal = pl.idlocal
                                           and l.idarmazem = pl.idarmazem
                                           and s.idsetor = l.idsetor
                                           and s.tipopermitirpickingsetor =
                                               c_origem.tipopermitirpickingsetor
                                           and ts.idtiposetor = s.idtiposetor
                                           and ts.normal = 'S'
                                           and l.ativo = 'S'
                                           and l.tipo = 0
                                           and ll.idendereco = l.id
                                           and (ll.estoque + ll.adicionar) > 0
                                           and lt.idlote = ll.idlote
                                           and lt.idproduto = pl.idproduto
                                           and lt.iddepositante =
                                               pl.identidade
                                           and (lt.descr <>
                                               r_lote.loteindustria or
                                               lt.dtvenc <>
                                               r_lote.datavencimento))
                                order by ordem)
          
          loop
          
            v_enderecoCompativel := pk_lote.isLocalPodeReceberLoteUnico(r_loteUnico,
                                                                        c_endPicking.Idarmazem,
                                                                        c_endPicking.Idlocal,
                                                                        v_msgErro);
          
            if (v_enderecoCompativel) then
              v_idLocalPickNovo   := c_endPicking.Idlocal;
              v_enderPickUtilizar := v_idLocalPickNovo;
              v_estoque           := 0;
            
              v_msg      := t_message('Reabastecimento Planejado');
              v_msgDescr := t_message('Local: {0}' ||
                                      ' não foi reabastecido por falta de estoque compatível. ' ||
                                      chr(13) ||
                                      'Reabastecimento planejado para o local: {1}.');
              v_msgDescr.addParam(c_origem.idlocal);
              v_msgDescr.addParam(v_enderPickUtilizar);
              pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                             v_msgDescr.formatMessage,
                                             pk_gttresumoexecucao.TIPO_ALERTA);
              exit;
            end if;
          
          end loop;
        
          if ((pk_onda.usaPickingDinamico(c_origem.idproduto,
                                          c_origem.iddepositante,
                                          c_origem.idarmazem) = 1) and
             (v_idLocalPickNovo is null)) then
          
            v_idLocalPickNovo := pk_picking_dinamico.inserir_picking_dinamico_auto(c_origem.idproduto,
                                                                                   c_origem.iddepositante,
                                                                                   c_origem.idarmazem,
                                                                                   0,
                                                                                   r_loteUnico);
          
            if v_idLocalPickNovo is not null then
              v_enderPickUtilizar := v_idLocalPickNovo;
              v_estoque           := 0;
            
              v_msg      := t_message('Reabastecimento Planejado');
              v_msgDescr := t_message('Local: {0}' ||
                                      ' não foi reabastecido por falta de estoque compatível. ' ||
                                      chr(13) ||
                                      'Reabastecimento planejado para o local: ' ||
                                      '{1}.');
              v_msgDescr.addParam(c_origem.idlocal);
              v_msgDescr.addParam(v_enderPickUtilizar);
              pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                             v_msgDescr.formatMessage,
                                             pk_gttresumoexecucao.TIPO_ALERTA);
            end if;
          
          end if;
        
        end if;
      
        if v_estoque = 0 then
        
          v_qtdelote := 0;
        
          if r_lote.disponivel = v_ressuprimento then
            v_qtdelote := r_lote.disponivel;
            v_exit     := true;
          elsif r_lote.disponivel < v_ressuprimento then
            v_qtdelote := r_lote.disponivel;
          else
            if c_origem.fracionado = 'S' then
              v_qtdelote := v_ressuprimento;
            else
              while (v_qtdelote < v_ressuprimento)
                    and (not v_exit)
              loop
                if (v_qtdelote + r_lote.fatorconversao) <= v_ressuprimento then
                  v_qtdelote := v_qtdelote + r_lote.fatorconversao;
                  v_exit     := false;
                else
                  v_exit := true;
                end if;
              end loop;
            end if;
          end if;
        
          if v_qtdelote > 0 then
          
            v_idremanejmanto := cadastrar_remanejamento(c_origem.idarmazem,
                                                        c_origem.idarmazem,
                                                        r_lote.idlocal,
                                                        v_enderPickUtilizar,
                                                        p_idusuario, NULL,
                                                        'REABASTECIMENTO POR DEMANDA PLANEJADA',
                                                        'N', 'N');
          
            insert into gtt_selecao
            values
              (v_idremanejmanto);
          
            begin
              insert into loteremanejamento
                (idremanejamento, idlote, qtde, conferido)
              values
                (v_idremanejmanto, r_lote.idlote, v_qtdelote, 'N');
            exception
              when dup_val_on_index then
                update loteremanejamento
                   set qtde = qtde + v_qtdelote
                 where idremanejamento = v_idremanejmanto
                   and idlote = r_lote.idlote;
            end;
          end if;
        
          v_qtde          := v_qtde + v_qtdelote;
          v_ressuprimento := v_ressuprimento - v_qtdelote;
        
        end if;
      
        fetch c_lote
          into r_lote;
      end loop;
    
      select count(1)
        into v_gerouRemanejamento
        from gtt_selecao;
    
      if (v_gerouRemanejamento = 0) then
      
        if (v_estoque > 0) then
          v_msg      := t_message('Reabastecimento Planejado');
          v_msgDescr := t_message('Local: {0}' ||
                                  ' não foi reabastecido por falta de estoque compatível. ' ||
                                  'Não foi possível cadastrar novo picking para o produto.');
          v_msgDescr.addParam(c_origem.idlocal);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ALERTA);
        
        else
          v_msg      := t_message('Reabastecimento Planejado');
          v_msgDescr := t_message('Local: {0}' ||
                                  ' não foi reabastecido por falta de estoque.');
          v_msgDescr.addParam(c_origem.idlocal);
          pk_gttresumoexecucao.addResumo(v_msg.formatMessage,
                                         v_msgDescr.formatMessage,
                                         pk_gttresumoexecucao.TIPO_ALERTA);
        
        end if;
      
      end if;
    
      close c_lote;
    
    end loop;
  
    select a.gerareabnaoplanejado
      into v_reabNaoPlanejado
      from armazem a
     where a.idarmazem = p_idarmazem;
  
    if (v_reabNaoPlanejado = 1) then
      v_planejado := 'N';
    end if;
  
    update remanejamento
       set planejado = v_planejado,
           cadmanual = 'S'
     where idremanejamento in (select idselecionado
                                 from gtt_selecao);
  
    for c in (select idselecionado
                from gtt_selecao)
    loop
      pk_remanejamento.regraRemanejamentoLoteUnico(c.idselecionado);
    end loop;
  
  end;

  /*
  * procedure responsavel por gerar os reabastecimentos automaticos
  */
  procedure reabastecer_automatico
  (
    p_idarmazem     in number,
    p_iddepositante in number,
    p_idproduto     in number,
    p_idlocal       in local.idlocal%type,
    p_idusuario     in number
  ) is
    v_tiporeabastecimento number;
  begin
    select tiporeabastecimento
      into v_tiporeabastecimento
      from configuracao
     where ativo = 'S';
  
    if v_tiporeabastecimento = 0 then
      reabastecerPorLastro(p_idarmazem, p_iddepositante, p_idproduto,
                           p_idlocal, p_idusuario);
    else
      reabastecerPorEmbalagem(p_idarmazem, p_iddepositante, p_idproduto,
                              p_idlocal, p_idusuario);
    end if;
  end;

  /*
   * Carrega as informacoes do remanejamento
  */
  function CarregarRemanejamento(p_idremanejamento in number)
    return remanejamento%rowtype is
    r_remanejamento remanejamento%rowtype;
  begin
    select *
      into r_remanejamento
      from remanejamento
     where idremanejamento = p_idremanejamento;
    return r_remanejamento;
  end;

  procedure validarInclusaoLote
  (
    p_idlote           in lote.idlote%type,
    p_idarmazemorigem  in armazem.idarmazem%type,
    p_idlocalorigem    in local.idlocal%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    v_msg              in out varchar,
    v_erro             in out boolean
  ) is
    v_idremanejamento number;
  begin
    -- Valida se o lote pode ser associado ao remanejamento
    begin
      select re.idremanejamento
        into v_idremanejamento
        from remanejamento re, loteremanejamento lr
       where lr.idremanejamento = re.idremanejamento
         and re.idarmazemdestino = p_idarmazemorigem
         and re.idlocaldestino = p_idlocalorigem
         and re.idarmazemorigem = p_idarmazemdestino
         and re.idlocalorigem = p_idlocaldestino
         and re.status <> 'F'
         and lr.idlote = p_idlote
         and rownum = 1;
    
      v_erro := True;
      v_msg  := v_msg || 'O remanejamento ' || v_idremanejamento ||
                ', contém o mesmo lote e com origem e destino inversos a este remanejamento. ' ||
                'Deve-se processar o remanejamento anterior ou escolher outro lote.';
    exception
      when no_data_found then
        v_idremanejamento := 0;
    end;
  end;

  procedure validarInclusaoLoteMontagem
  (
    p_idlote           in lote.idlote%type,
    p_idarmazemorigem  in armazem.idarmazem%type,
    p_idlocalorigem    in local.idlocal%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    v_msg              in out varchar,
    v_erro             in out boolean
  ) is
    v_tipoLocalOrigem  number;
    v_tipoLocalDestino number;
    v_total            number;
  begin
    -- validando inclusao de lote de montagem
    begin
      select l.tipo
        into v_tipolocalOrigem
        from local l
       where l.idarmazem = p_idarmazemorigem
         and l.idlocal = p_idlocalorigem;
    exception
      when no_data_found then
        v_erro := true;
        v_msg  := v_msg || 'Local de origem não encontrado.';
    end;
    begin
      select l.tipo
        into v_tipolocalDestino
        from local l
       where l.idarmazem = p_idarmazemdestino
         and l.idlocal = p_idlocaldestino;
    exception
      when no_data_found then
        v_erro := true;
        v_msg  := v_msg || 'Local de destino não encontrado.';
    end;
    if (v_tipoLocalOrigem = 0 and v_tipoLocalDestino in (1, 2)) then
      select count(*) total
        into v_total
        from lote
       where idlotemont = p_idlote;
      if v_total <> 0 then
        v_erro := true;
        v_msg  := v_msg ||
                  'Não é permitido incluir lotes avulsos neste tipo de remanejamento ou ' ||
                  'o lote é componente de montagem, utilize a função "Formar Lotes" ou escolha ' ||
                  'o lote agrupador de montagem.';
      else
        v_erro := true;
        v_msg  := v_msg ||
                  'Não é possível Incluir Lotes em Remanejamentos de Picking para Pulmão.';
      end if;
    end if;
  end;

  procedure validarInclusaoCompMontagem
  (
    p_idlote in lote.idlote%type,
    v_msg    in out varchar,
    v_erro   in out boolean
  ) is
  begin
    -- valida se o lote e um componente de uma montagem, se for nao permite incluir o lote 
    -- ao remanejamento
    if not CtrlValManipCompMont(p_idlote) then
      v_erro := True;
      v_msg  := v_msg ||
                'Lote componente de uma montagem não pode ser associado a um remanejamento. Selecione o lote principal da montagem.';
    end if;
  end;

  procedure validarSetor
  (
    p_idlote           in lote.idlote%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    v_msg              in out varchar,
    v_erro             in out boolean
  ) is
    v_msgRaise t_message;
  begin
    -- Validando o Setor
    if CtrlvalidarSetor(p_idlote, p_idarmazemdestino, p_idlocaldestino) =
       false then
      v_msgRaise := t_message('{0} O setor do Lote ou Volume {1}' ||
                              ' não está compatível com o setor do endereço de destino do remanejamento.' ||
                              chr(13));
      v_msgRaise.addParam(v_msg);
      v_msgRaise.addParam(to_char(p_idLote));
      v_msg  := v_msgRaise.formatMessage;
      v_erro := true;
    end if;
  end;

  procedure validarPicking
  (
    p_idlote           in lote.idlote%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    v_msg              in out varchar,
    v_erro             in out boolean
  ) is
    v_picking local.picking%type;
  begin
    -- Validando o picking
    select picking
      into v_picking
      from local
     where idlocal = p_idlocaldestino
       and idarmazem = p_idarmazemdestino;
  
    if v_picking = 'S' then
      if CtrlValidarPicking(p_idlote, p_idarmazemdestino, p_idlocaldestino) =
         false then
        v_msg  := v_msg ||
                  'O endereço de destino do remanejamento não é picking do Lote ou Volume ' ||
                  to_char(p_idLote) || '.' || chr(13);
        v_erro := true;
      end if;
    end if;
  end;

  procedure validarRestricoesFisicas
  (
    p_idlote           in lote.idlote%type,
    p_tipolote         in lote.tipolote%type,
    p_idproduto        in lote.idproduto%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    p_qtdedisponivel   in number,
    v_msg              in out varchar,
    v_erro             in out boolean
  ) is
    v_barra    embalagem.barra%type;
    v_tipoerro number;
  begin
    -- Validando restrições Fisicas
    if p_tipolote = c_lote then
      select barra
        into v_barra
        from lote
       where idlote = p_idlote;
      if CtrlValidarRestriFisicas(p_idproduto, p_qtdeDisponivel,
                                  p_idarmazemDestino, p_idlocalDestino,
                                  v_barra, v_tipoerro) = false then
      
        if v_tipoerro = 0 then
          v_msg  := v_msg ||
                    'O endereço de destino do remanejamento não possui capacidade de peso para alocar o Lote ou Volume ' ||
                    to_char(p_idLote) || '.' || chr(13);
          v_erro := true;
        elsif v_tipoerro = 1 then
          v_msg  := v_msg ||
                    'O endereço de destino do remanejamento não possui capacidade de cubagem para alocar o Lote ou Volume ' ||
                    to_char(p_idLote) || '.' || chr(13);
          v_erro := true;
        elsif v_tipoerro = 2 then
          v_msg  := v_msg ||
                    'O endereço de destino do remanejamento não possui capacidade de paletização para alocar o Lote ou Volume ' ||
                    to_char(p_idLote) || '.' || chr(13);
          v_erro := true;
        end if;
      end if;
    end if;
  end;

  /*
   * Procedure para Vincular os produtos ao remanejamento
  */
  function CtrlVincularMaterial
  (
    p_idlote           in lote.idlote%type,
    p_tipolote         in lote.tipolote%type,
    p_idproduto        in lote.idproduto%type,
    p_idarmazemorigem  in armazem.idarmazem%type,
    p_idlocalorigem    in local.idlocal%type,
    p_idarmazemdestino in armazem.idarmazem%type,
    p_idlocaldestino   in local.idlocal%type,
    p_qtdedisponivel   in number
  ) return varchar is
    v_msg              varchar(2000);
    v_erro             boolean := false;
    v_isDestinoPacking number;
  begin
    v_msg := '';
  
    validarInclusaoLoteMontagem(p_idlote, p_idarmazemorigem,
                                p_idlocalorigem, p_idarmazemdestino,
                                p_idlocaldestino, v_msg, v_erro);
  
    validarInclusaoLote(p_idlote, p_idarmazemorigem, p_idlocalorigem,
                        p_idarmazemdestino, p_idlocaldestino, v_msg, v_erro);
  
    validarInclusaoCompMontagem(p_idlote, v_msg, v_erro);
  
    validarSetor(p_idlote, p_idarmazemdestino, p_idlocaldestino, v_msg,
                 v_erro);
  
    validarPicking(p_idlote, p_idarmazemdestino, p_idlocaldestino, v_msg,
                   v_erro);
  
    select count(1)
      into v_isDestinoPacking
      from local l
     where l.idlocal = p_idlocaldestino
       and l.idarmazem = p_idarmazemdestino
       and exists (select 1
              from packing p
             where p.idendereco = l.id);
  
    if (v_isDestinoPacking = 0) then
      validarRestricoesFisicas(p_idlote, p_tipolote, p_idproduto,
                               p_idarmazemdestino, p_idlocaldestino,
                               p_qtdedisponivel, v_msg, v_erro);
    end if;
  
    if v_erro then
      return v_msg;
    else
      v_msg := '';
      return v_msg;
    end if;
  end;

  /*
   * Retorna a quantidade a ser remanejada
  */
  function CtrlObterQtdeRem
  (
    p_idlocal       in local.idlocal%type,
    p_idLote        in lote.idlote%type,
    p_idProduto     in lote.idproduto%type,
    p_qtdeDispLote  in number,
    p_pedirCodBarra in boolean := false
  ) return number is
    v_fatorConversao embalagem.fatorconversao%type;
    v_qtdeRemanejar  number;
  
  begin
    if p_qtdeDispLote <= 1 then
      return p_qtdeDispLote;
    else
      if p_pedirCodBarra = false then
        select em.fatorconversao
          into v_fatorConversao
          from embalagem em
         where em.idproduto = p_idProduto
           and em.barra =
               pk_produto.RetornarCodBarraMenorFator(p_idproduto);
        v_qtdeRemanejar := p_qtdeDispLote / v_fatorConversao;
        return v_qtdeRemanejar;
      end if;
    end if;
  end;

  /*
   * Função para retornar se um setor é valido para alocação e remanejamento
  */
  function CtrlvalidarSetor
  (
    p_idlote    in lote.idlote%type,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return boolean is
    v_idsetor   number;
    v_qtdesetor number;
  begin
    begin
      select idsetor
        into v_idsetor
        from local lo
       where lo.idarmazem = p_idarmazem
         and lo.idlocal = p_idlocal;
    exception
      when no_data_found then
        return false;
    end;
  
    select distinct count(sp.idsetor)
      into v_qtdesetor
      from lote l, setorproduto sp, setordepositante sd
     where l.idlote = p_idlote
       and sp.idproduto = l.idproduto
       and sd.idsetor = sp.idsetor
       and sd.iddepositante = l.iddepositante
       and sp.idsetor = v_idsetor;
    if v_qtdesetor > 0 then
      return true;
    else
      return false;
    end if;
  end;

  /* 
   * Validação do picking
  */
  function CtrlValidarPicking
  (
    p_idlote    in lote.idlote%type,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type
  ) return boolean is
    v_retorno         boolean;
    v_qtdelocal       number;
    v_pickingdinamico number;
  
    v_picking char(1);
  begin
    v_retorno := false;
  
    begin
      select sum(nvl(pl.qtdepk, 0)), nvl(pd.pickingdinamico, 0)
        into v_qtdelocal, v_pickingdinamico
        from lote l, produtodepositante pd,
             (select pk.identidade, pk.idproduto, pk.idarmazem, pk.idlocal,
                      count(1) qtdepk
                 from produtolocal pk, local lo
                where lo.idarmazem = pk.idarmazem
                  and lo.idlocal = pk.idlocal
                  and pk.idarmazem = p_idarmazem
                  and pk.idlocal = p_idlocal
                  and lo.ativo = 'S'
                group by pk.identidade, pk.idproduto, pk.idarmazem, pk.idlocal) pl
       where l.idlote = p_idlote
         and pd.identidade(+) = l.iddepositante
         and pd.idproduto(+) = l.idproduto
         and pl.identidade(+) = l.iddepositante
         and pl.idproduto(+) = l.idproduto
       group by pd.pickingdinamico;
    exception
      when no_data_found then
        v_qtdelocal       := 0;
        v_pickingdinamico := 0;
    end;
    if (v_qtdelocal > 0)
       or (v_pickingdinamico = 1) then
      v_retorno := true;
    else
      v_retorno := false;
    end if;
    return v_retorno;
  end;

  /*
   * Validar as restrições físicas do destino
   
   p_tipoerro retorna 0= Restrições de Peso / 1= Restrições de Cubagem / 2= Restrições de Paletização
   
  */
  function CtrlValidarRestriFisicas
  (
    p_idproduto in produto.idproduto%type,
    p_qtde      in number,
    p_idarmazem in armazem.idarmazem%type,
    p_idlocal   in local.idlocal%type,
    p_barra     in embalagem.barra%type,
    p_tipoerro  in out number
  ) return boolean is
  
    cursor c_embalagem
    (
      p_produto in produto.idproduto%type,
      pi_barra  in embalagem.barra%type
    ) is
      select em.idproduto, em.barra, em.pesobruto,
             (em.altura * em.largura * em.comprimento) cubagem,
             em.fatorconversao,
             (1 / (em.lastro * nvl(em.empilhamentomax, em.qtdecamada))) qtdeplt
        from embalagem em
       where em.idproduto = p_produto
         and barra = pi_barra;
  
    cursor c_dimensoes
    (
      p_armazem in armazem.idarmazem%type,
      p_local   in local.idlocal%type
    ) is
      select l.idarmazem, l.idlocal,
             l.cubagem_end - nvl(oc.cubagem_est, 0) cubagemDisponivel,
             l.peso_end - nvl(oc.peso_est, 0) pesoDisponivel,
             (1 - nvl(oc.qtdeplt_est, 0)) qtdepltdisponivel, l.tipo
        from (select l.idarmazem, l.idlocal,
                      (l.altura - l.alturamanobra) * l.largura *
                       l.comprimento cubagem_end, l.pesomaximo peso_end,
                      l.tipo
                 from local l
                where l.idarmazem = p_armazem
                  and l.idlocal = p_local) l,
             (select idarmazem, idlocal, round(sum(cubagem_est)) cubagem_est,
                      round(sum(peso_est)) peso_est,
                      sum(qtdeplt_est) qtdeplt_est
                 from (select ll.idarmazem, idlocal,
                               (e.altura * e.largura * e.comprimento) *
                                ((ll.estoque + ll.adicionar) / e.fatorconversao) cubagem_est,
                               e.pesobruto *
                                ((ll.estoque + ll.adicionar) / e.fatorconversao) peso_est,
                               ((ll.estoque + ll.adicionar) /
                                (e.lastro *
                                nvl(e.empilhamentomax, e.qtdecamada) *
                                e.fatorconversao)) qtdeplt_est
                          from lotelocal ll, lote l, embalagem e
                         where ll.idarmazem = p_armazem
                           and ll.idlocal = p_local
                           and (ll.estoque - ll.pendencia + ll.adicionar) > 0
                           and l.idlote = ll.idlote
                           and l.tipolote = 'L'
                           and e.idproduto = l.idproduto
                           and e.barra = l.barra
                        union all
                        select m.idarmazem, idlocal,
                               (e.altura * e.largura * e.comprimento) *
                                l.qtdeentrada cubagem_est,
                               e.pesobruto * l.qtdeentrada,
                               ((m.qtde * e.fatorconversao) /
                                (e.lastro *
                                nvl(e.empilhamentomax, e.qtdecamada) *
                                e.fatorconversao)) qtdeplt_est
                          from mapaalocacao m, lote l, embalagem e
                         where m.idarmazem = p_armazem
                           and m.idlocal = p_local
                           and m.status in ('P', 'A', 'M')
                           and l.tipolote = 'L'
                           and l.idlote = m.idlote
                           and e.idproduto = l.idproduto
                           and e.barra = l.barra) est
                group by idarmazem, idlocal) oc
       where oc.idarmazem(+) = l.idarmazem
         and oc.idlocal(+) = l.idlocal;
  
    r_dimensoes         c_dimensoes%rowtype;
    r_embalagem         c_embalagem%rowtype;
    r_dimensoesFisicas  t_dimensoesFisicas;
    v_pesoproduto       number;
    v_cubagemproduto    number;
    v_qtdepltproduto    number;
    v_pesodisponivel    number;
    v_cubagemdisponivel number;
    v_qtdepltdisponivel number;
    v_multiendereco     produto.multiendereco%type;
  begin
    if c_embalagem%isopen then
      close c_embalagem;
    end if;
    open c_embalagem(p_idproduto, p_barra);
    fetch c_embalagem
      into r_embalagem;
    close c_embalagem;
  
    v_pesoproduto              := r_embalagem.pesobruto *
                                  (p_qtde / r_embalagem.fatorconversao);
    v_cubagemproduto           := r_embalagem.cubagem *
                                  (p_qtde / r_embalagem.fatorconversao);
    v_qtdepltproduto           := r_embalagem.qtdeplt *
                                  (p_qtde / r_embalagem.fatorconversao);
    r_dimensoesFisicas.peso    := v_pesoproduto;
    r_dimensoesFisicas.cubagem := v_cubagemproduto;
    r_dimensoesFisicas.qtdeplt := v_qtdepltproduto;
  
    -- Aqui é avaliado a gtt para saber se a validação esta acumulando dados anteriores
    for c_produto in (select g.idproduto, g.barra, g.qtde
                        from gtt_produtoremanejamento g)
    loop
      if c_embalagem%isopen then
        close c_embalagem;
      end if;
      open c_embalagem(c_produto.idproduto, c_produto.barra);
      fetch c_embalagem
        into r_embalagem;
      close c_embalagem;
    
      v_pesoproduto              := r_embalagem.pesobruto *
                                    (c_produto.qtde /
                                    r_embalagem.fatorconversao);
      v_cubagemproduto           := r_embalagem.cubagem *
                                    (c_produto.qtde /
                                    r_embalagem.fatorconversao);
      v_qtdepltproduto           := r_embalagem.qtdeplt *
                                    (c_produto.qtde /
                                    r_embalagem.fatorconversao);
      r_dimensoesFisicas.peso    := r_dimensoesFisicas.peso + v_pesoproduto;
      r_dimensoesFisicas.cubagem := r_dimensoesFisicas.cubagem +
                                    v_cubagemproduto;
      r_dimensoesFisicas.qtdeplt := r_dimensoesFisicas.qtdeplt +
                                    v_qtdepltproduto;
    end loop;
  
    -- Checando a disponibilidade física
    if c_dimensoes%isopen then
      close c_dimensoes;
    end if;
    open c_dimensoes(p_idarmazem, p_idlocal);
    fetch c_dimensoes
      into r_dimensoes;
    close c_dimensoes;
  
    v_pesodisponivel    := r_dimensoes.pesodisponivel;
    v_cubagemdisponivel := r_dimensoes.cubagemdisponivel;
    v_qtdepltdisponivel := r_dimensoes.qtdepltdisponivel;
  
    if v_pesodisponivel < 0 then
      v_pesodisponivel := 0;
    end if;
    if v_cubagemdisponivel < 0 then
      v_cubagemdisponivel := 0;
    end if;
    if v_qtdepltdisponivel < 0 then
      v_qtdepltdisponivel := 0;
    end if;
  
    r_dimensoesFisicas.peso    := r_dimensoesFisicas.peso -
                                  v_pesodisponivel;
    r_dimensoesFisicas.cubagem := r_dimensoesFisicas.cubagem -
                                  v_cubagemdisponivel;
    r_dimensoesFisicas.qtdeplt := trunc(r_dimensoesFisicas.qtdeplt -
                                        v_qtdepltdisponivel, 6);
  
    -- Checando se o produto é multiendereco
    select pr.multiendereco
      into v_multiendereco
      from produto pr
     where pr.idproduto = p_idproduto;
  
    -- Validando Multiendereco
    if ((r_dimensoesFisicas.peso > 0 or r_dimensoesFisicas.cubagem > 0) and
       v_multiendereco = 'S') then
      r_dimensoesFisicas := validarMultiendereco(r_dimensoesFisicas,
                                                 v_multiEndereco, p_idarmazem,
                                                 p_idlocal);
    end if;
  
    --  p_tipoerro retorna 0= Restrições de Peso / 1= Restrições de Cubagem / 2= Restrições de Paletização
    if (r_dimensoesFisicas.peso > 0) then
      p_tipoerro := 0;
      return false;
    elsif (r_dimensoesFisicas.cubagem > 0) then
      p_tipoerro := 1;
      return false;
    elsif (r_dimensoesFisicas.qtdeplt > 0 and r_dimensoes.tipo = 2) then
      p_tipoerro := 2;
      return false;
    else
      return true;
    end if;
  end;

  /*
   * Validação de multiendereco
  */
  function validarMultiendereco
  (
    p_dimensoes     in t_dimensoesFisicas,
    p_multiendereco in produto.multiendereco%type,
    p_idarmazem     in armazem.idarmazem%type,
    p_idlocal       in local.idlocal%type
  ) return t_dimensoesFisicas is
  
    cursor c_listaVizinhos
    (
      p_armazem in armazem.idarmazem%type,
      p_local   in local.idlocal%type
    ) is
      select l.idarmazem, l.idlocal, l.rua, l.predio, l.andar, l.apartamento,
             l.numeroordem, l.pesomaximo, l.volumemaximo, l.altura,
             l.largura, l.comprimento, l.temperaturamin, l.temperaturamax,
             l.shelflife, l.classificacaoabc, l.estanteria, l.picking,
             l.ativo, l.qtdemax, s.descr setor, l.idSetor, l.modulo,
             l.alturamanobra,
             nvl(l.modulo, nvl(a.modulopadrao, 2)) modulopadrao,
             oc.cubagemDisponivel, oc.pesoDisponivel
        from (select l.idarmazem, l.idlocal, l.rua, l.predio, l.andar,
                      l.apartamento,
                      nvl(nvl(l.modulo, a.modulopadrao), 2) modulo,
                      mod(l.predio, 2) MOD
                 from armazem a, local l
                where a.idarmazem = p_armazem
                  and l.idarmazem = a.idarmazem
                  and l.idlocal = p_local) lo, armazem a, local l, setor s,
             (select l.idarmazem, l.idlocal,
                      l.cubagem_end - nvl(oc.cubagem_est, 0) cubagemDisponivel,
                      l.peso_end - nvl(oc.peso_est, 0) pesoDisponivel
                 from (select l.idarmazem, l.idlocal,
                               (l.altura - l.alturamanobra) * l.largura *
                                l.comprimento cubagem_end, l.pesomaximo peso_end
                          from local l) l,
                      (select idarmazem, idlocal,
                               round(sum(cubagem_est)) cubagem_est,
                               round(sum(peso_est)) peso_est
                          from (select ll.idarmazem, idlocal,
                                        (e.altura * e.largura * e.comprimento) *
                                         ((ll.estoque + ll.adicionar) /
                                         e.fatorconversao) cubagem_est,
                                        e.pesobruto * ((ll.estoque + ll.adicionar) /
                                         e.fatorconversao) peso_est
                                   from lotelocal ll, lote l, embalagem e
                                  where (ll.estoque - ll.pendencia + ll.adicionar) > 0
                                    and l.idlote = ll.idlote
                                    and l.tipolote = 'L'
                                    and e.idproduto = l.idproduto
                                    and e.barra = l.barra
                                 union all
                                 select m.idarmazem, idlocal,
                                        (e.altura * e.largura * e.comprimento) *
                                         l.qtdeentrada cubagem_est,
                                        e.pesobruto * l.qtdeentrada
                                   from mapaalocacao m, lote l, embalagem e
                                  where m.status in ('P', 'A', 'M')
                                    and l.idlote = m.idlote
                                    and l.tipolote = 'L'
                                    and e.idproduto = l.idproduto
                                    and e.barra = l.barra) est
                         group by idarmazem, idlocal) oc
                where oc.idarmazem(+) = l.idarmazem
                  and oc.idlocal(+) = l.idlocal) oc
       where a.idarmazem = lo.idarmazem
         and l.idarmazem = lo.idarmazem
         and l.rua = lo.rua
         and l.andar = lo.andar
         and l.apartamento = lo.apartamento
         and l.predio between lo.predio - (lo.modulo - 1) * 2 and
             lo.predio + (lo.modulo - 1) * 2
         and nvl(nvl(l.modulo, a.modulopadrao), 2) = lo.modulo
         and mod(l.predio, 2) = lo.mod
         and s.idsetor(+) = l.idsetor
         and oc.idarmazem(+) = l.idarmazem
         and oc.idlocal(+) = l.idlocal;
  
    r_listaVizinhos c_listaVizinhos%rowtype;
    type t_listaIrmaos is table of local%rowtype;
    type t_listaVizinhos is table of c_listaVizinhos%rowtype;
    v_listaVizinhos   t_listaVizinhos := t_listaVizinhos();
    v_listaIrmaos     t_listaIrmaos := t_listaIrmaos();
    v_retorno         t_dimensoesFisicas;
    v_indice          number;
    v_anterior        number;
    v_posterior       number;
    v_sair            boolean;
    i                 number;
    d                 number;
    v_qtdeVizinhos    number;
    v_localAnterior   local.idlocal%type;
    v_localPosterior  local.idlocal%type;
    v_localAtual      local.idlocal%type;
    v_inicioModulo    boolean;
    v_predioAtual     local.predio%type;
    v_predioAnterior  local.predio%type;
    v_predioPosterior local.predio%type;
    v_predioValido    boolean;
    v_peso            number;
    v_cubagem         number;
  
  begin
    v_peso         := p_dimensoes.peso;
    v_cubagem      := p_dimensoes.cubagem;
    v_qtdeVizinhos := 1;
    if c_listaVizinhos%isopen then
      close c_listaVizinhos;
    end if;
    open c_listaVizinhos(p_idarmazem, p_idlocal);
    fetch c_listaVizinhos
      into r_listaVizinhos;
    while c_listaVizinhos%found
    loop
      v_listaVizinhos.Extend;
      v_listaVizinhos(v_qtdeVizinhos).idarmazem := r_listaVizinhos.idarmazem;
      v_listaVizinhos(v_qtdeVizinhos).idlocal := r_listaVizinhos.idlocal;
      v_listaVizinhos(v_qtdeVizinhos).rua := r_listaVizinhos.rua;
      v_listaVizinhos(v_qtdeVizinhos).predio := r_listaVizinhos.predio;
      v_listaVizinhos(v_qtdeVizinhos).andar := r_listaVizinhos.andar;
      v_listaVizinhos(v_qtdeVizinhos).apartamento := r_listaVizinhos.apartamento;
      v_listaVizinhos(v_qtdeVizinhos).numeroordem := r_listaVizinhos.numeroordem;
      v_listaVizinhos(v_qtdeVizinhos).pesomaximo := r_listaVizinhos.pesomaximo;
      v_listaVizinhos(v_qtdeVizinhos).volumemaximo := r_listaVizinhos.volumemaximo;
      v_listaVizinhos(v_qtdeVizinhos).altura := r_listaVizinhos.altura;
      v_listaVizinhos(v_qtdeVizinhos).largura := r_listaVizinhos.largura;
      v_listaVizinhos(v_qtdeVizinhos).comprimento := r_listaVizinhos.comprimento;
      v_listaVizinhos(v_qtdeVizinhos).temperaturamin := r_listaVizinhos.temperaturamin;
      v_listaVizinhos(v_qtdeVizinhos).temperaturamax := r_listaVizinhos.temperaturamax;
      v_listaVizinhos(v_qtdeVizinhos).shelflife := r_listaVizinhos.shelflife;
      v_listaVizinhos(v_qtdeVizinhos).classificacaoabc := r_listaVizinhos.classificacaoabc;
      v_listaVizinhos(v_qtdeVizinhos).estanteria := r_listaVizinhos.estanteria;
      v_listaVizinhos(v_qtdeVizinhos).picking := r_listaVizinhos.picking;
      v_listaVizinhos(v_qtdeVizinhos).ativo := r_listaVizinhos.ativo;
      v_listaVizinhos(v_qtdeVizinhos).qtdemax := r_listaVizinhos.qtdemax;
      v_listaVizinhos(v_qtdeVizinhos).setor := r_listaVizinhos.setor;
      v_listaVizinhos(v_qtdeVizinhos).idSetor := r_listaVizinhos.idSetor;
      v_listaVizinhos(v_qtdeVizinhos).modulo := r_listaVizinhos.modulo;
      v_listaVizinhos(v_qtdeVizinhos).alturamanobra := r_listaVizinhos.alturamanobra;
      v_listaVizinhos(v_qtdeVizinhos).modulopadrao := r_listaVizinhos.modulopadrao;
      v_qtdeVizinhos := v_qtdeVizinhos + 1;
    
      fetch c_listaVizinhos
        into r_listaVizinhos;
    end loop;
    close c_listaVizinhos;
  
    v_qtdeVizinhos := v_listaVizinhos.Count;
    i              := 1;
    v_indice       := -1;
    while (v_indice < 0)
          and (i < v_qtdeVizinhos)
    loop
      if v_listaVizinhos(i).idlocal = p_idlocal then
        v_indice := i;
      end if;
      i := i + 1;
    end loop;
  
    i := v_indice + 1;
    if ((v_peso > 0) or (v_cubagem > 0))
       and (i < v_qtdeVizinhos) then
      v_anterior := v_indice;
      v_sair     := false;
      d          := 0;
    
      while v_sair = false
      loop
        v_localAnterior  := v_listaVizinhos(v_anterior).idlocal;
        v_localAtual     := v_listaVizinhos(i).idlocal;
        v_inicioModulo   := pk_alocacao.retornaEnderecoModulo(v_listaVizinhos(i)
                                                              .idarmazem,
                                                              v_listaVizinhos(i)
                                                               .idlocal,
                                                              v_listaVizinhos(i)
                                                               .predio,
                                                              v_listaVizinhos(i)
                                                               .modulo);
        v_predioAtual    := v_listaVizinhos(i).predio;
        v_predioAnterior := v_listaVizinhos(v_anterior).predio;
        if v_predioAtual = (v_predioAnterior + 2) then
          v_predioValido := true;
        else
          v_predioValido := false;
        end if;
      
        if (v_inicioModulo = true)
           or (v_predioValido = false) then
          v_sair := true;
        end if;
      
        if v_sair = false then
          v_peso    := v_peso - v_listaVizinhos(i).pesomaximo;
          v_cubagem := v_cubagem - (v_listaVizinhos(i)
                       .altura * v_listaVizinhos(i).largura * v_listaVizinhos(i)
                       .comprimento);
          v_listaIrmaos.Extend;
          v_listaIrmaos(d).idlocal := v_listaVizinhos(i).idlocal;
          v_listaIrmaos(d).idarmazempai := v_listaVizinhos(i).idarmazem;
          d := d + 1;
          v_anterior := i;
        end if;
        if ((v_peso <= 0) and (v_cubagem <= 0) or (v_sair = true)) then
          i := i + 1;
          if (i >= v_qtdeVizinhos)
             or (v_sair = true) then
            v_sair := true;
          end if;
        end if;
      end loop;
    end if;
  
    i := i - 1;
    if ((v_peso > 0) or (v_cubagem > 0) and (i >= 0)) then
      v_posterior := v_indice;
      v_sair      := false;
    
      while v_sair = false
      loop
        v_localPosterior  := v_listaVizinhos(v_posterior).idLocal;
        v_localAtual      := v_listaVizinhos(i).idlocal;
        v_inicioModulo    := pk_alocacao.retornaEnderecoModulo(v_listaVizinhos(i)
                                                               .idarmazem,
                                                               v_listaVizinhos(i)
                                                                .idlocal,
                                                               v_listaVizinhos(i)
                                                                .predio,
                                                               v_listaVizinhos(i)
                                                                .modulo);
        v_predioAtual     := v_listaVizinhos(i).predio;
        v_predioPosterior := v_listaVizinhos(v_posterior).predio;
        if v_predioAtual = (v_predioPosterior - 2) then
          v_predioValido := true;
        else
          v_predioValido := false;
        end if;
      
        if v_predioValido = false then
          v_sair := true;
        end if;
      
        if v_sair = false then
          v_peso    := v_peso - v_listaVizinhos(i).pesoMaximo;
          v_cubagem := v_cubagem - (v_listaVizinhos(i)
                       .altura * v_listaVizinhos(i).largura * v_listaVizinhos(i)
                       .comprimento);
          v_listaIrmaos.Extend;
          v_listaIrmaos(d).idlocal := v_listaVizinhos(i).idlocal;
          v_listaIrmaos(d).idarmazempai := v_listaVizinhos(i).idarmazem;
          d := d + 1;
          v_posterior := i;
        end if;
      
        if (v_inicioModulo = true)
           and (v_sair = true) then
          v_sair := true;
        end if;
      
        if ((v_peso <= 0) and (v_cubagem <= 0) and v_sair) then
          v_sair := true;
        end if;
        i := i - 1;
        if (i < 0)
           or (v_sair = true) then
          v_sair := true;
        end if;
      end loop;
    end if;
  
    if (v_peso <= 0)
       and (v_cubagem <= 0) then
      for i in 0 .. v_listaIrmaos.count
      loop
        update local
           set idarmazempai = v_listaIrmaos(i).idarmazempai,
               idlocalpai   = v_listaIrmaos(i).idlocalPai
         where idarmazem = p_idArmazem
           and idLocal = p_idlocal;
      end loop;
      v_peso    := 0;
      v_cubagem := 0;
    end if;
    v_retorno.peso    := v_peso;
    v_retorno.cubagem := v_cubagem;
    return v_retorno;
  end;

  /*
   * Limpa os endereços filhos de alocação multiendereço
  */
  procedure RemoveInfMultiEndereco(p_idremanejamento in remanejamento.idremanejamento%type) is
    cursor c_remanejamento(p_idremanejamento in remanejamento.idremanejamento%type) is
      select re.idarmazemorigem, re.idlocalorigem
        from remanejamento re
       where re.idremanejamento = p_idremanejamento;
  
    r_remanejamento c_remanejamento%rowtype;
  begin
    if c_remanejamento%isopen then
      close c_remanejamento;
    end if;
    open c_remanejamento(p_idremanejamento);
    fetch c_remanejamento
      into r_remanejamento;
    close c_remanejamento;
  
    for c_local in (select l.idarmazem, l.idlocal
                      from local l, setor s, armazem a
                     where (l.idarmazempai, l.idlocalpai) =
                           (select r.idarmazemorigem, r.idlocalorigem
                              from remanejamento r
                             where r.idremanejamento = p_idremanejamento
                               and (r.idarmazemorigem, r.idlocalorigem) not in
                                   (select ll.idarmazem, ll.idlocal
                                      from lotelocal ll, lote l, produto p
                                     where ll.idarmazem = r.idarmazemorigem
                                       and ll.idlocal = r.idlocalorigem
                                       and l.idlote = ll.idlote
                                       and p.idproduto = l.idproduto
                                       and p.multiendereco = c_multiendereco
                                       and l.tipolote = c_lote
                                       and ll.estoque - ll.pendencia +
                                           ll.adicionar > 0))
                       and s.idsetor(+) = l.idsetor
                       and a.idarmazem = l.idarmazem)
    loop
      update local
         set idarmazempai = null,
             idlocalpai   = null
       where idarmazem = r_remanejamento.idarmazemorigem
         and idlocal = r_remanejamento.idlocalorigem;
    end loop;
  end;

  /*
   * Valida se o lote e componente de montagem
  */
  function CtrlValManipCompMont(p_idlote in lote.idlote%type) return boolean is
    v_Resultado number;
  begin
    select decode(idlotemont, null, 0, 1)
      into v_resultado
      from lote
     where idlote = p_idlote;
  
    Return v_Resultado = 0;
  end;

  /*
   * Inclui no remanejamento os lotes componentes da montagem
  */
  procedure Associar
  (
    p_idRemanejamento in remanejamento.idremanejamento%type,
    p_idlote          in lote.idlote%type
  ) is
  
  begin
    insert into loteremanejamento
      (idRemanejamento, idLote, qtde, conferido, controlaQtde)
      select p_idRemanejamento, l.idlote, l.qtdeentrada, 'S', 'N'
        from lote l
       where l.idlotemont = p_idlote;
  end;

  /*
   * Excluir do remanejamento os lotes componentes da montagem
  */
  procedure Desassociar
  (
    p_idRemanejamento in remanejamento.idremanejamento%type,
    p_idlote          in lote.idlote%type
  ) is
    v_msg t_message;
  begin
    if not CtrlValManipCompMont(p_idlote) then
      v_msg := t_message('Lote componente de uma montagem não pode ser desassociado de um remanejamento. Selecione o lote principal da montagem.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_comps in (select idlote
                      from lote
                     where idlotemont = p_idlote)
    loop
      delete from loteremanejamento
       where idlote = c_comps.idlote
         and idremanejamento = p_idRemanejamento;
    end loop;
  end;

  procedure validarFormarLoteUnico
  (
    p_idlote          number,
    p_idremanejamento number,
    p_idlocaldestino  local.idlocal%type
  ) is
    r_loteunicocomparar pk_lote.t_loteunico;
    v_idarmazem         number;
    v_msgerro           varchar2(5000);
    v_msg               t_message;
  begin
  
    select lt.idarmazem
      into v_idarmazem
      from lote lt
     where lt.idlote = p_idlote;
  
    select lt.idproduto, lt.estado, lt.descr, lt.dtvenc,
           pd.loteuniconoendereco, lt.iddepositante,
           pd.vencimentouniconoendereco
      into r_loteunicocomparar
      from lote lt, produtodepositante pd
     where lt.idlote = p_idlote
       and pd.idproduto = lt.idproduto
       and pd.identidade = lt.iddepositante;
  
    for r_loteunico in (select distinct lt.idproduto, lt.estado,
                                        lt.descr loteindustria,
                                        lt.dtvenc dtvencimento,
                                        pd.loteuniconoendereco,
                                        lt.iddepositante,
                                        pd.vencimentouniconoendereco
                          from loteremanejamento lr, lote lt,
                               produtodepositante pd
                         where lr.idremanejamento = p_idremanejamento
                           and lr.idlote = lt.idlote
                           and lt.idlote = lr.idlote
                           and pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante)
    loop
    
      for r_loteunicoComp in (select distinct lt.idproduto, lt.estado,
                                              lt.descr loteindustria,
                                              lt.dtvenc dtvencimento,
                                              pd.loteuniconoendereco,
                                              lt.iddepositante,
                                              pd.vencimentouniconoendereco
                                from loteremanejamento lr, lote lt,
                                     produtodepositante pd
                               where lr.idremanejamento = p_idremanejamento
                                 and lr.idlote = lt.idlote
                                 and lt.idlote = lr.idlote
                                 and pd.idproduto = lt.idproduto
                                 and pd.identidade = lt.iddepositante
                                 and (lt.idproduto <> r_loteunico.idproduto or
                                     lt.estado <> r_loteunico.estado or
                                     lt.descr <> r_loteunico.loteindustria or
                                     lt.dtvenc <> r_loteunico.dtvencimento or
                                     pd.loteuniconoendereco <>
                                     r_loteunico.loteuniconoendereco))
      loop
        if not pk_lote.isLoteUnicoCompativel(r_loteunico, r_loteunicoComp,
                                             v_msgerro, v_idarmazem,
                                             p_idlocaldestino) then
          raise_application_error(-20000, v_msgerro);
        end if;
      end loop;
    end loop;
  
    if (not
        pk_lote.isLocalPodeReceberLoteUnico(r_loteunicocomparar, v_idarmazem,
                                             p_idlocaldestino, v_msgerro)) then
      raise_application_error(-20000, v_msgerro);
    end if;
  
  end;

  /*
  * Valida possibilidade  de geracao de lotes no remanejamento de picking para pulmao
  */
  function ValidarGeracaoLotes
  (
    p_idarmazem     in number,
    p_idlocal       local.idlocal%type,
    p_idproduto     in number,
    p_iddepositante in number,
    p_estado        lote.estado%type,
    p_fator         in number,
    p_qtde          in number,
    p_itemadicional in lote.itemadicional%type,
    p_mensagem      out varchar2,
    p_idlote        in number
  ) return boolean is
  
    v_qtdedisp number;
    v_msg      t_message;
  begin
    if p_qtde <= 0 then
      v_msg      := t_message('Quantidade de lotes a ser gerado não pode ser zero.');
      p_mensagem := v_msg.formatMessage;
    else
      select sum(ll.estoque - ll.pendencia + ll.adicionar) disp
        into v_qtdedisp
        from lotelocal ll, lote l
       where l.idproduto = p_idproduto
         and l.estado = p_estado
         and l.idlote = ll.idlote
         and ll.idarmazem = p_idarmazem
         and ll.idlocal = p_idlocal
         and l.liberado = 'S'
         and l.itemadicional = p_itemadicional
         and decode(p_idlote, 0, 0, ll.idlote) = p_idlote
         and ((ll.estoque > 0) or (ll.adicionar > 0) or (ll.pendencia > 0) or
             (ll.reservado > 0));
    
      if nvl(v_qtdedisp, 0) < (p_qtde * p_fator) then
        v_msg      := t_message('Quantidade disponível no endereço não atende a quantidade a ser remanejada.');
        p_mensagem := v_msg.formatMessage;
      end if;
    
    end if;
  
    if length(p_mensagem) > 0 then
      return false;
    else
      return true;
    end if;
  end;

  procedure InserirLoteRemanejamento
  (
    p_idremanejamento in number,
    p_idarmazem       in number,
    p_idlocal         local.idlocal%type,
    p_idusuario       in number,
    p_idlote          in number,
    p_qtde            in number
  ) is
    v_complementar lotelocal.complementar%type;
  begin
    insert into loteremanejamento
      (idremanejamento, idlote, qtde, conferido, controlaqtde, diferenca)
    values
      (p_idremanejamento, p_idlote, p_qtde, c_nao, c_sim, 0);
  
    -- Inserir adicionar e pendenica no lotes novos.
    v_complementar := 'AUMENTADO ADICIONAR EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                      p_idremanejamento;
    pk_estoque.incluir_adicionar(p_idarmazem, p_idlocal, p_idlote, p_qtde,
                                 p_idusuario, v_complementar);
  
    v_complementar := 'AUMENTADO PENDENCIA EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                      p_idremanejamento;
    pk_estoque.incluir_pendencia(p_idarmazem, p_idlocal, p_idlote, p_qtde,
                                 p_idusuario, v_complementar);
  end;

  procedure InserirComposicaoLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_qtde            in number,
    p_qtdecoberta     in number
  ) is
    cursor c_lotes(p_idremanejamento number) is
      select idremanejamento, idlote, qtde, disp
        from (select lr.idremanejamento, lr.idlote, lr.qtde,
                      lr.qtde -
                       nvl((select sum(cl.qtde) qtde
                             from composicaolote cl
                            where cl.idlotenovo = lr.idlote), 0) disp
                 from loteremanejamento lr
                where lr.idremanejamento = p_idremanejamento)
       where disp > 0
       order by idlote;
  
    C_REMANJ_PK_PL constant number := 3;
  
    r_lotes       c_lotes%rowtype;
    v_qtde        number;
    v_baixado     number;
    v_qtdecoberta number;
    v_cobertura   number;
  begin
    if (c_lotes%isopen) then
      close c_lotes;
    end if;
  
    open c_lotes(p_idremanejamento);
    fetch c_lotes
      into r_lotes;
  
    v_baixado   := p_qtde;
    v_cobertura := p_qtdecoberta;
  
    while (v_baixado > 0)
    loop
      if (r_lotes.disp >= v_baixado) then
        v_qtde := v_baixado;
      else
        v_qtde := r_lotes.disp;
      end if;
    
      v_baixado := v_baixado - v_qtde;
    
      if (v_qtde >= v_cobertura) then
        v_qtdecoberta := v_cobertura;
        v_cobertura   := 0;
      else
        v_qtdecoberta := v_qtde;
        v_cobertura   := v_cobertura - v_qtde;
      end if;
    
      -- insere o composicao do lote para rastreabilidade de cobertura
      pk_lote.inserirComposicaoLote(r_lotes.idlote, p_idlote, v_qtde,
                                    v_qtdecoberta, C_REMANJ_PK_PL,
                                    p_idremanejamento);
    
      pk_lote.inserirComposicaoLoteKit(p_idlote, r_lotes.idlote, v_qtde);
    
      pk_lote.inserirBarraOriginal(r_lotes.idlote);
      -- adiciona quantidade disponivel para o lote formado no inventario
      update lote
         set qtdedisponivel = nvl(qtdedisponivel, 0) + v_qtdecoberta
       where idlote = r_lotes.idlote;
    
      -- retira quantidade disponivel do lote baixado no remanejamento
      update lote
         set qtdedisponivel = nvl(qtdedisponivel, 0) - v_qtdecoberta
       where idlote = p_idlote;
    
      fetch c_lotes
        into r_lotes;
    end loop;
  end;

  procedure GerarDocumentos
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_iddepositante   in number,
    p_mensagem        out varchar2
  ) is
    r_notafiscal     notafiscal%rowtype;
    r_nfdet          nfdet%rowtype;
    v_idproprietario number;
    v_idnfsaida      number;
    v_idnfentrada    number;
    v_msg            t_message;
  begin
    begin
      select c.idproprietario
        into v_idproprietario
        from configuracao c
       where c.ativo = 'S';
    exception
      when no_data_found then
        v_msg      := t_message('Proprietario não foi localizado.');
        p_mensagem := v_msg.formatMessage;
    end;
    if p_mensagem is null then
      -- insere o cabecalho da NF de saida
      r_notafiscal.codigointerno      := p_idremanejamento;
      r_notafiscal.sequencia          := 'AVARIA';
      r_notafiscal.usuario            := p_idusuario;
      r_notafiscal.remetente          := v_idproprietario;
      r_notafiscal.destinatario       := v_idproprietario;
      r_notafiscal.dataemissao        := sysdate;
      r_notafiscal.datacadastro       := sysdate;
      r_notafiscal.statusnf           := 'P';
      r_notafiscal.estoqueverificado  := 'S';
      r_notafiscal.statusroteirizacao := 2;
      r_notafiscal.digitada           := 'N';
      r_notafiscal.impresso           := 'N';
      r_notafiscal.ident_entrega      := v_idproprietario;
      r_notafiscal.movestoque         := 'S';
      r_notafiscal.iddepositante      := p_iddepositante;
      --r_notafiscal.operacao          := r_nf.idoperacao; --????????????????? Ver com Leandro
    
      --Inserir NF de Saida
      r_notafiscal.tipo   := 'S';
      r_notafiscal.estado := 'N';
      v_idnfsaida         := pk_notafiscal.insere_cabecalho_nf(r_notafiscal);
    
      --Inserir NF de Entrada
      r_notafiscal.tipo   := 'E';
      r_notafiscal.estado := 'T';
      v_idnfentrada       := pk_notafiscal.insere_cabecalho_nf(r_notafiscal);
    
      for c_itens in (select l.idproduto, l.barra,
                             sum(lr.qtde / e.fatorconversao) qtde
                        from loteremanejamento lr, lote l, embalagem e
                       where e.barra = l.barra
                         and e.idproduto = l.idproduto
                         and l.idlote = lr.idlote
                         and lr.idremanejamento = p_idremanejamento
                       group by l.idproduto, l.barra)
      loop
        r_nfdet.idnfdet   := null;
        r_nfdet.nf        := v_idnfsaida;
        r_nfdet.idproduto := c_itens.idproduto;
        r_nfdet.barra     := c_itens.barra;
        r_nfdet.qtde      := c_itens.qtde;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      
        r_nfdet.idnfdet := null;
        r_nfdet.nf      := v_idnfentrada;
        pk_notafiscal.insere_detalhe_nf(r_nfdet);
      end loop;
      pk_notafiscal.p_gerar_nfimpressao(v_idnfsaida, 'N');
      pk_notafiscal.p_gerar_nfimpressao(v_idnfentrada, 'N');
    
    end if;
  end;

  /*
   * Rotina que pesa os lotes do remanejamento
  */
  procedure PesarLotes
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_peso            in number,
    p_mensagem        out varchar2
  ) is
  
    cursor c_pesocalc
    (
      p_idremanejamento in number,
      p_idlote          in number
    ) is
      select (e.pesobruto * lr.qtde) + nvl(tc.peso, 0) peso
        from loteremanejamento lr, lote l, embalagem e, tipocaixavolume tc
       where e.barra =
             pk_produto.retornar_codbarra_nao_precad(l.idproduto, 1)
         and e.idproduto = l.idproduto
         and l.idlote = lr.idlote
         and tc.idtipocaixavolume(+) = l.idtipocaixa
         and lr.idlote = p_idlote
         and lr.idremanejamento = p_idremanejamento;
  
    v_peso           number;
    v_tolerancia     number;
    v_pesotolerancia number;
    v_difmaior       number;
    v_difmenor       number;
    v_erro           char(1) := 'N';
    v_msg            t_message;
  begin
    if p_peso = 0 then
      v_msg      := t_message('O peso não pode ser zero. Operação Cancelada.');
      p_mensagem := v_msg.formatMessage;
    end if;
  
    if p_mensagem is null then
      if c_pesocalc%isopen then
        close c_pesocalc;
      end if;
      open c_pesocalc(p_idremanejamento, p_idlote);
      fetch c_pesocalc
        into v_peso;
    
      -- procurando uma escala de tolerancia adequada para o romaneio   
      v_tolerancia := pk_confsaida.retornarPercentualTolerancia(v_peso,
                                                                pk_confsaida.C_REMANEJAMENTO);
    
      if v_tolerancia > 0 then
        -- obtendo os limites de peso tolerado
        v_pesotolerancia := (v_tolerancia / 100) * v_peso;
        v_difmaior       := v_peso + v_pesotolerancia;
        v_difmenor       := v_peso - v_pesotolerancia;
        -- verificando se o peso da balanca esta no intervalo tolerante
        if (p_peso >= v_difmenor)
           and (p_peso <= v_difmaior) then
          v_erro := 'N';
        else
          v_erro := 'S';
        end if;
      
        update loteremanejamento
           set liberado    = decode(v_erro, 'N', 'S', 'E'),
               peso        = p_peso,
               datapesagem = sysdate
         where idremanejamento = p_idremanejamento
           and idlote = p_idlote;
      
        if c_pesocalc%isopen then
          close c_pesocalc;
        end if;
      
        v_msg      := t_message('Lote pesado com sucesso.');
        p_mensagem := v_msg.formatMessage;
      else
        v_msg := t_message('Não existe uma escala de tolerancia configurada no sistema para o peso: {0}.' ||
                           chr(13) ||
                           'Configure a escala e tente novamente.');
        v_msg.addParam(p_peso);
        p_mensagem := v_msg.formatMessage;
      end if;
    end if;
  end;

  procedure EtiquetaImpressaCorreta
  (
    p_idremanejamento in number,
    p_idlote          in number
  ) is
  begin
    update loteremanejamento
       set impetiqueta = 'S'
     where idremanejamento = p_idremanejamento
       and idlote = p_idlote;
  
  end;

  /*
   * Rotina que libera lotes com divergencia do remanejamento de PK para Pulmao
  */
  procedure LiberarLotesDivergente
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_idusuario       in number
  ) is
  begin
    update loteremanejamento
       set liberado  = 'S',
           idusuario = p_idusuario
     where idremanejamento = p_idremanejamento
       and idlote = p_idlote;
  
    pk_utilities.GeraLog(p_idusuario,
                         'LOTE ' || p_idlote ||
                          ' LIBERADO COM DIVERGENCIA DE PESO NO REMANEJAMENTO DE PICKING PARA PULMAO: ' ||
                          p_idremanejamento, p_idlote, 'R');
  end;

  /*
   * Rotina que cancela cadastramento de lotes
  */
  procedure CancelarGerarLotes
  (
    p_idremanejamento in number,
    p_idusuario       in number
  ) is
  begin
    rollback;
    pk_utilities.GeraLog(p_idusuario,
                         'CANCELADO O CADASTRO DE LOTES DO REMANEJAMENTO: ' ||
                          p_idremanejamento, p_idremanejamento, 'R');
  end;

  /*
   * Rotina que finaliza o cadastramento de Lotes
  */
  procedure FinalizarGerarLotes
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_mensagem        out varchar2,
    p_finalizar       out number,
    p_commit          in char := 'S'
  ) is
    cursor c_loteslib(p_idremanejamento in number) is
      select count(*) qtdelotes
        from loteremanejamento
       where idremanejamento = p_idremanejamento
         and (liberado = 'N' or impetiqueta = 'N');
  
    r_loteslib     c_loteslib%rowtype;
    v_complementar lotelocal.complementar%type;
    v_msg          t_message;
  
    function temInfEspecRem(p_idremanejamento in number) return boolean is
      v_qtdeInfEspRem number;
    begin
      select count(1)
        into v_qtdeInfEspRem
        from loteremanejamento lr, lote l, informacaomatdep imd
       where lr.idremanejamento = p_idremanejamento
         and l.idlote = lr.idlote
         and imd.idproduto = l.idproduto
         and imd.identidade = l.iddepositante;
    
      return v_qtdeInfEspRem > 0;
    end;
  begin
    if not temInfEspecRem(p_idremanejamento) then
      if c_loteslib%isopen then
        close c_loteslib;
      end if;
      open c_loteslib(p_idremanejamento);
      fetch c_loteslib
        into r_loteslib;
      if r_loteslib.qtdelotes > 0 then
        v_msg       := t_message('Existem Lotes que não foram liberados ou etiquetas que não foram impressas.' ||
                                 CHR(13) ||
                                 'Cadastramento não pode ser finalizado. Operação Cancelada.');
        p_mensagem  := v_msg.formatMessage;
        p_finalizar := 0;
      
      else
        for c_lotegerados in (select r.idarmazemorigem, r.idlocalorigem,
                                     r.idarmazemdestino, r.idlocaldestino,
                                     lr.idlote, lr.qtde, lt.idproduto,
                                     lt.iddepositante
                                from loteremanejamento lr, remanejamento r,
                                     lote lt
                               where r.idremanejamento = lr.idremanejamento
                                 and lr.idremanejamento = p_idremanejamento
                                 and lt.idlote = lr.idlote)
        loop
          -- Passa Adicionar para o estoque dos lotes criados que estão na origem 
          v_complementar := 'ESTOQUE ADICIONADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                            p_idremanejamento;
        
          pk_picking_dinamico.addGttPickingDinamico(c_lotegerados.idproduto,
                                                    c_lotegerados.iddepositante,
                                                    c_lotegerados.idlocaldestino,
                                                    c_lotegerados.idarmazemdestino,
                                                    1);
        
          pk_estoque.incluir_estoque(c_lotegerados.idarmazemorigem,
                                     c_lotegerados.idlocalorigem,
                                     c_lotegerados.idlote,
                                     c_lotegerados.qtde, p_idusuario,
                                     v_complementar, 'N');
        
          v_complementar := 'ADICIONAR RETIRADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                            p_idremanejamento;
          pk_estoque.retirar_adicionar(c_lotegerados.idarmazemorigem,
                                       c_lotegerados.idlocalorigem,
                                       c_lotegerados.idlote,
                                       c_lotegerados.qtde, p_idusuario,
                                       v_complementar);
        
          -- Incluir lotes criados no destino com adicionar
          v_complementar := 'AUMENTADO ADICIONAR EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N: ' ||
                            p_idremanejamento;
          pk_estoque.incluir_adicionar(c_lotegerados.idarmazemdestino,
                                       c_lotegerados.idlocaldestino,
                                       c_lotegerados.idlote,
                                       c_lotegerados.qtde, p_idusuario,
                                       v_complementar);
        
        end loop;
      
        pk_picking_dinamico.inserir_picking_dinamico;
      
        for c_lotes in (select r.idarmazemorigem idarmazem,
                               r.idlocalorigem idlocal,
                               lo.tipo tipoLocalOrigem,
                               lo.buffer BufferOrigem,
                               c.idloteanterior idlote, lt.idproduto,
                               lt.iddepositante, sum(c.qtde) qtdependencia
                          from remanejamento r, loteremanejamento lr,
                               composicaolote c, local lo, lote lt
                         where r.idremanejamento = p_idremanejamento
                           and lr.idremanejamento = r.idremanejamento
                           and c.idlotenovo = lr.idlote
                           and lo.idlocal = r.idlocalorigem
                           and lo.idarmazem = r.idarmazemorigem
                           and lt.idlote = lr.idlote
                         group by r.idarmazemorigem, r.idlocalorigem, lo.tipo,
                                  lo.buffer, c.idloteanterior, lt.idproduto,
                                  lt.iddepositante)
        loop
        
          -- Subtrair pendencia do estoque dos lotes que estão na origem
          v_complementar := 'PENDENCIA RETIRADA EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                            p_idremanejamento;
        
          pk_estoque.retirar_pendencia(c_lotes.idarmazem, c_lotes.idlocal,
                                       c_lotes.idlote, c_lotes.qtdependencia,
                                       p_idusuario, v_complementar);
          v_complementar := 'ESTOQUE RETIRADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                            p_idremanejamento;
        
          pk_estoque.retirar_estoque(c_lotes.idarmazem, c_lotes.idlocal,
                                     c_lotes.idlote, c_lotes.qtdependencia,
                                     p_idusuario, v_complementar, 'N');
        
          if ((c_lotes.tipoLocalOrigem = 0) AND
             (c_lotes.BufferOrigem = 'N')) then
            pk_picking_dinamico.addGttPickingDinamico(c_lotes.idproduto,
                                                      c_lotes.iddepositante,
                                                      c_lotes.idlocal,
                                                      c_lotes.idarmazem, 0);
          end if;
        end loop;
      
        pk_picking_dinamico.deletar_picking_dinamico;
      
        update remanejamento
           set planejado = 'S'
         where idremanejamento = p_idremanejamento;
      
        if p_commit = 'S' then
          commit;
        end if;
      
        v_msg       := t_message('Formação de lotes finalizada com sucesso.');
        p_mensagem  := v_msg.formatMessage;
        p_finalizar := 1;
      end if;
    else
      update remanejamento
         set planejado = 'S'
       where idremanejamento = p_idremanejamento;
    
      if p_commit = 'S' then
        commit;
      end if;
    
      v_msg       := t_message('Formação de lotes finalizada com sucesso.');
      p_mensagem  := v_msg.formatMessage;
      p_finalizar := 1;
    end if;
  end;

  /*
   * Retornar consulta de reabastecimentos 
  */
  function ConsultaLoteReab
  (
    p_idremanejamento in number,
    p_idlote          in number default 0
  ) return varchar2 is
    v_idLote         varchar2(4000);
    v_lotesIndustria varchar2(4000);
  begin
    if p_idlote = 0 then
      v_idLote := '';
      for c_id in (select lr.idlote
                     from loteremanejamento lr
                    where lr.idremanejamento = p_idremanejamento)
      loop
        if length(trim(v_idLote)) > 0 then
          v_idLote := substr(v_idLote || ',' || to_char(c_id.idlote), 1,
                             4000);
        else
          v_idLote := substr(to_char(c_id.idlote), 1, 4000);
        end if;
      end loop;
    
      return v_idLote;
    else
      v_lotesIndustria := '';
      for c_li in (select distinct l.descr loteIndustria
                     from loteremanejamento lr, lote l
                    where lr.idremanejamento = p_idremanejamento
                      and lr.idlote = p_idlote
                      and lr.idlote = l.idlote)
      loop
        if length(trim(v_lotesIndustria)) > 0 then
          v_lotesIndustria := substr(v_lotesIndustria || ',' ||
                                     to_char(c_li.loteIndustria), 1, 4000);
        else
          v_lotesIndustria := substr(to_char(c_li.loteIndustria), 1, 4000);
        end if;
      end loop;
    
      return v_lotesIndustria;
    end if;
  end;

  /*
  * Rotina que gera etiquetas de remanejamento
  */
  procedure GeraEtiqRemanejamento is
  
    v_cont number := 1;
  begin
    delete from gtt_geraetiqremanej;
  
    for c_etq in (select lr.idremanejamento,
                         sum(lr.qtde / e.fatorconversao) qtdeetiq
                    from loteremanejamento lr, lote l, embalagem e,
                         tipoembalagem te
                   where te.idtipoembalagem(+) = e.idtipoembalagem
                     and e.barra = l.barra
                     and e.idproduto = l.idproduto
                     and l.idlote = lr.idlote
                     and lr.idremanejamento in
                         (select idselecionado
                            from gtt_selecao)
                   group by lr.idremanejamento, l.idproduto)
    loop
      while (v_cont <= c_etq.qtdeetiq)
      loop
      
        insert into gtt_geraetiqremanej
          (idetiqremanej, idremanejamento)
        values
          (seq_gttgeraetiqremanej.nextval, c_etq.idremanejamento);
      
        v_cont := v_cont + 1;
      
      end loop;
      v_cont := 1;
    end loop;
  end;

  -- Refactored procedure validarCubagemMudancaSetor 
  procedure validarCubagemMudancaSetor
  (
    p_idusuario in number,
    p_idproduto in number,
    p_idarmazem in number,
    p_idlocal   in local.idlocal%type,
    p_qtdelotes in out number,
    p_qtdecoube in out number
  ) is
    v_coube    boolean;
    v_tipoerro number;
  begin
    p_qtdelotes := 0;
    p_qtdecoube := 0;
  
    for c_lote in (select ll.idlote, lt.barra,
                          (ll.estoque - ll.pendencia + ll.adicionar) disponivel
                     from lotelocal ll, lote lt, usuariodepositante ud
                    where ll.idarmazem = p_idarmazem
                      and ll.idlocal = p_idlocal
                      and ll.estoque - ll.pendencia + ll.adicionar > 0
                      and lt.idlote = ll.idlote
                      and lt.idproduto = p_idproduto
                      and ud.identidade = lt.iddepositante
                      and ud.idusuario = p_idusuario
                      and lt.idlotemont is null)
    loop
      p_qtdelotes := p_qtdelotes + 1;
      v_coube     := CtrlValidarRestriFisicas(p_idproduto, c_lote.disponivel,
                                              p_idarmazem, p_idlocal,
                                              c_lote.barra, v_tipoerro);
    
      if v_coube then
        p_qtdecoube := p_qtdecoube + 1;
        insert into gtt_produtoremanejamento
          (idproduto, barra, qtde)
        values
          (p_idproduto, c_lote.barra, c_lote.disponivel);
      else
        delete from gtt_produtoremanejamento;
        exit when not v_coube;
      end if;
    end loop;
  end validarCubagemMudancaSetor;

  /*
  *  Localiza um setor com prioridade 1 que seja do tipo compra ou devolucao
  */
  procedure getSetorPrioridadeUm
  (
    p_idusuario in number,
    p_idproduto in number,
    p_idsetor   in out number
  ) is
    v_msg t_message;
  begin
    begin
      select sp.idsetor
        into p_idsetor
        from setor s, setorproduto sp, setordepositante sd,
             usuariodepositante ud
       where s.ativo = 'S'
         and sp.idsetor = s.idsetor
         and sp.idproduto = p_idproduto
         and sp.prioridade = 1
         and sd.idsetor = s.idsetor
         and ud.identidade = sd.iddepositante
         and ud.idusuario = p_idusuario
         and exists
       (select 1
                from setorrecebimento sr, tiporecebimento tr
               where sr.idsetor = s.idsetor
                 and sr.idtiporecebimento = tr.idtiporecebimento
                 and tr.classificacao in ('C', 'D', 'T'))
         and rownum = 1;
    exception
      when no_data_found then
        v_msg := t_message('NENHUM SETOR ATIVO COM PRIORIDADE 1 QUE POSSUA TIPO DE RECEBIMENTO "COMPRA", OU "DEVOLUCAO" DEFINIDO PARA OS DEPOSITANTES DO USUARIO ID ' ||
                           '{0}, PRODUTO {1}.');
        v_msg.addParam(p_idusuario);
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  end getSetorPrioridadeUm;

  -- Refactored procedure CtrlPickingParaRemMudSetor 
  procedure CtrlPickingParaRemMudSetor
  (
    p_idproduto      in number,
    p_idarmazem      in number,
    p_idlocaldestino in local.idlocal%type,
    p_iddepositante  in number,
    p_idendereco     in number,
    p_idlocalorigem  in local.idlocal%type
  ) is
    v_tipodestino number;
    v_idpicking   number;
  begin
    select l.tipo
      into v_tipodestino
      from local l
     where l.idlocal = p_idlocaldestino
       and l.idarmazem = p_idarmazem;
  
    delete from produtolocal pl
     where pl.idproduto = p_idproduto
       and pl.idarmazem = p_idarmazem
       and pl.idlocal = p_idlocalorigem
       and pl.identidade = p_iddepositante;
  
    if v_tipodestino = 0 then
      begin
        select pl.idprodutolocal
          into v_idpicking
          from produtolocal pl
         where pl.idproduto = p_idproduto
           and pl.idarmazem = p_idarmazem
           and pl.idlocal = p_idlocaldestino
           and pl.identidade = p_iddepositante;
      exception
        when no_data_found then
          pk_armazem.criarPickingProduto(p_idarmazem, p_idlocaldestino,
                                         p_iddepositante, p_idproduto);
      end;
    end if;
  end CtrlPickingParaRemMudSetor;

  /*
  * Rotina responsavel por gerar o remanejamento por motivo de mudança de setor.
  */
  function NovoRemPorMudancaSetor
  (
    p_idusuario     in number,
    p_idproduto     in number,
    p_idarmazem     in number,
    p_idlocalorigem in local.idlocal%type
  ) return number is
    v_idlocaldestino  local.idlocal%type;
    v_idremanejamento number;
    v_idsetor         number;
    v_bufferorigem    char;
    v_tipoorigem      number;
    v_qtdelotes       number;
    v_qtdecoube       number;
    v_prioridade      number;
    v_totaldisponivel number;
    v_msg             t_message;
  begin
    getSetorPrioridadeUm(p_idusuario, p_idproduto, v_idsetor);
  
    begin
      select l.buffer, l.tipo, sp.prioridade
        into v_bufferorigem, v_tipoorigem, v_prioridade
        from local l, setorproduto sp
       where l.idlocal = p_idlocalorigem
         and l.idarmazem = p_idarmazem
         and sp.idsetor = l.idsetor
         and sp.idproduto = p_idproduto;
    
      if (v_tipoorigem not in (0, 1, 2) or v_bufferorigem = 'S') then
        v_msg := t_message('O LOCAL DE ORIGEM {0}' ||
                           ' DEVE SER UM LOCAL DO TIPO PULMAO OU PICKING');
        v_msg.addParam(p_idlocalorigem);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (v_prioridade <> 10) then
        v_msg := t_message('O LOCAL DE ORIGEM {0}' ||
                           ' ESTA EM UM SETOR COM PRIORIDADE {1}' ||
                           '. O CORRETO É O LOCAL ESTAR EM UM SETOR COM PRIORIDADE 10.');
        v_msg.addParam(p_idlocalorigem);
        v_msg.addParam(v_prioridade);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    exception
      when no_data_found then
        v_msg := t_message('LOCAL {0} PARA O ARMAZEM {1} NÃO ENCONTRADO.');
        v_msg.addParam(p_idlocalorigem);
        v_msg.addParam(p_idarmazem);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    begin
      select sum((ll.estoque - ll.pendencia + ll.adicionar)) total
        into v_totaldisponivel
        from lotelocal ll, lote lt, usuariodepositante ud
       where ll.idarmazem = p_idarmazem
         and ll.idlocal = p_idlocalorigem
         and lt.idlote = ll.idlote
         and lt.idproduto = p_idproduto
         and ud.idusuario = p_idusuario
         and lt.iddepositante = ud.identidade
         and lt.idlotemont is null;
    exception
      when no_data_found then
        v_msg := t_message('O LOCAL DE ORIGEM {0}' ||
                           ' NAO POSSUI QTDE EM ESTOQUE DISPONIVEL PARA CRIAR O REMANEJAMENTO.');
        v_msg.addParam(p_idlocalorigem);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    -- Aplicando 1 regra: Buscar endereco de destino onde haja estoque do produto e permita cubagem do mesmo
    for c_local in (select l.idlocal
                      from lotelocal ll, lote lt, usuariodepositante ud,
                           local l
                     where lt.idlote = ll.idlote
                       and lt.idproduto = p_idproduto
                       and ud.idusuario = p_idusuario
                       and ud.identidade = lt.iddepositante
                       and l.idlocal = ll.idlocal
                       and l.idarmazem = ll.idarmazem
                       and l.idarmazem = p_idarmazem
                       and l.idsetor = v_idsetor
                       and l.buffer = v_bufferorigem
                       and decode(l.tipo, 2, 1, l.tipo) =
                           decode(v_tipoorigem, 2, 1, v_tipoorigem)
                       and l.ativo = 'S')
    loop
      validarCubagemMudancaSetor(p_idusuario, p_idproduto, p_idarmazem,
                                 c_local.idlocal, v_qtdelotes, v_qtdecoube);
    
      if v_qtdelotes = v_qtdecoube then
        v_idlocaldestino := c_local.idlocal;
        exit when v_qtdelotes = v_qtdecoube;
      end if;
    end loop;
  
    -- Aplicando 2 regra: Buscar endereco de destino vazio que permita cubagem do mesmo
    if v_idlocaldestino is null then
      for c_localvazio in (select l.idlocal
                             from local l
                            where l.idarmazem = p_idarmazem
                              and l.idsetor = v_idsetor
                              and l.buffer = v_bufferorigem
                              and decode(l.tipo, 2, 1, l.tipo) =
                                  decode(v_tipoorigem, 2, 1, v_tipoorigem)
                              and l.ativo = 'S'
                              and not exists
                            (select 1
                                     from v_estoque_local
                                    where idlocal = l.idlocal
                                      and idarmazem = l.idarmazem
                                    group by idarmazem, idlocal
                                   having nvl(sum(disp), 0) > 0))
      loop
        validarCubagemMudancaSetor(p_idusuario, p_idproduto, p_idarmazem,
                                   c_localvazio.idlocal, v_qtdelotes,
                                   v_qtdecoube);
      
        if v_qtdelotes = v_qtdecoube then
          v_idlocaldestino := c_localvazio.idlocal;
          exit when v_qtdelotes = v_qtdecoube;
        end if;
      end loop;
    end if;
  
    -- Aplicando 3 regra: Buscar endereco com menor quantidade de SKU do mesmo depositante
    if v_idlocaldestino is null then
      for c_localsku in (select l.idlocal, count(distinct lt.idproduto) sku
                           from lotelocal ll, lote lt, usuariodepositante ud,
                                local l
                          where lt.idlote = ll.idlote
                            and ud.idusuario = p_idusuario
                            and lt.iddepositante = ud.identidade
                            and l.idlocal = ll.idlocal
                            and l.idarmazem = ll.idarmazem
                            and l.idarmazem = p_idarmazem
                            and l.idsetor = v_idsetor
                            and l.buffer = v_bufferorigem
                            and decode(l.tipo, 2, 1, l.tipo) =
                                decode(v_tipoorigem, 2, 1, v_tipoorigem)
                            and l.ativo = 'S'
                          group by l.idlocal
                          order by sku, l.idlocal)
      loop
        validarCubagemMudancaSetor(p_idusuario, p_idproduto, p_idarmazem,
                                   c_localsku.idlocal, v_qtdelotes,
                                   v_qtdecoube);
      
        if v_qtdelotes = v_qtdecoube then
          v_idlocaldestino := c_localsku.idlocal;
          exit when v_qtdelotes = v_qtdecoube;
        end if;
      end loop;
    end if;
  
    if v_idlocaldestino is null then
      v_msg := t_message('NENHUM LOCAL NO ARMAZEM PERMITE ALOCAR TODA QTDE DO PRODUTO VALIDANDO A CUBAGEM.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    -- Criando remanejamento 
    v_idremanejamento := cadastrar_remanejamento(p_idarmazem, p_idarmazem,
                                                 p_idlocalorigem,
                                                 v_idlocaldestino,
                                                 p_idusuario, null,
                                                 'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE SETOR',
                                                 C_NAO, C_SIM);
    update remanejamento r
       set r.tipo = 1
     where r.idremanejamento = v_idremanejamento;
  
    for c_lote in (select ll.idlote, lt.barra,
                          (ll.estoque - ll.pendencia + ll.adicionar) disponivel,
                          lt.iddepositante, l.id idendereco
                     from lotelocal ll, lote lt, usuariodepositante ud,
                          local l
                    where ll.idarmazem = p_idarmazem
                      and ll.idlocal = p_idlocalorigem
                      and ll.estoque - ll.pendencia + ll.adicionar > 0
                      and lt.idlote = ll.idlote
                      and lt.idproduto = p_idproduto
                      and ud.idusuario = p_idusuario
                      and lt.iddepositante = ud.identidade
                      and lt.idlotemont is null
                      and l.idlocal = ll.idlocal
                      and l.idarmazem = ll.idarmazem)
    loop
      CtrlPickingParaRemMudSetor(p_idproduto, p_idarmazem, v_idlocaldestino,
                                 c_lote.iddepositante, c_lote.idendereco,
                                 p_idlocalorigem);
    
      insert into loteremanejamento
        (idremanejamento, idlote, qtde, conferido, controlaqtde, diferenca)
      values
        (v_idremanejamento, c_lote.idlote, c_lote.disponivel, c_nao, c_sim,
         0);
    
      Associar(v_idremanejamento, c_lote.idlote);
    end loop;
  
    return v_idremanejamento;
  end;

  /*
  *  Localiza um setor com prioridade 1 que seja do tipo compra ou devolucao
  */
  procedure getSetorMaiorPrioridade
  (
    p_idusuario in number,
    p_idproduto in number,
    p_idsetor   in out number
  ) is
    v_msg t_message;
  begin
    begin
      select idsetor
        into p_idsetor
        from (select sp.idsetor
                 from setor s, setorproduto sp, setordepositante sd,
                      usuariodepositante ud
                where s.ativo = 'S'
                  and sp.idsetor = s.idsetor
                  and sp.idproduto = p_idproduto
                  and sp.prioridade = 1
                  and sd.idsetor = s.idsetor
                  and ud.identidade = sd.iddepositante
                  and ud.idusuario = p_idusuario
                  and exists
                (select 1
                         from setorrecebimento sr, tiporecebimento tr
                        where sr.idsetor = s.idsetor
                          and sr.idtiporecebimento = tr.idtiporecebimento
                          and tr.classificacao in ('C', 'D', 'T'))
                order by sp.prioridade)
       where rownum = 1;
    exception
      when no_data_found then
        v_msg := t_message('NENHUM SETOR ATIVO QUE POSSUA TIPO DE RECEBIMENTO "COMPRA", OU "DEVOLUCAO" DEFINIDO PARA OS DEPOSITANTES DO USUARIO ID ' ||
                           '{0}, PRODUTO {1}.');
        v_msg.addParam(p_idusuario);
        v_msg.addParam(p_idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  end getSetorMaiorPrioridade;

  -- Refactored procedure buscarEnderecoPulmaoVazio 
  function buscarEnderecoPulmaoVazio
  (
    p_idusuario in number,
    v_encomenda in encomenda%rowtype
  ) return local.idlocal%type is
    v_qtdelotes number;
    v_qtdecoube number;
    v_idlocal   local.idlocal%type := null;
  begin
    for c_localvazio in (select l.idlocal
                           from local l, setor s, setorproduto sp
                          where l.idarmazem = v_encomenda.idarmazem
                            and decode(l.buffer, 'N', 0, 1) = 0
                            and l.tipo in (1, 2)
                            and decode(l.ativo, 'N', 0, 1) = 1
                            and s.idsetor = l.idsetor
                            and sp.idsetor = s.idsetor
                            and sp.idproduto = v_encomenda.idproduto
                            and not exists
                          (select 1
                                   from setorrecebimento sr,
                                        tiporecebimento tr
                                  where tr.classificacao = 'E'
                                    and tr.idtiporecebimento =
                                        sr.idtiporecebimento
                                    and sr.idsetor = l.idsetor)
                            and not exists
                          (select 1
                                   from lotelocal ll
                                  where ll.idlocal = l.idlocal
                                    and ll.idarmazem = l.idarmazem
                                    and ll.estoque - ll.pendencia +
                                        ll.adicionar > 0)
                          order by sp.prioridade, l.idlocal)
    loop
      validarCubagemMudancaSetor(p_idusuario, v_encomenda.idproduto,
                                 v_encomenda.idarmazem, c_localvazio.idlocal,
                                 v_qtdelotes, v_qtdecoube);
    
      if v_qtdelotes = v_qtdecoube then
        v_idlocal := c_localvazio.idlocal;
        exit when v_qtdelotes = v_qtdecoube;
      end if;
    end loop;
  
    return v_idlocal;
  end;

  -- Refactored procedure buscarEnderecoPulmaoComEstoque 
  function buscarEnderecoPulmaoComEstoque
  (
    p_idusuario in number,
    v_encomenda in encomenda%rowtype
  ) return local.idlocal%type is
    v_qtdelotes number;
    v_qtdecoube number;
    v_idlocal   local.idlocal%type := null;
  begin
    for c_local in (select l.idlocal
                      from lotelocal ll, lote lt, usuariodepositante ud,
                           local l, setor s, setorproduto sp
                     where lt.idlote = ll.idlote
                       and lt.idproduto = v_encomenda.idproduto
                       and lt.iddepositante = v_encomenda.iddepositante
                       and ud.idusuario = p_idusuario
                       and ud.identidade = lt.iddepositante
                       and l.idlocal = ll.idlocal
                       and l.idarmazem = ll.idarmazem
                       and l.idarmazem = v_encomenda.idarmazem
                       and decode(l.buffer, 'N', 0, 1) = 0
                       and l.tipo in (1, 2)
                       and decode(l.ativo, 'N', 0, 1) = 1
                       and ll.estoque - ll.pendencia + ll.adicionar > 0
                       and s.idsetor = l.idsetor
                       and sp.idsetor = s.idsetor
                       and sp.idproduto = v_encomenda.idproduto
                       and not exists
                     (select 1
                              from setorrecebimento sr, tiporecebimento tr
                             where tr.classificacao = 'E'
                               and tr.idtiporecebimento =
                                   sr.idtiporecebimento
                               and sr.idsetor = l.idsetor)
                     order by l.idlocal)
    loop
      validarCubagemMudancaSetor(p_idusuario, v_encomenda.idproduto,
                                 v_encomenda.idarmazem, c_local.idlocal,
                                 v_qtdelotes, v_qtdecoube);
    
      if v_qtdelotes = v_qtdecoube then
        v_idlocal := c_local.idlocal;
        exit when v_qtdelotes = v_qtdecoube;
      end if;
    end loop;
  
    return v_idlocal;
  end;

  -- Refactored procedure buscarEnderecoPickingMaiorEspaco 
  function buscarEndPickingMaiorEspaco
  (
    p_idusuario in number,
    v_encomenda in encomenda%rowtype
  ) return local.idlocal%type is
    v_qtdelotes number;
    v_qtdecoube number;
    v_idlocal   local.idlocal%type := null;
  begin
    for c_localmaior in (select l.idlocal,
                                ((l.altura - l.alturamanobra) * l.largura *
                                 l.comprimento) -
                                 sum(e.altura * e.largura * e.comprimento *
                                     (ll.estoque - ll.pendencia +
                                     ll.adicionar)) cubestoque
                           from lotelocal ll, lote lt, local l, embalagem e,
                                produtolocal pl, setor s, setorproduto sp,
                                usuariodepositante ud
                          where ud.idusuario = p_idusuario
                            and ud.identidade = lt.iddepositante
                            and sp.idproduto = lt.idproduto
                            and sp.idsetor = s.idsetor
                            and s.idsetor = l.idsetor
                            and pl.idproduto = lt.idproduto
                            and pl.identidade = lt.iddepositante
                            and pl.idlocal = ll.idlocal
                            and pl.idarmazem = ll.idarmazem
                            and e.barra = lt.barra
                            and e.idproduto = lt.idproduto
                            and l.tipo = 0
                            and decode(l.buffer, 'N', 0, 1) = 0
                            and decode(l.ativo, 'N', 0, 1) = 1
                            and l.idlocal = ll.idlocal
                            and l.idarmazem = ll.idarmazem
                            and lt.iddepositante = v_encomenda.iddepositante
                            and lt.idproduto = v_encomenda.idproduto
                            and lt.idlote = ll.idlote
                            and ll.estoque + ll.adicionar > 0
                            and ll.idarmazem = v_encomenda.idarmazem
                            and not exists
                          (select 1
                                   from setorrecebimento sr,
                                        tiporecebimento tr
                                  where tr.classificacao = 'E'
                                    and tr.idtiporecebimento =
                                        sr.idtiporecebimento
                                    and sr.idsetor = l.idsetor)
                          group by l.idlocal, l.altura, l.largura,
                                   l.comprimento, l.alturamanobra
                          order by cubestoque desc)
    loop
      validarCubagemMudancaSetor(p_idusuario, v_encomenda.idproduto,
                                 v_encomenda.idarmazem, c_localmaior.idlocal,
                                 v_qtdelotes, v_qtdecoube);
    
      if v_qtdelotes = v_qtdecoube then
        v_idlocal := c_localmaior.idlocal;
        exit when v_qtdelotes = v_qtdecoube;
      end if;
    end loop;
  
    return v_idlocal;
  end;

  /*
   * Rotina responsavel por gerar remanejamentos de itens ja alocados de encomendas
  */
  procedure GerarRemItensAlocados
  (
    p_idencomenda in number,
    p_idusuario   in number
  ) is
    v_encomenda               encomenda%rowtype;
    v_qtderemanejar           number;
    v_qtdelote                number;
    v_idlocaldestino          local.idlocal%type;
    v_idremanejamento         number;
    v_qtdeemremanejamento     number;
    v_qtdeTotalCaixas         number;
    v_normaPallet             number;
    v_qtdePallet              number;
    v_caixasPallet            number;
    v_unidadesPallet          number;
    v_qtdeLastro              number;
    v_caixasLastro            number;
    v_unidadesLastro          number;
    v_qtdeCaixas              number;
    v_unidadesCaixas          number;
    v_qtdeunidades            number;
    v_metodoger_incompl_sobra number;
    v_msg                     t_message;
  begin
    begin
      select ec.id, ec.pedido, ec.serie, ec.idproduto, ec.codigoencomenda,
             ec.qtde, ec.idsetor, ec.iddepositante, ec.idarmazem, ec.status,
             ec.data, ec.qtdealocada, ec.qtdeconferida, ec.qtderemanejada,
             ec.idnotafiscalsaida
        into v_encomenda
        from encomenda ec
       where ec.id = p_idencomenda;
    exception
      when no_data_found then
        v_msg := t_message('ENCOMENDA ID {0} NAO ENCONTRADA.');
        v_msg.addParam(p_idencomenda);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    -- Seleciona o método de geração de lotes para palet incompleto e sobra
    select ar.metodogerlotesobraincompl
      into v_metodoger_incompl_sobra
      from encomenda e, armazem ar
     where ar.idarmazem = e.idarmazem
       and e.id = p_idencomenda;
  
    v_qtdeemremanejamento := 0;
    v_qtderemanejar       := (v_encomenda.qtdealocada -
                             v_encomenda.qtderemanejada) - v_encomenda.qtde;
  
    if (v_qtderemanejar > 0) then
      for c_estoque in (select ll.idlocal, lt.idlote,
                               (ll.estoque - ll.pendencia + ll.adicionar) disponivel,
                               lt.iddepositante, l.id idendereco,
                               e.fatorconversao,
                               pd.tipoalocpalletincompleto palletimcompleto,
                               e.lastro, e.qtdecamada,
                               pd.tipoalocpalletquebra,
                               pd.tipoalocpalletsobra, e.caixafechada
                          from lote lt, lotelocal ll, local l, embalagem e,
                               produtodepositante pd
                         where pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante
                           and e.barra =
                               pk_produto.ret_codbarra_nao_precad(lt.idproduto,
                                                                  1)
                           and e.idproduto = lt.idproduto
                           and l.idsetor = v_encomenda.idsetor
                           and l.idlocal = ll.idlocal
                           and l.idarmazem = ll.idarmazem
                           and (ll.estoque - ll.pendencia + ll.adicionar) > 0
                           and ll.idlote = lt.idlote
                           and lt.idencomenda = p_idencomenda)
      loop
        if (c_estoque.disponivel > v_qtderemanejar) then
          v_qtdelote := v_qtderemanejar;
        else
          v_qtdelote := c_estoque.disponivel;
        end if;
      
        pk_lote.CalcularQtdeLotes(v_qtdelote, c_estoque.fatorconversao,
                                  c_estoque.lastro, c_estoque.qtdecamada,
                                  c_estoque.caixafechada,
                                  v_metodoger_incompl_sobra,
                                  v_qtdeTotalCaixas, v_normaPallet,
                                  v_qtdePallet, v_caixasPallet,
                                  v_unidadesPallet, v_qtdeLastro,
                                  v_caixasLastro, v_unidadesLastro,
                                  v_qtdeCaixas, v_unidadesCaixas,
                                  v_qtdeunidades);
      
        if (v_qtdePallet > 0) then
          -- Aplicando 1 regra: Buscar endereco de destino vazio que permita cubagem do mesmo
          v_idlocaldestino := buscarEnderecoPulmaoVazio(p_idusuario,
                                                        v_encomenda);
        
          -- Aplicando 2 regra: Buscar endereco de destino onde haja estoque do produto e permita cubagem do mesmo
          if v_idlocaldestino is null then
            v_idlocaldestino := buscarEnderecoPulmaoComEstoque(p_idusuario,
                                                               v_encomenda);
          end if;
        
          if v_idlocaldestino is not null then
            v_qtdeemremanejamento := v_qtdeemremanejamento +
                                     v_unidadesPallet;
          
            -- Criando remanejamento 
            v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                         v_encomenda.idarmazem,
                                                         c_estoque.idlocal,
                                                         v_idlocaldestino,
                                                         p_idusuario, null,
                                                         'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                         C_NAO, C_SIM);
            update remanejamento r
               set r.tipo = 2
             where r.idremanejamento = v_idremanejamento;
          
            begin
              insert into loteremanejamento
                (idremanejamento, idlote, qtde, conferido, controlaqtde,
                 diferenca)
              values
                (v_idremanejamento, c_estoque.idlote, v_unidadesPallet,
                 c_nao, c_sim, 0);
            exception
              when dup_val_on_index then
                update loteremanejamento
                   set qtde = qtde + v_unidadesPallet
                 where idremanejamento = v_idremanejamento
                   and idlote = c_estoque.idlote;
            end;
          
            Associar(v_idremanejamento, c_estoque.idlote);
          else
            v_msg := t_message('ENDERECO DE DESTINO PARA REMANEJAMENTO DE PALLET COMPLETO NAO ENCONTRADO.');
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      
        if (v_qtdeLastro > 0) then
          v_idlocaldestino := null;
          if (c_estoque.palletimcompleto = 0 or
             c_estoque.palletimcompleto = 1) then
          
            -- Aplicando 1 regra: Buscar endereco de destino onde haja estoque do produto e permita cubagem do mesmo
            if (v_idlocaldestino is null and c_estoque.palletimcompleto = 1) then
              v_idlocaldestino := buscarEnderecoPulmaoComEstoque(p_idusuario,
                                                                 v_encomenda);
            end if;
          
            -- Aplicando 2 regra: Buscar endereco de destino vazio que permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEnderecoPulmaoVazio(p_idusuario,
                                                            v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_unidadesLastro;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_unidadesLastro,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_unidadesLastro
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PULMAO PARA REMANEJAMENTO DE PALLET INCOMPLETO NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          elsif (c_estoque.palletimcompleto = 2) then
            -- Aplicando 1 regra: Buscar endereco de destino onde haja maior espaço disponível e permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEndPickingMaiorEspaco(p_idusuario,
                                                              v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_unidadesLastro;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_unidadesLastro,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_unidadesLastro
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PICKING PARA REMANEJAMENTO DE PALLET INCOMPLETO NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end if;
        end if;
      
        if (v_qtdeCaixas > 0) then
          v_idlocaldestino := null;
          if (c_estoque.tipoalocpalletsobra = 0) then
            -- Aplicando 1 regra: Buscar endereco de destino vazio que permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEnderecoPulmaoVazio(p_idusuario,
                                                            v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_unidadesCaixas;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_unidadesCaixas,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_unidadesCaixas
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PULMAO VAZIO PARA REMANEJAMENTO DE PALLET SOBRA NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          elsif (c_estoque.tipoalocpalletsobra = 1) then
            -- Aplicando 1 regra: Buscar endereco de destino onde haja estoque do produto e permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEnderecoPulmaoComEstoque(p_idusuario,
                                                                 v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_unidadesCaixas;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_unidadesCaixas,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_unidadesCaixas
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PULMAO UTILIZADO PARA REMANEJAMENTO DE PALLET SOBRA NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
          elsif (c_estoque.tipoalocpalletsobra = 2) then
            -- Aplicando 1 regra: Buscar endereco de destino onde haja maior espaço disponível e permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEndPickingMaiorEspaco(p_idusuario,
                                                              v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_unidadesCaixas;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_unidadesCaixas,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_unidadesCaixas
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PICKING PARA REMANEJAMENTO DE PALLET SOBRA NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end if;
        end if;
      
        if (v_qtdeunidades > 0) then
          v_idlocaldestino := null;
          if (c_estoque.tipoalocpalletquebra = 0) then
            -- Aplicando 1 regra: Buscar endereco de destino vazio que permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEnderecoPulmaoVazio(p_idusuario,
                                                            v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_qtdeunidades;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_qtdeunidades,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_qtdeunidades
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PULMAO VAZIO PARA REMANEJAMENTO DE PALLET INCOMPLETO NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          elsif (c_estoque.tipoalocpalletquebra = 1) then
            -- Aplicando 1 regra: Buscar endereco de destino onde haja estoque do produto e permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEnderecoPulmaoComEstoque(p_idusuario,
                                                                 v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_qtdeunidades;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_qtdeunidades,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_qtdeunidades
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PULMAO UTILIZADO PARA REMANEJAMENTO DE PALLET INCOMPLETO NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          elsif (c_estoque.tipoalocpalletquebra = 2) then
            -- Aplicando 1 regra: Buscar endereco de destino onde haja maior espaço disponível e permita cubagem do mesmo
            if v_idlocaldestino is null then
              v_idlocaldestino := buscarEndPickingMaiorEspaco(p_idusuario,
                                                              v_encomenda);
            end if;
          
            if v_idlocaldestino is not null then
              v_qtdeemremanejamento := v_qtdeemremanejamento +
                                       v_qtdeunidades;
            
              -- Criando remanejamento 
              v_idremanejamento := cadastrar_remanejamento(v_encomenda.idarmazem,
                                                           v_encomenda.idarmazem,
                                                           c_estoque.idlocal,
                                                           v_idlocaldestino,
                                                           p_idusuario, null,
                                                           'REMANEJAMENTO CRIADO POR MOTIVO DE ALTERACAO DE ENCOMENDA',
                                                           C_NAO, C_SIM);
              update remanejamento r
                 set r.tipo = 2
               where r.idremanejamento = v_idremanejamento;
            
              begin
                insert into loteremanejamento
                  (idremanejamento, idlote, qtde, conferido, controlaqtde,
                   diferenca)
                values
                  (v_idremanejamento, c_estoque.idlote, v_qtdeunidades,
                   c_nao, c_sim, 0);
              exception
                when dup_val_on_index then
                  update loteremanejamento
                     set qtde = qtde + v_qtdeunidades
                   where idremanejamento = v_idremanejamento
                     and idlote = c_estoque.idlote;
              end;
            
              Associar(v_idremanejamento, c_estoque.idlote);
            else
              v_msg := t_message('ENDERECO DE PICKING PARA REMANEJAMENTO DE PALLET INCOMPLETO NAO ENCONTRADO.');
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end if;
        end if;
      
        v_idlocaldestino := null;
        exit when v_qtdeemremanejamento = v_qtderemanejar;
      end loop;
    
      update encomenda
         set qtderemanejada = qtderemanejada + v_qtderemanejar
       where id = p_idencomenda;
    end if;
  end;

  -- Refactored procedure validarMudancaPicking 
  procedure validarMudancaPicking
  (
    p_iddepositante            in number,
    p_idproduto                in number,
    p_idArmazem                in number,
    p_idlocalorigem            in local.idlocal%type,
    p_transfPendenciaAdicionar in out number,
    p_idlocaldestino           in local.idlocal%type,
    p_mudarPickingVazio        in number
  ) is
    v_totaldepositantes   number;
    v_totalpermitidomover number;
    v_totalestoque        number;
    r_loteUnicoComparar   pk_lote.t_loteunico;
    r_loteunico           pk_lote.t_loteunico;
    v_loteuniconoendereco number;
    v_msgErro             varchar2(1000);
    v_msg                 t_message;
    v_remanejamentos      varchar2(4000);
    r_local               local%rowtype;
  begin
  
    for c in (select l.idproduto, l.descr, l.dtvenc, l.estado,
                     pd.loteuniconoendereco, l.iddepositante
                from lotelocal ll, lote l, produtodepositante pd
               where l.idlote = ll.idlote
                 and ll.idlocal = p_idlocalorigem
                 and ll.idarmazem = p_idArmazem
                 and l.idproduto = p_idproduto
                 and l.iddepositante = pd.identidade
                 and pd.idproduto = l.idproduto)
    loop
    
      r_loteunicocomparar.idproduto           := c.idproduto;
      r_loteunicocomparar.estado              := c.estado;
      r_loteunicocomparar.loteindustria       := c.descr;
      r_loteunicocomparar.dtvencimento        := c.dtvenc;
      r_loteunicocomparar.loteuniconoendereco := c.loteuniconoendereco;
      r_loteunicocomparar.iddepositante       := c.iddepositante;
    
      if (not
          pk_lote.isLocalPodeReceberLoteUnico(r_loteunicocomparar,
                                               p_idArmazem, p_idlocaldestino,
                                               v_msgErro)) then
        raise_application_error(-20000, v_msgErro);
      end if;
    end loop;
  
    select count(distinct lt.iddepositante)
      into v_totaldepositantes
      from lotelocal ll, lote lt
     where ll.idlocal = p_idlocalorigem
       and ll.idarmazem = p_idarmazem
       and lt.idlote = ll.idlote
       and lt.idproduto = p_idproduto;
  
    if (v_totaldepositantes > 1) then
      v_msg := t_message('Erro ao executar mudança de picking. Local de Origem possui estoque de mais de um depositante.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select sum(ll.estoque - ll.pendencia) permitido,
           sum(ll.estoque + ll.adicionar) total
      into v_totalpermitidomover, v_totalestoque
      from lotelocal ll, lote lt
     where ll.idlocal = p_idlocalorigem
       and ll.idarmazem = p_idArmazem
       and (ll.estoque > 0 or ll.pendencia > 0 or ll.adicionar > 0)
       and lt.idlote = ll.idlote
       and lt.idproduto = p_idproduto
       and lt.iddepositante = p_iddepositante;
  
    if (v_totalestoque = 0 and p_mudarPickingVazio = 0) then
      v_msg := t_message('Endereço de origem sem estoque do produto. Operação cancelada');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if (v_totalpermitidomover = 0 and p_transfPendenciaAdicionar = 0) then
      v_msg := t_message('A configuração para transferir pendencia e adicionar na mudança de picking esta destivada.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select substr(stragg(r.idremanejamento), 1, 4000)
      into v_remanejamentos
      from remanejamento r, loteremanejamento lr, lote lt
     where r.idlocalorigem = p_idlocaldestino
       and r.idlocaldestino = p_idlocalorigem
       and r.idarmazemorigem = p_idArmazem
       and r.idarmazemdestino = p_idArmazem
       and lr.idremanejamento = r.idremanejamento
       and lt.idlote = lr.idlote
       and lt.idproduto = p_idproduto
       and lt.iddepositante = p_iddepositante
       and r.status <> 'F';
  
    if (v_remanejamentos is not null) then
      v_msg := t_message('Existe(m) remanejamento(s) criado(s) com local de origem igual o ' ||
                         'local destino e local destino igual ao local origem da mudança de ' ||
                         'picking para este produto e depositante. Finalize ou cancele o(s) remanejamento(s) ' ||
                         'para continuar. Remanejamento(s): {0}');
      v_msg.addParam(v_remanejamentos);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    pk_armazem.validarSetorPickingProduto(p_idArmazem, p_idlocaldestino,
                                          p_iddepositante, p_idproduto);
  
    select l.*
      into r_local
      from local l
     where l.idarmazem = p_idArmazem
       and l.idlocal = p_idlocaldestino;
  
    if (r_local.ativo = 'N') then
      v_msg := t_message('O local de destino da mudança de picking esta INATIVO.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select l.*
      into r_local
      from local l
     where l.idarmazem = p_idArmazem
       and l.idlocal = p_idlocalorigem;
  
    if (r_local.ativo = 'N') then
      v_msg := t_message('O local de origem da mudança de picking esta INATIVO.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end validarMudancaPicking;

  -- Refactored procedure criarRemMudancaPicking 
  procedure criarRemMudancaPicking
  (
    p_idusuario                in number,
    p_iddepositante            in number,
    p_idproduto                in number,
    p_idArmazem                in number,
    p_idlocalorigem            in local.idlocal%type,
    p_idlocaldestino           in local.idlocal%type,
    p_transfPendenciaAdicionar in number,
    p_idremanejamento          in out number
  ) is
    v_jaexistepickdestino number;
    v_qtdelr              number;
  begin
    select seq_remanejamento.nextval idremanejamento
      into p_idremanejamento
      from dual;
  
    pk_triggers_control.disableTrigger('T_BEFORE_REMANEJAMENTO');
  
    insert into remanejamento
      (idremanejamento, idarmazemorigem, idlocalorigem, idarmazemdestino,
       idlocaldestino, datahora, idusuariotela, status, cadmanual,
       idromaneio, descrpalet, planejado, horainicio, tipo)
    values
      (p_idremanejamento, p_idarmazem, p_idlocalorigem, p_idarmazem,
       p_idlocaldestino, sysdate, p_idusuario, c_aguardando, c_nao, NULL,
       'REMANEJAMENTO CRIADO PARA MUDANÇA DE PICKING', 'N', sysdate, 3);
  
    pk_triggers_control.enableTrigger('T_BEFORE_REMANEJAMENTO');
  
    delete from produtolocal pd
     where pd.idarmazem = p_idArmazem
       and pd.idlocal = p_idlocalorigem
       and pd.idproduto = p_idproduto
       and pd.identidade = p_iddepositante;
  
    select count(*)
      into v_jaexistepickdestino
      from produtolocal pd
     where pd.idarmazem = p_idArmazem
       and pd.idlocal = p_idlocaldestino
       and pd.idproduto = p_idproduto
       and pd.identidade = p_iddepositante;
  
    if (v_jaexistepickdestino = 0) then
      pk_armazem.criarPickingProduto(p_idArmazem, p_idlocaldestino,
                                     p_iddepositante, p_idproduto, 1);
    end if;
  
    for c_lote in (select ll.idlote, (ll.estoque - ll.pendencia) permitido,
                          (ll.estoque + ll.adicionar) total
                     from lotelocal ll, lote lt
                    where ll.idlocal = p_idlocalorigem
                      and ll.idarmazem = p_idArmazem
                      and (ll.estoque > 0 or ll.pendencia > 0 or
                          ll.adicionar > 0)
                      and lt.idlote = ll.idlote
                      and lt.idproduto = p_idproduto
                      and lt.iddepositante = p_iddepositante)
    loop
      if (p_transfPendenciaAdicionar = 1) then
        v_qtdelr := c_lote.total;
      else
        if (c_lote.permitido > 0) then
          v_qtdelr := c_lote.permitido;
        else
          v_qtdelr := 0;
        end if;
      end if;
    
      if (v_qtdelr > 0) then
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde)
        values
          (p_idremanejamento, c_lote.idlote, v_qtdelr, 'S', 'S');
      end if;
    end loop;
  end criarRemMudancaPicking;

  -- Refactored procedure moverEstoqueMudPicking 
  procedure moverEstoqueMudPicking
  (
    p_idusuario                in number,
    p_idArmazem                in number,
    p_idlocalorigem            in local.idlocal%type,
    p_idlocaldestino           in local.idlocal%type,
    v_transfPendenciaAdicionar in out number,
    v_idremanejamento          in out number
  ) is
    v_qtdemover number;
  begin
    for c_estoque in (select ll.idlote, ll.estoque, ll.pendencia,
                             ll.adicionar, lo.tipo tipoLocalOrigem,
                             lo.buffer bufferOrigem, lt.idproduto,
                             lt.iddepositante
                        from lotelocal ll, local lo, lote lt
                       where ll.idlocal = p_idlocalorigem
                         and ll.idarmazem = p_idarmazem
                         and lo.idlocal = ll.idlocal
                         and lo.idarmazem = ll.idarmazem
                         and lt.idlote = ll.idlote
                         and exists
                       (select 1
                                from loteremanejamento lr
                               where lr.idremanejamento = v_idremanejamento
                                 and lr.idlote = ll.idlote)
                       order by ll.idlote)
    loop
      if (v_transfPendenciaAdicionar = 0) then
        v_qtdemover := c_estoque.estoque - c_estoque.pendencia;
        if (v_qtdemover > 0) then
          pk_estoque.retirar_estoque(p_idArmazem, p_idlocalorigem,
                                     c_estoque.idlote, v_qtdemover,
                                     p_idusuario,
                                     'RETIRADO ESTOQUE REFERENTE MUDANCA DE PICKING ID: ' ||
                                      v_idremanejamento, 'N');
        
          if ((c_estoque.tipolocalorigem = 0) AND
             (c_estoque.bufferorigem = 'N')) then
            pk_picking_dinamico.addGttPickingDinamico(c_estoque.idproduto,
                                                      c_estoque.iddepositante,
                                                      p_idlocalorigem,
                                                      p_idArmazem, 0);
          end if;
          pk_picking_dinamico.addGttPickingDinamico(c_estoque.idproduto,
                                                    c_estoque.iddepositante,
                                                    p_idlocaldestino,
                                                    p_idArmazem, 1);
        
          pk_estoque.incluir_estoque(p_idArmazem, p_idlocaldestino,
                                     c_estoque.idlote, v_qtdemover,
                                     p_idusuario,
                                     'ADICIONADO ESTOQUE REFERENTE MUDANCA DE PICKING ID: ' ||
                                      v_idremanejamento, 'N');
        end if;
      else
        if (c_estoque.pendencia > 0) then
          pk_estoque.retirar_pendencia(p_idArmazem, p_idlocalorigem,
                                       c_estoque.idlote, c_estoque.pendencia,
                                       p_idusuario,
                                       'RETIRADA PENDENCIA REFERENTE MUDANCA DE PICKING ID: ' ||
                                        v_idremanejamento);
        end if;
      
        if (c_estoque.estoque > 0) then
          pk_estoque.retirar_estoque(p_idArmazem, p_idlocalorigem,
                                     c_estoque.idlote, c_estoque.estoque,
                                     p_idusuario,
                                     'RETIRADO ESTOQUE REFERENTE MUDANCA DE PICKING ID: ' ||
                                      v_idremanejamento, 'N');
        
          if ((c_estoque.tipolocalorigem = 0) AND
             (c_estoque.bufferorigem = 'N')) then
            pk_picking_dinamico.addGttPickingDinamico(c_estoque.idproduto,
                                                      c_estoque.iddepositante,
                                                      p_idlocalorigem,
                                                      p_idArmazem, 0);
          end if;
        
          pk_picking_dinamico.addGttPickingDinamico(c_estoque.idproduto,
                                                    c_estoque.iddepositante,
                                                    p_idlocaldestino,
                                                    p_idArmazem, 1);
          pk_estoque.incluir_estoque(p_idArmazem, p_idlocaldestino,
                                     c_estoque.idlote, c_estoque.estoque,
                                     p_idusuario,
                                     'ADICIONADO ESTOQUE REFERENTE MUDANCA DE PICKING ID: ' ||
                                      v_idremanejamento, 'N');
        end if;
      
        if (c_estoque.adicionar > 0) then
          pk_estoque.retirar_adicionar(p_idArmazem, p_idlocalorigem,
                                       c_estoque.idlote, c_estoque.adicionar,
                                       p_idusuario,
                                       'RETIRADO ADICIONAR REFERENTE MUDANCA DE PICKING ID: ' ||
                                        v_idremanejamento);
          pk_estoque.incluir_adicionar(p_idArmazem, p_idlocaldestino,
                                       c_estoque.idlote, c_estoque.adicionar,
                                       p_idusuario,
                                       'INCLUIDO ADICIONAR REFERENTE MUDANCA DE PICKING ID: ' ||
                                        v_idremanejamento);
        end if;
      
        if (c_estoque.pendencia > 0) then
          pk_estoque.incluir_pendencia(p_idArmazem, p_idlocaldestino,
                                       c_estoque.idlote, c_estoque.pendencia,
                                       p_idusuario,
                                       'ADICIONADA PENDENCIA REFERENTE MUDANCA DE PICKING ID: ' ||
                                        v_idremanejamento);
        end if;
      end if;
    end loop;
    pk_picking_dinamico.deletar_picking_dinamico;
    pk_picking_dinamico.inserir_picking_dinamico;
  end moverEstoqueMudPicking;

  -- Refactored procedure alterarRemMudPicking 
  procedure alterarRemMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idarmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
    v_totallr      number;
    v_totaltitulos number;
    v_idnovorem    number;
    v_tiporem      number;
    v_tiponovorem  number;
  begin
    for c_rem in (select r.idremanejamento, r.idlocaldestino, lr.idlote,
                         r.idromaneio, lr.qtde, r.idlocalorigem,
                         lr.controlaqtde, r.tipo
                    from remanejamento r, loteremanejamento lr, lote lt
                   where r.status <> 'F'
                     and r.tipo <> 3
                     and ((r.idarmazemorigem = p_idarmazem and
                         r.idlocalorigem = p_idlocalOrigem) or
                         (r.idarmazemdestino = p_idarmazem and
                         r.idlocaldestino = p_idlocalorigem))
                     and lr.idremanejamento = r.idremanejamento
                     and lt.idlote = lr.idlote
                     and lt.idproduto = p_idproduto
                     and lt.iddepositante = p_iddepositante)
    loop
      select r.tipo
        into v_tiporem
        from remanejamento r
       where r.idremanejamento = c_rem.idremanejamento;
    
      update remanejamento r
         set r.tipo = 3
       where r.idremanejamento = c_rem.idremanejamento;
    
      -- Se a origem do remanejamento é a mesma origem da mudança de picking
      -- o endenreco de origem do remanejamento deve apontar para o destino
      -- da mudança de picking     
      if (c_rem.idlocalorigem = p_idlocalorigem) then
        -- se o destino do remanejamento é o destino da mudança de picking
        -- o estoque esta sendo movido pela mudança de picking
        -- e não é necessario a existencia deste remanejamento
        -- portanto a pendencia e adcionar serão removidos
        -- do endereço de destino, pois a mudança de picking ja
        -- moveu o estoque.
        if (c_rem.idlocaldestino = p_idlocaldestino) then
          pk_utilities.GeraLog(p_idusuario,
                               'MUDANÇA DE PICKING ID ' ||
                                p_idremanejamento ||
                                ' ALTEROU REMANEJAMENTO ' ||
                                c_rem.idremanejamento || ', LOTE ' ||
                                c_rem.idlote || ' FOI REMOVIDO',
                               p_idremanejamento, 'MP');
        
          delete from loteremanejamento lr
           where lr.idremanejamento = c_rem.idremanejamento
             and lr.idlote = c_rem.idlote;
        
          if c_rem.controlaqtde = 'S' then
            update remanejamento
               set qtde = nvl(qtde, 0) - c_rem.qtde
             where idremanejamento = c_rem.idremanejamento;
          end if;
        
          pk_estoque.retirar_pendencia(p_idArmazem, p_idlocaldestino,
                                       c_rem.idlote, c_rem.qtde, p_idusuario,
                                       'RETIRADA PENDENCIA REFERENTE MUDANCA DE PICKING ID: ' ||
                                        p_idremanejamento);
        
          pk_estoque.retirar_adicionar(p_idArmazem, p_idlocaldestino,
                                       c_rem.idlote, c_rem.qtde, p_idusuario,
                                       'RETIRADO ADICIONAR REFERENTE MUDANCA DE PICKING ID: ' ||
                                        p_idremanejamento);
        
          select count(*)
            into v_totallr
            from loteremanejamento lr
           where lr.idremanejamento = c_rem.idremanejamento;
        
          if (v_totallr = 0) then
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento || '. REMANEJAMENTO ' ||
                                  c_rem.idremanejamento ||
                                  ' EXCLUIDO DEVIDO NÃO POSSUIR MAIS NENHUM LOTE.',
                                 p_idremanejamento, 'MP');
          
            delete from remanejamento r
             where r.idremanejamento = c_rem.idremanejamento;
          end if;
          -- caso o local de destino do remanejamento seja diferente 
          -- do local de destino da mudança de picking
          -- somente o endereço de origem do remanejamento
          -- será trocado
        else
          select count(distinct lt.idproduto)
            into v_totaltitulos
            from loteremanejamento lr, lote lt
           where lr.idremanejamento = c_rem.idremanejamento
             and lt.idlote = lr.idlote;
        
          -- se o remanejamento possui apenas lotes do produto que
          -- participa da mudança de picking, apenas o local do 
          -- remanejamento é trocado
          if (v_totaltitulos = 1) then
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento ||
                                  ' ALTEROU REMANEJAMENTO ' ||
                                  c_rem.idremanejamento ||
                                  '. LOCAL DE ORIGEM TROCADO. ORIGEM ANTERIOR ' ||
                                  c_rem.idlocalorigem || ', NOVA ORIGEM ' ||
                                  p_idlocaldestino, p_idremanejamento, 'MP');
          
            update remanejamento r
               set r.idlocalorigem = p_idlocaldestino
             where r.idremanejamento = c_rem.idremanejamento;
            -- se o remanejamento possui lotes de outros produtos,
            -- será necessario retirar os lotes do produto que participa
            -- da mudança de picking e gerar um novo remanejamento
            -- para mover o estoque corretamente. A pendencia do primeiro remanejamento 
            -- não será removida, devido a mudança de picking ja 
            -- ter movido a pendencia para o local de destino,
            -- onde o novo remanejamento irá utilizar esta pendencia
          else
            delete from loteremanejamento lr
             where lr.idremanejamento = c_rem.idremanejamento
               and lr.idlote = c_rem.idlote;
          
            if c_rem.controlaqtde = 'S' then
              update remanejamento
                 set qtde = nvl(qtde, 0) - c_rem.qtde
               where idremanejamento = c_rem.idremanejamento;
            end if;
          
            v_idnovorem := cadastrar_remanejamento(p_idarmazem, p_idarmazem,
                                                   p_idlocaldestino,
                                                   c_rem.idlocaldestino,
                                                   p_idusuario,
                                                   c_rem.idromaneio,
                                                   'REMANEJAMENTO CRIADO DEVIDO A MUDANCA DE PICKING ID: ' ||
                                                    p_idremanejamento, 'N',
                                                   'N');
          
            select r.tipo
              into v_tiponovorem
              from remanejamento r
             where r.idremanejamento = v_idnovorem;
          
            update remanejamento r
               set r.tipo = 3
             where r.idremanejamento = v_idnovorem;
          
            begin
              insert into loteremanejamento
                (idremanejamento, idlote, qtde, conferido, controlaqtde)
              values
                (v_idnovorem, c_rem.idlote, c_rem.qtde, 'N', 'S');
            exception
              when dup_val_on_index then
                update loteremanejamento lr
                   set lr.qtde = lr.qtde + c_rem.qtde
                 where lr.idremanejamento = v_idnovorem
                   and lr.idlote = c_rem.idlote;
            end;
          
            update remanejamento r
               set r.tipo = v_tiponovorem,
                   r.qtde = decode(c_rem.controlaqtde, 'S',
                                   nvl(r.qtde, 0) - c_rem.qtde, r.qtde)
             where r.idremanejamento = v_idnovorem;
          
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento ||
                                  ' ALTEROU O REMANEJAMENTO ' ||
                                  c_rem.idremanejamento || '. LOTE ' ||
                                  c_rem.idlote ||
                                  ' FOI REMOVIDO E ADICIONADO NO REMANEJAMENTO ' ||
                                  v_idnovorem, p_idremanejamento, 'MP');
          end if;
        end if;
        -- se o destino do remanejamento é igual a origem da mudança
        -- de picking, o destino do remanejamento deverá ser trocado para
        -- o destino da mudança de picking
      else
        -- se a origem do remanejamento é igual ao destino da mudança de 
        -- picking, o estoque não deve ser movido, pois a mudança de picking
        -- esta determinando a nova posição do estoque, e este remanejamento
        -- não deve mais existir
        if (c_rem.idlocalorigem = p_idlocaldestino) then
          pk_utilities.GeraLog(p_idusuario,
                               'MUDANÇA DE PICKING ID ' ||
                                p_idremanejamento ||
                                ' ALTEROU REMANEJAMENTO ' ||
                                c_rem.idremanejamento || ', LOTE ' ||
                                c_rem.idlote || ' FOI REMOVIDO',
                               p_idremanejamento, 'MP');
        
          delete from loteremanejamento lr
           where lr.idremanejamento = c_rem.idremanejamento
             and lr.idlote = c_rem.idlote;
        
          if c_rem.controlaqtde = 'S' then
            update remanejamento
               set qtde = nvl(qtde, 0) - c_rem.qtde
             where idremanejamento = c_rem.idremanejamento;
          end if;
        
          pk_estoque.retirar_pendencia(p_idArmazem, p_idlocaldestino,
                                       c_rem.idlote, c_rem.qtde, p_idusuario,
                                       'RETIRADA PENDENCIA REFERENTE MUDANCA DE PICKING ID: ' ||
                                        p_idremanejamento);
        
          pk_estoque.retirar_adicionar(p_idArmazem, p_idlocaldestino,
                                       c_rem.idlote, c_rem.qtde, p_idusuario,
                                       'RETIRADO ADICIONAR REFERENTE MUDANCA DE PICKING ID: ' ||
                                        p_idremanejamento);
        
          select count(*)
            into v_totallr
            from loteremanejamento lr
           where lr.idremanejamento = c_rem.idremanejamento;
        
          if (v_totallr = 0) then
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento || '. REMANEJAMENTO ' ||
                                  c_rem.idremanejamento ||
                                  ' EXCLUIDO DEVIDO NÃO POSSUIR MAIS NENHUM LOTE.',
                                 p_idremanejamento, 'MP');
          
            delete from remanejamento r
             where r.idremanejamento = c_rem.idremanejamento;
          end if;
          -- se a origem do remanejamento não é o destino da mudanca de picking,
          -- o destino do remanejamento deverá ser o mesmo destino da mudança de picking
        else
          select count(distinct lt.idproduto)
            into v_totaltitulos
            from loteremanejamento lr, lote lt
           where lr.idremanejamento = c_rem.idremanejamento
             and lt.idlote = lr.idlote;
        
          if (v_totaltitulos = 1) then
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento ||
                                  ' ALTEROU REMANEJAMENTO ' ||
                                  c_rem.idremanejamento ||
                                  '. LOCAL DE DESTINO TROCADO. DESTINO ANTERIOR ' ||
                                  c_rem.idlocaldestino || ', NOVO DESTINO ' ||
                                  p_idlocaldestino, p_idremanejamento, 'MP');
          
            update remanejamento r
               set r.idlocaldestino = p_idlocaldestino
             where r.idremanejamento = c_rem.idremanejamento;
            -- se o remanejamento possuir lotes de outros produtos,
            -- deverá ser criado um novo remanejamento para mover
            -- somente os lotes do produto que participa da mudança 
            -- de picking
          else
            delete from loteremanejamento lr
             where lr.idremanejamento = c_rem.idremanejamento
               and lr.idlote = c_rem.idlote;
          
            if c_rem.controlaqtde = 'S' then
              update remanejamento
                 set qtde = nvl(qtde, 0) - c_rem.qtde
               where idremanejamento = c_rem.idremanejamento;
            end if;
          
            v_idnovorem := cadastrar_remanejamento(p_idarmazem, p_idarmazem,
                                                   c_rem.idlocalorigem,
                                                   p_idlocaldestino,
                                                   p_idusuario,
                                                   c_rem.idromaneio,
                                                   'REMANEJAMENTO CRIADO DEVIDO A MUDANCA DE PICKING ID: ' ||
                                                    p_idremanejamento, 'N',
                                                   'N');
          
            select r.tipo
              into v_tiponovorem
              from remanejamento r
             where r.idremanejamento = v_idnovorem;
          
            update remanejamento r
               set r.tipo = 3
             where r.idremanejamento = v_idnovorem;
          
            begin
              insert into loteremanejamento
                (idremanejamento, idlote, qtde, conferido, controlaqtde)
              values
                (v_idnovorem, c_rem.idlote, c_rem.qtde, 'N', 'S');
            exception
              when dup_val_on_index then
                update loteremanejamento lr
                   set lr.qtde = lr.qtde + c_rem.qtde
                 where lr.idremanejamento = v_idnovorem
                   and lr.idlote = c_rem.idlote;
            end;
          
            update remanejamento r
               set r.tipo = v_tiponovorem,
                   r.qtde = decode(c_rem.controlaqtde, 'S',
                                   nvl(r.qtde, 0) - c_rem.qtde, r.qtde)
             where r.idremanejamento = v_idnovorem;
          
            pk_utilities.GeraLog(p_idusuario,
                                 'MUDANÇA DE PICKING ID ' ||
                                  p_idremanejamento ||
                                  ' ALTEROU O REMANEJAMENTO ' ||
                                  c_rem.idremanejamento || '. LOTE ' ||
                                  c_rem.idlote ||
                                  ' FOI REMOVIDO E ADICIONADO NO REMANEJAMENTO ' ||
                                  v_idnovorem, p_idremanejamento, 'MP');
          end if;
        end if;
      end if;
    
      update remanejamento r
         set r.tipo = v_tiporem
       where r.idremanejamento = c_rem.idremanejamento;
    end loop;
  end alterarRemMudPicking;

  procedure alterarAjusteMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
    v_idajuste number;
  begin
    v_idajuste := 0;
    for c_aje in (select ae.idajustemovtoentrada, ae.idajustemovto
                    from ajustemovto ajm, ajustemovtoentrada ae
                   where ajm.gerado = 'N'
                     and ajm.identidade = p_iddepositante
                     and ae.idajustemovto = ajm.idajustemovto
                     and ae.idarmazem = p_idarmazem
                     and ae.idlocal = p_idlocalorigem
                     and ae.idproduto = p_idproduto)
    loop
      update ajustemovtoentrada a
         set a.idlocal = p_idlocaldestino
       where a.idajustemovtoentrada = c_aje.idajustemovtoentrada;
    
      if (v_idajuste <> c_aje.idajustemovto) then
        v_idajuste := c_aje.idajustemovto;
      
        pk_utilities.GeraLog(p_idusuario,
                             'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                              ' ALTEROU O AJUSTE DE ENTRADA ' ||
                              c_aje.idajustemovto ||
                              '. ENDEREÇO TROCADO. ENDEREÇO ANTERIOR' ||
                              p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                              p_idlocaldestino, p_idremanejamento, 'MP');
      end if;
    end loop;
  
    v_idajuste := 0;
    pk_triggers_control.disableTrigger('t_before_ajustemovtosaida');
    for c_ajs in (select ajs.idarmazem, ajs.idlocal, ajs.idlote,
                         ajs.idajustemovto
                    from ajustemovto ajm, ajustemovtosaida ajs, lote lt
                   where ajm.gerado = 'N'
                     and ajm.identidade = p_iddepositante
                     and ajs.idajustemovto = ajm.idajustemovto
                     and ajs.idarmazem = p_idarmazem
                     and ajs.idlocal = p_idlocalorigem
                     and lt.idlote = ajs.idlote
                     and lt.idproduto = p_idproduto)
    loop
      update ajustemovtosaida a
         set a.idlocal = p_idlocaldestino
       where a.idarmazem = c_ajs.idarmazem
         and a.idlocal = c_ajs.idlocal
         and a.idlote = c_ajs.idlote
         and a.idajustemovto = c_ajs.idajustemovto;
    
      if (v_idajuste <> c_ajs.idajustemovto) then
        v_idajuste := c_ajs.idajustemovto;
      
        pk_utilities.GeraLog(p_idusuario,
                             'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                              ' ALTEROU O AJUSTE DE SAIDA ' ||
                              c_ajs.idajustemovto ||
                              '. ENDEREÇO TROCADO. ENDEREÇO ANTERIOR' ||
                              p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                              p_idlocaldestino, p_idremanejamento, 'MP');
      end if;
    end loop;
    pk_triggers_control.enableTrigger('t_before_ajustemovtosaida');
  end;

  procedure alterarRomaneioMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
    v_paletsepjaexiste number;
  begin
    delete from gtt_selecao;
    for c_lote in (select ps.idarmazem, ps.idlocal, ps.idlote, ps.idproduto,
                          ps.idromaneio, ps.idpalet, ps.barra, ps.qtde,
                          ps.qtdeunit
                     from romaneiopai r, paletseparacao ps, lote lt
                    where r.tipo = 0
                      and r.processado = 'N'
                      and ps.idromaneio = r.idromaneio
                      and ps.idarmazem = p_idArmazem
                      and ps.idlocal = p_idlocalorigem
                      and ps.idproduto = p_idproduto
                      and lt.idlote = ps.idlote
                      and lt.iddepositante = p_iddepositante)
    loop
      insert into gtt_selecao
        (idselecionado)
      values
        (c_lote.idromaneio);
    
      select count(*)
        into v_paletsepjaexiste
        from paletseparacao ps
       where ps.idarmazem = c_lote.idarmazem
         and ps.idlocal = p_idlocaldestino
         and ps.idlote = c_lote.idlote
         and ps.idproduto = c_lote.idproduto
         and ps.idromaneio = c_lote.idromaneio
         and ps.idpalet = c_lote.idpalet
         and ps.barra = c_lote.barra;
    
      if (v_paletsepjaexiste = 0) then
        update paletseparacao ps
           set ps.idlocal = p_idlocaldestino
         where ps.idarmazem = c_lote.idarmazem
           and ps.idlocal = c_lote.idlocal
           and ps.idlote = c_lote.idlote
           and ps.idproduto = c_lote.idproduto
           and ps.idromaneio = c_lote.idromaneio
           and ps.idpalet = c_lote.idpalet
           and ps.barra = c_lote.barra;
      
        pk_utilities.GeraLog(p_idusuario,
                             'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                              ' ALTEROU ROMANEIO ' || c_lote.idromaneio ||
                              '. ENDEREÇO DO PALETSEPARACAO (idarmazem ' ||
                              c_lote.idarmazem || ', idlocal ' ||
                              c_lote.Idlocal || ', idlote ' || c_lote.idlote ||
                              ', idproduto ' || c_lote.idproduto ||
                              ', idromaneio ' || c_lote.idromaneio ||
                              ', idpalet ' || c_lote.idpalet || ', barra ' ||
                              c_lote.barra ||
                              ') TROCADO. ENDEREÇO ANTERIOR ' ||
                              c_lote.idlocal || ', NOVO ENDEREÇO ' ||
                              p_idlocaldestino, p_idremanejamento, 'MP');
      else
        update paletseparacao ps
           set ps.qtde     = ps.qtde + c_lote.qtde,
               ps.qtdeunit = ps.qtdeunit + c_lote.qtdeunit
         where ps.idarmazem = c_lote.idarmazem
           and ps.idlocal = p_idlocaldestino
           and ps.idlote = c_lote.idlote
           and ps.idproduto = c_lote.idproduto
           and ps.idromaneio = c_lote.idromaneio
           and ps.idpalet = c_lote.idpalet
           and ps.barra = c_lote.barra;
      
        delete from paletseparacao ps
         where ps.idarmazem = c_lote.idarmazem
           and ps.idlocal = c_lote.idlocal
           and ps.idlote = c_lote.idlote
           and ps.idproduto = c_lote.idproduto
           and ps.idromaneio = c_lote.idromaneio
           and ps.idpalet = c_lote.idpalet
           and ps.barra = c_lote.barra;
      
        pk_utilities.GeraLog(p_idusuario,
                             'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                              ' ALTEROU O ROMANEIO ' || c_lote.idromaneio ||
                              '. QUANTIDADE DO PRODUTO NO PALETSEPARACAO (idarmazem ' ||
                              c_lote.idarmazem || ', idlocal ' ||
                              c_lote.Idlocal || ', idlote ' || c_lote.idlote ||
                              ', idproduto ' || c_lote.idproduto ||
                              ', idromaneio ' || c_lote.idromaneio ||
                              ', idpalet ' || c_lote.idpalet || ', barra ' ||
                              c_lote.barra ||
                              ') MOVIDA PARA O PALETSEPARACAO EXISTENTE (idarmazem ' ||
                              c_lote.idarmazem || ', idlocal ' ||
                              p_idlocaldestino || ', idlote ' ||
                              c_lote.idlote || ', idproduto ' ||
                              c_lote.idproduto || ', idromaneio ' ||
                              c_lote.idromaneio || ', idpalet ' ||
                              c_lote.idpalet || ', barra ' || c_lote.barra || ')' ||
                              '. QTDEUNIT AUMENTADA ' || c_lote.Qtdeunit ||
                              ', QTDE AUMENTADA ' || c_lote.qtde,
                             p_idremanejamento, 'MP');
      end if;
    end loop;
  
    for c_rom in (select distinct idselecionado
                    from gtt_selecao)
    loop
      pk_romaneio.RecalculaPaletSepCliente(c_rom.idselecionado);
      pk_romaneio.identificarlotes(c_rom.idselecionado);
    end loop;
  
    delete from gtt_selecao;
  
  end;

  procedure alterarAlocacaoMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
  begin
    for c_mapa in (select m.idalocacao
                     from mapaalocacao m, lote lt
                    where m.status <> 'F'
                      and m.idarmazem = p_idArmazem
                      and m.idlocal = p_idlocalorigem
                      and lt.idlote = m.idlote
                      and lt.idproduto = p_idproduto
                      and lt.iddepositante = p_iddepositante)
    loop
      update mapaalocacao
         set idlocal = p_idlocaldestino
       where idalocacao = c_mapa.idalocacao;
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU O MAPA DE ALOCACAO ' ||
                            c_mapa.Idalocacao ||
                            '. ENDEREÇO TROCADO. ENDEREÇO ANTERIOR ' ||
                            p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  
  end;

  procedure alterarOndaMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
    v_movanterior     number;
    v_idlocalanterior local.idlocal%type;
    v_idnovolocal     number;
  begin
    select id
      into v_idnovolocal
      from local
     where idarmazem = p_idArmazem
       and idlocal = p_idlocaldestino;
  
    for c_mov in (select m.idonda, m.id, lt.idlote, lo.idlocal,
                         m.qtdemovimentada, m.etapa, m.idlocalorigem
                    from movimentacao m, local lo, lote lt
                   where m.status in (0, 1)
                     and lo.id = m.idlocalorigem
                     and lo.idarmazem = p_idArmazem
                     and lo.idlocal = p_idlocalorigem
                     and lt.idlote = m.idlote
                     and lt.idproduto = p_idproduto
                     and lt.iddepositante = p_iddepositante)
    loop
      begin
        select m.id
          into v_movanterior
          from grupomovimentacao g, movimentacao m
         where g.idgrupo = c_mov.id
           and m.id = g.idmovimentacao
           and m.etapa < c_mov.etapa
           and m.idlocaldestino = c_mov.idlocal
           and m.status in (0, 1);
      exception
        when no_data_found then
          v_movanterior := 0;
      end;
    
      if (v_movanterior > 0) then
        select ld.idlocal
          into v_idlocalanterior
          from movimentacao m, local ld
         where m.id = v_movanterior
           and ld.id = m.idlocaldestino;
      
        update movimentacao m
           set m.idlocaldestino = v_idnovolocal
         where m.id = v_movanterior;
      
        pk_utilities.GeraLog(p_idusuario,
                             'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                              ' ALTEROU ONDA ' || c_mov.idonda ||
                              ', MOVIMENTACAO ID ' || v_movanterior ||
                              '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                              v_idlocalanterior || ', NOVO ENDEREÇO ' ||
                              p_idlocaldestino, p_idremanejamento, 'MP');
      end if;
    
      update movimentacao m
         set m.idlocalorigem = v_idnovolocal
       where m.id = c_mov.id;
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU ONDA ' || c_mov.idonda ||
                            ', MOVIMENTACAO ID ' || c_mov.id ||
                            '. ENDEREÇO DE ORIGEM ANTERIOR ' ||
                            c_mov.idlocal || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  
    for c_mov in (select m.idonda, m.id, lt.idlote, ld.idlocal,
                         m.qtdemovimentada, m.etapa, m.idlocalorigem
                    from movimentacao m, local ld, lote lt
                   where m.status in (0, 1)
                     and ld.id = m.idlocaldestino
                     and ld.idarmazem = p_idArmazem
                     and ld.idlocal = p_idlocalorigem
                     and lt.idlote = m.idlote
                     and lt.idproduto = p_idproduto
                     and lt.iddepositante = p_iddepositante)
    loop
      update movimentacao m
         set m.idlocaldestino = v_idnovolocal
       where m.id = c_mov.id;
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU ONDA ' || c_mov.idonda ||
                            ', MOVIMENTACAO ID ' || c_mov.id ||
                            '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                            c_mov.idlocal || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  end;

  procedure alterarCorteFisicoMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
    v_idnovolocal number;
  begin
    select id
      into v_idnovolocal
      from local
     where idarmazem = p_idArmazem
       and idlocal = p_idlocaldestino;
  
    for c_corte in (select c.id idcorte
                      from cortefisico c, local lo
                     where c.status = 0
                       and c.idproduto = p_idproduto
                       and lo.id = c.idenderecofalta
                       and lo.idarmazem = p_idArmazem
                       and lo.idlocal = p_idlocalorigem
                       and exists
                     (select 1
                              from cortefisiconf cnf, notafiscal nf
                             where cnf.idcortefisico = c.id
                               and cnf.qtdeseparacao <> cnf.qtdeutilizada
                               and nf.idnotafiscal = cnf.idnotafiscal
                               and nf.iddepositante = p_iddepositante))
    loop
      update cortefisico c
         set c.idenderecofalta = v_idnovolocal
       where c.id = c_corte.idcorte;
    
      update movimentacao m
         set m.idlocalorigem = v_idnovolocal
       where exists (select 1
                from cortefisiconf cnf, resestoquecortefisiconf r
               where cnf.idcortefisico = c_corte.idcorte
                 and cnf.qtdeseparacao <> cnf.qtdeutilizada
                 and r.idcortefisiconf = cnf.id
                 and r.idmovimentacaoafetada = m.id);
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU CORTE FÍSICO ID ' || c_corte.idcorte ||
                            '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                            p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  
    -- Atualizar local de corte para os cortes de separação e conferência da carga
    for c_cortesep in (select c.id idcorte
                         from cortefisico c, local lo, lote lt, lotelocal ll
                        where c.status = 0
                          and c.idproduto = p_idproduto
                          and ll.idarmazem = lo.idarmazem
                          and ll.idlocal = lo.idlocal
                          and ll.idlote = lt.idlote
                          and lt.idproduto = c.idproduto
                          and lt.iddepositante = p_iddepositante
                          and lo.id = c.idenderecofalta
                          and lo.idarmazem = p_idArmazem
                          and lo.idlocal = p_idlocalorigem
                          and (c.idconfexpedicaocarga is not null or exists
                               (select 1
                                  from separacaoporcarga s
                                 where s.idcortefisico = c.id)))
    loop
      update cortefisico c
         set c.idenderecofalta = v_idnovolocal
       where c.id = c_cortesep.idcorte;
    
      update separacaoporcarga
         set idlocal = p_idlocaldestino
       where idcortefisico = c_cortesep.idcorte;
    
      update paleteondanf pn
         set pn.idlocal = p_idlocaldestino
       where exists (select 1
                from separacaoporcarga s, paleteondanf p,
                     reservaestoqueondacarga r
               where r.idpaleteondanf = pn.idpaleteondanf
                 and r.idpaleteondanf = p.idpaleteondanf
                 and r.idseparacaoporcarga = s.idseparacaoporcarga
                 and s.idcortefisico = c_cortesep.idcorte);
    
      update reservaestoqueondacarga re
         set re.idlocal = p_idlocaldestino
       where exists (select 1
                from separacaoporcarga s, paleteondanf p,
                     reservaestoqueondacarga r
               where r.idseparacaoporcarga = re.idseparacaoporcarga
                 and r.idpaleteondanf = p.idpaleteondanf
                 and r.idseparacaoporcarga = s.idseparacaoporcarga
                 and s.idcortefisico = c_cortesep.idcorte);
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU CORTE FÍSICO ID ' ||
                            c_cortesep.idcorte ||
                            '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                            p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  end;

  procedure alteraratividadesMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
  
    procedure deletarAtividadeInutilizada(p_codonda in number) is
    begin
      delete from atividade a
       where a.idtipoatividade = 9
         and a.idoperacao = to_char(p_codonda)
         and status <> 'F'
         and exists
       (select 1
                from romaneiopai rp, movimentacao m, local lo,
                     regiaoarmazenagem ro, local ld, regiaoarmazenagem rd,
                     tipoatividadearmazem ta
               where rp.idromaneio = a.idoperacao
                 and lo.idregiao = a.idregiaoorigem
                 and lo.buffer = a.bufferorigem
                 and ld.idregiao = a.idregiaodestino
                 and ld.buffer = a.bufferdestino
                 and m.idonda = rp.idromaneio
                 and lo.id = m.idlocalorigem
                 and ro.idregiao = lo.idregiao
                 and ld.id = m.idlocaldestino
                 and rd.idregiao = ld.idregiao
                 and ta.idarmazem = lo.idarmazem
                 and ta.idtipoatividade = 9 -- tipo separação por onda
                 and m.status in (0, 1)
                 and not (m.qtdemovimentada - m.qtdeconferida = 0 and
                      m.status = 2)
                 and (ld.idregiao not in
                     (select idregiao
                         from regiaoarmazenagem
                        where tipo = decode(ro.tipo, 7, null, 3)) or
                     (lo.buffer = 'N' and ld.buffer = 'N' and
                     ro.tipo in (0, 1) and rd.tipo = 3))
                 and not
                      (lo.buffer = 'S' and
                      lo.idregiao in (select idregiao
                                         from regiaoarmazenagem
                                        where tipo = 2) and ld.buffer = 'N' and
                      ld.idregiao in (select idregiao
                                         from regiaoarmazenagem
                                        where tipo = 2))
                 and not
                      (lo.buffer = 'N' and m.status = 1 and
                      lo.idregiao in (select idregiao
                                         from regiaoarmazenagem
                                        where tipo = 0) and ld.buffer = 'N' and
                      ld.idregiao in (select idregiao
                                         from regiaoarmazenagem
                                        where tipo = 2)));
    end;
  
  begin
    for c_onda in (select o.idromaneio idonda, o.codigointerno codonda,
                          o.tituloromaneio titulo, o.idconfiguracaoonda
                     from romaneiopai o
                    where 1 = 1
                      and exists
                    (select 1
                             from movimentacao m, local lo, local ld
                            where 1 = 1
                              and lo.id = m.idlocalorigem
                              and ld.id = m.idlocaldestino
                              and m.idonda = o.idromaneio
                              and m.status in (0, 1)
                              and ((ld.idlocal = p_idlocaldestino and
                                  ld.idarmazem = p_idArmazem) or
                                  (lo.idlocal = p_idlocaldestino and
                                  lo.idarmazem = p_idArmazem)))
                      and o.statusonda in (2, 4)
                      and o.tipo = 1
                    group by o.idromaneio, o.codigointerno, o.tituloromaneio,
                             o.idconfiguracaoonda)
    loop
      deletarAtividadeInutilizada(c_onda.codonda);
    
      pk_convocacao.insereSeparacaoOnda(p_idusuario, c_onda.idonda,
                                        c_onda.codonda, p_idArmazem,
                                        c_onda.idconfiguracaoonda,
                                        c_onda.titulo || ' - Onda');
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU ATIVIDADE DE CONVOCAÇÃO ATIVA PARA O IDONDA: ' ||
                            c_onda.idonda ||
                            '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                            p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  end;

  procedure alterarOndaCargaMudPicking
  (
    p_idusuario       in number,
    p_iddepositante   in number,
    p_idproduto       in number,
    p_idArmazem       in number,
    p_idlocalorigem   in local.idlocal%type,
    p_idlocaldestino  in local.idlocal%type,
    p_idremanejamento in number
  ) is
  begin
    for c_carga in (select re.idonda, re.idseparacaoporcarga,
                           re.idpaleteondanf
                      from separacaoporcarga sc, paleteondanf pf,
                           reservaestoqueondacarga re, lote lt
                     where lt.idproduto = p_idproduto
                       and lt.iddepositante = p_iddepositante
                       and lt.idlote = re.idlote
                       and re.idlote = pf.idlote
                       and re.idpaleteondanf = pf.idpaleteondanf
                       and re.idseparacaoporcarga = sc.idseparacaoporcarga
                       and sc.idarmazem = p_idArmazem
                       and sc.idlocal = p_idlocalorigem
                       and sc.status in (0, 1))
    loop
      update separacaoporcarga
         set idlocal = p_idlocaldestino
       where idseparacaoporcarga = c_carga.idseparacaoporcarga;
    
      update paleteondanf
         set idlocal = p_idlocaldestino
       where idpaleteondanf = c_carga.idpaleteondanf;
    
      update reservaestoqueondacarga
         set idlocal = p_idlocaldestino
       where idseparacaoporcarga = c_carga.idseparacaoporcarga;
    
      pk_utilities.GeraLog(p_idusuario,
                           'MUDANÇA DE PICKING ID ' || p_idremanejamento ||
                            ' ALTEROU ONDA ' || c_carga.idonda ||
                            ', SEPARAÇÃO CARGA ID ' ||
                            c_carga.idseparacaoporcarga ||
                            '. ENDEREÇO DE DESTINO ANTERIOR ' ||
                            p_idlocalorigem || ', NOVO ENDEREÇO ' ||
                            p_idlocaldestino, p_idremanejamento, 'MP');
    end loop;
  end;

  procedure processarMudancaPicking
  (
    p_idusuario      in number,
    p_iddepositante  in number,
    p_idproduto      in number,
    p_idArmazem      in number,
    p_idlocalorigem  in local.idlocal%type,
    p_idlocaldestino in local.idlocal%type
  ) is
    v_transfPendenciaAdicionar number;
    v_mudarPickingVazio        number;
    v_idremanejamento          number;
    v_textolog                 varchar2(100);
    v_estoque                  number;
    v_pendencia                number;
    v_adicionar                number;
    v_msg                      t_message;
  
    procedure carregaDados is
    begin
    
      select a.transferirpendenciaeadicionar, a.mudarpickingvazio
        into v_transfPendenciaAdicionar, v_mudarPickingVazio
        from armazem a
       where a.idarmazem = p_idArmazem;
    
      if (v_transfPendenciaAdicionar = 1) then
        v_textolog := ' MUDANÇA DE PICKING MOVENDO ESTOQUE RESERVADO: ';
      else
        v_textolog := ' MUDANÇA DE PICKING: ';
      end if;
    end carregaDados;
  
    procedure validacoes is
    begin
    
      validarMudancaPicking(p_iddepositante, p_idproduto, p_idArmazem,
                            p_idlocalorigem, v_transfPendenciaAdicionar,
                            p_idlocaldestino, v_mudarPickingVazio);
    
    end validacoes;
  
    procedure iniciaMudancaDePicking is
    
      procedure gravaLog(p_etapa varchar2) is
      begin
        pk_utilities.GeraLog(p_idusuario,
                             p_etapa || v_textolog || v_idremanejamento ||
                              ', IDPRODUTO ' || p_idproduto ||
                              ', IDDEPOSITANTE ' || p_iddepositante ||
                              ', LOCAL ORIGEM ' || p_idlocalorigem ||
                              ', LOCAL DESTINO ' || p_idlocaldestino ||
                              ', REALIZADA PELO USUARIO ' || p_idusuario,
                             v_idremanejamento, 'MP');
      end gravaLog;
    
      procedure transferirPendenciaPicking is
      begin
        alterarAjusteMudPicking(p_idusuario, p_iddepositante, p_idproduto,
                                p_idArmazem, p_idlocalorigem,
                                p_idlocaldestino, v_idremanejamento);
      
        moverEstoqueMudPicking(p_idusuario, p_idArmazem, p_idlocalorigem,
                               p_idlocaldestino, v_transfPendenciaAdicionar,
                               v_idremanejamento);
      
        alterarRemMudPicking(p_idusuario, p_iddepositante, p_idproduto,
                             p_idArmazem, p_idlocalorigem, p_idlocaldestino,
                             v_idremanejamento);
      
        alterarRomaneioMudPicking(p_idusuario, p_iddepositante, p_idproduto,
                                  p_idArmazem, p_idlocalorigem,
                                  p_idlocaldestino, v_idremanejamento);
      
        alterarAlocacaoMudPicking(p_idusuario, p_iddepositante, p_idproduto,
                                  p_idArmazem, p_idlocalorigem,
                                  p_idlocaldestino, v_idremanejamento);
      
        alterarOndaMudPicking(p_idusuario, p_iddepositante, p_idproduto,
                              p_idArmazem, p_idlocalorigem, p_idlocaldestino,
                              v_idremanejamento);
      
        alterarCorteFisicoMudPicking(p_idusuario, p_iddepositante,
                                     p_idproduto, p_idArmazem,
                                     p_idlocalorigem, p_idlocaldestino,
                                     v_idremanejamento);
      
        alteraratividadesMudPicking(p_idusuario, p_iddepositante,
                                    p_idproduto, p_idArmazem,
                                    p_idlocalorigem, p_idlocaldestino,
                                    v_idremanejamento);
      
        alterarOndaCargaMudPicking(p_idusuario, p_iddepositante,
                                   p_idproduto, p_idArmazem, p_idlocalorigem,
                                   p_idlocaldestino, v_idremanejamento);
      end transferirPendenciaPicking;
    
      procedure alteraRemanejamentoGerado(p_idremanejamento number) is
      begin
      
        pk_triggers_control.disableTrigger('T_BEFORE_REMANEJAMENTO');
      
        update remanejamento r
           set r.planejado  = 'S',
               r.adicionado = 'S',
               r.idusuario  = p_idusuario,
               r.status     = 'F',
               r.horafim    = sysdate
         where r.idremanejamento = p_idremanejamento;
      
        pk_triggers_control.enableTrigger('T_BEFORE_REMANEJAMENTO');
      
      end alteraRemanejamentoGerado;
    
      procedure verificaMovimentacaoEstoque is
      begin
        SELECT NVL(SUM(LL.ESTOQUE), 0) ESTOQUE,
               NVL(SUM(LL.PENDENCIA), 0) PENDENCIA,
               NVL(SUM(LL.ADICIONAR), 0) ADICIONAR
          into v_estoque, v_pendencia, v_adicionar
          FROM LOCAL LO, LOTE LT, LOTELOCAL LL, ENTIDADE D, PRODUTO P
         WHERE P.IDPRODUTO = LT.IDPRODUTO
           AND D.IDENTIDADE = LT.IDDEPOSITANTE
           AND LT.IDPRODUTO = p_idProduto
           AND LT.IDDEPOSITANTE = p_idDepositante
           AND LL.IDLOTE = LT.IDLOTE
           AND LL.IDLOCAL = LO.IDLOCAL
           AND LL.IDARMAZEM = LO.IDARMAZEM
           AND LO.IDARMAZEM = p_idArmazem
           AND LO.IDLOCAL = p_idLocalOrigem;
      
        if (v_estoque > 0 or v_pendencia > 0 or v_adicionar > 0) then
          v_msg := t_message('Não foi possível mover todo estoque do produto para novo picking.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end verificaMovimentacaoEstoque;
    
    begin
      gravaLog('INICIOU');
    
      criarRemMudancaPicking(p_idusuario, p_iddepositante, p_idproduto,
                             p_idArmazem, p_idlocalorigem, p_idlocaldestino,
                             v_transfPendenciaAdicionar, v_idremanejamento);
    
      if (v_transfPendenciaAdicionar = 1) then
        transferirPendenciaPicking;
      else
        moverEstoqueMudPicking(p_idusuario, p_idArmazem, p_idlocalorigem,
                               p_idlocaldestino, v_transfPendenciaAdicionar,
                               v_idremanejamento);
      end if;
    
      validarFinalizarRemanejamento(v_idremanejamento);
    
      alteraRemanejamentoGerado(v_idremanejamento);
    
      verificaMovimentacaoEstoque;
    
      gravaLog('FINALIZOU');
    end iniciaMudancaDePicking;
  
  begin
  
    begin
    
      pk_locks.executeLock(p_idArmazem, 7);
    
      carregaDados;
    
      validacoes;
    
      iniciaMudancaDePicking;
    
    exception
      when others then
        raise_application_error(-20000, sqlerrm);
    end;
  
  end;

  /*
  * Funcao que verifica como o remanejamento sera executado
  */
  function retornarExecRemanejamento(p_idremanejamento in number)
    return number is
    v_tipoexecucao number;
    v_total        number;
  begin
  
    select count(*)
      into v_total
      from remanejamento r, local lo, regiaoarmazenagem ro, local ld,
           regiaoarmazenagem rd
     where r.idremanejamento = p_idremanejamento
       and lo.idlocal = r.idlocaldestino
       and lo.idarmazem = r.idarmazemdestino
       and ro.idregiao = lo.idregiao
       and ro.tipo = 1
       and ld.idlocal = r.idlocalorigem
       and ld.idarmazem = r.idarmazemorigem
       and rd.idregiao = ld.idregiao
       and rd.tipo = 1
       and exists
     (select 1
              from remanejamentoromaneio rr, romaneiopai rp,
                   configuracaoonda c
             where rr.idremanejamento = r.idremanejamento
               and c.idconfiguracaoonda = rp.idconfiguracaoonda
               and rp.idromaneio = rr.idromaneio
               and (c.idregiaopruadopulmao = ld.idregiao or
                   c.idregiaopruadopicking = ld.idregiao));
  
    if v_total > 0 then
      -- Execucao do remanejamento deverá ser realizada em 2 etapas
      v_tipoexecucao := 1;
    else
      -- Execucao do remanejamento será livre
      v_tipoexecucao := 0;
    end if;
  
    return v_tipoexecucao;
  end;

  /*
   * Inclui no remanejamento os lotes componentes da montagem
  */
  procedure verificarReabPendente(p_idremanejamento in number) is
  begin
    for c in (select lr.idlote, lo.id idEnderecoOrigem
                from loteremanejamento lr, remanejamento r, local lo
               where lo.idarmazem = r.idarmazemorigem
                 and lo.idlocal = r.idlocalorigem
                 and r.idremanejamento = lr.idremanejamento
                 and lr.conferido = 'N'
                 and lr.idremanejamento = p_idremanejamento)
    loop
      insert into gtt_reabpendente
        select lt.idproduto, l.id idendereco, r.idremanejamento, 0 idonda,
               0 idmovimentacao
          from loteremanejamento lr, remanejamento r, lote lt, local l
         where lr.idlote = c.idlote
           and lr.idremanejamento = r.idremanejamento
           and r.status <> 'F'
           and r.idremanejamento <> p_idremanejamento
           and lr.idlote = lt.idlote
           and l.idarmazem = r.idarmazemdestino
           and l.idlocal = r.idlocaldestino
           and l.id = c.idenderecoorigem;
    end loop;
  end;

  function getQtdeUnitEmbQueCoube
  (
    p_maxpeso           in number,
    p_maxcubagem        in number,
    p_idlote            in number,
    p_qtde              in number,
    p_remanejarPorFator in char
  ) return number is
    v_embalagem         embalagem%rowtype;
    v_qtdePorPeso_un    number;
    v_qtdePorCubagem_un number;
    v_qtdeQueCoube_un   number;
  begin
    if (p_maxpeso <= 0 or p_maxcubagem <= 0) then
      return 0;
    end if;
  
    select e.*
      into v_embalagem
      from lote lt, embalagem e
     where lt.idlote = p_idlote
       and e.barra = lt.barra
       and e.idproduto = lt.idproduto;
  
    v_qtdePorPeso_un := trunc(p_maxpeso / (v_embalagem.pesobruto /
                              v_embalagem.fatorconversao));
  
    v_qtdePorCubagem_un := trunc(p_maxcubagem /
                                 ((v_embalagem.altura * v_embalagem.largura *
                                 v_embalagem.comprimento) /
                                 v_embalagem.fatorconversao));
  
    if (v_qtdePorPeso_un > v_qtdePorCubagem_un) then
      v_qtdeQueCoube_un := v_qtdePorCubagem_un;
    else
      v_qtdeQueCoube_un := v_qtdePorPeso_un;
    end if;
  
    if (v_qtdeQueCoube_un > p_qtde) then
      v_qtdeQueCoube_un := p_qtde;
    end if;
  
    if (p_remanejarPorFator = 'S') then
      if (mod(v_qtdeQueCoube_un, v_embalagem.fatorconversao) <> 0 and
         v_qtdeQueCoube_un > v_embalagem.fatorconversao) then
        v_qtdeQueCoube_un := 0;
      end if;
    end if;
  
    return v_qtdeQueCoube_un;
  end;

  procedure planejarRemanejamentoLote
  (
    p_idusuario              in number,
    p_idarmazem              in number,
    p_idlocalorigem          in local.idlocal%type,
    p_idlocaldestino         in local.idlocal%type,
    p_idlote                 in number,
    p_qtde                   in number,
    p_descricao              in varchar2,
    p_idromaneio             in number := null,
    p_idnotafiscal           in number := null,
    p_verificarMaxDimensao   in char := 'N',
    p_remPorFatorMaxDimensao in char := 'S',
    p_idmovimentacao         in number := null
  ) is
    type rec_remlote is record(
      idusuario            number,
      idarmazem            number,
      idlocalorigem        local.idlocal%type,
      idlocaldestino       local.idlocal%type,
      idlote               number,
      qtde                 number,
      descricao            varchar2(1000),
      idromaneio           number,
      maxpeso              number,
      maxcubagem           number,
      verificarMaxDimensao char(1),
      remanejarPorFator    char(1));
  
    r_remlote        rec_remlote;
    v_qtdedistribuir number;
    r_remAberto      remanejamento%rowtype;
    v_isOrigemBuffer number;
    v_msg            t_message;
  
    procedure getMaxDimensaoLocal(r_remlote in out rec_remlote) is
    begin
      select (lo.altura - lo.alturamanobra) * lo.largura * lo.comprimento maxcubagem,
             lo.pesomaximo maxpeso
        into r_remlote.maxcubagem, r_remlote.maxpeso
        from local lo
       where lo.idarmazem = r_remlote.idarmazem
         and lo.idlocal = r_remlote.idlocaldestino;
    end;
  
    procedure inserirLoteRemanejamento
    (
      r_remlote         in rec_remlote,
      p_qtde            in out number,
      p_idremanejamento in number
    ) is
    begin
      begin
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, idromaneio)
        values
          (p_idremanejamento, r_remlote.idlote, p_qtde, 'N',
           r_remlote.idromaneio);
      
        Associar(p_idremanejamento, r_remlote.idlote);
      
      exception
        when dup_val_on_index then
          update loteremanejamento
             set qtde = qtde + p_qtde
           where idremanejamento = p_idremanejamento
             and idlote = r_remlote.idlote;
      end;
    
      begin
        if (r_remlote.idromaneio is not null) then
          insert into remanejamentoromaneio
            (idremanejamento, idromaneio, idlote, qtde, data)
          values
            (p_idremanejamento, r_remlote.idromaneio, r_remlote.idlote,
             p_qtde, sysdate);
        end if;
      exception
        when dup_val_on_index then
          update remanejamentoromaneio rr
             set rr.qtde = rr.qtde + p_qtde,
                 rr.data = sysdate
           where idremanejamento = p_idremanejamento
             and idromaneio = r_remlote.idromaneio
             and idlote = r_remlote.idlote;
      end;
    
    end;
  
    procedure usarRemanejamentoAberto
    (
      r_remlote        in out rec_remlote,
      p_qtdedistribuir in out number
    ) is
      v_pesoocupado    number;
      v_cubagemocupada number;
      v_qtdeQueCoube   number;
      c_remAberto      cursor_remanejamento;
      r_remAberto      remanejamento%rowtype;
    begin
      getRemAberto(c_remAberto, r_remAberto, r_remlote.idarmazem,
                   r_remlote.idlocalorigem, r_remlote.idlocaldestino);
      if (c_remAberto%found) then
        while (c_remAberto%found)
        loop
          if (r_remlote.verificarMaxDimensao = 'N') then
            inserirLoteRemanejamento(r_remlote, p_qtdedistribuir,
                                     r_remAberto.Idremanejamento);
          
            p_qtdedistribuir := 0;
          else
            begin
              select nvl(sum(lr.qtde * (e.pesobruto / e.fatorconversao)), 0),
                     nvl(sum(lr.qtde * ((e.altura * e.largura *
                              e.comprimento) / e.fatorconversao)), 0)
                into v_pesoocupado, v_cubagemocupada
                from loteremanejamento lr, lote lt, embalagem e
               where lr.idremanejamento = r_remAberto.idremanejamento
                 and lt.idlote = lr.idlote
                 and e.idproduto = lt.idproduto
                 and e.barra = lt.barra;
            exception
              when no_data_found then
                v_pesoocupado    := 0;
                v_cubagemocupada := 0;
            end;
          
            v_qtdeQueCoube := getQtdeUnitEmbQueCoube((r_remlote.maxpeso -
                                                     v_pesoocupado),
                                                     (r_remlote.maxcubagem -
                                                      v_cubagemocupada),
                                                     r_remlote.idlote,
                                                     p_qtdedistribuir,
                                                     r_remlote.remanejarPorFator);
          
            if (v_qtdeQueCoube > 0) then
              if (v_qtdeQueCoube >= p_qtdedistribuir) then
                inserirLoteRemanejamento(r_remlote, p_qtdedistribuir,
                                         r_remAberto.Idremanejamento);
              
                p_qtdedistribuir := 0;
              else
                inserirLoteRemanejamento(r_remlote, v_qtdeQueCoube,
                                         r_remAberto.Idremanejamento);
              
                insert into gtt_remanejamentogerado
                  (idremanejamento, idlote, qtdeunit)
                values
                  (r_remAberto.Idremanejamento, r_remlote.idlote,
                   v_qtdeQueCoube);
              
                p_qtdedistribuir := p_qtdedistribuir - v_qtdeQueCoube;
              end if;
            end if;
          end if;
        
          exit when p_qtdedistribuir = 0;
        
          fetch c_remAberto
            into r_remAberto;
        end loop;
      end if;
      close c_remAberto;
    end;
  
    procedure verificaLocalOrigemDestino
    (
      r_remlote      in rec_remlote,
      p_idnotafiscal in number
    ) is
      v_regiaoorigem        number;
      v_regiaodestino       number;
      v_idproduto           produto.idproduto%type;
      v_codigointerno       produto.codigointerno%type;
      v_idnotafiscal        notafiscal.idnotafiscal%type;
      v_codigointernonf     notafiscal.codigointerno%type;
      v_sequencia           notafiscal.sequencia%type;
      v_numpedidofornecedor notafiscal.numpedidofornecedor%type;
    begin
      select count(1)
        into v_regiaoorigem
        from regiaoarmazenagem r, local lo
       where lo.idregiao = r.idregiao
         and lo.idlocal = r_remlote.idlocalorigem
         and lo.idarmazem = r_remlote.idarmazem;
    
      if (v_regiaoorigem = 0) then
      
        select p.idproduto, p.codigointerno
          into v_idproduto, v_codigointerno
          from produto p, lote lt
         where lt.idproduto = p.idproduto
           and lt.idlote = r_remlote.idlote;
      
        if p_idnotafiscal is not null then
          select nf.idnotafiscal, nf.codigointerno, nf.sequencia,
                 nf.numpedidofornecedor
            into v_idnotafiscal, v_codigointernonf, v_sequencia,
                 v_numpedidofornecedor
            from notafiscal nf
           where nf.idnotafiscal = p_idnotafiscal;
        
          v_msg := t_message('O Local ({0}' ||
                             ') de origem não possui região definida.' ||
                             chr(13) || ' Idproduto: {1}' ||
                             ', Código Produto: {2}' || chr(13) ||
                             'Idnotafiscal: {3}, Nota Fiscal: {4}' ||
                             ', Série: {5}, Pedido: {6}.' || chr(13) ||
                             'Operação cancelada.');
          v_msg.addParam(r_remlote.idlocalorigem);
          v_msg.addParam(v_idproduto);
          v_msg.addParam(v_codigointerno);
          v_msg.addParam(v_idnotafiscal);
          v_msg.addParam(v_codigointernonf);
          v_msg.addParam(v_sequencia);
          v_msg.addParam(v_numpedidofornecedor);
          raise_application_error(-20100, v_msg.formatMessage);
        else
          v_msg := t_message('O Local ({0}' ||
                             ') de origem não possui região definida. ' ||
                             chr(13) || ' Idproduto: {1}' ||
                             ', Código interno: {2}' || chr(13) ||
                             '.Operação cancelada.');
          v_msg.addParam(r_remlote.idlocalorigem);
          v_msg.addParam(v_idproduto);
          v_msg.addParam(v_codigointerno);
          raise_application_error(-20100, v_msg.formatMessage);
        end if;
      
      end if;
    
      select count(1)
        into v_regiaodestino
        from regiaoarmazenagem r, local ld
       where ld.idregiao = r.idregiao
         and ld.idlocal = r_remlote.idlocaldestino
         and ld.idarmazem = r_remlote.idarmazem;
    
      if (v_regiaodestino = 0) then
      
        v_idproduto           := null;
        v_codigointerno       := null;
        v_idnotafiscal        := null;
        v_codigointernonf     := null;
        v_sequencia           := null;
        v_numpedidofornecedor := null;
      
        select p.idproduto, p.codigointerno
          into v_idproduto, v_codigointerno
          from produto p, lote lt
         where lt.idproduto = p.idproduto
           and lt.idlote = r_remlote.idlote;
      
        select nf.idnotafiscal, nf.codigointerno, nf.sequencia,
               nf.numpedidofornecedor
          into v_idnotafiscal, v_codigointernonf, v_sequencia,
               v_numpedidofornecedor
          from notafiscal nf
         where nf.idnotafiscal = p_idnotafiscal;
      
        v_msg := t_message('O Local ({0}' ||
                           ') de destino não possui região definida. ' ||
                           chr(13) || ' Idproduto: {1}' ||
                           ', Código Produto: {2}' || chr(13) ||
                           'Idnotafiscal: {3}, Nota Fiscal: ' ||
                           '{4}, Série: {5}, Pedido: {6}.' || chr(13) ||
                           'Operação cancelada.');
        v_msg.addParam(r_remlote.idlocaldestino);
        v_msg.addParam(v_idproduto);
        v_msg.addParam(v_codigointerno);
        v_msg.addParam(v_idnotafiscal);
        v_msg.addParam(v_codigointernonf);
        v_msg.addParam(v_sequencia);
        v_msg.addParam(v_numpedidofornecedor);
        raise_application_error(-20100, v_msg.formatMessage);
      
      end if;
    
    end;
  
    procedure usarNovoRemanejamento
    (
      r_remlote        in out rec_remlote,
      p_qtdedistribuir in out number,
      p_idnotafiscal   in number
    ) is
      v_idremanejamento   number;
      v_qtdeQueCoube      number;
      v_caixaMovimentacao number;
      v_status            char(1);
    
      function isCaixaMovimentacao
      (
        p_idArmazem number,
        p_idLocal   varchar2
      ) return boolean is
        v_caixaMovimentacao number;
      begin
        select count(1) total
          into v_caixaMovimentacao
          from local l, setor s
         where s.idsetor = l.idsetor
           and l.tipo = 1
           and l.idarmazem = p_idarmazem
           and s.usoexclusivocxmov = 1
           and l.idlocal = p_idLocal;
        return v_caixaMovimentacao > 0;
      end;
    
    begin
      if (p_qtdedistribuir <= 0) then
        return;
      end if;
    
      verificaLocalOrigemDestino(r_remlote, p_idnotafiscal);
    
      v_status := c_aguardando;
    
      if (isCaixaMovimentacao(r_remlote.idarmazem, r_remlote.idlocalorigem)) then
        v_status := 'G';
      end if;
    
      while (p_qtdedistribuir > 0)
      loop
        select seq_remanejamento.nextval idremanejamento
          into v_idremanejamento
          from dual;
      
        insert into remanejamento
          (idremanejamento, idarmazemorigem, idlocalorigem,
           idarmazemdestino, idlocaldestino, datahora, idusuariotela, status,
           cadmanual, idromaneio, descrpalet, planejado, idmovimentacao)
        values
          (v_idremanejamento, r_remlote.idarmazem, r_remlote.idlocalorigem,
           r_remlote.idarmazem, r_remlote.idlocaldestino, sysdate,
           r_remlote.idusuario, v_status, c_nao, r_remlote.idromaneio,
           r_remlote.descricao, 'S', p_idmovimentacao);
      
        if (r_remlote.verificarMaxDimensao = 'N') then
          v_qtdeQueCoube := p_qtdedistribuir;
        else
          v_qtdeQueCoube := getQtdeUnitEmbQueCoube(r_remlote.maxpeso,
                                                   r_remlote.maxcubagem,
                                                   r_remlote.idlote,
                                                   p_qtdedistribuir,
                                                   r_remlote.remanejarPorFator);
        
          if (v_qtdeQueCoube = 0) then
            v_msg := t_message('O endereço {0}' ||
                               ' não possui capacidade física para armazenar uma única embalagem do lote ' ||
                               '{1}. Operação cancelada.');
            v_msg.addParam(r_remlote.idlocaldestino);
            v_msg.addParam(r_remlote.idlote);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      
        inserirLoteRemanejamento(r_remlote, v_qtdeQueCoube,
                                 v_idremanejamento);
      
        insert into gtt_remanejamentogerado
          (idremanejamento, idlote, qtdeunit)
        values
          (v_idremanejamento, r_remlote.idlote, v_qtdeQueCoube);
      
        p_qtdedistribuir := p_qtdedistribuir - v_qtdeQueCoube;
      end loop;
    end;
  begin
  
    select count(*)
      into v_isOrigemBuffer
      from dual
     where exists (select 1
              from local lo
             where lo.idlocal = p_idlocalorigem
               and lo.picking = 'S'
               and lo.buffer = 'S');
  
    r_remlote.idusuario            := p_idusuario;
    r_remlote.idarmazem            := p_idarmazem;
    r_remlote.idlocalorigem        := p_idlocalorigem;
    r_remlote.idlocaldestino       := p_idlocaldestino;
    r_remlote.idlote               := p_idlote;
    r_remlote.qtde                 := p_qtde;
    r_remlote.descricao            := p_descricao;
    r_remlote.idromaneio           := p_idromaneio;
    r_remlote.verificarMaxDimensao := p_verificarMaxDimensao;
    r_remlote.remanejarPorFator    := p_remPorFatorMaxDimensao;
  
    v_qtdedistribuir := r_remlote.qtde;
    if (r_remlote.verificarMaxDimensao = 'S') then
      getMaxDimensaoLocal(r_remlote);
    end if;
  
    if nvl(v_isOrigemBuffer, 0) > 0 then
      usarNovoRemanejamento(r_remlote, v_qtdedistribuir, p_idnotafiscal);
    else
      usarRemanejamentoAberto(r_remlote, v_qtdedistribuir);
      usarNovoRemanejamento(r_remlote, v_qtdedistribuir, p_idnotafiscal);
    end if;
  end;

  function retornarTarefa
  (
    p_idremanejamento in number,
    p_idendereco      in number
  ) return varchar2 is
    v_tarefa varchar2(4000);
  begin
    select stragg(codbarratarefa)
      into v_tarefa
      from (select distinct v.codbarratarefa
               from remanejamentoromaneio rr, v_tarefas_onda v
              where rr.idremanejamento = p_idremanejamento
                and v.idonda = rr.idromaneio
                and v.idlote = rr.idlote
                and v.idlocalorigem = p_idendereco
                and v.status < 3);
  
    return v_tarefa;
  exception
    when no_data_found then
      return null;
  end;

  function retornarQtdeRemPorTarefa
  (
    p_codtarefa in varchar2,
    p_tipo      in varchar := 0
  ) return varchar2 is
    v_qtde           number;
    v_remanejamentos varchar2(4000);
  begin
  
    select count(distinct r.idremanejamento), stragg(r.idremanejamento)
      into v_qtde, v_remanejamentos
      from v_tarefas_onda v, loteremanejamento lr, remanejamento r, local l
     where v.codbarratarefa = p_codtarefa
       and v.status < 3
       and lr.idlote = v.idlote
       and r.idremanejamento = lr.idremanejamento
       and r.status <> 'F'
       and (exists (select 1
                      from remanejamentoromaneio rr
                     where rr.idremanejamento = r.idremanejamento
                       and rr.idlote = lr.idlote
                       and rr.idromaneio <= v.idonda) or
            (r.cadmanual = 'N' and r.idromaneio is null and
            upper(r.descrpalet) like '%REABASTECIMENTO PARA ONDA%') or
            (r.cadmanual = 'S' and r.idromaneio is null and
            upper(r.descrpalet) like
            '%REABASTECIMENTO POR DEMANDA PLANEJADA%' and
            ((v.quantidade >
            nvl((select sum(ll.estoque)
                            from lotelocal ll, local loc
                           where 1 = 1
                             and loc.idlocal = ll.idlocal
                             and loc.idarmazem = ll.idarmazem
                             and (ll.estoque + ll.pendencia + ll.adicionar) > 0
                             and loc.id = v.idlocalorigem
                             and ll.idlote = v.idlote), 0)) or
            (v.disponivelestoqueorigem is not null and
            v.disponivelestoqueorigem < 0))))
       and l.idlocal = r.idlocaldestino
       and l.tipo = 0
       and l.buffer = 'N';
  
    if (nvl(p_tipo, 0) = 0) then
      return v_qtde;
    end if;
  
    return v_remanejamentos;
  
  end;

  function retornarRemPorTarefa(p_codtarefa in varchar2) return varchar2 is
    v_rem varchar2(4000);
  begin
    select stragg(idremanejamento)
      into v_rem
      from (select distinct rr.idremanejamento
               from v_tarefas_onda v, remanejamentoromaneio rr,
                    remanejamento r
              where v.codbarratarefa = p_codtarefa
                and v.status < 3
                and rr.idromaneio = v.idonda
                and rr.idlote = v.idlote
                and r.idremanejamento = rr.idremanejamento
                and r.status <> 'F'
              order by rr.idremanejamento);
  
    return v_rem;
  exception
    when no_data_found then
      return null;
  end;

  procedure validarBufPickEsteira
  (
    p_idRemanejamento in number,
    p_telaExecRemanej in number default 0
  ) is
  
    C_DESTINOINICIADO CONSTANT CHAR(1) := 'Z';
    v_naoFinalizar number;
    v_msg          t_message;
  
    function isRemanejamentoBufPickEsteira(p_idRemanejamento in number)
      return boolean is
      v_resultado number;
    begin
      select count(*)
        into v_resultado
        from dual
       where exists (select 1
                from remanejamento r, local lo, local ld, setor sd
               where r.idremanejamento = p_idRemanejamento
                 and r.idarmazemorigem = lo.idarmazem
                 and r.idlocalorigem = lo.idlocal
                 and lo.tipo = 0
                 and lo.buffer = 'S'
                 and lo.bufferesteira = 1
                 and r.idlocaldestino = ld.idlocal
                 and ld.tipo = 0
                 and ld.buffer = 'N'
                 and ld.idsetor = sd.idsetor
                 and sd.codintegracaoesteira is not null
                 and r.planejado = 'S'
                 and r.cadmanual = 'N');
      return v_resultado > 0;
    end;
  
  begin
  
    if isRemanejamentoBufPickEsteira(p_idRemanejamento) then
      if nvl(p_telaExecRemanej, 0) in
         (C_REMANEJ_WEB, C_REMANEJ_MANUAL_COLETOR, C_REMANEJ_ORIGEM,
          C_REMANEJ_PLAN_COLETOR) then
        v_msg := t_message('Não é possível executar esse remanejamento por essa tela. Realize-o através da opção Remanejamento Destino via Coletor de Dados.');
        raise_application_error(-20000, v_msg.formatMessage);
      elsif nvl(p_telaExecRemanej, 0) = C_REMANEJ_DESTINO then
        select count(1)
          into v_naoFinalizar
          from remanejamento rem, local ld, setor s
         where ld.idarmazem = rem.idarmazemdestino
           and ld.idlocal = rem.idlocaldestino
           and ld.tipo = 0
           and ld.buffer = 'N'
           and ld.idsetor = s.idsetor
           and s.codintegracaoesteira is not null
           and rem.idremanejamento = p_idRemanejamento
           and rem.status <> C_DESTINOINICIADO;
      
        if (v_naoFinalizar > 0) then
          v_msg := t_message('Não é possível executar esse remanejamento. Verifique se o mesmo já teve sua origem realizada.');
          raise_application_error(-20000, v_msg.formatMessage);
        end if;
      end if;
    end if;
  end;

  procedure regraRemanejamentoLoteUnico(p_idremanejamento in number) is
    r_loteunico        pk_lote.t_loteunico;
    r_loteunicoComp    pk_lote.t_loteunico;
    r_loteunicoAvaliar pk_lote.t_loteunico;
    v_retorno          varchar2(500);
    r_remanejamento    t_rem;
  begin
    for r_loteunico in (select distinct lt.idproduto, lt.estado,
                                        lt.descr loteindustria,
                                        lt.dtvenc dtvencimento,
                                        pd.loteuniconoendereco,
                                        lt.iddepositante,
                                        pd.vencimentouniconoendereco
                          from loteremanejamento lr, lote lt,
                               produtodepositante pd
                         where lr.idremanejamento = p_idremanejamento
                           and lr.idlote = lt.idlote
                           and lt.idlote = lr.idlote
                           and pd.idproduto = lt.idproduto
                           and pd.identidade = lt.iddepositante)
    loop
    
      r_loteunicoAvaliar.idProduto                 := r_loteunico.idproduto;
      r_loteunicoAvaliar.estado                    := r_loteunico.estado;
      r_loteunicoAvaliar.loteindustria             := r_loteunico.loteindustria;
      r_loteunicoAvaliar.dtvencimento              := r_loteunico.dtvencimento;
      r_loteunicoAvaliar.loteuniconoendereco       := r_loteunico.loteuniconoendereco;
      r_loteunicoAvaliar.iddepositante             := r_loteunico.iddepositante;
      r_loteunicoAvaliar.vencimentouniconoendereco := r_loteunico.vencimentouniconoendereco;
    
      for r_loteunicoComp in (select distinct lt.idproduto, lt.estado,
                                              lt.descr loteindustria,
                                              lt.dtvenc dtvencimento,
                                              pd.loteuniconoendereco,
                                              lt.iddepositante,
                                              pd.vencimentouniconoendereco
                                from loteremanejamento lr, lote lt,
                                     produtodepositante pd
                               where lr.idremanejamento = p_idremanejamento
                                 and lr.idlote = lt.idlote
                                 and lt.idlote = lr.idlote
                                 and pd.idproduto = lt.idproduto
                                 and pd.identidade = lt.iddepositante
                                 and (lt.idproduto <> r_loteunico.idproduto or
                                     lt.estado <> r_loteunico.estado or
                                     lt.descr <> r_loteunico.loteindustria or
                                     lt.dtvenc <> r_loteunico.dtvencimento or
                                     pd.loteuniconoendereco <>
                                     r_loteunico.loteuniconoendereco))
      loop
        if not
            pk_lote.isLoteUnicoCompativel(r_loteunico, r_loteunicoComp,
                                          v_retorno,
                                          r_remanejamento.idarmazemdestino,
                                          r_remanejamento.idlocaldestino) then
          raise_application_error(-20000, v_retorno);
        end if;
      end loop;
    end loop;
  
    if not pk_lote.isLocalPodeReceberLoteUnico(r_loteunicoAvaliar,
                                               r_remanejamento.idarmazemdestino,
                                               r_remanejamento.idlocaldestino,
                                               v_retorno) then
      raise_application_error(-20000, v_retorno);
    end if;
  end regraRemanejamentoLoteUnico;

  procedure finalizarRemanejamento
  (
    p_idremanejamento     in number,
    p_idusuario           in number,
    p_telaExecFinalizacao in number default 0
  ) is
    r_remanejamento t_rem;
  
    v_idendereco           number;
    v_picking              number;
    v_qtde_lote            number;
    v_tipoLocalOrigem      number;
    v_LocalOrigemBuffer    varchar2(1);
    v_existeCRN            number;
    v_msg                  varchar(2000) := '';
    v_erro                 boolean := false;
    v_remDePlParaPkEsteira boolean := false;
    v_fatorConversao       number;
    v_caixaFechada         varchar2(1);
    v_produto              produto.codigointerno%type;
    v_msgRaise             t_message;
  
    v_tipoPermPkSetorOrigem  number;
    v_tipoPermPkSetorDestino number;
    v_barraUnitaria          embalagem.barra%type;
    v_qtdeUN                 number;
    v_fatorConversaoLote     embalagem.fatorconversao%type;
    v_qtdeTotalLote          lote.qtdedisponivel%type;
    r_lote                   lote%rowtype;
    v_idlote                 number;
    v_complementar           lotelocal.complementar%type;
    v_qtdeUtilizadaUN        number;
    v_qtdeCobertaLoteAntigo  number;
    v_complementar           varchar2(200);
  
    function isRemPulmParaPickComEsteira
    (
      p_idremanejamento in number,
      p_idArmazem       in number,
      p_idlocalorigem   in varchar2,
      p_idlocaldestino  in varchar2
    ) return boolean is
      v_isPulmParaPickEsteira number;
    begin
      -- Verificar se é fluxo de origem pulmão sem esteira para destino picking com esteira
      select count(l.idlocal)
        into v_isPulmParaPickEsteira
        from remanejamento r, local l, setor s
       where r.idremanejamento = p_idremanejamento
         and s.idsetor = l.idsetor
         and ((l.idlocal = p_idlocalorigem and l.idarmazem = p_idArmazem and
             l.tipo in (1, 2) and
             length(trim(s.codintegracaoesteira)) is null) or
             (l.idlocal = p_idlocaldestino and l.idarmazem = p_idArmazem and
             l.tipo = 0 and
             length(trim(s.codintegracaoesteira)) is not null));
    
      if (v_isPulmParaPickEsteira = 2) then
        return true;
      else
        return false;
      end if;
    
    exception
      when no_data_found then
        return false;
      
    end isRemPulmParaPickComEsteira;
  
    procedure execOrigemRemBufferPK is
    begin
      for c_remanejamentoFilho in (select r.idRemanejamento
                                     from remanejamento r
                                    where r.idremanejamentopai =
                                          p_idremanejamento
                                      and r.status = 'A'
                                      and exists (select 1
                                             from local lo
                                            where lo.idarmazem =
                                                  r.idarmazemorigem
                                              and lo.idlocal =
                                                  r.idlocalorigem
                                              and lo.tipo = 0
                                              and lo.buffer = 'S'
                                              and lo.bufferesteira = 1)
                                      and exists
                                    (select 1
                                             from local ld, setor sd
                                            where sd.idsetor = ld.idsetor
                                              and ld.idarmazem =
                                                  r.idarmazemdestino
                                              and ld.idlocal =
                                                  r.idlocaldestino
                                              and ld.tipo = 0
                                              and ld.buffer = 'N'
                                              and nvl(length(sd.codintegracaoesteira),
                                                      0) > 0))
      loop
        update loteremanejamento lr
           set lr.conferido = 'S'
         where lr.idremanejamento = c_remanejamentoFilho.idRemanejamento
           and lr.conferido = 'N';
      
        update remanejamento rem
           set rem.status          = 'G',
               rem.idusuarioinicio = p_idusuario,
               rem.horafimorigem   = sysdate
         where rem.Idremanejamento = c_remanejamentoFilho.idRemanejamento;
      
        integrarEsteira(c_remanejamentoFilho.idRemanejamento, p_idusuario);
      end loop;
    end execOrigemRemBufferPK;
  
    procedure validaPickingMultiplo
    (
      p_idlote         in number,
      p_idlocaldestino in varchar2
    ) is
      v_pickingmultiplo  varchar2(1);
      v_qtdeProdutoLocal number := 0;
    begin
      select nvl(d.pickingmultiplo, 'N')
        into v_pickingmultiplo
        from lote l, depositante d
       where l.idlote = p_idlote
         and d.identidade = l.iddepositante;
    
      if (v_pickingmultiplo = 'N') then
        v_qtdeProdutoLocal := 0;
      
        select count(1)
          into v_qtdeProdutoLocal
          from lote l, produtolocal pl
         where l.idlote = p_idlote
           and pl.idarmazem = l.idarmazem
           and pl.idlocal = p_idlocaldestino
           and pl.identidade = l.iddepositante
           and pl.idproduto <> l.idproduto;
      
        if (v_qtdeProdutoLocal > 0) then
          raise_application_error(-20000,
                                  'Depositante não utiliza Picking Múltiplo e o local destino já contém outro produto.');
        end if;
      end if;
    end validaPickingMultiplo;
  
    procedure validaLocalPicking
    (
      p_idlote         in number,
      p_idlocaldestino in varchar2,
      p_idarmazem      in number
    ) is
      v_pickingdinamico   varchar2(1);
      v_produtoComPicking number := 0;
      v_tipoDestino       number;
    begin
      select nvl(d.pickingdinamico, 0)
        into v_pickingdinamico
        from lote l, produtodepositante d
       where l.idlote = p_idlote
         and d.identidade = l.iddepositante
         and d.idproduto = l.idproduto;
    
      if (v_pickingdinamico = 1) then
        return;
      else
      
        select lo.tipo
          into v_tipoDestino
          from local lo
         where lo.idarmazem = p_idarmazem
           and lo.idlocal = p_idlocaldestino;
      
        if v_tipoDestino <> C_LOCAL_PICKING then
          return;
        else
          select count(1)
            into v_produtoComPicking
            from lote l, produtolocal pl
           where l.idlote = p_idlote
             and pl.idarmazem = l.idarmazem
             and pl.idlocal = p_idlocaldestino
             and pl.identidade = l.iddepositante
             and pl.idproduto = l.idproduto;
        
          if (v_produtoComPicking = 0) then
            raise_application_error(-20000,
                                    'Produto não está associado ao endereço de Picking: ' ||
                                     p_idlocaldestino);
          end if;
        end if;
      end if;
    end validaLocalPicking;
  
  begin
    select r.status
      into r_remanejamento.status
      from remanejamento r
     where r.idremanejamento = p_idremanejamento
       for update;
  
    select r.status, r.planejado, r.idlocalorigem, r.idarmazemorigem,
           r.idremanejamento, r.idlocaldestino, r.idarmazemdestino,
           r.idcontroleavaria, r.idinsucessoentrega, pr.idprodutorecuperado,
           d.tipoexportacaoprodrecuperado,
           nvl(s.usoexclusivocxmov, 0) usoexclusivocxmov
      into r_remanejamento.status, r_remanejamento.planejado,
           r_remanejamento.idlocalorigem, r_remanejamento.idarmazemorigem,
           r_remanejamento.idremanejamento, r_remanejamento.idlocaldestino,
           r_remanejamento.idarmazemdestino,
           r_remanejamento.idcontroleavaria,
           r_remanejamento.idinsucessoentrega,
           r_remanejamento.idprodutorecuperado,
           r_remanejamento.tipoexportacaoprodrecuperado,
           r_remanejamento.usoexclusivocxmov
      from remanejamento r, produtorecuperado pr, depositante d, local l,
           setor s
     where r.idremanejamento = p_idremanejamento
       and r.idlocalorigem = l.idlocal
       and r.idarmazemorigem = l.idarmazem
       and l.idsetor = s.idsetor(+)
       and pr.idremanejamento(+) = r.idremanejamento
       and d.identidade(+) = pr.iddepositante;
  
    if (r_remanejamento.status = 'F') then
      v_msgRaise := t_message('REMANEJAMENTO JA ESTA FINALIZADO. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msgRaise.formatMessage);
    end if;
  
    if r_remanejamento.planejado = 'S' then
      if (r_remanejamento.status in ('A', 'Z', 'G')) then
      
        select count(*)
          into v_qtde_lote
          from loteremanejamento lr
         where lr.idremanejamento = p_idremanejamento;
      
        if v_qtde_lote = 0 then
          v_msgRaise := t_message('REMANEJAMENTO SEM LOTES. OPERAÇÃO CANCELADA.');
          raise_application_error(-20000, v_msgRaise.formatMessage);
        end if;
      
        regraRemanejamentoLoteUnico(p_idremanejamento);
        regraLoteVencimentoUnicoNoEnd(p_idremanejamento);
      
        v_remDePlParaPkEsteira := isRemPulmParaPickComEsteira(p_idremanejamento,
                                                              r_remanejamento.idarmazemorigem,
                                                              r_remanejamento.idlocalorigem,
                                                              r_remanejamento.idlocaldestino);
      
        select lo.tipo, lo.buffer,
               nvl(so.tipopermitirpickingsetor, 0) tipopermitirpickingsetor,
               nvl(sd.tipopermitirpickingsetor, 0) tipopermitirpickingsetor
          into v_tipoLocalOrigem, v_LocalOrigemBuffer,
               v_tipoPermPkSetorOrigem, v_tipoPermPkSetorDestino
          from local lo, setor so, local ld, setor sd
         where lo.idlocal = r_remanejamento.idlocalorigem
           and lo.idarmazem = r_remanejamento.idarmazemorigem
           and so.idsetor(+) = lo.idsetor
           and ld.idlocal = r_remanejamento.idlocaldestino
           and ld.idarmazem = r_remanejamento.idarmazemdestino
           and sd.idsetor(+) = ld.idsetor;
      
        if ((v_tipoLocalOrigem = C_LOCAL_PICKING) and
           (v_tipoPermPkSetorOrigem = C_SETOR_CAIXAS and
           v_tipoPermPkSetorDestino = C_SETOR_UNIDADES)) then
        
          for c_loteRemanejamento in (select lr.qtde, lr.idlote
                                        from loteremanejamento lr
                                       where lr.idremanejamento =
                                             r_remanejamento.idremanejamento)
          loop
            validaPickingMultiplo(c_loteRemanejamento.idlote,
                                  r_remanejamento.idlocaldestino);
          
            validaPickingMultiplo(c_loteRemanejamento.idlote,
                                  r_remanejamento.idlocaldestino);
          
            validaLocalPicking(c_loteRemanejamento.idlote,
                               r_remanejamento.idlocaldestino,
                               r_remanejamento.idarmazemdestino);
          
            delete from gtt_formarloteremanejamento;
          
            select e.fatorconversao, lt.qtdedisponivel
              into v_fatorConversaoLote, v_qtdeTotalLote
              from lote lt, embalagem e
             where lt.idlote = c_loteRemanejamento.Idlote
               and e.idproduto = lt.idproduto
               and e.barra = lt.barra;
          
            if (verificaCompOrigemDestino(v_qtdeTotalLote,
                                          v_fatorConversaoLote,
                                          c_loteRemanejamento.Qtde)) then
              begin
                select e.barra
                  into v_barraUnitaria
                  from lote lt, embalagem e
                 where lt.idlote = c_loteRemanejamento.Idlote
                   and e.idproduto = lt.idproduto
                   and e.fatorconversao = 1
                   and e.caixafechada = 'N'
                   and e.ativo = 'S'
                   and e.precadastro = 'N'
                   and rownum = 1;
              exception
                when no_data_found then
                  v_msgRaise := t_message('Não foi encontrada barra de unidade. Operação não permitida.');
                  raise_application_error(-20000, v_msgRaise.formatMessage);
              end;
            
              insert into gtt_formarloteremanejamento
                (idremanejamento, iddepositante, idproduto, estado, barra,
                 qtde, itemadicional, peso, loteindustria, loteadicional,
                 dtvenc, dtfabricacao, idloteinfoespec, liberado)
                select lr.idremanejamento, lt.iddepositante, lt.idproduto,
                       lt.estado, v_barraUnitaria, lr.qtde, lt.itemadicional,
                       (e.pesobruto * lr.qtde) peso, lt.descr,
                       lt.loteadicional, lt.dtvenc, lt.dtfabricacao,
                       decode(pk_lote.retinformacoesespecifica(lt.idlote),
                               'SEM INFORMAÇÃO', null) idloteinfoespec,
                       lt.liberado
                  from loteremanejamento lr, lote lt, embalagem e
                 where lr.idremanejamento = r_remanejamento.idremanejamento
                   and lr.idlote = c_loteRemanejamento.Idlote
                   and lt.idlote = lr.idlote
                   and e.idproduto = lt.idproduto
                   and e.barra = v_barraUnitaria;
            
              for c_novoLote in (select g.idproduto, g.estado,
                                        g.iddepositante, g.itemadicional,
                                        g.loteindustria, g.dtvenc,
                                        g.dtfabricacao, g.qtde,
                                        e.fatorconversao, e.lastro,
                                        e.qtdecamada, g.idtipocaixa,
                                        g.loteadicional, g.idloteinfoespec,
                                        g.peso, g.barra,
                                        nvl(g.liberado, 'S') liberado
                                   from gtt_formarloteremanejamento g,
                                        embalagem e
                                  where e.barra = g.barra
                                    and e.idproduto = g.idproduto)
              loop
              
                v_qtdeUN := (c_novoLote.qtde * c_novoLote.fatorconversao);
              
                -- Informando os dados do Novo Lote Unitário
                r_lote.idproduto     := c_novoLote.idproduto;
                r_lote.iddepositante := c_novoLote.iddepositante;
                r_lote.descr         := c_novoLote.loteindustria;
                r_lote.dtVenc        := c_novoLote.dtvenc;
                r_lote.estado        := c_novoLote.estado;
                r_lote.idUsuario     := p_idusuario;
                r_lote.tipolote      := 'L';
                r_lote.situacao      := 'R';
                r_lote.numerovolume  := 1;
                r_lote.itemadicional := c_novoLote.itemadicional;
                r_lote.idtipocaixa   := c_novoLote.idtipocaixa;
                r_lote.idarmazem     := r_remanejamento.idarmazemorigem;
                r_lote.dtfabricacao  := c_novoLote.dtfabricacao;
                r_lote.loteadicional := c_novoLote.loteadicional;
                r_lote.barra         := c_novoLote.barra;
                r_lote.qtdeEntrada   := v_qtdeUN;
                r_lote.tipoPalet     := 'U';
              
                if (pk_lote.isLoteIndustriaComMaisDeUmVenc(c_novoLote.Iddepositante,
                                                           c_novoLote.idproduto,
                                                           c_novoLote.loteindustria,
                                                           c_novoLote.dtvenc)) then
                  raise_application_error(-20000,
                                          'Não é possível cadastrar lote do mesmo produto/depositante com o mesmo lote indústria e data de vencimento diferentes. Depositante:' ||
                                           c_novoLote.Iddepositante ||
                                           '. Produto: ' ||
                                           c_novoLote.idproduto ||
                                           ' Lote Indústria: ' ||
                                           c_novoLote.loteindustria ||
                                           ' Data Venc: ' ||
                                           c_novoLote.dtvenc);
                
                end if;
              
                v_idlote := pk_lote.cadastrar_lote(r_lote, null, 'N');
              
                if (c_novoLote.liberado = 'N') then
                  update lote lt
                     set lt.liberado = 'N'
                   where lt.idlote = v_idlote;
                end if;
              
                if (c_novoLote.peso is not null) then
                  update lote lt
                     set lt.pesobruto = c_novoLote.peso
                   where lt.idlote = v_idlote;
                end if;
              
                pk_estoque.incluir_estoque(r_remanejamento.idarmazemdestino,
                                           r_remanejamento.idlocaldestino,
                                           v_idlote, r_lote.qtdeEntrada,
                                           p_idusuario,
                                           'ESTOQUE ADICIONADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                                            p_idremanejamento, 'N');
              
                -- Consumindo quantidade dos lotes antigos
                v_qtdeUtilizadaUN := 0;
                for r_loteantigo in (select ll.idarmazem, l.idlote,
                                            ll.pendencia,
                                            (ll.estoque - ll.pendencia) disponivelestoque,
                                            l.qtdedisponivel qtdecoberta
                                       from lotelocal ll, lote l
                                      where ll.idarmazem =
                                            r_remanejamento.idarmazemorigem
                                        and ll.idlocal =
                                            r_remanejamento.idlocalorigem
                                        and l.idlote =
                                            c_loteRemanejamento.Idlote
                                        and l.idlote = ll.idlote
                                        and l.idproduto =
                                            c_novoLote.idproduto
                                        and l.estado = c_novoLote.estado
                                        and l.iddepositante =
                                            c_novoLote.iddepositante
                                        and case
                                              when c_novoLote.itemadicional is null then
                                               1
                                              else
                                               decode(l.itemadicional,
                                                      c_novoLote.itemadicional,
                                                      1, 0)
                                            end = 1
                                        and decode(trunc(l.dtvenc),
                                                   trunc(c_novoLote.dtvenc), 1,
                                                   0) = 1
                                        and case
                                              when c_novoLote.dtfabricacao is null then
                                               1
                                              else
                                               decode(trunc(l.dtfabricacao),
                                                      trunc(c_novoLote.dtfabricacao),
                                                      1, 0)
                                            end = 1
                                        and decode(l.descr,
                                                   c_novoLote.loteindustria, 1,
                                                   decode(l.descr,
                                                           'LOTE DE PICKING SETOR CAIXAS PARA PICKING SETOR UNIDADES',
                                                           1, 0)) = 1
                                        and case
                                              when c_novoLote.loteadicional is null then
                                               1
                                              else
                                               decode(l.loteadicional,
                                                      c_novoLote.loteadicional,
                                                      1, 0)
                                            end = 1
                                      order by l.dtalocacao)
                
                loop
                  if (r_loteantigo.disponivelestoque >= v_qtdeUN) then
                    v_qtdeUtilizadaUN := v_qtdeUN;
                  else
                    if ((r_loteantigo.disponivelestoque = 0) or
                       -- pode estar zerando o estoque do lote antigo ou
                       (v_qtdeUN >= r_loteantigo.disponivelestoque)) then
                      -- pode estar retirando uma quantidade maior que o disponível, porém dentro desta operação
                      -- onde a pendência é deste remanejamento e não de outro
                      v_qtdeUtilizadaUN := r_loteantigo.pendencia;
                    else
                      v_qtdeUtilizadaUN := r_loteantigo.disponivelestoque;
                    end if;
                  end if;
                
                  v_qtdeUN := v_qtdeUN - v_qtdeUtilizadaUN;
                
                  pk_estoque.retirar_adicionar(r_remanejamento.idarmazemdestino,
                                               r_remanejamento.idlocaldestino,
                                               r_loteantigo.idlote,
                                               v_qtdeUtilizadaUN,
                                               p_idusuario,
                                               'ADICIONAR SUBTRAIDO REFERENTE AO REMANEJAMENTO N:' ||
                                                r_remanejamento.idremanejamento);
                
                  pk_estoque.retirar_pendencia(r_remanejamento.idarmazemorigem,
                                               r_remanejamento.idlocalorigem,
                                               r_loteantigo.idlote,
                                               v_qtdeUtilizadaUN,
                                               p_idusuario,
                                               'PENDENCIA SUBTRAIDA REFERENTE AO REMANEJAMENTO N:' ||
                                                r_remanejamento.idremanejamento);
                
                  pk_estoque.retirar_estoque(r_loteantigo.idarmazem,
                                             r_remanejamento.idlocalorigem,
                                             r_loteantigo.idlote,
                                             v_qtdeUtilizadaUN, p_idusuario,
                                             'ESTOQUE RETIRADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                                              p_idremanejamento, 'N');
                  exit when v_qtdeUN = 0;
                end loop;
              
                if (v_qtdeUN > 0) then
                  v_msgRaise := t_message('Não foi possível encontrar estoque suficiente para o produto.' ||
                                          chr(13) || 'IDPRODUTO: {0}' ||
                                          chr(13) ||
                                          'QTDENECESSARIA UN: {1}');
                  v_msgRaise.addParam(c_novoLote.idproduto);
                  v_msgRaise.addParam(c_novoLote.qtde *
                                      c_novoLote.fatorconversao);
                  raise_application_error(-20000, v_msgRaise.formatMessage);
                end if;
              
              end loop;
            
            else
              v_msgRaise := t_message('Houve alterações no lote selecionado e não será possível continuar o processo.');
              raise_application_error(-20000, v_msgRaise.formatMessage);
            end if;
          end loop;
        else
          for c in (select lr.idlote, lr.qtde, lt.idproduto, lt.barra,
                           lt.iddepositante
                      from loteremanejamento lr, lote lt
                     where lt.idlote = lr.idlote
                       and lr.idremanejamento =
                           r_remanejamento.idremanejamento
                     order by lr.idlote)
          loop
          
            validarSetor(c.idlote, r_remanejamento.idarmazemdestino,
                         r_remanejamento.idlocaldestino, v_msg, v_erro);
          
            validaPickingMultiplo(c.idlote, r_remanejamento.idlocaldestino);
          
            validaLocalPicking(c.idlote, r_remanejamento.idlocaldestino,
                               r_remanejamento.idarmazemdestino);
          
            validaPickingMultiplo(c.idlote, r_remanejamento.idlocaldestino);
          
            validarBufPickEsteira(p_idremanejamento, p_telaExecFinalizacao);
          
            if (v_remDePlParaPkEsteira) then
            
              -- Remanejamento é de Pulmão sem esteira para Picking com esteira
              -- Verifica se o fator de conversão é maior que um ou caixa fechada
              begin
                select e.fatorconversao, e.caixafechada, p.codigointerno
                  into v_fatorConversao, v_caixaFechada, v_produto
                  from loteremanejamento lr, lote lt, produto p, embalagem e
                 where lr.idremanejamento = r_remanejamento.idremanejamento
                   and lr.idlote = c.idlote
                   and lt.idlote = lr.idlote
                   and p.idproduto = lt.idproduto
                   and e.idproduto = p.idproduto
                   and e.barra = c.barra;
              
                if (v_fatorConversao = 1 and v_caixaFechada = 'N' and
                   r_remanejamento.usoexclusivocxmov = 0) then
                  v_msgRaise := t_message('Não é permitido remanejar produtos unitários diretamente para o Picking com Esteira.' ||
                                          chr(13) || 'Código Interno: {0}.');
                  v_msgRaise.addParam(v_produto);
                  raise_application_error(-20000, v_msgRaise.formatMessage);
                end if;
              
              end;
            end if;
          
            if (v_erro) then
              raise_application_error(-20000, v_msg);
            end if;
          
            pk_picking_dinamico.addGttPickingDinamico(c.idproduto,
                                                      c.iddepositante,
                                                      r_remanejamento.idlocaldestino,
                                                      r_remanejamento.idarmazemdestino,
                                                      1);
          
            pk_estoque.incluir_estoque(r_remanejamento.idarmazemdestino,
                                       r_remanejamento.idlocaldestino,
                                       c.idlote, c.qtde, p_idusuario,
                                       'ESTOQUE ACRESCIDO NO LOTE REFERENTE AO REMANEJAMENTO N:' ||
                                        r_remanejamento.idremanejamento, 'N');
          
            pk_estoque.retirar_adicionar(r_remanejamento.idarmazemdestino,
                                         r_remanejamento.idlocaldestino,
                                         c.idlote, c.qtde, p_idusuario,
                                         'ADICIONAR SUBTRAIDO REFERENTE AO REMANEJAMENTO N:' ||
                                          r_remanejamento.idremanejamento);
          
            pk_estoque.retirar_pendencia(r_remanejamento.idarmazemorigem,
                                         r_remanejamento.idlocalorigem,
                                         c.idlote, c.qtde, p_idusuario,
                                         'PENDENCIA SUBTRAIDA  REFERENTE AO REMANEJAMENTO N:' ||
                                          r_remanejamento.idremanejamento);
          
            pk_estoque.retirar_estoque(r_remanejamento.idarmazemorigem,
                                       r_remanejamento.idlocalorigem,
                                       c.idlote, c.qtde, p_idusuario,
                                       'ESTOQUE SUBTRAIDO NO LOTE REFERENTE AO REMANEJAMENTO N:' ||
                                        r_remanejamento.idremanejamento, 'N');
          
            if ((v_tipoLocalOrigem = 0) AND (v_LocalOrigemBuffer = 'N')) then
              pk_picking_dinamico.addGttPickingDinamico(c.idproduto,
                                                        c.iddepositante,
                                                        r_remanejamento.idlocalorigem,
                                                        r_remanejamento.idarmazemorigem,
                                                        0);
            end if;
          end loop;
        
          pk_picking_dinamico.deletar_picking_dinamico;
          pk_picking_dinamico.inserir_picking_dinamico;
        
          pk_convocacao.finalizaremanejamento(p_idusuario,
                                              r_remanejamento.idremanejamento);
        
          pk_convocacao.finalizaRemOrigem(p_idusuario,
                                          r_remanejamento.idremanejamento);
        
          pk_convocacao.finalizaRemDestino(p_idusuario,
                                           r_remanejamento.idremanejamento);
        
          select l.id, l.tipo
            into v_idendereco, v_picking
            from local l
           where l.idlocal = r_remanejamento.idlocaldestino
             and l.idarmazem = r_remanejamento.idarmazemdestino;
        
          if (v_picking = 0) then
            for c in (select distinct r_remanejamento.idarmazemdestino idarmazem,
                                      r_remanejamento.idlocaldestino idlocal,
                                      l.idproduto, l.iddepositante
                        from loteremanejamento lr, lote l,
                             produtodepositante pd
                       where l.idlote = lr.idlote
                         and pd.identidade = l.iddepositante
                         and pd.idproduto = l.idproduto
                         and pd.pickingdinamico = 1
                         and lr.idremanejamento =
                             r_remanejamento.idremanejamento
                         and not exists
                       (select 1
                                from produtolocal
                               where idarmazem =
                                     r_remanejamento.idarmazemdestino
                                 and idlocal = r_remanejamento.idlocaldestino
                                 and idproduto = l.idproduto
                                 and identidade = l.iddepositante))
            loop
              pk_armazem.criarPickingProduto(c.idarmazem, c.idlocal,
                                             c.iddepositante, c.idproduto);
            end loop;
          end if;
        end if;
      else
        v_msgRaise := t_message('O REMANEJAMENTO NAO FOI PLANEJADO.');
        raise_application_error(-20000, v_msgRaise.formatMessage);
      end if;
    
      validarFinalizarRemanejamento(p_idremanejamento);
    
      update remanejamento r
         set r.status           = 'F',
             r.idusuario        = nvl(r.idusuario, p_idusuario),
             r.idusuarioinicio  = nvl(r.idusuarioinicio, p_idusuario),
             r.idusuariofim     = nvl(r.idusuariofim, p_idusuario),
             r.datahora         = nvl(r.datahora, sysdate),
             r.horainicio       = nvl(r.horainicio, sysdate),
             r.horafim          = nvl(r.horafim, sysdate),
             r.horainicioorigem = nvl(r.horainicioorigem, sysdate),
             r.horafimorigem    = nvl(r.horafimorigem, sysdate)
       where r.idremanejamento = p_idremanejamento;
    
      -- Removendo os endereços filhos da origem quando houver
      RemoveInfMultiEndereco(p_idremanejamento);
    
      -- Finalizar Remanejamento Ordem Devolução (Caso seje)
      pk_ordemdevolucao.finalizarremanejamento(p_idremanejamento);
    
      if r_remanejamento.idprodutorecuperado is not null then
        if r_remanejamento.tipoexportacaoprodrecuperado = 1 then
          pk_integracao.exportarprodutorecuperado(r_remanejamento.idprodutorecuperado);
        elsif r_remanejamento.tipoexportacaoprodrecuperado in (2, 3) then
          pk_integracao.exportarmovimentacaointerna(r_remanejamento.idprodutorecuperado,
                                                    3);
        elsif r_remanejamento.tipoexportacaoprodrecuperado in (4, 5, 6) then
          pk_integracao.exportarProdutoRecuperadoMV(r_remanejamento.idprodutorecuperado,
                                                    r_remanejamento.tipoexportacaoprodrecuperado);
        end if;
      end if;
    
      if r_remanejamento.idcontroleavaria is not null then
        pk_integracao.exportarControleAvaria(r_remanejamento.idcontroleavaria);
        pk_integracao.exportarMovimentacaoInterna(r_remanejamento.idcontroleavaria,
                                                  1);
      end if;
    
      if r_remanejamento.idinsucessoentrega is not null then
        select count(*)
          into v_existeCRN
          from remanejamento r
         where r.idinsucessoentrega = r_remanejamento.idinsucessoentrega
           and r.idremanejamento <> p_idremanejamento
           and r.status <> 'F';
      
        if v_existeCRN = 0 then
          pk_integracao.exportarMovimentacaoInterna(r_remanejamento.idinsucessoentrega,
                                                    5);
        
          update insucessoentrega
             set status = 3
           where id = r_remanejamento.idinsucessoentrega;
        end if;
      end if;
    
      pk_integracao.expRemanejamentoEntreSetores(p_idremanejamento);
    
      pk_utilities.GeraLog(p_idusuario,
                           'O REMANEJAMENTO ' || p_idremanejamento ||
                            ' FOI EXECUTADO COM SUCESSO.', p_idremanejamento,
                           'RP');
    
      execOrigemRemBufferPK;
    end if;
  end;

  procedure finalizarRemanejamentoWEB
  (
    p_idremanejamento in number,
    p_idusuario       in number
  ) is
    v_Pendentes  varchar2(2000);
    v_finalizado char(1);
    v_msg        t_message;
  begin
    /*Verifica se não existe remanejamentos anteriores para o endereço de origem */
    select status
      into v_finalizado
      from remanejamento
     where idremanejamento = p_idremanejamento;
  
    if v_finalizado <> 'F' then
      select (select stragg(r.idremanejamento) pendente
                 from remanejamento r, loteremanejamento lr
                where r.idarmazemdestino = rp.idarmazemorigem
                  and r.idlocaldestino = rp.idlocalorigem
                  and r.status <> 'F'
                  and lr.idremanejamento = r.idremanejamento
                  and r.datahora < rp.datahora
                  and r.idremanejamento < rp.idremanejamento
                  and exists
                (select 1
                         from loteremanejamento
                        where idremanejamento = rp.idremanejamento
                          and idlote = lr.idlote))
        into v_Pendentes
        from remanejamento rp
       where rp.idremanejamento = p_idremanejamento
         and rp.status <> 'F';
    
      if v_pendentes is null then
      
        finalizarRemanejamento(p_idremanejamento, p_idusuario,
                               C_REMANEJ_WEB);
      else
        v_msg := t_message('EXISTEM REMANEJAMENTOS PENDENTES QUE DEVEM SER EXECUTADOS ANTERIORMENTE: ' ||
                           '{0}. OPERAÇÃO CANCELADA.');
        v_msg.addParam(v_Pendentes);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    else
      v_msg := t_message('O REMANEJAMENTO JÁ FOI FINALIZADO. OPERAÇÃO CANCELADA.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
  end finalizarRemanejamentoWEB;

  procedure finalizarPlanejamento(p_idremanejamento in number) is
    v_lotes number;
    v_msg   t_message;
  begin
    select count(*)
      into v_lotes
      from loteremanejamento
     where idremanejamento = p_idremanejamento;
  
    if v_lotes = 0 then
      v_msg := t_message('LOTES NÃO VINCULADOS AO REMANEJAMENTO');
      raise_application_error(-20000, v_msg.formatMessage);
    else
      update remanejamento
         set planejado = 'S'
       where idremanejamento = p_idremanejamento
         and planejado = 'N';
    end if;
  end;

  procedure reabrirPlanejamento
  (
    p_idremanejamento in number,
    p_idusuario       in number
  ) is
    v_lotes            number;
    v_status           remanejamento.status%type;
    v_tipolocalorigem  number;
    v_tipolocaldestino number;
    v_msg              t_message;
  begin
    -- Realizando lock e verificando status do remanejamento
    select r.status
      into v_status
      from remanejamento r
     where r.idremanejamento = p_idremanejamento
       for update;
  
    select count(*)
      into v_lotes
      from loteremanejamento
     where idremanejamento = p_idremanejamento
       and conferido = 'S';
  
    select lo.tipo, ld.tipo
      into v_tipolocalorigem, v_tipolocaldestino
      from remanejamento r, local lo, local ld
     where r.idremanejamento = p_idremanejamento
       and lo.idlocal = r.idlocalorigem
       and lo.idarmazem = r.idarmazemorigem
       and ld.idlocal = r.idlocaldestino
       and ld.idarmazem = r.idarmazemdestino;
  
    if v_tipolocalorigem = 0
       and (v_tipolocaldestino = 1 or v_tipolocaldestino = 2) then
      v_msg := t_message('O PLANEJAMENTO NÃO PODE SER REABERTO PARA REMANEJAMENTOS DE PICKING PARA PULMÃO');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if v_status = 'F' then
      v_msg := t_message('O PLANEJAMENTO NÃO PODE SER REABERTO. REMANEJAMENTO JÁ FINALIZADO.');
      raise_application_error(-20000, v_msg.formatMessage);
    elsif v_lotes > 0
          or v_status <> 'A' then
      v_msg := t_message('O PLANEJAMENTO NÃO PODE SER REABERTO. REMANEJAMENTO JÁ INICIADO.');
      raise_application_error(-20000, v_msg.formatMessage);
    else
      update remanejamento
         set planejado = 'N'
       where idremanejamento = p_idremanejamento
         and planejado = 'S';
    
      pk_utilities.GeraLog(p_idusuario,
                           'PLANEJAMENTO REABERTO PARA O ID: ' ||
                            P_IDREMANEJAMENTO, P_IDREMANEJAMENTO, 'RP');
    end if;
  end;

  /*
   * Carrega o resumo das embalagens a serem utilizadas
   * a partir do produto, local e da qtde a ser movimentada
  */
  function retResumoEmbalagensLocal
  (
    p_idproduto in number,
    p_qtde      in number,
    p_idlocal   in local.idlocal%type
  ) return string is
  
    cursor c_emb
    (
      p_produto in number,
      p_rest    in number,
      p_idlocal in local.idlocal%type
    ) is
      select e.barra, e.fatorconversao, e.descrreduzido
        from embalagem e, lote l, lotelocal ll
       where e.idproduto = p_idproduto
         and trunc(p_rest / e.fatorconversao) > 0
         and e.ativo = 'S'
         and l.idproduto = e.idproduto
         and l.barra = e.barra
         and ll.idlote = l.idlote
         and ll.idlocal = p_idlocal
         and ll.estoque > 0
       order by e.fatorconversao desc;
  
    r_emb           c_emb%rowtype;
    v_resumo        varchar2(1000);
    v_qtdeUtilizada number;
    v_qtde          number;
  begin
    v_qtde := p_qtde;
  
    open c_emb(p_idproduto, v_qtde, p_idlocal);
    fetch c_emb
      into r_emb;
    while (v_qtde > 0)
          and (c_emb%found)
    loop
      v_qtdeUtilizada := trunc(v_qtde / r_emb.fatorconversao);
      if v_qtdeUtilizada > 0 then
        v_qtde := v_qtde - (v_qtdeUtilizada * r_emb.fatorconversao);
      
        if v_resumo is not null then
          v_resumo := v_resumo || ', ';
        end if;
      
        v_resumo := v_resumo || v_qtdeUtilizada || ' ' ||
                    r_emb.descrreduzido || ' [' || r_emb.fatorconversao || ']';
      
      end if;
      fetch c_emb
        into r_emb;
    end loop;
    close c_emb;
  
    return v_resumo;
  
  end;

  procedure associarLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_quantidade      in number,
    p_idusuario       in number
  ) is
    v_idproduto            number;
    v_idarmazemorigem      number;
    v_idlocalorigem        local.idlocal%type;
    v_idarmazemdestino     number;
    v_total                number;
    v_idlocaldestino       local.idlocal%type;
    v_tipolote             char(1);
    v_result               varchar(500);
    v_pkpl                 number;
    v_travaLocalIntEsteira number;
    v_produtoCodigoInt     produto.codigointerno%type;
    v_msg                  t_message;
  
    procedure regraLoteUnico(p_idLote in lote.idlote%type) is
      r_loteUnicoComparar pk_lote.t_loteunico;
      v_idarmazemdestino  number;
      v_idlocaldestino    local.idlocal%type;
      v_msgerro           varchar2(5000);
    begin
    
      select lt.idproduto, lt.estado, lt.descr loteindustria,
             lt.dtvenc dtvencimento, pd.loteuniconoendereco,
             lt.iddepositante, pd.vencimentouniconoendereco
        into r_loteUnicoComparar
        from lote lt, produtodepositante pd
       where lt.idlote = p_idLote
         and pd.identidade = lt.iddepositante
         and pd.idproduto = lt.idproduto;
    
      select r.idarmazemdestino, r.idlocaldestino
        into v_idarmazemdestino, v_idlocaldestino
        from remanejamento r
       where r.idremanejamento = p_idremanejamento;
    
      for r_loteunico in (select lt.idproduto, lt.estado,
                                 lt.descr loteindustria,
                                 lt.dtvenc dtvencimento,
                                 pd.loteuniconoendereco, lt.iddepositante,
                                 pd.vencimentouniconoendereco
                            from loteremanejamento lr, lote lt,
                                 produtodepositante pd
                           where lr.idremanejamento = p_idremanejamento
                             and pd.idproduto = lt.idproduto
                             and lt.idlote = lr.idlote
                             and pd.identidade = lt.iddepositante
                             and pd.idproduto = lt.idproduto)
      loop
      
        if (not
            pk_lote.isLoteUnicoCompativel(r_loteunicocomparar, r_loteunico,
                                           v_msgerro, v_idarmazemdestino,
                                           v_idlocaldestino)) then
          raise_application_error(-20000, v_msgErro);
        end if;
      
      end loop;
    
      if (not
          pk_lote.isLocalPodeReceberLoteUnico(r_loteunicocomparar,
                                               v_idarmazemdestino,
                                               v_idlocaldestino, v_msgerro)) then
        raise_application_error(-20000, v_msgerro);
      end if;
    end;
  
    procedure validarVinculos is
      v_localOrigem            local.idlocalformatado%type;
      v_localDestino           local.idlocalformatado%type;
      v_tipoLocalOrigem        local.tipo%type;
      v_tipoLocalDestino       local.tipo%type;
      v_tipoPermPkSetorOrigem  setor.tipopermitirpickingsetor%type;
      v_tipoPermPkSetorDestino setor.tipopermitirpickingsetor%type;
      v_localIncompativel      number;
      v_idProduto              produto.idproduto%type;
      v_barra                  embalagem.barra%type;
      v_tipoPkProdDep          produtodepositante.tipopicking%type;
      v_idArmazem              armazem.idarmazem%type;
      v_idLocalDestino         local.idlocal%type;
      v_idEntidade             depositante.identidade%type;
      v_unidades               number;
      v_msg                    t_message;
      v_fatorConversaoLote     embalagem.fatorconversao%type;
      v_qtdeTotalLote          lote.qtdedisponivel%type;
      v_barraUnitaria          number;
      v_existeEstoque          number;
      v_fatorNoEstoque         number;
    begin
    
      select lt.idarmazem, lt.iddepositante, lt.idproduto, e.fatorconversao,
             lt.qtdedisponivel
        into v_idArmazem, v_idEntidade, v_idProduto, v_fatorConversaoLote,
             v_qtdeTotalLote
        from lote lt, embalagem e
       where lt.idlote = p_idlote
         and e.idproduto = lt.idproduto
         and e.barra = lt.barra;
    
      select lo.idlocalformatado localorigem, lo.tipo,
             so.tipopermitirpickingsetor, ld.idlocalformatado localdestino,
             ld.tipo, sd.tipopermitirpickingsetor, ld.idlocal
        into v_localOrigem, v_tipoLocalOrigem, v_tipoPermPkSetorOrigem,
             v_localDestino, v_tipoLocalDestino, v_tipoPermPkSetorDestino,
             v_idLocalDestino
        from remanejamento r, local lo, local ld, setor so, setor sd
       where r.idremanejamento = p_idremanejamento
         and lo.idlocal = r.idlocalorigem
         and lo.idarmazem = r.idarmazemorigem
         and ld.idlocal = r.idlocaldestino
         and ld.idarmazem = r.idarmazemdestino
         and so.idsetor = lo.idsetor
         and sd.idsetor = ld.idsetor;
    
      if (v_tipoLocalDestino = C_LOCAL_PICKING) then
        -- Validando se o produto é compatível com o setor/endereço Destino.
        pk_armazem.validarSetorPickingProduto(v_idArmazem, v_idLocalDestino,
                                              v_idEntidade, v_idProduto);
        if (v_tipoLocalOrigem in
           (C_LOCAL_PULMAO_BLOCADO, C_LOCAL_PULMAO_PALETIZADO)) then
          -- Validando se o setor/endereço Origem é compatível com o setor/endereço Destino.
          if (v_tipoPermPkSetorDestino = C_SETOR_MISTO) then
            return;
          elsif (v_tipoPermPkSetorDestino = C_SETOR_UNIDADES) then
            begin
              select count(1), e.barra
                into v_localIncompativel, v_barra
                from lote lt, produto p, embalagem e
               where lt.idlote = p_idlote
                 and p.idproduto = lt.idproduto
                 and e.idproduto = p.idproduto
                 and e.barra = lt.barra
                 and ((e.fatorconversao = 1 and e.caixafechada = 'S') or
                     e.fatorconversao > 1)
               group by p.idproduto, e.barra;
            exception
              when no_data_found then
                v_localIncompativel := 0;
            end;
          
            if (v_localIncompativel > 0) then
              v_msg := t_message('Local Origem: {0} incompatível com o Local Destino: {1}.' ||
                                 chr(13) ||
                                 'O Produto: {2}  Barra: {3}  Lote: {4}  não pode ser remanejado para um picking que aceita somente Unidades.');
              v_msg.addParam(v_localOrigem);
              v_msg.addParam(v_localDestino);
              v_msg.addParam(v_idProduto);
              v_msg.addParam(v_barra);
              v_msg.addParam(p_idlote);
            
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
          elsif (v_tipoPermPkSetorDestino = C_SETOR_CAIXAS) then
            begin
              select count(1), e.barra
                into v_localIncompativel, v_barra
                from lote lt, produto p, embalagem e
               where lt.idlote = p_idlote
                 and p.idproduto = lt.idproduto
                 and e.idproduto = p.idproduto
                 and e.barra = lt.barra
                 and e.fatorconversao = 1
                 and e.caixafechada = 'N'
               group by p.idproduto, e.barra;
            exception
              when no_data_found then
                v_localIncompativel := 0;
            end;
          
            if v_localIncompativel > 0 then
              v_msg := t_message('Local Origem: {0} incompatível com o Local Destino: {1}.' ||
                                 chr(13) ||
                                 'O Produto: {2}  Barra: {3}  Lote: {4}  não pode ser remanejado para um picking que aceita somente Caixas.');
              v_msg.addParam(v_localOrigem);
              v_msg.addParam(v_localDestino);
              v_msg.addParam(v_idProduto);
              v_msg.addParam(v_barra);
              v_msg.addParam(p_idlote);
            
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          
            select count(1)
              into v_existeEstoque
              from remanejamento r, local ld, lotelocal ll
             where r.idremanejamento = p_idremanejamento
               and ld.idlocal = r.idlocaldestino
               and ld.idarmazem = r.idarmazemdestino
               and ll.idlocal = ld.idlocal
               and ll.idarmazem = ld.idarmazem
               and (ll.estoque > 0 or ll.pendencia > 0 or ll.adicionar > 0);
          
            if v_existeEstoque > 0 then
              begin
                select distinct e.fatorconversao
                  into v_fatorNoEstoque
                  from remanejamento r, lotelocal ll, lote lt, embalagem e
                 where r.idremanejamento = p_idremanejamento
                   and ll.idlocal = r.idlocaldestino
                   and lt.idlote = ll.idlote
                   and (ll.estoque > 0 or ll.pendencia > 0 or
                       ll.adicionar > 0)
                   and e.idproduto = lt.idproduto
                   and e.barra = lt.barra;
              exception
                when too_many_rows then
                  v_msg := t_message('Verifique o endereço de destino pois Picking pertencente à um Setor configurado para ¿Permitir Picking: Caixas¿ não pode ter estoque com diferentes fatores de conversão.');
                  raise_application_error(-20000, v_msg.formatMessage);
              end;
            
              if v_fatorNoEstoque <> v_fatorConversaoLote then
                v_msg := t_message('O endereço destino é um Picking pertencente à um Setor configurado para ¿Permitir Picking: Caixas¿ e existe estoque com fator de conversão {0}.' ||
                                   chr(13) ||
                                   'Selecione uma embalagem com o mesmo fator de conversão ou escolha outro endereço para o remanejamento.');
                v_msg.addParam(v_fatorNoEstoque);
              
                raise_application_error(-20000, v_msg.formatMessage);
              end if;
            end if;
          end if;
        
        elsif (v_tipoLocalOrigem = C_LOCAL_PICKING) then
        
          if (v_tipoPermPkSetorOrigem = C_SETOR_CAIXAS and
             v_tipoPermPkSetorDestino = C_SETOR_UNIDADES) then
            begin
              select count(1)
                into v_barraUnitaria
                from lote lt, embalagem e
               where lt.idlote = p_idlote
                 and e.idproduto = lt.idproduto
                 and e.barra = lt.barra
                 and e.fatorconversao = 1
                 and e.caixafechada = 'N'
                 and e.ativo = 'S'
                 and e.precadastro = 'N';
            exception
              when no_data_found then
                v_barraUnitaria := 0;
            end;
          
            if not (v_barraUnitaria > 0) then
              if (verificaCompOrigemDestino(v_qtdeTotalLote,
                                            v_fatorConversaoLote,
                                            p_quantidade)) then
                return;
              else
                v_msg := t_message('A quantidade em unidades {0} escolhida para o remanejamento, não permite manter a compatibilidade das configurações dos setores nos endereços de Origem e Destino.' ||
                                   chr(13) || 'Escolha outra quantidade.');
                v_msg.addParam(p_quantidade);
                raise_application_error(-20000, v_msg.formatMessage);
              end if;
            end if;
          
          elsif (v_tipoPermPkSetorOrigem = C_SETOR_UNIDADES and
                v_tipoPermPkSetorDestino = C_SETOR_CAIXAS) then
          
            v_msg := t_message('O Produto[ idProduto: {0} ] está em um Picking pertencente à um Setor configurado para ¿Permitir Picking: Unidades¿ e o destino é um Picking pertencente à um Setor configurado para ¿Permitir Picking: Caixas¿.' ||
                               chr(13) ||
                               'Este Picking só poderá receber remanejamentos vindos do Pulmão ou de outro Picking pertencente à um Setor configurado para ¿Permitir Picking: Caixas¿.');
            v_msg.addParam(v_idProduto);
          
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      end if;
    end validarVinculos;
  
  begin
    if p_quantidade <= 0 then
      v_msg := t_message('Quantidade não pode ser menor ou igual a zero');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    select count(*)
      into v_pkpl
      from remanejamento r, local lo, local ld
     where lo.idarmazem = r.idarmazemorigem
       and lo.idlocal = r.idlocalorigem
       and ld.idarmazem = r.idarmazemdestino
       and ld.idlocal = r.idlocaldestino
       and lo.tipo = 0 -- picking = 'S'
       and ld.tipo in (1, 2) --picking = 'N'
       and r.idcontroleavaria is null
       and r.idremanejamento = p_idremanejamento;
  
    if v_pkpl <> 0 then
      v_msg := t_message('Não é possível Incluir Lotes em Remanejamentos de Picking para Pulmão');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarVinculos;
  
    pk_lote.validarProdutoFracionado(p_idlote, p_quantidade);
  
    select count(*)
      into v_total
      from loteremanejamento lr
     where lr.idremanejamento = p_idremanejamento
       and idlote = p_idlote;
    if v_total > 0 then
      desassociarLote(p_idremanejamento, p_idlote, p_idusuario);
    end if;
  
    select tipolote, idproduto
      into v_tipolote, v_idproduto
      from lote
     where idlote = p_idlote;
  
    select idarmazemorigem, idlocalorigem, idarmazemdestino, idlocaldestino
      into v_idarmazemorigem, v_idlocalorigem, v_idarmazemdestino,
           v_idlocaldestino
      from remanejamento
     where idremanejamento = p_idremanejamento;
  
    pk_lote.validarLoteDispMovimentacao(p_idlote, v_idlocalorigem,
                                        v_idarmazemorigem, v_idlocaldestino,
                                        v_idarmazemdestino);
  
    select count(l.idlocal)
      into v_travaLocalIntEsteira
      from remanejamento r, local l, setor s
     where r.idremanejamento = p_idremanejamento
       and s.idsetor = l.idsetor
       and ((l.idlocal = v_idlocalorigem and
           l.idarmazem = v_idarmazemorigem and l.tipo in (1, 2) and
           length(trim(s.codintegracaoesteira)) is null) or
           (l.idlocal = v_idlocaldestino and
           l.idarmazem = v_idarmazemdestino and l.tipo = 0 and
           length(trim(s.codintegracaoesteira)) is not null));
  
    if (v_travaLocalIntEsteira = 2) then
      begin
        select pd.codigointerno
          into v_produtoCodigoInt
          from lote lt, produto pd, embalagem emb
         where lt.idlote = p_idlote
           and pd.idproduto = lt.idproduto
           and emb.idproduto = pd.idproduto
           and emb.barra = lt.barra
           and (emb.fatorconversao = 1 and emb.caixafechada = 'N')
           and rownum = 1;
      
        v_msg := t_message('Não é possível vincular as unidades do produto cod: "' ||
                           '{0}" nesse remanejamento.' || CHR(13) ||
                           'Esse remanejamento possui o endereço de destino id: "' ||
                           '{1}" parametrizado para ser do tipo picking com setor que utiliza integração com esteira.');
        v_msg.addParam(v_produtoCodigoInt);
        v_msg.addParam(v_idlocaldestino);
        raise_application_error(-20000, v_msg.formatMessage);
      exception
        when no_data_found then
          null;
      end;
    end if;
  
    v_result := ctrlVincularMaterial(p_idlote, v_tipolote, v_idproduto,
                                     v_idarmazemorigem, v_idlocalorigem,
                                     v_idarmazemdestino, v_idlocaldestino,
                                     p_quantidade);
  
    if v_result is not null then
      raise_application_error(-20000, v_result);
    end if;
  
    regraLoteUnico(p_idlote);
  
    insert into loteremanejamento
      (idremanejamento, idlote, qtde, conferido, controlaqtde)
    values
      (p_idremanejamento, p_Idlote, p_quantidade, 'N', 'S');
  
    associar(p_idremanejamento, p_idlote);
  end;

  procedure desassociarLote
  (
    p_idremanejamento in number,
    p_idlote          in number,
    p_idusuario       in number
  ) is
  begin
  
    DESASSOCIAR(p_idremanejamento, p_idlote);
  
    delete from loteremanejamento
     where idremanejamento = p_idremanejamento
       and idlote = p_idlote;
  end;

  procedure MarcarImpressoRemanejamento
  (
    p_idremanejamento in number,
    p_idusuario       in number
  ) is
    v_usuario usuario.nomeusuario%type;
  begin
    select nomeusuario
      into v_usuario
      from usuario
     where idusuario = p_idusuario;
  
    update loteremanejamento
       set impresso = 'S'
     where idremanejamento = p_idremanejamento;
  
    pk_utilities.GeraLog(p_idusuario,
                         'REMANEJAMENTO ID:' || p_idremanejamento ||
                          ' MARCADO COMO IMPRESSO PELO USUARIO ID:' ||
                          p_idusuario || ' nome: ' || v_usuario,
                         p_idremanejamento, 'RM');
  end;

  procedure formarLotePickingPulmao
  (
    p_idremanejamento in number,
    p_idusuario       in number,
    p_moduloSistema   in number := 0
  ) is
    MODULO_ENTERPRISE constant number := 0;
    MODULO_MWMS       constant number := 1;
  
    r_remanejamento remanejamento%rowtype;
  
    v_msg             t_message;
    v_mgsContratoLote historicomudancacontratolote.mensagem%type;
  
    procedure validacoes is
      v_jaPossuiLoteVinculado number;
      v_caixaNaoInformada     number;
      r_loteunicocomparar     pk_lote.t_loteunico;
      v_msgerro               varchar2(4000);
    
      v_existeLoteSemPeso           number;
      v_existeInfoEspecNaoInformada number;
    
      C_PRODUTO_SEGREGADO constant number := 1;
    
      procedure validarProdutoSegregado is
        v_fatorOrigem  number;
        v_fatorDestino number;
      begin
        for r in (select g.idproduto, g.iddepositante
                    from gtt_formarloteremanejamento g, produtodepositante pd
                   where pd.tipopicking = C_PRODUTO_SEGREGADO
                     and pd.idproduto = g.idproduto
                     and pd.identidade = g.iddepositante
                   group by g.idproduto, g.iddepositante)
        loop
        
          select l.fatorconversao
            into v_fatorOrigem
            from lotelocal lo, lote l
           where lo.idlocal = r_remanejamento.idlocalorigem
             and lo.idarmazem = r_remanejamento.idarmazemorigem
             and l.idproduto = r.idproduto
             and l.idlote = lo.idlote
             and rownum = 1;
        
          begin
            select l.fatorconversao
              into v_fatorDestino
              from lotelocal ld, lote l
             where ld.idlocal = r_remanejamento.idlocaldestino
               and ld.idarmazem = r_remanejamento.idarmazemdestino
               and l.idproduto = r.idproduto
               and l.idlote = ld.idlote
               and rownum = 1;
          exception
            when no_data_found then
              v_fatorDestino := 0;
          end;
        
          if (v_fatorDestino > 0 and v_fatorDestino <> v_fatorOrigem) then
            v_msg := t_message('Local de origem e local de destino, devem possuir lotes ' ||
                               'com mesmo fator, para produtos segregados. Produto sendo ' ||
                               'remanejado {0}');
            v_msg.addParam(p_idremanejamento);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end loop;
      end validarProdutoSegregado;
    begin
      if (r_remanejamento.planejado = 'S') then
        v_msg := t_message('O remanejamento {0}' ||
                           ' já possui planejamento finalizado.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_jaPossuiLoteVinculado
        from loteremanejamento lr
       where lr.idremanejamento = p_idremanejamento;
    
      if (v_jaPossuiLoteVinculado > 0) then
        v_msg := t_message('O remanejamento {0}' ||
                           ' já possui lotes gerados.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(1)
        into v_caixaNaoInformada
        from armazem a
       where a.idarmazem = r_remanejamento.idarmazemorigem
         and a.indicaqtdecaixaremanejamento = 1
         and exists (select 1
                from gtt_formarloteremanejamento g
               where g.idtipocaixa is null);
    
      if (v_caixaNaoInformada = 1) then
        v_msg := t_message('A configuração do armazém esta definida para que o tipo de caixa seja obrigatório. Selecione um tipo de caixa.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      validarProdutoSegregado;
    
      -- validar lote unico no destino
      for r_produto in (select g.iddepositante, g.idproduto, g.estado,
                               g.loteindustria, g.dtvenc,
                               pd.loteuniconoendereco
                          from gtt_formarloteremanejamento g,
                               produtodepositante pd
                         where pd.idproduto = g.idproduto
                           and pd.identidade = g.iddepositante)
      loop
        r_loteunicocomparar.idProduto           := r_produto.idproduto;
        r_loteunicocomparar.estado              := r_produto.estado;
        r_loteunicocomparar.loteindustria       := r_produto.loteindustria;
        r_loteunicocomparar.dtvencimento        := r_produto.dtvenc;
        r_loteunicocomparar.loteuniconoendereco := r_produto.loteuniconoendereco;
        r_loteunicocomparar.iddepositante       := r_produto.iddepositante;
      
        if (not pk_lote.isLocalPodeReceberLoteUnico(r_loteunicocomparar,
                                                    r_remanejamento.idarmazemdestino,
                                                    r_remanejamento.idlocaldestino,
                                                    v_msgerro)) then
          raise_application_error(-20000, v_msgerro);
        end if;
      end loop;
    
      select count(*)
        into v_existeLoteSemPeso
        from dual
       where exists (select 1
                from gtt_formarloteremanejamento g
               where g.idremanejamento = p_idremanejamento
                 and g.peso is null
                 and exists
               (select 1
                        from configuracao c
                       where c.ativo = 'S'
                         and c.pesagemremanejamento = 'S'));
    
      if (v_existeLoteSemPeso = 1) then
        v_msg := t_message('A configuração geral esta parâmetrizada para que os produtos sejam pesados, porém existem produtos não pesados.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      select count(*)
        into v_existeInfoEspecNaoInformada
        from dual
       where exists
       (select 1
                from gtt_formarloteremanejamento g
               where g.idloteinfoespec is null
                 and exists
               (select 1
                        from produtodepositante pd
                       where pd.identidade = g.iddepositante
                         and pd.idproduto = g.idproduto
                         and pd.rastrearinfoespecifica = 0
                         and exists
                       (select 1
                                from informacaomatdep im
                               where im.identidade = pd.identidade
                                 and im.idproduto = pd.idproduto)));
    
      if (v_existeInfoEspecNaoInformada = 1) then
        v_msg := t_message('Todos os produtos que trabalham com informação especifica devem ser especificados.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validacoes;
  
    procedure formarLotes is
      cursor c_produto is
        select g.idproduto, g.estado, g.iddepositante, g.itemadicional,
               g.loteindustria, g.dtvenc, g.dtfabricacao, g.qtde,
               e.fatorconversao, e.lastro, e.qtdecamada, g.idtipocaixa,
               g.loteadicional, g.idloteinfoespec, g.peso, g.barra,
               g.liberado, g.idusuariobloqueio, g.motivobloqueio,
               g.idmotivobloqueio, g.databloqueio, g.hashcomplotekit,
               e.caixafechada
          from gtt_formarloteremanejamento g, embalagem e
         where e.barra = g.barra
           and e.idproduto = g.idproduto;
    
      r_produto c_produto%rowtype;
    
      v_metodoger_incompl_sobra number;
      v_dispCoberturaAntes      number;
      v_dispCoberturaDepois     number;
    
      procedure moverSeparacaoEspecifica
      (
        p_idloteOrigem     in number,
        p_idarmazemorigem  in number,
        p_idlocalorigem    in varchar2,
        p_qtde             in number,
        p_idloteDestino    in number,
        p_idarmazemDestino in number,
        p_idlocalDestino   in varchar2
      ) is
        r_sepNova              separacaoespecifica%rowtype;
        r_seploteindsepespecif seploteindsepespecif%rowtype;
        v_idSepLoteInd         number;
      begin
        for r_sepespecifica in (select *
                                  from separacaoespecifica se
                                 where se.idarmazem = p_idarmazemorigem
                                   and se.idlocal = p_idlocalorigem
                                   and se.idlote = p_idloteOrigem
                                   and exists
                                 (select 1
                                          from notafiscal nf
                                         where nf.tipo = 'S'
                                           and nf.statusnf in
                                               ('N', 'C', 'I', 'B')
                                           and (nf.statusroteirizacao = 0 or
                                               nf.statusroteirizacao = 1)
                                           and se.idnotafiscal =
                                               nf.idnotafiscal))
        loop
        
          if ((r_sepespecifica.qtde - p_qtde) > 0) then
            update separacaoespecifica se
               set se.qtde = se.qtde - p_qtde
             where se.id = r_sepespecifica.id;
            pk_utilities.GeraLog(p_idUsuario,
                                 'Removeu a quantidade ' || p_qtde ||
                                  ' da separação especifica Id: ' ||
                                  r_sepespecifica.id ||
                                  ' por remanejamento picking para pulmão, remanejamento Id: ' ||
                                  p_idremanejamento, r_sepespecifica.id,
                                 'SE');
          end if;
        
          begin
            select *
              into r_sepNova
              from separacaoespecifica se
             where se.idarmazem = p_idarmazemdestino
               and se.idlocal = p_idlocaldestino
               and se.idlote = p_idloteDestino
               and se.idnotafiscal = r_sepespecifica.idnotafiscal;
          
            r_sepNova.Qtde := r_sepNova.qtde + p_qtde;
          
            update separacaoespecifica
               set row = r_sepNova
             where id = r_sepNova.id;
          
            pk_utilities.GeraLog(p_idUsuario,
                                 'Adicionou a quantidade ' || p_qtde ||
                                  ' a separação especifica Id: ' ||
                                  r_sepNova.id ||
                                  ' por remanejamento picking para pulmão, remanejamento Id: ' ||
                                  p_idremanejamento, r_sepNova.id, 'SE');
          
          exception
            when no_data_found then
              select seq_separacaoespecifica.nextval
                into r_sepNova.id
                from dual;
              r_sepNova.idarmazem      := p_idarmazemdestino;
              r_sepNova.idlocal        := p_idlocaldestino;
              r_sepNova.idlote         := p_idloteDestino;
              r_sepNova.idnotafiscal   := r_sepespecifica.idnotafiscal;
              r_sepNova.qtde           := p_qtde;
              r_sepNova.cadmanual      := r_sepespecifica.cadmanual;
              r_sepNova.fonteseparacao := r_sepespecifica.fonteseparacao;
              r_sepNova.idusuario      := p_idUsuario;
              r_sepNova.dtvinculo      := sysdate;
            
              insert into separacaoespecifica
                (id, idarmazem, idlocal, idlote, idnotafiscal, qtde,
                 cadmanual, fonteseparacao, idusuario, dtvinculo)
              values
                (r_sepNova.id, r_sepNova.idarmazem, r_sepNova.idlocal,
                 r_sepNova.idlote, r_sepNova.idnotafiscal, r_sepNova.qtde,
                 r_sepNova.cadmanual, r_sepNova.fonteseparacao,
                 r_sepNova.Idusuario, r_sepNova.Dtvinculo);
            
              pk_utilities.GeraLog(p_idUsuario,
                                   'Criou a separação especifica Id: ' ||
                                    r_sepNova.id || ' com quantidade ' ||
                                    r_sepNova.qtde ||
                                    ' para Nota Fiscal Id: ' ||
                                    r_sepNova.Idnotafiscal ||
                                    ' para o Lote Id: ' || r_sepNova.Idlote ||
                                    ' no Local ID: ' || r_sepNova.Idlocal ||
                                    ' no Armazém Id: ' ||
                                    r_sepNova.Idarmazem ||
                                    ' por remanejamento picking para pulmão, remanejamento Id: ' ||
                                    p_idremanejamento, r_sepNova.id, 'SE');
          end;
        
          begin
            select sls.idseploteind
              into v_idSepLoteInd
              from seploteindsepespecif sls
             where sls.idsepespecifica = r_sepespecifica.id;
          
            begin
              select *
                into r_seploteindsepespecif
                from seploteindsepespecif s
               where s.idseploteind = v_idSepLoteInd
                 and s.idsepespecifica = r_sepNova.id;
            
              r_seploteindsepespecif.qtde := r_seploteindsepespecif.qtde +
                                             p_qtde;
            
              update seploteindsepespecif r
                 set row = r_seploteindsepespecif
               where r.idsepespecifica =
                     r_seploteindsepespecif.idsepespecifica
                 and r.idseploteind = r_seploteindsepespecif.idseploteind;
            exception
              when no_data_found then
                insert into seploteindsepespecif
                  (idsepespecifica, idseploteind, idlote, qtde)
                values
                  (r_sepNova.id, v_idSepLoteInd, r_sepNova.idlote,
                   r_sepNova.qtde);
            end;
          
            if ((r_sepespecifica.qtde - p_qtde) > 0) then
              update seploteindsepespecif s
                 set s.qtde = s.qtde - p_qtde
               where s.idsepespecifica = r_sepespecifica.id;
            
            else
              delete from seploteindsepespecif s
               where s.idsepespecifica = r_sepespecifica.id
                 and s.idseploteind = v_idSepLoteInd;
            end if;
          exception
            when no_data_found then
              v_idSepLoteInd := null;
          end;
        
          if ((r_sepespecifica.qtde - p_qtde) <= 0) then
            delete from separacaoespecifica se
             where se.id = r_sepespecifica.id;
          
            pk_utilities.GeraLog(p_idUsuario,
                                 'Removeu a separação especifica Id: ' ||
                                  r_sepespecifica.id || ' com quantidade ' ||
                                  r_sepespecifica.qtde ||
                                  ' para Nota Fiscal Id: ' ||
                                  r_sepespecifica.Idnotafiscal ||
                                  ' para o Lote Id: ' ||
                                  r_sepespecifica.Idlote || ' no Local ID: ' ||
                                  r_sepespecifica.Idlocal ||
                                  ' no Armazém Id: ' ||
                                  r_sepespecifica.Idarmazem ||
                                  ' por remanejamento picking para pulmão, remanejamento Id: ' ||
                                  p_idremanejamento, r_sepespecifica.id,
                                 'SE');
          end if;
        end loop;
      end moverSeparacaoEspecifica;
    
      procedure addNovoLoteRemanejamento
      (
        p_idlote in number,
        p_qtde   in number,
        p_peso   in number
      ) is
        v_complementar lotelocal.complementar%type;
      
      begin
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde,
           diferenca, liberado, impetiqueta, peso)
        values
          (p_idremanejamento, p_idlote, p_qtde, 'N', 'S', 0, 'S', 'S',
           p_peso);
      
        if (p_peso is not null) then
          update lote lt
             set lt.pesobruto = p_peso
           where lt.idlote = p_idlote;
        end if;
      
        v_complementar := 'ESTOQUE ADICIONADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                          p_idremanejamento;
        pk_estoque.incluir_estoque(r_remanejamento.idarmazemorigem,
                                   r_remanejamento.idlocalorigem, p_idlote,
                                   p_qtde, p_idusuario, v_complementar, 'N');
      
        v_complementar := 'AUMENTADO PENDENCIA EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                          p_idremanejamento;
        pk_estoque.incluir_pendencia(r_remanejamento.idarmazemorigem,
                                     r_remanejamento.idlocalorigem, p_idlote,
                                     p_qtde, p_idusuario, v_complementar);
      
        v_complementar := 'AUMENTADO ADICIONAR EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                          p_idremanejamento;
        pk_estoque.incluir_adicionar(r_remanejamento.idarmazemorigem,
                                     r_remanejamento.idlocaldestino,
                                     p_idlote, p_qtde, p_idusuario,
                                     v_complementar);
      
      end addNovoLoteRemanejamento;
    
      procedure usarLoteUnitario(r_produto in c_produto%rowtype) is
        v_complementar lotelocal.complementar%type;
      
      begin
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde,
           diferenca, liberado, impetiqueta, datapesagem, peso)
        values
          (p_idremanejamento, r_produto.idloteinfoespec, 1, 'N', 'S', 0,
           'S', 'S', sysdate, r_produto.peso);
      
        if (r_produto.peso is not null) then
          update lote lt
             set lt.pesobruto = r_produto.peso
           where lt.idlote = r_produto.idloteinfoespec;
        end if;
      
        v_complementar := 'AUMENTADO PENDENCIA EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                          p_idremanejamento;
        pk_estoque.incluir_pendencia(r_remanejamento.idarmazemorigem,
                                     r_remanejamento.idlocalorigem,
                                     r_produto.idloteinfoespec, 1,
                                     p_idusuario, v_complementar);
      
        v_complementar := 'AUMENTADO ADICIONAR EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                          p_idremanejamento;
        pk_estoque.incluir_adicionar(r_remanejamento.idarmazemorigem,
                                     r_remanejamento.idlocaldestino,
                                     r_produto.idloteinfoespec, 1,
                                     p_idusuario, v_complementar);
      
        moverSeparacaoEspecifica(r_produto.idloteinfoespec,
                                 r_remanejamento.idarmazemorigem,
                                 r_remanejamento.idlocalorigem, 1,
                                 r_produto.idloteinfoespec,
                                 r_remanejamento.idarmazemorigem,
                                 r_remanejamento.idlocaldestino);
      
      end usarLoteUnitario;
    
      procedure criarNovosLotes(r_produto in c_produto%rowtype) is
      
        v_qtdeUN number;
      
        procedure inserirNovosLotes is
          r_lote lote%rowtype;
        
          v_qtdeTotalCaixas number;
          v_normaPallet     number;
          v_qtdePallet      number;
          v_caixasPallet    number;
          v_unidadesPallet  number;
          v_qtdeLastro      number;
          v_caixasLastro    number;
          v_unidadesLastro  number;
          v_qtdeCaixas      number;
          v_unidadesCaixas  number;
          v_qtdeUnidades    number;
          v_idlote          number;
        begin
          pk_lote.CalcularQtdeLotes(v_qtdeUN, r_produto.fatorconversao,
                                    r_produto.lastro, r_produto.qtdecamada,
                                    r_produto.caixafechada,
                                    v_metodoger_incompl_sobra,
                                    v_qtdeTotalCaixas, v_normaPallet,
                                    v_qtdePallet, v_caixasPallet,
                                    v_unidadesPallet, v_qtdeLastro,
                                    v_caixasLastro, v_unidadesLastro,
                                    v_qtdeCaixas, v_unidadesCaixas,
                                    v_qtdeUnidades);
        
          -- Informando os dados do Lote   
          r_lote.idproduto         := r_produto.idproduto;
          r_lote.iddepositante     := r_produto.iddepositante;
          r_lote.descr             := r_produto.loteindustria;
          r_lote.dtVenc            := r_produto.dtvenc;
          r_lote.estado            := r_produto.estado;
          r_lote.idUsuario         := p_idusuario;
          r_lote.tipolote          := 'L';
          r_lote.situacao          := 'R';
          r_lote.numerovolume      := 1;
          r_lote.itemadicional     := r_produto.itemadicional;
          r_lote.idtipocaixa       := r_produto.idtipocaixa;
          r_lote.idarmazem         := r_remanejamento.idarmazemorigem;
          r_lote.dtfabricacao      := r_produto.dtfabricacao;
          r_lote.loteadicional     := r_produto.loteadicional;
          r_lote.idusuariobloqueio := r_produto.idusuariobloqueio;
          r_lote.motivobloqueio    := r_produto.motivobloqueio;
          r_lote.idmotivobloqueio  := r_produto.idmotivobloqueio;
          r_lote.databloqueio      := r_produto.databloqueio;
          r_lote.hashcomplotekit   := r_produto.hashcomplotekit;
        
          if (pk_lote.isLoteIndustriaComMaisDeUmVenc(r_produto.iddepositante,
                                                     r_produto.idproduto,
                                                     r_produto.loteindustria,
                                                     r_produto.dtvenc)) then
            raise_application_error(-20000,
                                    'Não é possível cadastrar lote do mesmo produto/depositante com o mesmo lote indústria e data de vencimento diferentes. Depositante:' ||
                                     r_produto.iddepositante ||
                                     '. Produto: ' || r_produto.idproduto ||
                                     ' Lote Indústria: ' ||
                                     r_produto.loteindustria ||
                                     ' Data Venc: ' || r_produto.dtvenc);
          
          end if;
        
          -- Gerando o Lote Pallet
          for i in 1 .. v_qtdePallet
          loop
            r_lote.barra       := r_produto.barra;
            r_lote.qtdeEntrada := v_normaPallet;
            r_lote.tipoPalet   := 'C';
            v_idlote           := pk_lote.cadastrar_lote(r_lote, null, 'N');
          
            if (r_produto.liberado = 'N') then
              update lote lt
                 set lt.liberado = 'N'
               where lt.idlote = v_idlote;
            end if;
          
            addNovoLoteRemanejamento(v_idlote,
                                     v_normaPallet *
                                      r_produto.fatorconversao,
                                     r_produto.peso);
          end loop;
        
          -- Gerando o Lote Lastro
          if v_qtdeLastro > 0 then
            r_lote.barra       := r_produto.barra;
            r_lote.qtdeEntrada := v_caixasLastro;
            r_lote.tipoPalet   := 'I';
            v_idlote           := pk_lote.cadastrar_lote(r_lote, null, 'N');
          
            if (r_produto.liberado = 'N') then
              update lote lt
                 set lt.liberado = 'N'
               where lt.idlote = v_idlote;
            end if;
          
            addNovoLoteRemanejamento(v_idlote,
                                     v_caixasLastro *
                                      r_produto.fatorconversao,
                                     r_produto.peso);
          end if;
        
          -- Gerando o Lote Quebrado - Sobra
          if v_qtdeCaixas > 0 then
            r_lote.barra       := r_produto.barra;
            r_lote.qtdeEntrada := v_qtdeCaixas;
            r_lote.tipoPalet   := 'S';
            v_idlote           := pk_lote.cadastrar_lote(r_lote, null, 'N');
          
            if (r_produto.liberado = 'N') then
              update lote lt
                 set lt.liberado = 'N'
               where lt.idlote = v_idlote;
            end if;
          
            addNovoLoteRemanejamento(v_idlote,
                                     v_qtdeCaixas *
                                      r_produto.fatorconversao,
                                     r_produto.peso);
          end if;
        
          -- Gerando o Lote Quebrado - Unidades
          if v_qtdeUnidades > 0 then
            r_lote.barra       := pk_produto.RetornarCodBarraMenorFator(r_produto.idproduto);
            r_lote.qtdeEntrada := v_qtdeUnidades;
            r_lote.tipoPalet   := 'U';
            v_idlote           := pk_lote.cadastrar_lote(r_lote, null, 'N');
          
            if (r_produto.liberado = 'N') then
              update lote lt
                 set lt.liberado = 'N'
               where lt.idlote = v_idlote;
            end if;
          
            addNovoLoteRemanejamento(v_idlote, v_qtdeUnidades,
                                     r_produto.peso);
          end if;
        end inserirNovosLotes;
      
        procedure consumirLotesAntigos is
          cursor c_loteantigo
          (
            pc_idarmazem       number,
            pc_idlocal         local.idlocal%type,
            pc_idproduto       number,
            pc_estado          lote.estado%type,
            pc_iddepositante   number,
            pc_itemadicional   lote.itemadicional%type,
            pc_dtvenc          date,
            pc_dtfabricacao    date,
            pc_loteindustria   lote.descr%type,
            pc_loteadicional   lote.loteadicional%type,
            pc_hashcomplotekit lote.hashcomplotekit%type
          ) is
            select ll.idarmazem, l.idlote,
                   (ll.estoque - ll.pendencia) disponivelestoque,
                   l.qtdedisponivel qtdecoberta
              from lotelocal ll, lote l
             where ll.idarmazem = pc_idarmazem
               and ll.idlocal = pc_idlocal
               and (ll.estoque - ll.pendencia + ll.adicionar) > 0
               and l.idlote = ll.idlote
               and l.idproduto = pc_idproduto
               and l.estado = pc_estado
               and l.iddepositante = pc_iddepositante
               and case
                     when pc_itemadicional is null then
                      1
                     else
                      decode(l.itemadicional, pc_itemadicional, 1, 0)
                   end = 1
               and decode(trunc(l.dtvenc), trunc(pc_dtvenc), 1, 0) = 1
               and case
                     when pc_dtfabricacao is null then
                      1
                     else
                      decode(trunc(l.dtfabricacao), trunc(pc_dtfabricacao), 1,
                             0)
                   end = 1
               and decode(l.descr, pc_loteindustria, 1,
                          decode(l.descr, 'LOTE DE PICKING PARA PULMÃO', 1, 0)) = 1
               and case
                     when pc_loteadicional is null then
                      1
                     else
                      decode(l.loteadicional, pc_loteadicional, 1, 0)
                   end = 1
               and case
                     when pc_hashcomplotekit is null then
                      1
                     else
                      decode(l.hashcomplotekit, pc_hashcomplotekit, 1, 0)
                   end = 1
             order by l.dtalocacao;
        
          r_loteantigo            c_loteantigo%rowtype;
          v_qtdeUtilizadaUN       number;
          v_qtdeCobertaLoteAntigo number;
          v_complementar          varchar2(200);
        begin
          v_qtdeUtilizadaUN := 0;
          for r_loteantigo in c_loteantigo(r_remanejamento.idarmazemorigem,
                                           r_remanejamento.idlocalorigem,
                                           r_produto.idproduto,
                                           r_produto.estado,
                                           r_produto.iddepositante,
                                           r_produto.itemadicional,
                                           r_produto.dtvenc,
                                           r_produto.dtfabricacao,
                                           r_produto.loteindustria,
                                           r_produto.loteadicional,
                                           r_produto.hashcomplotekit)
          loop
            pk_lote.validarLoteDispMovimentacao(r_loteantigo.idlote,
                                                r_remanejamento.idlocalorigem,
                                                r_remanejamento.idarmazemorigem,
                                                r_remanejamento.idlocaldestino,
                                                r_remanejamento.idarmazemdestino);
          
            if (r_loteantigo.disponivelestoque >= v_qtdeUN) then
              v_qtdeUtilizadaUN := v_qtdeUN;
            else
              v_qtdeUtilizadaUN := r_loteantigo.disponivelestoque;
            end if;
          
            v_qtdeUN := v_qtdeUN - v_qtdeUtilizadaUN;
          
            v_complementar := 'ESTOQUE RETIRADO EM FUNCAO DA FINALIZACAO DO CADASTRO DE LOTE DO REMANEJAMENTO N:' ||
                              p_idremanejamento;
          
            pk_estoque.retirar_estoque(r_loteantigo.idarmazem,
                                       r_remanejamento.idlocalorigem,
                                       r_loteantigo.idlote,
                                       v_qtdeUtilizadaUN, p_idusuario,
                                       v_complementar, 'N');
          
            InserirComposicaoLote(p_idremanejamento, r_loteantigo.idlote,
                                  v_qtdeUtilizadaUN,
                                  r_loteantigo.qtdecoberta);
          
            exit when v_qtdeUN = 0;
          end loop;
        
          if (v_qtdeUN > 0) then
            v_msg := t_message('Não foi possivel encontrar estoque suficiente para o produto.' ||
                               chr(13) || 'IDPRODUTO: {0}' || chr(13) ||
                               'QTDENECESSARIA UN: {1}');
            v_msg.addParam(r_produto.idproduto);
            v_msg.addParam(r_produto.qtde * r_produto.fatorconversao);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        
        end consumirLotesAntigos;
      
        procedure tratarModuloMWMS is
        begin
        
          for r_lotenovo in (select lr.idlote
                               from loteremanejamento lr
                              where lr.idremanejamento = p_idremanejamento)
          loop
            update lote lt
               set (lt.dtfabricacao, lt.loteadicional, lt.itemadicional) =
                   (select la.dtfabricacao, la.loteadicional,
                           la.itemadicional
                      from composicaolote cl, lote la
                     where cl.idlotenovo = lt.idlote
                       and la.idlote = cl.idloteanterior
                       and rownum = 1)
             where lt.idlote = r_lotenovo.idlote;
          end loop;
        
        end tratarModuloMWMS;
      
      begin
        v_qtdeUN := r_produto.qtde * r_produto.fatorconversao;
      
        inserirNovosLotes;
      
        consumirLotesAntigos;
      
        if (p_moduloSistema = MODULO_MWMS) then
          tratarModuloMWMS;
        end if;
      
      end criarNovosLotes;
    
      function getQtdeDispCobertura return number is
        v_qtde number;
      begin
        select sum(lt.qtdedisponivel)
          into v_qtde
          from lotelocal ll, lote lt
         where ll.idarmazem = r_remanejamento.idarmazemorigem
           and ll.idlocal = r_remanejamento.idlocalorigem
           and lt.idlote = ll.idlote;
      
        return v_qtde;
      end getQtdeDispCobertura;
    
      procedure moverSepEspecLotesNovos is
        v_qtdeMover            number;
        v_qtdeEstoqueDispLtAnt number;
        v_qtdeEmSepEspec       number;
      begin
        for r_lt_spEspecifica in (select lr.idlote idLoteNovo,
                                         cl.qtde qtdeFormadaLtNovo,
                                         cl.idloteanterior
                                    from loteremanejamento lr,
                                         composicaolote cl
                                   where lr.idremanejamento =
                                         p_idremanejamento
                                     and cl.idlotenovo = lr.idlote
                                     and exists
                                   (select 1
                                            from separacaoespecifica sep
                                           where sep.idlote =
                                                 cl.idloteanterior
                                             and sep.idlocal =
                                                 r_remanejamento.idlocalorigem
                                             and sep.idarmazem =
                                                 r_remanejamento.idarmazemorigem
                                             and exists
                                           (select 1
                                                    from notafiscal nf
                                                   where nf.tipo = 'S'
                                                     and nf.statusnf in
                                                         ('N', 'C', 'I', 'B')
                                                     and (nf.statusroteirizacao = 0 or
                                                         nf.statusroteirizacao = 1)
                                                     and sep.idnotafiscal =
                                                         nf.idnotafiscal)))
        loop
          select sum(ll.estoque + ll.adicionar - ll.pendencia) qtde
            into v_qtdeEstoqueDispLtAnt
            from lotelocal ll
           where ll.idarmazem = r_remanejamento.idarmazemorigem
             and ll.idlocal = r_remanejamento.idlocalorigem
             and ll.idlote = r_lt_spEspecifica.Idloteanterior
           group by ll.idarmazem, ll.idlocal, ll.idlote;
        
          select sum(sep.qtde)
            into v_qtdeEmSepEspec
            from separacaoespecifica sep
           where sep.idlote = r_lt_spEspecifica.Idloteanterior
             and sep.idarmazem = r_remanejamento.idarmazemorigem
             and sep.idlocal = r_remanejamento.idlocalorigem
             and exists
           (select 1
                    from notafiscal nf
                   where nf.tipo = 'S'
                     and nf.statusnf in ('N', 'C', 'I', 'B')
                     and (nf.statusroteirizacao = 0 or
                         nf.statusroteirizacao = 1)
                     and sep.idnotafiscal = nf.idnotafiscal)
           group by sep.idlote, sep.idlocal, sep.idarmazem;
        
          if (v_qtdeEstoqueDispLtAnt >= v_qtdeEmSepEspec) then
            v_qtdeMover := 0;
          end if;
        
          if (v_qtdeEstoqueDispLtAnt < v_qtdeEmSepEspec) then
            if (r_lt_spEspecifica.Qtdeformadaltnovo <=
               (v_qtdeEmSepEspec - v_qtdeEstoqueDispLtAnt)) then
              v_qtdeMover := r_lt_spEspecifica.Qtdeformadaltnovo;
            end if;
          
            if (r_lt_spEspecifica.Qtdeformadaltnovo >
               (v_qtdeEmSepEspec - v_qtdeEstoqueDispLtAnt)) then
              v_qtdeMover := r_lt_spEspecifica.Qtdeformadaltnovo -
                             (v_qtdeEmSepEspec - v_qtdeEstoqueDispLtAnt);
            end if;
          end if;
        
          if (v_qtdeMover > 0) then
            moverSeparacaoEspecifica(r_lt_spEspecifica.Idloteanterior,
                                     r_remanejamento.idarmazemorigem,
                                     r_remanejamento.idlocalorigem,
                                     v_qtdeMover,
                                     r_lt_spEspecifica.Idlotenovo,
                                     r_remanejamento.idarmazemdestino,
                                     r_remanejamento.idlocaldestino);
          end if;
        
        end loop;
      end moverSepEspecLotesNovos;
    
    begin
    
      select ar.metodogerlotesobraincompl
        into v_metodoger_incompl_sobra
        from armazem ar
       where ar.idarmazem = r_remanejamento.idarmazemorigem;
    
      v_dispCoberturaAntes := getQtdeDispCobertura;
    
      for r_produto in c_produto
      loop
      
        if (r_produto.idloteinfoespec is null) then
          criarNovosLotes(r_produto);
        else
          usarLoteUnitario(r_produto);
        end if;
      
      end loop;
    
      moverSepEspecLotesNovos;
    
      v_dispCoberturaDepois := getQtdeDispCobertura;
    
      if (v_dispCoberturaAntes <> v_dispCoberturaDepois) then
        v_msg := t_message('A quantidade disponivel de cobertura não deve ser alterada por remanejamento de picking para pulmão.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end formarLotes;
  
    procedure controlarPesagemLotes is
      v_pesar configuracao.pesagemremanejamento%type;
    begin
      select c.pesagemremanejamento
        into v_pesar
        from configuracao c
       where c.ativo = 'S';
    
      if (v_pesar = 'N') then
        for r_lote in (select lr.idlote, (e.pesobruto * lr.qtde) pesoteorico
                         from loteremanejamento lr, lote l, embalagem e
                        where e.barra = l.barra
                          and e.idproduto = l.idproduto
                          and l.idlote = lr.idlote
                          and lr.idremanejamento = p_idremanejamento
                          and not exists
                        (select 1
                                 from gtt_formarloteremanejamento g
                                where g.idloteinfoespec = lr.idlote))
        loop
          update loteremanejamento
             set liberado    = 'S',
                 peso        = r_lote.pesoteorico,
                 datapesagem = sysdate
           where idremanejamento = p_idremanejamento
             and idlote = r_lote.idlote;
        end loop;
      end if;
    
    end controlarPesagemLotes;
  
    procedure valorarLotes is
    begin
      for c_loteremanejamento in (select lr.idlote
                                    from loteremanejamento lr
                                   where lr.idremanejamento =
                                         p_idremanejamento
                                     and not exists
                                   (select 1
                                            from gtt_formarloteremanejamento g
                                           where g.idloteinfoespec =
                                                 lr.idlote))
      loop
        delete from gtt_valorarlote;
        pk_lote.valorarLotePeloLoteAnterior(c_loteremanejamento.idlote);
      
        pk_lote.atualizaInfLote(c_loteremanejamento.idlote,
                                C_MOV_CADASTRO_LOTE);
      end loop;
    end valorarLotes;
  
    procedure apagarPickingDinamico is
    begin
      for r_picking in (select distinct lt.idproduto, lt.iddepositante
                          from loteremanejamento lr, lote lt
                         where lr.idremanejamento = p_idremanejamento
                           and lt.idlote = lr.idlote)
      loop
        pk_picking_dinamico.addGttPickingDinamico(r_picking.idproduto,
                                                  r_picking.iddepositante,
                                                  r_remanejamento.idlocalorigem,
                                                  r_remanejamento.idarmazemorigem,
                                                  0);
      
      end loop;
    
      pk_picking_dinamico.deletar_picking_dinamico;
    end apagarPickingDinamico;
  
  begin
  
    select *
      into r_remanejamento
      from remanejamento r
     where r.idremanejamento = p_idremanejamento
       for update;
  
    validacoes;
  
    formarLotes;
  
    controlarPesagemLotes;
  
    valorarLotes;
  
    apagarPickingDinamico;
  
    update remanejamento
       set planejado = 'S'
     where idremanejamento = p_idremanejamento;
  
    pk_utilities.GeraLog(p_idusuario,
                         'LOTES FORMADOS DE PICKING PARA PULMÃO (MODULO SILTWMS). ' ||
                          chr(13) || 'IDREMANEJAMENTO: ' ||
                          p_idremanejamento, p_idremanejamento, 'R');
  
    for c_histContratoLote in (select cl.idlote, cl.idcontrato, cl.prazotroca,
                                      cl.status
                                 from loteremanejamento lr, contratolote cl
                                where lr.idremanejamento = p_idRemanejamento
                                  and cl.idlote = lr.idlote)
    
    loop
      if c_histContratoLote.Idcontrato is null then
        v_mgsContratoLote := 'INCLUÍDO REGISTRO PARA VINCULAR CONTRATO AO LOTE ID: ' ||
                             c_histContratoLote.Idlote ||
                             ' EM FUNÇÃO DO REMANEJAMENTO ID: ' ||
                             p_idRemanejamento;
      else
        v_mgsContratoLote := 'VINCULADO O LOTE ID: ' ||
                             c_histContratoLote.Idlote ||
                             ' AO CONTRATO ID: ' ||
                             c_histContratoLote.Idcontrato ||
                             ' EM FUNÇÃO DO REMANEJAMENTO ID: ' ||
                             p_idRemanejamento;
      end if;
      pk_contrato.historicoMudancaContratoLote(c_histContratoLote.Idcontrato,
                                               c_histContratoLote.Idlote,
                                               c_histContratoLote.Prazotroca,
                                               p_idusuario, 1,
                                               v_mgsContratoLote,
                                               c_histContratoLote.Status);
    end loop;
  end formarLotePickingPulmao;

  procedure gerarRemPerdaCorteFisico(p_idusuario in number) is
    cursor c_lotesRemanejar is
      select g.idarmazem, g.idlocalorigem, g.idlote, g.qtde, g.idcortefisico,
             g.idromaneio, e.comprimento * e.altura * e.largura cubagem,
             e.pesobruto, e.barra, lt.idproduto, lt.iddepositante,
             e.descrreduzido, l.picking, nvl(p.fracionado, 'N') fracionado
        from GTT_REMANEJA_CORTE G, lote lt, embalagem e, local l, produto p
       where lt.idlote = g.idlote
         and lt.idarmazem = g.idarmazem
         and e.barra = lt.barra
         and e.idproduto = lt.idproduto
         and l.idlocal = g.idlocalorigem
         and l.idarmazem = g.idarmazem
         and p.idproduto = lt.idproduto;
  
    cursor c_locaisDisponiveisSetorPerda
    (
      p_idArmazem     number,
      p_iddepositante number,
      p_idproduto     number,
      p_idlocal       local.idlocal%type
    ) is
      select lp.idlocal,
             (lp.cubagemMaxima - nvl(lp.cubagemOcupada, 0)) cubagemDisponivel,
             (lp.pesomaximo - nvl(lp.pesoOcupado, 0)) pesoDisponivel
        from (select l.idlocal,
                      (l.comprimento * (l.altura - l.alturamanobra) *
                       l.largura) cubagemMaxima, l.pesomaximo,
                      (select sum((e.comprimento * e.largura * e.altura) *
                                    (ll.estoque + ll.adicionar))
                          from lotelocal ll, lote lt, embalagem e
                         where ll.idarmazem = l.idarmazem
                           and ll.idlocal = l.idlocal
                           and lt.idlote = ll.idlote
                           and e.barra = lt.barra
                         group by ll.idlocal) cubagemOcupada,
                      (select sum(e.pesobruto * (ll.estoque + ll.adicionar))
                          from lotelocal ll, lote lt, embalagem e
                         where ll.idarmazem = l.idarmazem
                           and ll.idlocal = l.idlocal
                           and lt.idlote = ll.idlote
                           and e.barra = lt.barra
                         group by ll.idlocal) pesoOcupado
                 from local l, setor s
                where l.idarmazem = p_idArmazem
                  and s.idsetor = l.idsetor
                  and s.perda = 1
                  and exists (select 1
                         from setordepositante sd
                        where sd.idsetor = l.idsetor
                          and sd.iddepositante = p_iddepositante)
                  and exists (select 1
                         from setorproduto sp
                        where sp.idsetor = l.idsetor
                          and sp.idproduto = p_idproduto)
                  and l.idlocal <> p_idlocal) lp;
  
    r_lotesRemanejar              c_lotesRemanejar%rowtype;
    r_locaisDisponiveisSetorPerda c_locaisDisponiveisSetorPerda%rowtype;
    v_idRemanejamento             number;
    v_quantidadeAlocar            number;
    v_qtdRemanejar                number;
    v_qtdRemanejada               number;
    v_qtdPossivelAlocar           number;
    v_msg                         t_message;
  begin
    open c_lotesRemanejar;
    fetch c_lotesRemanejar
      into r_lotesRemanejar;
  
    if (c_lotesRemanejar%notfound) then
      close c_lotesRemanejar;
      return;
    end if;
  
    while (c_lotesRemanejar%found)
    loop
      if (r_lotesRemanejar.Picking = 'N') then
        pk_estoque.retirar_pendencia(r_lotesRemanejar.Idarmazem,
                                     r_lotesRemanejar.Idlocalorigem,
                                     r_lotesRemanejar.Idlote,
                                     r_lotesRemanejar.Qtde, p_idusuario,
                                     p_complementar => 'RETIRANDO PENDENCIA PARA MOVIMENTACAO PARA SETOR DE PERDA IDCORTE: ' ||
                                                        r_lotesRemanejar.Idcortefisico,
                                     p_idmovimentacao => NULL);
      end if;
    
      v_qtdRemanejar := r_lotesRemanejar.Qtde;
    
      if (c_locaisDisponiveisSetorPerda%isopen) then
        close c_locaisDisponiveisSetorPerda;
      end if;
    
      open c_locaisDisponiveisSetorPerda(r_lotesRemanejar.Idarmazem,
                                         r_lotesRemanejar.Iddepositante,
                                         r_lotesRemanejar.Idproduto,
                                         r_lotesRemanejar.Idlocalorigem);
      fetch c_locaisDisponiveisSetorPerda
        into r_locaisDisponiveisSetorPerda;
    
      if (c_locaisDisponiveisSetorPerda%notfound) then
        v_msg := t_message('Não foi possivel encontrar locais em setor de perdas para remanejar o produto Id: ' ||
                           '{0} pertencente ao depositante Id: ' ||
                           '{1} em função do aceite do corte físico Id: {2}');
        v_msg.addParam(r_lotesRemanejar.Idproduto);
        v_msg.addParam(r_lotesRemanejar.Iddepositante);
        v_msg.addParam(r_lotesRemanejar.Idcortefisico);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      while ((c_locaisDisponiveisSetorPerda%found) and (v_qtdRemanejar > 0))
      loop
        v_idRemanejamento   := 0;
        v_qtdPossivelAlocar := 0;
        if ((r_locaisDisponiveisSetorPerda.Cubagemdisponivel /
           r_lotesRemanejar.Cubagem) > (r_locaisDisponiveisSetorPerda.Pesodisponivel /
           r_lotesRemanejar.Pesobruto)) then
          v_qtdPossivelAlocar := r_locaisDisponiveisSetorPerda.Pesodisponivel /
                                 r_lotesRemanejar.Pesobruto;
        
        else
          v_qtdPossivelAlocar := r_locaisDisponiveisSetorPerda.Cubagemdisponivel /
                                 r_lotesRemanejar.Cubagem;
        end if;
      
        if (r_lotesRemanejar.Fracionado = 'N') then
          v_qtdPossivelAlocar := trunc(v_qtdPossivelAlocar);
        end if;
      
        if (v_qtdPossivelAlocar > 0) then
          v_idRemanejamento := cadastrar_remanejamento(r_lotesRemanejar.Idarmazem,
                                                       r_lotesRemanejar.Idarmazem,
                                                       r_lotesRemanejar.Idlocalorigem,
                                                       r_locaisDisponiveisSetorPerda.Idlocal,
                                                       p_idusuario, null,
                                                       'REMANEJAMENTO PARA SETOR DE PERDA, CORTE FÍSICO ID:' ||
                                                        r_lotesRemanejar.idcortefisico,
                                                       'N', 'S');
          if (v_qtdPossivelAlocar < v_qtdRemanejar) then
            v_qtdRemanejada := v_qtdPossivelAlocar;
          else
            v_qtdRemanejada := v_qtdRemanejar;
          end if;
        
          -- caso remanejamento seja origem picking destino pulmao, 
          -- inclui adiconar e pendencia manualmente e nao gera lote,
          -- caso contrario usa triger da loteremanejamento
          if (r_lotesRemanejar.Picking = 'S') then
            pk_triggers_control.disableTrigger('T_ALTERA_LOTEREMANEJAMENTO');
          
            insert into loteremanejamento
              (idremanejamento, idlote, qtde, conferido, controlaqtde,
               diferenca)
            values
              (v_idRemanejamento, r_lotesRemanejar.Idlote, v_qtdRemanejada,
               c_nao, c_sim, 0);
          
            pk_triggers_control.enableTrigger('T_ALTERA_LOTEREMANEJAMENTO');
          
            pk_estoque.incluir_adicionar(r_lotesRemanejar.Idarmazem,
                                         r_locaisDisponiveisSetorPerda.Idlocal,
                                         r_lotesRemanejar.Idlote,
                                         v_qtdRemanejada, p_idusuario,
                                         'AUMENTADO ADICIONAR EM FUNCAO DA INCLUSAO DO LOTE NO REMANEJAMENTO N: ' ||
                                          v_idRemanejamento);
          else
            insert into loteremanejamento
              (idremanejamento, idlote, qtde, conferido, controlaqtde,
               diferenca)
            values
              (v_idRemanejamento, r_lotesRemanejar.Idlote, v_qtdRemanejada,
               c_nao, c_sim, 0);
          end if;
        
          finalizarRemanejamento(v_idRemanejamento, p_idusuario);
        
          insert into cortefisicoremanejamento
            (id, idcortefisico, idremanejamento)
          values
            (seq_cortefisicoremanejamento.nextval,
             r_lotesremanejar.idcortefisico, v_idremanejamento);
        
          update remanejamento r
             set r.origemCorte = 1
           where r.idremanejamento = v_idRemanejamento;
        
          v_qtdRemanejar := v_qtdRemanejar - v_qtdRemanejada;
        end if;
      
        fetch c_locaisDisponiveisSetorPerda
          into r_locaisDisponiveisSetorPerda;
      end loop;
    
      if (v_qtdRemanejar > 0) then
        v_msg := t_message('Não foi possível remanejar toda a quantidade ' ||
                           '{0} {1} do lote {2} do produto Id:' ||
                           '{3} pertencente ao depositante Id: ' ||
                           '{4} para locais de setor de perda.');
        v_msg.addParam(r_lotesRemanejar.Qtde);
        v_msg.addParam(r_lotesRemanejar.Descrreduzido);
        v_msg.addParam(r_lotesRemanejar.Idlote);
        v_msg.addParam(r_lotesRemanejar.Idproduto);
        v_msg.addParam(r_lotesRemanejar.Iddepositante);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      fetch c_lotesRemanejar
        into r_lotesRemanejar;
    end loop;
  
    if (c_locaisDisponiveisSetorPerda%isopen) then
      close c_locaisDisponiveisSetorPerda;
    end if;
  
    if (c_lotesRemanejar%isopen) then
      close c_lotesRemanejar;
    end if;
  
  end gerarRemPerdaCorteFisico;

  procedure verificarpendencia
  (
    p_idremanejamento in number,
    p_idromaneio      in number,
    p_idusuario       in number
  ) is
    p_mensagem varchar2(4000);
    v_msg      t_message;
  begin
  
    p_mensagem := 'O REMANEJAMENTO ' || p_idremanejamento ||
                  ' GERADO PELA ONDA/ROMANEIO ID ' || p_idromaneio ||
                  ' NÃO PODE SER EXCLUIDO POIS A QUANTIDADE A SER RETIRADA ' ||
                  'É MAIOR DO QUE A QUANTIDADE DISPONIVEL DO LOTE NO ENDEREÇO:';
  
    for c_lote in (select lr.idlote, lr.qtde, r.idlocaldestino,
                          r.idarmazemdestino,
                          (ll.estoque + ll.adicionar - ll.pendencia) disp,
                          ll.estoque, ll.adicionar, ll.pendencia
                     from loteremanejamento lr, remanejamento r, lotelocal ll
                    where r.idremanejamento = p_idremanejamento
                      and r.idremanejamento = lr.idremanejamento
                      and ll.idlocal = r.idlocaldestino
                      and ll.idlote = lr.idlote
                      and lr.qtde >=
                          (ll.estoque + ll.adicionar - ll.pendencia)
                      and r.idremanejamento not in
                          (select pr.idremanejamento
                             from produtorecuperado pr
                            where pr.idremanejamento = p_idremanejamento)
                      and r.idremanejamento not in
                          (select rr.idremanejamento
                             from controleavaria ca, remanejamento rr
                            where ca.idcontroleavaria = rr.idcontroleavaria
                              and rr.idremanejamento = p_idremanejamento))
    loop
      p_mensagem := substr(p_mensagem || chr(13) || '- LOTE: ' ||
                           c_lote.idlote || ' / QUANTIDADE REMANEJAMENTO: ' ||
                           c_lote.qtde ||
                           ' / QUANTIDADES NO DESTINO: (DISP ' ||
                           c_lote.disp || ', EST ' || c_lote.estoque ||
                           ', ADIC ' || c_lote.adicionar || ', PEND ' ||
                           c_lote.pendencia || ')' || ' / OPERAÇÕES:', 1,
                           4000);
    
      for c_pend in (select iddepositante, idproduto, idlote, idarmazem,
                            idlocal,
                            decode(tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO', 2,
                                    'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4,
                                    'DOCA', 5, 'AUDITORIA', 6, 'RUA EXPEDICAO',
                                    7, 'STAGE', 8, 'PACKING') tipolocal,
                            buffer, sum(pendencia) pendencia, tipooperacao,
                            operacao
                       from ( -- localiza pendencia por onda de picking e pulmão
                              select lt.iddepositante, lt.idproduto, m.idlote,
                                      lo.idarmazem, lo.idlocal, lo.tipo,
                                      lo.buffer, m.qtdemovimentada pendencia,
                                      'ONDA' tipooperacao, m.idonda operacao
                                from movimentacao m, local lo, romaneiopai r,
                                      lote lt
                               where m.status in (0, 1)
                                 and m.etapa = 1
                                 and lo.id = m.idlocalorigem
                                 and lo.tipo < 3
                                 and lo.buffer = 'N'
                                 and r.idromaneio = m.idonda
                                 and r.processado <> 'S'
                                 and lt.idlote = m.idlote
                                 and m.idonda != p_idromaneio
                              union all
                              -- localiza pendencia por onda para reabastecimento do picking
                              select lt.iddepositante, lt.idproduto, m.idlote,
                                      lo.idarmazem, lo.idlocal, lo.tipo,
                                      lo.buffer, m.qtdemovimentada pendencia,
                                      'ONDA' tipooperacao, m.idonda operacao
                                from movimentacao m, local lo, romaneiopai r,
                                      lote lt
                               where m.status in (0, 1)
                                 and m.etapa = 3
                                 and lo.id = m.idlocalorigem
                                 and lo.tipo < 3
                                 and lo.buffer = 'N'
                                 and r.idromaneio = m.idonda
                                 and r.processado <> 'S'
                                 and lt.idlote = m.idlote
                                 and m.idonda != p_idromaneio
                                 and exists
                               (select 1
                                        from grupomovimentacao g, movimentacao ma
                                       where g.idgrupo = m.id
                                         and ma.id = g.idmovimentacao
                                         and ma.etapa < m.etapa
                                         and ma.status = 2)
                              union all
                              -- localiza pendencia por onda de colmeia
                              select iddepositante, idproduto, idlote, idarmazem,
                                      idlocal, tipo, buffer,
                                      sum(pendencia) pendencia, tipooperacao,
                                      operacao
                                from (select lt.iddepositante, lt.idproduto,
                                               m.idlote, lo.idarmazem, lo.idlocal,
                                               lo.tipo, lo.buffer,
                                               m.qtdemovimentada pendencia,
                                               'ONDA' tipooperacao,
                                               m.idonda operacao
                                          from movimentacao m, local lo,
                                               romaneiopai r, lote lt
                                         where lo.id = m.idlocaldestino
                                           and lo.tipo = 3
                                           and lo.buffer = 'N'
                                           and m.status = 2
                                           and r.idromaneio = m.idonda
                                           and r.processado <> 'S'
                                           and lt.idlote = m.idlote
                                           and m.idonda != p_idromaneio
                                        union all
                                        select lt.iddepositante, lt.idproduto,
                                               c.idlote, lo.idarmazem, lo.idlocal,
                                               lo.tipo, lo.buffer,
                                               c.quantidade * -1 pendencia,
                                               'ONDA' tipooperacao,
                                               m.idonda operacao
                                          from movimentacao m, local lo,
                                               volumeromaneio vr, conteudovolume c,
                                               romaneiopai r, lote lt
                                         where lo.id = m.idlocalorigem
                                           and lo.tipo = 3
                                           and m.status = 2
                                           and vr.idvolumeromaneio =
                                               m.idvolumeromaneio
                                           and c.idvolumeromaneio =
                                               vr.idvolumeromaneio
                                           and r.idromaneio = m.idonda
                                           and r.processado <> 'S'
                                           and lt.idlote = c.idlote
                                           and m.idonda != p_idromaneio)
                               group by iddepositante, idproduto, idlote,
                                         idarmazem, idlocal, tipo, buffer,
                                         tipooperacao, operacao
                              union all
                              -- localiza pendencia por onda da Rua Expedição ou Doca
                              select lt.iddepositante, lt.idproduto, c.idlote,
                                      lo.idarmazem, lo.idlocal, lo.tipo,
                                      lo.buffer, c.quantidade pendencia,
                                      'ONDA' tipooperacao, m.idonda operacao
                                from movimentacao m, local lo, volumeromaneio vr,
                                      conteudovolume c, romaneiopai r, lote lt
                               where lo.id = m.idlocaldestino
                                 and m.status = 2
                                 and vr.idvolumeromaneio = m.idvolumeromaneio
                                 and c.idvolumeromaneio = vr.idvolumeromaneio
                                 and r.idromaneio = m.idonda
                                 and r.processado <> 'S'
                                 and lt.idlote = c.idlote
                                 and m.idonda != p_idromaneio
                              union all
                              -- localiza pendencia por onda do buffer de pulmão
                              select iddepositante, idproduto, idlote, idarmazem,
                                      idlocal, tipo, buffer,
                                      sum(pendencia) pendencia, tipooperacao,
                                      operacao
                                from (select lt.iddepositante, lt.idproduto,
                                               c.idlote, lo.idarmazem, lo.idlocal,
                                               lo.tipo, lo.buffer,
                                               c.quantidade pendencia,
                                               'ONDA' tipooperacao,
                                               m.idonda operacao
                                          from movimentacao m, local lo,
                                               volumeromaneio vr, conteudovolume c,
                                               romaneiopai r, lote lt
                                         where lo.id = m.idlocalorigem
                                           and lo.buffer = 'S'
                                           and m.status in (0, 1)
                                           and vr.idvolumeromaneio =
                                               m.idvolumeromaneio
                                           and c.idvolumeromaneio =
                                               vr.idvolumeromaneio
                                           and r.idromaneio = m.idonda
                                           and r.processado <> 'S'
                                           and lt.idlote = c.idlote
                                           and m.idonda != p_idromaneio
                                        union all
                                        select lt.iddepositante, lt.idproduto,
                                               m.idlote, lo.idarmazem, lo.idlocal,
                                               lo.tipo, lo.buffer,
                                               (m.qtdemovimentada * -1) pendencia,
                                               'ONDA' tipooperacao,
                                               m.idonda operacao
                                          from movimentacao m, local lo,
                                               romaneiopai r, lote lt
                                         where m.status in (0, 1)
                                           and m.etapa = 1
                                           and lo.id = m.idlocaldestino
                                           and lo.tipo < 3
                                           and lo.buffer = 'S'
                                           and r.idromaneio = m.idonda
                                           and r.processado <> 'S'
                                           and lt.idlote = m.idlote
                                           and m.idonda != p_idromaneio)
                               group by iddepositante, idproduto, idlote,
                                         idarmazem, idlocal, tipo, buffer,
                                         tipooperacao, operacao
                              union all
                              -- localiza pendencia por onda do buffer de picking
                              select lt.iddepositante, lt.idproduto, m.idlote,
                                      lo.idarmazem, lo.idlocal, lo.tipo,
                                      lo.buffer, m.qtdemovimentada pendencia,
                                      'ONDA' tipooperacao, m.idonda operacao
                                from movimentacao m, local lo, romaneiopai r,
                                      lote lt
                               where m.status in (0, 1)
                                 and m.etapa = 2
                                 and lo.id = m.idlocalorigem
                                 and lo.tipo = 0
                                 and lo.buffer = 'S'
                                 and r.idromaneio = m.idonda
                                 and r.processado <> 'S'
                                 and lt.idlote = m.idlote
                                 and m.idonda != p_idromaneio
                              union all
                              -- localiza pendencia por romaneio
                              select lt.iddepositante, lt.idproduto, ps.idlote,
                                      ps.idarmazem, ps.idlocal, lo.tipo,
                                      lo.buffer, ps.qtdeunit pendencia,
                                      'ROMANEIO' tipooperacao,
                                      r.idromaneio operacao
                                from paletseparacao ps, romaneiopai r, lote lt,
                                      local lo
                               where r.idromaneio = ps.idromaneio
                                 and r.processado = 'N'
                                 and r.tipo = 0
                                 and lt.idlote = ps.idlote
                                 and lo.idarmazem = ps.idarmazem
                                 and lo.idlocal = ps.idlocal
                                 and r.idromaneio != p_idromaneio
                              union all
                              -- localiza pendencia por ajuste de saida
                              select lt.iddepositante, lt.idproduto, a.idlote,
                                      a.idarmazem, a.idlocal, lo.tipo, lo.buffer,
                                      a.qtde pendencia,
                                      'AJUSTE SAIDA' tipooperacao,
                                      a.idajustemovto operacao
                                from ajustemovtosaida a, ajustemovto aj, lote lt,
                                      local lo
                               where aj.idajustemovto = a.idajustemovto
                                 and aj.gerado = 'N'
                                 and lt.idlote = a.idlote
                                 and lo.idarmazem = a.idarmazem
                                 and lo.idlocal = a.idlocal
                              union all
                              -- localiza pendencia por remanejamento
                              select lt.iddepositante, lt.idproduto, lr.idlote,
                                      r.idarmazemorigem idarmazem,
                                      r.idlocalorigem idlocal, lo.tipo, lo.buffer,
                                      lr.qtde pendencia,
                                      'REMANEJAMENTO' tipooperacao,
                                      r.idremanejamento operacao
                                from loteremanejamento lr, remanejamento r,
                                      lote lt, local lo
                               where r.idremanejamento = lr.idremanejamento
                                 and r.status <> 'F'
                                 and lt.idlote = lr.idlote
                                 and lo.idarmazem = r.idarmazemorigem
                                 and lo.idlocal = r.idlocalorigem
                                 and r.idremanejamento != p_idremanejamento)
                      where idlote = c_lote.idlote
                        and idlocal = c_lote.idlocaldestino
                        and idarmazem = c_lote.idarmazemdestino
                      group by iddepositante, idproduto, idlote, idarmazem,
                               idlocal,
                               decode(tipo, 0, 'PICKING', 1, 'PULMÃO BLOCADO',
                                       2, 'PULMÃO PALETIZADO', 3, 'COLMÉIA', 4,
                                       'DOCA', 5, 'AUDITORIA', 6,
                                       'RUA EXPEDICAO', 7, 'STAGE', 8,
                                       'PACKING'), buffer, tipooperacao,
                               operacao
                     -- having sum(pendencia) <> sum(pendenciaonda + pendenciaromaneio + pendenciaajustesaida + pendenciaremanejamento + pendenciadecorte)
                      order by idlote, tipolocal)
      loop
        p_mensagem := substr(p_mensagem || chr(13) || '-- ' ||
                             c_pend.tipooperacao || ' ID ' ||
                             c_pend.operacao || ' QUANTIDADE ' ||
                             c_pend.pendencia, 1, 4000);
      end loop;
    end loop;
  
    p_mensagem := substr(p_mensagem || chr(13) || 'SQLERR ' || sqlerrm, 1,
                         4000);
    pk_utilities.GeraLog(p_idusuario, p_mensagem, p_idremanejamento, 'DR');
  end;

  /*
   * rotina responsavel por desfazer o romaneio.
  */
  procedure desfazerRemanejamento
  (
    p_romaneio     in number,
    p_usuario      in number,
    p_tipo         in number,
    p_idnotafiscal in number
  ) is
    v_QtdeLotesExcluidos number := 0;
  
    procedure corrigeSepEspecificaOnda is
      r_sepespecifica       separacaoespecifica%rowtype;
      v_idNovaSepEspecifica number;
      v_idSepLoteInd        number;
      v_loteuniconoendereco number;
      v_qtdeSepLoteInd      number;
    begin
      for c_rem in (select r.idlocalorigem, r.idlocaldestino, rr.idlote,
                           m.idnotafiscal, rp.idarmazem
                      from remanejamentoromaneio rr, remanejamento r,
                           movimentacao m, local l, romaneiopai rp
                     where rp.idromaneio = p_romaneio
                       and rr.idromaneio = rp.idromaneio
                       and r.idremanejamento = rr.idremanejamento
                       and r.status in ('A', 'P')
                       and l.idlocal = r.idlocaldestino
                       and m.idonda = rr.idromaneio
                       and m.idlocalorigem = l.id
                       and m.idlote = rr.idlote)
      loop
        begin
          select pd.loteuniconoendereco
            into v_loteuniconoendereco
            from produtodepositante pd, lote lt
           where lt.idlote = c_rem.idlote
             and pd.identidade = lt.iddepositante
             and pd.idproduto = lt.idproduto;
        exception
          when no_data_found then
            v_loteuniconoendereco := 0;
        end;
      
        begin
          select *
            into r_sepespecifica
            from separacaoespecifica s
           where s.idlocal = c_rem.idlocaldestino
             and s.idnotafiscal = c_rem.idnotafiscal
             and s.idlote = c_rem.idlote
             and s.idarmazem = c_rem.idarmazem;
        exception
          when no_data_found then
            r_sepespecifica := null;
        end;
      
        if r_sepespecifica.id is not null then
          begin
            insert into separacaoespecifica
              (idarmazem, idlocal, idlote, idnotafiscal, qtde, cadmanual,
               fonteseparacao, idusuario, dtvinculo)
            values
              (r_sepespecifica.idarmazem, c_rem.idlocalorigem,
               r_sepespecifica.idlote, r_sepespecifica.idnotafiscal,
               r_sepespecifica.qtde, r_sepespecifica.cadmanual,
               r_sepespecifica.fonteseparacao, r_sepespecifica.idusuario,
               sysdate)
            returning id into v_idNovaSepEspecifica;
          exception
            when dup_val_on_index then
              update separacaoespecifica
                 set qtde = qtde + r_sepespecifica.qtde
               where idarmazem = r_sepespecifica.idarmazem
                 and idlocal = c_rem.idlocalorigem
                 and idlote = r_sepespecifica.idlote
                 and idnotafiscal = r_sepespecifica.idnotafiscal
              returning id into v_idNovaSepEspecifica;
          end;
        
          select count(1)
            into v_qtdeSepLoteInd
            from seploteindsepespecif sls
           where sls.idsepespecifica = r_sepespecifica.id;
        
          for c_sep in (select sls.idseploteind, sls.qtde
                          from seploteindsepespecif sls
                         where sls.idsepespecifica = r_sepespecifica.id)
          loop
            if (v_qtdeSepLoteInd = 1) then
              insert into seploteindsepespecif
                (idsepespecifica, idseploteind, idlote, qtde)
              values
                (v_idNovaSepEspecifica, c_sep.idseploteind,
                 r_sepespecifica.idlote, r_sepespecifica.qtde);
            else
              insert into seploteindsepespecif
                (idsepespecifica, idseploteind, idlote, qtde)
              values
                (v_idNovaSepEspecifica, c_sep.idseploteind,
                 r_sepespecifica.idlote, c_sep.qtde);
            end if;
          
            delete from seploteindsepespecif s
             where s.idsepespecifica = r_sepespecifica.id
               and s.idseploteind = c_sep.idseploteind;
          end loop;
        
          delete from separacaoespecifica
           where id = r_sepespecifica.id;
        
        end if;
      
      end loop;
    end corrigeSepEspecificaOnda;
  
  begin
    if p_tipo = 1
       and pk_onda.validarFluxo('%buffer%', p_romaneio)
       and pk_onda.validarFluxo('%colmeia%', p_romaneio) then
      return;
    end if;
  
    -- No caso de cancelamento de onda, essa rotina avalia as 
    -- separações específicas e volta do picking para o pulmão
    -- no caso da formação ter criado remanejamentos e alterado isso.
    corrigeSepEspecificaOnda;
  
    delete from gtt_selecao;
  
    if (p_tipo = 0) then
      insert into gtt_selecao
        select distinct lr.idremanejamento
          from paletseparacao ps, loteremanejamento lr, remanejamento r
         where r.cadmanual = 'N'
           and r.status <> 'F'
           and r.idremanejamento = lr.idremanejamento
           and lr.idlote = ps.idlote
           and ps.idromaneio = p_romaneio
        union
        select distinct rr.idremanejamento
          from remanejamentoromaneio rr, remanejamento r
         where rr.idremanejamento = r.idremanejamento
           and r.cadmanual = 'N'
           and r.status <> 'F'
           and rr.idromaneio = p_romaneio;
    
    else
      insert into gtt_selecao
        select distinct lr.idremanejamento
          from movimentacao m, loteremanejamento lr, remanejamento r,
               local ld
         where m.idonda = p_romaneio
           and m.etapa = 1
           and m.status = 3
           and m.idnotafiscal = p_idnotafiscal
           and lr.idlote = m.idlote
           and r.idremanejamento = lr.idremanejamento
           and r.cadmanual = 'N'
           and r.status <> 'F'
           and ld.idarmazem = r.idarmazemdestino
           and ld.idlocal = r.idlocaldestino
           and not exists
         (select 1
                  from ordemdevolucaoremanejamento o
                 where o.idremanejamento = lr.idremanejamento);
    
    end if;
  
    for c_remanej in (select idselecionado idremanejamento, r.planejado
                        from gtt_selecao g, remanejamento r
                       where r.idremanejamento = g.idselecionado
                       order by tipo)
    loop
      begin
        update loteremanejamento
           set idromaneio = null
         where idromaneio = p_romaneio
           and idremanejamento = c_remanej.idremanejamento;
      
        update remanejamento
           set idromaneio = null
         where idromaneio = p_romaneio
           and idremanejamento = c_remanej.idremanejamento;
      
        delete remanejamentoromaneio
         where idromaneio = p_romaneio
           and idremanejamento = c_remanej.idremanejamento;
      
        update remanejamento r
           set r.planejado = 'N'
         where r.idremanejamento = c_remanej.idremanejamento;
      
        --Excluindo lotes do remanejamento onde não exista remanejamento em produtorecuperado e controle de avaria.
        delete from loteremanejamento
         where idremanejamento = c_remanej.idremanejamento
           and idremanejamento not in
               (select pr.idremanejamento
                  from produtorecuperado pr
                 where pr.idremanejamento = c_remanej.idremanejamento)
           and idremanejamento not in
               (select r.idremanejamento
                  from controleavaria ca, remanejamento r
                 where ca.idcontroleavaria = r.idcontroleavaria
                   and r.idremanejamento = c_remanej.idremanejamento);
      
        v_QtdeLotesExcluidos := sql%rowcount;
      
        if (p_tipo = 0) then
          pk_utilities.GeraLog(p_usuario,
                               substr('O REMANEJAMENTO ' ||
                                       c_remanej.idremanejamento ||
                                       ' FOI EXCLUIDO POIS ROMANEIO DE ID: ' ||
                                       p_romaneio || ' FOI DESFEITO.', 1, 1000),
                               c_remanej.idremanejamento, 'DR');
        else
          pk_utilities.GeraLog(p_usuario,
                               substr('O REMANEJAMENTO ' ||
                                       c_remanej.idremanejamento ||
                                       ' FOI EXCLUIDO POIS A ONDA DE ID: ' ||
                                       p_romaneio || ' FOI DESFEITA.', 1, 1000),
                               c_remanej.idremanejamento, 'DR');
        
        end if;
      exception
        when others then
          v_QtdeLotesExcluidos := 0;
        
          verificarpendencia(c_remanej.idremanejamento, p_romaneio,
                             p_usuario);
      end;
    
      if (v_QtdeLotesExcluidos > 0) then
      
        update trocarlocaldestinorem
           set idremanejamento = null
         where idremanejamento = c_remanej.idremanejamento;
      
        delete remanejamentoromaneio
         where idremanejamento = c_remanej.idremanejamento;
      
        delete from remanejamento
         where idremanejamento = c_remanej.idremanejamento;
      else
        update remanejamento r
           set r.planejado = c_remanej.planejado
         where r.idremanejamento = c_remanej.idremanejamento;
      end if;
    end loop;
  
    delete from gtt_selecao;
  
  end;

  procedure desfazRemanejBuffPickParaPick
  (
    p_idonda          in number,
    p_idusuario       in number,
    p_idmovimentacoes in varchar2
  ) is
    v_sqlRem varchar2(4000);
    type cursorRem is ref cursor;
    c_cursorRem cursorRem;
  
    type rec_cursorRem is record(
      idremanejamento  number,
      status           remanejamento.status%type,
      idarmazemorigem  number,
      idlocalorigem    remanejamento.idlocalorigem%type,
      idarmazemdestino number,
      idlocaldestino   remanejamento.idlocaldestino%type);
    r_cursorRem rec_cursorRem;
  
    function montarSqlRem return varchar2 is
      v_sqlRem varchar2(4000);
    begin
      v_sqlRem := 'select r.idremanejamento, r.status, ' ||
                  '       r.idarmazemorigem, r.idlocalorigem, r.idarmazemdestino, r.idlocaldestino ' ||
                  '  from remanejamento r, local lo, local ld ' ||
                  ' where lo.idarmazem = r.idarmazemorigem ' ||
                  '   and lo.idlocal = r.idlocalorigem ' ||
                  '   and ld.idarmazem = r.idarmazemdestino ' ||
                  '   and ld.idlocal = r.idlocaldestino ' ||
                  '   and lo.tipo in (0) ' || '   and lo.buffer = ''S'' ' ||
                  '   and ld.tipo = 0 ' || '   and ld.buffer = ''N'' ' ||
                  '   and r.status <> ''F'' ' ||
                  '   and r.cadmanual = ''N'' ' ||
                  '   and r.idmovimentacao in (' || p_idmovimentacoes || ')';
    
      return v_sqlRem;
    end;
  
    procedure integrarRemEsteira(p_idremanejamento in number) is
      C_ESTEIRA_PICKING       constant number := 1;
      C_NAO_INTEGRADO         constant number := 0;
      C_REMANEJ_CAIXA_GRAFICA constant number := 1;
      C_CANCELAMENTO_ONDA     constant number := 9;
      C_EVENTO_EXCLUSAO       constant number := 1;
    begin
      for r_intEsteira in (select *
                             from int_automacao_esteira i
                            where i.esteira = C_ESTEIRA_PICKING
                              and i.idoperacao = p_idremanejamento
                              and i.tipooperacao = C_REMANEJ_CAIXA_GRAFICA
                              and i.integrado = C_NAO_INTEGRADO)
      loop
        delete from int_automacao_esteira i
         where i.id = r_intEsteira.id;
      
        insert into historico_automacao_esteira
          (id, data, evento, esteira, codintegracao, identificador,
           integrado, pesagemliberada, idoperacao, tipooperacao,
           usuariologado)
        values
          (seq_hist_automacao_esteira.nextval, sysdate, C_EVENTO_EXCLUSAO,
           r_intEsteira.Esteira, r_intEsteira.Codintegracao,
           r_intEsteira.Identificador, r_intEsteira.Integrado,
           r_intEsteira.Pesagemliberada, r_intEsteira.Idoperacao,
           C_CANCELAMENTO_ONDA, user);
      end loop;
    end;
  
  begin
    --SITUAÇÕES POSSÍVEIS
    --1 ONDA FOI FORMADA, NÃO FORAM FORMADAS ONDAS POSTERIORES DEPENDENDO DESSES REMANEJAMENTOS 
    --E ESTA ONDA ESTÁ SENDO DESFEITA
    --RESULTADO ESPERADO: OS REMANEJAMENTOS DE BUFFER DE PICKING PARA PICKING SERÃO DESFEITOS NORMALMENTE
    --2 ONDA FOI FORMADA, POSTERIORMENTE FOI FORMADA OUTRA ONDA DEPENDENDO DO EXCESSO DE DISPONIVEL NO PICKING
    --E A PRIMEIRA ONDA ESTÁ SENDO DESFEITA
    --RESULTADO ESPERADO: O GRUPO DE REMANEJAMENTOS (GERADO PELO MESMO IDMOVIMENTACAO) SOMENTE SERA DESFEITO
    --SE TODO O GRUPO PUDER SER DESFEITO, POSTERIORMENTE VINCULARÁ ESTES REMANEJAMENTOS A UM NOVO QUE SERÁ CRIADO
    --PARA SUBSTITUIR A MOVIMENTAÇÃO DE PULMÃO PARA BUFFER DE PICKING
    --3 ONDA FOI FORMADA CRIANDO MOVIMENTACAO DE PL PARA BUFFER DE PK, OUTRA ONDA FOI FORMADA UTILIZANDO O 
    --EXCESSO DO DISPONIVEL DA PRIMEIRA ONDA, PRIMEIRA ONDA FOI DESFEITA, CRIANDO UM REMANEJAMENTO DE PL PARA
    --BUFFER DE PK PARA SUBSTITUIR A MOVIMENTACAO, UMA TERCEIRA ONDA FOI FORMADA UTILIZANDO O EXCESSO DE DISPONIVEL
    --NO PICKING, A SEGUNDA ONDA ESTÁ SENDO CANCELADA.
    --RESULTADO ESPERADO: DEVERÁ LOCALIZAR OS REMANEJAMENTOS DE PULMÃO PARA BUFFER DE PICKING, CADASTRADOS AUTOMATICAMENTE
    --E SEM REMANEJAMENTOROMANEIO, TENTANDO EXCLUIR TODOS OS REMANEJAMENTOS FILHOS, SOMENTE EXCLUIRÁ 
    --SE PUDER EXCLUIR TODOS OS FILHOS E O PAI
    --4 APÓS O CENÁRIO 3, CASO A TERCEIRA ONDA SEJA CANCELADA
    --RESULTADO ESPERADO: DEVERÁ CONSEGUIR EXCLUIR TODOS OS REMANEJAMENTOS FILHOS E O PAI POSTERIORMENTE
  
    --identificar remanejamentos pendentes sem REMANEJAMENTOROMANEIO, cadastrados automaticamente,
    --de pulmão para buffer de picking e tentar desfazer todos os filhos
    --se um dos filhos falhar, efetuar rollback e seguir para o próximo remanejamento pai
    for c_rem in (select r.idremanejamento
                    from remanejamento r, local lo, local ld
                   where lo.idarmazem = r.idarmazemorigem
                     and lo.idlocal = r.idlocalorigem
                     and ld.idarmazem = r.idarmazemdestino
                     and ld.idlocal = r.idlocaldestino
                     and lo.tipo in (1, 2)
                     and lo.buffer = 'N'
                     and ld.tipo = 0
                     and ld.buffer = 'S'
                     and r.status <> 'F'
                     and r.cadmanual = 'N'
                     and not exists
                   (select 1
                            from remanejamentoromaneio rr
                           where rr.idremanejamento = r.idremanejamento)
                     and not exists
                   (select 1
                            from loteremanejamento lr
                           where lr.idremanejamento = r.idremanejamento
                             and lr.conferido = 'S'))
    loop
      savepoint sv_remanejamento;
    
      begin
        --alterando status dos remanejamentos filhos para permitir exclusão
        update remanejamento r
           set r.planejado = 'N'
         where r.idremanejamentopai = c_rem.idremanejamento;
      
        --excluindo remanejamentoromaneio dos remanejamentos filhos
        delete from remanejamentoromaneio rr
         where exists
         (select 1
                  from remanejamento r
                 where r.idremanejamento = rr.idremanejamento
                   and r.idremanejamentopai = c_rem.idremanejamento);
      
        --excluindo loteremanejamento dos remanejamentos filhos
        delete from loteremanejamento lr
         where exists
         (select 1
                  from remanejamento r
                 where r.idremanejamento = lr.idremanejamento
                   and r.idremanejamentopai = c_rem.idremanejamento);
      
        --excluindo remanejamentos filhos
        delete from remanejamento r
         where r.idremanejamentopai = c_rem.idremanejamento;
      
        --alterando status do remanejamento pai para permitir exclusão
        update remanejamento r
           set r.planejado = 'N'
         where r.idremanejamento = c_rem.idremanejamento;
      
        --excluindo loteremanejamento do remanejamento pai
        delete from loteremanejamento lr
         where lr.idremanejamento = c_rem.idremanejamento;
      
        --excluindo remanejamento pai
        delete from remanejamento r
         where r.idremanejamento = c_rem.idremanejamento;
      
        --integrando remanejamento excluído com a esteira
        for c_remFilho in (select r.idremanejamento
                             from remanejamento r
                            where r.idremanejamentopai =
                                  c_rem.idremanejamento)
        loop
          integrarRemEsteira(c_remFilho.idremanejamento);
        end loop;
      exception
        when others then
          rollback to sv_remanejamento;
        
          pk_utilities.GeraLog(p_idusuario,
                               'Erro ao tentar excluir o remanejamento id: ' ||
                                c_rem.idremanejamento ||
                                ' durante o cancelamento da onda id: ' ||
                                p_idonda || '. Erro: ' || sqlerrm,
                               c_rem.idremanejamento, 'RM');
      end;
    end loop;
  
    --identificar remanejamentos pendentes de buffer de picking para picking com os IDMOVIMENTACAO passados
    --se um deles falhar, efetuar rollback de todos já desfeitos
    --se estiver com status G, executar
    --desfazer se o status estiver diferente de G
    if p_idmovimentacoes is not null then
      v_sqlRem := montarSqlRem;
    
      if (c_cursorRem%isopen) then
        close c_cursorRem;
      end if;
    
      open c_cursorRem for v_sqlRem;
    
      fetch c_cursorRem
        into r_cursorRem;
    
      savepoint sv_remanejamento;
    
      begin
        while (c_cursorRem%found)
        loop
          -- Se o status é G, já realizou a origem e está na esteira, sendo assim, executa
          if r_cursorRem.status = 'G' then
            for c_loteRem in (select lr.idlote, lr.qtde
                                from loteremanejamento lr
                               where lr.idremanejamento =
                                     r_cursorRem.idremanejamento)
            loop
              pk_estoque.retirar_estoque(r_cursorRem.idarmazemorigem,
                                         r_cursorRem.idlocalorigem,
                                         c_loteRem.idlote, c_loteRem.qtde,
                                         p_idusuario,
                                         'RETIRADO ESTOQUE EM FUNÇÃO DA EXECUÇÃO AUTOMÁTICA E EXCLUSÃO DO REMANEJAMENTO: ' ||
                                          r_cursorRem.idremanejamento ||
                                          ' DEVIDO AO CANCELAMENTO DA ONDA ID: ' ||
                                          p_idonda);
            
              pk_estoque.incluir_estoque(r_cursorRem.idarmazemdestino,
                                         r_cursorRem.idlocaldestino,
                                         c_loteRem.idlote, c_loteRem.qtde,
                                         p_idusuario,
                                         'INCLUIDO ESTOQUE REMANESCENTE DO BUFFER DE PICKING EM FUNÇÃO ' ||
                                          'DA EXECUÇÃO AUTOMÁTICA E EXCLUSÃO DO REMANEJAMENTO: ' ||
                                          r_cursorRem.idremanejamento ||
                                          ' PDEVIDO AO CANCELAMENTO DA ONDA ID: ' ||
                                          p_idonda);
            end loop;
          end if;
        
          --excluindo a remanejamentoromaneio dos remanejamentos 
          delete from remanejamentoromaneio rr
           where rr.idremanejamento = r_cursorRem.idremanejamento;
        
          --excluindo loteremanejamento do remanejamento
          delete from loteremanejamento lr
           where lr.idremanejamento = r_cursorRem.idremanejamento;
        
          --excluindo remanejamento
          delete from remanejamento r
           where r.idremanejamento = r_cursorRem.idremanejamento;
        
          --integrando remanejamento excluído com a esteira
          integrarRemEsteira(r_cursorRem.idremanejamento);
        
          fetch c_cursorRem
            into r_cursorRem;
        end loop;
      exception
        when others then
          rollback to sv_remanejamento;
        
          pk_utilities.GeraLog(p_idusuario,
                               'Ocorreu um erro durante o cancelamento da onda id: ' ||
                                p_idonda ||
                                ' ao tentar excluir os remanejamentos criados pelas movimentações id (' ||
                                p_idmovimentacoes || '). Erro: ' || sqlerrm,
                               p_idonda, 'RM');
      end;
    
      close c_cursorRem;
    end if;
  end;

  procedure validaDispExecucao(p_idremanejamento in number) is
    v_idArmazem number;
    v_idLocal   local.idlocal%type;
  
    v_cubagemRemanej number;
    v_pesoRemanej    number;
    v_qtde           number;
    v_msg            t_message;
  
    function isDestinoBufferPicking
    (
      p_idArmazem in number,
      p_idLocal   in varchar2
    ) return boolean is
      v_resultado number;
    begin
      select count(*)
        into v_resultado
        from dual
       where exists (select 1
                from local l
               where l.idarmazem = p_idArmazem
                 and l.idlocal = p_idLocal
                 and l.tipo = 0
                 and l.buffer = 'S');
      return v_resultado > 0;
    end;
  
  begin
    -- Rotina criada para validar se o remanejamento pode ser realizado
    -- Caso o local de destino não possua disponibilidade de peso ou cubagem
    -- para receber os materiais e a configuração de armazem exibeAtvRemSemDisp
    -- estiver marcada ocorrerá erro
  
    select r.idarmazemdestino, r.idlocaldestino,
           sum((lr.qtde / e.fatorconversao) * e.altura * e.largura *
                e.comprimento) cubagemrem,
           sum((lr.qtde / e.fatorconversao) * e.pesobruto) pesorem
      into v_idArmazem, v_idLocal, v_cubagemRemanej, v_pesoRemanej
      from remanejamento r, loteremanejamento lr, lote lt, embalagem e
     where r.idremanejamento = p_idremanejamento
       and lr.idremanejamento = r.idremanejamento
       and lt.idlote = lr.idlote
       and e.barra = lt.barra
       and e.idproduto = lt.idproduto
     group by r.idarmazemdestino, r.idlocaldestino, r.idremanejamento;
  
    if isDestinoBufferPicking(v_idArmazem, v_idLocal) then
      return;
    end if;
  
    select count(1)
      into v_qtde
      from dual
     where exists
     (select 1
              from local ld,
                   (select ll.idendereco,
                            sum((ll.estoque / e.fatorconversao) * e.altura *
                                 e.largura * e.comprimento) cubagemutilizada,
                            sum((ll.estoque / e.fatorconversao) * e.pesobruto) pesoutilizado
                       from lotelocal ll, lote lt, embalagem e
                      where lt.idlote = ll.idlote
                        and e.barra = lt.barra
                        and e.idproduto = lt.idproduto
                        and ll.idarmazem = v_idArmazem
                        and ll.idlocal = v_idlocal
                      group by ll.idendereco) est, armazem ar
             where ld.idarmazem = v_idArmazem
               and ld.idlocal = v_idlocal
               and est.idendereco(+) = ld.id
               and ar.idarmazem = ld.idarmazem
               and (ar.exibeAtvRemSemDisp = 1 or
                   (((ld.altura - ld.alturamanobra) * ld.largura *
                   ld.comprimento) - nvl(est.cubagemutilizada, 0) -
                   v_cubagemRemanej >= 0 and
                   ld.pesomaximo - nvl(est.pesoutilizado, 0) -
                   v_pesoRemanej >= 0)));
  
    if v_qtde = 0 then
      v_msg := t_message('O remanejamento não pode ser realizado, ' ||
                         'pois local de destino não possui cubagem ' ||
                         'ou peso disponível no momento.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  end;

  procedure excluirRemanejamento
  (
    p_idremanejamento in number,
    p_usuario         in number
  ) is
    r_remanejamento remanejamento%rowtype;
  
    v_tipolocalorigem  number;
    v_tipolocaldestino number;
    v_msg              t_message;
  begin
  
    r_remanejamento := pk_remanejamento.CarregarRemanejamento(p_idremanejamento);
  
    select lo.tipo, ld.tipo
      into v_tipolocalorigem, v_tipolocaldestino
      from remanejamento r, local lo, local ld
     where r.idremanejamento = p_idremanejamento
       and lo.idlocal = r.idlocalorigem
       and lo.idarmazem = r.idarmazemorigem
       and ld.idlocal = r.idlocaldestino
       and ld.idarmazem = r.idarmazemdestino;
  
    if ((v_tipolocalorigem = 0) and
       (v_tipolocaldestino = 1 or v_tipolocaldestino = 2)) then
      if (r_remanejamento.status = 'F') then
        v_msg := t_message('Não é permitido realizar alterações em remanejamento que está finalizado.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    else
      if (r_remanejamento.status <> 'A') then
        v_msg := t_message('Não é permitido realizar alterações em remanejamento que não esteja aberto.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
    end if;
  
    if (r_remanejamento.planejado = 'S') then
      v_msg := t_message('Não é permitido realizar alterações em remanejamento planejado.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    if ((v_tipolocalorigem = 0) and
       (v_tipolocaldestino = 1 or v_tipolocaldestino = 2)) then
    
      for c_loterem in (select idlote
                          from loteremanejamento
                         where idremanejamento = p_idremanejamento)
      loop
        desassociarLote(p_idremanejamento, c_loterem.idlote, p_usuario);
      end loop;
    end if;
  
    delete from remanejamento
     where idremanejamento = p_idremanejamento;
  
    pk_utilities.GeraLog(p_usuario,
                         'Tela: Remanejamento - Apagou o Remanejamento Id: ' ||
                          p_idremanejamento, p_idremanejamento, 'CA');
  end;

  function getDadosRegraDepositanteLocal
  (
    p_idLocal        in varchar2,
    p_idArmazem      in number,
    p_barraInformada in varchar2
  ) return number is
  
    cursor c_depositante is
      select distinct lt.iddepositante
        from lotelocal ll, lote lt
       where ll.estoque > 0
         and ll.idarmazem = p_idArmazem
         and ll.idlocal = p_idLocal
         and lt.idlote = ll.idlote;
  
    v_qtdDepositantes number;
    v_retorno         number;
    v_idproduto       number;
    v_codProduto      produto.codigointerno%type;
    v_barraProduto    embalagem.barra%type;
    v_qtd             number;
    v_loteIndustria   lote.descr%type;
    v_dtVencimento    lote.dtvenc%type;
  begin
    v_qtdDepositantes := 0;
  
    delete from GTT_BARRA_REGRADEPOSITANTE;
  
    for r_dep in c_depositante
    loop
      pk_depositante.encontrarRegraBarraDepositante(r_dep.iddepositante,
                                                    p_barraInformada,
                                                    v_qtdDepositantes);
    end loop;
  
    if (v_qtdDepositantes = 0) then
      for r_dep in c_depositante
      loop
        v_retorno := pk_depositante.getDadosBarraRegraDepositante(r_dep.iddepositante,
                                                                  p_barraInformada,
                                                                  v_codProduto,
                                                                  v_barraProduto,
                                                                  v_qtd,
                                                                  v_loteIndustria,
                                                                  v_dtVencimento);
      
        if (v_retorno = 1) then
          if (v_codProduto is null and v_loteIndustria is not null) then
            begin
              select p.idproduto, p.codigointerno, l.barra
                into v_idproduto, v_codProduto, v_barraProduto
                from lote l, produto p
               where l.descr = v_loteIndustria
                 and l.iddepositante = r_dep.iddepositante
                 and l.idproduto = p.idproduto
                 and rownum = 1;
            exception
              when no_data_found then
                v_qtdDepositantes := 0;
                continue;
            end;
          
            v_qtdDepositantes := 1;
          
            insert into gtt_barra_regradepositante
              (iddepositante, depositante, barrainformada, idproduto,
               codproduto, descrproduto, barraproduto, qtd, loteindustria,
               dtvencimento)
            values
              (r_dep.iddepositante, null, p_barrainformada, v_idproduto,
               v_codproduto, null, v_barraproduto, v_qtd, v_loteindustria,
               v_dtvencimento);
          
            return v_qtdDepositantes;
          end if;
        end if;
      end loop;
    end if;
  
    return v_qtdDepositantes;
  end getDadosRegraDepositanteLocal;

  function getDadosRegraDepositanteLote
  (
    p_idremanejamento in number,
    p_barraInformada  in varchar2
  ) return number is
  
    v_qtdDepositantes number;
  begin
    v_qtdDepositantes := 0;
  
    delete from GTT_BARRA_REGRADEPOSITANTE;
  
    for r_dep in (select distinct lt.iddepositante
                    from loteremanejamento lr, lote lt
                   where lt.idlote = lr.idlote
                     and lr.idremanejamento = p_idremanejamento)
    loop
      pk_depositante.encontrarRegraBarraDepositante(r_dep.iddepositante,
                                                    p_barraInformada,
                                                    v_qtdDepositantes);
    end loop;
  
    return v_qtdDepositantes;
  end;

  procedure validarFinalizarRemanejamento(p_idRemanejamento number) is
    v_idlocalorigem       local.idlocal%type;
    v_idlocalorigemFormat local.idlocalformatado%type;
    v_idarmazemorigem     number;
    v_pk_origem           number;
    v_pk_destino          number;
    v_remanejamentos      varchar2(4000);
    v_msg                 t_message;
  begin
    select r.idlocalorigem, lo.idlocalformatado, r.idarmazemorigem,
           decode(lo.picking, 'S', 1, 0) pk_origem,
           decode(ld.picking, 'S', 1, 0) pk_destino
      into v_idlocalorigem, v_idlocalorigemFormat, v_idarmazemorigem,
           v_pk_origem, v_pk_destino
      from remanejamento r, local lo, local ld
     where 1 = 1
       and lo.idlocal = r.idlocalorigem
       and lo.idarmazem = r.idarmazemorigem
       and ld.idlocal = r.idlocaldestino
       and ld.idarmazem = r.idarmazemdestino
       and r.idremanejamento = p_idRemanejamento;
  
    if (v_pk_origem = 1 and v_pk_destino = 0) then
      select stragg(idrem)
        into v_remanejamentos
        from (select distinct r.idremanejamento idrem
                 from remanejamento r, loteremanejamento lr, local lo,
                      local ld
                where 1 = 1
                  and r.idremanejamento = lr.idremanejamento
                  and r.idlocaldestino = v_idlocalorigem
                  and r.idarmazemdestino = v_idarmazemorigem
                  and lo.idlocal = r.idlocalorigem
                  and lo.idarmazem = r.idarmazemorigem
                  and ld.idlocal = r.idlocaldestino
                  and ld.idarmazem = r.idarmazemdestino
                  and lo.buffer = 'N'
                  and ld.buffer = 'N'
                  and r.status <> 'F'
                  and lr.idlote in
                      (select distinct cl.idloteanterior
                         from composicaolote cl, loteremanejamento lr
                        where 1 = 1
                          and lr.idremanejamento = p_idRemanejamento
                          and cl.idlotenovo = lr.idlote));
    
      if (v_remanejamentos is not null) then
        v_msg := t_message('EXISTEM REMANEJAMENTOS PENDENTES CUJO ENDEREÇO DE DESTINO É ' ||
                           '{0}.' || chr(13) || chr(13) ||
                           'É NECESSÁRIO EXECUTAR OS SEGUINTES REMANEJAMENTOS(' ||
                           '{1}).' || chr(13) || chr(13) ||
                           'OPERAÇÃO CANCELADA.');
        v_msg.addParam(v_idlocalorigemFormat);
        v_msg.addParam(v_remanejamentos);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end if;
  end validarFinalizarRemanejamento;

  procedure integrarEsteira
  (
    p_idremanejamento number,
    p_idusuario       number
  ) is
    v_fatorConversao number;
    v_caixaFechada   char(1);
    v_barraEmbalagem varchar2(32);
    v_resto          number;
    v_qtdeCaixa      number;
    v_idlocalOrigem  local.idlocal%type;
    v_estoque        number;
    v_idsOnda        varchar2(512);
    v_msg            t_message;
  
    ESTEIRA_PICKING constant number := 1;
  
    procedure validarIntegracaoEsteira is
    
      v_countValidacao    number;
      v_idLocalOrigemRem  local.idlocal%type;
      v_idLocalDestinoRem local.idlocal%type;
      v_idSetorOrigemRem  setor.idsetor%type;
      v_idSetorDestinoRem setor.idsetor%type;
    
      C_BUFFER_ESTEIRA_ATIVADO    constant number := 1;
      C_BUFFER_ESTEIRA_DESATIVADO constant number := 0;
    
      v_msg t_message;
    begin
      select lo.idlocal, lo.idsetor, ld.idlocal, ld.idsetor
        into v_idLocalOrigemRem, v_idSetorOrigemRem, v_idLocalDestinoRem,
             v_idSetorDestinoRem
        from remanejamento r, local lo, local ld
       where r.idremanejamento = p_idremanejamento
         and lo.idlocal = r.idlocalorigem
         and ld.idlocal = r.idlocaldestino;
    
      if v_idSetorOrigemRem is null then
        v_msg := t_message('Não foi possível criar a integração com esteira do Remanejamento ID: {0} ' ||
                           'pois o setor Local Origem (ID:{1}) não possui setor configurado. Favor, ' ||
                           'regularizar o cadastro para continuar com o processo');
        v_msg.addParam(p_idremanejamento);
        v_msg.addParam(v_idLocalOrigemRem);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if v_idSetorDestinoRem is null then
        v_msg := t_message('Não foi possível criar a integração com esteira do Remanejamento ID: {0} pois ' ||
                           'o setor Local Destino (ID:{1}) não possui setor configurado. Favor, regularizar o ' ||
                           'cadastro para continuar com o processo');
        v_msg.addParam(p_idremanejamento);
        v_msg.addParam(v_idLocalDestinoRem);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    
      select count(1)
        into v_countValidacao
        from remanejamento r, local lo, local ld, setor sd
       where r.idremanejamento = p_idremanejamento
         and lo.idlocal = r.idlocalorigem
         and lo.idarmazem = r.idarmazemorigem
         and lo.buffer = 'S'
         and lo.bufferesteira = C_BUFFER_ESTEIRA_ATIVADO
         and ld.idlocal = r.idlocaldestino
         and ld.idarmazem = r.idarmazemdestino
         and ld.buffer = 'N'
         and ld.bufferesteira = C_BUFFER_ESTEIRA_DESATIVADO
         and sd.idsetor = ld.idsetor
         and sd.codintegracaoesteira is not null;
    
      if v_countValidacao = 0 then
        v_msg := t_message('Não foi possível criar a integração com esteira do Remanejamento ID: {0}. ' ||
                           'Só é possível criar esta integração para remanejamentos com local origem do tipo Buffer ' ||
                           'com parâmetro Buffer Esteira ativado e destino com o parâmetro Código ' ||
                           'de Integração com Esteira configurado no Setor (IDLOCALORIGEM: {1} e IDSETORDESTINO: {2}).');
        v_msg.addParam(p_idremanejamento);
        v_msg.addParam(v_idLocalOrigemRem);
        v_msg.addParam(v_idSetorDestinoRem);
        raise_application_error(-20000, v_msg.formatMessage);
      
      end if;
    end validarIntegracaoEsteira;
  begin
  
    validarIntegracaoEsteira;
  
    for intEsteira in (select sd.codintegracaoesteira codintegracaoesteiraDestino,
                              lr.qtde, lr.idlote, lt.idproduto, lt.barra,
                              r.idusuarioinicio, r.horafimorigem, r.status,
                              r.idlocalorigem
                         from setor sd, local ld, remanejamento r, local lo,
                              setor so, loteremanejamento lr, lote lt
                        where sd.usoexclusivocxmov = 0
                          and sd.codintegracaoesteira is not null
                          and sd.ativo = 'S'
                          and ld.idsetor = sd.idsetor
                          and ld.ativo = 'S'
                          and ld.idregiao is not null
                          and r.idlocaldestino = ld.idlocal
                          and r.idarmazemdestino = ld.idarmazem
                          and r.idremanejamento = p_idremanejamento
                          and lo.idlocal = r.idlocalorigem
                          and lo.idarmazem = r.idarmazemorigem
                          and lo.ativo = 'S'
                          and lo.idregiao is not null
                          and so.idsetor = lo.idsetor
                          and so.ativo = 'S'
                          and lr.idremanejamento = r.idremanejamento
                          and lt.idlote = lr.idlote)
    loop
    
      if (intEsteira.idusuarioinicio is null and
         intEsteira.horafimorigem is null and intEsteira.status <> 'G') then
        v_msg := t_message('Não é possível gerar Integração para o setor de Picking com Esteira, pois o remanejamento de Origem não foi finalizado. OPERAÇÃO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      begin
        select e.barra, e.fatorconversao, e.caixafechada, ll.idlocal
          into v_barraEmbalagem, v_fatorConversao, v_caixaFechada,
               v_idlocalOrigem
          from embalagem e, lote l, lotelocal ll
         where e.idproduto = intEsteira.Idproduto
           and trunc(intEsteira.qtde / e.fatorconversao) > 0
           and e.ativo = 'S'
           and l.idlote = intEsteira.Idlote
           and l.idproduto = e.idproduto
           and l.barra = e.barra
           and ll.idlote = l.idlote
           and ll.idlocal = intEsteira.Idlocalorigem
           and ll.estoque > 0
         order by e.fatorconversao desc;
      exception
        when no_data_found then
          select nvl(sum(ll.estoque), 0)
            into v_estoque
            from embalagem e, lote l, lotelocal ll
           where e.idproduto = intEsteira.Idproduto
             and trunc(intEsteira.qtde / e.fatorconversao) > 0
             and e.ativo = 'S'
             and l.idproduto = e.idproduto
             and l.barra = e.barra
             and ll.idlote = l.idlote
             and ll.idlocal = intEsteira.Idlocalorigem;
        
          select stragg(rr.idromaneio)
            INTO v_idsOnda
            from remanejamentoromaneio rr
           where rr.idremanejamento = p_idremanejamento
           group by rr.idremanejamento;
        
          if (v_estoque = 0) then
            v_msg := t_message('Não foi encontrado estoque no local origem: ' ||
                               '{0}, verifique o processo anterior de separação da(s) onda(s) id(s): ' ||
                               '{1}. OPERAÇÃO CANCELADA.');
            v_msg.addParam(intEsteira.Idlocalorigem);
            v_msg.addParam(v_idsOnda);
            raise_application_error(-20000, v_msg.formatMessage);
          else
            v_msg := t_message('Não foi encontrado embalagem cadastrada para o produto de id: ' ||
                               '{0} ou a embalagem de barra: ' ||
                               '{1} não está ativa. OPERAÇÃO CANCELADA.');
            v_msg.addParam(intEsteira.Idproduto);
            v_msg.addParam(v_barraEmbalagem);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
      end;
    
      if ((v_fatorConversao <> 1) or
         (v_fatorConversao = 1 and v_caixaFechada = 'S')) then
      
        v_barraEmbalagem := intEsteira.Barra;
      
      elsif (v_fatorConversao = 1 and v_caixaFechada = 'N') then
        v_msg := t_message('Não é permitido realizar integração com esteira de embalagens que não sejam ' ||
                           'CAIXA FECHADA ou fator de conversão igual a 1.OPERAÇÃO CANCELADA.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      v_resto := mod(intEsteira.Qtde, v_fatorConversao);
    
      if (v_resto = 0) then
        v_qtdeCaixa := (intEsteira.Qtde / v_fatorConversao);
      else
        v_msg := t_message('Não foi possível realizar a integração com a esteira porque a quantidade remanejada do produto de id: ' ||
                           '{0} deve ser em caixa. OPERAÇÃO CANCELADA.');
        v_msg.addParam(intEsteira.Idproduto);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      for intAutomacao in 1 .. v_qtdeCaixa
      loop
      
        insert into int_automacao_esteira
          (id, esteira, codintegracao, identificador, integrado,
           pesagemliberada, idoperacao, tipooperacao)
        values
          (seq_int_automacao_esteira.nextval, ESTEIRA_PICKING,
           intEsteira.codintegracaoesteiraDestino, v_barraEmbalagem, 0, 0,
           p_idremanejamento, 1);
      
      end loop;
    
    end loop;
  
  end integrarEsteira;

  procedure concluirOrigem
  (
    p_idRemanejamento       in number,
    p_idUsuario             in number,
    p_TipoMenuRemanejamento in number
  ) is
    localOrigem  t_localRemanejamento;
    localDestino t_localRemanejamento;
  
    r_remanejamento remanejamento%rowtype;
  
    v_existeUsuario number;
    v_nomeUsuario   usuario.nomeusuario%type;
    v_msg           t_message;
  
    procedure validarRemanejamento is
    begin
      if (r_remanejamento.status <> 'A') then
        v_msg := t_message('Este remanejamento ja foi finalizado, portanto nao pode ser executado. Operacao Cancelada');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_remanejamento.planejado <> 'S') then
        v_msg := t_message('Este remanejamento nao foi planejado, portanto nao pode ser executado. Operacao Cancelada');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_remanejamento.horafimorigem is not null and
         r_remanejamento.idusuarioinicio is not null) then
        select nomeusuario
          into v_nomeUsuario
          from usuario
         where idusuario = r_remanejamento.idusuarioinicio;
        v_msg := t_message('O remanejamento id {0}' ||
                           ' já teve sua origem finalizada pelo usuario {1}.');
        v_msg.addParam(p_idRemanejamento);
        v_msg.addParam(v_nomeUsuario);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarRemanejamento;
  
  begin
    begin
      select r.*
        into r_remanejamento
        from remanejamento r
       where r.idremanejamento = p_idRemanejamento;
    exception
      when no_data_found then
        v_msg := t_message('Não foi encontrado remanejamento com id informado. IdRemanejamento {0}');
        v_msg.addParam(p_idRemanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
    end;
  
    select count(1)
      into v_existeUsuario
      from usuario u
     where u.idusuario = p_idUsuario;
  
    if (v_existeUsuario = 0) then
      v_msg := t_message('Não foi encontrado usuário com id informado. IdUsuario {0}');
      v_msg.addParam(p_idUsuario);
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    validarRemanejamento;
    validarBufPickEsteira(p_idRemanejamento, p_TipoMenuRemanejamento);
  
    update remanejamento
       set status          = 'G',
           idusuarioinicio = p_idUsuario,
           horafimorigem   = sysdate
     where idremanejamento = p_idRemanejamento;
  
    select l.idlocal, l.tipo, l.idarmazem, l.picking, l.buffer,
           s.codintegracaoesteira
      into localOrigem.idLocal, localOrigem.tipoLocal, localOrigem.idarmazem,
           localOrigem.picking, localOrigem.buffer,
           localOrigem.codIntegracaoEsteira
      from local l, setor s
     where l.idlocal = r_remanejamento.idlocalorigem
       and l.idarmazem = r_remanejamento.idarmazemorigem
       and s.idsetor(+) = l.idsetor;
  
    select l.idlocal, l.tipo, l.idarmazem, l.picking, l.buffer,
           s.codintegracaoesteira
      into localDestino.idLocal, localDestino.tipoLocal,
           localDestino.idarmazem, localDestino.picking, localDestino.buffer,
           localDestino.codIntegracaoEsteira
      from local l, setor s
     where l.idlocal = r_remanejamento.idlocaldestino
       and l.idarmazem = r_remanejamento.idarmazemdestino
       and s.idsetor(+) = l.idsetor;
  
    if (localOrigem.tipoLocal in (1, 2) and localOrigem.buffer = 'N') then
      if (localDestino.tipoLocal = 0)
         and (localDestino.picking = 'S')
         and (localDestino.buffer = 'N')
         and ((localDestino.codIntegracaoEsteira is not null) and
         (length(localDestino.codIntegracaoEsteira) > 0)) then
      
        integrarEsteira(p_idRemanejamento, p_idUsuario);
      end if;
    end if;
  
    pk_utilities.GeraLog(p_idUsuario,
                         'REABASTECIMENTO ORIGEM, REABASTECIMENTO ' ||
                          p_idRemanejamento || ', LOCAL ORIGEM ' ||
                          localOrigem.tipoLocal ||
                          ' REALIZADO PELO USUARIO ' || p_idUsuario,
                         p_idRemanejamento, 'RO');
  
  end concluirOrigem;

  procedure ExecOrigemRemBufferPicking
  (
    p_idOnda        in number,
    p_idLocalBuffer in local.idlocal%type,
    p_idProduto     in number,
    p_idUsuario     in number
  ) is
  
    localOrigem  t_localRemanejamento;
    localDestino t_localRemanejamento;
  
  begin
    for r_Remanejamentos in (select distinct r.idremanejamento,
                                             r.idlocalorigem,
                                             r.idlocaldestino,
                                             r.idarmazemorigem,
                                             r.idarmazemdestino
                               from remanejamento r, remanejamentoromaneio rr,
                                    lote lt, gtt_selecao g
                              where rr.idromaneio = p_idonda
                                and r.idremanejamento = rr.idremanejamento
                                and r.status = 'A'
                                and r.horafimorigem is null
                                and r.idusuarioinicio is null
                                and r.idlocalorigem = p_idLocalBuffer
                                and lt.idlote = rr.idlote
                                and lt.idproduto = p_idproduto
                                and r.idmovimentacao = g.idselecionado)
    loop
    
      select l.idlocal, l.tipo, l.idarmazem, l.picking, l.buffer,
             s.codintegracaoesteira, l.bufferesteira
        into localOrigem.idLocal, localOrigem.tipoLocal,
             localOrigem.idarmazem, localOrigem.picking, localOrigem.buffer,
             localOrigem.codIntegracaoEsteira, localOrigem.bufferesteira
        from local l, setor s
       where l.idlocal = r_Remanejamentos.idlocalorigem
         and l.idarmazem = r_Remanejamentos.idarmazemorigem
         and s.idsetor(+) = l.idsetor;
    
      select l.idlocal, l.tipo, l.idarmazem, l.picking, l.buffer,
             s.codintegracaoesteira
        into localDestino.idLocal, localDestino.tipoLocal,
             localDestino.idarmazem, localDestino.picking,
             localDestino.buffer, localDestino.codIntegracaoEsteira
        from local l, setor s
       where l.idlocal = r_Remanejamentos.idlocaldestino
         and l.idarmazem = r_Remanejamentos.idarmazemdestino
         and s.idsetor(+) = l.idsetor;
    
      if ((localOrigem.tipoLocal = 0) and (localOrigem.picking = 'S') and
         (localOrigem.buffer = 'S') and (localOrigem.bufferEsteira = 1)) then
      
        if ((localDestino.tipoLocal = 0) and (localDestino.picking = 'S') and
           (localDestino.buffer = 'N') and
           (localDestino.codIntegracaoEsteira is not null and
           length(localDestino.codIntegracaoEsteira) > 0)) then
          update loteremanejamento lr
             set lr.conferido = 'S'
           where lr.idremanejamento = r_Remanejamentos.Idremanejamento
             and lr.conferido = 'N';
        
          update remanejamento rem
             set rem.status          = 'G',
                 rem.idusuarioinicio = p_idusuario,
                 rem.horafimorigem   = sysdate
           where rem.Idremanejamento = r_Remanejamentos.Idremanejamento;
        
          integrarEsteira(r_Remanejamentos.Idremanejamento, p_idusuario);
        end if;
      end if;
    end loop;
  end ExecOrigemRemBufferPicking;

  procedure conferirLoteIndustria
  (
    p_idremanejamento in remanejamento.idremanejamento%type,
    p_loteIndustria   in lote.descr%type
  ) is
  
    v_loteIndustria lote.descr%type;
  
  begin
    v_loteIndustria := trim(p_loteIndustria);
  
    if (v_loteIndustria is null) then
      return;
    end if;
  
    update loteremanejamento lr
       set lr.conferido     = 'S',
           lr.qtdeconferida = lr.qtde
     where lr.idremanejamento = p_idremanejamento
       and exists (select 1
              from loteremanejamento lra, lote lt
             where lra.idremanejamento = p_idremanejamento
               and lra.idlote = lt.idlote
               and lra.idremanejamento = lr.idremanejamento
               and lra.idlote = lr.idlote
               and lra.conferido = 'N'
               and upper(nvl(lt.descr, 'NAOINFORMADO')) =
                   upper(v_loteIndustria));
  
  end conferirLoteIndustria;

  function retorna_qtde_caixa
  (
    p_idremanejamento in number,
    p_idproduto       in number default null,
    p_loteIndustria   in varchar2 default null,
    p_conferido       in varchar2 default null
  ) return varchar2 is
    cursor c_cx
    (
      p_idremanejamento in number,
      p_idproduto       in number default null,
      p_loteIndustria   in varchar2 default null,
      p_conferido       in varchar2 default null
    ) is
      select sum(lr.qtde), e.fatorconversao, l.idproduto
        from loteremanejamento lr, lote l, embalagem e
       where lr.idremanejamento = p_idremanejamento
         and lr.conferido = nvl(p_conferido, lr.conferido)
         and l.idlote = lr.idlote
         and ((p_loteIndustria is null) or
             (l.descr is null and p_loteIndustria = '-1') or
             (l.descr = p_loteIndustria))
         and l.idproduto = nvl(p_idproduto, l.idproduto)
         and e.barra = pk_produto.retornarcodbarramaiorfator(l.idproduto)
         and e.idproduto = l.idproduto
       group by l.idproduto, e.fatorconversao;
  
    v_qtde            number;
    v_caixa           number;
    v_caixaAux        number;
    v_unidade         number;
    v_fcmaior         number;
    v_descr           varchar2(254);
    v_idproduto       number;
    v_descrMenorFator embalagem.descrreduzido%type;
    v_descrMaiorFator embalagem.descrreduzido%type;
  begin
    v_caixa   := 0;
    v_unidade := 0;
  
    if c_cx%isopen then
      close c_cx;
    end if;
  
    open c_cx(p_idremanejamento, p_idproduto, p_loteIndustria, p_conferido);
    fetch c_cx
      into v_qtde, v_fcmaior, v_idproduto;
  
    if c_cx%found then
      while (c_cx%found)
      loop
        if (v_fcmaior > 1) then
          v_caixaAux := trunc(v_qtde / v_fcmaior);
        else
          v_caixaAux := 0;
        end if;
      
        v_caixa := v_caixa + v_caixaAux;
      
        v_unidade := v_unidade + (v_qtde - (v_caixaAux * v_fcmaior));
      
        begin
          select e.descrreduzido
            into v_descrMenorFator
            from embalagem e
           where e.barra =
                 pk_produto.retornarcodbarramenorfator(e.idproduto)
             and e.idproduto = v_idproduto;
        exception
          when no_data_found then
            return 'EMBALAGEM NAO CONFIGURADA';
        end;
      
        begin
          select e.descrreduzido
            into v_descrMaiorFator
            from embalagem e
           where e.fatorconversao = v_fcmaior
             and e.idproduto = v_idproduto
             and e.ativo = 'S'
             and rownum = 1;
        exception
          when no_data_found then
            return 'EMBALAGEM NAO CONFIGURADA';
        end;
      
        if (v_descr is not null) then
          v_descr := null;
        end if;
      
        select v_descr || ' ' ||
                decode(v_caixa, 0,
                       decode(v_unidade, 0, '',
                               v_unidade || ' ' ||
                                nvl(v_descrMenorFator, 'UNIDADE') || ' (1)'),
                       v_caixa || ' ' || v_descrMaiorFator || ' (' ||
                        v_fcmaior || ')' ||
                        decode(v_unidade, 0, '',
                               ' e ' || v_unidade || ' ' ||
                                nvl(v_descrMenorFator, 'UNIDADE') || ' (1)'))
          into v_descr
          from dual;
      
        fetch c_cx
          into v_qtde, v_fcmaior, v_idproduto;
      end loop;
    else
      return 'EMBALAGEM NAO CONFIGURADA';
    end if;
  
    return trim(v_descr);
  end retorna_qtde_caixa;

  function confirmarTrocaLocalDestino
  (
    p_idremanejamento in number,
    p_idtrocalocal    in number,
    p_idusuario       in number
  ) return number is
  
    type tpLoteRem is record(
      idproduto           lote.idproduto%type,
      idlote              lote.idlote%type,
      estado              lote.estado%type,
      loteindustria       lote.descr%type,
      dtvenc              lote.dtvenc%type,
      iddepositante       lote.iddepositante%type,
      loteuniconoendereco produtodepositante.loteuniconoendereco%type,
      idlocaldestino      local.idlocal%type,
      qtdeentregue        number);
  
    type tpMovCancelada is record(
      id             number,
      idonda         number,
      idlote         number,
      idlocaldestino number,
      quantidade     number,
      idnotafiscal   number,
      identificador  number,
      ordem          number);
  
    type vTpLoteRem is table of tpLoteRem;
    type vTpMovCancelada is table of tpMovCancelada;
  
    v_loteremtrocado vTpLoteRem;
    v_movcancelada   vTpMovCancelada;
  
    TROCALOCAL_ERRO    constant number := 0;
    TROCALOCAL_SUCESSO constant number := 1;
  
    TROCA_ANDAMENTO constant number := 0;
    TROCA_REALIZADA constant number := 1;
    TROCA_CANCELADA constant number := 2;
  
    DETALHE_TROCA_ATIVO      constant number := 1;
    DETALHE_TROCA_ALERTA     constant number := 2;
    DETALHE_TROCA_PROCESSADO constant number := 3;
  
    r_trocalocal trocarlocaldestinorem%rowtype;
    v_alerta     number;
  
    v_idlocalorigem number;
  
    v_msg t_message;
  
    v_qtdeCancelada number := 0;
    v_qtdeCriadas   number := 0;
  
    procedure validarPermissaoAlteracaoLocal is
      v_permitiralterarlocalqtdereab number;
    begin
      select count(1) permitiralterarlocalqtdereab
        into v_permitiralterarlocalqtdereab
        from remanejamento r, loteremanejamento lr, lote lt, depositante d
       where r.idremanejamento = p_idremanejamento
         and d.identidade = lt.iddepositante
         and lt.idlote = lr.idlote
         and lr.idremanejamento = r.idremanejamento
         and d.permitiralterarlocalqtdereab = 1;
    
      if (v_permitiralterarlocalqtdereab = 0) then
        v_msg := t_message('O Remanejamento {0} não permite entregar em vários endereços de destino.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarPermissaoAlteracaoLocal;
  
    procedure getTrocaLocalDestino is
    begin
      begin
        select tl.*
          into r_trocalocal
          from trocarlocaldestinorem tl
         where tl.id = p_idtrocalocal;
      exception
        when no_data_found then
          v_msg := t_message('Troca de Local de Destino do remanejamento {0} não encontrada.');
          v_msg.addParam(p_idremanejamento);
          raise_application_error(-20000, v_msg.formatMessage);
      end;
    
      if (r_trocalocal.idremanejamento <> p_idremanejamento) then
        v_msg := t_message('Troca de Local de Destino não pertence ao remanejamento {0}.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_trocalocal.status = TROCA_REALIZADA) then
        v_msg := t_message('Troca de Local de Destino do remanejamento {0} está FINALIZADA.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_trocalocal.status = TROCA_CANCELADA) then
        v_msg := t_message('Troca de Local de Destino do remanejamento {0} está CANCELADA.');
        v_msg.addParam(p_idremanejamento);
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end getTrocaLocalDestino;
  
    procedure validarDadosTrocaLocalDestino is
      v_qtdeTotalEntregue number;
    begin
      select sum(tld.qtdeentregue * e.fatorconversao)
        into v_qtdeTotalEntregue
        from trocarlocaldestinoremdet tld, trocarlocaldestinorem tl,
             embalagem e
       where tl.id = r_trocalocal.id
         and tl.status = TROCA_ANDAMENTO
         and tl.id = tld.idtrocalocal
         and tld.status = DETALHE_TROCA_ATIVO
         and e.idproduto = tld.idproduto
         and e.barra = tld.barra;
    
      if (v_qtdeTotalEntregue = 0) then
        v_msg := t_message('Não existem quantidade(s) entregue(s) para realizar a troca de local destino.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    
      if (r_trocalocal.qtdeentregar <> v_qtdeTotalEntregue) then
        v_msg := t_message('A quantide total entregue ativa é diferente da quantidade total a entregar.');
        raise_application_error(-20000, v_msg.formatMessage);
      end if;
    end validarDadosTrocaLocalDestino;
  
    procedure validarEstoqueMinimoEntregue is
      v_estoqueMinimoEntregue boolean;
    begin
      --Verifica se existem outras operações diferente da onda que utilizam o estoque a entregar no remanejamento
      v_estoqueMinimoEntregue := false;
      for c_estreservado in (select idproduto, idlocal,
                                    sum(pendencia - qtdemovimentada) reservado
                               from (select lt.idproduto, ll.idlocal,
                                             sum(ll.pendencia - ll.estoque) pendencia,
                                             0 qtdemovimentada
                                        from lotelocal ll, local ld, lote lt,
                                             loteremanejamento lr
                                       where lt.idlote = ll.idlote
                                         and ld.idarmazem = ll.idarmazem
                                         and ld.idlocal = ll.idlocal
                                         and ll.idarmazem =
                                             r_trocalocal.idarmazem
                                         and ll.idlocal =
                                             r_trocalocal.idlocaldestino
                                         and ll.pendencia > 0
                                         and lr.idlote = lt.idlote
                                         and lr.idremanejamento =
                                             r_trocalocal.idremanejamento
                                       group by lt.idproduto, ll.idlocal
                                      union
                                      select lt.idproduto, lo.idlocal,
                                             0 pendencia,
                                             sum(m.qtdemovimentada) qtdemovimentada
                                        from movimentacao m, lote lt, local lo,
                                             loteremanejamento lr
                                       where lo.idarmazem =
                                             r_trocalocal.idarmazem
                                         and lo.idlocal =
                                             r_trocalocal.idlocaldestino
                                         and lo.id = m.idlocalorigem
                                         and lt.idlote = m.idlote
                                         and m.status in (0, 1)
                                         and lr.idlote = lt.idlote
                                         and lr.idremanejamento =
                                             r_trocalocal.idremanejamento
                                       group by lt.idproduto, lo.idlocal)
                              group by idproduto, idlocal
                             having sum(pendencia - qtdemovimentada) > 0)
      loop
        v_estoqueMinimoEntregue := false;
        for c_entregue in (select tld.idproduto, tld.idlocaldestino,
                                  sum(tld.qtdeentregue * e.fatorconversao) totalentregue
                             from trocarlocaldestinoremdet tld,
                                  trocarlocaldestinorem tl, embalagem e
                            where tl.id = r_trocalocal.id
                              and tl.status = TROCA_ANDAMENTO
                              and tl.id = tld.idtrocalocal
                              and tld.status = DETALHE_TROCA_ATIVO
                              and tld.idproduto = c_estreservado.idproduto
                              and tld.idlocaldestino =
                                  c_estreservado.idlocal
                              and e.idproduto = tld.idproduto
                              and e.barra = tld.barra
                            group by tld.idproduto, tld.idlocaldestino
                           having sum(tld.qtdeentregue * e.fatorconversao) >= c_estreservado.reservado)
        loop
          v_estoqueMinimoEntregue := true;
        end loop;
      
        if (not v_estoqueMinimoEntregue) then
          update trocarlocaldestinoremdet
             set status = DETALHE_TROCA_ALERTA
           where idproduto = c_estreservado.idproduto
             and status = DETALHE_TROCA_ATIVO;
        end if;
      end loop;
    end validarEstoqueMinimoEntregue;
  
    procedure prepararDadosParaTroca is
      v_qtdelote number;
      v_qtdeGtt  number;
    begin
      for c_loterem in (select lt.idproduto, lt.idlote, lr.qtde
                          from loteremanejamento lr, lote lt
                         where lr.idremanejamento =
                               r_trocalocal.idremanejamento
                           and lt.idlote = lr.idlote
                         order by lt.idproduto, lr.qtde)
      loop
        v_qtdelote := c_loterem.qtde;
        for c_troca in (select tld.idproduto, tld.idlocaldestino,
                               sum((tld.qtdeentregue -
                                    nvl(tld.qtdeutilizada, 0)) *
                                    e.fatorconversao) totalentregue
                          from trocarlocaldestinoremdet tld,
                               trocarlocaldestinorem tl, embalagem e
                         where tl.id = r_trocalocal.id
                           and tl.status = TROCA_ANDAMENTO
                           and tl.id = tld.idtrocalocal
                           and tld.status = DETALHE_TROCA_ATIVO
                           and tld.idproduto = c_loterem.idproduto
                           and e.idproduto = tld.idproduto
                           and e.barra = tld.barra
                         group by tld.idproduto, tld.idlocaldestino
                         order by sum(tld.qtdeentregue * e.fatorconversao),
                                  tld.idproduto, tld.idlocaldestino)
        loop
        
          if (c_troca.totalentregue > v_qtdelote) then
            v_qtdeGtt := v_qtdelote;
          else
            v_qtdeGtt := c_troca.totalentregue;
          
          end if;
        
          update trocarlocaldestinoremdet tld
             set tld.qtdeutilizada = nvl(tld.qtdeutilizada, 0) + v_qtdeGtt
           where idproduto = c_troca.idproduto
             and idlocaldestino = c_troca.idlocaldestino
             and status = DETALHE_TROCA_ATIVO;
        
          update trocarlocaldestinoremdet tld
             set status = DETALHE_TROCA_PROCESSADO
           where idproduto = c_troca.idproduto
             and idlocaldestino = c_troca.idlocaldestino
             and status = DETALHE_TROCA_ATIVO
             and tld.qtdeutilizada = tld.qtdeentregue;
        
          insert into gtt_trocaloteremanejamento
            (idremanejamento, idlote, idlocaldestino, qtde)
          values
            (r_trocalocal.idremanejamento, c_loterem.idlote,
             c_troca.idlocaldestino, v_qtdeGtt);
        
          v_qtdelote := v_qtdelote - v_qtdeGtt;
          exit when v_qtdelote = 0;
        end loop;
      end loop;
    end prepararDadosParaTroca;
  
    procedure cancelarMovLoteRemAtual is
    begin
      -- Cancelar movimentações de lote que estão no remanejamento 
      -- quando não foi entregue a quantidade suficiente que atenda a onda
      v_movcancelada := vTpMovCancelada();
      for c_movafet in (select m.id, m.idonda, lo.idarmazem, lo.idlocal,
                               m.idlote, m.quantidade, m.idlocaldestino,
                               m.idnotafiscal, m.identificador, m.ordem
                          from movimentacao m, local lo, lote lt
                         where lt.idlote = m.idlote
                           and lo.idarmazem = r_trocalocal.idarmazem
                           and lo.idlocal = r_trocalocal.idlocaldestino
                           and lo.id = m.idlocalorigem
                           and m.status in (0, 1)
                           and exists
                         (select 1
                                  from gtt_trocaloteremanejamento g
                                 where g.idremanejamento =
                                       r_trocalocal.idremanejamento
                                   and g.idlote = m.idlote))
      loop
        pk_estoque.retirar_pendencia(c_movafet.idarmazem, c_movafet.idlocal,
                                     c_movafet.idlote, c_movafet.quantidade,
                                     p_idusuario,
                                     'RETIRADA PENDENCIA PARA MOVIMENTACAO LOTE POR MOTIVO DE TROCA DE ENDEREÇO DE DESTINO DO REMANEJAMENTO:' ||
                                      r_trocalocal.idremanejamento ||
                                      ', ONDA ID: ' || c_movafet.idonda ||
                                      ', MOVIMENTAÇÃO ID: ' || c_movafet.id);
      
        update movimentacao m
           set m.status = 3
         where m.id = c_movafet.id;
      
        v_movcancelada.extend();
        v_movcancelada(v_movcancelada.count).id := c_movafet.id;
        v_movcancelada(v_movcancelada.count).idonda := c_movafet.idonda;
        v_movcancelada(v_movcancelada.count).idlote := c_movafet.idlote;
        v_movcancelada(v_movcancelada.count).idlocaldestino := c_movafet.idlocaldestino;
        v_movcancelada(v_movcancelada.count).quantidade := c_movafet.quantidade;
        v_movcancelada(v_movcancelada.count).idnotafiscal := c_movafet.idnotafiscal;
        v_movcancelada(v_movcancelada.count).identificador := c_movafet.identificador;
        v_movcancelada(v_movcancelada.count).ordem := c_movafet.ordem;
      
        v_qtdeCancelada := v_qtdeCancelada + c_movafet.quantidade;
      end loop;
    end cancelarMovLoteRemAtual;
  
    procedure finalizarRemanejamentoAtual is
      v_totallote number;
    begin
      -- Atualizando lotes do remanejamento atual para finaliza-lo
      v_loteremtrocado := vTpLoteRem();
    
      update remanejamento
         set planejado = 'N',
             cadmanual = 'N'
       where idremanejamento = r_trocalocal.idremanejamento;
    
      for c_troca in (select lt.idproduto, g.idlote, lt.estado,
                             lt.descr loteindustria, lt.dtvenc,
                             lt.iddepositante, pd.loteuniconoendereco,
                             g.idlocaldestino, sum(g.qtde) totalentregue
                        from gtt_trocaloteremanejamento g, lote lt,
                             produtodepositante pd
                       where g.idremanejamento =
                             r_trocalocal.idremanejamento
                         and pd.idproduto = lt.idproduto
                         and pd.identidade = lt.iddepositante
                         and lt.idlote = g.idlote
                       group by lt.idproduto, g.idlote, lt.estado, lt.descr,
                                lt.dtvenc, lt.iddepositante,
                                pd.loteuniconoendereco, g.idlocaldestino)
      loop
        if (c_troca.idlocaldestino <> r_trocalocal.idlocaldestino) then
          update loteremanejamento
             set qtde = qtde - c_troca.totalentregue
           where idremanejamento = r_trocalocal.idremanejamento
             and idlote = c_troca.idlote;
        
          v_loteremtrocado.extend();
          v_loteremtrocado(v_loteremtrocado.count).idproduto := c_troca.idproduto;
          v_loteremtrocado(v_loteremtrocado.count).idlote := c_troca.idlote;
          v_loteremtrocado(v_loteremtrocado.count).estado := c_troca.estado;
          v_loteremtrocado(v_loteremtrocado.count).loteindustria := c_troca.loteindustria;
          v_loteremtrocado(v_loteremtrocado.count).dtvenc := c_troca.dtvenc;
          v_loteremtrocado(v_loteremtrocado.count).iddepositante := c_troca.iddepositante;
          v_loteremtrocado(v_loteremtrocado.count).loteuniconoendereco := c_troca.loteuniconoendereco;
          v_loteremtrocado(v_loteremtrocado.count).idlocaldestino := c_troca.idlocaldestino;
          v_loteremtrocado(v_loteremtrocado.count).qtdeentregue := c_troca.totalentregue;
        end if;
      end loop;
    
      -- Retirando lote que não serão entregues no remanejamento atual
      for c_loteretirar in (select lr.idremanejamento, lt.idlote
                              from loteremanejamento lr, lote lt
                             where lr.idremanejamento =
                                   r_trocalocal.idremanejamento
                               and lt.idlote = lr.idlote
                               and lr.qtde = 0)
      loop
        delete from loteremanejamento
         where idremanejamento = c_loteretirar.idremanejamento
           and idlote = c_loteretirar.idlote;
      end loop;
    
      -- Finalizando o remanejamento atual
      select count(*)
        into v_totallote
        from loteremanejamento
       where idremanejamento = r_trocalocal.idremanejamento;
    
      if (v_totallote > 0) then
        -- Finaliza o planejamento      
        update remanejamento
           set planejado = 'S'
         where idremanejamento = r_trocalocal.idremanejamento;
      
        pk_Remanejamento.finalizarRemanejamento(r_trocalocal.idremanejamento,
                                                p_idusuario);
      else
        update trocarlocaldestinorem
           set idremanejamento = null
         where idremanejamento = r_trocalocal.idremanejamento;
      
        delete from remanejamentoromaneio
         where idremanejamento = r_trocalocal.idremanejamento;
      
        delete from remanejamento
         where idremanejamento = r_trocalocal.idremanejamento;
      end if;
    end finalizarRemanejamentoAtual;
  
    procedure criarNovoRemParaNovoDestino is
      r_loteunico       pk_lote.t_loteunico;
      v_mensagem        varchar2(1000);
      v_idremanejamento number;
    begin
      -- Criando remanejamento do lotes que vão para outros endereços
      for i in 1 .. v_loteremtrocado.count
      loop
        r_loteunico.idProduto           := v_loteremtrocado(i).idproduto;
        r_loteunico.estado              := v_loteremtrocado(i).estado;
        r_loteunico.loteindustria       := v_loteremtrocado(i).loteindustria;
        r_loteunico.dtvencimento        := v_loteremtrocado(i).dtvenc;
        r_loteunico.loteuniconoendereco := v_loteremtrocado(i)
                                           .loteuniconoendereco;
        r_loteunico.iddepositante       := v_loteremtrocado(i).iddepositante;
      
        -- Validação de compatibilidade para o endereço que o lote será remanejado.
        if not
            pk_lote.isLocalPodeReceberLoteUnico(r_loteunico,
                                                r_trocalocal.idarmazem,
                                                v_loteremtrocado(i)
                                                 .idlocaldestino, v_mensagem) then
          if v_mensagem is not null then
            v_msg := t_message('ERRO NO LOTE INDÚSTRIA: {0}. LOTE NÃO PODE SER ALOCADO NO ENDEREÇO {1}. ERRO NA VALIDAÇÃO DO REMANEJAMENTO: {2}');
            v_msg.addParam(r_loteunico.loteindustria);
            v_msg.addParam(v_loteremtrocado(i).idlocaldestino);
            v_msg.addParam(v_mensagem);
            raise_application_error(-20000, v_msg.formatMessage);
          end if;
        end if;
      
        -- Cria o remanejamento
        select seq_remanejamento.nextval
          into v_idremanejamento
          from dual;
      
        insert into remanejamento
          (idremanejamento, idarmazemorigem, idlocalorigem,
           idarmazemdestino, idlocaldestino, datahora, idusuariotela, status,
           cadmanual, descrpalet, planejado)
        values
          (v_idremanejamento, r_trocalocal.idarmazem,
           r_trocalocal.idlocalorigem, r_trocalocal.idarmazem,
           v_loteremtrocado(i).idlocaldestino, sysdate, p_idusuario, 'A',
           'N',
           'TROCA DE LOCAL DESTINO DO REMANEJAMENTO ' ||
            r_trocalocal.idremanejamento, 'N');
      
        -- Vincula o lote no remanejamento 
        insert into loteremanejamento
          (idremanejamento, idlote, qtde, conferido, controlaqtde)
        values
          (v_idremanejamento, v_loteremtrocado(i).idlote,
           v_loteremtrocado(i).qtdeentregue, 'S', 'S');
      
        -- Finaliza o planejamento      
        update remanejamento
           set planejado = 'S'
         where idremanejamento = v_idremanejamento;
      
        -- Executa o remanejamento
        pk_Remanejamento.finalizarRemanejamento(v_idremanejamento,
                                                p_idusuario);
      end loop;
    end criarNovoRemParaNovoDestino;
  
    -- Refactored procedure criarMovNovoLocalDestino 
    procedure criarMovNovoLocalDestino is
      v_idconfiguracaoonda  number;
      r_movNovaTrocada      movimentacao%rowtype;
      v_idgrupomovimentacao number;
      v_qtdemov             number;
      v_qtdenova            number;
    begin
      -- Criar movimentações novas para os lotes que foram afetados pelo remanejamento para pegar das novas origens
      for i in 1 .. v_movcancelada.count
      loop
        select r.idconfiguracaoonda
          into v_idconfiguracaoonda
          from romaneiopai r
         where r.idromaneio = v_movcancelada(i).idonda;
      
        v_qtdemov := v_movcancelada(i).quantidade;
        for c_novolocal in (select idlote, idendereco, idarmazem, idlocal,
                                   sum(totalentregue - totalmov) totalrestante
                              from (select g.idlote, ld.id idendereco,
                                            ld.idarmazem,
                                            g.idlocaldestino idlocal,
                                            sum(g.qtde) totalentregue,
                                            0 totalmov
                                       from gtt_trocaloteremanejamento g,
                                            lote lt, local ld
                                      where g.idremanejamento =
                                            r_trocalocal.idremanejamento
                                        and lt.idlote = g.idlote
                                        and g.idlote = v_movcancelada(i)
                                           .idlote
                                        and ld.idarmazem =
                                            r_trocalocal.idarmazem
                                        and ld.idlocal = g.idlocaldestino
                                      group by g.idlote, ld.id, ld.idarmazem,
                                               g.idlocaldestino
                                     union
                                     select m.idlote, lo.id idendereco,
                                            lo.idarmazem, lo.idlocal,
                                            0 totalentregue,
                                            sum(m.quantidade) totalmov
                                       from movimentacao m, local lo,
                                            gtt_trocaloteremanejamento g
                                      where g.idlote = m.idlote
                                        and g.idlocaldestino = lo.idlocal
                                        and lo.idarmazem =
                                            r_trocalocal.idarmazem
                                        and lo.id = m.idlocalorigem
                                        and m.idlote = v_movcancelada(i)
                                           .idlote
                                        and m.status in (0, 1)
                                      group by m.idlote, lo.id, lo.idarmazem,
                                               lo.idlocal)
                             group by idlote, idendereco, idarmazem, idlocal
                            having sum(totalentregue - totalmov) > 0)
        loop
          -- calcula a qtde correta para a geração da movimentação 
          if (c_novolocal.totalrestante > v_qtdemov) then
            v_qtdenova := v_qtdemov;
          else
            v_qtdenova := c_novolocal.totalrestante;
          end if;
        
          pk_estoque.incluir_pendencia(c_novolocal.idarmazem,
                                       c_novolocal.idlocal,
                                       c_novolocal.idlote, v_qtdenova,
                                       p_idusuario,
                                       'ADICIONADO PENDENCIA PARA NOVA MOVIMENTACAO CRIADA POR MOTIVO DE TROCA DE ENDEREÇO DESTINO NO REMANEJAMENTO: ' ||
                                        r_trocalocal.idremanejamento ||
                                        ' IDTROCALOCAL:' || r_trocalocal.id ||
                                        ', ONDA ID: ' || v_movcancelada(i)
                                       .idonda);
        
          r_movNovaTrocada.id              := null;
          r_movNovaTrocada.idlocalorigem   := c_novolocal.idendereco;
          r_movNovaTrocada.idlocaldestino  := v_movcancelada(i)
                                              .idlocaldestino;
          r_movNovaTrocada.quantidade      := v_qtdenova;
          r_movNovaTrocada.etapa           := 1;
          r_movNovaTrocada.idlote          := c_novolocal.idlote;
          r_movNovaTrocada.status          := 0;
          r_movNovaTrocada.idonda          := v_movcancelada(i).idonda;
          r_movNovaTrocada.qtdemovimentada := v_qtdenova;
          r_movNovaTrocada.idnotafiscal    := v_movcancelada(i).idnotafiscal;
          r_movNovaTrocada.datainicio      := null;
          r_movNovaTrocada.idusuario       := null;
          r_movNovaTrocada.qtdeconferida   := 0;
          r_movNovaTrocada.identificador   := v_movcancelada(i)
                                              .identificador;
          r_movNovaTrocada.tiposeparacao   := null;
          r_movNovaTrocada.ordem           := v_movcancelada(i).ordem;
        
          pk_triggers_control.disableTrigger('T_insereMovimentacao');
        
          v_idgrupomovimentacao := pk_onda.inserirMovimentacao(r_movNovaTrocada,
                                                               v_idgrupomovimentacao);
        
          pk_triggers_control.enableTrigger('T_insereMovimentacao');
        
          v_qtdemov := v_qtdemov - v_qtdenova;
        
          v_qtdeCriadas := v_qtdeCriadas + v_qtdenova;
          exit when v_qtdemov = 0;
        end loop;
        pk_romaneio.preencherInfSeparacao(v_movcancelada(i).idonda,
                                          v_idconfiguracaoonda);
      end loop;
    
      if (v_qtdeCriadas <> v_qtdeCancelada) then
        raise_application_error(-20000,
                                'Não foi possível concluir a operação, a quantidade de movimentação cancelada: ' ||
                                 v_qtdeCancelada ||
                                 ' é diferente da quantidade nova criada: ' ||
                                 v_qtdeCriadas);
      end if;
    end criarMovNovoLocalDestino;
  begin
    validarPermissaoAlteracaoLocal;
    getTrocaLocalDestino;
    validarDadosTrocaLocalDestino;
    validarEstoqueMinimoEntregue;
  
    select count(*)
      into v_alerta
      from trocarlocaldestinoremdet
     where idtrocalocal = r_trocalocal.id
       and status = DETALHE_TROCA_ALERTA;
  
    if (v_alerta > 0) then
      return TROCALOCAL_ERRO;
    end if;
  
    prepararDadosParaTroca;
    cancelarMovLoteRemAtual;
    finalizarRemanejamentoAtual;
    criarNovoRemParaNovoDestino;
    criarMovNovoLocalDestino;
  
    update trocarlocaldestinorem
       set status          = TROCA_REALIZADA,
           datafinalizacao = sysdate
     where id = r_trocalocal.id;
  
    pk_utilities.GeraLog(p_idusuario,
                         'Troca Local Destino id: ' || r_trocalocal.id ||
                          ' Realizada.', r_trocalocal.idremanejamento, 'TL');
  
    return TROCALOCAL_SUCESSO;
  end;

  function verificaCompOrigemDestino
  (
    p_qtdeTotalLote      in lote.qtdedisponivel%type,
    p_fatorConversaoLote in lote.fatorconversao%type,
    p_qtdeLoteRemanejado in lote.qtdedisponivel%type
  ) return boolean is
  begin
    -- verifica se a quantidade escolhida pode formar uma ou mais caixas exatas
    -- baseando-se no fator do lote selecionado  
    -- e se com a quantidade remanescente na origem também será possível formar
    -- caixas exatas com o mesmo fator do lote selecionado, garantindo assim,
    -- a compatibiliadade com o setor.  
    if ((mod(p_qtdeLoteRemanejado, p_fatorConversaoLote) = 0) and
       (mod((p_qtdeTotalLote - p_qtdeLoteRemanejado), p_fatorConversaoLote) = 0)) then
      return true;
    else
      return false;
    end if;
  end verificaCompOrigemDestino;

  procedure infLoteIndRemanejarMaterial
  (
    p_idLote        in number,
    p_loteIndustria in varchar2
  ) is
    v_iddepositante number;
    v_idproduto     number;
    v_dtvenc        date;
  begin
  
    select l.iddepositante, l.idproduto, l.dtvenc
      into v_iddepositante, v_idproduto, v_dtvenc
      from lote l
     where l.idlote = p_idLote;
  
    if (pk_lote.isLoteIndustriaComMaisDeUmVenc(v_iddepositante, v_idproduto,
                                               p_loteIndustria, v_dtvenc)) then
      raise_application_error(-20000,
                              'Não é possível cadastrar lote do mesmo produto/depositante com o mesmo lote indústria e data de vencimento. Lote: ' ||
                               p_idLote);
    end if;
  
    update lote
       set descr = p_loteIndustria
     where idlote = p_idLote;
  end;

  function validarImpressaoEtqRemanej
  (
    p_idUsuario    in number,
    p_idsupervisor in number := 0
  ) return number is
  
    SOLICITAR_SENHASUPERVISOR constant number := 0;
    IMPRIMIR_DIRETO           constant number := 1;
    PRE_VISUALIZAR_IMPRESSAO  constant number := 2;
  
    C_NAO constant number := 0;
    C_SIM constant number := 1;
  
    v_solSenhaSuperReimpEtqRemanej number;
    v_preVisualizarEtqRemanej      number;
    v_existeEtqImpressa            number;
  
    v_resultado number;
    v_finalizar number;
    v_validar   number;
  
    v_msg t_message;
  
  begin
  
    v_resultado := PRE_VISUALIZAR_IMPRESSAO;
    v_finalizar := C_NAO;
  
    select count(1)
      into v_existeEtqImpressa
      from remanejamento rm, gtt_selecao g
     where rm.idremanejamento = g.idselecionado
       and rm.etiquetaremanejamentoimpressa = C_SIM;
  
    select count(*)
      into v_validar
      from dual
     where exists
     (select 1
              from gtt_selecao g, remanejamento r
             where r.idremanejamento = g.idselecionado
               and not exists
             (select 1
                      from loteremanejamento lr
                     where lr.idremanejamento = r.idremanejamento));
  
    if (v_validar > 0) then
      v_msg := t_message('Existem remanejamentos selecionados que não possuem lotes vinculados.');
      raise_application_error(-20000, v_msg.formatMessage);
    end if;
  
    for c_idRemanejamento in (select idselecionado
                                from gtt_selecao)
    loop
    
      if (v_existeEtqImpressa > 0) then
        for c_depositantes in (select distinct d.identidade,
                                               d.solsenhasuperreimpetiqremaneja,
                                               d.previsualizaretiqremanejamento
                                 from loteremanejamento lmr, lote lt,
                                      depositante d
                                where lmr.idremanejamento =
                                      c_idRemanejamento.Idselecionado
                                  and lt.idlote = lmr.idlote
                                  and d.identidade = lt.iddepositante)
        loop
          if (c_depositantes.solsenhasuperreimpetiqremaneja = C_SIM and
             p_idSupervisor = 0) then
            v_resultado := SOLICITAR_SENHASUPERVISOR;
            v_finalizar := C_SIM;
            exit;
          else
            if (c_depositantes.previsualizaretiqremanejamento = C_NAO) then
              v_resultado := IMPRIMIR_DIRETO;
              v_finalizar := C_SIM;
              exit;
            end if;
          end if;
        end loop;
      else
        for c_depositantes in (select distinct d.identidade,
                                               d.previsualizaretiqremanejamento
                                 from loteremanejamento lmr, lote lt,
                                      depositante d
                                where lmr.idremanejamento =
                                      c_idRemanejamento.Idselecionado
                                  and lt.idlote = lmr.idlote
                                  and d.identidade = lt.iddepositante)
        loop
          if (c_depositantes.previsualizaretiqremanejamento = C_NAO) then
            v_resultado := IMPRIMIR_DIRETO;
            v_finalizar := C_SIM;
            exit;
          end if;
        end loop;
      end if;
    
      if (v_finalizar = C_SIM) then
        exit;
      end if;
    
    end loop;
  
    return v_resultado;
  
  end validarImpressaoEtqRemanej;

  procedure regraLoteVencimentoUnicoNoEnd(p_idremanejamento in number) is
    r_loteunico                pk_lote.t_loteunico;
    r_loteunicoComp            pk_lote.t_loteunico;
    r_loteunicoBase            pk_lote.t_loteunico;
    v_retorno                  varchar2(500);
    v_lotevencimentouniconoend number;
    r_remanejamento            t_rem;
    v_msg                      t_message;
  begin
  
    select count(1)
      into v_lotevencimentouniconoend
      from remanejamento r, local ld, setor s
     where r.idremanejamento = p_idremanejamento
       and ld.idlocal = r.idlocaldestino
       and s.idsetor = ld.idsetor
       and s.lotevencimentouniconoend = 1;
  
    if (v_lotevencimentouniconoend > 0) then
    
      for r_loteunico in (select distinct lt.idlote, lt.idproduto,
                                          lt.descr loteindustria,
                                          lt.dtvenc dtvencimento,
                                          lt.iddepositante,
                                          pd.vencimentouniconoendereco
                            from loteremanejamento lr, lote lt,
                                 produtodepositante pd
                           where lr.idremanejamento = p_idremanejamento
                             and lr.idlote = lt.idlote
                             and lt.idlote = lr.idlote
                             and pd.idproduto = lt.idproduto
                             and pd.identidade = lt.iddepositante)
      loop
      
        r_loteunicoBase.idProduto                 := r_loteunico.idproduto;
        r_loteunicoBase.loteindustria             := r_loteunico.loteindustria;
        r_loteunicoBase.dtvencimento              := r_loteunico.dtvencimento;
        r_loteunicoBase.iddepositante             := r_loteunico.iddepositante;
        r_loteunicoBase.vencimentouniconoendereco := r_loteunico.vencimentouniconoendereco;
      
        for r_loteunicoComp in (select lt.idlote, lt.idproduto,
                                       lt.descr loteindustria,
                                       lt.dtvenc dtvencimento,
                                       lt.iddepositante,
                                       pd.vencimentouniconoendereco
                                  from remanejamento r, local ld,
                                       lotelocal ll, lote lt,
                                       produtodepositante pd
                                 where r.idremanejamento = p_idremanejamento
                                   and ld.idlocal = r.idlocaldestino
                                   and ll.idendereco = ld.id
                                   and ll.idlocal = ld.idlocal
                                   and ll.idarmazem = ld.idarmazem
                                   and (ll.estoque + ll.adicionar) > 0
                                   and lt.idlote = ll.idlote
                                   and pd.idproduto = lt.idproduto
                                   and pd.identidade = lt.iddepositante)
        loop
          if ((r_loteunicoBase.idProduto = r_loteunicoComp.Idproduto) and
             (r_loteunicoBase.vencimentouniconoendereco =
             r_loteunicoComp.Vencimentouniconoendereco)) then
            if ((r_loteunicoBase.loteindustria <>
               r_loteunicoComp.Loteindustria) or
               (r_loteunicoBase.dtvencimento <>
               r_loteunicoComp.Dtvencimento)) then
              v_msg := t_message('Remanejamento não pode ser concluído devido ao Lote {0} tem um prazo fabricação/vencimento diferente do Lote {1} armazenado neste local.');
              v_msg.addParam(r_loteunico.idlote);
              v_msg.addParam(r_loteunicoComp.idlote);
              raise_application_error(-20000, v_msg.formatMessage);
            end if;
          end if;
        end loop;
      end loop;
    end if;  
  end regraLoteVencimentoUnicoNoEnd;
  
end pk_remanejamento;
/

