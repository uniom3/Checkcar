create view ETL_PRODUTOS_NF_ENTRADA as
select nfProc.idnotafiscal,
       nfProc.codigointerno,
       nfProc.dataProcessamento,
       nfProc.idarmazem,
       a.codigointerno codigoArmazem,
       a.descr descrArmazem,
       nfProc.iddepositante,
       ed.codigointerno codigoDepositante,
       ed.razaosocial descrDepositante,
       nfproc.idproduto,
       p.codigointerno codigoProduto,
       p.descr descrProduto,
       nfproc.qtdeProcessada,
       (select ecx.fatorconversao
          from embalagem ecx
         where ecx.idproduto = nfproc.idproduto
           and ecx.ativo = 'S'
           and ecx.fatorconversao =
               (select max(ecxMf.fatorconversao)
                  from embalagem ecxMf
                 where ecxMf.idproduto = nfproc.idproduto
                   and ecxMf.ativo = 'S'
                   and rownum = 1)
           and rownum = 1) maiorFator,
       (eu.lastro * eu.qtdecamada) normaPalete
  from (select nf.idnotafiscal,
               nf.codigointerno,
               to_char(CAST(nf.dataprocessamento AS TIMESTAMP WITH TIME ZONE),
                       'RRRR-MM-DD"T"HH24:MI:SSTZH:TZM') dataprocessamento,
               nf.idarmazem,
               nf.iddepositante,
               n.idproduto,
               sum((n.qtdeatendida * e.fatorconversao)) qtdeProcessada
          from notafiscal nf, nfdet n, embalagem e
         where nf.tipo = 'E'
           and nf.movestoque = 'S'
           and exists (select 1
                  from lotenf lnf
                 where lnf.idlotenf = nf.idlotenf
                   and lnf.status = 'P')
           and n.nf = nf.idnotafiscal
           and e.idproduto = n.idproduto
           and e.barra = n.barra
         group by nf.idnotafiscal,
                  nf.codigointerno,
                  nf.dataprocessamento,
                  nf.idarmazem,
                  nf.iddepositante,
                  n.idproduto) nfProc,
       entidade ed,
       armazem a,
       produto p,
       embalagem eu
 where a.idarmazem = nfProc.idarmazem
   and ed.identidade = nfProc.iddepositante
   and p.idproduto = nfProc.idproduto
   and eu.idproduto = nfProc.idproduto
   and eu.barra =
       pk_produto.ret_codbarra_tratando_erro(nfProc.idproduto, 1)
/

